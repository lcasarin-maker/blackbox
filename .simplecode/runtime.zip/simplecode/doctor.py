"""Local setup diagnostics for people and automation."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import time
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from simplecode.utils.tool_limits import VERSION_PROBE_TIMEOUT


def _import_simplecode_probe(python: str, root: Path) -> subprocess.CompletedProcess[str] | None:
    try:
        return subprocess.run(
            [python, "-c", "import simplecode"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=VERSION_PROBE_TIMEOUT,
            check=False,
        )
    except OSError:
        return None


def _verification_interpreter_health(root: Path) -> dict[str, Any]:
    """Detect drift between the python a real git hook resolves and the
    python a person resolves when reproducing by hand.

    ``hook_install._preamble`` prepends ``.venv/bin`` to PATH before running
    any hook -- deliberately, so a project's own venv wins -- which means
    every bare ``python`` inside a task's ``verification_command`` silently
    resolves to ``.venv/bin/python`` during a real commit/push, but to
    whatever ``python`` is ambient on PATH (e.g. an interactive shell's own
    interpreter) when reproduced directly.

    Reported live by Atlas (2026-08-26): its ``.venv`` never had simplecode
    installed, only its interactive shell's python did, so every
    verification_command that imported simplecode failed 5/5 inside a real
    push but passed clean 15+/15+ reproduced by hand -- indistinguishable
    from an intermittent race until the two interpreters were compared
    side by side. No ``.venv`` at all means no drift is possible, since
    hooks and manual reproduction then resolve the same ambient python.
    """
    venv_python = root / ".venv" / "bin" / "python"
    if not venv_python.is_file():
        return {"ok": True, "detail": None}
    venv_probe = _import_simplecode_probe(str(venv_python), root)
    if venv_probe is not None and venv_probe.returncode == 0:
        return {"ok": True, "detail": None}
    ambient_probe = _import_simplecode_probe("python", root)
    if ambient_probe is None or ambient_probe.returncode != 0:
        # simplecode isn't importable anywhere for this repo -- nothing to drift.
        return {"ok": True, "detail": None}
    return {
        "ok": False,
        "detail": (
            f"{venv_python} cannot import simplecode, but the ambient 'python' "
            "on PATH can -- a real commit/push resolves the former (hooks "
            "prepend .venv/bin to PATH), so any verification_command that "
            "imports simplecode will fail only inside a real hook run, never "
            "when reproduced by hand. Fix: install simplecode into .venv "
            "itself, e.g. `.venv/bin/python -m pip install -e .`"
        ),
    }


def _fork_own_coverage(root: Path) -> dict[str, Any]:
    """Vendored code without a fork&own cosecha is fork-and-forget (ADR-0009).

    Every `vendored_paths`/`vendored_path_prefixes` entry in
    `corpus_exempt.yaml` must be covered by a cosecha's `local_paths` in the
    fork&own manifest -- that is what makes a project that starts 100%%
    original acquire the upstream watch the moment it vendors something.
    A manifest entry without `local_paths` covers no vendored paths. Keeping
    the registry non-empty is not evidence that its local vendor surface is
    watched.
    """
    from simplecode.guards.upstream_watch import load_manifest
    from simplecode.worktree.zero_debt import _load_corpus_exempt_list
    vendored = list(_load_corpus_exempt_list(root, "vendored_paths")) + list(
        _load_corpus_exempt_list(root, "vendored_path_prefixes"))
    if not vendored:
        return {"ok": True, "detail": None}
    cosechas, _ = load_manifest(root)
    declared = [
        str(path)
        for cosecha in cosechas
        if _valid_fork_own_identity(cosecha)
        for path in (cosecha.get("local_paths") or [])
    ]
    uncovered = [v for v in vendored
                 if not any(v.startswith(d) or d.startswith(v) for d in declared)]
    if not uncovered:
        return {"ok": True, "detail": None}
    return {"ok": False, "detail": (
        "vendored without a fork&own cosecha: " + ", ".join(uncovered[:3]) +
        " -- register {repo, ref, licencia, local_paths} in "
        ".simplecode/fork_own.json so upstream drift is watched (ADR-0009)")}


def _valid_fork_own_identity(cosecha: dict[str, Any]) -> bool:
    repo = cosecha.get("repo")
    ref = cosecha.get("ref")
    return (
        isinstance(repo, str)
        and re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo) is not None
        and isinstance(ref, str)
        and (re.fullmatch(r"[0-9a-fA-F]{40}", ref) is not None or ref == "GONE")
    )


def _upstream_watch_freshness(root: Path) -> dict[str, Any]:
    """Dead-man switch for the upstream-watch cron (ADR-0009).

    Clock-based ON PURPOSE and therefore NEVER part of the `healthy`
    conjunction: upstream movement is an external-world fact no local tree
    fingerprint can witness, so staleness here is measured in days -- but a
    clock must not gate a commit, so this check only ever prints.
    """
    from simplecode.guards.upstream_watch import STATE_FILE, load_manifest
    cosechas, _ = load_manifest(root)
    if not cosechas:
        return {"ok": True, "detail": None}
    stale_days = int(os.environ.get("SIMPLECODE_UPSTREAM_WATCH_STALE_DAYS", "14"))
    # Only repos the manifest still declares count: an orphan entry left by a
    # slug correction or a removed cosecha would otherwise set the age forever
    # (AUDIT-MI-HALLAZGO-MI-F038, measured 27 days from one orphan in Aequitas
    # while all 15 declared repos were 6 days old).
    declared = {c.get("repo") for c in cosechas}
    try:
        state = json.loads((root / STATE_FILE).read_text(encoding="utf-8"))
        stamps = [datetime.fromisoformat(entry["last_checked"])
                  for repo, entry in state["repos"].items()
                  if repo in declared and entry.get("last_checked")]
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        stamps = []
    if not stamps:
        return {"ok": False, "detail": (
            "fork&own manifest present but upstream-check has never recorded a "
            "run -- run `simplecode upstream-check` (ADR-0009)")}
    age = datetime.now(UTC) - min(stamps)
    if age.days <= stale_days:
        return {"ok": True, "detail": None}
    return {"ok": False, "detail": (
        f"upstream watch is stale: oldest check is {age.days} days old "
        f"(threshold {stale_days}) -- the cron may be dead; run "
        "`simplecode upstream-check` (ADR-0009)")}


def _kit_drift_freshness(root: Path) -> dict[str, Any]:
    """Dead-man switch for the kit-drift-check cron -- espejo de
    `_upstream_watch_freshness` (ADR-0009) para el drift kit-vs-satelite en vez
    de un upstream externo.

    Solo tiene sentido en la madre: el estado de `kit-drift-check` es
    fleet-wide (un archivo, `.simplecode/kit_drift_state.json`, con una
    entrada por satelite), no por-proyecto como el manifiesto de fork&own. Un
    satelite no tiene con que compararse a si mismo, asi que reporta `ok` sin
    mas -- lo mismo que `_upstream_watch_freshness` hace cuando el proyecto no
    tiene manifiesto: ausencia de sujeto no es lo mismo que un sujeto sano,
    pero tampoco es una alarma que el propio proyecto pueda resolver.

    Clock-based a proposito, y por eso NUNCA entra en la conjuncion `healthy`
    (mismo razonamiento que ADR-0009): el drift de la flota es un hecho
    externo a este arbol que ningun fingerprint local puede atestiguar.
    """
    from simplecode.satellite.satellite_sync import is_mother_repo
    if not is_mother_repo(root):
        return {"ok": True, "detail": None}
    from simplecode.guards.kit_drift_watch import STATE_FILE
    stale_days = int(os.environ.get("SIMPLECODE_KIT_DRIFT_STALE_DAYS", "14"))
    try:
        state = json.loads((root / STATE_FILE).read_text(encoding="utf-8"))
        stamps = [datetime.fromisoformat(entry["last_checked"])
                  for entry in state["satellites"].values() if entry.get("last_checked")]
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        stamps = []
    if not stamps:
        return {"ok": False, "detail": (
            "this is the mother repo, but kit-drift-check has never recorded a run -- "
            "run `simplecode kit-drift-check --fleet <projects-dir>`")}
    age = datetime.now(UTC) - min(stamps)
    if age.days <= stale_days:
        return {"ok": True, "detail": None}
    return {"ok": False, "detail": (
        f"kit-drift-check is stale: oldest check is {age.days} days old "
        f"(threshold {stale_days}) -- the cron may be dead; run "
        "`simplecode kit-drift-check --fleet <projects-dir>`")}


def _mother_package_sources(package_root: Path) -> list[tuple[str, bytes]]:
    """The (.py, .yaml) entries under a mother's src/simplecode, exactly as
    `cli_new.runtime_content_sha256` expects them.

    Duplicated from `cli_new._runtime_bundle` rather than called into it:
    that function reads `Path(__file__)`, which on a satellite resolves to
    the SATELLITE's own installed/bundled `doctor.py`, never to a reachable
    mother checkout elsewhere on disk. This walk is handed an explicit
    `package_root` instead, so it can be pointed at a different repo's tree.
    """
    return [
        (source.relative_to(package_root.parent).as_posix(), source.read_bytes())
        for source in sorted(package_root.rglob("*"))
        if source.is_file() and source.suffix in (".py", ".yaml")
    ]


def _runtime_freshness(root: Path) -> dict[str, Any]:
    """How far this satellite's bundled `runtime.zip` sits behind the mother,
    in minutes -- item 2 of DEBT-SURVEY-KIT-VERSION-UNKNOWABLE.

    `.simplecode/run.py`'s own hot-pull already runs this comparison on every
    hook invocation and ACTS on it (ADR-0012): resync when the mother's
    content digest no longer matches the bundle's declared one. This is the
    same comparison, surfaced as a standalone, human-readable answer -- "is
    the zip stale, and since when" -- callable without waiting for a hook to
    fire and without triggering a resync itself.

    Never part of `diagnose()`'s `healthy` conjunction by default: reported
    unconditionally so it survives as evidence, blocking only when
    `doctor --runtime` opts in. Additive, exactly like `upstream_watch_fresh`
    beside it, and for the same reason -- an existing green `doctor --gate`
    must not go red under people who never asked for this signal.
    """
    from simplecode import cli_new

    runtime_bundle = root / ".simplecode" / "runtime.zip"
    if not runtime_bundle.is_file():
        # Not itself a defect: `runtime_available` already says whether a
        # runtime exists at all. This mother repo runs from source and
        # carries no `runtime.zip` of its own, which is the common case this
        # branch reports, not an alarm.
        return {
            "ok": True,
            "state": "zip_absent",
            "stale_minutes": None,
            "detail": f"{runtime_bundle} is absent -- nothing bundled to compare for staleness",
        }
    try:
        with zipfile.ZipFile(runtime_bundle) as archive:
            manifest = json.loads(archive.read("RUNTIME_MANIFEST.json").decode("utf-8"))
    except (OSError, KeyError, ValueError, zipfile.BadZipFile) as exc:
        return {
            "ok": False,
            "state": "could_not_run",
            "stale_minutes": None,
            "detail": f"could not read {runtime_bundle}'s manifest: {exc}",
        }
    bundled_sha = str(manifest.get("content_sha256", ""))

    mother_pkg = root / "src" / "simplecode"
    mother_label = "this repo (running as the mother)"
    if not mother_pkg.is_dir():
        # Same reachability rule `.simplecode/run.py` uses for its hot-pull:
        # a mother checkout on the local workstation, at a fixed path.
        candidate = Path.home() / "projects" / "simplecode"
        candidate_pkg = candidate / "src" / "simplecode"
        if candidate_pkg.is_dir() and (candidate / "pyproject.toml").is_file():
            mother_pkg, mother_label = candidate_pkg, str(candidate)
        else:
            mother_pkg = None
    if mother_pkg is None:
        return {
            "ok": True,
            "state": "mother_absent",
            "stale_minutes": None,
            "detail": (
                "no mother repo reachable from here (this is not the mother, "
                "and ~/projects/simplecode is absent) -- staleness against it "
                "is unknowable, and that is reported rather than assumed fresh"
            ),
        }

    current_sha = cli_new.runtime_content_sha256(_mother_package_sources(mother_pkg))
    if current_sha == bundled_sha:
        return {
            "ok": True,
            "state": "up_to_date",
            "stale_minutes": 0,
            "detail": f"bundle matches {mother_label}'s current content ({current_sha[:12]})",
        }
    stale_minutes = int((time.time() - runtime_bundle.stat().st_mtime) // 60)
    return {
        "ok": False,
        "state": "stale",
        "stale_minutes": stale_minutes,
        "detail": (
            f"bundle content {bundled_sha[:12]} != {mother_label}'s current content "
            f"{current_sha[:12]}; this bundle was last written {stale_minutes} "
            f"minute(s) ago and has been serving that stale snapshot since"
        ),
    }


def diagnose(root: Path) -> dict[str, Any]:
    """Return stable, machine-readable setup facts for ``root``."""
    organ_root = root / "src" / "simplecode"
    if not organ_root.is_dir():
        organ_root = root / ".simplecode"
    runtime_bundle = root / ".simplecode" / "runtime.zip"
    if not organ_root.is_dir() and not runtime_bundle.is_file():
        organ_root = Path(__file__).resolve().parent

    organs: list[str] = []
    runtime_manifest: dict[str, Any] | None = None
    for group in ("verification", "worktree", "guards", "utils"):
        for path in (organ_root / group).glob("*.py"):
            if path.name != "__init__.py":
                try:
                    organs.append(str(path.relative_to(root)))
                except ValueError:
                    organs.append(f"simplecode/{group}/{path.name}")
    if runtime_bundle.is_file():
        try:
            with zipfile.ZipFile(runtime_bundle) as archive:
                organs.extend(
                    name
                    for name in archive.namelist()
                    if name.startswith("simplecode/")
                    and name.endswith(".py")
                    and "/__init__.py" not in name
                )
                # Which frozen snapshot is actually executing -- a gate run
                # through `.simplecode/run.py` uses this bundle, which can
                # silently drift from a "standalone" run against a live
                # install. Surfacing the fingerprint here is what turns an
                # unexplained hook-vs-standalone contradiction into a
                # diagnosable one: compare this hash against the currently
                # installed `simplecode` package's own bundle.
                try:
                    runtime_manifest = json.loads(
                        archive.read("RUNTIME_MANIFEST.json").decode("utf-8")
                    )
                except KeyError:
                    runtime_manifest = {"error": "no RUNTIME_MANIFEST.json in bundle (stale resync)"}
        except (OSError, zipfile.BadZipFile):
            organs.append("COULD_NOT_RUN: .simplecode/runtime.zip is corrupt")
    organs.sort()
    telemetry_file = Path(
        os.environ.get(
            "SIMPLECODE_TELEMETRY",
            root / ".simplecode" / "evidence" / "telemetry.jsonl",
        )
    )
    hooks_dir = root / ".git" / "hooks"
    hooks_installed = all((hooks_dir / name).is_file() for name in ("pre-commit", "pre-push", "post-commit"))
    return {
        "hooks_installed": hooks_installed,
        "spec_exists": (root / "SPEC.md").is_file(),
        "telemetry_dir": telemetry_file.parent.is_dir(),
        "telemetry_flowing": telemetry_file.is_file() and telemetry_file.stat().st_size > 0,
        "runtime_available": organ_root.is_dir() or runtime_bundle.is_file(),
        "runtime_manifest": runtime_manifest,
        "verification_interpreter": _verification_interpreter_health(root),
        "fork_own_coverage": _fork_own_coverage(root),
        "upstream_watch_fresh": _upstream_watch_freshness(root),
        "kit_drift_fresh": _kit_drift_freshness(root),
        "runtime_freshness": _runtime_freshness(root),
        "organs": organs,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", dest="as_json")
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--gate", action="store_true", help="Exit 1 if any required component is missing")
    parser.add_argument(
        "--runtime",
        action="store_true",
        help=(
            "Also gate on runtime_freshness (the bundled runtime.zip's staleness "
            "against the reachable mother). Opt-in: without this flag staleness "
            "is reported, exactly as before, and never blocks."
        ),
    )
    args = parser.parse_args(argv)
    result = diagnose(args.root.resolve())
    healthy = (
        result["hooks_installed"]
        and result["spec_exists"]
        and result["telemetry_flowing"]
        and result["runtime_available"]
        and result["verification_interpreter"]["ok"]
        # upstream_watch_fresh and kit_drift_fresh are deliberately absent: a
        # clock never gates (ADR-0009); both report below and that is all
        # they do.
        and result["fork_own_coverage"]["ok"]
        # runtime_freshness only joins the conjunction under --runtime: an
        # existing green `doctor --gate` must not go red under callers who
        # never asked for this signal (additive observability, SPEC axiom).
        and (result["runtime_freshness"]["ok"] or not args.runtime)
    )

    if args.as_json:
        print(json.dumps(result, sort_keys=True))
        return 0 if (healthy or not args.gate) else 1

    print("=== simplecode doctor ===")
    print("Hooks installed:", "OK" if result["hooks_installed"] else "MISSING")
    print("SPEC.md exists:", "YES" if result["spec_exists"] else "NO")
    print("Telemetry dir:", "EXISTS" if result["telemetry_dir"] else "MISSING")
    print("Telemetry flowing:", "YES" if result["telemetry_flowing"] else "NO")
    print("Runtime:", "AVAILABLE" if result["runtime_available"] else "MISSING")
    vi = result["verification_interpreter"]
    print("Verification interpreter:", "OK" if vi["ok"] else f"BROKEN -- {vi['detail']}")
    fo = result["fork_own_coverage"]
    print("Fork&own coverage:", "OK" if fo["ok"] else f"MISSING -- {fo['detail']}")
    uw = result["upstream_watch_fresh"]
    print("Upstream watch:", "FRESH" if uw["ok"] else f"STALE -- {uw['detail']}")
    kd = result["kit_drift_fresh"]
    print("Kit drift watch:", "FRESH" if kd["ok"] else f"STALE -- {kd['detail']}")
    rf = result["runtime_freshness"]
    rf_label = {
        "up_to_date": "UP TO DATE",
        "zip_absent": "N/A",
        "mother_absent": "UNKNOWABLE",
        "could_not_run": "COULD_NOT_RUN",
        "stale": f"STALE ({rf['stale_minutes']} min behind)",
    }[rf["state"]]
    print(f"Runtime freshness: {rf_label} -- {rf['detail']}")
    print("Organs present:")
    for organ in result["organs"]:
        print(f"  {organ}")
    return 0 if (healthy or not args.gate) else 1


if __name__ == "__main__":
    raise SystemExit(main())
