"""Optional Simplecode capability profiles, local to each repository."""
from __future__ import annotations

import json
from pathlib import Path

RELPATH = Path(".simplecode/profiles.json")


def enabled(root: Path, profile: str) -> tuple[bool, str | None]:
    """Return whether a profile is declared; absent config means intentionally off."""
    path = root / RELPATH
    if not path.exists():
        return False, None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return False, f"cannot read {RELPATH}: {exc}"
    values = raw.get("enabled") if isinstance(raw, dict) else None
    if not isinstance(values, list) or not all(isinstance(item, str) for item in values):
        return False, f"{RELPATH} requires object key 'enabled' with a string list"
    return profile in values, None
