#!/usr/bin/env python3
"""A commit message that says it closed a ficha must show that ficha closing.

DEBT-COMMIT-MESSAGE-UNCHECKED-AGAINST-DIFF. Three commits in one session
(2026-09-02) carried a message describing work their diff did not contain, and
all three passed all twenty-one gates, because no gate reads the message.

`staged-parity` catches two SPECIFIC consequences -- a staged import the commit
would not contain, and a silent reopening of a closed entry. Neither reads the
message; both catch a diff that is wrong on its own terms. The third case, a
message ASSERTING something the diff does not do, had nothing.

WHAT THIS CHECKS, AND WHY ONLY THIS
-----------------------------------
One claim, mechanically decidable: **a message that names ficha ids as closed
must contain those fichas reaching `status: done` in the same commit.**

The ficha is explicit about what must NOT be attempted: a general "does the
message describe the diff" check. That is a judgement, and a gate that renders
judgement on prose either passes everything or blocks honest work -- and both
teach people to skip it. So this reads exactly one verb pattern and says nothing
about the rest of the message.

WHAT IT CANNOT SEE, stated rather than discovered later
-------------------------------------------------------
* A message that claims anything else -- "added X", "fixed Y" -- is not checked.
  Those are the general case and are deliberately out of scope.
* A ficha closed in a DIFFERENT commit of the same push. The check is per
  commit, because that is the unit a commit message describes.
* A claim spelled in a way the patterns below do not match. Every such spelling
  is a silent miss, which is why the patterns cover the forms actually used in
  this fleet's history rather than a general grammar.
* A closure mentioned ONLY in the message body. Only the subject line and
  explicit `Closes:` trailers are read, because a body is narrative and
  narrative discusses other commits -- this gate convicted the very commit that
  introduced it for describing, in past tense, what another commit had closed.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

from simplecode.utils.tool_limits import GIT_O1_TIMEOUT

# A ficha id, and the case is NOT optional. Calibrated against this session's own
# 36 commits before wiring anything: with `re.IGNORECASE` on the id, the first
# version flagged 15 of 36, and almost all were the conventional-commit scope --
# `fix(build-tools):`, `fix(zero-debt):`, `fix(gate-effectiveness):`. IGNORECASE
# made `[A-Z]` match lowercase, so every hyphenated word near a claim verb became
# a ficha id.
#
# A gate with a ~90% false-positive rate on real history is worse than no gate:
# it teaches its reader to skip it, and then the true positive goes past too.
# The measurement is why this shipped narrow instead of eager.
#
# So the id must look like one: SCREAMING-KEBAB with at least one segment that is
# not purely alphabetic, which is what every ficha id in this fleet has
# (DEBT-P2-01, DEBT-SPEC8-MUTATION-CI, CANON-ADOPT, AQ-CORPUS-001) and what a
# commit scope never has.
_FICHA_ID = r"\b([A-Z][A-Z0-9]*(?:-[A-Z0-9][A-Z0-9._]*)+)\b"
# Ends at a word boundary: `close_check` is an identifier, not the verb `close`.
_VERB = r"(?:clos(?:e|es|ed|ing)|cierr[ae]|cerrada?s?|resuelv[ae]|resuelta?s?)\b"

# Claim forms measured in this fleet's own history, English and Spanish. A form
# not listed here is a silent miss, named in the module docstring.
_CLAIM_RE = re.compile(_VERB + r"[^\n]{0,40}?" + _FICHA_ID, re.IGNORECASE)
# Found on THIS repo's own history (2026-09-05): "give DEBT-X real closing
# evidence" matched the reversed form -- "closing" as a gerund is not a claim
# when it modifies a following noun ("closing evidence", the artifact a
# closure needs), only when it stands alone as the sentence's verb ("DEBT-X:
# closing", "DEBT-X closed"). The negative lookahead excludes exactly the
# compound-noun shape without touching the real claim forms below it.
_CLAIM_REVERSED_RE = re.compile(
    _FICHA_ID + r"[^\n]{0,20}?\b" + _VERB
    + r"\b(?!\s+(?:evidence|argument|statement|note|remarks?|report))",
    re.IGNORECASE,
)


def _looks_like_a_ficha_id(token: str) -> bool:
    """SCREAMING-KEBAB with a non-alphabetic segment, or a known ficha prefix.

    `BUILD-TOOLS` and `ZERO-DEBT` are commit scopes shouting; `DEBT-P2-01` and
    `CANON-ADOPT` are ids. The discriminator that survives both: an id either
    carries a segment with a digit, or starts with a prefix this fleet actually
    uses for fichas.
    """
    if token != token.upper():
        return False
    # The FIRST segment must be a prefix this fleet actually uses. The earlier
    # rule -- "any segment contains a digit" -- was looser and let prose through:
    # re-calibrated on this session's 36 commits it still flagged `P1-A`, which
    # is a label inside a commit body ("P1-A: the closing contract...") and not a
    # ficha at all. Two heuristics were one too many.
    return token.split("-")[0] in _FICHA_PREFIXES


# Prefixes measured across the fleet's tasks/ trees, 2026-09-05.
_FICHA_PREFIXES = frozenset({
    "DEBT", "TASK", "CANON", "AQ", "DGX", "CONV", "WARN", "REQ", "LIMIT", "AUDIT",
})


def claimed_closed(message: str) -> set[str]:
    """Ficha ids the message says it closed.

    Lines beginning `#` are git's own comments and are skipped: a commit
    template that lists open fichas as a reminder must not become a claim.
    """
    # ONLY the subject line and explicit `Closes:`-style trailers. The body is
    # narrative, and narrative talks about OTHER commits.
    #
    # Found by this gate convicting the commit that INTRODUCED it: its body said
    # "the gate accused the very commit that closed DEBT-GS2-04 and DEBT-P2-01",
    # which is a description of a past event, not a claim about this diff. The
    # ficha warned that a gate rendering judgement on prose "will either pass
    # everything or block honest work"; reading the whole body was the second.
    #
    # Subject + trailer is a real git convention, not one invented here, and it
    # is where a closure is actually declared. A closure mentioned only in
    # narrative is a silent miss, named in the module docstring.
    lines = [ln for ln in message.splitlines() if not ln.lstrip().startswith("#")]
    if not lines:
        return set()
    considered = [lines[0]]
    considered += [
        ln for ln in lines[1:]
        if re.match(r"^\s*(?:closes|cierra|fixes|resuelve)\s*:", ln, re.IGNORECASE)
    ]
    body = "\n".join(considered)
    # A verb claims EVERY id in the clause that follows it, not just the first.
    # `_CLAIM_RE` is non-greedy and `finditer` resumes past its match, so
    # "cierra CANON-ADOPT y DEBT-GS2-04" yielded only the first -- and the
    # second closure would have gone unchecked, which is the whole point of the
    # gate.
    ids: set[str] = set()
    for m in re.finditer(_VERB, body, re.IGNORECASE):
        window = body[m.end(): m.end() + 80].split("\n", 1)[0]
        ids |= set(re.findall(_FICHA_ID, window))
    ids |= {m.group(1) for m in _CLAIM_REVERSED_RE.finditer(body)}
    # A version is not a ficha; nor is a lower-case or scope-shaped token.
    return {
        i for i in ids
        if _looks_like_a_ficha_id(i) and not re.fullmatch(r"[A-Z]+-\d+\.\d+.*", i)
    }


def _staged_diff(root: Path) -> str:
    try:
        out = subprocess.run(
            # `-M` is required or a pure MOVE carries no rename line and the
            # closure it performs is invisible. Without it this reported the very
            # commit that closed DEBT-GS2-04 and DEBT-P2-01 -- by moving them --
            # as making unbacked claims about them.
            ["git", "diff", "--cached", "--unified=0", "-M"],
            cwd=root, capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return out.stdout if out.returncode == 0 else ""


def closed_in_diff(diff: str) -> set[str]:
    """Ficha ids this diff actually moves to a closed state.

    Two spellings, because the repo uses both: a `status: done` line ADDED, and
    a file appearing under `tasks/done/`.
    """
    closed: set[str] = set()
    current: str | None = None
    for line in diff.splitlines():
        if line.startswith("rename to ") and "tasks/done/" in line:
            # A pure rename carries no `+status: done` line. Missed by the first
            # version, which reported the commit that closed DEBT-GS2-04 and
            # DEBT-P2-01 as making unbacked claims -- it had closed them by
            # moving them.
            closed.add(Path(line[len("rename to "):].strip()).stem.upper())
        elif line.startswith("+++ b/"):
            path = line[6:]
            current = Path(path).stem if path != "/dev/null" else None
            if "tasks/done/" in path and current:
                closed.add(current.upper())
        elif line.startswith("+") and current and re.match(r"\+status:\s*done\b", line):
            closed.add(current.upper())
    return closed


def _backed_by(claim: str, closed: set[str]) -> bool:
    """Whether `claim` names one of the fichas `closed` contains.

    A ficha's FILENAME often carries a slug after its id --
    `DEBT-GS2-04-ghost-tool-and-contract-verifier.md` closes `DEBT-GS2-04` -- so
    equality is the wrong test. Found by calibrating on this session's own
    commits: the run that closed DEBT-GS2-04 and DEBT-P2-01 was reported as
    claiming them falsely, because their stems merely START with their ids.

    The boundary matters: `DEBT-P2-01` must not be satisfied by `DEBT-P2-011`,
    so a match needs the id followed by `-` or by nothing at all.
    """
    return any(c == claim or c.startswith(claim + "-") for c in closed)


def check(root: Path, message: str) -> list[str]:
    """Claims the message makes that its own staged diff does not back."""
    claims = claimed_closed(message)
    if not claims:
        return []
    actually = closed_in_diff(_staged_diff(root))
    return sorted(c for c in claims if not _backed_by(c, actually))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("message_file", type=Path, nargs="?",
                    help="the file git passes to a commit-msg hook")
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--gate", action="store_true", help="exit 1 on an unbacked claim")
    args = ap.parse_args(argv)

    if args.message_file is None:
        # INSTRUMENTO CAIDO: no fue invocado con un mensaje que mirar.
        print("[commit-msg-claims] COULD_NOT_RUN: no message file given", file=sys.stderr)
        return 2
    try:
        message = args.message_file.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        # INSTRUMENTO CAIDO: el mensaje no se pudo leer, nunca "sin claims".
        print(f"[commit-msg-claims] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 2

    claims = claimed_closed(message)
    unbacked = check(args.root.resolve(), message)
    print(f"[commit-msg] closure claims in this message: {len(claims)}"
          + (f" ({', '.join(sorted(claims))})" if claims else ""))
    if not unbacked:
        print("[commit-msg] OK: every closure this message claims is in its own diff.")
        return 0
    print(f"[commit-msg-claims] UNBACKED CLAIM: {len(unbacked)} ficha(s) this message says it "
          f"closed do NOT reach `status: done` in this commit:", file=sys.stderr)
    for ident in unbacked:
        print(f"  - {ident}", file=sys.stderr)
    print("Either stage the closure, or stop claiming it. A message that describes "
          "work its diff does not contain passed all twenty-one gates three times "
          "in one session, because no gate read it.", file=sys.stderr)
    if args.gate:
        # CONDENA: miro el diff y el mensaje, y el primero no respalda al segundo.
        print(f"[commit-msg-claims] FAIL: {len(unbacked)} unbacked closure claim(s); "
              f"primera {unbacked[0]}")
    return 1 if args.gate else 0


if __name__ == "__main__":
    sys.exit(main())
