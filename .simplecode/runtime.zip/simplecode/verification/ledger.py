#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ledger -- the one reader of the canonical task corpus.

The task corpus lives under ``tasks/backlog`` and ``tasks/done``. A legacy
``ledger/entries`` tree is read only to surface it as unresolved migration work;
it never wins over the canonical task tree.

    repo            ledger/ open      tasks/backlog/ (what ship-freeze read)
    office2office   791 of 791        1
    declutter        95 of 95         0
    cuenza          102 of 102        5

988 open entries in three repos; the gate saw 6. In declutter it saw zero and
reported the repository clean. Mould (a): the instrument points at a subject
that no longer exists.

This module is the single seat for that reading, on purpose. Today's other
defect was a bare directory test for `.git` living in five places, fixed in one
and blind in the other four; a corpus reader duplicated across `finding_backlog`,
`backlog_verifier` and whatever comes next would repeat it with higher stakes.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import yaml

# The canon's state vocabulary (Atlas `docs/LEDGER_CONTRACT.md`, f432d3e3).
DONE_STATE = "done"

# Legacy synonyms in an imported record. `void` is NOT one of them: void means
# "this turned out not to be debt" and counts in neither direction, while done
# means "it was debt and it is fixed" and owes evidence.
#
# `done_unverified` joined this set 2026-09-22 (DEBT-done-unverified-two-organs-disagree,
# Luis's decision: "ciérralas para ship-freeze"). Before this it counted as OPEN here while
# `backlog_verifier`/`close_check_discrimina` already treated it as a closed cohort -- two
# organs of the same kit classifying the same status differently, parked as a comment for
# months until declutter-fa hit it live: 36 honestly-closed fichas from a documented
# re-verification campaign (DECL-GOV-175) needed `done_unverified` to satisfy
# close_check_discrimina, and doing so would have opened 36 new ship-freeze rows. The
# evasion risk this set exists to block (mass-relabeling real debt to dodge the gate) stays
# visible instead of hidden: `done_unverified` still requires `unverified_reason` in prose
# (ledger_schema._validar_status_done_unverified), and close_check_discrimina already
# distinguishes it from `done` (which owes real evidence) by name, not by silence.
_DONE_SYNONYMS = frozenset({DONE_STATE, "closed", "cerrado", "resolved-verified", "done_unverified"})

_TASKS_RELDIR = "tasks"
LEDGER_RELPATH = Path("ledger") / "entries"

_ID_RE = re.compile(r"^id:\s*(\S+)\s*$", re.M)
_STATUS_RE = re.compile(r"^status:\s*(.+?)\s*$", re.M)

SOURCE_TASKS = "tasks"
SOURCE_LEDGER = "ledger"


@dataclass(frozen=True)
class Entry:
    """One corpus entry, from whichever tree supplied it."""

    id: str
    status: str
    path: Path
    source: str
    content: str

    @property
    def is_open(self) -> bool:
        """Whether this entry counts as outstanding debt.

        Anything not recognised counts as OPEN: an unreadable state is not a
        clean one, and the strict zero-debt invariant has always treated an
        unknown label as outstanding. **`void` is now one of those unknowns.**

        It used to count in neither direction, and that made this gate disagree
        with the canon. Measured 2026-09-05:

            a ficha with `status: void`
              finding_backlog (pre-push):  open debt 0, "1 void"   rc=0
              ledger_schema  (pre-commit): status out of domain    rc=1

        It passed the push gate and blocked the commit gate, so no repo could
        actually use it -- and none did: **0 fichas across all 17 repos**.
        `ledger_schema.STATUS` dropped it on Luis's 2026-09-02 decision ("solo 2
        estados"), and this organ was never told. Luis voted 2026-09-05 to
        settle it here rather than restore the third state.

        A `void` ficha therefore blocks now, by the unknown-label rule, and its
        name appears in the open list so whoever wrote it can see why.
        """
        return self.status.strip().lower() not in _DONE_SYNONYMS


def _entry_from_file(path: Path, source: str) -> Entry:
    """Read one entry. An unreadable file is an OPEN entry, never a missing one."""
    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        return Entry(id=path.stem, status=f"unreadable ({exc})", path=path, source=source, content="")
    id_match = _ID_RE.search(content)
    # The id is taken VERBATIM and never normalised: 177 of 182 real ids in the
    # fleet fail any shape pattern (`DEBT-ruff-rag-entity-graph-py-157-5-...`),
    # so normalising stops the deduplicator finding the pairs it exists to find
    # and would double-count all 988.
    entry_id = id_match.group(1) if id_match else path.stem
    status_match = _STATUS_RE.search(content)
    # The state is declared by the FIELD, never inferred from the path: measured
    # across the fleet, 605 of 2,742 entries disagreed with their own directory,
    # and RePic holds 33 in `backlog/` declaring `status: closed`. A counter that
    # reads the path returns a reassuring zero in a repo full of live debt.
    status = status_match.group(1).strip() if status_match else "missing"
    return Entry(id=entry_id, status=status, path=path, source=source, content=content)


def _task_files(root: Path, task_globs: tuple[str, ...]) -> list[Path]:
    directory = root / _TASKS_RELDIR / "backlog"
    if not directory.is_dir():
        return []
    seen: set[Path] = set()
    for pattern in task_globs:
        seen.update(directory.glob(pattern))
    return sorted(seen)


def _ledger_files(root: Path) -> list[Path]:
    directory = root / LEDGER_RELPATH
    return sorted(p for p in directory.rglob("*.md") if p.name != "README.md") if directory.is_dir() else []


def read_corpus(root: Path, task_globs: tuple[str, ...]) -> dict[str, Entry]:
    """Canonical tasks plus legacy entries, deduplicated by stable id.

    A canonical task wins over a legacy copy. This compatibility read prevents
    a legacy tree from disappearing from the debt report before migration.

    The precedence is the owner's, voted 2026-09-02: *`ledger/` manda; `tasks/`
    sólo aporta ids que `ledger` no tiene.* It is applied EXPLICITLY here rather
    than left to emerge from iteration order, because the canon session's own
    migration tool did the opposite by accident and returned a verified closure
    -- `done` with all three evidence artifacts, the first real one under the
    contract -- back to `active` with no check. Letting `tasks/` win over a
    closed ledger entry destroys the most expensive thing in the corpus.

    Ruled out with it: reading only `ledger/` (declares resolved whatever stayed
    behind in `tasks/`) and reading only `tasks/` (the 988 stay invisible).
    """
    corpus: dict[str, Entry] = {}
    for path in _ledger_files(root):
        entry = _entry_from_file(path, SOURCE_LEDGER)
        corpus.setdefault(entry.id, entry)
    for path in _task_files(root, task_globs):
        entry = _entry_from_file(path, SOURCE_TASKS)
        corpus[entry.id] = entry
    return corpus


_FRONTMATTER_RE = re.compile(r"\A---\n(.*?)\n---\s*\n", re.S)


def evidence_fail_path(content: str) -> str:
    r"""The `evidence.fail` path an entry declares, or "" -- by PARSING, not grep.

    The canon's own validator does `fm["evidence"].get("fail")`; this used to do
    `re.search(r"^\s*fail:\s*\S+")` on the raw text. Both forms of the field
    parse to the same mapping under YAML --

        evidence:                     evidence: {"pass": "...", "fail": "...", "e2e": "..."}
          fail: path/to/fail.txt

    -- so the difference was never in the data, only in one reader grepping
    where the other parsed. Measured by the aequitas_os session 2026-09-02: 23
    entries with all three artifacts present on disk were each reported
    "done with no evidence.fail artifact", because they use the inline form,
    and that blocks ship-freeze in every repo adopting the canon.

    Unparseable frontmatter returns "" and therefore blocks: a file whose
    header cannot be read has not shown its evidence.
    """
    match = _FRONTMATTER_RE.match(content)
    if match is None:
        return ""
    try:
        data = yaml.safe_load(match.group(1))
    except yaml.YAMLError:
        return ""
    if not isinstance(data, dict):
        return ""
    evidence = data.get("evidence")
    if not isinstance(evidence, dict):
        return ""
    fail = evidence.get("fail")
    return str(fail).strip() if isinstance(fail, (str, int, float)) and str(fail).strip() else ""


def census(corpus: dict[str, Entry]) -> dict[str, int]:
    """Counts that always print, zeros included."""
    values = list(corpus.values())
    return {
        "total": len(values),
        "open": sum(1 for e in values if e.is_open),
        "from_ledger": sum(1 for e in values if e.source == SOURCE_LEDGER),
        "from_tasks": sum(1 for e in values if e.source == SOURCE_TASKS),
    }
