#!/usr/bin/env python3
"""Un limite declarado en prosa tiene que nombrar la ficha que lo rastrea.

Generalizado desde `gates/deuda_declarada.py` en descargaSAT (auditoria de flota
2026-09-07, ver DEBT-FLEET-GENERALIZATION-CANDIDATES-2026-09-07 item 2). EL AGUJERO QUE
CIERRA, medido alli el 2026-09-05: `ship-freeze` cuenta fichas con `status: open` y
bloquea si hay alguna -- pero eso mide si alguien ESCRIBIO la deuda, no si la deuda
existe:

    08:00  el riesgo existe, declarado solo en un comentario o docstring -> ship-freeze VERDE
    13:00  el mismo riesgo, ya fichado                                   -> ship-freeze ROJO

Entre las dos lecturas no cambio una linea de codigo funcional. Cambio donde estaba el
texto. Un sistema asi premia NO escribir la deuda, que es exactamente al reves de lo que
quiere. Este gate ataca la otra mitad: si el codigo dice "LIMITE DECLARADO" o equivalente,
tiene que nombrar una ficha que exista de verdad -- asi el limite deja de ser prosa que
nadie vuelve a leer y pasa a colgar de algo que un `zero-debt`/`backlog` real si cuenta.

POR QUE MIRA COMENTARIOS Y DOCSTRINGS Y NO LINEAS CRUDAS. La primera version (descargaSAT)
probo una expresion regular sobre el texto completo del fichero y cazo nombres de
variable (`if limite:`, `args.limite`) como falsos positivos. Aqui los comentarios salen
de `tokenize` y los docstrings de `ast`, asi que el codigo ejecutable no se mira.

POR QUE LOS IDS SE COMPRUEBAN CONTRA DISCO Y NO CONTRA UNA LISTA DE PREFIJOS. Cada repo de
la flota usa sus propios prefijos (`DEBT-`, `DECL-`, `DGX-`, `CANON-`, `CONV-`, `ADR-`...);
codificar una lista fija solo cazaria los prefijos de HOY. En su lugar se busca cualquier
token con forma de id (mayusculas-numeros con guiones) y se acepta solo si coincide con
un id que existe de verdad en `tasks/` -- lo que consulta el propio repo en vez de
adivinar su vocabulario.

LO QUE NO COMPRUEBA, y conviene saberlo: que la ficha DIGA lo que el limite dice. Se
comprueba que exista. Un limite que apunte a una ficha equivocada pasa este gate, y eso
solo lo caza leer.

Uso: python -m simplecode.verification.deuda_declarada --root . [--json]
"""
from __future__ import annotations

import argparse
import ast
import io
import json
import re
import tokenize
from pathlib import Path

# Marcas DECLARADAS, no heuristica -- las que un repo usa a proposito para decir "esto no
# esta verificado". En MAYUSCULAS y sensible a mayusculas a proposito: un limite declarado
# se escribe como encabezado gritado, y eso lo distingue de la prosa corriente que
# menciona la misma palabra de pasada.
MARCAS = re.compile(
    r"LIMITE DECLARADO|LO QUE NO SE PUDO|LO QUE NO SE PRUEBA|LIMITE, |LIMITE:|LIMITE \("
)
MARCAS_MINUSCULA = re.compile(r"prueba que falta|sigue sin probarse", re.IGNORECASE)

# Retro-referencias: "ver el limite declarado arriba" APUNTA a un limite, no declara uno
# nuevo. Exigirle su propia ficha duplicaria la referencia en cada mencion.
REMISION = re.compile(r"ver el limite declarado|ver el limite de|descrito arriba", re.IGNORECASE)

# Forma generica de un id de ficha: token en mayusculas-numeros-guiones de al menos dos
# segmentos (ej. DEBT-FLEET-09, DECL-GOV-113, ADR-0009). Solo cuenta si ademas existe en
# `ids_existentes()` -- este regex es deliberadamente permisivo, la lista real filtra.
ID_CANDIDATO = re.compile(r"\b[A-Z]{2,}(?:-[A-Za-z0-9]+)+\b")

# Cuantas lineas alrededor de la marca se admite la referencia -- hacia arriba y hacia
# abajo. Un limite se explica en un parrafo; dentro de un parrafo la ficha puede
# nombrarse antes de la frase que la necesita.
VENTANA_ADELANTE = 16
VENTANA_ATRAS = 12

# El propio modulo y su test se auto-excluyen: el docstring de arriba NOMBRA las marcas
# para explicarlas, asi que se cazaria a si mismo eternamente -- self_polluting_tooling,
# declarado en vez de resuelto con una excepcion muda.
AUTOEXCLUIDOS = {
    "src/simplecode/verification/deuda_declarada.py",
    "tests/test_deuda_declarada.py",
}


def ids_existentes(root: Path) -> set[str]:
    """Los ids de ficha que existen en disco, en cualquier estado (`tasks/**/*.md`)."""
    ids = set()
    tasks_dir = root / "tasks"
    if tasks_dir.is_dir():
        for ruta in tasks_dir.rglob("*.md"):
            ids.add(ruta.stem)
    return ids


def _prosa(ruta: Path) -> list[tuple[int, str]]:
    """[(linea, texto)] de comentarios y docstrings de un `.py`. El codigo NO entra."""
    fuente = ruta.read_text(encoding="utf-8")
    trozos: list[tuple[int, str]] = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(fuente).readline):
            if tok.type == tokenize.COMMENT:
                trozos.append((tok.start[0], tok.string))
    except (tokenize.TokenError, IndentationError, SyntaxError):
        pass
    try:
        arbol = ast.parse(fuente)
    except SyntaxError:
        return trozos
    for nodo in ast.walk(arbol):
        if isinstance(nodo, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            doc = ast.get_docstring(nodo, clean=False)
            if doc:
                base = getattr(nodo, "lineno", 1)
                for i, linea in enumerate(doc.splitlines()):
                    trozos.append((base + i, linea))
    return trozos


def _texto_plano(ruta: Path) -> list[tuple[int, str]]:
    return list(enumerate(ruta.read_text(encoding="utf-8").splitlines(), 1))


def _objetivos(root: Path) -> list[Path]:
    objetivos: list[Path] = []
    for carpeta in ("src", "tests"):
        d = root / carpeta
        if d.is_dir():
            objetivos += sorted(d.rglob("*.py"))
    for nombre in ("SPEC.md", "README.md"):
        f = root / nombre
        if f.is_file():
            objetivos.append(f)
    return objetivos


def revisar(root: Path) -> tuple[list[tuple[str, int, str]], list[tuple[str, int, str]]]:
    """(huerfanas, atadas). Una marca es huerfana si no nombra una ficha QUE EXISTE."""
    ids = ids_existentes(root)
    huerfanas: list[tuple[str, int, str]] = []
    atadas: list[tuple[str, int, str]] = []
    for ruta in _objetivos(root):
        rel = ruta.relative_to(root).as_posix()
        if rel in AUTOEXCLUIDOS:
            continue
        lineas = _prosa(ruta) if ruta.suffix == ".py" else _texto_plano(ruta)
        indice: dict[int, list[str]] = {}
        for n, t in lineas:
            indice.setdefault(n, []).append(t)
        for n, t in lineas:
            if not (MARCAS.search(t) or MARCAS_MINUSCULA.search(t)):
                continue
            if REMISION.search(t):
                continue
            ventana = " ".join(
                x
                for m in range(n - VENTANA_ATRAS, n + VENTANA_ADELANTE)
                for x in indice.get(m, [])
            )
            citadas = {c for c in ID_CANDIDATO.findall(ventana) if c in ids}
            (atadas if citadas else huerfanas).append((rel, n, t.strip()[:70]))
    return huerfanas, atadas


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    root = args.root

    huerfanas, atadas = revisar(root)
    if args.json:
        print(json.dumps({
            "huerfanas": len(huerfanas),
            "atadas": len(atadas),
            "detalle": huerfanas,
        }, ensure_ascii=False))
        return 1 if huerfanas else 0

    total = len(huerfanas) + len(atadas)
    if huerfanas:
        print(
            f"[deuda-declarada] FAIL: {len(huerfanas)} de {total} limite(s) declarado(s) "
            f"no nombran ninguna ficha existente:"
        )
        for rel, n, t in huerfanas:
            print(f"  {rel}:{n}  {t}")
        print("  Un limite que no cuelga de una ficha no lo cuenta el backlog, y nadie")
        print("  vuelve a leerlo. Anade el id de la ficha que lo rastrea en el mismo parrafo.")
        return 1
    print(f"[deuda-declarada] OK: los {total} limite(s) declarado(s) nombran su ficha.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
