# -*- coding: utf-8 -*-
"""adversarial_judge.py -- Automated Red-Team Adversarial Judge (Judge-Zero).

Coordinates the source audits below. Coverage, typing, mutation, dependency,
and runtime gates enforce the remaining forensic axioms separately:
1. Anti-Mock-Theater (Rule GS2-216): Verifies tests don't swallow errors with blind mocks.
2. Source disguise: homoglyphs and bidi/zero-width characters in the code --
   code that reads differently from what it executes.

Trimmed 2026-09-27 on Luis's vote, per docs/gate_audit_2026-09-26/
veredicto_producto/adversarial-judge.md: the debt-ficha contract, broken
markdown evidence pins, unselected mandatory ruff rules and the prompt-injection
regex left this gate -- none of them is a product defect.

Angry Path Dominance (Rule B3) and the Corruption & Mojibake Guard are NOT
re-audited here (2026-08-31 dedup pass): both are dedicated hooks
(`angry-path`, `corruption-guard` -- .pre-commit-config.yaml, stages `pre-commit`
and `pre-merge-commit`; `adversarial-judge` runs at `pre-push`) that gate every
commit on failure. By the time this module runs at push, every committed file it
would re-scan has already passed those exact checks at its commit -- re-running
`angry_path.inspect_angry_path`/`corruption_guard.scan` here produced no new
information, only duplicate work (confirmed via the two hooks' own source,
not assumed). Removed rather than cached: neither check belongs to Judge-Zero's
actual job (mock-theater/agent-threat forensics), a dedicated hook already owns
each, and nothing outside the `adversarial-judge` pre-push hook calls this module standalone.

SCOPE OF THE SWEEPS (read before trusting a PASS)
-------------------------------------------------
This module is NOT a full-repo forensic sweep, and a clean verdict says nothing
about the directories it never opens. The audits below read exactly:

* Mock theater  -> ``<root>/tests/**/*.py`` (excluding any ``fixtures`` segment).
* Source disguise -> every tree in ``AGENT_THREAT_TREES`` that EXISTS in the repo.

Widened 2026-09-04 from ``src/`` alone to the trees SPEC section 8 named, on
Luis's ballot (option "widen here and measure", DEBT-SPEC8-JUDGE-SWEEP-SCOPE).
The measurement that preceded the wiring: in this repo the widened sweep adds
``scripts/`` (2 files) and convicts 0 -- ``daemon/``, ``central/`` and
``installer/`` do not exist here at all. A 0 measured on a sweep whose teeth
were never shown is worth nothing, so ``test_adversarial_judge.py`` plants a
real homoglyph under ``scripts/`` and asserts the widened sweep convicts it
while the old ``src/``-only scope stays blind to the same file.

What a clean verdict still does NOT cover: any top-level tree not named in
``AGENT_THREAT_TREES``, and, in a repo where one of those trees is absent, that
tree. Absence is not coverage, so ``sweep_coverage`` reports swept and absent
trees BY NAME and the CLI prints both lines on a PASS. Reading "OK" without
reading which trees produced it is how a sweep of two files gets mistaken for
a sweep of the product.
"""
from __future__ import annotations

import argparse
import ast
import builtins
import json
import logging
import math
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

from simplecode.verification import ledger_schema
from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.tool_limits import SMOKE_SUITE_TIMEOUT, compute_proportional_timeout

logger = logging.getLogger(__name__)


def _reject_nonfinite_json_number(value: str) -> None:
    raise ValueError(f"Non-finite JSON number: {value}")

# Throughput budget for the dynamic pytest invariant run, in bytes of test
# SOURCE processed per second. This is a measured rate, not a fixed timeout:
# the wall clock is derived from it and the real byte count of ``tests/``.
#
# Measurement on the reference host (2026-08-23), the exact command the judge
# issues -- `python -m pytest -q -p no:cov -o testpaths=tests`:
#     349,953 bytes across 51 test modules / 372 tests -> 2.974s real
#     => ~117,000 bytes of test source per second.
# Calibrated at 20,000 B/s, ~5.9x slower than measured, so that a loaded or
# cold CI host cannot manufacture a fabricated timeout finding. At the current
# corpus this yields 30.0 + 349953/20000 = 47.5s against a 2.974s reality.
PYTEST_SUITE_BYTES_PER_SEC = 20_000.0

# File-level prefilter. It must be at least as wide as the per-node check in
# ``_check_test_node_mock_theater``, otherwise a file is dropped before the AST
# walk ever runs: a module whose only mocking is a bare ``@patch("pkg.dep")``
# decorator matched none of these patterns and was skipped whole.
MOCK_THEATER_PATTERNS = (
    "unittest.mock.patch",
    "patch(",
    "patch.object(",
    "patch.dict(",
    "pytest.raises",
    "monkeypatch",
    "Mock(",
    "MagicMock(",
    "except ",
    "except:",
)


def get_judge_zero_prompt(root: Path | None = None) -> str:
    """Load the canonical JUDGE-ZERO V3.0 system prompt."""
    if root is not None:
        p = root / ".agents" / "judge.md"
        if p.is_file():
            try:
                return p.read_text(encoding="utf-8")
            except OSError as exc:
                logger.debug("Could not read prompt from %s: %s", p, exc)
    return "JUDGE-ZERO V3.0 FORENSIC AUDITOR PROMPT"


def _normalize_severity_score(raw: Any) -> int:
    if isinstance(raw, bool):
        return 5
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str):
        val = raw.upper().strip()
        if val in ("CRITICAL", "P0"):
            return 9
        if val in ("HIGH", "P1"):
            return 7
        if val in ("MEDIUM", "P2"):
            return 5
        if val in ("LOW", "P3"):
            return 3
        try:
            return int(val)
        except ValueError:
            return 5
    return 5


def _validate_severity(idx: int, severity: Any) -> str | None:
    if isinstance(severity, bool) or not isinstance(severity, (int, str)):
        return f"Finding at index {idx} has invalid severity (must be an integer from 0 to 10 or a known label)"
    if isinstance(severity, str) and severity.upper().strip() not in {
        "CRITICAL", "P0", "HIGH", "P1", "MEDIUM", "P2", "LOW", "P3",
    }:
        try:
            score = int(severity.strip())
        except ValueError:
            return f"Finding at index {idx} has unknown severity label {severity!r}"
    else:
        score = _normalize_severity_score(severity)
    if not 0 <= score <= 10:
        return f"Finding at index {idx} severity must be between 0 and 10, got {score}"


def _validate_confidence(idx: int, confidence: Any) -> str | None:
    if confidence is None:
        return None
    if isinstance(confidence, bool):
        return f"Finding at index {idx} confidence must be a finite number from 0 to 1 or HIGH/MEDIUM/LOW"
    if isinstance(confidence, int):
        if not 0 <= confidence <= 1:
            return f"Finding at index {idx} confidence must be a finite number from 0 to 1"
    elif isinstance(confidence, float):
        if not math.isfinite(confidence) or not 0 <= confidence <= 1:
            return f"Finding at index {idx} confidence must be a finite number from 0 to 1"
    elif not isinstance(confidence, str) or confidence.upper().strip() not in {"HIGH", "MEDIUM", "LOW"}:
        return f"Finding at index {idx} confidence must be a number from 0 to 1 or HIGH/MEDIUM/LOW"
    return None


def _validate_finding_item(idx: int, finding: Any) -> str | None:
    if not isinstance(finding, dict):
        return f"Finding at index {idx} must be an object"
    for field in ("technical_evidence", "location", "severity"):
        if field not in finding:
            return f"Finding at index {idx} is missing mandatory field '{field}'"
    loc = finding.get("location")
    if not isinstance(loc, dict) or "file" not in loc:
        return f"Finding at index {idx} has invalid 'location' structure (must have 'file')"
    score_error = _validate_severity(idx, finding["severity"])
    if score_error:
        return score_error
    confidence = finding.get("confidence")
    confidence_error = _validate_confidence(idx, confidence)
    if confidence_error:
        return confidence_error
    return None


def _parse_judge_json(raw_json: str) -> tuple[Any, str | None]:
    try:
        return json.loads(raw_json, parse_constant=_reject_nonfinite_json_number), None
    except json.JSONDecodeError as exc:
        return None, f"Invalid JSON syntax: {exc}"
    except ValueError as exc:
        return None, f"Invalid JSON value: {exc}"


def validate_judge_report(raw_json: str) -> tuple[bool, dict[str, Any] | str]:
    """Validate that a Judge-Zero audit report conforms to the strict machine-executable JSON schema."""
    data, parse_error = _parse_judge_json(raw_json)
    if parse_error:
        return False, parse_error

    if not isinstance(data, dict):
        return False, "Root JSON must be an object"
    if "findings" not in data:
        return False, "Missing required root field 'findings'"

    meta = data.get("audit_metadata") or data.get("report_metadata")
    if not isinstance(meta, dict):
        return False, "Missing or invalid 'audit_metadata' / 'report_metadata' schema"

    verdict = data.get("verdict")
    if verdict not in ("PASS", "FAIL"):
        return False, f"Verdict must be 'PASS' or 'FAIL', got '{verdict}'"

    findings = data["findings"]
    if not isinstance(findings, list):
        return False, "'findings' must be a list"

    # Deep schema validation of each finding
    for idx, finding in enumerate(findings):
        err = _validate_finding_item(idx, finding)
        if err:
            return False, err

    high_sev_findings = [f for f in findings if _normalize_severity_score(f.get("severity")) >= 7]
    if verdict == "PASS" and high_sev_findings:
        return False, "Verdict/Findings Mismatch: Verdict is 'PASS' but report contains high-severity findings."

    return True, data


def _is_dummy_assert(assert_node: ast.Assert) -> bool:
    test = assert_node.test
    if isinstance(test, ast.Constant) and test.value in (True, 1, "true", "ok", "passed"):
        return True
    if isinstance(test, ast.Compare):
        if (
            isinstance(test.left, ast.Constant)
            and len(test.comparators) == 1
            and isinstance(test.comparators[0], ast.Constant)
        ):
            if test.left.value == test.comparators[0].value:
                return True
    return False


# Context managers that establish an "expect this to raise" scope: pytest's
# ``pytest.raises``/``xxx.raises`` and unittest.TestCase's own
# ``self.assertRaises``/``self.assertRaisesRegex``. All four are attribute
# calls used as ``with ... as x:`` items.
_RAISES_CONTEXT_ATTRS = frozenset({"raises", "assertRaises", "assertRaisesRegex"})


def _raises_context_call_ids(node: ast.AST) -> set[int]:
    """id() of every Call used as a raises-context with-item's expression.

    ``self.assertRaises(X)``/``self.assertRaisesRegex(X, p)`` used this way
    (``with self.assertRaises(X) as ctx: ...``) verify nothing by themselves
    -- the verification is the block's own outcome or a later assertion on
    the bound name. They must not double as "an assertion call happened"
    evidence on their own, or the dedicated raises-without-verification
    branch below would never fire for this shape. The *direct-call* form
    (``self.assertRaises(Exception, func, arg)``) is unaffected: it isn't a
    with-item, so its id() never lands in this set.
    """
    ids: set[int] = set()
    for child in ast.walk(node):
        if not isinstance(child, ast.With):
            continue
        for item in child.items:
            call = item.context_expr
            if (
                isinstance(call, ast.Call)
                and isinstance(call.func, ast.Attribute)
                and call.func.attr in _RAISES_CONTEXT_ATTRS
            ):
                ids.add(id(call))
    return ids


def _pytest_raises_state(node: ast.AST, assertions: list[ast.Assert]) -> tuple[bool, bool]:
    raises_names: set[str] = set()
    has_raises = False
    has_match = False
    for child in ast.walk(node):
        if not isinstance(child, ast.With):
            continue
        for item in child.items:
            call = item.context_expr
            if not isinstance(call, ast.Call) or not isinstance(call.func, ast.Attribute):
                continue
            if call.func.attr not in _RAISES_CONTEXT_ATTRS:
                continue
            has_raises = True
            # pytest.raises(..., match=...) and assertRaisesRegex(exc, pattern)
            # both narrow the raised exception beyond its type -- either
            # counts as an explicit match, not just a bare catch-anything.
            has_match = (
                has_match
                or any(keyword.arg == "match" for keyword in call.keywords)
                or (call.func.attr == "assertRaisesRegex" and len(call.args) >= 2)
            )
            if item.optional_vars is not None:
                raises_names.update(
                    name.id for name in ast.walk(item.optional_vars) if isinstance(name, ast.Name)
                )
    observes_exception = any(
        raises_names
        & {child.id for child in ast.walk(assertion.test) if isinstance(child, ast.Name)}
        for assertion in assertions
    )
    return has_raises, has_match or observes_exception


def _call_assigned_names(node: ast.AST) -> set[str]:
    """Names bound to an expression containing a Call's result -- ``x = f()``
    / ``x: T = f()`` / ``with f() as x:``, AND a compound expression wrapping
    one, e.g. ``elapsed = time.perf_counter() - start`` -- an assertion
    referencing such a name (e.g. ``assert x.out == ...`` or
    ``assert elapsed < 0.5``) is observing real call/mocked behavior, not
    just a static literal.

    Reported live (2026-08-30): a test computing elapsed real time as
    `t2 = time.perf_counter(); ...; elapsed = time.perf_counter() - t2`
    false-positived here -- the assignment's value is a BinOp WRAPPING a
    Call, not a bare Call, so the original `isinstance(child.value,
    ast.Call)` check (direct-call-only) missed it entirely despite the
    assertion genuinely depending on the call's result.
    """
    names: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, (ast.Assign, ast.AnnAssign)) and child.value is not None and any(
            isinstance(n, ast.Call) for n in ast.walk(child.value)
        ):
            targets = child.targets if isinstance(child, ast.Assign) else [child.target]
            for target in targets:
                names.update(n.id for n in ast.walk(target) if isinstance(n, ast.Name))
        elif isinstance(child, ast.With):
            for item in child.items:
                if isinstance(item.context_expr, ast.Call) and item.optional_vars is not None:
                    names.update(
                        n.id for n in ast.walk(item.optional_vars) if isinstance(n, ast.Name)
                    )
    return names


def _assertions_observe_calls(
    assertions: list[ast.Assert], assigned_call_results: set[str]
) -> bool:
    return any(
        any(isinstance(child, ast.Call) for child in ast.walk(assertion.test))
        or bool(
            assigned_call_results
            & {child.id for child in ast.walk(assertion.test) if isinstance(child, ast.Name)}
        )
        for assertion in assertions
    )


def _assertions_observe_patch_dict(
    node: ast.FunctionDef | ast.AsyncFunctionDef, assertions: list[ast.Assert]
) -> bool:
    """A patch.dict decorator changes its target's state; an assertion reading
    that target observes the patched behavior even though the assertion has no call."""
    targets = {
        ast.dump(decorator.args[0], include_attributes=False)
        for decorator in node.decorator_list
        if isinstance(decorator, ast.Call)
        and _call_chain(decorator.func)[-2:] == ["patch", "dict"]
        and decorator.args
    }
    if not targets:
        return False
    return any(
        ast.dump(child, include_attributes=False) in targets
        for assertion in assertions
        for child in ast.walk(assertion.test)
    )


# unittest.TestCase's own assertion methods (self.assertEqual, self.assertIn,
# self.assertRaises used as a plain call, etc.) are ast.Call nodes, invisible
# to an AST walk that only looks for bare ``ast.Assert`` statements -- a
# unittest-style test with perfectly real assertions read as an unverified
# mock. Same story for a Mock's own ``mock_obj.assert_called_once_with(...)``
# family: those calls verify the mock's recorded call history by definition.
_UNITTEST_ASSERT_METHOD_RE = re.compile(r"^assert[A-Z]")
_MOCK_ASSERT_METHOD_RE = re.compile(r"^assert_")


def _assertion_call_kind(call: ast.Call) -> str | None:
    """Classify a Call as a unittest assertion, a Mock's own assertion, or neither."""
    if not isinstance(call.func, ast.Attribute):
        return None
    attr = call.func.attr
    if _UNITTEST_ASSERT_METHOD_RE.match(attr):
        return "unittest"
    if _MOCK_ASSERT_METHOD_RE.match(attr):
        return "mock"
    return None


def _collect_assertion_calls(node: ast.AST) -> list[ast.Call]:
    excluded = _raises_context_call_ids(node)
    return [
        c
        for c in ast.walk(node)
        if isinstance(c, ast.Call) and _assertion_call_kind(c) is not None and id(c) not in excluded
    ]


def _assertion_calls_observe_behavior(
    assertion_calls: list[ast.Call], assigned_call_results: set[str]
) -> bool:
    for call in assertion_calls:
        kind = _assertion_call_kind(call)
        if kind == "mock":
            # A Mock's own assert_called_once_with()/assert_not_called()/etc.
            # inspects the mock's recorded call history -- that IS observing
            # mocked behavior, regardless of what its arguments look like.
            return True
        if kind == "unittest":
            attr = call.func.attr if isinstance(call.func, ast.Attribute) else ""
            if attr in ("assertRaises", "assertRaisesRegex") and len(call.args) >= 2:
                # Direct-call form -- self.assertRaises(Exc, func, *args) --
                # invokes func itself and checks it raises. Self-contained,
                # unlike the with-item context-manager form (excluded from
                # this list entirely; see _raises_context_call_ids).
                return True
            args = list(call.args) + [kw.value for kw in call.keywords]
            for arg in args:
                if any(isinstance(child, ast.Call) for child in ast.walk(arg)):
                    return True
                if assigned_call_results & {
                    child.id for child in ast.walk(arg) if isinstance(child, ast.Name)
                }:
                    return True
    return False


def _test_source_with_decorators(content: str, node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Return the function's source INCLUDING its decorator expressions.

    ``ast.get_source_segment`` on a FunctionDef starts at the ``def`` line and
    drops every decorator above it, so a test whose only mocking is
    ``@patch("pkg.dep")`` presented an unmocked-looking body to the auditor and
    escaped conviction. The decorator list is part of the inspected surface.
    """
    parts = [ast.get_source_segment(content, dec) or "" for dec in node.decorator_list]
    parts.append(ast.get_source_segment(content, node) or "")
    return "\n".join(parts)


def _check_mock_theater_assertions(
    test_file: Path, node: ast.FunctionDef | ast.AsyncFunctionDef, fn_code: str
) -> list[str]:
    """Defect class 1: mocking present, but nothing observes real behavior.

    The three outcomes are mutually exclusive by construction (one `elif`
    chain) and each names a DIFFERENT cause in its message -- "no asserts at
    all", "asserts that observe nothing", "a raises context that verifies
    nothing". Kept as one function because they read one shared state
    (has_mocking / has_any_assertion / raises_verified / observes_behavior);
    splitting the chain further would duplicate that state, not reduce it.
    """
    violations: list[str] = []
    has_mocking = any(pat in fn_code for pat in ("patch(", "patch.object(", "patch.dict(", "monkeypatch", "Mock(", "MagicMock("))
    valid_asserts = [c for c in ast.walk(node) if isinstance(c, ast.Assert) and not _is_dummy_assert(c)]
    assertion_calls = _collect_assertion_calls(node)
    has_any_assertion = bool(valid_asserts) or bool(assertion_calls)
    has_pytest_raises, raises_verified = _pytest_raises_state(node, valid_asserts)
    assigned_call_results = _call_assigned_names(node)
    assertions_observe_behavior = _assertions_observe_calls(
        valid_asserts, assigned_call_results
    ) or _assertions_observe_patch_dict(node, valid_asserts) or _assertion_calls_observe_behavior(
        assertion_calls, assigned_call_results
    )

    if has_mocking and not has_any_assertion and not has_pytest_raises:
        violations.append(
            f"Mock Theater (GS2-216) in {test_file.name}::{node.name}: "
            "Function mocks dependencies but contains no non-trivial asserts."
        )
    elif has_mocking and has_any_assertion and not assertions_observe_behavior and not raises_verified:
        violations.append(
            f"Mock Theater (GS2-216) in {test_file.name}::{node.name}: "
            "Assertions do not observe a call result or mocked behavior."
        )
    elif has_pytest_raises and not has_any_assertion and not raises_verified:
        violations.append(
            f"Mock Theater (GS2-216) in {test_file.name}::{node.name}: "
            "pytest.raises context lacks exception match or exc_info assertions."
        )
    return violations


def _check_covert_test_skip(
    test_file: Path, node: ast.FunctionDef | ast.AsyncFunctionDef
) -> list[str]:
    """Defect class 2: a try/except whose handler silently swallows.

    A separate defect from Mock Theater: it convicts tests with NO mocking at
    all, and it is the only one of the three that reads the AST rather than
    the source text.
    """
    violations: list[str] = []
    # Check for silent exception swallowing inside test functions (covert skips).
    # Excludes "expect this exception, then assert the effect" -- a try/except
    # with a bare pass/... body followed by the function's OWN unconditional
    # `assert`s elsewhere verifies real behavior, not nothing. Reported live
    # (Atlas, 2026-08-29, atlas-42): forcing an OSError mid-write, catching
    # it, then asserting the destination survived intact false-positived here.
    for child in ast.walk(node):
        if isinstance(child, ast.ExceptHandler):
            if len(child.body) == 1 and (
                isinstance(child.body[0], ast.Pass)
                or (
                    isinstance(child.body[0], ast.Expr)
                    and isinstance(child.body[0].value, ast.Constant)
                    and child.body[0].value.value is ...
                )
            ):
                handler_ids = {id(n) for n in ast.walk(child)}
                if any(
                    isinstance(n, ast.Assert) and id(n) not in handler_ids
                    for n in ast.walk(node)
                ):
                    continue
                violations.append(
                    f"Covert Test Skip (GS2-216) in {test_file.name}::{node.name}: "
                    "Test function contains try/except that silently swallows exceptions with pass/..."
                )
    return violations


def _check_integration_test_mocks_fs(
    test_file: Path, node: ast.FunctionDef | ast.AsyncFunctionDef, fn_code: str
) -> list[str]:
    """Defect class 3: a test NAMED integration/e2e that mocks the filesystem.

    Gated on the FILE name, not the function's contents -- the only one of the
    three checks whose trigger lives outside the function under audit, which is
    why it was the easiest to lose sight of inside the old single body.
    """
    violations: list[str] = []
    # Check if a test labeled integration/e2e mocks core filesystem primitives
    if "integration" in test_file.name.lower() or "e2e" in test_file.name.lower():
        if any(
            pat in fn_code
            for pat in (
                "patch('os.",
                "patch('shutil.",
                "patch('pathlib.",
                'patch("os.',
                'patch("shutil.',
                'patch("pathlib.',
                "patch('builtins.open",
                'patch("builtins.open',
            )
        ):
            violations.append(
                f"Mock Theater in Integration Test (GS2-216) in {test_file.name}::{node.name}: "
                "Integration test mocks core filesystem primitives instead of using real tmp_path."
            )

    return violations


# Defect class 4 (DEBT-GATE-ENGANABLE-ADVERSARIAL-JUDGE, 2026-09-27): a test
# that mocks and then calls NOTHING but its own mocks. The audit's atajo --
# ``m = MagicMock(); r = m(1, 2); assert r`` -- passed class 1 because ``r`` is
# "assigned from a Call"; the Call was the mock's own. A mocking test must
# exercise at least one callable that is none of: a mock factory, a name
# derived from a mock, a builtin, a pytest builtin fixture, or an assertion.
_MOCK_FACTORY_NAMES = frozenset({
    "Mock", "MagicMock", "AsyncMock", "NonCallableMock", "NonCallableMagicMock",
    "PropertyMock", "create_autospec", "patch",
})
_MOCK_FIXTURE_ROOTS = frozenset({"monkeypatch", "mocker"})
_TOOL_ROOTS = frozenset({
    "pytest", "mock", "unittest",
    "tmp_path", "tmp_path_factory", "tmpdir", "capsys", "capfd", "caplog", "recwarn", "request",
}) | frozenset(dir(builtins))


def _call_chain(expr: ast.AST) -> list[str]:
    """``a.b.c(...)`` -> ["a", "b", "c"]; unwraps calls, subscripts and awaits."""
    chain: list[str] = []
    while True:
        if isinstance(expr, ast.Attribute):
            chain.append(expr.attr)
            expr = expr.value
        elif isinstance(expr, (ast.Call, ast.Await)):
            expr = expr.func if isinstance(expr, ast.Call) else expr.value
        elif isinstance(expr, ast.Subscript):
            expr = expr.value
        else:
            break
    chain.append(expr.id if isinstance(expr, ast.Name) else "")
    return chain[::-1]


def _is_mock_rooted(chain: list[str], derived: set[str]) -> bool:
    return chain[0] in derived or chain[0] in _MOCK_FIXTURE_ROOTS or any(
        part in _MOCK_FACTORY_NAMES for part in chain
    )


def _mock_derived_names(node: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    """Names bound, directly or transitively, to a mock or a mock's output."""
    derived: set[str] = set()
    changed = True
    while changed:
        changed = False
        for child in ast.walk(node):
            bound: list[tuple[ast.AST, ast.AST]] = []
            if isinstance(child, (ast.Assign, ast.AnnAssign)) and child.value is not None:
                targets = child.targets if isinstance(child, ast.Assign) else [child.target]
                bound = [(t, child.value) for t in targets]
            elif isinstance(child, (ast.With, ast.AsyncWith)):
                bound = [(i.optional_vars, i.context_expr) for i in child.items if i.optional_vars]
            for target, value in bound:
                if not _is_mock_rooted(_call_chain(value), derived):
                    continue
                new = {n.id for n in ast.walk(target) if isinstance(n, ast.Name)} - derived
                if new:
                    derived |= new
                    changed = True
    return derived


_TEST_HELPER_ROOTS = frozenset({"tests", "test", "conftest"})


def _project_import_names(tree: ast.AST, root: Path | None) -> frozenset[str]:
    """Names a test file binds by importing a PROJECT module (code under test).

    Reported live (blackbox, 2026-10-04): ``controls.assert_evidence_pass(...)``
    -- a real function of ``from tools import runtime_batch01_controls as
    controls`` -- was skipped as "a Mock's own assert_*" purely by its name, and
    the test was convicted of calling nothing but mocks. A receiver bound by
    importing a module that lives under ``root`` is code under test, whatever
    its functions are called. Excluded, so the rule keeps convicting: mock
    libraries, test-helper packages (``tests``/``conftest``/relative imports),
    and anything not found under ``root`` (third-party ``npt.assert_equal``).
    ponytail: top-level package lookup under root and root/src only, no
    import resolution; trigger: a project laid out elsewhere being re-convicted.
    """
    if root is None:
        return frozenset()
    names: set[str] = set()
    for child in ast.walk(tree):
        if isinstance(child, ast.Import):
            pairs = [(a.name, a.asname or a.name.split(".")[0]) for a in child.names]
        elif isinstance(child, ast.ImportFrom) and child.level == 0 and child.module:
            pairs = [(child.module, a.asname or a.name) for a in child.names if a.name != "*"]
        else:
            continue
        for module, bound in pairs:
            top = module.split(".")[0]
            if "mock" in module.lower() or top in _TEST_HELPER_ROOTS:
                continue
            if any((base / top).is_dir() or (base / f"{top}.py").is_file() for base in (root, root / "src")):
                names.add(bound)
    return frozenset(names)


def _is_project_module_call(call: ast.Call, project_names: frozenset[str]) -> bool:
    """``mod.func(...)`` whose receiver is directly a project-module import name."""
    return (
        isinstance(call.func, ast.Attribute)
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id in project_names
    )


def _exercises_non_mock_code(
    node: ast.FunctionDef | ast.AsyncFunctionDef, project_names: frozenset[str] = frozenset()
) -> bool:
    derived = _mock_derived_names(node)
    for stmt in node.body:
        for call in (c for c in ast.walk(stmt) if isinstance(c, ast.Call)):
            chain = _call_chain(call)
            if _is_mock_rooted(chain, derived):
                continue
            if _assertion_call_kind(call) is not None and not _is_project_module_call(call, project_names):
                continue
            if chain[0] and chain[0] not in _TOOL_ROOTS:
                return True
    return False


def _check_mock_only_exercise(
    test_file: Path,
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    fn_code: str,
    project_names: frozenset[str] = frozenset(),
) -> list[str]:
    """Defect class 4: the test mocks, then calls nothing but its own mocks."""
    has_mocking = any(pat in fn_code for pat in ("patch(", "patch.object(", "patch.dict(", "monkeypatch", "Mock(", "MagicMock("))
    valid_asserts = [c for c in ast.walk(node) if isinstance(c, ast.Assert) and not _is_dummy_assert(c)]
    if (
        not has_mocking
        or _assertions_observe_patch_dict(node, valid_asserts)
        or _exercises_non_mock_code(node, project_names)
    ):
        return []
    return [
        f"Mock Theater (GS2-216) in {test_file.name}::{node.name}: "
        "Test calls nothing but its own mocks -- no code under test is exercised."
    ]


def _check_test_node_mock_theater(
    test_file: Path, node: ast.AST, content: str, project_names: frozenset[str] = frozenset()
) -> list[str]:
    """Run every mock-theater defect class over ONE test function.

    Order is the reporting order, not a precedence: the four classes are
    independent, so a function can be convicted by more than one and the
    caller sees every reason. Adding a class means adding a call here,
    which is the point of the split -- the previous single body had no place
    to add one without growing past the complexity gate again.
    """
    if not (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_")):
        return []
    fn_code = _test_source_with_decorators(content, node)
    # Class 4 runs only when class 1 is silent: an assert-free mock test is
    # already convicted with the more specific reason, and one test reported
    # twice for the same theater reads as two defects.
    theater = _check_mock_theater_assertions(test_file, node, fn_code) or _check_mock_only_exercise(
        test_file, node, fn_code, project_names
    )
    return [
        *theater,
        *_check_covert_test_skip(test_file, node),
        *_check_integration_test_mocks_fs(test_file, node, fn_code),
    ]


def _check_test_file_mock_theater(test_file: Path, root: Path | None = None) -> list[str]:
    violations: list[str] = []
    try:
        content = test_file.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return [f"COULD_NOT_RUN: Failed reading test {test_file.name}: {exc}"]

    if not any(pattern in content for pattern in MOCK_THEATER_PATTERNS):
        return violations

    try:
        tree = ast.parse(content, filename=str(test_file))
    except SyntaxError as exc:
        return [f"Syntax error in test {test_file.name}: {exc}"]

    project_names = _project_import_names(tree, root)
    for node in ast.walk(tree):
        violations.extend(_check_test_node_mock_theater(test_file, node, content, project_names))
    return violations


def audit_mock_theater(root: Path) -> list[str]:
    """Inspect all test files for mock theater where mocks lack concrete assertions on state/results."""
    tests_dir = root / "tests"
    if not tests_dir.is_dir():
        return []

    violations: list[str] = []
    for test_file in sorted(tests_dir.rglob("*.py")):
        if test_file.is_file() and "fixtures" not in test_file.parts:
            violations.extend(_check_test_file_mock_theater(test_file, root))
    return violations


def materialize_debt_from_judge_report(report: dict[str, Any], root: Path) -> list[Path]:
    """Materialize severe findings from Judge-Zero report into formal GS2-214 debt tasks."""
    created_tasks: list[Path] = []
    backlog_dir = root / "tasks" / "backlog"
    backlog_dir.mkdir(parents=True, exist_ok=True)

    findings = report.get("findings", [])
    for idx, finding in enumerate(findings):
        if _validate_finding_item(idx, finding) is not None:
            continue
        severity = _normalize_severity_score(finding.get("severity"))
        confidence = finding.get("confidence", 0.0)
        conf_val = 0.0
        if isinstance(confidence, (int, float)):
            conf_val = float(confidence)
        elif isinstance(confidence, str):
            conf_val = 0.9 if confidence.upper() == "HIGH" else (0.6 if confidence.upper() == "MEDIUM" else 0.3)

        if severity < 7 or severity > 10 or not math.isfinite(conf_val) or not 0 <= conf_val <= 1 or conf_val < 0.8:
            continue

        file_loc = finding.get("location", {}).get("file", "unknown")
        line_loc = finding.get("location", {}).get("line", 0)
        raw_id = finding.get("finding_id") or f"{Path(file_loc).stem.upper()[:12]}-{line_loc}-{idx:02d}"
        safe_id = re.sub(r"[^A-Za-z0-9_\-]", "_", str(raw_id)).strip("_") or f"FINDING-{idx:02d}"
        task_file = backlog_dir / f"DEBT-JUDGE-ZERO-{safe_id}.md"

        debt_mat = finding.get("debt_materialization", {}) if isinstance(finding.get("debt_materialization"), dict) else {}
        raw_satd = debt_mat.get("satd_family") or "JUDGE_ZERO_DEBT"
        satd_family = re.sub(r"[^A-Za-z0-9_]", "_", str(raw_satd))
        p_sev = "P1" if severity >= 9 else "P2"
        raw_cmd = finding.get("reproduction_command") or debt_mat.get("verification_command", "pytest")
        verif_cmd = re.sub(r'["\n\r]', '', str(raw_cmd))

        raw_title = str(finding.get('title', 'Judge-Zero Finding')).replace('\n', ' ')
        safe_title = re.sub(r'[^\w\s\-\.\:\(\)\[\]]', '', raw_title)

        _fm = ledger_schema.render_frontmatter(
            id=f"DEBT-JUDGE-ZERO-{safe_id}",
            title=safe_title or f"Judge-Zero finding {safe_id}",
            status="open", severity=p_sev, satd_family=satd_family,
            close_check={"cmd": verif_cmd, "expect": "exit_zero"},
            risk_score=severity, blast_radius="HIGH",
            lifespan="introduced", tag="BUG",
        )
        content = f"""{_fm}

# Technical Debt [BUG | {satd_family}]: {safe_title}

## I · Issue (Deficiencia Identificada por Judge-Zero)
{finding.get('technical_evidence', '')}
- Axioma: `{finding.get('axiom', '')}`
- Ubicación: `{file_loc}:{line_loc}`
- Impacto: {finding.get('impact', '')}

## R · Rule / Mecanismo Implicado
- Clasificación: `{finding.get('classification', 'OBSERVED')}`
- Confianza: `{confidence}` (Severidad: {severity}/10)
- Frontera: `{finding.get('trust_boundary', '')}`

## A · Application & Safe Reproduction
```python
{finding.get('safe_reproduction', {}).get('payload', '# Reproduction payload')}
```
Resultado Actual: `{finding.get('actual_behavior', '')}`
Resultado Esperado: `{finding.get('expected_behavior', '')}`

## C · Conclusion & Required Remediation
{finding.get('minimal_remediation', '')}
- Test Negativo Requerido: `{finding.get('negative_test_required', '')}`

```json queue-job
{{
  "name": "remediate_{safe_id.lower()}",
  "command": "{verif_cmd}",
  "artifact": "tasks/backlog/DEBT-JUDGE-ZERO-{safe_id}.md"
}}
```
"""
        atomic_io.write_text_durable(task_file, content)
        created_tasks.append(task_file)
    return created_tasks


def _is_declared_corpus_file(code: str) -> bool:
    """Helper to detect corpus declaration comments."""
    for line in code.splitlines()[:10]:
        if line.strip().startswith("# simplecode:corpus"):
            return True
    return False


# Trees the agent-threat sweep reads. `src/` alone until 2026-09-04; the other
# four are the ones SPEC section 8 named as the pending widening. Absent trees
# are NOT an error (no satellite has all five) but they are not coverage either,
# so `sweep_coverage` returns them separately instead of letting a PASS imply a
# sweep that never happened.
AGENT_THREAT_TREES: tuple[str, ...] = ("src", "scripts", "daemon", "central", "installer", "tools")


def sweep_coverage(root: Path) -> tuple[list[str], list[str]]:
    """Split `AGENT_THREAT_TREES` into (present, absent) for this repo, in order."""
    present = [t for t in AGENT_THREAT_TREES if (root / t).is_dir()]
    absent = [t for t in AGENT_THREAT_TREES if not (root / t).is_dir()]
    return present, absent


def collect_threat_sources(root: Path) -> list[Path]:
    """Every `*.py` under the trees that exist, sorted.

    Axiom 9: `rglob` yields filesystem order, so an unsorted feed makes two runs
    over an identical tree emit the same findings in a different order. The sort
    is over the whole cross-tree list, not per tree, so the order does not depend
    on which trees happen to exist.
    """
    present, _ = sweep_coverage(root)
    return sorted(
        p for tree in present for p in (root / tree).rglob("*.py") if p.is_file()
    )


def _audit_code_threats(root: Path, py_files: list[Path]) -> list[str]:
    from simplecode.guards import agent_threats
    from simplecode.worktree import zero_debt
    violations: list[str] = []
    for pf in py_files:
        if pf.name in ("agent_threats.py", "pattern_detectors.py"):
            continue
        rel = str(pf.relative_to(root))
        if zero_debt.declares_corpus(root, rel) != "":
            continue
        try:
            code = pf.read_text(encoding="utf-8", errors="replace")
            if agent_threats.tool_poisoning_homoglyph(code):
                violations.append(f"Homoglyph / confusables detected in {rel}")
            if agent_threats.tool_poisoning_invisible(code):
                violations.append(f"Invisible character threat detected in {rel}")
        except OSError as exc:
            violations.append(f"COULD_NOT_RUN: Failed reading {pf} for threat audit: {exc}")
    return violations


def run_adversarial_judge(root: Path, run_tests: bool = False) -> tuple[bool, list[str]]:
    """Execute source forensics once; the coverage gate owns test execution."""
    violations: list[str] = []

    # 1. Mock Theater Audit (Axiom 1)
    violations.extend(audit_mock_theater(root))

    # (Angry Path Dominance and the Corruption & Mojibake Guard are dedicated,
    # earlier-running pre-push hooks -- see the module docstring's 2026-08-31
    # dedup note -- so py_files here exists solely for the threat audit below.)
    py_files = collect_threat_sources(root)

    # 2. Source disguise: homoglyphs and bidi/zero-width characters (Axiom 15)
    violations.extend(_audit_code_threats(root, py_files))

    # 3. Dynamic Test Suite Invariant Execution (Axiom 1 & GS2-210)
    tests_dir = root / "tests"
    if run_tests and tests_dir.is_dir() and any(tests_dir.rglob("test_*.py")):
        budget = SMOKE_SUITE_TIMEOUT
        try:
            env = os.environ.copy()
            env.pop("PYTEST_CURRENT_TEST", None)
            suite_bytes = sum(p.stat().st_size for p in tests_dir.rglob("*.py") if p.is_file())
            budget = compute_proportional_timeout(
                suite_bytes,
                base_timeout_sec=SMOKE_SUITE_TIMEOUT,
                bytes_per_sec=PYTEST_SUITE_BYTES_PER_SEC,
            )
            res = subprocess.run(
                [sys.executable, "-m", "pytest", "-q", "-p", "no:cov", "-o", "testpaths=tests"],
                cwd=root,
                capture_output=True,
                text=True,
                timeout=budget,
                check=False,
                env=env,
            )
            if res.returncode != 0:
                out_err = (res.stdout + "\n" + res.stderr).strip()
                err_summary = out_err.splitlines()[-1] if out_err else f"exit code {res.returncode}"
                violations.append(f"Dynamic test suite failure: {err_summary}")
        except subprocess.TimeoutExpired:
            # A timeout is a COULD_NOT_RUN, not a conviction of the subject: the
            # judge learned nothing about the suite, and must say so.
            violations.append(
                f"COULD_NOT_RUN: Dynamic test suite execution timed out after {budget:.0f}s"
            )
        except Exception as exc:
            violations.append(f"COULD_NOT_RUN: Failed executing dynamic test suite: {exc}")

    passed = len(violations) == 0
    return passed, violations


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Automated Adversarial Judge (Red-Team)")
    parser.add_argument("--root", type=Path, default=Path("."), help="Repository root directory")
    parser.add_argument("--gate", action="store_true", help="Exit 1 if adversarial judge finds violations")
    parser.add_argument("--run-tests", action="store_true", help="Also execute pytest (coverage remains a separate gate)")
    parser.add_argument("--prompt", action="store_true", help="Print the Judge-Zero V3.0 system prompt")
    parser.add_argument("--ingest-report", type=Path, help="Ingest and materialize a JSON Judge-Zero report")
    args = parser.parse_args(argv)

    root = args.root.resolve()

    if args.prompt:
        print(get_judge_zero_prompt(root))
        return 0

    if args.ingest_report:
        raw_text = args.ingest_report.read_text(encoding="utf-8")
        ok, data = validate_judge_report(raw_text)
        if not ok:
            # A malformed/inconsistent report was READ and rejected on its own
            # content -- a condena, not an instrument failure -- so it gets the
            # tagged FAIL line, not COULD_NOT_RUN.
            print(f"[adversarial-judge] FAIL: report schema/verdict mismatch: {data}")
            print(f"\033[31m[judge-zero] SCHEMA ERROR: {data}\033[0m")
            return 1
        created = materialize_debt_from_judge_report(data, root)  # type: ignore
        print(f"[judge-zero] OK: Ingested report and materialized {len(created)} debt tasks into backlog.")
        return 0

    print("=== ADVERSARIAL RED-TEAM JUDGE (JUDGE-ZERO) ===")
    passed, violations = run_adversarial_judge(root, args.run_tests)

    present, absent = sweep_coverage(root)
    swept = collect_threat_sources(root)
    print(
        f"[judge-zero] threat sweep read {len(swept)} file(s) across "
        f"{', '.join(present) if present else '<no tree>'}"
    )
    if absent:
        # Printed on PASS and on FAIL alike: a tree that does not exist here was
        # not audited, and a verdict that hides that is a verdict about nothing.
        print(f"[judge-zero] NOT swept (absent in this repo): {', '.join(absent)}")

    if passed:
        print("[judge-zero] OK: Mock-theater and source-disguise audits passed.")
        emit_hallazgos("[adversarial-judge]", 0)
        return 0

    # `violations` mixes two shapes that must not collapse into one verdict:
    # a "COULD_NOT_RUN: ..." entry means the judge never looked at that
    # subject (unreadable test file, threat-audit read failure, dynamic-suite
    # timeout) -- an instrument failure, not a conviction. Everything else is
    # a real condemnation. A single unconditional "[judge-zero] FAIL: ..."
    # header printed regardless of which shape filled `violations` would tag
    # an instrument-down-only run as a subject verdict (the tagged line the
    # gate regex looks for does not care what filled the count behind it) and
    # hide a dead instrument behind a false conviction -- so the header itself
    # is now conditioned on there being a real condemnation to report.
    cnr_items = [v for v in violations if v.startswith("COULD_NOT_RUN:")]
    fail_items = [v for v in violations if not v.startswith("COULD_NOT_RUN:")]

    print(f"[judge-zero] detected {len(violations)} finding(s) this run:")
    for v in violations:
        print(f"  🔴 {v}")

    if fail_items:
        print(
            f"[adversarial-judge] FAIL: {len(fail_items)} condemned finding(s) "
            f"(mock-theater/source-disguise); "
            f"first: {fail_items[0]}"
        )
    emit_hallazgos("[adversarial-judge]", len(fail_items))
    if cnr_items:
        print(
            f"[adversarial-judge] COULD_NOT_RUN: {len(cnr_items)} subject(s) the judge "
            f"could not read/execute; first: {cnr_items[0][len('COULD_NOT_RUN: '):]}",
            file=sys.stderr,
        )
    return 1 if args.gate else 0


if __name__ == "__main__":
    sys.exit(main())
