# -*- coding: utf-8 -*-
"""sunset_redate.py -- re-date the sunset tags of exemptions that did NOT change since their last review.

`sunset_audit` only audits; a minor bump needs every exemption re-dated to the new minor, and
that was done by hand in 8.2, 8.3 and 8.4 (95 lines each). The doctrine of the gate is that a
REVIEW is a question with a real answer -- has this line changed since anyone last looked at it --
so a blanket re-date that does not ask it is a stamp. This asks it, per line, against git:

* the tag line (and, for `.gitignore`, the pattern line it guards) is compared with the same line
  of the last review commit; identical -> re-dated, changed or absent -> listed, never touched;
* `.gitignore` carries its tag on the line ABOVE the pattern, while the auditor reports the
  pattern's line number: the tag line is `line_number - 1` for that kind only.

"Unchanged since the last review" is NOT "still contributes": blackbox found (2026-09-25) two sleeps whose
justification was FALSE and had never changed, which this tool would have renewed in silence. So it
never says "reviewed": it prints a NOTE, and `--list` shows each exemption next to the justification
its tag carries, so the ones worth doubting can be checked (remove the exemption, run its subject).

Dry run by default. Exit 0: nothing left for a human; 1: lines changed since the review and need one;
2: COULD_NOT_RUN (no readable base revision).
"""
from __future__ import annotations

import argparse
import re
import stat
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.verification.sunset_audit import ExemptionRecord, scan_exemptions

_TAG = re.compile(r"(sunset-reviewed:\s*)(\d+\.\d+)\b")


def _sin_version(line: str) -> str:
    """`line` with the version number of its sunset tag masked.

    A re-date changes ONLY that number, so a base commit that predates one is still a fair witness of
    what the exemption said: comparing raw lines made every tag read 'changed' whenever the newest
    `chore(sunset)`-titled commit was not the last re-date (Atlas 2026-09-25: the 1.7->1.8 re-date
    entered under an `auto-commit: job ...` subject, the base fell back to 1.7 and 251 unchanged tags
    came out as `need a human`, 0 re-dated).
    """
    return _TAG.sub(r"\1<V>", line)


@dataclass
class Plan:
    redate: list[tuple[Path, int]] = field(default_factory=list)
    needs_review: list[tuple[ExemptionRecord, str]] = field(default_factory=list)


def _git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, check=False)


def last_review_commit(root: Path) -> str | None:
    """The newest commit whose subject starts `chore(sunset)`, the house convention for a review."""
    done = _git(root, "log", "-1", "--format=%H", "--grep=^chore(sunset)")
    return done.stdout.strip() or None


def _tag_line(rec: ExemptionRecord) -> int:
    return rec.line_number - 1 if rec.kind == "gitignore" else rec.line_number


def _lines_at(root: Path, base: str, rel: str) -> list[str] | None:
    shown = _git(root, "show", f"{base}:{rel}")
    return shown.stdout.splitlines() if shown.returncode == 0 else None


def _unchanged(rec: ExemptionRecord, now: list[str], old: list[str]) -> bool:
    """The exempted text is the same as when it was last reviewed, wherever it now sits.

    By CONTENT, not by line number: an edit above an exemption moves it (measured 2026-09-25, a
    13-line insert in tests/conftest.py made an untouched tag read as changed). A `.gitignore` tag and
    its pattern are judged as the ADJACENT pair they were reviewed as.
    """
    if rec.kind == "gitignore":
        tag, pattern = _sin_version(now[rec.line_number - 2]), now[rec.line_number - 1]
        return any(_sin_version(old[i]) == tag and old[i + 1] == pattern for i in range(len(old) - 1))
    return _sin_version(now[rec.line_number - 1]) in {_sin_version(x) for x in old}


def build_plan(root: Path, to_minor: str, base: str) -> Plan:
    plan = Plan()
    cache: dict[str, list[str] | None] = {}
    for rec in scan_exemptions(root):
        if rec.version_reviewed is None or rec.version_reviewed == to_minor:
            continue
        rel = str(Path(rec.path).resolve().relative_to(root.resolve()))
        if rel not in cache:
            cache[rel] = _lines_at(root, base, rel)
        old = cache[rel]
        now = (root / rel).read_text(encoding="utf-8").splitlines()
        tag_no = _tag_line(rec)
        if old is None:
            plan.needs_review.append((rec, f"{rel} does not exist at {base[:8]}"))
        elif not _unchanged(rec, now, old):
            plan.needs_review.append((rec, "the line changed since the last review"))
        else:
            plan.redate.append((root / rel, tag_no))
    return plan


def apply_plan(plan: Plan, to_minor: str) -> int:
    """Rewrite each planned tag once; returns how many lines changed."""
    by_file: dict[Path, list[int]] = {}
    for path, tag_no in plan.redate:
        by_file.setdefault(path, []).append(tag_no)
    changed = 0
    for path, numbers in by_file.items():
        lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
        for n in numbers:
            new = _TAG.sub(lambda m: f"{m.group(1)}{to_minor}", lines[n - 1], count=1)
            if new != lines[n - 1]:
                lines[n - 1] = new
                changed += 1
        # atomic_io's temp file is born 0600: carry the rewritten file's mode over, or an
        # executable script re-dated here would lose its x bit.
        modo = stat.S_IMODE(path.stat().st_mode)
        atomic_io.write_text_durable(path, "".join(lines))
        path.chmod(modo)
    return changed


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Re-date the sunset tags of exemptions unchanged since the last review.")
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--to", required=True, help="MAJOR.MINOR being cut, e.g. 8.5")
    ap.add_argument("--base", help="commit of the last review (default: newest `chore(sunset)`)")
    ap.add_argument("--apply", action="store_true", help="write the re-dates; default is a dry run")
    ap.add_argument("--list", action="store_true", help="show each re-datable exemption with its justification")
    args = ap.parse_args(argv)
    root = args.root.resolve()
    base = args.base or last_review_commit(root)
    if not base or _git(root, "rev-parse", "--verify", f"{base}^{{commit}}").returncode != 0:
        print("[sunset-redate] COULD_NOT_RUN: no readable last-review commit; pass --base.", file=sys.stderr)
        return 2
    plan = build_plan(root, args.to, base)
    print(f"[sunset-redate] base={base[:8]} to={args.to}: {len(plan.redate)} unchanged, "
          f"{len(plan.needs_review)} need a human")
    for rec, why in plan.needs_review:
        print(f"  REVIEW  {rec.path}:{rec.line_number} [{rec.kind}] -- {why}")
    print("[sunset-redate] NOTE: unchanged since the last review is NOT proof an exemption still contributes; "
          "use --list to read each justification and verify the ones you doubt.")
    if args.list:
        for path, tag_no in plan.redate:
            line = path.read_text(encoding="utf-8").splitlines()[tag_no - 1]
            why = line.split("--", 1)[1].strip() if "--" in line else "(no justification text)"
            print(f"  {path.relative_to(root)}:{tag_no} -- {why}")
    if args.apply:
        print(f"[sunset-redate] re-dated {apply_plan(plan, args.to)} line(s) to {args.to} (content unchanged; not a judgment)")
    return 1 if plan.needs_review else 0


if __name__ == "__main__":
    sys.exit(main())
