# -*- coding: utf-8 -*-
"""pyright_gate.py -- run `pyright` and confess what it never looked at.

Until now `.pre-commit-config.yaml`'s `pyright` hook invoked the `pyright`
binary directly (`gate_runner ... -- pyright`), so its own output was the
whole report: a green run read as "type-checking passed", full stop. pyright
type-checks Python; it has no opinion on a satellite's C#, Rust or
TypeScript, and nothing said so.

DEBT-SURVEY-GATES-MEASURE-THE-SCAFFOLD: same confession `zero_debt` already
prints for its own scan (`NOT EXAMINED -- this scanner reads Python only`),
applied here. This is a thin pass-through, not a reimplementation: pyright
still runs exactly as before (same binary, same args, same cwd, same exit
code), and the one thing added is the line naming what pyright cannot see.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

from simplecode.worktree.zero_debt import unexamined_source


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path.cwd())
    args, forwarded = ap.parse_known_args(argv)
    root = args.root.resolve()

    exe = shutil.which("pyright")
    if exe is None:
        print("[pyright] COULD_NOT_RUN: `pyright` is not on PATH", file=sys.stderr)
        return 2

    result = subprocess.run([exe, *forwarded], cwd=root, check=False)

    unexamined = unexamined_source(root)
    if unexamined:
        total = sum(unexamined.values())
        breakdown = ", ".join(f"{n} {ext}" for ext, n in sorted(unexamined.items()))
        print(
            f"[pyright] NOT EXAMINED -- this gate type-checks Python only: "
            f"{total} tracked source file(s) ({breakdown}). A clean verdict above "
            f"says NOTHING about them."
        )
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
