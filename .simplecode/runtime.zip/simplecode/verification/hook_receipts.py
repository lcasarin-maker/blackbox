# -*- coding: utf-8 -*-
"""hook_receipts.py -- Make `git commit --no-verify` leave a permanent trace (WP18/G3).

When an agent or developer passes `--no-verify`, git skips pre-commit hooks.
This mechanism provides asymmetric accountability:
  1. pre-commit writes a fresh nonce receipt into `.git/.simplecode_receipt`.
  2. post-commit or verify checks if HEAD was committed with a valid receipt.
  3. If not, the unverified commit is recorded into `.simplecode/evidence/hook_receipts.jsonl`.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos

logger = logging.getLogger("hook_receipts")

NO_VERIFY = "GIT_NO_VERIFY"
SEQUENCER_NO_HOOK = "GIT_SEQUENCER_NO_HOOK"
VERIFIED = "GIT_VERIFIED"
# A tree that a SIBLING worktree's own gate_runner verified for real (its
# ledger has a GIT_VERIFIED entry with this exact head_tree), recognized here
# because a fast-forward/no-op merge preserves the worktree's sha and never
# re-runs pre-commit in this checkout. Kept distinct from VERIFIED so the
# ledger states its provenance instead of claiming a receipt that was never
# written in this gitdir. See `_find_verified_by_tree`.
VERIFIED_INHERITED = "GIT_VERIFIED_INHERITED"
# A HISTORICAL commit, already reachable from HEAD, whose own staged state was
# RECONSTRUCTED in a throwaway worktree and put through this repo's own
# installed pre-commit gate launcher, for real, after the fact. Kept distinct
# from both VERIFIED (a live receipt consumed at commit time) and
# VERIFIED_INHERITED (a content match against another worktree's live receipt)
# because it is neither: it is a re-run, by a named operator, at a named time,
# against content that was already in history. See `verify_historical`.
VERIFIED_RETROACTIVE = "GIT_VERIFIED_RETROACTIVE"
# The negative half of the same mechanism, recorded so a REFUSED retroactive
# attempt leaves as permanent a trace as a granted one. Inert to the gate --
# `_ledger_state` does not read it as verification, so a commit whose
# retroactive run failed keeps blocking exactly as if nobody had tried.
RETROACTIVE_REFUSED = "GIT_RETROACTIVE_REFUSED"

# Every event that counts as "this commit passed a real gate". One tuple, read
# by `_ledger_state` AND `unverified_outside_window`, so a new verification
# route can never be recognized by one of the two readers and not the other.
VERIFIED_EVENTS = (VERIFIED, VERIFIED_INHERITED, VERIFIED_RETROACTIVE)

STAGE_PRE_COMMIT = "pre-commit"

# How many commits `--audit` looks back over. Named because the report has
# to say the number out loud: everything older than this is invisible to the
# gate, and `unverified_outside_window` exists to name what fell past it.
AUDIT_WINDOW = 10

# The count of commits that left the window always prints in full; the rows
# are capped, same as `backlog_verifier`'s undatable list, because a repo
# with 48 of them (measured in this one) would otherwise bury the four lines
# that actually block. Every DECLARED one prints uncapped: those are the
# entries whose retirement is now due.
_ESCAPED_PRINT_LIMIT = 10

# How many newly-reachable ancestors one `--stamp-head` will examine for an
# inheritable receipt (see `_stamp_new_ancestors`). Bounded because a first
# merge after adopting this kit can pull in the whole history of a branch, and
# `post-commit`/`post-merge` sit on the commit latency budget (SPEC: < 2s). The
# number of candidates left UNEXAMINED always prints, so the cap can never make
# the walk look complete when it was not.
_ANCESTOR_WALK_LIMIT = 100


def get_git_dir(root: Path) -> Path | None:
    """Return the git directory for root, honouring worktree pointer files.

    In a `git worktree` (and in a submodule) checkout, `root/.git` is a FILE
    holding `gitdir: <path>`, never a directory. The plain `is_dir()` check
    therefore returned None for every worktree, `write_receipt` silently failed,
    and `gate_runner` aborted the commit with `COULD_NOT_RUN receipt` even when
    every real check had passed.

    git already knows how to resolve that pointer, so ask it instead of parsing
    the file here. The answer is the worktree's OWN private gitdir
    (`.git/worktrees/<name>`), so receipts stay isolated per worktree. git is
    only consulted in the pointer-file case, so the common path costs nothing.
    """
    git_path = root / ".git"
    if git_path.is_dir():
        return git_path
    if not git_path.is_file():
        return None
    resolved = _git_output(root, ["rev-parse", "--absolute-git-dir"])
    if not resolved:
        return None
    candidate = Path(resolved)
    return candidate if candidate.is_dir() else None


def git_hooks_dir(root: Path) -> Path | None:
    """The directory git actually looks in for hooks, or None if `root` is no repo.

    NOT `get_git_dir(root) / "hooks"`. In a worktree, `get_git_dir` answers the
    worktree's PRIVATE gitdir (`.git/worktrees/<name>`), which is right for
    receipts and wrong for hooks: git reads hooks from the COMMON directory,
    shared by the main checkout and every worktree. Installing them in the
    private dir puts them where nothing will ever run them.
    """
    if (root / ".git").is_dir():
        return root / ".git" / "hooks"
    if get_git_dir(root) is None:
        return None
    common = _git_output(root, ["rev-parse", "--path-format=absolute", "--git-common-dir"])
    return Path(common) / "hooks" if common else None


def is_git_repo(root: Path) -> bool:
    """Whether `root` is a git checkout, worktrees and submodules included.

    The one place the "is this a repo?" question is answered, because
    `(root / ".git").is_dir()` gets it wrong for both and had already been fixed
    HERE and nowhere else. `organ_crossings` crosses the two readings so the
    next fix does not have to be made twice.
    """
    return get_git_dir(root) is not None


def _git_output(root: Path, args: list[str]) -> str | None:
    """Run a git plumbing command, returning trimmed stdout or None on any failure.

    Used only to read cheap, already-computed git object ids (tree hashes); it
    never mutates the working tree or index beyond what git itself caches.
    """
    try:
        res = subprocess.run(
            ["git", *args],
            cwd=root,
            capture_output=True,
            text=True,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if res.returncode != 0:
        return None
    return res.stdout.strip() or None


def _git_ok(root: Path, args: list[str]) -> bool:
    """Whether a git command SUCCEEDED, judged by its exit code alone.

    Not `_git_output(...) is not None`: that helper folds empty stdout into
    failure, which is right for reading an object id and wrong for a command
    whose success is silent. `git worktree add` and `git reset --soft` both
    print to stderr and leave stdout empty on success, so reading them through
    `_git_output` reports every successful call as a failure.
    """
    try:
        res = subprocess.run(["git", *args], cwd=root, capture_output=True,
                             text=True, check=False)
    except (OSError, subprocess.SubprocessError):
        return False
    return res.returncode == 0


def staged_tree_fingerprint(root: Path) -> str | None:
    """SHA-1 of the staged index tree (``git write-tree``).

    This is the content fingerprint of exactly what a commit *would* capture at
    pre-commit time. git already has to hash the index to commit, so reading it
    is free; the object it writes is a harmless dangling tree.
    """
    return _git_output(root, ["write-tree"])


def head_tree_fingerprint(root: Path) -> str | None:
    """SHA-1 of the tree that HEAD actually committed (``git rev-parse HEAD^{tree}``)."""
    return _git_output(root, ["rev-parse", "HEAD^{tree}"])


def write_receipt(root: Path, stage: str = STAGE_PRE_COMMIT) -> str | None:
    """Write a fingerprinted receipt during pre-commit.

    The receipt is a JSON record carrying the nonce, the resolved hook stage,
    the staged-tree content fingerprint, and a timestamp. The return value stays
    the nonce string, so existing callers are unaffected.
    """
    git_dir = get_git_dir(root)
    if not git_dir:
        return None
    fingerprint = staged_tree_fingerprint(root)
    if fingerprint is None:
        logger.warning("Could not fingerprint staged tree; refusing to write an unverified hook receipt")
        return None
    receipt_file = git_dir / ".simplecode_receipt"
    nonce = str(uuid.uuid4())
    record = {
        "nonce": nonce,
        "stage": stage,
        "staged_fingerprint": fingerprint,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    try:
        atomic_io.write_text_durable(receipt_file, json.dumps(record, sort_keys=True))
        return nonce
    except OSError as exc:
        logger.warning("Could not write hook receipt: %s", exc)
        return None


def _read_receipt_record(root: Path) -> dict[str, Any] | None:
    """Read and remove the receipt, returning its record dict.

    Understands both the fingerprinted JSON receipt and a legacy plain-nonce
    receipt (wrapped as ``{"nonce": <raw>}``). Returns None when there is no
    receipt or it cannot be read.
    """
    git_dir = get_git_dir(root)
    if not git_dir:
        return None
    receipt_file = git_dir / ".simplecode_receipt"
    if not receipt_file.is_file():
        return None
    try:
        raw = receipt_file.read_text(encoding="utf-8").strip()
        receipt_file.unlink(missing_ok=True)
    except OSError:
        return None
    try:
        record = json.loads(raw)
    except ValueError:
        return {"nonce": raw}
    if isinstance(record, dict):
        return record
    return {"nonce": raw}


def consume_receipt(root: Path) -> str | None:
    """Read and remove the receipt, returning the nonce (backward-compatible)."""
    record = _read_receipt_record(root)
    if record is None:
        return None
    nonce = record.get("nonce")
    return nonce if isinstance(nonce, str) else None


def record_hook_event(root: Path, event_type: str, commit_sha: str, details: dict | None = None) -> Path | None:
    """Append event to .simplecode/evidence/hook_receipts.jsonl.

    PER WORKTREE, deliberately, and NOT shared with the main checkout. The
    launcher links `.simplecode/run.py` and `runtime.zip` into a linked worktree
    precisely so gates can run there; `evidence/` is excluded from that linking
    on purpose, and this paragraph exists so nobody adds it later as an obvious
    convenience.

    Decided by the Atlas session 2026-09-02 (DGX-403/DGX-434) with the argument
    that settles it: a coder's commit lands in the main checkout via
    `git apply` + `git commit -C`, which creates a NEW sha whose pre-commit runs
    in the main checkout and writes ITS receipt to the main ledger. The
    worktree's receipt describes a different sha and has no reason to travel.
    The only route that would need a shared ledger is `git am` / `cherry-pick`,
    which preserve a patch without passing through pre-commit -- and that route
    is prohibited there for exactly that reason.

    Sharing it would also let one worktree CONSUME the nonce another wrote: a
    receipt that does not describe the tree being committed, which is the single
    thing this mechanism exists to make impossible.

    DEBT-AEQUITAS-WORKTREE-RECEIPT (2026-09-17): the assumption above -- that a
    worktree-originated commit always lands via `git apply` + `git commit -C`
    -- does not hold for a plain `git merge --ff-only` (or any fast-forward),
    which keeps the worktree's ORIGINAL sha and never re-runs pre-commit in the
    main checkout. Measured live: a commit verified in an isolated worktree
    (created by e.g. the Agent tool's `isolation: "worktree"`) left a real
    GIT_VERIFIED entry in ITS OWN ledger, then a fast-forward merge of that
    same sha into main produced GIT_NO_VERIFY in main's ledger, because main
    never had a fresh receipt to consume. The ledger stays split per worktree
    (unchanged, per the reasoning above); what changed is that `--stamp-head`
    now ALSO checks, read-only, whether some sibling worktree's ledger already
    verified the EXACT TREE it is about to stamp (`_find_verified_by_tree`).
    That is content-identity, not sha-identity, so it does not reopen the
    nonce-reuse hole this docstring warns about: nothing is consumed, and a
    tree that never had a real GIT_VERIFIED entry anywhere still blocks.

    DEBT-AEQUITAS-MERGE-ANCESTOR-RECEIPT (2026-09-17): the fix above covers
    the commit that IS HEAD and nothing else, because `--stamp-head` only ever
    judged the one commit just made. Measured live in poe_systems the same
    day: a TRUE (non-fast-forward) merge makes a whole topic branch reachable
    at once, git runs no hook for any of those ancestors, and the merge commit
    `24ec59e` left `067d6d35` -- a real, worktree-verified commit -- with ZERO
    entries in main's ledger. Two additions, both in the direction of
    recognizing verification that really happened and in no other:

      * `_stamp_new_ancestors`, called from `--stamp-head` after HEAD's own
        verdict, offers every NEWLY-REACHABLE, not-yet-judged ancestor the
        same tree-identity check. A match writes that ancestor its own
        GIT_VERIFIED_INHERITED entry; no match writes NOTHING, so the commit
        keeps blocking exactly as before.
      * `verify_historical`, for the case inheritance structurally cannot
        reach: the originating worktree was removed (`git worktree remove`,
        routine cleanup) and its ledger went with it. That one does not look
        for a past receipt at all -- it RE-RUNS this repo's own pre-commit
        suite against the commit's reconstructed staged diff and records
        GIT_VERIFIED_RETROACTIVE only if it passes. See the long comment above
        `verify_historical` for why that is a verification and not a bypass.
    """
    evidence_dir = root / ".simplecode" / "evidence"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    ledger = evidence_dir / "hook_receipts.jsonl"
    
    entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "event": event_type,
        "commit": commit_sha,
        "details": details or {},
    }
    try:
        atomic_io.append_jsonl(ledger, entry)
        return ledger
    except OSError as exc:
        logger.warning("Could not record hook event: %s", exc)
        return None


def _sibling_worktree_roots(root: Path) -> list[Path]:
    """Every OTHER worktree git already knows about for this checkout.

    Reads `git worktree list --porcelain` rather than assuming a path
    convention like `.claude/worktrees/*`, so it works for any linked
    worktree regardless of who created it. `root` itself is excluded --
    inheritance only ever looks AWAY from where verification just failed to
    find a fresh receipt. A worktree git still lists but whose directory was
    since removed (`prunable`) is filtered out by the `.is_dir()` check in
    `_find_verified_by_tree`, not here, so a single `git` call covers both.
    """
    listing = _git_output(root, ["worktree", "list", "--porcelain"])
    if not listing:
        return []
    root_resolved = root.resolve()
    others: list[Path] = []
    for line in listing.splitlines():
        if not line.startswith("worktree "):
            continue
        candidate = Path(line[len("worktree "):]).resolve()
        if candidate != root_resolved:
            others.append(candidate)
    return others


def _sibling_verified_index(root: Path) -> dict[str, dict[str, Any]]:
    """tree hash -> the GIT_VERIFIED entry (plus its worktree) that earned it.

    One pass over every sibling worktree's ledger, so a caller with N trees to
    check pays for the ledgers ONCE instead of N times. That is the whole
    reason it exists: `_stamp_new_ancestors` asks about up to
    `_ANCESTOR_WALK_LIMIT` trees on the `post-merge` latency budget, and the
    per-tree scan `_find_verified_by_tree` used to do would re-read the same
    files a hundred times.

    Priority is the one `_find_verified_by_tree` already had, preserved
    deliberately: within one worktree the LAST matching entry wins (a ledger is
    append-only, so the last one is the most recent verdict for that tree), and
    between worktrees the FIRST one git lists wins (`setdefault`). Which of two
    worktrees supplies the receipt is immaterial to the verdict -- both are
    real GIT_VERIFIED entries for the identical tree -- but it decides which
    provenance gets printed, so it stays deterministic rather than incidental.

    Only GIT_VERIFIED is indexed. A sibling's VERIFIED_INHERITED entry is a
    second-hand claim and would let inheritance chain across worktrees without
    anybody re-reading the original; a sibling's VERIFIED_RETROACTIVE entry is
    a re-run whose provenance belongs to that commit and does not travel. Both
    are declared limits, not oversights.
    """
    index: dict[str, dict[str, Any]] = {}
    for wt_root in _sibling_worktree_roots(root):
        ledger = wt_root / ".simplecode" / "evidence" / "hook_receipts.jsonl"
        if not ledger.is_file():
            continue
        local: dict[str, dict[str, Any]] = {}
        for entry in atomic_io.read_jsonl(ledger):
            if entry.get("event") != VERIFIED:
                continue
            tree = entry.get("details", {}).get("head_tree")
            if isinstance(tree, str) and tree:
                local[tree] = {**entry, "worktree": str(wt_root)}
        for tree, entry in local.items():
            index.setdefault(tree, entry)
    return index


def _find_verified_by_tree(root: Path, head_tree: str | None) -> dict[str, Any] | None:
    """A GIT_VERIFIED ledger entry from a SIBLING worktree for this exact tree.

    Read-only cross-check for the fast-forward gap described in
    `record_hook_event`'s docstring: main has no fresh receipt to consume, but
    some other worktree this repo knows about may have already run the real
    gate against the identical tree now sitting at HEAD. Matches on
    `details.head_tree`, the git-native tree hash recorded at the OTHER
    worktree's own `--stamp-head` time -- content identity, not sha identity,
    so it still refuses a tree nobody ever actually verified. Returns the
    entry plus which worktree it came from, or None if nothing matches.
    """
    if not head_tree:
        return None
    return _sibling_verified_index(root).get(head_tree)


def _ledger_path(root: Path) -> Path:
    return root / ".simplecode" / "evidence" / "hook_receipts.jsonl"


def _judged_shas(root: Path) -> set[str]:
    """Every commit this checkout's ledger has ANY verdict about.

    Not "verified" -- ANY entry, GIT_NO_VERIFY included. `_stamp_new_ancestors`
    uses it as a "leave it alone" set: a commit already judged here (verified,
    bypassed, or refused a retroactive run) must not be re-judged behind the
    operator's back by a later merge that happens to re-reach it.
    """
    judged: set[str] = set()
    for entry in atomic_io.read_jsonl(_ledger_path(root)):
        commit = entry.get("commit")
        if isinstance(commit, str):
            judged.add(commit)
    return judged


def _new_ancestor_candidates(root: Path, head: str) -> list[str]:
    """Commits this checkout can now reach that it could not reach before.

    DEBT-AEQUITAS-MERGE-ANCESTOR-RECEIPT (2026-09-17, measured live in
    poe_systems): `--stamp-head` only ever judged the ONE commit that had just
    been made. A merge does not make one commit reachable, it makes a whole
    topic branch reachable, and git runs no hook for any of those ancestors --
    so a commit verified for real inside an isolated worktree, then brought in
    by a TRUE (non-fast-forward) merge, ends with ZERO entries in the merging
    checkout's ledger: not GIT_VERIFIED, not GIT_NO_VERIFY, nothing. Measured:
    `24ec59e` merged `067d6d35` into poe_systems' master and `--audit --gate`
    blocked on `067d6d35` for want of an entry nobody could have written.

    Two independent readings, unioned, because neither alone covers both
    shapes:

      * `HEAD ^HEAD^1` -- for a merge commit, exactly what the merge pulled in
        along its non-first parents. Derived from the commit graph, so it needs
        no state and cannot go stale.
      * `HEAD ^HEAD@{1}` -- the reflog's previous HEAD, which also catches a
        FAST-FORWARD of a branch carrying SEVERAL commits: there the graph has
        no merge commit to interrogate at all, HEAD simply moved forward over
        commits 1..n-1 that nothing ever stamped. Absent or unresolvable
        (a fresh clone, an expired reflog) it contributes nothing rather than
        failing the walk.

    HEAD itself is always excluded -- its own verdict is `_run_stamp_head`'s
    job and was already written by the time this runs.
    """
    candidates: list[str] = []
    seen: set[str] = {head}
    parents = (_git_output(root, ["rev-list", "--parents", "-n", "1", head]) or "").split()
    ranges: list[list[str]] = []
    if len(parents) > 2:  # sha + 2 or more parents == a real merge commit
        ranges.append(["rev-list", head, f"^{head}^1"])
    # `HEAD@{1}` literally, never `<sha>@{1}`: the reflog suffix resolves
    # against a REF NAME, and git rejects it on a raw object id -- so passing
    # the sha silently produced no range at all and the fast-forward-over-
    # several-commits case was never reached (caught by
    # `test_fast_forward_of_a_multi_commit_branch_stamps_every_commit`, which
    # failed until this read `HEAD`). Guarded by `head == current HEAD`, since
    # the reflog only describes where HEAD itself has been.
    if head == (_git_output(root, ["rev-parse", "HEAD"]) or "") and _git_output(
        root, ["rev-parse", "--verify", "--quiet", "HEAD@{1}"]
    ):
        ranges.append(["rev-list", head, "^HEAD@{1}"])
    for args in ranges:
        listed = _git_output(root, args)
        if not listed:
            continue
        for sha in listed.splitlines():
            sha = sha.strip()
            if sha and sha not in seen:
                seen.add(sha)
                candidates.append(sha)
    return candidates


def _stamp_new_ancestors(root: Path, head: str) -> None:
    """Offer every newly-reachable, unjudged ancestor the inheritance check.

    Additive and one-directional: an ancestor whose EXACT tree a sibling
    worktree really verified gets its own GIT_VERIFIED_INHERITED entry here;
    an ancestor with no such match gets NOTHING WRITTEN AT ALL, so it keeps
    blocking `--audit --gate` exactly as it does today. This closes a hole in
    the direction of recognizing real verification and in no other direction --
    the negative control for that is
    `test_merge_pulling_in_a_never_verified_commit_still_blocks`.

    Bounded by `_ANCESTOR_WALK_LIMIT`, and the number of candidates it did NOT
    examine prints, because a cap that hides what it skipped is how a partial
    walk gets read as a complete one.
    """
    candidates = _new_ancestor_candidates(root, head)
    if not candidates:
        return
    judged = _judged_shas(root)
    pending = [sha for sha in candidates if sha not in judged]
    if not pending:
        return
    examined, unexamined = pending[:_ANCESTOR_WALK_LIMIT], pending[_ANCESTOR_WALK_LIMIT:]
    index = _sibling_verified_index(root)
    if not index:
        # Nothing to match against, so the per-candidate `rev-parse <sha>^{tree}`
        # would be pure cost on the commit-latency budget (SPEC: < 2s) with no
        # reachable verdict. A plain `git checkout` between divergent branches
        # can make dozens of old commits "newly reachable" on the next commit,
        # which is exactly when this short-circuit earns its keep. Silent on
        # purpose: with no sibling ledger there is no walk to report.
        return
    inherited = 0
    for sha in examined:
        tree = _git_output(root, ["rev-parse", f"{sha}^{{tree}}"])
        match = index.get(tree) if tree else None
        if match is None:
            continue
        details = {
            "nonce": None,
            "stage": None,
            "staged_fingerprint": None,
            "head_tree": tree,
            "verification_ran": False,
            "inherited_from_worktree": match.get("worktree"),
            "inherited_from_commit": match.get("commit"),
            "reached_by": head,
            "reached_as": "newly-reachable ancestor of a merge/fast-forward, "
                          "never HEAD in this checkout",
        }
        if record_hook_event(root, VERIFIED_INHERITED, sha, details) is not None:
            inherited += 1
            print(
                f"[hook-receipts] Ancestor {sha[:8]}, newly reachable via {head[:8]} and "
                f"never HEAD here, stamped verified BY INHERITANCE: tree {tree} matches a "
                f"GIT_VERIFIED receipt in worktree {match.get('worktree')}."
            )
    # Unconditional, zeros included: this line is the only evidence that the
    # walk ran at all, and a walk that stayed silent when it found nothing
    # could not be told apart from a walk that never happened.
    print(
        f"[hook-receipts] newly-reachable ancestors examined: {len(examined)} "
        f"({inherited} inherited a real receipt, {len(examined) - inherited} left "
        f"unverified and still blocking); {len(unexamined)} NOT examined "
        f"(cap {_ANCESTOR_WALK_LIMIT})"
    )


def _ledger_state(ledger_file: Path) -> tuple[set[str], list[str]]:
    verified_shas: set[str] = set()
    recorded_shas: list[str] = []
    for entry in atomic_io.read_jsonl(ledger_file):
        commit = entry.get("commit")
        if not isinstance(commit, str):
            continue
        recorded_shas.append(commit)
        if entry.get("event") in VERIFIED_EVENTS:
            verified_shas.add(commit)
    return verified_shas, recorded_shas


def _parse_commit(line: str, verified_shas: set[str]) -> dict[str, Any] | None:
    """One `git log` row.

    `date` is the COMMITTER date (`%cd`), not the author date it used to be
    (`%ad`): a cherry-pick or a rebase carries the ORIGINAL author date onto a
    commit created today, so a baseline that amnestied by author date would
    hand a brand-new commit the date of whatever it was derived from. Nothing
    else in the kit reads this field, and no column was added: the row keeps
    its four fields, which is why the mocked `audit_recent_commits` fixture in
    `test_forensic_coverage_completion.py` keeps parsing.
    """
    parts = line.split("\x1f", 3)
    if len(parts) < 4:
        return None
    return {
        "sha": parts[0],
        "author": parts[1],
        "date": parts[2],
        "subject": parts[3],
        "verified": parts[0] in verified_shas,
    }


def audit_recent_commits(root: Path, limit: int = AUDIT_WINDOW) -> list[dict[str, Any]]:
    """Inspect commits since receipt adoption and report their verification state."""
    ledger_file = root / ".simplecode" / "evidence" / "hook_receipts.jsonl"
    verified_shas, recorded_shas = _ledger_state(ledger_file)

    if not recorded_shas:
        return []

    try:
        res = subprocess.run(
            ["git", "log", f"-n{limit}", "--format=%H%x1f%an%x1f%cd%x1f%s", "--date=iso-strict"],
            cwd=root,
            capture_output=True,
            text=True,
            check=False,
        )
        if res.returncode != 0:
            return []
        commits: list[dict[str, Any]] = []
        for line in res.stdout.splitlines():
            commit = _parse_commit(line, verified_shas)
            if commit is None:
                continue
            commits.append(commit)
            if commit["sha"] == recorded_shas[0]:
                break
        return commits
    except (OSError, subprocess.SubprocessError):
        return []


# ---------------------------------------------------------------------------
# Declared receipt baseline: HISTORICAL commits amnestied by SHA
# ---------------------------------------------------------------------------
#
# Same shape as `finding_backlog.load_baseline` and
# `backlog_verifier.load_could_not_run_baseline` -- owner + expiry + a NAMED
# list of entries, each with its own reason -- so the kit has ONE way to
# declare a baseline and not a third one. The per-entry-reason variant
# (`could_not_run_baseline.json`) is the one copied: every amnestied commit
# states why it has no receipt, because "4 commits, historical debt" is a
# count and a count is satisfied by any 4 commits.
#
# What this file may NOT become is an off switch, and that is the whole
# difficulty. A baseline that forgives a commit made tomorrow with
# `--no-verify` is `--gate` disabled under another name. Three locks, all of
# which must hold before one commit stops blocking:
#
#   1. EXPLICIT SHA, never a range and never a prefix. A commit that does not
#      exist yet has no sha to name, so the file cannot pre-authorise it.
#   2. THE COMMIT MUST PREDATE THE DECLARED `cutoff` (its committer date,
#      strictly before). This is `task_contract_cutoff.json`'s mechanism, and
#      it is what stops lock 1 from being defeated by appending tomorrow's sha
#      to the file tomorrow: tomorrow's commit is not before the cutoff, so
#      naming it changes nothing and the gate says so out loud.
#   3. THE CUTOFF MAY NOT BE IN THE FUTURE. A cutoff nobody has reached yet
#      authorises commits nobody has written, which is lock 2 spelled
#      backwards. A future cutoff voids the WHOLE baseline, not just the
#      entries past it.
#
# Declared residual, because a limit that is not written down is a limit
# nobody knows about: whoever can edit this file can also move `cutoff`
# forward to today and name a commit made today. No code in this module can
# prevent that -- the file is the human's declaration. What is left against it
# is that the file is a reviewed commit and that the cutoff, the owner and
# every amnestied sha PRINT on every single run of the gate. A strictly
# stronger lock exists and is NOT implemented here (it would need a fourth
# rule rather than reusing the fleet's two): require each amnestied sha to be
# an ancestor of the commit that first ADDED this file, which makes moving the
# cutoff useless and forces a visible delete-and-reintroduce instead.
#
# Absent, malformed, expired, or future-cutoff all mean NO entries apply and
# every unverified commit blocks. Failing toward blocking is the only
# direction in which an expiry stays honest.

RECEIPT_BASELINE_RELPATH = Path(".simplecode") / "hook_receipt_baseline.json"

_SHA_LEN = 40


def _commit_date(iso: str | None) -> date | None:
    """The date part of a git iso-strict stamp, or None if it is not one.

    None is the fail-closed answer: `classify_unverified` REFUSES an entry it
    cannot date rather than granting it, so a row this cannot read blocks."""
    if not iso:
        return None
    try:
        return datetime.fromisoformat(iso).date()
    except ValueError:
        return None


def load_receipt_baseline(root: Path) -> tuple[dict[str, Any], str]:
    """The declared receipt baseline and a note, or ({}, why-not).

    The note is printed unconditionally by the audit, exactly as
    `finding_backlog` prints its own: a baseline that stopped applying in
    silence is how a gate goes green without anybody fixing anything.
    """
    path = root / RECEIPT_BASELINE_RELPATH
    rel = RECEIPT_BASELINE_RELPATH.as_posix()
    if not path.is_file():
        return {}, f"no {rel} declared: every commit without a receipt blocks"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        expires = date.fromisoformat(str(data["expires"]))
        cutoff = date.fromisoformat(str(data["cutoff"]))
        owner = str(data["owner"]).strip()
        raw_entries = {str(k).strip().lower(): str(v) for k, v in dict(data["entries"]).items()}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return {}, (f"COULD_NOT_RUN: {rel} is unreadable or incomplete ({exc}); it needs "
                    f"`owner`, `expires`, `cutoff` and `entries`. No entry applies.")
    if not owner or not raw_entries:
        return {}, f"{rel} declares no owner or no entries; none apply"
    today = date.today()
    if today > expires:
        return {}, (f"RECEIPT BASELINE EXPIRED on {expires.isoformat()} (owner: {owner}); "
                    f"every commit it named blocks again")
    if cutoff > today:
        return {}, (f"RECEIPT BASELINE REFUSED: its cutoff {cutoff.isoformat()} is in the FUTURE "
                    f"(today {today.isoformat()}), which would pre-authorise commits nobody has "
                    f"written yet. The whole baseline is void; every entry blocks.")
    entries = {k: v for k, v in raw_entries.items()
               if len(k) == _SHA_LEN and all(c in "0123456789abcdef" for c in k)}
    ignored = sorted(set(raw_entries) - set(entries))
    left = (expires - today).days
    note = (f"{len(entries)} declared commit(s), owner {owner}, cutoff {cutoff.isoformat()}, "
            f"expires {expires.isoformat()} ({left} day(s) left)")
    if ignored:
        note += (f"; {len(ignored)} key(s) IGNORED, not a full 40-hex sha: "
                 f"{', '.join(ignored)}")
    if not entries:
        return {}, note + " -- so no entry applies"
    return {"owner": owner, "cutoff": cutoff, "expires": expires,
            "entries": entries, "reason": str(data.get("reason", ""))}, note


def classify_unverified(unverified: list[dict[str, Any]],
                        baseline: dict[str, Any]) -> tuple[list[tuple[dict, str]],
                                                           list[tuple[dict, str]],
                                                           list[dict]]:
    """Split unverified commits into (amnestied, refused, blocking).

    `refused` is a commit the baseline NAMES but may not cover, because it is
    not strictly older than the declared cutoff. It appears in `blocking` too:
    naming it does not stop it blocking, and the report says why it was named
    in vain instead of dropping the attempt on the floor.

    DEBT-HOOK-RECEIPT-BASELINE-SAME-DAY-CUTOFF (2026-09-08): the strict `<`
    below, combined with `load_receipt_baseline`'s own `cutoff <= today`
    invariant, made same-day amnesty impossible by construction -- for a
    commit made today, `when == today`, so covering it needed `today < cutoff`
    while the other rule demanded `cutoff <= today`, contradictory for any
    cutoff. The narrow fix: `when <= cutoff` is allowed ONLY when the cutoff
    itself IS today. A cutoff dated any earlier day keeps the strict `<` --
    the lock that stops a stale, distant-past baseline from reaching forward
    to amnesty a commit written well after the baseline was declared.
    """
    entries = baseline.get("entries", {})
    cutoff = baseline.get("cutoff")
    today = date.today()
    amnestied: list[tuple[dict, str]] = []
    refused: list[tuple[dict, str]] = []
    blocking: list[dict] = []
    for commit in unverified:
        reason = entries.get(commit["sha"].lower())
        when = _commit_date(commit.get("date"))
        covers = cutoff is not None and when is not None and (
            when < cutoff or (cutoff == today and when == cutoff)
        )
        if reason is None:
            blocking.append(commit)
        elif not covers:
            stamp = when.isoformat() if when else "UNDATABLE"
            refused.append((commit, f"named by the baseline but committed {stamp}, "
                                    f"not strictly before the cutoff "
                                    f"{cutoff.isoformat() if cutoff else 'NONE'} "
                                    "(same-day is allowed only when the cutoff "
                                    "itself is today)"))
            blocking.append(commit)
        else:
            amnestied.append((commit, reason))
    return amnestied, refused, blocking


def unverified_outside_window(root: Path, window_shas: set[str]) -> list[dict[str, Any]]:
    """Unverified commits still in HEAD's history that the audited window no longer reaches.

    The audit looks at the last `limit` commits, so an unverified commit stops
    being reported once enough commits land on top of it -- measured live in
    the `own_chats` satellite, 6 -> 5 -> 4 over three commits. The gate then
    turns green BY EXPIRY OF THE WINDOW and not by anybody fixing anything,
    and whoever reads the green has no way to tell the two apart.

    The ledger outlives the window, so the fact survives even when the report
    of it does: every commit that reached `post-commit` without a receipt has
    a GIT_NO_VERIFY row in `hook_receipts.jsonl`. Commits no longer reachable
    from HEAD (amended, rebased away) are excluded -- they would be a false
    alarm that never clears.

    This is REPORTED, never blocking. Blocking on every historical bypass at
    once would block every repo that ever had one, which is how a gate gets
    switched off for good.
    """
    ledger_file = root / ".simplecode" / "evidence" / "hook_receipts.jsonl"
    verified: set[str] = set()
    unverified: dict[str, str] = {}
    for entry in atomic_io.read_jsonl(ledger_file):
        commit = entry.get("commit")
        if not isinstance(commit, str):
            continue
        if entry.get("event") in VERIFIED_EVENTS:
            verified.add(commit)
        elif entry.get("event") in (NO_VERIFY, SEQUENCER_NO_HOOK):
            unverified.setdefault(commit, str(entry.get("timestamp", "")))
    candidates = {sha: ts for sha, ts in unverified.items()
                  if sha not in verified and sha not in window_shas}
    if not candidates:
        return []
    reachable = _git_output(root, ["rev-list", "HEAD"])
    if reachable is None:
        return []
    in_history = set(reachable.splitlines())
    return [{"sha": sha, "recorded": ts}
            for sha, ts in sorted(candidates.items(), key=lambda kv: kv[1])
            if sha in in_history]


def _print_escaped(escaped: list[dict[str, Any]], declared: set[str]) -> None:
    """The silent-green half of the report: what the window stopped charging for.

    The COUNT always prints, zeros included. The rows are capped, the way
    `backlog_verifier` caps its undatable list, because a repo with 48 of them
    (measured in the kit itself, 2026-09-05) would otherwise bury the lines
    that actually block. Every DECLARED one prints uncapped: those are exactly
    the baseline entries whose retirement is now due, and they are the ones
    that would let a green gate be mistaken for a repaired one.
    """
    for row in escaped:
        if row["sha"].lower() in declared:
            print(f"  ~ {row['sha'][:8]} recorded unverified at {row['recorded']} [declared -- "
                  f"the baseline still pays for a commit the window no longer charges for]")
    others = [row for row in escaped if row["sha"].lower() not in declared]
    for row in others[:_ESCAPED_PRINT_LIMIT]:
        print(f"  ~ {row['sha'][:8]} recorded unverified at {row['recorded']}")
    hidden = len(others) - _ESCAPED_PRINT_LIMIT
    if hidden > 0:
        print(f"  ~ ... and {hidden} more that left the window unverified")


# ---------------------------------------------------------------------------
# Retroactive verification: re-run the REAL gate against a historical commit
# ---------------------------------------------------------------------------
#
# DEBT-AEQUITAS-MERGE-ANCESTOR-RECEIPT, second half (2026-09-17, poe_systems).
# `_stamp_new_ancestors` above can only recognize verification that still
# EXISTS somewhere: it needs the originating worktree present on disk with its
# own `hook_receipts.jsonl`. `git worktree remove` is a normal, sanctioned
# cleanup -- poe_systems' `/clean` skill ran it on three worktrees minutes
# after the merge that brought their commits in -- and it takes that ledger
# with it. Four commits in poe_systems were left permanently unverifiable by
# inheritance: `067d6d35`, `a018cb70`, `0c8a8877`, `372a904e`.
#
# The declared-amnesty file (`hook_receipt_baseline.json`, above) would forgive
# them. Luis refused that route for this case on 2026-09-17 and asked for the
# mechanism to be fixed instead, which is what this is: not a forgiveness, a
# RE-RUN. Given a commit already reachable from HEAD, this reconstructs the
# exact state its own pre-commit hook would have seen -- HEAD at its first
# parent, index and working tree at its own tree, so `git diff --cached` IS
# that commit's diff -- inside a throwaway `git worktree`, and executes THE
# REPO'S OWN installed pre-commit launcher against it. If that suite passes,
# clean and for real, the ledger gets a GIT_VERIFIED_RETROACTIVE entry naming
# who ran it, when, with what, and against what. If it fails, or could not
# run, the ledger gets GIT_RETROACTIVE_REFUSED -- inert to the gate -- and the
# commit keeps blocking.
#
# Why the PRE-COMMIT stage and the commit's own staged diff, rather than a
# whole-repo `--all-files` sweep: the receipt that is missing is a pre-commit
# receipt, and a pre-commit receipt attests what the COMMIT INTRODUCED. Half
# this fleet's pre-commit gates are explicitly `--staged`-scoped for that
# reason (`corruption-guard --staged`, `zero-debt --staged`, `staged-parity`,
# `staged-mode-guard`), and running them over a checkout with an empty index
# reports `(no files to check)Skipped` for each -- exit 0, nothing measured,
# the 2026-08-24 failure verbatim. Reconstructing the index makes the same
# instrument measure the same subject it was built to measure.
#
# Three things make this a verification and not a bypass:
#
#   1. THE COMMAND IS NOT AN ARGUMENT. There is no `--gate-command`, because
#      `--gate-command true` would certify anything. The command is the repo's
#      own `pre-commit` hook launcher, found through git, required to carry the
#      `simplecode-managed-hook:v1` marker, and its sha256 is recorded in the
#      ledger entry so an auditor can tell WHICH suite did the certifying.
#   2. A SUITE THAT MEASURED NOTHING IS A REFUSAL. Exit 0 is necessary and not
#      sufficient: an empty reconstructed diff, a run whose every check was
#      Skipped, or any `COULD_NOT_RUN` marker in the output all refuse. The
#      count of checks that did not run prints beside the count that did.
#   3. THE ENVIRONMENT CANNOT SILENCE IT. `SKIP`, `SIMPLECODE_SKIP_REASON` and
#      `SIMPLECODE_TELEMETRY` are stripped from the child environment: `SKIP`
#      is pre-commit's own off switch keyed by hook id, and an ambient one
#      would turn this into exactly the assertion it must not be.
#
# Declared residuals, because a limit nobody wrote down is a limit nobody
# knows about:
#
#   * It certifies the commit's CONTENT against TODAY'S gates and today's tool
#     versions, not against the gates as they stood when the commit was made.
#     That is strictly the stronger claim for a commit still reachable from
#     HEAD (it is the current gates that must accept the current history), and
#     it is the reason the event is not called GIT_VERIFIED.
#   * The gate output is kept only as a sha256 in the ledger, not stored. The
#     text prints live, for the operator who ran it; nothing replays it later.
#   * A merge commit reconstructs against its FIRST parent, which is what
#     git's own `pre-merge-commit` would have staged. The other parents'
#     content is reviewed as part of THEIR OWN commits, each of which the
#     audit judges separately.
#   * A root commit (no parent) is refused: there is no pre-commit state to
#     reconstruct from. No repo in the fleet adopted receipts at its root
#     commit, so this has no live case.

_MANAGED_HOOK_MARKER = "simplecode-managed-hook:v1"

# One regex over the pre-commit framework's own per-hook result lines
# (`name...........Passed`, `name....(no files to check)Skipped`). It is a
# deliberate superset of `gate_runner._DID_NOT_RUN`, which only needs the
# Skipped half: here the PASSED count is load-bearing, because a suite where
# nothing ran must be refused rather than read as clean.
_SUITE_RESULT_LINE = re.compile(r"^(?P<check>.*?)\.{3,}(?P<tail>.*?)\s*$", re.M)

# Stripped from the child environment before the gate suite runs. The first
# three are pre-commit's/simplecode's own off switches; the git ones would
# point the child at THIS process's gitdir instead of the scratch worktree's
# (this module runs from inside git hooks, where git exports them).
_STRIPPED_GATE_ENV = frozenset({
    "SKIP", "SIMPLECODE_SKIP_REASON", "SIMPLECODE_TELEMETRY", "SIMPLECODE_RUN_ID",
    "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
})


def _operator_identity(root: Path) -> str:
    """Who is making this retroactive claim, as specifically as git and the OS know.

    Recorded because a retroactive verification is the one entry in this
    ledger that a PERSON decided to create; every other entry is a hook firing
    on its own. An entry that does not name its author is an anonymous claim.
    """
    name = _git_output(root, ["config", "user.name"]) or "UNKNOWN"
    email = _git_output(root, ["config", "user.email"]) or "UNKNOWN"
    login = os.environ.get("USER") or os.environ.get("LOGNAME") or "UNKNOWN"
    return f"{name} <{email}> (os user {login}@{platform.node() or 'UNKNOWN'})"


def _managed_gate_launcher(root: Path) -> tuple[Path, str] | None:
    """This repo's own installed pre-commit launcher, and its sha256.

    None when there is no launcher, it is not executable, or it does not carry
    the `simplecode-managed-hook:v1` marker -- all three are COULD_NOT_RUN,
    never "nothing to check": with no managed launcher there is no gate suite
    to re-run, so no retroactive claim can be made about anything.
    """
    hooks = git_hooks_dir(root)
    if hooks is None:
        return None
    launcher = hooks / STAGE_PRE_COMMIT
    if not launcher.is_file() or not os.access(launcher, os.X_OK):
        return None
    try:
        raw = launcher.read_bytes()
    except OSError:
        return None
    if _MANAGED_HOOK_MARKER not in raw.decode("utf-8", errors="replace"):
        return None
    return launcher, hashlib.sha256(raw).hexdigest()


def _suite_tallies(output: str) -> tuple[int, int, list[str]]:
    """(passed, failed, names that did not run) from one pre-commit suite run."""
    passed = failed = 0
    skipped: list[str] = []
    for match in _SUITE_RESULT_LINE.finditer(output):
        tail, check = match.group("tail"), match.group("check").strip()
        if tail.endswith("Passed"):
            passed += 1
        elif tail.endswith("Failed"):
            failed += 1
        elif tail.endswith("Skipped"):
            skipped.append(check)
    return passed, failed, skipped


def _reconstruct_precommit_state(root: Path, sha: str, scratch: Path) -> str | None:
    """Stage `sha`'s own diff in a fresh worktree; return its first parent, or None.

    `git worktree add --detach` puts HEAD, index and working tree all at
    `sha`; `git reset --soft <parent>` then moves HEAD alone back one commit,
    leaving index and working tree at `sha`'s content. The result is byte-for-
    byte the state `sha`'s own pre-commit hook saw: `git diff --cached` is its
    diff, `git status` shows its files staged, nothing else differs.
    """
    parents = (_git_output(root, ["rev-list", "--parents", "-n", "1", sha]) or "").split()
    if len(parents) < 2:
        return None
    base = parents[1]
    if not _git_ok(root, ["worktree", "add", "--detach", str(scratch), sha]):
        return None
    if not _git_ok(scratch, ["reset", "--soft", base]):
        return None
    # Positive control on the reconstruction itself, not on the commands that
    # built it: HEAD must really be the parent and the index must really hold
    # the commit's own tree. Without this a silently half-applied reset would
    # hand the suite the WRONG subject and the pass would mean nothing.
    if _git_output(scratch, ["rev-parse", "HEAD"]) != base:
        return None
    if _git_output(scratch, ["write-tree"]) != _git_output(root, ["rev-parse", f"{sha}^{{tree}}"]):
        return None
    return base


def _remove_scratch_worktree(root: Path, scratch: Path) -> None:
    """Take the throwaway worktree back out of git's list, then off the disk.

    Both halves unconditionally, and neither allowed to raise: a scratch
    worktree left registered would show up in `_sibling_worktree_roots` for
    every later `--stamp-head` in this repo, which is the one place a stale
    directory could turn into a wrong inheritance verdict.
    """
    _git_output(root, ["worktree", "remove", "--force", str(scratch)])
    shutil.rmtree(scratch, ignore_errors=True)
    _git_output(root, ["worktree", "prune"])


def _run_gate_suite(root: Path, launcher: Path, scratch: Path) -> tuple[int, str]:
    """Execute the repo's own pre-commit launcher inside `scratch`."""
    from simplecode.utils.tool_limits import RETROACTIVE_GATE_TIMEOUT

    env = {k: v for k, v in os.environ.items() if k not in _STRIPPED_GATE_ENV}
    try:
        res = subprocess.run(
            [str(launcher)], cwd=scratch, capture_output=True, text=True,
            errors="replace", check=False, env=env, timeout=RETROACTIVE_GATE_TIMEOUT,
        )
    except subprocess.TimeoutExpired:
        # Tagged (`[hook-receipts] COULD_NOT_RUN`): gate_could_not_run reads rc 126/127 or this exact
        # shape. An untagged message with rc 124 was recorded as an ordinary failure, not as an
        # instrument that did not finish.
        return 124, (f"[hook-receipts] COULD_NOT_RUN: the gate suite did not finish within "
                     f"{RETROACTIVE_GATE_TIMEOUT:.0f}s and was killed\n")
    except (OSError, subprocess.SubprocessError) as exc:
        return 127, f"COULD_NOT_RUN: {exc}\n"
    return res.returncode, res.stdout + res.stderr


def _retroactive_precondition(root: Path, sha: str) -> str | None:
    """Why `sha` may NOT be retroactively verified, or None if it may be tried."""
    if len(sha) != _SHA_LEN or any(c not in "0123456789abcdef" for c in sha):
        return (f"{sha!r} is not a full 40-hex commit sha. A prefix or a revision "
                "expression is refused on purpose: the same lock the receipt "
                "baseline uses, so nothing can be named ambiguously.")
    if _git_output(root, ["rev-parse", "--verify", "--quiet", f"{sha}^{{commit}}"]) != sha:
        return f"{sha} is not a commit object in {root}"
    if subprocess.run(["git", "merge-base", "--is-ancestor", sha, "HEAD"],
                      cwd=root, capture_output=True, check=False).returncode != 0:
        return (f"{sha} is not reachable from HEAD. Only history that HEAD "
                "actually carries can be certified; an unreachable commit is "
                "not something `--audit` judges.")
    return None


def verify_historical(root: Path, sha: str) -> int:
    """Re-run the real gate against one historical commit. 0 only if it PASSED.

    Returns 0 when the commit already carries a verification event (nothing to
    do) or when the re-run passed clean; 1 when the re-run refused it; 2 when
    the mechanism itself could not run. Every outcome except "already verified"
    appends an entry to the ledger, so the attempt is as permanent as the
    verdict.
    """
    from simplecode.verification import gate_runner  # local: gate_runner imports THIS module

    sha = sha.strip().lower()
    why_not = _retroactive_precondition(root, sha)
    if why_not is not None:
        print(f"[hook-receipts] COULD_NOT_RUN retroactive verification: {why_not}",
              file=sys.stderr)
        return 2
    already = [e.get("event") for e in atomic_io.read_jsonl(_ledger_path(root))
               if e.get("commit") == sha and e.get("event") in VERIFIED_EVENTS]
    if already:
        print(f"[hook-receipts] {sha[:8]} is already verified in this ledger "
              f"({already[-1]}); nothing re-run, nothing recorded.")
        return 0
    found = _managed_gate_launcher(root)
    if found is None:
        print(f"[hook-receipts] COULD_NOT_RUN retroactive verification: {root} has no "
              f"executable, simplecode-managed `{STAGE_PRE_COMMIT}` hook launcher "
              "(marker `" + _MANAGED_HOOK_MARKER + "`). There is no gate suite to "
              "re-run, so no claim can be made.", file=sys.stderr)
        return 2
    launcher, launcher_sha = found
    holder = Path(tempfile.mkdtemp(prefix="simplecode-retroverify-"))
    scratch = holder / "tree"
    started = time.monotonic()
    try:
        base = _reconstruct_precommit_state(root, sha, scratch)
        if base is None:
            print(f"[hook-receipts] COULD_NOT_RUN retroactive verification of {sha[:8]}: "
                  "could not reconstruct its pre-commit state (a root commit has no "
                  "parent to reconstruct against, and a scratch worktree could not be "
                  "created).", file=sys.stderr)
            return 2
        run = _RetroRun(root, sha, base, launcher, launcher_sha, started)
        staged = _git_output(scratch, ["diff", "--no-relative", "--cached", "--name-only"]) or ""
        staged_paths = [p for p in staged.splitlines() if p.strip()]
        if not staged_paths:
            print(f"[hook-receipts] REFUSED {sha[:8]}: its reconstructed index is EMPTY "
                  "(an empty commit), so the suite would have nothing to measure. A run "
                  "that measures nothing is not a verification.", file=sys.stderr)
            _record_retroactive(run, RETROACTIVE_REFUSED,
                                {"refused_because": "reconstructed staged diff is empty",
                                 "staged_paths": 0})
            return 1
        print(f"[hook-receipts] retroactively gating {sha[:8]} -- {len(staged_paths)} "
              f"staged path(s) reconstructed against parent {base[:8]} in {scratch}; "
              f"running {launcher}")
        rc, output = _run_gate_suite(root, launcher, scratch)
        if output:
            print(output, end="" if output.endswith("\n") else "\n")
        return _judge_retroactive_run(run, rc, output, staged_paths, gate_runner)
    finally:
        _remove_scratch_worktree(root, scratch)
        shutil.rmtree(holder, ignore_errors=True)


@dataclass(frozen=True)
class _RetroRun:
    """What one retroactive verification is ABOUT, carried together.

    These six values travel as a unit through the judge and the ledger entry; passing them
    one by one gave two functions of 10 and 8 parameters (ruff PLR0913).
    """

    root: Path
    sha: str
    base: str
    launcher: Path
    launcher_sha: str
    started: float


def _judge_retroactive_run(run: _RetroRun, rc: int, output: str,
                           staged_paths: list[str], gate_runner: Any) -> int:
    """Turn one suite run into a ledger entry and an exit code, fail-closed.

    Exit 0 is necessary and NOT sufficient, which is the whole point: a suite
    that could not run, or that ran and measured nothing, is refused with the
    same force as one that found a real defect. The tallies print either way.
    """
    sha = run.sha
    passed, failed, skipped = _suite_tallies(output)
    could_not_run = gate_runner.gate_could_not_run(rc, output)
    measurement = {
        "gate_exit_code": rc,
        "gate_output_sha256": hashlib.sha256(output.encode("utf-8")).hexdigest(),
        "checks_passed": passed,
        "checks_failed": failed,
        "checks_did_not_run": skipped,
        "staged_paths": len(staged_paths),
    }
    # Print what did not run beside what did, zeros included -- the count is
    # the only thing that separates "13 checks passed" from "13 checks were
    # skipped and the suite exited 0".
    print(f"[hook-receipts] {sha[:8]} retroactive suite: {passed} passed, {failed} failed, "
          f"{len(skipped)} DID NOT RUN{': ' + ', '.join(skipped) if skipped else ''}; "
          f"could_not_run={int(could_not_run)}; exit {rc}")
    refusal = None
    if could_not_run:
        refusal = "the suite reported COULD_NOT_RUN; an unavailable check is not a pass"
    elif rc != 0:
        refusal = f"the suite exited {rc} ({failed} check(s) Failed)"
    elif passed == 0:
        refusal = ("the suite exited 0 but not one check actually ran; a gate that "
                   "measured nothing cannot certify anything")
    if refusal is not None:
        print(f"[hook-receipts] REFUSED {sha[:8]}: {refusal}. It stays unverified and "
              "keeps blocking --audit --gate.", file=sys.stderr)
        _record_retroactive(run, RETROACTIVE_REFUSED,
                            {**measurement, "refused_because": refusal})
        return 1
    if _record_retroactive(run, VERIFIED_RETROACTIVE, measurement) is None:
        return 2
    print(f"[hook-receipts] {sha[:8]} stamped {VERIFIED_RETROACTIVE}: {passed} check(s) of "
          f"this repo's own {STAGE_PRE_COMMIT} suite re-run against its reconstructed "
          "staged diff, all passed. This is a re-run after the fact, not a receipt that "
          "was written at commit time -- the ledger says so.")
    return 0


def _record_retroactive(run: _RetroRun, event: str,
                        measurement: dict[str, Any]) -> Path | None:
    """Append one retroactive verdict, carrying its whole provenance."""
    root, sha = run.root, run.sha
    details = {
        # Same three keys every other entry in this ledger carries, answered
        # honestly: no nonce was consumed, because no pre-commit ran at commit
        # time. That is the fact this entry exists to work around, not to hide.
        "nonce": None,
        "stage": None,
        "verification_ran": False,
        "head_tree": _git_output(root, ["rev-parse", f"{sha}^{{tree}}"]),
        "staged_fingerprint": _git_output(root, ["rev-parse", f"{sha}^{{tree}}"]),
        "retroactive": True,
        "base_commit": run.base,
        "gate_launcher": str(run.launcher),
        "gate_launcher_sha256": run.launcher_sha,
        "gate_hook_stage": STAGE_PRE_COMMIT,
        "gate_scope": ("this commit's own staged diff against its first parent, "
                       "reconstructed in a throwaway git worktree"),
        "gate_env_stripped": sorted(_STRIPPED_GATE_ENV),
        "ran_by": _operator_identity(root),
        "ran_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "duration_ms": int((time.monotonic() - run.started) * 1000),
        **measurement,
    }
    return record_hook_event(root, event, sha, details)


def _run_verify_historical(root: Path, shas: list[str]) -> int:
    """Every named commit, with a tally that prints the zeros."""
    verdicts: dict[str, int] = {}
    for sha in shas:
        verdicts[sha] = verify_historical(root, sha)
    ok = [s for s, rc in verdicts.items() if rc == 0]
    refused = [s for s, rc in verdicts.items() if rc == 1]
    broken = [s for s, rc in verdicts.items() if rc == 2]
    print(f"[hook-receipts] retroactive verification: {len(shas)} requested, "
          f"{len(ok)} verified, {len(refused)} REFUSED, {len(broken)} COULD_NOT_RUN")
    for label, group in (("REFUSED", refused), ("COULD_NOT_RUN", broken)):
        for sha in group:
            print(f"  🔴 {label}: {sha[:8]}", file=sys.stderr)
    # 2, not 1, when the MECHANISM could not run: a gate that never measured
    # the subject is not the same verdict as one that measured it and refused,
    # and `gate_runner` reads 2 as exactly that distinction. Collapsing them
    # would make a broken instrument indistinguishable from bad content -- the
    # 2026-08-24 failure this kit keeps re-learning.
    if broken:
        return 2
    return 1 if refused else 0


def _retroactive_in_window(root: Path, window_shas: set[str]) -> list[str]:
    """Which audited commits are verified RETROACTIVELY rather than by receipt."""
    found: list[str] = []
    for entry in atomic_io.read_jsonl(_ledger_path(root)):
        commit = entry.get("commit")
        if (entry.get("event") == VERIFIED_RETROACTIVE and isinstance(commit, str)
                and commit in window_shas and commit not in found):
            found.append(commit)
    return found


def run_audit(root: Path, gate: bool) -> int:
    """The `--audit` verdict: 1 when something blocks and `gate` is on, else 0."""
    commits = audit_recent_commits(root)
    unverified = [c for c in commits if not c.get("verified", True)]
    baseline, baseline_note = load_receipt_baseline(root)
    declared = set(baseline.get("entries", {}))
    amnestied, refused, blocking = classify_unverified(unverified, baseline)
    escaped = unverified_outside_window(root, {c["sha"] for c in commits})
    n_declared_escaped = sum(1 for row in escaped if row["sha"].lower() in declared)

    # Every count prints, zeros included: a report that speaks only when it has
    # something to say cannot be told apart from one that was never run.
    print(f"[hook-receipts] Audited {len(commits)} recent commit(s) "
          f"({len(unverified)} unverified: {len(amnestied)} declared, {len(blocking)} blocking).")
    # Same "blocking" count as the line above, unconditional -- covers the
    # clean run (0 blocking) and the FAIL run below alike, at the one point
    # both funnel through.
    emit_hallazgos("[hook-receipts]", len(blocking))
    print(f"[hook-receipts] receipt baseline: {baseline_note}")
    if baseline_note.startswith("COULD_NOT_RUN:"):
        # The tagged, line-anchored twin of the note above: gate_runner's
        # _CNR_MARKER only matches a line that STARTS with `[tag] COULD_NOT_RUN`,
        # and the note above is embedded mid-line after "receipt baseline: ".
        print(f"[hook-receipts] {baseline_note}", file=sys.stderr)
    if baseline.get("reason"):
        print(f"[hook-receipts] baseline reason: {baseline['reason']}")
    for commit, why in amnestied:
        print(f"  🟡 DECLARED, not blocking: {commit['sha'][:8]} - {commit['subject']}\n      {why}")
    for commit, why in refused:
        print(f"  🔴 BASELINE REFUSED: {commit['sha'][:8]} - {commit['subject']}\n      {why}")
    named_refused = {commit["sha"] for commit, _ in refused}
    for commit in blocking:
        if commit["sha"] not in named_refused:
            print(f"  🔴 Unverified commit (missing receipt): {commit['sha'][:8]} - {commit['subject']}")

    # Unconditional, zeros included. A window that is green because somebody
    # re-ran the gates after the fact is not the same fact as a window that
    # was green all along, and whoever reads the verdict has no other way to
    # tell the two apart.
    retro = _retroactive_in_window(root, {c["sha"] for c in commits})
    print(f"[hook-receipts] verified RETROACTIVELY (gate re-run against historical "
          f"content, not a receipt written at commit time): {len(retro)}"
          + (f" -- {', '.join(s[:8] for s in retro)}" if retro else ""))

    print(f"[hook-receipts] unverified commits that left the {AUDIT_WINDOW}-commit window "
          f"without a verdict (reported, NOT blocking): {len(escaped)} "
          f"({n_declared_escaped} of them still named by the baseline)")
    _print_escaped(escaped, declared)

    if blocking and gate:
        first = blocking[0]
        print(
            f"[hook-receipts] FAIL: {len(blocking)} unverified commit(s) missing a "
            f"pre-commit receipt; first {first['sha'][:8]} - {first['subject']}",
            file=sys.stderr,
        )
        return 1
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Audit and record hook verification receipts (WP18/G3)")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--write-receipt", action="store_true", help="Write pre-commit nonce receipt")
    ap.add_argument("--stamp-head", action="store_true", help="Consume receipt and stamp HEAD commit")
    ap.add_argument("--post-commit", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--audit", action="store_true", help="Audit recent commits for unverified bypasses")
    ap.add_argument("--gate", action="store_true", help="Exit 1 if unverified commits found")
    ap.add_argument(
        "--verify-historical", metavar="SHA", action="append", default=[],
        help=("Re-run this repo's OWN pre-commit gate suite against the full 40-hex "
              "commit SHA's reconstructed staged diff, in a throwaway worktree, and "
              "record GIT_VERIFIED_RETROACTIVE only if it passes clean. Repeatable. "
              "Fail-closed: a suite that fails, could not run, or measured nothing "
              "records GIT_RETROACTIVE_REFUSED and the commit keeps blocking."),
    )
    args = ap.parse_args(argv)

    root = args.root.resolve()
    if args.verify_historical:
        return _run_verify_historical(root, args.verify_historical)

    if args.write_receipt:
        nonce = write_receipt(root)
        if nonce:
            print(f"[hook-receipts] Pre-commit nonce written: {nonce[:8]}...")
            return 0
        print("[hook-receipts] COULD_NOT_RUN: receipt could not be written with a valid staged-tree fingerprint")
        return 2

    if args.stamp_head or args.post_commit:
        return _run_stamp_head(root)

    return run_audit(root, args.gate)


def _run_stamp_head(root: Path) -> int:
    """Consume the pre-commit receipt (if any) and stamp HEAD in the ledger.

    Split out of `main` purely to keep `main` itself under the complexity
    gate -- no behavior change from when this lived inline.
    """
    record = _read_receipt_record(root)
    try:
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    except (OSError, subprocess.SubprocessError):
        head = "UNKNOWN"
    nonce = record.get("nonce") if record else None
    verification_ran = isinstance(nonce, str)
    head_tree = head_tree_fingerprint(root)
    # Only consulted when THIS checkout has no fresh receipt of its own --
    # a fast-forward (or other no-op) merge of a worktree-verified branch
    # never re-runs pre-commit here, so without this the tree's real
    # GIT_VERIFIED receipt (written in the worktree's own ledger) would be
    # invisible and every such merge would misreport GIT_NO_VERIFY. See
    # `_find_verified_by_tree` and the DEBT-AEQUITAS-WORKTREE-RECEIPT note
    # on `record_hook_event`.
    inherited = None if verification_ran else _find_verified_by_tree(root, head_tree)
    if verification_ran:
        event = VERIFIED
    elif inherited is not None:
        event = VERIFIED_INHERITED
    else:
        reflog_msg = _git_output(root, ["reflog", "-1", "--format=%gs"]) or ""
        if reflog_msg.startswith("cherry-pick") or reflog_msg.startswith("revert"):
            event = SEQUENCER_NO_HOOK
        else:
            event = NO_VERIFY
    details = {
        "nonce": nonce,
        "stage": record.get("stage") if record else None,
        "staged_fingerprint": record.get("staged_fingerprint") if record else None,
        "head_tree": head_tree,
        "verification_ran": verification_ran,
    }
    if inherited is not None:
        details["inherited_from_worktree"] = inherited.get("worktree")
        details["inherited_from_commit"] = inherited.get("commit")
    if record_hook_event(root, event, head, details) is None:
        return 2
    if event == VERIFIED_INHERITED:
        print(
            f"[hook-receipts] Commit {head[:8]} stamped as verified BY INHERITANCE: "
            f"tree {head_tree} matches a GIT_VERIFIED receipt recorded in worktree "
            f"{details['inherited_from_worktree']} (its commit "
            f"{str(details['inherited_from_commit'])[:8]}). No fresh receipt exists in "
            "this checkout -- this is a content match against a real prior run, not a re-run."
        )
    elif not verification_ran:
        # Reported live (aequitas_os, 2026-09-01): this used to read
        # "(--no-verify detected)" -- neither `git revert` nor `git
        # cherry-pick` even accept a --no-verify flag, and a real,
        # instrumented repro (positive control: a normal `git commit`
        # DOES fire pre-commit) confirmed the actual cause on a
        # conflict-free revert/cherry-pick: git's own sequencer routes
        # straight to post-commit, never through pre-commit, no flag
        # involved at all. This message no longer presumes which of the
        # two happened -- only `--audit --gate` at pre-push (see below)
        # can actually catch either one before it ships.
        print(
            f"[hook-receipts] \033[33mWARNING: commit {head[:8]} has no pre-commit "
            "receipt -- either --no-verify was passed, or it was created via a path "
            "(e.g. a conflict-free git revert/cherry-pick) that git's own sequencer "
            "never routes through pre-commit at all\033[0m"
        )
    else:
        print(f"[hook-receipts] Commit {head[:8]} stamped as verified (staged_fingerprint={details['staged_fingerprint']}, head_tree={details['head_tree']}).")
    # AFTER HEAD's own verdict is on disk, never before: the ancestor walk
    # reads the ledger to decide what is already judged, and HEAD must be in
    # it by then or a merge commit could be offered to the walk as one of its
    # own ancestors' candidates. DEBT-AEQUITAS-MERGE-ANCESTOR-RECEIPT.
    if head != "UNKNOWN":
        _stamp_new_ancestors(root, head)
    return 0


if __name__ == "__main__":
    sys.exit(main())
