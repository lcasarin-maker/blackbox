"""Validate the machine-readable decision that closes a HARVEST task.

Two valid shapes, checked in this order:

1. Closed (`status: done`): the ficha's own recorded decision IS the
   deliverable -- most evaluations conclude DESCARTAR/ya-cubierto with no code
   to write. Valid only with a declared `closure_type` (the same enum
   `genuine_task_closure.py` accepts: void_wontfix/duplicate/
   relocated_prior_verification) and a non-empty `reason`. Checked FIRST
   because `ledger_schema` forbids `accepted` co-existing with `status: done`
   ("una ficha cerrada no tiene nada que aceptar") -- a real closure has
   already had its `accepted` block removed, so falling through to shape 2
   would always read as "sin campo accepted" and reject every genuine close.
2. Open + accepted (`status: open` or absent): the original contract below --
   `accepted.{by,date,trigger}` complete and non-placeholder.

Declared limit: a HARVEST ficha closed by a real substantive code change
(ADOPTAR, implemented in the same commit) with no `closure_type` is not
handled here -- `genuine_task_closure.py` doesn't require one for that case,
but this module would still reject it as "sin closure_type valido". Not built
for because it hasn't happened yet: every closure this repo has produced so
far is a decision-only DESCARTAR/ADAPTAR-deferred with no code to attach a
close_check to. Extend `_closed_decision` if that case arrives for real.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import yaml

from simplecode.utils.closure_types import EXEMPT_CLOSURE_TYPES


DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
REQUIRED = ("by", "date", "trigger")

# Marcadores de "aqui todavia no hay una decision". Hasta el 2026-09-23 se
# rechazaba exactamente UNA cadena, `(pendiente)`, la que Atlas deja al crear
# la ficha -- medido ese dia: `accepted.by="TODO", trigger="TODO"` devolvia
# "accepted completo" con rc=0, o sea que una ficha cuya decision es
# literalmente "TODO" satisfacia su propio close_check. Se compara contra el
# valor ENTERO ya recortado y sin distinguir mayusculas: un trigger real tiene
# decenas de caracteres y no puede colisionar con ninguno de estos.
PLACEHOLDERS = frozenset({
    "(pendiente)", "pendiente", "por decidir", "sin decidir",
    "todo", "tbd", "tba", "fixme", "xxx", "hack",
    "n/a", "na", "none", "null", "nil", "pending", "unknown",
    "-", "--", "?", "??", "...", ".",
})


def _is_placeholder(value: str) -> bool:
    return value.strip().strip("*_`").casefold() in PLACEHOLDERS

_EXEMPT_CLOSURE_TYPES = EXEMPT_CLOSURE_TYPES
_STATUS_RE = re.compile(r'^status:\s*"?([\w-]+)"?\s*$', re.MULTILINE)
_CLOSURE_TYPE_RE = re.compile(r'^closure_type:\s*"?([\w-]+)"?\s*$', re.MULTILINE)
_REASON_RE = re.compile(r'^reason:\s*"?(.+?)"?\s*$', re.MULTILINE)


def _closed_decision(text: str) -> tuple[bool, str] | None:
    """(ok, message) for a `status: done` ficha, or None when `status` isn't
    `done` at all -- the caller falls through to the open+accepted contract."""
    status_match = _STATUS_RE.search(text)
    if status_match is None or status_match.group(1) != "done":
        return None
    type_match = _CLOSURE_TYPE_RE.search(text)
    if type_match is None or type_match.group(1) not in _EXEMPT_CLOSURE_TYPES:
        return False, f"status: done sin closure_type valido {sorted(_EXEMPT_CLOSURE_TYPES)}"
    reason_match = _REASON_RE.search(text)
    reason = reason_match.group(1).strip() if reason_match else ""
    if not reason:
        return False, "closure_type declarado sin reason"
    if _is_placeholder(reason):
        return False, f"reason es un marcador de pendiente: {reason!r}"
    return True, f"cerrada por closure_type={type_match.group(1)}: {reason}"


def check(path: Path) -> tuple[bool, str]:
    if not path.is_file():
        return False, f"no existe: {path}"
    text = path.read_text(encoding="utf-8")
    closed = _closed_decision(text)
    if closed is not None:
        return closed
    match = re.search(r"^accepted:\s*(\{.*\})\s*$", text, re.MULTILINE)
    if not match:
        return False, "sin campo accepted en el frontmatter"
    accepted = yaml.safe_load(match.group(1))
    if not isinstance(accepted, dict):
        return False, "accepted no es un objeto"  # pragma: no cover -- the regex only
        # captures `{...}`, and PyYAML's flow-mapping parser returns a dict or raises
        # for anything brace-delimited (verified: no input makes it a non-dict, no-error)
    for field in REQUIRED:
        value = str(accepted.get(field) or "").strip()
        if not value:
            return False, f"accepted.{field} sigue vacío"
        if _is_placeholder(value):
            return False, f"accepted.{field} sigue en un marcador de pendiente: {value!r}"
    if not DATE_RE.fullmatch(str(accepted["date"])):
        return False, f"accepted.date no es ISO-8601: {accepted['date']!r}"
    return True, "accepted completo"


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        print("uso: python -m simplecode.verification.harvest_decision <ficha>", file=sys.stderr)
        return 2
    ok, message = check(Path(args[0]))
    print(message)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
