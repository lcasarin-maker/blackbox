#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""¿Qué compuerta automática ha corrido, y qué ha atrapado?

`gate_runner` añade una línea JSONL por ejecución. Este informe evalúa las
compuertas propias que los hooks canónicos prometen ejecutar; no presenta
utilidades internas ni comandos manuales como si fueran detectores ausentes.

DOS COSAS QUE ESTE INFORME NO CONFUNDE, porque confundirlas es el defecto:

1. `rc != 0` NO es "captura". Es "bloqueó". Un órgano consultivo informa
   hallazgos y sale 0. Por eso la columna se llama `bloqueos`, no `capturas`, y
   hay una tercera clase -- `sin_senal` -- para el órgano que corre y cuya
   telemetría no distingue "limpio" de "halló y no bloqueó".

2. Un órgano SIN NINGUNA FILA no es un órgano limpio: es un órgano del que no
   sabemos nada. Se imprime aparte y con su cero, nunca omitido.

3. «Ajeno al kit» (pyright, un hook local del satélite) NO es «del kit y no
   gobernado» (un módulo de este kit que el conjunto canónico deja fuera). La
   primera etiqueta describe al sujeto; la segunda describe un hueco de ESTE
   informe. Compartían etiqueta, y por eso el hueco de once órganos --uno de
   ellos este mismo módulo-- no se podía ver leyendo la tabla.
"""

from __future__ import annotations

import argparse
import contextlib
import gzip
import importlib
import io
import json
import math
import re
import sys
from collections import Counter, defaultdict
from collections.abc import Callable
from datetime import date
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any, NamedTuple

from simplecode.utils.gate_signal import emit_hallazgos

TELEMETRIA = Path(".simplecode/evidence/telemetry.jsonl")
PAQUETE = "simplecode"
ORGANOS = ("guards", "verification", "worktree", "utils")
# EL CRITERIO, ESCRITO, porque una lista curada sin criterio es una lista que
# nadie puede auditar. Un organo canonico es UN MODULO DEL KIT QUE LA PLANTILLA
# CANONICA DE SATELITE (`cli_new._pre_commit_config()`) CABLEA A UN HOOK. Ni mas
# --un modulo del kit que ningun hook invoca es una utilidad, no una compuerta--
# ni menos.
#
# Hasta 2026-09-05 esta lista tenia OCHO nombres y la plantilla cableaba
# DIECINUEVE. Los once que faltaban -- clean_worktree, coverage_target,
# gate_effectiveness, hook_receipts, ledger_schema, no_perder_lineas, pii_scan,
# ponytail_debt, ratchet, telemetry_prune, version_bump -- salian en la tabla
# marcados `(no es organo del kit)`, que era literalmente falso, y quedaban
# fuera de la regla de cero capturas. Uno de los once era ESTE MODULO: el organo
# que vigila a los organos se excluia de su propia auditoria. Ningun criterio
# elegia esos ocho y rechazaba coverage_target; era un hueco, no una curaduria.
# Medido: la lista vieja era un subconjunto propio de lo que cablea la plantilla
# (`CANONICAS - cableadas == set()`), asi que no habia una segunda regla en juego.
#
# Se re-deriva con `python -m pytest tests/test_gate_effectiveness.py
# -k plantilla`, que lee la plantilla y falla si esta lista se queda corta.
#
# Los ocho gates que SOLO cablea el `.pre-commit-config.yaml` de la madre
# (artifact_verifier, consumer_shapes, detector_controls, findings_detail_ratchet,
# findings_ratchet, orphan_hunter, red_team, signed_commit) quedan FUERA a
# proposito: no viajan a los satelites, asi que gobernarlos imprimiria
# "nunca se observo" en los 17 satelites donde no estan instalados -- fabricar
# una falsa alarma es el mismo vicio que callar una real. Salen en el informe
# bajo `DEL KIT Y NO GOBERNADOS`, contados y visibles.
# 2026-09-27 (DECISIONS.md): la plantilla dejo de cablear 21 modulos al retirarse del
# pipeline los 37 hooks que la auditoria de gates juzgo APARATO / AVISO / REDUNDANTE
# (backlog_md_freeze, backlog_verifier, claim_guard, clean_worktree,
# close_check_discrimina, detach, finding_backlog, gate_effectiveness,
# genuine_task_closure, hook_receipts, ledger_schema, lockfile_parity, no_perder_lineas,
# ponytail_debt, ratchet, red_team_corpus, staged_mode_guard, sunset_audit,
# telemetry_dispositions, telemetry_prune; version_bump tambien salio ese dia, pero el
# mismo 2026-09-27 volvio al pre-push del kit y no cuenta aqui). Por el criterio de
# arriba salen de esta lista: ningun hook los invoca, asi que ya no son compuertas. Sus filas
# historicas se siguen leyendo -- los ALIAS de abajo se conservan para eso -- y caen en
# el cubo "ya no cableado aqui", que imprime el conteo sin pedir nada.
COMPUERTAS_CANONICAS = frozenset({
    "adversarial_judge",
    "angry_path",
    "corruption_guard",
    "coverage_target",
    "pii_scan",
    "pyright_gate",
    "staged_parity",
    "truncation_guard",
    "zero_debt",
})
# `success_evals` is deliberately ABSENT (DEBT-REDESIGN-10, 2026-08-26): its
# pre-push hook only ever ran a fixed self-evaluation corpus (EVAL_CASES),
# never a real agent report or repository artifact -- 86 runs, 0 catches,
# because there was nothing live for it to catch. Listing it here would
# keep presenting an H2-style self-test as a production consumer whose
# silence looks like health instead of what it is: a meta-check that
# already runs, and is already asserted, inside the ordinary test suite
# (`tests/test_success_evals_behavior.py::test_evaluate_fixtures_meta_eval`).
# The real, subject-judging entry point (`simplecode success-eval <file>`,
# in cli.py) is unaffected -- it is opt-in tooling for judging an actual
# report, not a hook wired to run on every push.
# `test_effectiveness` (DEBT-SPEC8-MUTATION-CI, closed 2026-09-06) is also
# deliberately ABSENT, for a different reason than `success_evals`: it is not
# mute, it runs and it convicts (proven: a scratch project with a weak test
# gets MUTATION GATE FAILED, exit 2; a real test gets exit 0). It is simply
# not a `.pre-commit-config.yaml` hook -- mutating a file replays the WHOLE
# suite once per mutant, measured at ~4 min for one plain run of this repo's
# own suite alone, so it is wired as a WEEKLY scheduled CI job instead
# (`.github/workflows/ci.yml`'s `mutation-testing`, and the same shape in the
# satellite template's `_ci_workflow`), never as a hook `organ_crossings`
# reads from `.pre-commit-config.yaml`. Adding it to COMPUERTAS_CANONICAS
# without a hook entry would make `cross_canonical_organs_are_wired` report
# it unwired forever; adding a hook entry would make every push pay minutes
# of mutation testing it does not need. Its own telemetry lives in the CI
# job's log, not `telemetry.jsonl` -- this report does not see it, by design,
# the same way it does not see `secrets` (gitleaks) or any other CI-only job.
# El nombre del paso en el hook no siempre es el del archivo: `no_dangling`
# corre dangling_refs.py y `semgrep_54` corre semgrep_strict.py. Sin este mapa
# el informe declararía muertos a dos órganos que llevan cientos de corridas.
# Y un paso puede correr MÁS DE UN órgano: acreditar a uno solo dejaba a
# command_guard mudo con 26,332 corridas encima.
ALIAS: dict[str, tuple[str, ...]] = {
    "angry-path": ("angry_path",),
    "corruption-guard": ("corruption_guard",),
    "zero-debt-staged": ("zero_debt",),
    "zero-debt-repo": ("zero_debt",),
    "staged-parity": ("staged_parity",),
    "truncation-guard": ("truncation_guard",),
    "backlog-gate": ("finding_backlog",),
    "backlog-verifier": ("backlog_verifier",),
    "adversarial-judge": ("adversarial_judge",),
    "ship-freeze": ("finding_backlog",),
    "success-evals": ("success_evals",),
    "telemetry-disposition": ("telemetry_dispositions",),
    "no_dangling": ("dangling_refs",),
    "semgrep_54": ("semgrep_strict",),
    "product_ceiling": ("ratchet",),
    "pattern_scan": ("pattern_detectors",),
    # Los cuatro pasos de la PLANTILLA cuyo `--name` no es el nombre del modulo.
    # Sin ellos, meter esos modulos en COMPUERTAS_CANONICAS los declararia
    # "nunca se observo" teniendo decenas de corridas encima: en own_chats,
    # `coverage-100` lleva 30 y `hook-receipts-gate` 16.
    # Dos deletreos del mismo organo, y hacen falta LOS DOS: `coverage-100` es
    # el `--name` que aparece en la telemetria, `coverage-floor` es el `id` del
    # hook que `organ_crossings._wired_organs` lee del `.pre-commit-config.yaml`.
    # Con solo el primero, el cruce declaraba `coverage_target` "canonico y
    # cableado a ningun hook" y `test_this_repo_has_no_undeclared_divergence`
    # fallaba -- el cruce cazando esta misma omision el dia que se escribio.
    "coverage-100": ("coverage_target",),
    "coverage-floor": ("coverage_target",),
    # `pyright` is both the hook `id` and the `--name` gate_runner logs
    # telemetry under (DEBT-SURVEY-GATES-MEASURE-THE-SCAFFOLD); the module
    # the entry actually runs, alongside the real `pyright` binary, is
    # `pyright_gate` (the NOT-EXAMINED confession wrapper). Same shape as
    # `coverage-100`/`coverage-floor` above: without this entry, every real
    # `pyright` telemetry row would credit nothing, and `pyright_gate` would
    # sit in COMPUERTAS_CANONICAS with zero runs recorded under its own name
    # forever -- indistinguishable from never having been wired at all.
    "pyright": ("pyright_gate",),
    # `growth-ratchet` also wires `detach` (DEBT-GATE-RUNNER-PREK-ORPHAN-
    # TELEMETRY-RACE, 2026-09-15): its entry launches the real `ratchet`
    # check through `simplecode.utils.detach` for a genuine session detach.
    # Without `detach` here, `cross_canonical_organs_are_wired` would read it
    # as "canonical and wired to no hook", same shape as the other entries
    # in this map.
    "growth-ratchet": ("ratchet", "detach"),
    "hook-receipts-gate": ("hook_receipts",),
    "lockfile-parity": ("lockfile_parity",),
    "red-team-corpus": ("red_team_corpus",),
    "telemetry-bound": ("telemetry_prune",),
    # Y los de la madre, que no son canonicos pero si son modulos del kit: sin
    # el mapa se marcarian "ajeno al kit", la etiqueta que esta version existe
    # para dejar de mentir.
    "build-dist": ("artifact_verifier",),
    "deadcode-gate": ("orphan_hunter",),
    "gate-controls": ("detector_controls",),
    "ratchet-audit": ("findings_ratchet",),
    "write-hook-receipt": ("hook_receipts",),
    # El paso nombra dos órganos pero el punto de entrada que `settings.json`
    # invoca es un tercero: `guards/pretooluse_guard.py`. Acreditar sólo a los
    # nombrados lo dejaba mudo con 26,000 corridas encima.
    "command_guard+permission_audit": (
        "pretooluse_guard", "command_guard", "permission_audit"),
}
# Pasos que son el hook entero, no un órgano.
AGREGADOS = frozenset({
    # `pre-push-all` stays listed although neither this repo nor the satellite
    # template emits it any more (DEBT-PUSH-LOOP-04, 2026-09-15: `make check`
    # now rehearses the installed launcher instead). Satellites synced before
    # that change still write rows under that name, and a name dropped from
    # this list stops being read at all -- the organ would report zero where
    # there is history. It falls into the "no longer wired here" bucket, which
    # prints the count and says there is nothing to fix.
    "pre-commit", "pre-push", "pre-commit-all", "pre-push-all",
    "PreToolUse", "PostToolUse",
})
MIN_RUNS_WITHOUT_CAPTURE = 10
# SPEC's success metric for the commit lane. Until `gate_runner` wrote
# `duration_ms` this number was a promise nothing measured.
LATENCIA_OBJETIVO_MS = 2000
# The one stage the target governs; every other stage is reported, not judged.
LATENCIA_ETAPA_OBJETIVO = "pre-commit"


@dataclass
class _LineState:
    corridas: dict[str, Counter] = field(default_factory=lambda: defaultdict(Counter))
    repos: dict[str, set] = field(default_factory=lambda: defaultdict(set))
    total: int = 0
    ilegibles: int = 0
    # Complete hook wrappers and their component checks are distinct samples.
    # The latency target applies only to the former.
    duraciones: dict[str, list[int]] = field(default_factory=lambda: defaultdict(list))
    duraciones_pasos: dict[str, list[int]] = field(default_factory=lambda: defaultdict(list))
    # Provenance of the archive read (DEBT-AEQUITAS-08 point 2): even with the
    # gzip archives now included in every count above, the report still SAYS
    # how many it read and how many rows they contributed -- printing the
    # zeros with their procedencia, not just fixing the arithmetic silently.
    archivos_leidos: int = 0
    filas_archivadas: int = 0


@dataclass(frozen=True)
class DashboardData:
    corridas: dict[str, Counter]
    repos: dict[str, set]
    total: int
    ilegibles: int
    organos: set[str]
    modulos: frozenset[str] = frozenset()


def _modulos_del_paquete(paquete: str) -> set[str]:
    """Submodule names of `paquete`, read through its own loader.

    `Path.glob` used to do this and it is the whole defect. In every satellite
    the kit runs from inside `.simplecode/runtime.zip`, so `__file__` names a
    path INSIDE the archive; globbing such a path neither raises nor warns, it
    returns empty. Measured 2026-09-05 against own_chats' runtime.zip, same
    bytes, same minute: `Path.glob` 0 modules from the zip and 71 from the
    package directory, `importlib.resources` 71 from both. The loader is the
    only thing that knows whether the package is a directory or an archive,
    so the loader is what gets asked.
    """
    return {
        entrada.name[:-3]
        for entrada in resources.files(paquete).iterdir()
        if entrada.name.endswith(".py") and entrada.name != "__init__.py"
    }


def modulos_del_kit(kit: Path | None = None) -> set[str]:
    """Every module of the kit's organ subpackages, canonical or not.

    This is the denominator the report needs to tell TWO different things
    apart, which it used to print with the same label:

    * `pyright`, a step that runs somebody else's tool, and
      `coverage-100-NEGCTRL`, a probe a satellite planted by hand -- neither
      is a module of this kit and neither ever will be, so "not an organ of
      the kit" is the truth about them;
    * `gate_effectiveness`, `version_bump`, `hook_receipts` -- modules that
      ARE the kit, wired by the canonical template, and simply absent from
      `COMPUERTAS_CANONICAS`. Calling those "not an organ of the kit" was
      false, and it is the label that kept an eleven-organ hole invisible
      for as long as it existed.

    With no `kit` the package enumerates ITSELF through its loader, which is
    the only mechanism that survives being shipped inside a zip. An explicit
    `kit` path is a caller pointing at a kit laid out on disk, and is read
    with `glob` because that is what a plain directory offers.
    """
    if kit is None:
        return set().union(
            *(_modulos_del_paquete(f"{PAQUETE}.{d}") for d in ORGANOS)
        )
    return {
        p.stem
        for directory in ORGANOS
        for p in (kit / directory).glob("*.py")
        if p.name != "__init__.py"
    }


def organos_del_kit(kit: Path | None = None) -> set[str]:
    """Return canonical custom gates that exist in this kit."""
    return modulos_del_kit(kit) & COMPUERTAS_CANONICAS


def _organos_del_paso(paso: str) -> tuple[str, ...]:
    """Which organ(s) a telemetry step name credits.

    The fallback used to be the step name VERBATIM, and a step name is written
    with hyphens while a module name is written with underscores. So
    `clean-worktree`, `version-bump` and `gate-effectiveness` never met
    `clean_worktree`, `version_bump` and `gate_effectiveness`, and the report
    printed them as steps of their own, outside every verdict.

    MEASURED on own_chats 2026-09-05, and it is the negative control that
    caught it: adding those three modules to `COMPUERTAS_CANONICAS` changed
    NOTHING -- three organs with 28, 28 and 15 runs and zero catches stayed
    unjudged, still labelled foreign, and `--gate` still exited 0 -- because
    the counter had been filed under the hyphenated name all along. `ALIAS`
    hid the shape by spelling out `angry-path`, `corruption-guard` and six
    more one by one; every step with no entry was silently unreachable.

    `organ_crossings._wired_organs` already normalises hook ids this way; this
    is the same rule on the telemetry side, which is why the two now agree.
    """
    return ALIAS.get(paso, (paso.replace("-", "_"),))


_MODULO_EN_ENTRY = re.compile(
    r"simplecode\.(?:" + "|".join(ORGANOS) + r")\.(\w+)"
)

# A satellite may run a REPO-LOCAL fork of a kit organ instead of the kit module:
#     entry: python gates/ledger_schema.py --check
# The module pattern above finds nothing there, so the organ was classified "not
# wired in this repo" -- about a gate running on EVERY commit with
# `always_run: true`.
#
# Reported by the descargaSAT session 2026-09-05, and it is worse than a blind
# spot: this same commit's earlier change made "not wired" NON-BLOCKING, so
# those forks went from wrongly convicted to silently excused. Measured there:
# 4 of the gates that actually execute are repo-local, the effectiveness report
# covered 0 of the 4, and about three of them it asserted the OPPOSITE of the
# truth.
#
# `gate_effectiveness` is the organ whose entire job is catching instruments
# that look at nothing. A false negative here is the failure the negative-control
# rule exists to prevent, and its own closing line -- "una compuerta sin filas es
# una compuerta de la que no sabemos nada" -- was being applied to itself unread.
_SCRIPT_EN_ENTRY = re.compile(r"[\w./-]*?([A-Za-z_]\w*)\.py\b")

# A third fork shape, distinct from both above: `python -m gates.pii_scan`
# (a `-m` module-flag invocation of a repo-local package, not the kit's own
# `simplecode.<pkg>.<mod>` dotted path and not a `.py` script path). Reported
# by aequitas_os 2026-09-06, reproduced against its real
# .pre-commit-config.yaml: `pii_scan`/`no_perder_lineas`/`ledger_schema`
# invoked this way on every commit (68 runs each) read as "not wired here"
# and, worse, non-blocking -- two instruments with 68 runs and zero catches
# stayed invisible to the exact detector built to catch that shape. Takes
# the LAST dotted segment of whatever follows `-m` (`gates.pii_scan` ->
# `pii_scan`), same "the stem must BE a kit organ" guard as `_SCRIPT_EN_ENTRY`
# so an unrelated `-m pytest`/`-m build` never manufactures coverage.
_MODULO_FLAG_EN_ENTRY = re.compile(r"-m\s+(?:[\w]+\.)*(\w+)\b")


def _modulos_cableados(root: Path) -> set[str] | None:
    """Kit modules some hook of THIS repo invokes, or None if unreadable.

    Needed to keep the `sin fila` list from manufacturing the very alarm this
    module exists to denounce. Once the canonical set grew from 8 to 19, a
    satellite that wires 13 of them printed the other 6 as "DEFECTO DEL
    INSTRUMENTO; nunca se observo" -- and a gate that is not installed here has
    no telemetry BY CONSTRUCTION. That is not a blind instrument, it is an
    absent one, and calling it blind is a false positive of exactly the kind
    this report condemns in others. Measured on own_chats 2026-09-05: 6 of the
    9 `sin fila` names were gates own_chats never wired.

    The config's `entry` lines name the module path verbatim
    (`... -- python .simplecode/run.py simplecode.verification.coverage_target`),
    so a regex over the raw text is enough and needs no YAML parser. `None`
    means the file could not be read, which is reported as COULD_NOT_RUN for
    this distinction rather than guessed either way.
    """
    config = root / ".pre-commit-config.yaml"
    try:
        texto = config.read_text(encoding="utf-8")
    except OSError:
        return None
    # Kit-module spelling, plus any repo-local script whose stem names a kit
    # organ. The stem must BE a kit organ: a repo's unrelated `build.py` is not
    # a wired gate, and counting it would manufacture coverage.
    from_module = set(_MODULO_EN_ENTRY.findall(texto))
    kit = modulos_del_kit()
    from_script = {m for m in _SCRIPT_EN_ENTRY.findall(texto) if m in kit}
    from_module_flag = {m for m in _MODULO_FLAG_EN_ENTRY.findall(texto) if m in kit}
    return from_module | from_script | from_module_flag


def _bloqueo(evento: dict) -> bool:
    """Whether this run BLOCKED -- which a run that never started did not.

    126/127 are the shell's "found but not executable" and "command not found".
    The child never ran, so the row is an instrument failure and not a verdict,
    and counting it as a block credits an organ that never looked with a catch.
    Fixed on BOTH sides the same day (declutter, 2026-09-05): the producer had
    already stopped calling it `blocked`, and this reads `rc` before `status`,
    so the producer's fix alone would not have reached here.
    """
    rc = evento.get("rc")
    if isinstance(rc, int):
        return rc != 0 and rc not in (126, 127)
    return evento.get("would_block") is True or evento.get("status") == "blocked"


def _hallazgos(evento: dict) -> int | None:
    """Cuántos hallazgos declaró la corrida, o None si la salida no lo decía.

    None NO es cero. Un órgano cuya salida no declara un número deja el campo
    vacío a propósito: inventarle un cero sería la misma mentira que confundir
    `rc == 0` con "no atrapó".
    """
    n = evento.get("hallazgos")
    return n if isinstance(n, int) else None


def _duracion(evento: dict) -> int | None:
    """Milisegundos medidos por `gate_runner`, o None si la fila no los trae.

    None NO es cero, aquí tampoco: una fila escrita antes de que
    `gate_runner` midiera la duración no vale como "corrió en 0 ms". Se
    cuenta aparte, como `sin_duracion`.
    """
    ms = evento.get("duration_ms")
    if isinstance(ms, bool) or not isinstance(ms, int):
        return None
    return ms


def percentil(muestras: list[int], p: float) -> int:
    """Nearest-rank percentile. `muestras` no vacía."""
    ordenadas = sorted(muestras)
    rango = max(1, min(len(ordenadas), math.ceil(p / 100 * len(ordenadas))))
    return ordenadas[rango - 1]


def _contar(contador: Counter, bloqueo: bool, disposicion: str | None, n: int | None) -> None:
    """Add ONE run of ONE organ to its counters."""
    contador["corridas"] += 1
    if bloqueo:
        contador["bloqueos"] += 1
        if disposicion == "controlled_canary":
            contador["controles"] += 1
        elif disposicion == "false_positive":
            contador["falsos_positivos"] += 1
        else:
            contador["bloqueos_reales"] += 1
    if n is None:
        contador["sin_senal"] += 1
        return
    contador["hallazgos"] += n
    if n > 0 and not bloqueo:
        # A finding reported WITHOUT blocking: the channel an advisory organ
        # (wrapped in `|| true`, "(advisory)" in its name) speaks through.
        contador["hallazgos_consultivos"] += n


def _procesar_linea(linea: str, state: _LineState, disposiciones: dict[str, str] | None = None) -> None:
    """Add one telemetry line to the accumulated state.

    `disposiciones` (DEBT-REDESIGN-09) maps `event_id` -> disposition for
    blocked events a human has since classified. A block disposed as
    `controlled_canary` (an H2 canary that blocked on purpose) counts toward
    `controles`, not `bloqueos_reales` -- an instrument with only planted
    catches on record has proof it fires, which is not the same claim as
    "never caught anything", the thing `sin_capturas` below actually warns
    about.
    """
    state.total += 1
    try:
        e = json.loads(linea)
    except (ValueError, TypeError):
        state.ilegibles += 1
        return

    paso = e.get("check") or e.get("hook") or "?"
    ms = _duracion(e)
    if ms is not None:
        if paso in AGREGADOS:
            state.duraciones[e.get("hook") or paso].append(ms)
        else:
            state.duraciones_pasos[paso].append(ms)
    if paso in AGREGADOS:
        return

    n = _hallazgos(e)
    bloqueo = _bloqueo(e)
    disposicion = (disposiciones or {}).get(e.get("event_id")) if bloqueo else None
    for nombre in _organos_del_paso(paso):
        _contar(state.corridas[nombre], bloqueo, disposicion, n)
        if e.get("repo"):
            state.repos[nombre].add(e["repo"])


def _archivos_del_horizonte(ruta: Path) -> list[Path]:
    """`ruta` plus every gzip archive `telemetry_prune.prune()` wrote beside
    it (`<ledger>.until-<date>.gz`), sorted for a stable read order.

    `telemetry_prune` never deletes: it moves rows older than the horizon
    into these archives ("renombrar, nunca borrar" applied to rows) and
    leaves the live ledger with only what is left. A reader that opens only
    `ruta` sees a strictly smaller population after every prune -- an organ
    with real history reads as never having run, which this report cannot
    tell apart from "actually never ran" without reading the archive too.
    DEBT-AEQUITAS-08 point 2 (reported by declutter 2026-09-14): a
    legitimate `telemetry_prune --apply` left `gate_effectiveness` blocking
    a push over organs it declared blind; restoring 10,575 pruned rows was
    the only way anyone found to get back to rc 0.
    """
    return [ruta, *sorted(ruta.parent.glob(f"{ruta.name}.until-*.gz"))]


def _abrir_texto(ruta: Path) -> contextlib.AbstractContextManager:
    """Open `ruta` for text reading, transparently gzip-aware by suffix."""
    if ruta.suffix == ".gz":
        return gzip.open(ruta, "rt", encoding="utf-8", errors="replace")
    return ruta.open(encoding="utf-8", errors="replace")


def repos_en_el_archivo(ruta: Path) -> Counter:
    """How many rows each `repo` owns across `ruta` and its archives.
    Usually one repo; not always."""
    cuenta: Counter = Counter()
    for fuente in _archivos_del_horizonte(ruta):
        if not fuente.is_file():
            continue
        with _abrir_texto(fuente) as fh:
            for linea in fh:
                if not linea.strip():
                    continue
                try:
                    fila = json.loads(linea)
                except (ValueError, TypeError):
                    continue
                if isinstance(fila, dict) and fila.get("repo"):
                    cuenta[str(fila["repo"])] += 1
    return cuenta


def leer_estado(ruta: Path, disposiciones: dict[str, str] | None = None,
                solo_repo: str | None = None) -> _LineState:
    """Read telemetry rows without inventing signals for absent fields.

    `solo_repo` keeps rows belonging to ONE subject. It exists because a ledger
    can hold another repo's history and nothing said so.

    Measured by the declutter session 2026-09-05, in a file of 7,947 rows:

        rows by `repo`:  simplecode 4371 · declutter 3576
        first 4371 lines of declutter's ledger, sha256 -> 0d524547b34701fc09c3
        first 4371 lines of simplecode's ledger, sha256 -> 0d524547b34701fc09c3

    Byte-identical: a SEED copied once when declutter was adopted as a
    satellite on 2026-08-30, not a leak. Their own 3,576 rows are uncontaminated
    and each row carries the HEAD of the repo that wrote it -- a perfect split,
    no row-level mixing.

    But this reader counted all 7,947, so declutter's report said
    "success_evals: modulo del kit con 86 corridas" about an organ that has run
    there exactly ZERO times. They measured BOTH directions rather than the
    convenient one:

        FALSE EXONERATION (something escapes the blind list on foreign catches)
          total: 0        <- the dangerous direction is clean
        FALSE CONVICTION (crosses the 10-run threshold only on seeded history)
          total: 12       <- four of them with zero local runs

    None bites today, and not by design: all twelve fall outside
    `COMPUERTAS_CANONICAS`. What protects the fleet is the exclusion, not the
    arithmetic. The day one of them joins the canonical set, "10+ runs and zero
    catches is an instrument defect" would judge it on runs that happened in
    another repo.

    The filter applies ONLY when the ledger actually holds more than one repo
    AND the named subject is among them, so a single-repo ledger -- every other
    repo in the fleet, and every fixture in this suite -- reads exactly as
    before. Narrow on purpose: this changes the denominator of a rule that
    blocks pushes, and it should change it in the one case that is measurably
    wrong.
    """
    state = _LineState()
    fuentes = _archivos_del_horizonte(ruta)
    for fuente in fuentes:
        if not fuente.is_file():
            continue
        es_archivo = fuente != ruta
        if es_archivo:
            state.archivos_leidos += 1
        with _abrir_texto(fuente) as fh:
            for linea in fh:
                if not linea.strip():
                    continue
                if solo_repo is not None:
                    try:
                        fila = json.loads(linea)
                    except (ValueError, TypeError):
                        fila = None
                    if isinstance(fila, dict) and fila.get("repo") and str(fila["repo"]) != solo_repo:
                        continue
                _procesar_linea(linea, state, disposiciones)
                if es_archivo:
                    state.filas_archivadas += 1
    return state


def leer(ruta: Path) -> tuple[dict[str, Counter], dict[str, set], int, int]:
    """The historical 4-tuple view of `leer_estado`, kept for its callers."""
    state = leer_estado(ruta)
    return state.corridas, state.repos, state.total, state.ilegibles


def _imprimir_latencia(state: _LineState) -> None:
    """Separate full wrapper durations from component-check durations.

    Se imprime aunque no haya una sola fila con `duration_ms`: una tabla
    vacía dice "no lo estamos midiendo", que es un hecho; omitir la sección
    diría "no hay problema", que es una invención.
    """
    legibles = state.total - state.ilegibles
    con_duracion = sum(len(v) for v in state.duraciones.values()) + sum(
        len(v) for v in state.duraciones_pasos.values()
    )
    print(
        f"\nLATENCIA (objetivo SPEC: < {LATENCIA_OBJETIVO_MS} ms, solo {LATENCIA_ETAPA_OBJETIVO}) -- "
        f"{con_duracion} filas con duracion, {legibles - con_duracion} sin duracion"
    )
    if con_duracion == 0:
        print("  (ninguna fila trae duration_ms: la latencia no esta medida)")
    print("WRAPPER COMPLETO (muestra agregada del hook)")
    print(f"{'stage':30} {'n':>9} {'p95_ms':>9} {'max_ms':>10} {'sobre_objetivo':>15}")
    for hook, muestras in sorted(state.duraciones.items(), key=lambda kv: -len(kv[1])):
        # Solo pre-commit responde al objetivo (SPEC-L291): contar pre-push o manual
        # "sobre objetivo" invita la mala lectura que SPEC.md:74 ya nombra.
        sobre = (sum(1 for ms in muestras if ms > LATENCIA_OBJETIVO_MS)
                 if hook == LATENCIA_ETAPA_OBJETIVO else "n/a (fuera del objetivo)")
        print(
            f"  {hook:30} {len(muestras):>9} {percentil(muestras, 95):>9} "
            f"{max(muestras):>10} {sobre:>15}"
        )
    if not state.duraciones:
        print("  (sin muestras de wrapper completo: p95 no medido)")
    print("PASOS INDIVIDUALES (no representan la duración total del hook)")
    print(f"{'check':30} {'n':>9} {'p95_ms':>9} {'max_ms':>10}")
    for paso, muestras in sorted(state.duraciones_pasos.items(), key=lambda kv: -len(kv[1])):
        print(f"  {paso:30} {len(muestras):>9} {percentil(muestras, 95):>9} {max(muestras):>10}")
    if not state.duraciones_pasos:
        print("  (sin muestras de checks individuales)")


INAPPLICABLE_RELPATH = Path(".simplecode") / "organ_inapplicable.json"

# A cap, not a warning. Broken by the cuenza session 2026-09-05 within an hour
# of shipping: `expires` at 2126-01-01 printed "36277 day(s) left" and turned
# the gate green permanently. Their words, and they are right -- 36277 does not
# read as "forever", it reads as a number, and a reader skims numbers. A
# suspension whose expiry can be set past a human horizon has no expiry.
MAX_DECLARATION_DAYS = 60


def _leer_declaracion(root: Path) -> tuple[dict[str, str], dict[str, str], str]:
    """Organs declared to have NO case they could catch in this subject, plus a note.

    An organ can be mute for three reasons and only one is a defect of the
    instrument:
      (a) BLIND -- a case it should have caught went past it;
      (b) UNWIRED -- no hook invokes it here (already handled: `historicos`);
      (c) INAPPLICABLE -- this repo contains no case it could ever catch.

    Until now (c) was scored as (a). Measured 2026-09-05 by the cuenza session:
    their `version_bump` cannot catch anything because the canon has not fixed
    how the fleet versions, so there is no negative control to run -- not one
    that was skipped. Their pre-push was blocked by a gate measuring nothing
    about them, which is the ship-freeze inversion DEBT-SURVEY-SHIP-FREEZE
    -INCENTIVE-INVERTED already names.

    This is the shape of `could_not_run_baseline.json` on purpose -- owner,
    expiry, named entries -- so the fleet learns one format, not four. Absent,
    malformed or expired all mean NO declarations apply and every mute organ
    blocks again: failing toward blocking is the only direction that keeps an
    expiry honest.

    What stops this from being an amnesty is the refutation in
    `_refutadas` below, not this loader.
    """
    path = root / INAPPLICABLE_RELPATH
    if not path.is_file():
        return {}, {}, f"no {INAPPLICABLE_RELPATH.as_posix()} declared"
    difiere_por_organo: dict[str, str] = {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        expires = date.fromisoformat(str(data["expires"]))
        owner = str(data["owner"]).strip()
        entries = {}
        for k, v in dict(data["entries"]).items():
            reason = str(v["reason"]).strip()
            # `canario` is the key this file used before 8.6.3; accepted so a repo
            # that never migrated it does not lose EVERY declaration to one KeyError
            # (blackbox, 2026-09-26: six declarations dropped, condemned organs 1 -> 6).
            canary = str(v["canary"] if "canary" in v else v["canario"]).strip()
            if not reason or not canary:
                raise ValueError(f"entry {k!r} has an empty `reason` or `canary`")
            # `difiere` is OPTIONAL here and required later, by `_refutadas`,
            # and only for an organ the fleet index shows catching elsewhere.
            # Demanding it unconditionally would make every honest declaration
            # answer a counterexample that does not exist.
            difiere = str(v.get("difiere", "") or "").strip()
            entries[str(k)] = f"{reason} | canary attempted: {canary}" + (
                f" | differs from the fleet because: {difiere}" if difiere else "")
            difiere_por_organo[str(k)] = difiere
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return {}, {}, (
            f"COULD_NOT_RUN: {INAPPLICABLE_RELPATH.as_posix()} is unreadable or "
            f"incomplete ({exc}); it needs `expires`, `owner`, and `entries` "
            f"mapping each organ to an object with `reason` AND `canary`. "
            f"No declaration applies, so every mute organ blocks."
        )
    if not owner or not entries:
        return {}, {}, (
            f"{INAPPLICABLE_RELPATH.as_posix()} declares no owner or no entries; "
            f"none apply"
        )
    if date.today() > expires:
        return {}, {}, (
            f"INAPPLICABLE DECLARATIONS EXPIRED on {expires.isoformat()} "
            f"(owner: {owner}); every organ named there blocks again"
        )
    left = (expires - date.today()).days
    if left > MAX_DECLARATION_DAYS:
        return {}, {}, (
            f"INAPPLICABLE DECLARATIONS REFUSED: `expires` is {expires.isoformat()}, "
            f"{left} day(s) out, over the {MAX_DECLARATION_DAYS}-day cap. An expiry "
            f"past a human horizon is not an expiry. Nothing is excused."
        )
    return entries, difiere_por_organo, (
        f"{len(entries)} organ(s) declared inapplicable, owner {owner}, "
        f"expires {expires.isoformat()} ({left} day(s) left)"
    )



def load_inapplicable(root: Path) -> tuple[dict[str, str], str]:
    """The declared entries and a note. Thin wrapper over `_leer_declaracion`,
    kept because every caller and every test speaks this 2-tuple."""
    entries, _difiere, nota = _leer_declaracion(root)
    return entries, nota


def declared_difiere(root: Path) -> dict[str, str]:
    """Per-organ `difiere` text from the declaration, or {} when none applies."""
    _entries, difiere, _nota = _leer_declaracion(root)
    return difiere


def _refutadas(declared: dict[str, str], corridas: dict,
               fleet: dict[str, list[str]] | None = None,
               difiere: dict[str, str] | None = None) -> list[str]:
    """Declarations the telemetry itself proves false.

    "No case exists here" is a falsifiable claim, and this is what falsifies
    it: an organ that has ever blocked, found something, or caught a planted
    control HAS a case here, whatever the declaration says. Without this the
    file would be a mute switch with a date on it -- the suspension-with-no-
    expiry failure wearing a different hat.
    """
    fleet = fleet or {}
    difiere = difiere or {}
    refutadas = []
    for nombre in sorted(declared):
        c = corridas.get(nombre)
        if c and (c["bloqueos_reales"] or c["hallazgos"] or c["controles"]):
            refutadas.append(
                f"{nombre}: declared inapplicable, but this repo's telemetry "
                f"records bloqueos_reales={c['bloqueos_reales']} "
                f"hallazgos={c['hallazgos']} controles={c['controles']}. "
                f"The declaration is refuted by the subject; delete it."
            )
            continue
        # The half the subject's own telemetry cannot reach. A BLIND organ has
        # zero of all three by definition, so everything above is silent for
        # exactly the class this gate exists to expose -- cuenza broke the
        # first version this way within an hour, declaring `truncation_guard`
        # inapplicable with a reason reading "AFIRMACION FALSA: es el ataque".
        testigos = fleet.get(nombre) or []
        if not testigos:
            continue
        if difiere.get(nombre):
            # Answered. Not refuted -- and deliberately not silenced either:
            # the counterexample prints beside the answer so a reader judges
            # the answer instead of taking it.
            continue
        refutadas.append(
            f"{nombre}: declared inapplicable with no `difiere`, but this organ "
            f"CATCHES in {len(testigos)} other fleet repo(s) -- "
            f"{'; '.join(testigos[:3])}"
            + (f" (+{len(testigos) - 3} more)" if len(testigos) > 3 else "")
            + ". Fleet evidence does not prove a case exists HERE, so this is "
              "not an automatic refutation -- but a bare assertion cannot stand "
              "against a named counterexample. Add `difiere` saying what makes "
              "this repo different, or delete the declaration."
        )
    return refutadas


def _imprimir_no_gobernados(
    no_gobernados: list[str], corridas: dict[str, Counter], organos: set[str],
) -> None:
    """Kit modules with telemetry that `COMPUERTAS_CANONICAS` leaves out.

    Printed ALWAYS, its zero included: a zero here is the claim "every kit
    module with telemetry is governed", which is a measured fact. Omitting the
    section when it is empty would make that claim indistinguishable from a
    version that does not know how to look -- and not knowing how to look is
    what kept eleven ungoverned organs invisible until 2026-09-05.
    """
    print(
        f"\nDEL KIT Y NO GOBERNADOS POR ESTE INFORME: {len(no_gobernados)} "
        f"(de {len(organos)} gobernados)"
    )
    for nombre in no_gobernados:
        print(
            f"  {nombre}: modulo del kit con {corridas[nombre]['corridas']} "
            f"corridas, FUERA de COMPUERTAS_CANONICAS; la regla de cero "
            f"capturas no lo juzga"
        )
    if not no_gobernados:
        print("  (ninguno: todo modulo del kit con filas esta en el conjunto)")


def _imprimir_mudos(mudos: set[str], organos: set[str], root: Path) -> None:
    """Governed organs with no telemetry row at all, split by why.

    "Wired here and never observed" is a defect. "No hook of this repo invokes
    it" is an absence, and calling an absent gate blind manufactures the very
    alarm this module condemns in others. When the config cannot be read the
    two are not distinguished, and that is printed as COULD_NOT_RUN rather
    than guessed either way.
    """
    cableados = _modulos_cableados(root)
    print(f"\nCOMPUERTAS AUTOMATICAS SIN FILA: {len(mudos)} de {len(organos)}")
    if cableados is None:
        print(
            f"  COULD_NOT_RUN: no se pudo leer {root / '.pre-commit-config.yaml'}, "
            "asi que 'cableado y mudo' (defecto) y 'no instalado aqui' (nada que "
            "medir) no se distinguen abajo. Se listan juntos, sin veredicto."
        )
        for nombre in sorted(mudos):
            print(f"    {nombre}: sin fila, y no se pudo saber si esta cableado")
        return
    ciegos = sorted(n for n in mudos if n in cableados)
    ausentes = sorted(n for n in mudos if n not in cableados)
    print(f"  cableados aqui y mudos: {len(ciegos)}")
    for nombre in ciegos:
        # NOT "instrument defect". An organ wired here with ZERO rows is not a
        # gate that fails to catch things -- it is a gate nobody is watching,
        # and the gate has no way to know it is unobserved.
        #
        # agente_inmobiliario, 2026-09-05: three of their 22 hooks ran with
        # `entry: python gates/<x>.py` directly instead of through
        # `gate_runner`. Zero rows out of 1,429. They ran, they passed, they
        # convicted -- and left no trace. The cost was concrete: that same day
        # `ledger_schema` made a real catch (an `evidence` block with three
        # invented keys that no human review had spotted) and the organ that
        # measures catches recorded it as "never observed".
        #
        # The old wording sent them looking inside the gate. The defect was in
        # its wiring, one level out. The report already distinguishes "not
        # wired here"; this is the symmetric case it was missing.
        print(f"    {nombre}: NO OBSERVADO -- este repo lo cablea y no llega "
              f"ni una fila. No es que el organo no cace: es que su `entry:` no "
              f"pasa por `gate_runner`, asi que corre, condena y no deja "
              f"rastro. Envuelvelo y vuelve a medir antes de juzgarlo.")
    print(f"  no cableados en este repo: {len(ausentes)}")
    for nombre in ausentes:
        # The old wording said "sin telemetria por construccion", which is FALSE
        # for an organ that was wired for days, accumulated rows, and was then
        # unwired -- exactly Atlas's `ledger_schema` with 12 runs. Saying a
        # measured thing is unmeasurable is worse than saying nothing.
        print(
            f"    {nombre}: ningun hook de este repo lo invoca hoy, asi que no es "
            f"un instrumento ciego de este repo"
        )


class CouldNotRun(Exception):
    """This report cannot reach its subject, so it says so instead of judging.

    One exception type for the three preflight cases (no ledger file, an empty
    kit organ set, a ledger with not one row of this subject) means rc 2 is
    minted in exactly ONE place -- `main`'s handler -- instead of three scattered
    `return 2`. It exists because the failure this whole module guards against is
    "I could not measure" being filed as "I measured and it is bad": rc 2 and
    rc 1 are different verdicts, and the fourth rc-2 case lives in
    `_rc_del_gate`, which is the only other function allowed to return it.

    The message is printed verbatim to stderr by the handler, leading newline
    included where the original had one.
    """


class Clasificacion(NamedTuple):
    """Why each mute organ is mute -- the three reasons kept apart.

    `sin_capturas` is the only field that reaches rc 1. `historicos` (wired here
    once, not any more) and `inaplicables` (declared to have no case here) are
    PRINTED and never gate; `refutadas` gates separately and harder, because a
    declaration the subject itself contradicts silences an organ that
    demonstrably has work to do. Collapsing any two of these is the defect Atlas
    reported on 2026-09-05, when this gate blocked a push on three organs whose
    own report said they were not blind instruments.
    """

    sin_capturas: list[str]
    historicos: list[str]
    inaplicables: list[str]
    refutadas: list[str]
    declaradas: dict[str, str]
    nota_declaracion: str
    nota_fleet: str
    fleet_testigos: dict[str, list[str]]


def _construir_parser() -> argparse.ArgumentParser:
    """The CLI surface. Separated from `main` so the flag comments -- several of
    them the record of a measured defect in a DEFAULT -- sit together and are not
    read as part of the report logic."""
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."), help="Root for telemetry_dispositions.jsonl (DEBT-REDESIGN-09)")
    # DEFAULT resolved against `--root`, not against the cwd.
    #
    # `TELEMETRIA` is a relative path, so until 2026-09-05 `--root X` reported
    # on X while reading whatever ledger sat under the CURRENT DIRECTORY.
    # Observed by declutter while building a harness for the filter above:
    # their three synthetic cases all read 7,947 events out of declutter's own
    # file and produced identical numbers. They caught it because the three
    # results were the SAME, not because they suspected the harness -- and they
    # reported it as an observation rather than a finding, unsure whether the
    # cwd-relative read was deliberate.
    #
    # It was not. It is the third place today where an instrument answered
    # about a subject other than the one it was handed, after `kit_sha` reading
    # the subject's git and `gate_effectiveness` counting another repo's rows.
    # An explicit `--telemetria` still wins; only the DEFAULT moves, and for
    # every hook in the fleet cwd IS root, so their behaviour is unchanged.
    ap.add_argument("--telemetria", type=Path, default=None)
    ap.add_argument(
        "--kit", type=Path, default=None,
        help="Read organs from this directory instead of from the running package",
    )
    ap.add_argument("--html", type=Path, help="Write HTML dashboard to this file")
    ap.add_argument(
        "--gate", action="store_true",
        help="Exit 1 if any kit organ has run many times and never caught anything",
    )
    return ap


def _preparar(args: argparse.Namespace, raiz: Path) -> tuple[Any, Any]:
    """The kit's organs and this repo's telemetry state, or `CouldNotRun`.

    Every preflight that can end the run without a verdict about the subject
    lives here and nowhere else.
    """
    from simplecode.verification import telemetry_dispositions

    # FIRST PREFLIGHT: there is no ledger to read. Kept here with the other two
    # rather than in `main` so that all three ways this report can fail to reach
    # its subject are in one function and none of them can be dropped while the
    # others are moved -- which is exactly what happened to this one during the
    # split on 2026-09-15: the differential control caught it printing a 51-line
    # report over a repo with no telemetry file at all.
    if not args.telemetria.is_file():
        raise CouldNotRun(f"COULD NOT RUN: no existe {args.telemetria}")

    organos = organos_del_kit(args.kit)
    # THE BRANCH THAT WOULD HAVE DENOUNCED THIS ON DAY ONE. Every verdict
    # below -- `sin_capturas`, `mudos`, the `--gate` exit -- is a filter over
    # `organos`, and a filter over the empty set is empty for free. Empty then
    # prints as "0 instrumentos sin capturas / 0 de 0" and reads as CLEAN. That
    # is exactly how this report ran green in all 17 satellites while the same
    # code, same telemetry, same minute convicted three organs when run from
    # the package directory: `0 de 0` and `0 de 8` are this same program, and
    # the denominator was the only clue, printed where nobody looks at rc=0.
    # An instrument that cannot reach its subject reports that it could not
    # run. It does not report the subject clean.
    if not organos:
        fuente = args.kit if args.kit is not None else f"paquete {PAQUETE}"
        raise CouldNotRun(
            f"COULD_NOT_RUN: el conjunto de organos del kit salio VACIO ({fuente}). "
            "Sin organos no hay nada que filtrar, y un filtro sobre el vacio "
            "siempre sale vacio -- que es indistinguible de limpio. Este "
            "informe no sabe nada sobre ningun organo y no lo va a fingir."
        )

    # telemetry_dispositions.load_dispositions returns the full entry per
    # event_id (state/evidence/source/recorded_at); leer_estado only needs
    # the state string each one resolved to.
    disposiciones = {
        event_id: state
        for event_id, entry in telemetry_dispositions.load_dispositions(raiz).items()
        if isinstance(state := entry.get("state"), str)
    }
    # One subject per report. A ledger holding another repo's history makes
    # every count in this report a sum of two repos, silently -- see
    # `leer_estado`. Applied only when the file really holds more than one repo
    # AND this subject is among them.
    poblacion = repos_en_el_archivo(args.telemetria)
    sujeto = raiz.name
    # THIRD BRANCH: a ledger holding not one row of this subject.
    #
    # Reported by declutter 2026-09-05 after verifying the filter with three
    # synthetic ledgers, and they are right that the first version chose the
    # wrong half of a false dichotomy. I refused to filter to zero events
    # because that would manufacture an ACQUITTAL -- and convicted instead,
    # which manufactures a CONVICTION on evidence in which the subject never
    # appears. Both are verdicts. Neither is what happened.
    #
    # What happened is that there is nothing here to judge, which is
    # COULD_NOT_RUN: "I cannot judge this repo's organs because I have not one
    # run of theirs" is neither "their organs are blind" nor "their organs are
    # fine". Same boundary this kit separated in four other modules today.
    #
    # And it is not a laboratory case: it is the FIRST DAY OF EVERY SATELLITE.
    # declutter's ledger on 2026-08-30 was 100% seed; their first own row is
    # 00:48:28 that day. Any run in that window would have judged their organs
    # on simplecode's entire history and blocked, with rc=1, the push of a repo
    # that had not yet run anything. Their window was short. An adoption
    # prepared on a Friday and started on a Monday is not.
    if poblacion and sujeto not in poblacion:
        raise CouldNotRun(
            f"\n[gate-effectiveness] COULD_NOT_RUN: {args.telemetria} holds "
            f"{sum(poblacion.values())} row(s) and NOT ONE belongs to "
            f"`{sujeto}` (owners: {', '.join(sorted(poblacion))}). This repo's "
            f"organs are neither cleared nor convicted here -- there is "
            f"nothing of theirs to read. A fresh satellite looks exactly like "
            f"this until its first gate runs.")
    solo = sujeto if len(poblacion) > 1 and sujeto in poblacion else None
    state = leer_estado(args.telemetria, disposiciones, solo_repo=solo)
    if solo:
        ajenas = sum(n for r, n in poblacion.items() if r != solo)
        print(f"[gate-effectiveness] AVISO: {args.telemetria} carries "
              f"{ajenas} row(s) belonging to other repo(s) "
              f"({', '.join(sorted(r for r in poblacion if r != solo))}); "
              f"they are EXCLUDED from every count below. They are not deleted "
              f"-- somebody else's history is still history.")
    corridas, repos, total, ilegibles = (
        state.corridas, state.repos, state.total, state.ilegibles,
    )
    return organos, state


def _imprimir_tabla(state: Any, args: argparse.Namespace,
                    organos: Any, modulos: Any) -> None:
    """The per-organ table, plus latency and the kit modules this auditor does
    not govern."""
    corridas, repos, total, ilegibles = (
        state.corridas, state.repos, state.total, state.ilegibles,
    )
    no_gobernados = sorted(
        nombre for nombre in corridas
        if nombre not in organos and nombre in modulos
    )

    horizonte = (
        f", +{state.archivos_leidos} archivo(s) gzip "
        f"({state.filas_archivadas} fila(s) archivada(s) incluida(s))"
        if state.archivos_leidos else ", 0 archivo(s) gzip junto al ledger"
    )
    print(f"EFECTIVIDAD -- {total} eventos, {ilegibles} ilegibles, "
          f"fuente {args.telemetria}{horizonte}")
    print(f"{'organo':30} {'corridas':>9} {'bloqueos':>9} {'hallazgos':>10} "
          f"{'sin_senal':>10}  repos")
    for nombre, c in sorted(corridas.items(), key=lambda kv: -kv[1]["corridas"]):
        if nombre in organos:
            marca = ""
        elif nombre in modulos:
            marca = "  (DEL KIT, NO GOBERNADO)"
        else:
            marca = "  (ajeno al kit)"
        print(f"  {nombre:30} {c['corridas']:>9} {c['bloqueos']:>9} "
              f"{c['hallazgos']:>10} {c['sin_senal']:>10}  {len(repos[nombre])}{marca}")

    _imprimir_latencia(state)

    _imprimir_no_gobernados(no_gobernados, corridas, organos)


def _clasificar(corridas: dict[str, Any], organos: Any, modulos: Any,
                raiz: Path) -> Clasificacion:
    """Sort the mute organs into the three reasons they can be mute.

    Computes only; prints nothing and decides no rc. That separation is the
    point: the reason an organ is excused has to be readable on its own, apart
    from the wording of the report and apart from the exit code.
    """
    mudos_con_corridas = sorted(
        nombre
        for nombre, c in corridas.items()
        if nombre in organos
        and c["corridas"] >= MIN_RUNS_WITHOUT_CAPTURE
        and c["bloqueos_reales"] == 0
        # `hallazgos` used to be a third clause here and has been dropped,
        # because `gate_runner` fabricated it as `int(rc != 0)`: measured
        # 2026-09-05 over the whole file, 0 of 9011 rows had it differ from the
        # block bit, so it was a verbatim copy of `bloqueos` and added nothing.
        # Dropping it also FIXES a case it was getting wrong in the other
        # direction: an organ whose every block was dispositioned
        # `false_positive` has bloqueos_reales == 0 and controles == 0 -- it has
        # never truly caught anything -- yet its non-zero `hallazgos` was
        # letting it out of this list. Now it is condemned, which is right.
        and c["controles"] == 0
        # ...but an ADVISORY organ never blocks by design, so its only way to catch
        # is to report a finding with rc=0. `hallazgos` cannot be brought back as
        # the plain third clause (the false_positive case above), so what counts
        # is the part that is NOT a copy of the block bit: findings reported on a
        # run that did not block. Measured 2026-09-26 over the fleet's telemetry:
        # 226 of 33,865 rows carry a `hallazgos` that differs from the block bit
        # (backlog-verifier 110, telemetry-bound 68, claim-guard 31), so the field
        # is no longer the verbatim copy the 2026-09-05 measurement found. Reported
        # by blackbox: telemetry_prune (`|| true`) had 4 findings and 0 blocks and
        # was condemned for it, and no declaration could be legal.
        and c["hallazgos_consultivos"] == 0
    )
    # Split by WIRING before the verdict. Reported by the Atlas session
    # 2026-09-05, and the defect was visible in this gate's own output: it
    # already printed "cableados aqui y mudos: 0" beside "no cableados en este
    # repo: 3", said in words that the second group is NOT a blind instrument,
    # and then blocked the push on all three. Atlas held 56 commits rather than
    # bypass the gate.
    #
    # Cero capturas ESTANDO CABLEADA is a defect of the instrument: it ran, it
    # was asked, it never answered. Cero capturas because no hook here invokes
    # it any more is history, not a live defect -- there is nothing this repo can
    # fix, and blocking its push buys nothing. Same shape as `finding_backlog`
    # conflating "not evaluated" with "evaluated and clean", in another organ.
    #
    # It is still PRINTED. A gate with no rows is a gate we know nothing about,
    # and that line stays. What changes is only which of the two categories
    # reaches `rc`.
    cableados_ahora = _modulos_cableados(raiz)
    # `_modulos_cableados` recognises ONLY kit modules, by matching
    # `simplecode.<pkg>.<module>` in a hook's `entry`. An organ that is not a kit
    # module -- `ruff`, `gitleaks`, anything from an external repo -- can never
    # appear in that set, so "not in cableados" does NOT mean "not wired" for it.
    #
    # Excusing those would be a far worse bug than the one being fixed: `ruff`
    # with 12 runs and zero catches is a blind instrument and must still block.
    # So the historical branch applies only to names this function COULD have
    # found -- `modulos`, the kit's own module set, already computed above.
    if cableados_ahora is None:
        # Could not read the hook config: wired and unwired are indistinguishable,
        # so fail toward the stricter reading rather than silently excusing them.
        sin_capturas = mudos_con_corridas
        historicos: list[str] = []
    else:
        historicos = [
            n for n in mudos_con_corridas
            if n in modulos and n not in cableados_ahora
        ]
        sin_capturas = [n for n in mudos_con_corridas if n not in historicos]

    # The third reason an organ can be mute: this repo holds no case it could
    # catch. Applied AFTER `historicos` so an unwired organ is never also
    # counted as inapplicable, and printed with its declared reason so the
    # claim can be read and argued with rather than only obeyed.
    declaradas, nota_declaracion = load_inapplicable(raiz)
    # Fleet evidence is only consulted when something is actually declared: a
    # repo with no declaration has no claim to test, and reading the index
    # anyway would print a note about evidence nobody asked for.
    fleet_testigos: dict[str, list[str]] = {}
    nota_fleet = ""
    if declaradas:
        from simplecode.verification import fleet_telemetry

        indice, nota_fleet = fleet_telemetry.cargar(raiz)
        for organo in declaradas:
            fleet_testigos[organo] = fleet_telemetry.capturas_ajenas(
                indice, organo, raiz.name)
    refutadas = _refutadas(declaradas, corridas, fleet_testigos,
                           declared_difiere(raiz))
    inaplicables = [n for n in sin_capturas if n in declaradas and n not in refutadas]
    sin_capturas = [n for n in sin_capturas if n not in inaplicables]
    return Clasificacion(
        sin_capturas=sin_capturas, historicos=historicos, inaplicables=inaplicables,
        refutadas=refutadas, declaradas=declaradas,
        nota_declaracion=nota_declaracion, nota_fleet=nota_fleet,
        fleet_testigos=fleet_testigos,
    )


def _imprimir_procedimiento_control() -> None:
    """How to close a blind-instrument finding, printed beside the finding.

    Its own function because it is 8 statements of pure text with no branch --
    the bulk of what made `main` unreadable -- and because a gate that names a
    defect nobody is told how to fix is a gate that trains its reader to reach
    for SKIP.
    """
    # The PROCEDURE, not just the verdict. Reported by the
    # maletin_homeopatia session 2026-09-05: "es un diagnostico correcto y
    # sin procedimiento -- no encontre donde se documenta plantar un
    # control ni donde se registra", and it blocks their push over the
    # health of the instrument, not over their content, so there is nothing
    # they can improve in their own commits to turn it off. A gate that
    # names a defect nobody is told how to fix is a gate that trains its
    # reader to reach for SKIP.
    #
    # These are the exact steps this session ran twice on 2026-09-05, for
    # growth-ratchet and telemetry_prune.
    print(
        "  COMO SE CIERRA ESTO -- plantar un control es hacer que el organo "
        "dispare a proposito, una vez, y dejarlo registrado:",
    )
    print(
        "    1. Construye un sujeto que DEBA bloquear (arma el marcador, "
        "fabrica el fichero sobre el techo, mete el vicio). Fuera del arbol: "
        "un fixture dentro del repo que se mide es self_polluting_tooling. "
        "PERO el organo tiene que poder ALCANZARLO: si toma su propio "
        "--root, apuntaselo al sujeto. Medido por maletin 2026-09-05 "
        "siguiendo este texto al pie de la letra: truncation_guard rechaza "
        "rutas fuera de su raiz con 'File is outside repository root' y "
        "--gate lo convierte en rc=1, asi que el sujeto SANO tambien "
        "bloqueaba -- un canario falso que se habria registrado como bueno.",
    )
    print(
        "    2. Corre el organo POR gate_runner con su nombre de compuerta, "
        "no a mano -- si no pasa por ahi no deja fila y no cuenta:",
    )
    print(
        "       python -m simplecode.verification.gate_runner --root . "
        "--name <compuerta> --hook manual -- <comando>",
    )
    print(
        "    3. Corre el CONTROL NEGATIVO acto seguido: el mismo comando "
        "sobre un sujeto limpio, que debe salir 0. Sin el, el bloqueo puede "
        "venir de la ruta o del fixture y no del defecto. Este paso es el "
        "que destapo el fallo del paso 1 descrito arriba, y es la unica "
        "razon por la que se vio: si el sujeto sano tambien sale 1, no "
        "tienes un canario, tienes un error de invocacion.",
    )
    print(
        "    4. Registra la fila como control plantado, con la evidencia de "
        "los dos pasos anteriores (se rechaza sin `--evidence`):",
    )
    print(
        "       python -m simplecode.cli telemetry-disposition --root . "
        "--record <event_id> controlled_canary --evidence \"...\"",
    )
    print(
        "    El event_id sale de la fila que escribio el paso 2, en "
        ".simplecode/evidence/telemetry.jsonl.",
    )
    print(
        "    Si el organo NO PUEDE disparar aqui porque no existe el caso, "
        "eso es otra cosa y se declara aparte en "
        f"{INAPPLICABLE_RELPATH.as_posix()} -- no plantes un control falso "
        "para apagar la linea.",
    )


def _imprimir_clasificacion(clas: Clasificacion, corridas: dict[str, Any]) -> None:
    """Print the classification: declarations, then each reason, each labelled
    with whether it gates."""
    _imprimir_declaraciones(clas)
    _imprimir_razones(clas, corridas)


def _imprimir_declaraciones(clas: Clasificacion) -> None:
    """The inapplicability declarations, their residue, and the ones this repo's
    own telemetry refutes.

    Separate from `_imprimir_razones` because a DECLARATION is a claim somebody
    made and this half is where it is read back and, where possible, contradicted
    -- while the other half reports what was measured. The residue paragraph
    below says exactly which half of that job the mechanism cannot do.
    """
    declaradas, nota_declaracion = clas.declaradas, clas.nota_declaracion
    nota_fleet, refutadas = clas.nota_fleet, clas.refutadas
    print(f"\nDECLARACIONES DE INAPLICABILIDAD: {nota_declaracion}")
    if nota_fleet:
        print(f"  {nota_fleet}")
    if declaradas:
        # The residue, printed where it is used rather than buried in a
        # docstring. Measured by the cuenza session 2026-09-05: they declared
        # `truncation_guard` inapplicable with the reason literally reading
        # "AFIRMACION FALSA: es el ataque" and it was accepted, because
        # `_refutadas` reads THIS repo's telemetry and a blind organ has zero
        # blocks, zero findings and zero canaries BY DEFINITION. So the refuter
        # works where it is not needed (a productive organ) and is blind where
        # it is (mould (a)) -- it can catch a declaration that is wrong about a
        # working organ, never one that is wrong about a broken one.
        print(
            "  RESIDUO DECLARADO: la telemetria de ESTE repo no puede refutar "
            "una declaracion falsa sobre un organo CIEGO -- un organo ciego no "
            "tiene bloqueos, hallazgos ni canarios, por definicion. Desde "
            "2026-09-05 esa mitad la cubre la cosecha de flota: si el organo "
            "captura en otros repos, la declaracion tiene que responder con "
            "`difiere` a un contraejemplo CON NOMBRE. LO QUE SIGUE ABIERTO: la "
            "evidencia de flota NO prueba que aqui exista un caso -- "
            "`version_bump` captura en simplecode y de verdad no tiene nada que "
            "capturar en un satelite que no se versiona -- asi que un `difiere` "
            "bien escrito se acepta sin verificarlo. El contraejemplo se imprime "
            "al lado para que el lector juzgue la respuesta en vez de tomarla."
        )
    if refutadas:
        print(f"  DECLARACIONES REFUTADAS POR EL SUJETO: {len(refutadas)}")
        for linea in refutadas:
            print(f"    {linea}")


def _imprimir_razones(clas: Clasificacion, corridas: dict[str, Any]) -> None:
    """The three reasons an organ can be mute, each labelled with whether it
    gates: a measured instrument defect (it does), no case in this repo
    (declared, it does not), no longer wired here (history, it does not)."""
    sin_capturas, historicos = clas.sin_capturas, clas.historicos
    inaplicables, declaradas = clas.inaplicables, clas.declaradas
    fleet_testigos = clas.fleet_testigos
    print(
        f"\nINSTRUMENTOS SIN CAPTURAS TRAS {MIN_RUNS_WITHOUT_CAPTURE}+ CORRIDAS: "
        f"{len(sin_capturas)}"
    )
    for nombre in sin_capturas:
        c = corridas[nombre]
        # "It never fired" and "nothing ever recorded whether it fired" are
        # different verdicts and the reader gets both. Until 2026-09-05 they
        # were indistinguishable here: the producer wrote a fabricated zero
        # into every row, so `sin_senal` -- the class built for exactly this --
        # was 0 for every organ in the fleet and could never fire.
        sin_senal = c.get("sin_senal", 0)
        if sin_senal >= c["corridas"]:
            print(
                f"  {nombre}: DEFECTO DEL INSTRUMENTO; falta una captura medida. "
                f"Ademas ninguna de sus {c['corridas']} corridas declaro un "
                f"numero de hallazgos, asi que 'nunca capturo' y 'nadie midio "
                f"si capturo' no se distinguen aqui -- plantar un control es la "
                f"unica salida que produce el dato."
            )
        else:
            print(f"  {nombre}: DEFECTO DEL INSTRUMENTO; falta una captura medida")
    if sin_capturas:
        _imprimir_procedimiento_control()
    if inaplicables:
        print(
            f"  sin caso posible en este repo (declarado, NO bloquea): "
            f"{len(inaplicables)}"
        )
        for nombre in inaplicables:
            c = corridas[nombre]
            print(
                f"    {nombre}: corrio {c['corridas']} vez/veces sin capturar "
                f"nada porque no hay nada que capturar. Declarado: "
                f"{declaradas[nombre]}"
            )
            # The counterexample prints BESIDE the accepted answer, never
            # instead of it. `difiere` is prose and nothing verifies it, so the
            # reader has to be able to judge the answer against the evidence it
            # is answering -- printing only the answer would be taking its word
            # for it in the one place the mechanism cannot check.
            for testigo in (fleet_testigos.get(nombre) or [])[:3]:
                print(f"      pero CAPTURA en {testigo}")
    if historicos:
        print(
            f"  ya no cableados aqui (historico, NO bloquea): {len(historicos)}"
        )
        for nombre in historicos:
            c = corridas[nombre]
            print(
                f"    {nombre}: corrio {c['corridas']} vez/veces en este repo sin "
                f"capturar nada, y hoy ningun hook lo invoca. El dato se conserva; "
                f"no hay nada que arreglar aqui."
            )

    # DEBT-REDESIGN-09: a blocked event a human has since disposed as a
    # deliberately planted control (or a false alarm) is not production
    # signal -- printed separately from confirmed/undisposed so neither
    # category can hide inside the other.
    # DEBT-PUSH-LOOP-03 (2026-09-15): `build_report` now RAISES when the cutoff
    # is undeclared or malformed, because a gate must not write a tracked file
    # to make itself runnable. This organ reads that report, so it inherits the
    # condition -- and an uncaught exception here would print a traceback where
    # the reader expects a verdict, which is the same defect in the neighbouring
    # organ that ticket fixed in `telemetry_dispositions`. Measured: 27 tests
    # went red this way the moment the exception existed.


def _imprimir_disposiciones(raiz: Path, telemetria: Path) -> str:
    """Print the disposition summary and return the cutoff COULD_NOT_RUN reason
    (empty string when the report could be computed).

    The returned string is what `_rc_del_gate` reads to choose rc 2 over rc 0,
    so it must stay a REASON and never a boolean: the reader is told why.
    """
    from simplecode.verification import telemetry_dispositions

    cutoff_could_not_run = ""
    try:
        disposicion_reporte = telemetry_dispositions.build_report(
            raiz, telemetry_path=telemetria
        )
    except (telemetry_dispositions.CutoffUndeclared,
            telemetry_dispositions.CutoffMalformed) as exc:
        cutoff_could_not_run = str(exc)
        disposicion_reporte = telemetry_dispositions.DispositionReport()
    counts = disposicion_reporte.counts
    # legacy_migrated (identified as a pre-event_id row, but no state
    # recorded yet) folds into "sin_disponer" for this line -- it is a
    # `telemetry_dispositions`-only bucket, still undecided either way,
    # not a fourth outcome this summary needs to distinguish.
    # `same_run` is deliberately NOT in this sum: it counts rows the push
    # currently executing produced itself, which nobody could have judged yet
    # and which `build_report` already exempts from gating. Folding them into
    # "sin_disponer" would print a backlog that empties by itself on the next
    # run -- noise that trains the reader to ignore the number.
    sin_disponer = counts.get("could_not_dispose", 0) + counts.get("legacy_migrated", 0)
    if cutoff_could_not_run:
        print(
            "\nDISPOSICION DE BLOQUEOS -- COULD_NOT_RUN: "
            f"{cutoff_could_not_run}"
        )
    else:
        print(
            "\nDISPOSICION DE BLOQUEOS -- "
            f"confirmados: {counts.get('confirmed_defect', 0)} · "
            f"falsos_positivos: {counts.get('false_positive', 0)} · "
            f"controles_plantados: {counts.get('controlled_canary', 0)} · "
            f"sin_disponer: {sin_disponer}"
        )
    return cutoff_could_not_run


def _imprimir_cierre(organos: Any, corridas: dict[str, Any], root: Path) -> None:
    """The organs with no rows at all, and the two standing caveats about
    reading this report."""
    _imprimir_mudos(set(organos) - set(corridas), organos, root)
    print("\nUna compuerta sin filas es una compuerta de la que no sabemos nada.")
    print("Y 'bloqueos' no es 'capturas': una compuerta consultiva")
    print("informa hallazgos con rc=0 -- ver la columna sin_senal.")
    # The gate that watches the gates. The standing law already says a gate with
    # many runs and zero catches is a defect in the instrument, never evidence of
    # a clean subject -- this report has printed that list for a while and
    # nothing acted on it. Eighteen blind instruments surfaced across four repos
    # on 2026-09-01, several of which had been green for weeks: two probes that
    # approved by grepping for a keyword, an H1 ledger that accepted empty
    # evidence, three semgrep rules blind since the day they were written, a
    # sunset audit that could not fire, a backlog gate that never opened the
    # files it counted. None of them was caught by a gate; all were caught by a
    # human or an adversarial panel.
    #
    # HONEST LIMIT: this only sees mould (b)/(d) of the Atlas taxonomy -- an
    # instrument that cannot reach its subject or cancels itself leaves zero
    # catches here. Mould (c), two organs measuring the same thing and diverging
    # while both stay green, is invisible to a per-organ counter; the only
    # instance closed so far (template vs config) needed its own crossing test.
    # A report with could_not_run > 0 is not a clean report, however many rows
    # pass -- but it is also not a verdict about the subject. So it gates, and
    # it gates with rc 2 (COULD_NOT_RUN), while a real finding below keeps rc 1:
    # the two must stay distinguishable, or "I could not judge" gets filed as
    # "I judged and it is bad". Checked LAST so the findings print first when
    # both apply, and the stronger statement about the subject wins the rc.


def _rc_del_gate(gate: bool, cutoff_could_not_run: str,
                 refutadas: list[str], sin_capturas: list[str]) -> int:
    """The verdict, and the only place rc 1 and rc 2 are chosen.

    rc 2 means "this report could not be computed"; rc 1 means "the instruments
    have a measured defect"; rc 0 means neither. A change that lets one of the
    first two answer for the other turns "I could not judge" into "I judged and
    it is bad", which is the exact inversion this module exists to prevent --
    so this is a function with a name and a signature, callable from a test
    without a ledger on disk, rather than four trailing `if`s in a 120-statement
    `main`.
    """
    if gate and cutoff_could_not_run and not (refutadas or sin_capturas):
        print(
            "\n[gate-effectiveness] COULD_NOT_RUN: the disposition half of this "
            "report could not be computed, so this is not a clean report."
        )
        return 2
    if gate and refutadas:
        print(
            f"\n[gate-effectiveness] NOT CLEAN: {len(refutadas)} inapplicability "
            f"declaration(s) contradicted by this repo's own telemetry. A "
            f"declaration the subject refutes is worse than no declaration: it "
            f"silences an organ that demonstrably has work to do here.",
        )
        return 1
    if gate and sin_capturas:
        print(
            f"\n[gate-effectiveness] NOT CLEAN: {len(sin_capturas)} organ(s) with "
            f"{MIN_RUNS_WITHOUT_CAPTURE}+ runs and zero catches. That is a "
            f"statement about the instrument, not about this repo.",
        )
        return 1
    return 0


def main(argv: list[str]) -> int:
    args = _construir_parser().parse_args(argv)
    if args.telemetria is None:
        args.telemetria = args.root / TELEMETRIA
    raiz = args.root.resolve()
    try:
        organos, state = _preparar(args, raiz)
    except CouldNotRun as exc:
        print(exc, file=sys.stderr)
        return 2

    modulos = modulos_del_kit(args.kit)
    if args.html:
        data = DashboardData(
            state.corridas, state.repos, state.total, state.ilegibles, organos,
            frozenset(modulos),
        )
        _write_html_dashboard(args.html, data)
        print(f"HTML dashboard written to {args.html}")
        return 0

    # TRES clases, no dos. La version anterior imprimia una sola etiqueta,
    # `(no es organo del kit)`, para dos hechos incompatibles: una compuerta
    # ajena y un modulo del propio kit que este auditor no gobierna. Con una
    # etiqueta comun el segundo caso -- el hueco del auditor -- no se puede ver
    # leyendo el informe, y no se vio durante los once organos que faltaban.
    _imprimir_tabla(state, args, organos, modulos)
    clas = _clasificar(state.corridas, organos, modulos, raiz)
    # Both kinds of finding this gate can report in one run -- refuted
    # inapplicability declarations, and organs with zero real catches -- are
    # NOT mutually exclusive (the rc picks refutadas first when both fire, see
    # `_rc_del_gate`, but sin_capturas is a real finding too), so both are
    # summed into the one count `emit_hallazgos` declares. This point is
    # reached on every completed classification: the early `CouldNotRun`
    # (nothing measured yet) and the `--html` branch (returns before `clas`
    # exists) are both excluded by construction, and this fires whether or
    # not `--gate` was passed -- exactly the advisory-gate case (exit 0,
    # findings > 0) this mechanism exists to make visible.
    emit_hallazgos("[gate-effectiveness]", len(clas.refutadas) + len(clas.sin_capturas))
    _imprimir_clasificacion(clas, state.corridas)
    cutoff_could_not_run = _imprimir_disposiciones(raiz, args.telemetria)
    _imprimir_cierre(organos, state.corridas, args.root)
    return _rc_del_gate(args.gate, cutoff_could_not_run,
                        clas.refutadas, clas.sin_capturas)


def _write_html_dashboard(
    output: Path,
    data: DashboardData,
) -> None:
    """Write HTML dashboard with table and summary cards."""
    corridas = data.corridas
    repos = data.repos
    total = data.total
    ilegibles = data.ilegibles
    organos = data.organos
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>simplecode Gate Effectiveness Dashboard</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 2rem; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; border-bottom: 2px solid #007bff; padding-bottom: 0.5rem; }}
        .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 1.5rem 0; }}
        .card {{ background: #f8f9fa; padding: 1.5rem; border-radius: 6px; border-left: 4px solid #007bff; }}
        .card h3 {{ margin: 0 0 0.5rem 0; font-size: 0.9rem; color: #666; text-transform: uppercase; }}
        .card .value {{ font-size: 2rem; font-weight: bold; color: #333; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 1rem; }}
        th, td {{ padding: 0.75rem; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #f8f9fa; font-weight: 600; }}
        tr:hover {{ background: #f8f9fa; }}
        .badge {{ display: inline-block; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: bold; }}
        .badge-armed {{ background: #d4edda; color: #155724; }}
        .badge-advisory {{ background: #fff3cd; color: #856404; }}
        .badge-missing {{ background: #f8d7da; color: #721c24; }}
        .corridas {{ text-align: right; }}
        .bloqueos {{ text-align: right; color: #dc3545; font-weight: bold; }}
        .hallazgos {{ text-align: right; color: #28a745; }}
        .sin-senal {{ text-align: right; color: #6c757d; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>simplecode Gate Effectiveness Dashboard</h1>
        <div class="summary">
            <div class="card"><h3>Total Events</h3><div class="value">{total}</div></div>
            <div class="card"><h3>Unreadable Lines</h3><div class="value">{ilegibles}</div></div>
            <div class="card"><h3>Organs Tracked</h3><div class="value">{len(organos)}</div></div>
            <div class="card"><h3>Organs with Rows</h3><div class="value">{len([v for v in corridas.values() if v['corridas'] > 0])}</div></div>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Organ</th>
                    <th class="corridas">Runs</th>
                    <th class="bloqueos">Blocks</th>
                    <th class="hallazgos">Findings</th>
                    <th class="sin-senal">No Signal</th>
                    <th>Repos</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
"""
    for nombre, c in sorted(corridas.items(), key=lambda kv: -kv[1]["corridas"]):
        if nombre in organos:
            status_class, status_text = "badge-armed", "organ"
        elif nombre in data.modulos:
            status_class, status_text = "badge-advisory", "kit module, ungoverned"
        else:
            status_class, status_text = "badge-missing", "foreign to the kit"
        html += f"""                <tr>
                    <td><strong>{nombre}</strong></td>
                    <td class="corridas">{c['corridas']}</td>
                    <td class="bloqueos">{c['bloqueos']}</td>
                    <td class="hallazgos">{c['hallazgos']}</td>
                    <td class="sin-senal">{c['sin_senal']}</td>
                    <td>{len(repos[nombre])}</td>
                    <td><span class="badge {status_class}">{status_text}</span></td>
                </tr>
"""
    html += """            </tbody>
        </table>
    </div>
    <script>
        // Add sorting on click
        document.querySelectorAll('th').forEach((th, i) => {
            th.style.cursor = 'pointer';
            th.addEventListener('click', () => sortTable(i));
        });
        function sortTable(col) {
            const table = document.querySelector('table');
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const isNumeric = col >= 1 && col <= 5;
            const asc = !table.dataset.sortAsc || table.dataset.sortCol != col;
            rows.sort((a, b) => {
                const aVal = a.cells[col].textContent.trim();
                const bVal = b.cells[col].textContent.trim();
                const cmp = isNumeric ? parseFloat(aVal) - parseFloat(bVal) : aVal.localeCompare(bVal);
                return asc ? cmp : -cmp;
            });
            table.dataset.sortAsc = asc;
            table.dataset.sortCol = col;
            rows.forEach(r => tbody.appendChild(r));
        }
    </script>
</body>
</html>"""
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding="utf-8")


# ---------------------------------------------------------------------------
# DEBT-SURVEY-VERDICT-AND-RC-DIVERGE (2026-09-05): permanent verdict/rc parity
# ---------------------------------------------------------------------------
# Diagnostic (Atlas), the structural cause a sweep of five separate one-off
# fixes had been missing: "no es un bug de tres organos: la salida legible y
# el rc se escriben en sitios distintos y nada los ata." A manual sweep
# (printed word vs rc, per organ, against a subject built to convict) found 0
# divergences across 8 organs on 2026-09-05 -- but a sweep run once by hand is
# a MEASUREMENT, not a mechanism (own_chats: "vale mas que arreglarlos de uno
# en uno, porque volveran"). This is that mechanism.
#
# Two things a naive version of this gets wrong, both caught building it:
# 1. A per-test blocking-word list drifts from the organs' real vocabulary --
#    the ticket's OWN first sweep flagged finding_backlog as divergent because
#    its list never included COULD_NOT_RUN, which IS a blocking verdict. One
#    shared list closes that: every check here reads BLOCKING_WORDS, nothing
#    invents its own.
# 2. Comparing against telemetry (like the rest of this module does) answers
#    "did a PAST run's word match its PAST rc" -- it cannot prove a CURRENT
#    subject drives both. Every check below builds a real condemning subject
#    and actually invokes the organ against it in-process, capturing both
#    streams (corruption_guard prints to stderr, the rest to stdout).
#
# NOT COMPLETE, the same stance organ_crossings.py takes and for the same
# reason: there is no enumeration of "every organ" to check completeness
# against, so this proves only that every REGISTERED organ's word and rc
# agree -- extending it costs the ten lines one entry takes, not a redesign.

BLOCKING_WORDS = ("BLOCKED", "COULD_NOT_RUN", "FRAUD", "FAIL")


def says_blocks(output: str) -> bool:
    """True when an organ's own printed output claims a block: any of the
    shared BLOCKING_WORDS appearing anywhere in it. Case-sensitive -- these
    are organs' own literal tokens (FAIL, BLOCKED, ...), not prose that
    happens to contain them (ADVISORY never contains a bare one)."""
    return any(word in output for word in BLOCKING_WORDS)


@dataclass(frozen=True)
class VerdictParityResult:
    organ: str
    verdict: str  # AGREE / DIVERGE
    detail: str


@dataclass(frozen=True)
class VerdictParityCheck:
    """One organ's condemning fixture, plus how to invoke it against it."""

    organ: str
    build_subject: Callable[[Path], list[str]]  # writes the subject, returns argv (minus --root)
    module: str


def _invoke(module: str, argv: list[str]) -> tuple[str, int]:
    """Import `module` and run its real `main(argv)` in-process, capturing
    BOTH streams -- real execution against a real subject, never a mock of
    the outcome under test."""
    mod = importlib.import_module(module)
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        rc = mod.main(argv)
    return out.getvalue() + err.getvalue(), rc


def _zero_debt_subject(root: Path) -> list[str]:
    """`zero_debt.tracked_python` reads `git ls-files` -- an untracked file in
    a non-git directory scans as an empty set (0 findings, rc=0), which would
    silently pass as "AGREE" for the wrong reason (nothing was scanned, not
    "the subject is clean"). A real git repo with the finding committed is
    what actually exercises the organ's conviction path."""
    import subprocess
    subprocess.run(["git", "init", "-q"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.email", "t@t.t"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=root, check=True)
    (root / "debt.py").write_text('def f():\n    return eval("1+1")\n', encoding="utf-8")
    subprocess.run(["git", "add", "-A"], cwd=root, check=True)
    subprocess.run(["git", "commit", "-q", "-m", "subject"], cwd=root, check=True)
    return ["--root", str(root), "--mode", "zero", "--gate"]


def _angry_path_subject(root: Path) -> list[str]:
    bad = root / "bad.py"
    bad.write_text(
        "def f():\n    try:\n        x = 1\n    except (ValueError, Exception):\n        pass\n",
        encoding="utf-8",
    )
    return ["--root", str(root), str(bad), "--gate"]


def _corruption_guard_subject(root: Path) -> list[str]:
    corrupt = root / "corrupt.txt"
    corrupt.write_bytes(b"hola\x00mundo")
    return [str(corrupt)]


VERDICT_PARITY_CHECKS: tuple[VerdictParityCheck, ...] = (
    VerdictParityCheck("zero_debt", _zero_debt_subject, "simplecode.worktree.zero_debt"),
    VerdictParityCheck("angry_path", _angry_path_subject, "simplecode.guards.angry_path"),
    VerdictParityCheck("corruption_guard", _corruption_guard_subject, "simplecode.guards.corruption_guard"),
)


def check_verdict_parity(root: Path) -> list[VerdictParityResult]:
    """Run every registered :data:`VERDICT_PARITY_CHECKS` entry against a
    fresh condemning subject built under ``root``, and report whether the
    printed word and the exit code agree on "this must block".

    ``root`` must be an empty, disposable directory (each check writes its
    own subject file into it) -- callers pass a fresh ``tmp_path``, never a
    real repo.
    """
    results: list[VerdictParityResult] = []
    for check in VERDICT_PARITY_CHECKS:
        argv = check.build_subject(root)
        output, rc = _invoke(check.module, argv)
        word_blocks = says_blocks(output)
        rc_blocks = rc != 0
        if word_blocks == rc_blocks:
            results.append(VerdictParityResult(check.organ, "AGREE", f"word={word_blocks} rc={rc}"))
        else:
            results.append(VerdictParityResult(
                check.organ, "DIVERGE",
                f"printed output {'claims' if word_blocks else 'does not claim'} a block "
                f"(BLOCKING_WORDS) but rc={rc}",
            ))
    return results


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
