"""Repara el corpus de fichas contra el esquema del canon, sin inventar un campo.

Existe porque el 2026-09-03 el gate `ledger_schema` bloqueaba CADA commit de 16 de
18 repos con 1,306 fichas invalidas, y porque repararlas a mano repo por repo es
como se pierde el rastro de que se cambio y por que. Lo que este modulo hace es
exactamente lo que se hizo a mano en `simplecode` ese dia, con las mismas guardas.

La linea que lo gobierna: **repara lo derivable, DECLARA lo que no.** Tres clases
se arreglan porque su arreglo es un hecho comprobable; tres se cuentan y se
imprimen porque arreglarlas seria escribir algo que nadie midio.

REPARA
  duplicados  Dos archivos con el mismo `id` tras la migracion del canon. Se borra
              el original SOLO si el sucesor lo cita por nombre Y no pierde una
              linea de cuerpo. Las dos condiciones, no una.
  punteros    `ledger/evidence/...` quedo huerfano cuando el canon retiro `ledger/`
              el 2026-09-02. Se reescribe a `tasks/evidence/...` SOLO si el destino
              existe en disco.
  sin_prueba  Cerrada como `done` sin `evidence`. No se le fabrica la triada: pasa
              a `done_unverified`, el tercer estado, con una razon DERIVADA de lo
              que la ficha trae. Solo si nacio antes del contrato.

DECLARA (y no toca)
  cmd_vacio   `close_check.cmd` vacio. Quien no puede enunciar como se sabria que
              esta resuelta no entendio el defecto; inventarle un comando seria
              ponerle palabras en la boca.
  falta_campo Campos obligatorios ausentes que no se derivan de ningun hecho.
  titulo      Titulo por encima del maximo. Recortarlo es editar la frase de una
              persona, y eso lo decide esa persona.

Uso:
    python -m simplecode.verification.canon_repair --root .            # solo mide
    python -m simplecode.verification.canon_repair --root . --apply    # escribe

Simplificado el 2026-09-04: hasta entonces cargaba `gates/ledger_schema.py` del propio repo
via `importlib` + `setattr(mod, "ROOT", root)`, porque cada satelite tenia su PROPIA copia
del gate (y podia haber divergido en un fork -- de ahi `fork_state()`, que RePic pidio tras
encontrar tres forks que una medicion anterior habia declarado limpios sin poder verlo). Con
`ledger_schema` migrado a `simplecode.verification` (runtime.zip), ya no hay copia local que
cargar ni fork posible: este modulo importa el esquema canonico directo, y "reparar contra el
canon" deja de necesitar averiguar primero SI el repo tiene el canon -- lo tiene, porque lo
trae el propio paquete que esta corriendo.
"""

from __future__ import annotations

import argparse
import re

from simplecode.utils import atomic_io
from simplecode.verification import ledger_schema as esquema
from collections import Counter
from pathlib import Path

# DERIVADAS del esquema desde el 2026-09-29, no copiadas. Este modulo repara lo que
# `ledger_schema` bloquea, asi que su pregunta es la misma -- ¿que fichas juzga el esquema? --
# y hasta ese dia la contestaba con dos literales propios. Cuando el esquema empezo a
# gobernar `roadmap/` (Atlas DGX-619), una ficha de roadmap con esquema invalido habria
# quedado bloqueada por el gate e invisible para su reparador: el molde (c) que
# `no_perder_lineas` ya habia cerrado derivando. Medido sobre la flota antes/despues: en
# los 16 repos sin `tasks/roadmap/` las cifras son identicas, y en Atlas solo sube
# `avisos_no_bloqueantes` 129 -> 135 (los 6 titulos largos de roadmap); 0 reparables nuevos.
OMITIR = esquema.OMITIR
GOBERNADAS = esquema.GOBERNADAS
PUNTERO_VIEJO = "ledger/evidence/"
PUNTERO_NUEVO = "tasks/evidence/"


def fichas(root: Path) -> list[Path]:
    return sorted(p for c in GOBERNADAS for p in (root / "tasks" / c).glob("*.md")
                  if p.name not in OMITIR)


def _cuerpo(texto: str) -> str:
    return texto.split("---", 2)[-1]


def duplicados(root: Path) -> list[tuple[Path, Path]]:
    """(original_a_borrar, sucesor) para cada id con dos archivos, si es seguro.

    Seguro = el sucesor CITA al original por nombre y no pierde una sola linea de
    su cuerpo. Una condicion sola no basta: citarlo sin conservarlo borra prosa, y
    conservarlo sin citarlo puede ser una ficha distinta que reuso el id.
    """
    por_id: dict[str, list[Path]] = {}
    for p in fichas(root):
        m = re.search(r"^id:\s*(\S+)", p.read_text(encoding="utf-8", errors="replace"), re.M)
        if m:
            por_id.setdefault(m.group(1), []).append(p)
    pares: list[tuple[Path, Path]] = []
    for ident, grupo in sorted(por_id.items()):
        if len(grupo) != 2:
            continue
        canon = [p for p in grupo if p.stem == ident]
        viejo = [p for p in grupo if p.stem != ident]
        if len(canon) != 1 or len(viejo) != 1:
            continue
        nuevo, original = canon[0], viejo[0]
        texto_nuevo = nuevo.read_text(encoding="utf-8", errors="replace")
        if original.name not in texto_nuevo:
            continue
        cn = _cuerpo(texto_nuevo)
        perdidas = [ln for ln in _cuerpo(original.read_text(encoding="utf-8", errors="replace")
                                         ).splitlines() if ln.strip() and ln not in cn]
        if not perdidas:
            pares.append((original, nuevo))
    return pares


def punteros_rotos(root: Path) -> list[Path]:
    """Archivos con punteros al arbol retirado cuyo destino SI existe bajo tasks/."""
    afectados = []
    for p in list((root / "tasks").rglob("*.md")):
        t = p.read_text(encoding="utf-8", errors="replace")
        objetivos = re.findall(re.escape(PUNTERO_VIEJO) + r"[A-Za-z0-9._-]+\.txt", t)
        if objetivos and all((root / PUNTERO_NUEVO / Path(o).name).is_file() for o in objetivos):
            afectados.append(p)
    return afectados


def razon_derivada(texto: str) -> str:
    """La razon sale de lo que la ficha TRAE, no de una plantilla estampada.

    Un solo texto para todas seria una etiqueta larga. Las dos ramas se distinguen
    por un hecho comprobable en el propio archivo: si declaro como se comprobaria.
    """
    tiene_cmd = bool(re.search(r"^(close_check|verification_command):", texto, re.M))
    if tiene_cmd:
        return ("cerrada antes de que el contrato de evidencia existiera. Declara como se "
                "comprobaria, pero nadie guardo la corrida negativa, y reconstruirla hoy "
                "contra un codigo que ya cambio seria fabricarla, no medirla")
    return ("cerrada antes de que el contrato de evidencia existiera, y sin comando de "
            "verificacion registrado: no hay nada que correr, asi que no hay corrida "
            "negativa que se pueda producir sin inventar primero la comprobacion")


def sin_prueba(root: Path) -> list[Path]:
    """Cierres sin evidencia, nacidos ANTES del contrato. Los de despues NO entran."""
    corte = esquema.CONTRATO_EVIDENCE
    fuera = []
    for p in fichas(root):
        t = p.read_text(encoding="utf-8", errors="replace")
        if not re.search(r"^status:\s*done\s*$", t, re.M):
            continue
        if re.search(r"^evidence:", t, re.M):
            continue
        creada = re.search(r"^created:\s*(\S+)", t, re.M)
        if creada and creada.group(1).strip('"\'') >= corte:
            continue
        fuera.append(p)
    return fuera


def aplicar(root: Path, escribir: bool) -> Counter:
    c: Counter = Counter()

    for original, _sucesor in duplicados(root):
        c["duplicados"] += 1
        if escribir:
            original.unlink()

    for p in punteros_rotos(root):
        c["punteros"] += 1
        if escribir:
            t = p.read_text(encoding="utf-8", errors="replace")
            atomic_io.write_text_durable(p, t.replace(PUNTERO_VIEJO, PUNTERO_NUEVO))

    for p in sin_prueba(root):
        c["sin_prueba"] += 1
        if escribir:
            t = p.read_text(encoding="utf-8", errors="replace")
            razon = razon_derivada(t)
            nuevo = re.sub(r"^status:\s*done\s*$",
                           f'status: done_unverified\nunverified_reason: "{razon}"',
                           t, count=1, flags=re.M)
            atomic_io.write_text_durable(p, nuevo)
    return c


def declarado(root: Path) -> Counter:
    """Lo que este modulo NO arregla, contado por clase. Se imprime siempre."""
    c: Counter = Counter()
    for p in fichas(root):
        fm, _motivo = esquema.parse(p)
        if fm is None:
            c["ilegible"] += 1
            continue
        for b in esquema.validate(fm):
            if "close_check.cmd" in b:
                c["cmd_vacio"] += 1
            elif b.startswith("falta campo obligatorio"):
                c["falta_campo"] += 1
            elif b.startswith("title de"):
                c["titulo"] += 1
        # Los avisos se cuentan aparte de las violaciones porque son otra cosa: no
        # bloquean. Pero se cuentan, o «no bloquea» acaba significando «no se ve».
        c["avisos"] += len(esquema.avisos(fm))
    return c


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=".")
    ap.add_argument("--apply", action="store_true",
                    help="escribe; sin esta bandera solo mide")
    a = ap.parse_args(argv)
    root = Path(a.root).resolve()

    antes = sum(1 for p in fichas(root)
                if (fm := esquema.parse(p)[0]) is None or esquema.validate(fm))
    c = aplicar(root, escribir=a.apply)
    despues = sum(1 for p in fichas(root)
                  if (fm := esquema.parse(p)[0]) is None or esquema.validate(fm))
    pend = declarado(root)

    modo = "APLICADO" if a.apply else "SOLO MEDIDO (usa --apply para escribir)"
    print(f"[canon-repair] {root.name}: {modo}")
    print(f"  reparables  duplicados={c['duplicados']} punteros={c['punteros']} "
          f"sin_prueba={c['sin_prueba']}")
    # Los ceros se imprimen. Un repo sin nada que declarar y un repo que no supo mirar
    # se ven igual si solo se imprime lo que se encontro.
    print(f"  DECLARADO, no tocado: cmd_vacio={pend['cmd_vacio']} "
          f"falta_campo={pend['falta_campo']} titulo={pend['titulo']} "
          f"ilegible={pend['ilegible']} avisos_no_bloqueantes={pend['avisos']}")
    print(f"  fichas invalidas: antes={antes} despues={despues}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
