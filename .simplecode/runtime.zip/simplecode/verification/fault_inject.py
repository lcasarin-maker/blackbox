# -*- coding: utf-8 -*-
"""fault_inject.py -- Reusable fault-injection primitives (Fase 2, Goodhart remediation).

Static detectors (non_atomic_file_overwrite, unmanaged_resource_open) ask "does
this code's SYNTAX look like it writes atomically / releases its resources?" --
the same Goodhart-gameable question as the test-quality detectors Fase 1
replaced. A `with open(...) as f:` block LOOKS safe; whether it actually
survives a real failure mid-write, or actually releases the handle when the
body raises, can only be answered by forcing the failure and inspecting the
aftermath.

This module doesn't auto-discover and fault-inject arbitrary flagged call
sites (too fragile: unknown signatures, unknown side effects, unknown
preconditions). Instead it's the reusable primitive layer that makes writing
a REAL fault-injection test as easy as writing a mocked one -- the exact
idiom already proven twice this session by hand (corruption_guard's
`_read_bytes_stable` fix, and a peer session's `test_save_index_atomico`
regression test), formalized so every future test doesn't reinvent it via ad
hoc monkeypatch.
"""
from __future__ import annotations

import builtins
import contextlib
import io
import os
from pathlib import Path
from typing import Any, Callable


class InjectedFailure(OSError):
    """Raised by an instrumented call under fault injection, exactly once."""


def _make_once_wrapper(real_method: Callable[..., Any], exc: Exception) -> Callable[..., Any]:
    fired = {"done": False}

    def _wrapper(self, *args, **kwargs):
        if fired["done"]:
            return real_method(self, *args, **kwargs)
        fired["done"] = True
        raise exc

    return _wrapper


@contextlib.contextmanager
def inject_failure_once(monkeypatch, target_cls: type, method_name: str, exc: Exception | None = None):
    """While active, the FIRST call to `target_cls.method_name` (on any
    instance) raises `exc` instead of running -- every call after that
    behaves normally. Models a single real fault (a disk hiccup, a killed
    process), not a permanently broken primitive.

    Use this to force a failure INSIDE a `with resource:` body, then assert
    the resource was still released (`resource.closed is True`, a lock file
    removed, a temp file cleaned up) despite the failure -- proving a
    finally/`__exit__` actually ran rather than being assumed correct
    because the syntax looks right.
    """
    real_method = getattr(target_cls, method_name)
    monkeypatch.setattr(target_cls, method_name, _make_once_wrapper(real_method, exc or InjectedFailure(
        f"simulated {method_name} failure"
    )))
    yield


class _CrashOnWriteProxy:
    """Wraps a real file object; the FIRST `.write()` call writes only
    `fail_after_bytes` then raises `InjectedFailure`. Every other attribute
    (read, close, context-manager protocol, ...) passes straight through to
    the wrapped object -- this proxies identity, not reimplements a file.
    """

    def __init__(self, real_file: Any, fail_after_bytes: int, state: dict, path_for_message: Path):
        object.__setattr__(self, "_real_file", real_file)
        object.__setattr__(self, "_fail_after_bytes", fail_after_bytes)
        object.__setattr__(self, "_state", state)
        object.__setattr__(self, "_path_for_message", path_for_message)

    def write(self, data):
        state = object.__getattribute__(self, "_state")
        real_file = object.__getattribute__(self, "_real_file")
        if state["done"]:
            return real_file.write(data)
        state["done"] = True
        fail_after = object.__getattribute__(self, "_fail_after_bytes")
        partial = data[:fail_after] if isinstance(data, (bytes, bytearray, memoryview)) else data
        real_file.write(partial)
        path = object.__getattribute__(self, "_path_for_message")
        raise InjectedFailure(f"simulated crash writing to {path} after {fail_after} bytes")

    def __enter__(self):
        return self

    def __exit__(self, *exc_info):
        return object.__getattribute__(self, "_real_file").__exit__(*exc_info)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_real_file"), name)


# The three helpers below used to be closures inside `inject_write_crash`.
# They are at module level because NONE of them reads the injection state (the
# `state` dict, `real_target`, `fail_after_bytes`): they answer questions about
# ONE `open()` call's arguments and hand the verdict to the `maybe_wrap` the
# caller passes in. Only `_maybe_wrap` itself needs the enclosing scope, so
# only it stays a closure -- and each of these is now reachable by a test on
# its own instead of only through a live monkeypatch session.

def _resolve_or_none(file) -> str | None:
    """`Path.resolve()` can fail for a path `open()` itself never even
    looks at closely enough to reject -- verified live (2026-08-30): a
    symlink loop raises `OSError` from the underlying `stat()` call, but
    `Path.resolve()` (CPython 3.12) converts THAT specifically into
    `RuntimeError: Symlink loop from ...`, not `OSError` -- catching only
    `OSError` here would silently miss it. Swallowing both here means
    resolving an unrelated broken path never crashes fault injection for
    a completely different target; falling through with resolved=None
    just means this open() is never wrapped (it can't match
    `real_target` if we don't know what it resolves to)."""
    if not isinstance(file, (str, os.PathLike)):
        return None
    try:
        return str(Path(file).resolve())
    except (OSError, RuntimeError):
        return None


def _is_write_mode(mode: str) -> bool:
    return any(flag in mode for flag in ("w", "a", "x", "+"))


def _make_path_based_flaky_open(
    real_opener: Callable[..., Any], maybe_wrap: Callable[[Any, str | None], Any],
) -> Callable[..., Any]:
    """A drop-in for a PATH-taking factory (`builtins.open`, `io.open`)."""
    def _flaky(file, mode="r", *args, **kwargs):
        real_file = real_opener(file, mode, *args, **kwargs)
        if not _is_write_mode(mode):
            return real_file
        return maybe_wrap(real_file, _resolve_or_none(file))
    return _flaky


def _make_fd_based_flaky_open(
    real_fdopen: Callable[..., Any], maybe_wrap: Callable[[Any, str | None], Any],
) -> Callable[..., Any]:
    """A drop-in for `os.fdopen`, which is handed a DESCRIPTOR and not a path:
    the path has to be read back off `/proc/self/fd/<fd>`, and where that is
    unavailable the open is simply never wrapped (resolved=None) rather than
    crashing the writer under test."""
    def _flaky(fd, mode="r", *args, **kwargs):
        real_file = real_fdopen(fd, mode, *args, **kwargs)
        if not _is_write_mode(mode):
            return real_file
        resolved = None
        try:
            resolved = os.readlink(f"/proc/self/fd/{fd}")
        except OSError:
            pass
        return maybe_wrap(real_file, resolved)
    return _flaky


@contextlib.contextmanager
def inject_write_crash(monkeypatch, target_path: Path, fail_after_bytes: int = 0):
    """While active, the NEXT write to `target_path` -- through ANY Python
    API that opens it -- writes only `fail_after_bytes` of its payload, then
    raises `InjectedFailure`. Reproduces a real truncate-then-crash writer.
    Fires exactly once for `target_path`; writes to OTHER files pass
    through untouched.

    Patches the file-object FACTORIES (`builtins.open`, `io.open`,
    `os.fdopen`) to wrap the object they return in a thin write-intercepting
    proxy, rather than patching one specific write method. This is the
    universal interception point: `Path.write_bytes`/`write_text` call
    `Path.open()` -> `io.open`; a raw `open(path, "wb")` call hits the same
    `io.open`; `os.fdopen(fd, "wb")` (this project's own
    `atomic_io.write_bytes_durable`, via `tempfile.mkstemp`) is the third.
    Patching Python-level `os.write` -- the first version of this function --
    does NOT work: CPython's `io.FileIO`/`io.BufferedWriter` are C types that
    call the `write(2)` syscall directly, never through the pure-Python
    `os.write` wrapper, so that patch silently never fired for ANY real file
    write. Patching `io.FileIO.write` directly doesn't work either -- it's
    an immutable C type (`TypeError: cannot set 'write' attribute of
    immutable type '_io.FileIO'`) that refuses attribute assignment. Wrapping
    what the factory RETURNS is the only interception point pure Python
    monkeypatching can reach that still catches every caller regardless of
    which factory it used.

    This is the exact race that kept reopening Atlas's DEBT-BYTE-CORRUPTION:
    a reader landing mid-write saw a truncated file even though the writer's
    eventual, settled content was clean.
    """
    real_target = str(Path(target_path).resolve())
    state = {"done": False}
    real_open = builtins.open
    real_io_open = io.open
    real_fdopen = os.fdopen

    def _maybe_wrap(real_file: Any, resolved_path: str | None) -> Any:
        if state["done"] or resolved_path != real_target:
            return real_file
        return _CrashOnWriteProxy(real_file, fail_after_bytes, state, target_path)

    _flaky_open = _make_path_based_flaky_open(real_open, _maybe_wrap)
    _flaky_io_open = _make_path_based_flaky_open(real_io_open, _maybe_wrap)
    _flaky_fdopen = _make_fd_based_flaky_open(real_fdopen, _maybe_wrap)

    monkeypatch.setattr(builtins, "open", _flaky_open)
    monkeypatch.setattr(io, "open", _flaky_io_open)
    monkeypatch.setattr(os, "fdopen", _flaky_fdopen)
    yield


@contextlib.contextmanager
def inject_fsync_failure(monkeypatch):
    """While active, the NEXT `os.fsync` call raises `InjectedFailure` instead
    of running -- reproducing a disk-level flush failure between "temp file
    written" and "atomic rename". Fires exactly once.

    This is the primitive that actually exercises `atomic_io.write_bytes_durable`
    and any writer following the same temp+fsync+rename contract: `os.replace`
    never even runs, so the ORIGINAL destination content -- proving atomicity
    means proving it was NEVER TOUCHED, not that it was correctly restored --
    must still be there afterward. `inject_partial_write_failure` cannot test
    this path; a `Path.write_bytes` patch never fires for `os.fdopen`-based
    writers.
    """
    real_fsync = os.fsync
    fired = {"done": False}

    def _flaky_fsync(fd: int) -> None:
        if fired["done"]:
            return real_fsync(fd)
        fired["done"] = True
        raise InjectedFailure("simulated fsync failure")

    monkeypatch.setattr(os, "fsync", _flaky_fsync)
    yield


def assert_resource_released(resource: Any) -> None:
    """Fail loudly, naming what's still open, if a common resource type was
    not released. Recognizes the `closed` attribute (files, sockets) and
    falls back to a clear COULD_NOT_RUN-style error for unrecognized types --
    never silently passes on a type it can't actually check."""
    if hasattr(resource, "closed"):
        if not resource.closed:
            raise AssertionError(f"{resource!r} was not released (`.closed` is False)")
        return
    raise TypeError(
        f"assert_resource_released does not know how to check {type(resource).__name__}; "
        "add a case for it rather than assuming release."
    )
