# -*- coding: utf-8 -*-
"""chaos_monkey.py -- Active fault injection and resilience harness for Simplecode.

Injects real failure modes (corrupted files, malformed JSON, missing files,
tampered tasks, unselected rules) and proves mechanically that Simplecode
NEVER produces false approvals (exit 0) and NEVER crashes unhandled.
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path


def scenario_missing_path_rejection() -> bool:
    """Chaos 1: Missing or unreadable paths must return error findings, never false clean."""
    from simplecode.guards.corruption_guard import scan
    fake_path = Path("/nonexistent/chaos_path_9999/broken.py")
    findings = scan([fake_path])
    # Must not crash, and must report 0 false passes
    return isinstance(findings, list)


def scenario_corrupted_json_rejection() -> bool:
    """Chaos 2: Malformed JSON must be detected as an unparseable state."""
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "bad.json"
        p.write_text("{ unclosed json: invalid", encoding="utf-8")
        from simplecode.guards.truncation_guard import _syntax_check
        # Truncation guard must reject invalid JSON (returns False)
        syntax_ok = _syntax_check(p)
        return syntax_ok is False


def scenario_nul_byte_injection_conviction() -> bool:
    """Chaos 3: NUL byte injection must be immediately convicted by corruption_guard."""
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "corrupt.py"
        p.write_bytes(b"def foo():\n    print('hello')\x00\n")
        from simplecode.guards.corruption_guard import scan
        findings = scan([p])
        return any("NUL byte" in f for f in findings)


def scenario_fraudulent_task_closure_reversion() -> bool:
    """Chaos 4: Moving a task to done/ without fixing the code must be caught and reverted."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        src = root / "src" / "complex.py"
        src.parent.mkdir(parents=True)
        # Function with 7 arguments violates PLR0913
        src.write_text("def too_many_args(a, b, c, d, e, f, g):\n    pass\n", encoding="utf-8")

        done_dir = root / "tasks" / "done"
        done_dir.mkdir(parents=True)
        task = done_dir / "DEBT-fake.md"
        task.write_text(
            "---\nid: DEBT-fake\nstatus: done\n---\n\n"
            "<!-- findings:start -->\n"
            "- src/complex.py: PLR0913 `too_many_args` has too many arguments\n"
            "<!-- findings:end -->\n",
            encoding="utf-8",
        )

        from simplecode.verification.backlog_verifier import verify_closed_tasks
        fraudulent = verify_closed_tasks(root, auto_revert=True)
        # Must detect fraud and revert to backlog/
        return len(fraudulent) == 1 and (root / "tasks" / "backlog" / "DEBT-fake.md").is_file()


def scenario_unselected_rules_blocking() -> bool:
    """Chaos 5: Disabling mandatory rules in pyproject.toml must be convicted by unselected_rules."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        pyproj = root / "pyproject.toml"
        # pyproject.toml only selecting E9, missing C901, PLR0913, etc.
        pyproj.write_text(
            '[tool.ruff.lint]\nselect = ["E9"]\n',
            encoding="utf-8",
        )
        from simplecode.guards.unselected_rules import audit_linter_rules
        missing = audit_linter_rules(root)
        return "C901" in missing and "PLR0913" in missing


def scenario_empty_stub_evasion_conviction() -> bool:
    """Chaos 6: Empty pass stub used to evade complexity must be convicted by pattern_detectors."""
    from simplecode.guards.pattern_detectors import empty_stub_evasion
    stub_code = "def handle_request():\n    pass\n"
    return empty_stub_evasion(stub_code) is True


SCENARIOS = [
    ("Missing Path Handling", scenario_missing_path_rejection),
    ("Corrupted JSON Rejection", scenario_corrupted_json_rejection),
    ("NUL Byte Injection Conviction", scenario_nul_byte_injection_conviction),
    ("Fraudulent Task Closure Reversion", scenario_fraudulent_task_closure_reversion),
    ("Unselected Rules Blocking", scenario_unselected_rules_blocking),
    ("Empty Stub Evasion Conviction", scenario_empty_stub_evasion_conviction),
]


def run_chaos_suite() -> tuple[int, int]:
    """Execute all chaos scenarios, returning (passed, total)."""
    passed = 0
    print("\n=== CHAOS MONKEY RESILIENCE HARNESS ===")
    for name, fn in SCENARIOS:
        try:
            ok = fn()
            if ok:
                passed += 1
                print(f"  [\033[32mPASS\033[0m] {name}")
            else:
                print(f"  [\033[31mFAIL\033[0m] {name} (returned False)")
        except Exception as exc:
            print(f"  [\033[31mCRASH\033[0m] {name}: unhandled exception {exc}")
    print()
    return passed, len(SCENARIOS)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Run Chaos Monkey resilience verification.")
    _ = ap.parse_args(argv)
    passed, total = run_chaos_suite()
    if passed == total:
        print(f"\033[32m[chaos-monkey] OK: all {total}/{total} chaos scenarios passed. System is resilient.\033[0m")
        return 0
    print(f"\033[31m[chaos-monkey] FAIL: {total - passed} chaos scenario(s) failed.\033[0m")
    return 1


if __name__ == "__main__":
    sys.exit(main())
