# -*- coding: utf-8 -*-
"""red_team.py -- Autonomous Adversarial Mutation Engine & Self-Hardening Loop (ADR-0012).

Fuzzes Simplecode quality gates by synthesizing isomorphic evasion mutations
(dynamic indirections, compound tautologies, stealth wraps) and verifying that
Simplecode's canonical AST normalizers convict every mutation without fail.
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
from collections.abc import Callable
from dataclasses import dataclass

from simplecode.guards import agent_threats, ast_normalizer, pattern_detectors
from simplecode.verification import detector_controls


@dataclass(frozen=True)
class RedTeamMutation:
    detector_id: str
    mutation_type: str
    original_code: str
    mutated_code: str


@dataclass(frozen=True)
class RedTeamResult:
    detector_id: str
    mutation_type: str
    status: str  # CONVICTED | EVADED
    evidence: str


_CALL_TARGET_RE = re.compile(r"\b([a-zA-Z_][a-zA-Z0-9_.]*)\.([a-zA-Z_][a-zA-Z0-9_]*)\s*\(")


def _extract_call_target(code: str) -> tuple[str, str] | None:
    """Find the first `obj.method(` call site to mutate, or None if there's
    none. Shared by every synthesizer below -- each one only differs in
    which guard it applies and what it replaces the call site with."""
    match = _CALL_TARGET_RE.search(code)
    if not match:
        return None
    return match.group(1), match.group(2)


def synthesize_getattr_evasion(code: str) -> str | None:
    """Synthesize a dynamic getattr indirection mutation: x.y(...) -> getattr(x, 'y')(...)."""
    target = _extract_call_target(code)
    if target is None:
        return None
    obj, method = target
    # Don't mutate getattr itself
    if "getattr" in obj or method == "getattr":
        return None
    return code.replace(f"{obj}.{method}(", f"getattr({obj}, '{method}')(", 1)


def synthesize_dynamic_import_evasion(code: str) -> str | None:
    """Synthesize a dynamic __import__ indirection mutation: mod.fn(...) -> __import__('mod').fn(...)."""
    target = _extract_call_target(code)
    if target is None:
        return None
    obj, method = target
    if obj in ("self", "cls", "getattr", "__import__"):
        return None
    if "." in obj:
        first_mod, rest = obj.split(".", 1)
        replacement = f"getattr(__import__('{first_mod}').{rest}, '{method}')("
    else:
        replacement = f"__import__('{obj}').{method}("
    return code.replace(f"{obj}.{method}(", replacement, 1)


def synthesize_attrgetter_evasion(code: str) -> str | None:
    """Synthesize an operator.attrgetter indirection: x.y(...) -> operator.attrgetter('y')(x)(...).

    Unlike getattr/__import__ indirection, this doesn't require `x` to be a
    module -- it's the general Python idiom for "resolve this attribute name
    dynamically" on ANY object, so it applies to every `.method(...)` call a
    detector might convict, not just module-rooted ones.
    """
    target = _extract_call_target(code)
    if target is None:
        return None
    obj, method = target
    if "getattr" in obj or method == "getattr" or obj == "operator":
        return None
    replacement = f"operator.attrgetter('{method}')({obj})("
    return code.replace(f"{obj}.{method}(", replacement, 1)


def synthesize_lambda_wrap_evasion(code: str) -> str | None:
    """Synthesize a lambda-wrapped attribute access: x.y(...) -> (lambda: x.y)()(...).

    A zero-arg lambda immediately called is semantically a no-op indirection
    -- `(lambda: x.y)()` evaluates to exactly `x.y` -- but it's a completely
    different AST shape (Call-of-Call-of-Lambda) than getattr/attrgetter
    indirection, so a normalizer built for those two doesn't see this one
    for free.
    """
    target = _extract_call_target(code)
    if target is None:
        return None
    obj, method = target
    if "getattr" in obj or method == "getattr":
        return None
    replacement = f"(lambda: {obj}.{method})()("
    return code.replace(f"{obj}.{method}(", replacement, 1)


_MUTATION_SYNTHESIZERS: list[tuple[str, Callable[[str], str | None]]] = [
    ("getattr_indirection", synthesize_getattr_evasion),
    ("dynamic_import_indirection", synthesize_dynamic_import_evasion),
    ("attrgetter_indirection", synthesize_attrgetter_evasion),
    ("lambda_wrap_indirection", synthesize_lambda_wrap_evasion),
]


def synthesize_all_mutations() -> list[RedTeamMutation]:
    """Generate all adversarial evasion mutations over the live detector registry."""
    mutations: list[RedTeamMutation] = []
    controls = detector_controls.CONTROLS

    for det_id, (pos_code, _) in controls.items():
        for mutation_type, synthesizer in _MUTATION_SYNTHESIZERS:
            mutated = synthesizer(pos_code)
            if mutated and mutated != pos_code:
                mutations.append(
                    RedTeamMutation(
                        detector_id=det_id,
                        mutation_type=mutation_type,
                        original_code=pos_code,
                        mutated_code=mutated,
                    )
                )

    return mutations


def evaluate_mutation(mutation: RedTeamMutation) -> RedTeamResult:
    """Evaluate whether Simplecode's normalized engine catches the synthesized evasion."""
    detector_fn = None
    for fn, name, _ in pattern_detectors.PATTERN_DETECTORS:
        if name == mutation.detector_id:
            detector_fn = fn
            break

    if detector_fn is None and mutation.detector_id == "data_exfiltration":
        detector_fn = agent_threats.data_exfiltration
        try:
            tree = ast.parse(mutation.mutated_code)
            tree = ast_normalizer.normalize_ast(tree)
            code_to_check = ast.unparse(tree)
        except (SyntaxError, ValueError, TypeError) as exc:
            return RedTeamResult(
                detector_id=mutation.detector_id,
                mutation_type=mutation.mutation_type,
                status="EVADED",
                evidence=f"COULD_NOT_RUN: could not normalize mutation: {type(exc).__name__}: {exc}",
            )
    else:
        code_to_check = mutation.mutated_code

    if detector_fn is None:
        return RedTeamResult(
            detector_id=mutation.detector_id,
            mutation_type=mutation.mutation_type,
            status="EVADED",
            evidence="COULD_NOT_RUN: no mutation evaluator is registered for this detector",
        )

    # A detector that crashes on the mutation did not convict it (status stays
    # EVADED, fail-closed), but the evidence must name the crash instead of
    # passing it off as a plain blind spot (angry-path, 2026-09-27).
    crash = ""
    try:
        convicted = bool(detector_fn(code_to_check))
    except Exception as exc:
        convicted = False
        crash = f" (detector crashed: {type(exc).__name__}: {exc})"

    if convicted:
        return RedTeamResult(
            detector_id=mutation.detector_id,
            mutation_type=mutation.mutation_type,
            status="CONVICTED",
            evidence=f"Normalized AST caught {mutation.mutation_type} evasion",
        )
    return RedTeamResult(
        detector_id=mutation.detector_id,
        mutation_type=mutation.mutation_type,
        status="EVADED",
        evidence=f"0-Day Blind Spot: {mutation.mutation_type} was not convicted by {mutation.detector_id}{crash}",
    )


def _synthesize_and_evaluate() -> tuple[list[RedTeamMutation], list[RedTeamResult]]:
    mutations = synthesize_all_mutations()
    return mutations, [evaluate_mutation(m) for m in mutations]


def run_red_team_audit() -> list[RedTeamResult]:
    """Run full adversarial red team audit across all synthesized mutations."""
    _mutations, results = _synthesize_and_evaluate()
    return results


_PROPOSALS_DIR_RELPATH = "tasks/hardening_proposals"


def _propose_hardening_for_evasions(evaded_mutations: list[RedTeamMutation]) -> int:
    """Ask the local LLM to draft + mechanically verify a fix for each 0-day
    evasion the gate just caught. Never applies anything to real source --
    writes a markdown proposal artifact for human review, or reports why it
    couldn't (down local LLM, verification failure). A gate that's already
    failing must not crash harder because the drafting assist is unavailable.

    DEBT-RED-TEAM-SE-CURA-SOLO-Y-DUPLICA (segunda mitad): dos evasiones
    distintas pueden producir el MISMO parche (misma forma de indireccion
    detectada dos veces), y nada comparaba antes de escribir -- medido, tres
    copias EXACTAS de un bloque de 12 lineas terminaron en `ast_normalizer.py`.
    `known_rule_bodies` empieza vacio aqui y `mechanically_verify_patch` lo va
    llenando con cada regla que verifica de verdad en ESTA corrida; la
    evasion #2 que redacta el mismo cuerpo que la #1 vuelve marcada
    `DUPLICATE:` y se salta la escritura -- se registra por que, nunca se
    escribe dos veces.
    """
    from pathlib import Path

    from simplecode.verification import hardening_proposal

    root = Path(__file__).resolve().parents[3]
    out_dir = root / _PROPOSALS_DIR_RELPATH
    print("\n[red-team] Drafting hardening proposals via local LLM (never auto-applied)...")
    known_rule_bodies: dict[str, str] = {}
    escritas = 0
    for mutation in evaded_mutations:
        try:
            proposal = hardening_proposal.propose_hardening_for_evasion(
                mutation, root, known_rule_bodies=known_rule_bodies,
            )
        except hardening_proposal.LocalLLMUnavailable as exc:
            print(f"  [!] {mutation.detector_id}/{mutation.mutation_type}: could not draft -- {exc}")
            continue
        if proposal.mechanical_evidence.startswith("DUPLICATE:"):
            print(
                f"  [dup] {mutation.detector_id}/{mutation.mutation_type}: "
                f"{proposal.mechanical_evidence} -- no se escribe propuesta"
            )
            continue
        path = hardening_proposal.write_proposal_file(proposal, out_dir)
        verdict = "MECHANICALLY VERIFIED" if proposal.mechanically_verified else "NOT VERIFIED"
        print(f"  [proposal] {mutation.detector_id}/{mutation.mutation_type}: {verdict} -> {path}")
        escritas += 1
    return escritas


def _spawn_hardening_drafting_detached() -> None:
    """Launch `--draft-proposals-only` as a detached background process.

    The verdict this gate exists to produce (CONVICTED/EVADED, and whether to
    fail the push) is already fully determined and printed by the time this
    is called -- the LLM-based hardening-proposal drafting that follows adds
    nothing to that decision, only a nice-to-have suggested patch. Measured
    2026-09-08: drafting one proposal per evasion, synchronously, is what
    made this gate spike to 212s in the worst case, all of it AFTER the FAIL
    verdict a developer needs immediately was already on screen. Detaching
    into a new session (same mechanism as the `observe`/`growth-ratchet`
    hooks, factored into `simplecode.utils.detach`) returns control to the
    caller in milliseconds; the child re-synthesizes the same deterministic
    mutations (cheap, ~1s) and drafts+writes proposals on its own time.
    """
    from pathlib import Path

    from simplecode.utils.detach import launch_detached

    log_path = Path(__file__).resolve().parents[3] / _PROPOSALS_DIR_RELPATH / ".last_drafting.log"
    # Append, not truncate: each drafting run's output stays alongside the
    # prior ones for debugging (and non_atomic_file_overwrite -- GS2-222 --
    # only convicts truncating 'w'/'wb'/'w+' opens, correctly: a log handle
    # inherited by a live subprocess is never the "replace a whole document"
    # shape that check exists for).
    launch_detached(
        [sys.executable, "-m", "simplecode.verification.red_team", "--draft-proposals-only"],
        log_path,
    )


def main(argv: list[str] | None = None) -> int:
    """CLI entrypoint for simplecode redteam."""
    parser = argparse.ArgumentParser(description="Run autonomous red-team adversarial evasion fuzzer.")
    parser.add_argument("--gate", action="store_true", help="Fail if any synthesized evasion bypasses detection")
    parser.add_argument(
        "--draft-proposals-only", action="store_true",
        help="Internal: re-run synthesis, draft hardening proposals for any evasions, and exit. "
             "Used by the detached process --gate spawns; never run this manually as the gate.",
    )
    args = parser.parse_args(argv)

    if args.draft_proposals_only:
        _mutations, _results = _synthesize_and_evaluate()
        evaded = [m for m, r in zip(_mutations, _results) if r.status == "EVADED"]
        if evaded:
            _propose_hardening_for_evasions(evaded)
        return 0

    mutations, results = _synthesize_and_evaluate()
    evasions = [r for r in results if r.status == "EVADED"]

    if not results:
        # Zero mutations synthesized means zero detectors were exercised -- an
        # empty `detector_controls.CONTROLS` registry (or one where no
        # synthesizer produced a mutation) would otherwise fall straight
        # through to "SUCCESS: All ... evasions convicted", which is true only
        # because nothing was tried. Silence is not proof of hardness.
        print(
            "[red-team] COULD_NOT_RUN: 0 adversarial mutations were synthesized "
            "from the detector control registry; no detector was exercised",
            file=sys.stderr,
        )
        return 1 if args.gate else 0

    # Cobertura REAL al lado del total, no el total solo. These synthesizers only
    # exercise pattern detectors with a registered positive control containing
    # a transformable call. Other controls remain visible as untested. Measured
    # 2026-09-06. Mecanismo tomado de
    # Bratan (Atlas, cosecha 2026-09-06, cita contra captura cruda del upstream):
    # el Red Team existe para que el Blue Team no descanse sobre lo que ya pasa, y
    # un numero que no dice sobre CUANTO se probo tranquiliza sin informar. Es la
    # politica de la casa -- imprimir lo que no corrio al lado de lo que si.
    ejercitados = {m.detector_id for m in mutations}
    total_controles = len(detector_controls.CONTROLS)
    mudos = total_controles - len(ejercitados)
    print(f"\n=== SIMPLECODE AUTONOMOUS RED-TEAM AUDIT ({len(results)} adversarial mutations tested) ===")
    print(f"[red-team] cobertura: {len(ejercitados)} de {total_controles} controles ejercitados; "
          f"{mudos} no tienen mutacion soportada y NO fueron probados aqui")
    for r in results:
        icon = "✓" if r.status == "CONVICTED" else "✗"
        print(f"  [{icon}] {r.detector_id:32s} | {r.mutation_type:26s} -> {r.status}")

    print(f"\n[red-team] Total mutations: {len(results)} | Convicted: {len(results) - len(evasions)} | Evasions: {len(evasions)}")

    if evasions and args.gate:
        # DEBT-RED-TEAM-SE-CURA-SOLO-Y-DUPLICA: este organo ATACA y ademas redacta
        # el arreglo, asi que su rojo significaba dos cosas incompatibles con el
        # mismo texto -- "tu codigo esta mal" y "encontre evasiones, escribi las
        # propuestas, vuelve a correr". Lo segundo leido como lo primero ensena que
        # un rojo se arregla reintentando, que es el antipatron que la regla
        # anti-bucle prohibe. La cura no es quitarle la escritura (ADR-0012 se la da
        # a proposito) sino que el veredicto diga cual de las dos es.
        #
        # La separacion es la de Bratan (Atlas, cosecha 2026-09-06, citada contra la
        # captura cruda del upstream): "Red Team breaks the pipeline. Blue Team
        # fixes it. Judge keeps the score" -- tres papeles, tres frases distintas.
        # Aqui los tres viven en un proceso, asi que lo que se separa es el
        # VEREDICTO, no el organo.
        first = evasions[0]
        print(f"\033[31m[red-team] GATE FAILED: {len(evasions)} 0-day evasion(s) bypassed detectors!\033[0m")
        print(
            f"[red-team] RED: {len(evasions)} de {len(results)} mutacion(es) evadieron "
            f"su detector; primera {first.detector_id}/{first.mutation_type} "
            f"({first.evidence})",
            file=sys.stderr,
        )
        # Drafting (the LLM step) is decoupled from the verdict, 2026-09-08:
        # the FAIL below is fully determined already, and used to wait up to
        # 212s (one LLM call per evasion) before it could even print. Spawned
        # detached; proposals land in _PROPOSALS_DIR_RELPATH/ within a few
        # minutes, not before this process exits.
        try:
            _spawn_hardening_drafting_detached()
        except OSError as exc:
            print(f"[red-team] could not spawn the hardening-drafting process (non-fatal, gate result unaffected): {exc}")
        else:
            print(
                f"[red-team] FAIL: {len(evasions)} evasion(es) encontradas; redactando "
                f"propuesta(s) de endurecimiento en segundo plano -- apareceran en "
                f"{_PROPOSALS_DIR_RELPATH}/ en unos minutos. NADA se aplico solo. "
                f"Revisa cuando esten listas y vuelve a correr; primera "
                f"{first.detector_id}/{first.mutation_type}",
                file=sys.stderr,
            )
        return 1

    print("\033[32m[red-team] SUCCESS: All synthesized adversarial evasions convicted by normalized AST engine.\033[0m")
    return 0


if __name__ == "__main__":
    sys.exit(main())
