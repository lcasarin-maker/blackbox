#!/usr/bin/env python3
"""push_recheck.py -- after a blocked push, is a full retry worth spending?

A blocked `git push` pays the whole suite again on the next try (simplecode: 96-170 s per
attempt). Attempt 1 is unchanged: it still runs every gate and declares every failure
(no early cut; target 2 attempts per push = discover, then confirm). What this adds is the
step between the two attempts: re-run, in seconds, the gates that can say whether the retry
will block again.

    python -m simplecode.verification.push_recheck --repo .
    python -m simplecode.verification.push_recheck --repo . --only-red

It takes the LAST push attempt in `.simplecode/evidence/telemetry.jsonl` (the same ledger
and the same `run_id` grouping as `push_attempts` / `push_timing`) and re-runs, with the
literal `command` that attempt recorded for each gate:

  * every gate that was red in it, whatever its cost; and
  * unless `--only-red`, every CHEAP gate that ran in it -- median duration <= 30 s in this
    repo's own telemetry, computed (`push_timing.per_gate`), never listed by name.

Why the cheap ones too: of 88 retries blocked only by cheap gates across 8 repos, 33 (38%)
were blocked by a gate that was NOT red in the previous attempt -- the fix created a new red
(version-bump fresh 3x in simplecode, 9x in blackbox). Re-running only the previously-red
gates misses those; `--only-red` is there to measure that difference, not as the default.

One verdict per gate: OK, BLOCKED, or COULD_NOT_RUN (no command in the row, tool missing,
no row written). Then one line saying whether a full retry is worth spending. Gates run
through `gate_runner` so each recheck lands in telemetry, under `hook=pre-push-recheck`:
`push_attempts` and `push_timing` read only `hook=pre-push`, and `gate_effectiveness` and
`telemetry_dispositions` skip this hook, because a re-observation of a gate is not a new
catch and not a new finding.

Exit codes: 0 every rechecked gate is OK; 1 at least one is BLOCKED (the retry would block);
2 COULD_NOT_RUN -- the ledger has no blocked attempt, the last attempt is green, the blocked
attempt names no red gate, or a rechecked gate could not run. A recheck with
`could_not_run > 0` is not a clean report, however many gates passed.

Declared limits: this is an upper bound on what a retry can avoid, not a measured saving; an
EXPENSIVE gate that was green is not rechecked, so a fix can still turn it red (that is what
the confirming retry is for); `gitleaks-outgoing` is not rechecked because it needs the
push's own ref list; the commands run against the working tree as it is now, with the
interpreter the attempt recorded (`python_executable`; this module's own when that file is gone)
in place of the recorded `python`; a run killed before
its aggregate row is not an attempt (same limit as `push_attempts`).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from simplecode.verification import gate_runner, push_timing
from simplecode.verification.gate_runner import HOOK_RECHECK
from simplecode.verification.push_attempts import TELEMETRY, load_attempts, telemetry_sources

CHEAP_MEDIAN_SECONDS = 30.0
OK = "OK"
BLOCKED = "BLOCKED"
COULD_NOT_RUN = "COULD_NOT_RUN"
_STATUS_VERDICT = {"ok": OK, "blocked": BLOCKED}
_INTERPRETERS = frozenset({"python", "python3"})


@dataclass(frozen=True)
class Gate:
    """One gate to re-run: its name, the recorded command, and why it was picked."""

    name: str
    command: list[str]
    reason: str
    python: str = ""


@dataclass(frozen=True)
class Plan:
    attempt: list[dict]
    gates: list[Gate]
    not_rechecked: list[str]


def _suite_rows(attempt: list[dict]) -> list[dict]:
    """The gate rows of an attempt, one per gate (the last row wins), bookkeeping excluded."""
    rows = {r["check"]: r for r in attempt[:-1] if r.get("check") not in push_timing._NOT_SUITE}
    return list(rows.values())


def make_plan(path: Path, only_red: bool) -> tuple[Plan | None, str]:
    """(plan, why there is none): the gates to re-run for the last attempt in the ledger."""
    attempts, _ = push_timing.regroup_by_run(load_attempts(path, "0000"))
    if not attempts:
        return None, "the ledger holds no push attempt"
    last = attempts[-1]
    if last[-1].get("status") == "ok":
        return None, f"the last push attempt ({last[-1].get('ts')}) was green: nothing was blocked"
    medians = {g["gate"]: g["median"] for g in push_timing.per_gate(attempts)}
    gates: list[Gate] = []
    left_alone: list[str] = []
    for row in _suite_rows(last):
        red = row.get("status") != "ok"
        cheap = medians[row["check"]] <= CHEAP_MEDIAN_SECONDS
        if red or (cheap and not only_red):
            reason = "red in the last attempt" if red else f"cheap (median {medians[row['check']]:.1f}s)"
            gates.append(Gate(row["check"], list(row.get("command") or []), reason,
                              str(row.get("python_executable") or "")))
        else:
            left_alone.append(f"{row['check']} (median {medians[row['check']]:.0f}s)")
    if not any(g.reason.startswith("red") for g in gates):
        return None, (f"the last attempt ({last[-1].get('ts')}) was blocked but no gate row in it "
                      f"was red: the cause of the block is not in the ledger")
    return Plan(last, gates, left_alone), ""


def _verdict_from_ledger(path: Path, run_id: str, name: str) -> str:
    """What `gate_runner` wrote for this recheck, read back by `run_id`: COULD_NOT_RUN when absent."""
    status = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if run_id not in line:
            continue
        row = json.loads(line)
        if row.get("run_id") == run_id and row.get("check") == name and row.get("hook") == HOOK_RECHECK:
            status = row.get("status")
    return _STATUS_VERDICT.get(str(status), COULD_NOT_RUN)


def recheck_gate(root: Path, gate: Gate, run_id: str) -> str:
    """Run one gate through `gate_runner` and return OK, BLOCKED or COULD_NOT_RUN."""
    if not gate.command:
        print(f"[push-recheck] {gate.name}: the ledger row carries no command", file=sys.stderr)
        return COULD_NOT_RUN
    # The interpreter the attempt really used (its venv has the gate's tools), when it still exists:
    # from a bare shell `python` is another one, and the gates that need pytest or pyright
    # would read COULD_NOT_RUN (measured live: coverage-100 under /opt/miniforge3/bin/python).
    python = gate.python if Path(gate.python).is_file() else sys.executable
    command = [python if gate.command[0] in _INTERPRETERS else gate.command[0], *gate.command[1:]]
    path = root / TELEMETRY
    gate_runner.run_gate(root, gate.name, HOOK_RECHECK, command,
                         gate_runner.GateOptions(telemetry=path, own_failure=False))
    return _verdict_from_ledger(path, run_id, gate.name)


def decide(verdicts: dict[str, str], only_red: bool) -> tuple[int, str]:
    """(exit code, the line that says whether a full retry is worth spending)."""
    counts = {v: sum(1 for x in verdicts.values() if x == v) for v in (OK, BLOCKED, COULD_NOT_RUN)}
    tally = f"OK={counts[OK]} BLOCKED={counts[BLOCKED]} COULD_NOT_RUN={counts[COULD_NOT_RUN]}"
    if counts[BLOCKED]:
        red = ", ".join(n for n, v in verdicts.items() if v == BLOCKED)
        return 1, f"a full retry is NOT worth spending: still red: {red} ({tally})"
    if counts[COULD_NOT_RUN]:
        gone = ", ".join(n for n, v in verdicts.items() if v == COULD_NOT_RUN)
        return 2, f"cannot say whether a retry is worth it: could not run: {gone} ({tally})"
    scope = ("only the red gates were rechecked, so a cheap gate that was green may have turned red"
             if only_red else "the expensive gates that were green were not rechecked")
    return 0, f"a full retry IS worth spending: every rechecked gate is green ({tally}); {scope}"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", default=".", help="repository root (default: .)")
    ap.add_argument("--only-red", action="store_true",
                    help="re-run only the gates that were red; default is red + every cheap gate")
    args = ap.parse_args(argv)

    root = Path(args.repo).resolve()
    path = root / TELEMETRY
    if not telemetry_sources(path)[0]:
        print(f"[push-recheck] COULD_NOT_RUN: no telemetry at {path} or its archives", file=sys.stderr)
        return 2
    plan, why = make_plan(path, args.only_red)
    if plan is None:
        print(f"[push-recheck] COULD_NOT_RUN: {why}", file=sys.stderr)
        return 2
    last = plan.attempt[-1]
    print(f"[push-recheck] repo={root.name} last blocked attempt ts={last.get('ts')} "
          f"run_id={last.get('run_id') or 'n/a'} mode={'only-red' if args.only_red else 'red+cheap'}")
    run_id = f"recheck-{int(time.time())}-{os.getpid()}"
    previous = os.environ.get("SIMPLECODE_RUN_ID")
    os.environ["SIMPLECODE_RUN_ID"] = run_id
    try:
        verdicts = {g.name: recheck_gate(root, g, run_id) for g in plan.gates}
    finally:
        if previous is None:
            os.environ.pop("SIMPLECODE_RUN_ID")
        else:
            os.environ["SIMPLECODE_RUN_ID"] = previous
    for gate in plan.gates:
        print(f"  {verdicts[gate.name]:14}{gate.name:28}{gate.reason}")
    print(f"  not rechecked (green then, and expensive or --only-red): {', '.join(plan.not_rechecked) or 'none'}")
    code, line = decide(verdicts, args.only_red)
    print(f"[push-recheck] {line}")
    return code


if __name__ == "__main__":
    sys.exit(main())
