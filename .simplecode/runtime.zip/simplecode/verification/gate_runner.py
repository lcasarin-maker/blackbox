#!/usr/bin/env python3
"""Run one gate without losing its result, telemetry, or backlog ownership."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io, tree_lock
import simplecode as simplecode_module
from simplecode.utils.tool_limits import GATE_DRAIN_HARD_TIMEOUT, GATE_DRAIN_WARN_AFTER, GIT_O1_TIMEOUT
from simplecode.verification import hook_receipts

ENV_TELEMETRY = os.environ.get("SIMPLECODE_TELEMETRY")
# The `hook` value of a row written by `push_recheck`: a re-run of a gate after a blocked push.
# Neither a push attempt (`push_attempts`/`push_timing` read only `hook=pre-push`) nor a new
# catch or finding (`gate_effectiveness` and `telemetry_dispositions` skip it).
HOOK_RECHECK = "pre-push-recheck"
# The shell's "did not start" codes: 127 command not found, 126 found
# but not executable. Neither is a verdict about the subject.
_NO_ARRANCO = frozenset({126, 127})
_SECRET = re.compile(
    r"(?i)(api[-_]?key|authorization|password|secret|token)(\s*[:=]\s*)"
    r"(?:Bearer\s+|Basic\s+)?(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)"
)


@dataclass(frozen=True)
class GateOptions:
    telemetry: Path | None = None
    write_receipt: bool = False
    own_failure: bool = True


def _failure_key(name: str, command: list[str]) -> str:
    rendered = " ".join(_redact_command(command))
    return f"gate-failure: {name}: command `{rendered}` exited nonzero"


def _telemetry_path(root: Path, override: Path | None = None) -> Path:
    if override is not None:
        return override
    if ENV_TELEMETRY:
        return Path(ENV_TELEMETRY)
    return root / ".simplecode" / "evidence" / "telemetry.jsonl"


def _gate_failures_path(root: Path) -> Path:
    return root / ".simplecode" / "evidence" / "gate_failures.jsonl"


def _log_gate_failure(root: Path, key: str, cleared: bool) -> bool:
    """Append-only log of this gate wrapper's own self-report, gitignored
    (.simplecode/evidence/, same as telemetry.jsonl and hook_receipts).

    Was `finding_backlog.write_findings`/`prune_finding` into tasks/backlog/
    -- a git-TRACKED path. `pre-commit` diffs the tracked tree before and
    after each hook it runs; pruning a stale ticket on a now-passing check is
    a benign cleanup, but it still changes a tracked file, and `pre-commit`
    cannot tell "wrote its own bookkeeping" from "silently auto-fixed the
    code" -- it reports the SAME hook that just passed as `Failed - files
    were modified by this hook`, on every commit, forever, self-perpetuating
    (Atlas, DGX-228, 2026-08-25, measured with a negative control: `zero-debt`
    itself scanned clean, `violations: 0`, and still failed the commit).

    This is deliberately narrower than the fix for the 2026-08-17 incident
    (office2office, invisible debt when tasks/backlog/ was gitignored): THAT
    was about the granular findings a detector materializes under `--stamp`
    -- genuine debt that must stay visible, tracked, and reviewable. THIS is
    only gate_runner's own generic "a check exited nonzero" self-report,
    which duplicates what telemetry.jsonl and the printed stdout/stderr
    already capture for every run, pass or fail -- moving it costs no
    visibility that wasn't already redundant.
    """
    try:
        atomic_io.append_jsonl(
            _gate_failures_path(root),
            {"key": key, "cleared": cleared, "ts": datetime.now(timezone.utc).isoformat()},
        )
        return True
    except OSError as exc:
        print(f"[gate-runner] COULD_NOT_RUN gate-failure log: {exc}", file=sys.stderr)
        return False


def _redact(text: str) -> str:
    return _SECRET.sub(r"\1\2[REDACTED]", text)


def _redact_command(command: list[str]) -> list[str]:
    """Keep command structure while removing named credentials from durable logs."""
    redacted: list[str] = []
    secret_value = False
    for argument in command:
        redacted.append("[REDACTED]" if secret_value else _redact(argument))
        secret_value = bool(re.fullmatch(
            r"--?(?:api[-_]?key|authorization|password|secret|token)", argument, re.I,
        ))
    return redacted


def _skipped_gates() -> list[str]:
    """Gate ids silenced by pre-commit's `SKIP` for this run, in order."""
    raw = os.environ.get("SKIP", "")
    return [g.strip() for g in raw.split(",") if g.strip()]


def announce_bypass() -> None:
    """Say out loud that gates were skipped, and whether a reason was given.

    A bypass nobody sees becomes permanent in silence -- the same failure the
    suspension contract exists to prevent, which is why an unexplained SKIP is
    itself the alarm rather than a detail.

    This is TRANSPARENCY, not enforcement: `SKIP` is pre-commit's own env var,
    keyed to a hook's `id:` in `.pre-commit-config.yaml`, and pre-commit reads
    it BEFORE deciding whether to invoke this gate's `entry:` at all -- a
    correctly-targeted SKIP means this function never runs in the first
    place. Every name it prints here is a name gate_runner cannot act on
    itself (see `main()`'s own, separate check against `--name` for the one
    case it CAN act on). DEBT-AEQUITAS-07 (aequitas_os, 2026-09-08): a reader
    who only saw this line, naming their own `--name`, reasonably concluded
    THIS gate was silenced -- it was not, until `main()`'s check below.
    """
    # The kit says WHICH kit it is, on every run, before anything else it says.
    # Asked for by agente_inmobiliario 2026-09-05 in the form that makes it
    # actionable: "if a repo could print the kit version it runs -- one line in
    # any gate's output -- it would have been caught in the first minute
    # instead of the last."
    print(f"[gate-runner] kit: {kit_identity()}", file=sys.stderr)

    skipped = _skipped_gates()
    if not skipped:
        return
    reason = os.environ.get("SIMPLECODE_SKIP_REASON", "").strip()
    print(
        f"[gate-runner] !! BYPASS: {len(skipped)} gate(s) silenced by SKIP -- "
        f"{', '.join(skipped)}",
        file=sys.stderr,
    )
    if reason:
        print(f"[gate-runner]    declared reason: {reason}", file=sys.stderr)
    else:
        print(
            "[gate-runner]    NO REASON DECLARED. Set SIMPLECODE_SKIP_REASON so the "
            "row records WHY; a bypass whose cause nobody wrote down is one nobody "
            "can retire, and it becomes permanent the way a suspension with no "
            "expiry does.",
            file=sys.stderr,
        )


def _skip_self(name: str) -> bool:
    """True iff `SKIP` names THIS gate's own `--name` -- the one case
    `gate_runner` can actually honor, as opposed to the generic transparency
    `announce_bypass()` prints for names it has no power over.

    DEBT-AEQUITAS-07 (aequitas_os, 2026-09-08): before this, `main()` ran the
    wrapped command unconditionally regardless of `_skipped_gates()`, so
    setting this gate's local-skip variable to its own `--name` produced the
    exact same "!! BYPASS" line as a value that matched nothing, while the full command still ran end to
    end -- a message that read as "skipped" for a gate that was not.
    """
    return name in _skipped_gates()


def kit_identity() -> str:
    """WHICH KIT is running, derived from the kit itself -- never from `root`.

    The most-reported complaint in the fleet survey, named FIRST by 6 of 7
    sessions: a repo cannot tell which version of the kit its gates are. The
    field that was supposed to answer it, `kit_sha`, has been answering a
    different question since it was written: `_kit_sha(root)` runs
    `git rev-parse HEAD` with `cwd=root`, and in a satellite `root` is the
    SATELLITE. Measured 2026-09-05:

        _kit_sha(descargaSAT)  -> 720be1ea...  (descargaSAT's own HEAD)
        descargaSAT HEAD       -> 720be1ea...

    In simplecode the kit and the subject are the same repo, so the field is
    correct in exactly the one place it cannot be wrong -- which is why it
    survived. Measuring an instrument in the only environment where it cannot
    fail is the mould this kit spends its life catching in others.

    What it costs is not time. agente_inmobiliario, 2026-09-05: they opened a
    ficha against a threshold that had already been recalibrated, it passed two
    gates, and it only fell over when they went to produce its negative control
    -- so the closing contract had to serve as a detector of obsolete
    contracts. own_chats reported the same from another angle.

    Derived from where the code actually lives: a zip-imported kit is
    identified by its archive's digest, a source checkout by its OWN repo's
    HEAD. Never by the subject's.

    BOTH BRANCHES RUN IN PRODUCTION, measured 2026-09-05 from the rows the
    field itself now writes:

        src:  114 rows   simplecode, agente_inmobiliario
        zip:   62 rows   declutter, own_chats

    That number is the THIRD version of this paragraph, and the two before it
    were both wrong in opposite directions. I first wrote that satellites run
    the archive. agente_inmobiliario corrected me -- "yo no corro el zip", true
    for them, because `run.py` prefers the mother checkout when the archive
    matches it. I then generalised their one datum to the whole fleet and wrote
    that NO repo runs the zip, "measured" by grepping 18 copies of `run.py` for
    the word `mother`. That is reading the instrument instead of the subject:
    the presence of a mother-preferring branch says nothing about which branch
    is TAKEN, since the guard falls back to the archive whenever the two
    diverge. declutter's own output falsified it within the hour --
    `zip:runtime.zip:f187bb060643`.

    The measurement that settled it is the field's own rows, which is the only
    reading of the subject available: own_chats even shows two DIFFERENT zip
    digests in one session, which is the kit changing underneath them and the
    field doing exactly the job it was added for.

    Their detector, for sweeping this class without reading code: a CORRECT
    kit identity changes when the KIT changes -- rarely, and simultaneously
    everywhere. Cardinality close to a repo's own commit count means the field
    is recording the subject. Measured across the fleet the same day, 17 of 18
    repos flagged, RePic at exactly 108 distinct values over 108 commits. The
    18th (poe_normare, 6 values over 13 commits) is under the threshold only
    for want of history. simplecode shows 442 and is the one repo where the
    high count is CORRECT, since kit and subject coincide -- the detector
    cannot tell those apart here, which is the same blind spot that hid the
    defect.
    """
    import hashlib
    import zipfile

    pkg = Path(simplecode_module.__file__ or "").resolve()
    for parent in [pkg, *pkg.parents]:
        if parent.suffix == ".zip" and zipfile.is_zipfile(parent):
            digest = hashlib.sha256(parent.read_bytes()).hexdigest()[:12]
            return f"zip:{parent.name}:{digest}"
    # A source checkout: the kit's own repo, which is the parent of `src/`.
    kit_root = pkg.parent.parent.parent
    out = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=kit_root,
        capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
    )
    sha = out.stdout.strip()
    if not sha:
        return "src:unknown"
    # `+dirty` when the kit's own tree has uncommitted changes, because then
    # this identity is NOT RECONSTRUCTIBLE from any commit of any repo.
    #
    # `run.py` re-packs `runtime.zip` from the mother's WORKING TREE when the
    # CONTENT has changed -- not on every invocation. declutter reported the
    # hot-pull (ADR-0012) and I wrote "on every invocation" repeating their
    # phrasing without measuring it; agente_inmobiliario measured it and it is
    # wrong. Re-measured here in both directions, which is what makes it a
    # measurement rather than a swap of one assertion for another:
    #
    #   t1 mtime=1788632070 sha=901418cf4a89   <- mother had moved since packing
    #   t2 mtime=1788636129 sha=30540264ae2c
    #   t3 mtime=1788636129 sha=30540264ae2c   <- invoked again, nothing moved
    #
    # The distinction matters for this field rather than being pedantry: if it
    # re-packed per invocation, `zip:<digest>` would be an identity per RUN and
    # worth nothing. Being content-triggered it is a BETTER identity than
    # `src:<sha>` in one specific way -- it ignores commits that do not touch
    # the kit. Between 64b9283 and ea42a72 five files changed and one was
    # packaged; `src:` moved for all five, `zip:` only for the one that matters.
    # So declutter's three digests in a session are three real KIT CHANGES, not
    # three runs.
    #
    # The dirty case is what this marker is for. The mother runs from its
    # WORKING TREE, so on a normal development session -- when it is dirty --
    # the gates run code that exists in no commit anywhere, and the row records
    # the digest of an unrepeatable state.
    #
    # The field would still be telling the truth, and the truth would be "not
    # reconstructible". That is a different KIND of answer, the same way
    # `could_not_run` is a different kind from `blocked`, and the row has to
    # say which. ADR-0012 decides the hot-pull deliberately and this does not
    # argue with it -- it labels what the hot-pull produces.
    sucio = subprocess.run(
        ["git", "status", "--porcelain"], cwd=kit_root,
        capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
    )
    marca = "+dirty" if sucio.stdout.strip() else ""
    return f"src:{sha[:12]}{marca}"


def _kit_sha(root: Path) -> str | None:
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    return result.stdout.strip() or None


def _working_tree_fingerprint(root: Path) -> dict[str, tuple[int, int]] | None:
    """(tracked relpath -> (size, mtime_ns)) for every git-tracked file, or
    `None` when `root` is not a git repo at all.

    DEBT-GATE-RUNNER-CONCURRENT-WRITE-MISATTRIBUTION (Atlas DGX-409): a hook
    can be blamed for "files were modified" when a totally unrelated,
    concurrent process wrote to the SAME working tree during its run --
    measured live, 2026-09-01, a `git apply` from another session landing
    mid-run inside `tenancy-isolation`'s own 22s window. That verdict comes
    from `pre-commit` itself (third-party, out of this process's control),
    which diffs WORKING-TREE file content -- not `hook_receipts.
    staged_tree_fingerprint()`'s `git write-tree`, which only reflects the
    INDEX and would miss an unstaged `git apply` entirely. This is deliberately
    stat-only (size + mtime), never content hashing: it exists to answer "did
    anything change during my own window", cheaply enough to run twice per
    gate with no measurable latency added -- a stat per tracked file, not a
    read.
    """
    result = subprocess.run(
        ["git", "ls-files", "-z"], cwd=root, capture_output=True, check=False,
    )
    if result.returncode != 0:
        return None
    fingerprint: dict[str, tuple[int, int]] = {}
    for rel in result.stdout.decode("utf-8", "replace").split("\0"):
        if not rel:
            continue
        try:
            st = (root / rel).stat()
        except OSError:
            continue
        fingerprint[rel] = (st.st_size, st.st_mtime_ns)
    return fingerprint


def _tree_changes_during_window(
    before: dict[str, tuple[int, int]] | None,
    after: dict[str, tuple[int, int]] | None,
) -> list[str]:
    """Tracked paths whose (size, mtime) differ, or that appeared/disappeared,
    between two `_working_tree_fingerprint` snapshots -- sorted for a stable,
    diffable report. `[]` when either snapshot is unavailable (not a git repo):
    that is `COULD_NOT_RUN` for attribution, not "nothing changed", but this
    function only ever feeds an ADDITIONAL evidence field on an already-
    computed verdict, never the verdict itself, so it degrades to reporting
    nothing extra rather than blocking anything new."""
    if before is None or after is None:
        return []
    return sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))


@dataclass(frozen=True)
class GateOutcome:
    """Effective gate verdict, elapsed time, and unavailable checks."""

    returncode: int
    duration_ms: int
    # Lo decide `gate_could_not_run` LEYENDO la salida del hijo, no adivinando por
    # su codigo de salida. Por defecto False para que un constructor viejo (tests)
    # conserve la semantica anterior.
    could_not_run: bool = False
    subject_failed: bool = False
    # DEBT-GATE-RUNNER-CONCURRENT-WRITE-MISATTRIBUTION: tracked paths that
    # changed during THIS gate's own subprocess window, per
    # `_working_tree_fingerprint` -- evidence for attribution, never a verdict
    # by itself (a hook's own legitimate output lands here too).
    tree_changed_during_run: tuple[str, ...] = ()
    # DEBT-GATE-RUNNER-NEVER-WRITES-HALLAZGOS: the gate's own declared findings
    # count, parsed from its `HALLAZGOS: <int>` line (see `_parse_hallazgos`).
    # None when the child never printed the line -- absence, not zero; a gate
    # that has not adopted the convention yet must not read as "found nothing".
    hallazgos: int | None = None
    # Which detector produced those findings, parsed from the child's
    # `DETECTORES: {json}` line (see `_parse_detectores`). None -- field absent
    # in the row -- when the child never printed it, same rule as `hallazgos`.
    detectores: dict[str, int] | None = None


@dataclass(frozen=True)
class GateExecution:
    output: str
    returncode: int
    failure_log_ok: bool


def _telemetry_record(
    root: Path,
    name: str,
    hook: str,
    command: list[str],
    outcome: GateOutcome,
) -> dict[str, Any]:
    """One telemetry row. Existing fields keep their names and meanings;
    `duration_ms` is appended so the SPEC's "commit latency < 2s" target stops
    being an unmeasured claim. Measured with `time.perf_counter` around the
    child process itself -- not around telemetry or backlog bookkeeping.
    """
    returncode = outcome.returncode
    ts = datetime.now(timezone.utc).isoformat()
    subject_sha = _kit_sha(root)
    failed = returncode != 0 and (outcome.subject_failed or not outcome.could_not_run)
    record: dict[str, Any] = {
        "ts": ts,
        "repo": root.name,
        "hook": hook,
        "check": name,
        "status": "blocked" if failed else ("could_not_run" if outcome.could_not_run else "ok"),
        "rc": returncode,
        "fallos": int(failed),
        "could_not_run": int(outcome.could_not_run),
        "command": _redact_command(command),
        "kit_sha": subject_sha,
        "subject_sha": subject_sha,
        "kit_identity": kit_identity(),
        "duration_ms": outcome.duration_ms,
        "python_executable": sys.executable,
        "python_version": sys.version.split()[0],
        "skipped": _skipped_gates(),
        "skip_reason": os.environ.get("SIMPLECODE_SKIP_REASON", ""),
        "tree_changed_during_run": list(outcome.tree_changed_during_run),
        # Which push this row belongs to (see `main`). Empty when no outer
        # gate_runner minted one -- a direct `run_gate` call from a test or a
        # library caller. Stamped BEFORE `event_id` is derived so the row's
        # sha256 identity covers it.
        "run_id": os.environ.get("SIMPLECODE_RUN_ID", ""),
    }
    if outcome.hallazgos is not None:
        # Absent unless the child printed its own `HALLAZGOS: <int>` line
        # (DEBT-GATE-RUNNER-NEVER-WRITES-HALLAZGOS). Never defaulted to 0:
        # a gate that has not adopted the convention is unmeasured, not clean.
        record["hallazgos"] = outcome.hallazgos
    if outcome.detectores is not None:
        record["detectores"] = outcome.detectores
    record["event_id"] = hashlib.sha256(
        json.dumps(record, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()[:16]
    return record


# A pre-commit line for a check that did not run, e.g.
# `zero debt (staged, blocks)...........................(no files to check)Skipped`
_DID_NOT_RUN = re.compile(r"^(?P<check>.*?)\.{3,}.*Skipped\s*$", re.M)

# Tagged verdicts are the child protocol. A run can contain both a real
# finding and an unavailable check; both must survive in the telemetry row.
_TAG = r"\[[A-Za-z0-9][A-Za-z0-9_-]*\]"
_CNR_MARKER = re.compile(rf"^\s*{_TAG}\s+COULD_NOT_RUN\b", re.M)
_SUBJECT_VERDICT = re.compile(rf"^\s*{_TAG}\s+(?:FAIL|BLOCKED|FRAUD|NOT CLEAN)\b", re.M)
# DEBT-GATE-RUNNER-NEVER-WRITES-HALLAZGOS: a gate that has adopted the
# convention (see `simplecode.utils.gate_signal.emit_hallazgos`) prints this
# line exactly once, unconditionally, right before exiting -- on the clean
# path AND the blocking path alike. Absence means the gate has not adopted
# it yet, not that it found nothing; `_parse_hallazgos` returns None for that
# case and the caller must not substitute a zero. A gate that emits the line
# more than once (a multi-subcommand tool) is read on its LAST occurrence,
# printed closest to the final verdict.
_HALLAZGOS_LINE = re.compile(rf"^\s*{_TAG}\s+HALLAZGOS:\s*(\d+)\s*$", re.M)


def _parse_hallazgos(output: str) -> int | None:
    matches = _HALLAZGOS_LINE.findall(output)
    return int(matches[-1]) if matches else None


# Twin of `_HALLAZGOS_LINE` (`simplecode.utils.gate_signal.emit_detectores`):
# `{detector_id: count}` as one JSON object, read on its LAST occurrence.
_DETECTORES_LINE = re.compile(rf"^\s*{_TAG}\s+DETECTORES:\s*(\{{.*\}})\s*$", re.M)


def _parse_detectores(output: str) -> dict[str, int] | None:
    """None when the line is missing OR malformed: a count the runner cannot
    read is unmeasured, and recording a guess would invent attribution."""
    matches = _DETECTORES_LINE.findall(output)
    if not matches:
        return None
    try:
        parsed = json.loads(matches[-1])
    except json.JSONDecodeError:
        return None
    if not all(isinstance(k, str) and type(v) is int and v >= 0 for k, v in parsed.items()):
        return None
    return parsed


def gate_could_not_run(returncode: int, output: str) -> bool:
    """Record unavailable checks independently of real findings and the exit code."""
    return returncode in _NO_ARRANCO or bool(_CNR_MARKER.search(output))


def _report_not_run(name: str, output: str) -> None:
    """Print what did NOT run beside what did.

    A gate whose every check was skipped exits 0 and reads as green. On
    2026-08-24 that cost a real commit: a worktree fix was declared verified
    against a run whose eight checks had all been skipped for want of a staged
    file, and the defect it was meant to fix was still there. A report with rows
    that could not run is not a clean report, however many rows passed -- so
    name them. Silence here is the failure mode, which is why the count is
    printed rather than only the names.
    """
    skipped = [m.group("check").strip() for m in _DID_NOT_RUN.finditer(output)]
    if not skipped:
        return
    print(
        f"[gate-runner] {name}: {len(skipped)} check(s) DID NOT RUN: {', '.join(skipped)}",
        file=sys.stderr,
    )


def _record(telemetry: Path, record: dict[str, Any]) -> bool:
    try:
        atomic_io.append_jsonl(telemetry, record)
        return True
    except OSError as exc:
        print(f"[gate-runner] COULD_NOT_RUN telemetry: {exc}", file=sys.stderr)
        return False


def _clear_failure_logs(root: Path, name: str, command: list[str], enabled: bool) -> bool:
    if not enabled:
        return True
    failure = _failure_key(name, command)
    telemetry_failure = f"gate-telemetry: {name}: could not persist telemetry"
    return all((
        _log_gate_failure(root, failure, cleared=True),
        _log_gate_failure(root, telemetry_failure, cleared=True),
    ))


def _record_failure_logs(
    root: Path, telemetry_key: str, recorded: bool,
) -> None:
    if not recorded:
        _log_gate_failure(root, telemetry_key, cleared=False)


_PROCESS_GROUP_POLL_S = 0.1


def _prepare_gate_verdict(
    root: Path, name: str, command: list[str], options: GateOptions,
    execution: GateExecution,
) -> tuple[str, int, bool, bool]:
    output, returncode = execution.output, execution.returncode
    child_could_not_run = gate_could_not_run(returncode, output)
    child_failed = returncode != 0 and not child_could_not_run
    could_not_run = child_could_not_run
    if not execution.failure_log_ok:
        output = f"[gate-runner] COULD_NOT_RUN gate-failure log could not be cleared\n{output}"
        could_not_run = True
    if could_not_run and returncode == 0:
        returncode = 2
    if returncode == 0 and options.write_receipt and hook_receipts.write_receipt(root) is None:
        output = f"[gate-runner] COULD_NOT_RUN receipt: .git is missing or unwritable\n{output}"
        print("[gate-runner] COULD_NOT_RUN receipt: .git is missing or unwritable", file=sys.stderr)
        returncode = 2
        could_not_run = True
    failure_key = _failure_key(name, command)
    if returncode != 0 and options.own_failure and not _log_gate_failure(
        root, failure_key, cleared=False,
    ):
        output = f"[gate-runner] COULD_NOT_RUN gate-failure log could not be written\n{output}"
        could_not_run = True
    return output, returncode, could_not_run, child_failed


def _drain_process_group(pgid: int) -> None:
    """Block until process group `pgid` has no member left alive.

    DEBT-GATE-RUNNER-PREK-ORPHAN-TELEMETRY-RACE (2026-09-15): prek (ADR-0009)
    dispatches the pre-push hooks it wraps concurrently, and can exit while
    one of them is still running -- `run_gate`'s subprocess only waits for
    ITS direct child (prek) to exit via `communicate()`, never for prek's own
    children, so a hook process orphaned by prek's early exit kept writing
    telemetry.jsonl after the pre-push hook, and `git push`, had already
    returned control. Observed live: a `backlog_verifier --gate` process
    still alive 316s after the push attempt that started it had exited.

    `run_gate` launches its command with `start_new_session=True`, so `pgid`
    (the child's own pid, which becomes its process group id) covers the
    whole tree it spawns -- group membership survives reparenting to init,
    so this sees an orphan even after its immediate parent (prek) is gone.
    It does NOT see anything that escaped into its OWN new session, which is
    the escape hatch `simplecode.utils.detach.launch_detached` exists for:
    the `observe`/`growth-ratchet` pre-push hooks rely on that escape to
    keep returning immediately (SPEC-L133) -- this drain must never force
    them to wait, and it does not, because they are no longer members of
    this group by the time this runs.

    `os.killpg(pgid, 0)` cannot distinguish a zombie (already exited, only
    waiting for ITS parent to reap it -- and thus for any file write it was
    going to do, already done) from a genuinely running process, so this can
    over-wait slightly on a zombie under a slow reaper; `GATE_DRAIN_HARD_TIMEOUT`
    bounds that so a broken init that never reaps cannot wedge every future
    push in the repo, and says so instead of hanging silently.
    """
    started = time.monotonic()
    warned = False
    while True:
        try:
            os.killpg(pgid, 0)
        except (ProcessLookupError, PermissionError):
            return
        elapsed = time.monotonic() - started
        if elapsed >= GATE_DRAIN_HARD_TIMEOUT:
            print(
                f"[gate-runner] giving up waiting for process group {pgid} to empty "
                f"after {elapsed:.0f}s -- returning anyway (DEBT-GATE-RUNNER-PREK-"
                "ORPHAN-TELEMETRY-RACE: a lingering member may still write telemetry "
                "after this hook has already reported its result)",
                file=sys.stderr,
            )
            return
        if not warned and elapsed >= GATE_DRAIN_WARN_AFTER:
            print(
                f"[gate-runner] waiting for lingering process(es) in group {pgid} to "
                "exit before returning -- avoids an orphan still writing telemetry "
                "after this hook has already reported its result",
                file=sys.stderr,
            )
            warned = True
        time.sleep(min(_PROCESS_GROUP_POLL_S, GATE_DRAIN_HARD_TIMEOUT - elapsed))  # blocking-sleep: bounded poll, capped by GATE_DRAIN_HARD_TIMEOUT above -- DEBT-GATE-RUNNER-PREK-ORPHAN-TELEMETRY-RACE  # sunset-reviewed: 9.6 -- sondeo ACOTADO por el tope duro GATE_DRAIN_HARD_TIMEOUT de arriba, no una espera de duracion fija. Un proceso que hay que drenar exige ceder la CPU entre comprobaciones: es el patron CORRECTO y no deuda diferida, asi que no se etiqueta a una version en la que nunca se 'arreglara'. Es la misma forma a la que se convirtieron el 2026-09-15 los tres sleeps de duracion fija de los tests (fixture wait_until en tests/conftest.py)


def run_gate(
    root: Path,
    name: str,
    hook: str,
    command: list[str],
    options: GateOptions = GateOptions(),
) -> int:
    """Run once, block unavailable checks, and persist redacted evidence."""
    root = root.resolve()
    failure_log_ok = _clear_failure_logs(root, name, command, options.own_failure)

    started = time.perf_counter()
    tree_before = _working_tree_fingerprint(root)
    # A gate that reads the source tree holds it SHARED for its whole run, orphans
    # included, so the mutating lane of coverage-100 (tree_lock) cannot rewrite a
    # real file under it when prek runs the two at once. The wait counts in the
    # gate's duration on purpose: it is time this gate cost the push.
    holds_tree = tree_lock.shared(root) if name in tree_lock.READERS else contextlib.nullcontext()
    try:
        with holds_tree:
            proc = subprocess.Popen(
                command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, errors="replace", start_new_session=True,
            )
            stdout, stderr = proc.communicate()
            returncode = proc.returncode
            output = _redact(stdout + stderr)
            _drain_process_group(proc.pid)
    except OSError as exc:
        returncode = 127
        output = f"COULD_NOT_RUN: {exc}\n"
    output, returncode, could_not_run, child_failed = _prepare_gate_verdict(
        root, name, command, options, GateExecution(output, returncode, failure_log_ok),
    )
    duration_ms = int((time.perf_counter() - started) * 1000)
    tree_changed = _tree_changes_during_window(tree_before, _working_tree_fingerprint(root))

    if output:
        print(output, end="" if output.endswith("\n") else "\n")
    _report_not_run(name, output)
    if tree_changed:
        print(
            f"[gate-runner] {name}: tracked path(s) changed during this gate's own window "
            f"(attribution evidence, not a verdict by itself): {', '.join(tree_changed)}",
            file=sys.stderr,
        )

    telemetry = _telemetry_path(root, options.telemetry)
    outcome = GateOutcome(
        returncode=returncode,
        duration_ms=duration_ms,
        could_not_run=could_not_run,
        subject_failed=bool(_SUBJECT_VERDICT.search(output)) or child_failed,
        tree_changed_during_run=tuple(tree_changed),
        # A COULD_NOT_RUN gate never measured the subject, so any HALLAZGOS
        # line it happened to print (e.g. from a prior real run's leftover
        # buffering) must not be read as a finding count either.
        hallazgos=None if could_not_run else _parse_hallazgos(output),
        detectores=None if could_not_run else _parse_detectores(output),
    )
    recorded = _record(telemetry, _telemetry_record(root, name, hook, command, outcome))
    if returncode == 0 and recorded:
        return 0

    hook_receipts.consume_receipt(root)
    _record_failure_logs(
        root, f"gate-telemetry: {name}: could not persist telemetry", recorded,
    )
    if returncode == 0:
        print("[gate-runner] FAIL: telemetry could not be persisted; see gate-failure log", file=sys.stderr)
        return 2
    digest = hashlib.sha256(output.encode("utf-8")).hexdigest()[:12]
    ownership = "see .simplecode/evidence/gate_failures.jsonl" if options.own_failure else "failure propagated; see child diagnostics"
    print(
        f"[gate-runner] FAIL: {name} exited {returncode}; "
        f"{ownership}; redacted output sha256={digest}",
        file=sys.stderr,
    )
    return returncode


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--name", required=True)
    parser.add_argument("--hook", default="manual")
    parser.add_argument("--telemetry", type=Path)
    parser.add_argument("--receipt", action="store_true")
    parser.add_argument(
        "--propagate-only",
        action="store_true",
        help="Do not duplicate a command failure already owned by a child gate",
    )
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a command is required after --")
    announce_bypass()
    if _skip_self(args.name):
        reason = os.environ.get("SIMPLECODE_SKIP_REASON", "").strip()
        print(
            f"[gate-runner] SKIPPED: {args.name} (SKIP names this gate's own --name; "
            f"the wrapped command was NOT run){' -- ' + reason if reason else ''}",
            file=sys.stderr,
        )
        return 0
    # DEBT-AEQUITAS-06: one push = one run id, minted by the OUTERMOST
    # gate_runner (the `--name pre-push` wrapper `hook_install.py` generates)
    # and INHERITED by every gate_runner prek/pre-commit spawns underneath it
    # (`subprocess.run` passes `os.environ` through by default). `setdefault`,
    # never assignment: a child minting its own id would make every row look
    # like its own separate run, which is exactly the property
    # `telemetry_dispositions`'s `same_run` bucket relies on to tell "blocked
    # a moment ago, by THIS push" apart from "blocked by an earlier push and
    # never judged". An id, not a clock: the grace window it replaces was
    # measured shorter than a single run (33 red pushes in simplecode, 20 in
    # Atlas, over 12 days).
    # `setdefault` alone is not enough: a variable exported EMPTY (measured
    # 2026-09-15 with `SIMPLECODE_RUN_ID= python .simplecode/run.py ...`) counts
    # as set, so every child would inherit "" and no row would ever be
    # `same_run`. Empty is absent.
    if not os.environ.get("SIMPLECODE_RUN_ID"):
        os.environ["SIMPLECODE_RUN_ID"] = f"{int(time.time())}-{os.getpid()}"
    return run_gate(
        args.root,
        args.name,
        args.hook,
        command,
        GateOptions(
            telemetry=args.telemetry,
            write_receipt=args.receipt,
            own_failure=not args.propagate_only,
        ),
    )


if __name__ == "__main__":
    raise SystemExit(main())
