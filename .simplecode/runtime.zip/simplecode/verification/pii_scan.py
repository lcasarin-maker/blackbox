#!/usr/bin/env python3
"""Bloquea datos personales de terceros en `tasks/` y `docs/`. Seguridad: no se recorta.

Lo pidio la sesion aequitas_os el 2026-09-02 tras un incidente real: un agente pego en una
ficha una tabla con **20 RFC y razones sociales de clientes reales**, y la migracion del canon
la copio verbatim a `ledger/entries/`. El repo se publica en GitHub. Lo redactaron en los dos
sitios antes de que entrara a la historia.

La regla del canon: **fichas, entradas y evidencia llevan CONTEOS y NOMBRES DE ARCHIVO, nunca
RFC, CURP, razones sociales, folios ni texto de clientes.** Un hallazgo se describe por su forma
y su tamano, no por su contenido identificable.

Tambien se bloquean correos y telefonos mexicanos con separadores. El barrido usa
`git ls-files` con el entorno de hooks saneado: revisa solo contenido versionado y
un `GIT_DIR` heredado nunca lo redirige a otro repositorio.

**Las exenciones estan declaradas y son la parte que hace usable el control.** Un barrido que da
un numero irreducible se apaga; uno que puede llegar a cero se respeta. Medido en la flota:

  - **Ids de hash con forma de RFC**: `CONV-DEBT-DBB092660AB4` casa el patron por casualidad.
    1 ficha de las 2,044 de la flota. Sin esta exencion, office2office nunca llega a cero.
  - **RFC generico oficial** `XAXX010101000` (publico) y valores de prueba tipo `BETA010203AB1`.
  - **El RFC propio del repo**, declarado en `tasks/pii_allow.txt` una vez por repo.
    Medido: aequitas_os usa `SPG081028LV3` y poe_systems `POE930217QIA` en fichas legitimas
    sobre su propia FIEL.
  - **Fixtures declarados**: lineas que dicen `[SIMULACION]` o viven en un test, y archivos
    con `<!-- pii:sintetico -->`. Desde 2026-09-27 la declaracion solo exime valores que el
    gate prueba sinteticos (verificador de RFC/CURP que no cuadra, dominio de correo
    reservado); un dato con forma real sigue cazado aunque la linea diga `fixture`.
  - **Formas que no son correo** (unit de systemd con instancia, archivo de iconos DEP-11),
    **direcciones de rol exactas** (`PERMITIDOS_FIJOS`) y los dominios `example.com/.net/.org`
    de RFC 2606, sin declaracion y en cualquier contexto.

Uso:
    python -m simplecode.verification.pii_scan --root .

Migrado el 2026-09-04 de `gates/pii_scan.py`, copiado sin pasar por `cli_new`/`satellite_sync`
a cada satelite. La copia de simplecode habia quedado ATRASADA respecto a aequitas_os y Atlas:
seguia apuntando a `ledger/pii_allow.txt`, una ruta retirada de la flota el 2026-09-02 (ver
`permitidos()` abajo) -- el mismo defecto de fondo que esta migracion existe para cerrar, esta
vez encontrado en el propio "canon". Como modulo de `simplecode.verification`, este archivo
viaja en runtime.zip y ningun satelite vuelve a tener su propia copia que pueda divergir.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
from collections.abc import Iterator
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.tool_limits import GIT_SCAN_TIMEOUT

AMBITOS = ("tasks", "docs")
# Direcciones de ROL publicadas por proyectos, no de personas: `cudatools@nvidia.com` es la
# etiqueta del Release firmado de NVIDIA y `ftpmaster@ubuntu.com` el UID de la llave de archivo
# de Ubuntu; aparecen en cualquier volcado de apt/gpgv. Cadena EXACTA, nunca el dominio:
# `persona@nvidia.com` o `persona@ubuntu.com` siguen cazados (blackbox, 2026-10-04).
PERMITIDOS_FIJOS = {"XAXX010101000", "XEXX010101000", "noreply@anthropic.com",
                    "cudatools@nvidia.com", "ftpmaster@ubuntu.com"}
RFC = re.compile(r"\b[A-Z&Ñ]{3,4}-?[0-9]{6}-?[A-Z0-9]{3}\b")
CURP = re.compile(r"\b[A-Z]{4}[0-9]{6}[HM][A-Z]{5}[A-Z0-9]{2}\b")
CORREO = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
TELEFONO = re.compile(
    r"(?<![\w-])(?:\+?52[\s.-]?)?"
    r"(?:\(\d{2,3}\)\s?\d{3,4}[\s.-]?\d{4}|\d{2,3}[\s.-]\d{3,4}[\s.-]\d{4})(?![\w-])"
)
EXENTA_LINEA = re.compile(r"\[SIMULACION\]|fixture|_test|test_|NO es secreto", re.I)
# Un archivo entero puede DECLARARSE sintetico con este marcador en sus primeras 20 lineas.
# Existe porque un documento de ejemplo legal contiene una identidad completa inventada
# --nombre, cedula, RFC, telefono, correo-- y el escaner no puede distinguirla de una real.
# La salida correcta no es eximirla en silencio ni dejar el gate en rojo para siempre: es que
# el documento DIGA lo que es. Un marcador es una afirmacion que alguien firma; una exencion
# en el codigo del gate es una que nadie ve.
MARCADOR_SINTETICO = re.compile(r"<!--\s*pii:sintetico\s*-->", re.I)
# DEBT-GATE-ENGANABLE-PII-SCAN (auditoria 2026-09-26, cerrada 2026-09-27): la afirmacion de
# arriba NO se verificaba. Un `(fixture)` al final de una linea con datos reales, o el
# marcador en la cabecera de un archivo con datos reales, daba `hallazgos=0`. Ahora una
# declaracion (palabra de EXENTA_LINEA o marcador) solo exime un valor que el gate PUEDE
# PROBAR que no es de nadie: un RFC o una CURP cuyo digito verificador no cuadra (todo RFC
# emitido por el SAT y toda CURP de RENAPO lo cumplen) o un correo en un dominio reservado
# por RFC 2606/6761. Un telefono no tiene forma sintetica decidible en Mexico: la declaracion
# nunca lo exime; se escribe enmascarado (`55-XXXX-XXXX`) o se firma en `tasks/pii_allow.txt`.
_RFC_ALFABETO = "0123456789ABCDEFGHIJKLMN&OPQRSTUVWXYZ Ñ"
_CURP_ALFABETO = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"
_DOMINIO_RESERVADO = re.compile(
    r"(?:\A|\.)(?:example\.(?:com|net|org)|example|test|invalid|localhost)\Z", re.I
)
# DGX-409 (Atlas, 2026-09-06): la exencion de "id de hash con forma de RFC" solo
# comparaba contra el STEM del propio fichero (`id_del_archivo` mas abajo), asi que
# cubria el caso donde el hash vive en su propio archivo (`CONV-DEBT-<hash>.md`)
# pero no el caso donde OTRO fichero lo CITA -- un registro/manifiesto en `.json`
# que referencia varios `CONV-DEBT-<hash>` por nombre. Ese .json no existia como
# hallazgo antes de DECL-GOV-113 porque el barrido solo miraba `.md`; al ampliarse
# a todo texto, quedo expuesto. Reproducido en este repo: un `tasks/registro.json`
# con `{"id": "CONV-DEBT-DBB092660AB4"}` daba 2 hallazgos falsos con el codigo
# anterior.
#
# La regla estructural: un RFC/CURP real de una persona nunca se escribe pegado
# con un guion a OTRA palabra en mayusculas (nadie firma "CONV-DEBT-GARC800101AB2").
# Un identificador interno compuesto (`CONV-DEBT-`, `DEBT-`, `DGX-`, `ADR-`, y
# cualquier otro que la flota invente despues) SI se escribe asi -- por eso se
# detecta por FORMA (palabra en mayusculas + guion pegado al match), no por una
# lista de prefijos que habria que mantener cada vez que un satelite acuñe uno
# nuevo.
_PREFIJO_COMPUESTO = re.compile(r"(?<![A-Za-z0-9])[A-Z]+(?:-[A-Z]+)*-$")
# Una unit de systemd con instancia (`user@1000.service`, `getty@tty1.service`,
# `org.gnome.Shell@x11.service`) tiene la forma exacta de una direccion: local, arroba,
# "dominio", punto, "tld". Lo unico que la separa de un correo es que su TLD es un TIPO de unit,
# y ninguno de estos es un TLD delegado. Se decide sobre el MATCH ENTERO, nunca sobre un
# fragmento: `nombre.apellido@empresa.com.mx` no termina en un tipo de unit, asi que se sigue
# cazando entero, que es lo unico que el gate imprime (medido por blackbox, 2026-09-25).
_UNIDAD_SYSTEMD = re.compile(
    r"\A[A-Za-z0-9._%+-]+@[A-Za-z0-9.:-]+\."
    r"(?:service|socket|target|timer|mount|automount|slice|scope|swap|device|path)\Z"
)
# Archivo de iconos HiDPI de DEP-11 (`icons-64x64@2.tar`, `icons-128x128@2.tar.gz`): misma
# forma de direccion, pero el "dominio" `2.tar` no existe (`tar`/`gz` no son TLD). Se decide
# por FORMA del match entero y en cualquier contexto: tamano repetido (48/64/128), `@2`, y
# `.tar` o `.tar.gz`; cualquier otro local-part o dominio sigue cazado (blackbox, 2026-10-04).
_ARCHIVO_ICONOS_DEP11 = re.compile(r"\Aicons-(48|64|128)x\1@2\.tar(?:\.gz)?\Z")
# Dominios de documentacion de RFC 2606 §3: ningun buzon de persona puede vivir ahi. Solo los
# tres EXACTOS -- `example.com.mx`, `mi-example.com` o un subdominio siguen cazados. El resto
# de dominios reservados (`.test`, `.invalid`, `.localhost`) solo se exime con declaracion.
_DOMINIO_DE_EJEMPLO = re.compile(r"example\.(?:com|net|org)", re.I)
_APT_RELEASE_DEP11_ROW = re.compile(
    r"\A\s*(?:[0-9a-f]{32}|[0-9a-f]{40}|[0-9a-f]{64}|[0-9a-f]{96}|[0-9a-f]{128})"
    r"\s+(?:0|[1-9][0-9]{0,19})\s+"
    r"(?:main|restricted|universe|multiverse)/dep11/"
    r"(?P<archive>icons-(?P<size>48|64|128)x(?P=size)@2\.tar(?:\.gz)?)\s*\Z"
)
_APT_INDEX_DEP11_ROW = re.compile(
    r"/var/lib/apt/lists/ports\.ubuntu\.com_ubuntu-ports_dists_"
    r"(?P<suite>[a-z0-9-]+)_(?P<section>main|restricted|universe|multiverse)_"
    r"dep11_icons-64x64%402\.tar\.gz\|(?P=section)/dep11/"
    r"(?P<archive>icons-64x64@2\.tar)\|http://ports\.ubuntu\.com/ubuntu-ports/dists/"
    r"(?P=suite)/\|(?P=suite)\|\$\(ARCHITECTURE\)\|DEP-11-icons-hidpi"
)
_APT_INDEX_DEP11_SIX_FIELDS = re.compile(
    r"/var/lib/apt/lists/ports\.ubuntu\.com_ubuntu-ports_dists_"
    r"(?P<suite>[a-z0-9-]+)_(?P<section>main|restricted|universe|multiverse)_"
    r"dep11_icons-64x64%402\.tar\.gz\|(?P=section)/dep11/"
    r"(?P<archive>icons-64x64@2\.tar)\|http://ports\.ubuntu\.com/ubuntu-ports\|"
    r"(?P=suite)\|DEP-11-icons-hidpi\|\$\(ARCHITECTURE\)"
)
_APT_INDEX_DEP11_JSON_META_KEY = re.compile(
    r'\A\s*"meta_key": "(?P<section>main|restricted|universe|multiverse)'
    r'/dep11/icons-64x64@2\.tar",?\s*\Z'
)
_APT_INDEX_DEP11_JSON_FILENAME = re.compile(
    r"/var/lib/apt/lists/ports\.ubuntu\.com_ubuntu-ports_dists_"
    r"(?P<suite>[a-z0-9-]+)_(?P<section>main|restricted|universe|multiverse)_"
    r"dep11_icons-64x64%402\.tar\.gz\Z"
)
_APT_META_KEY_CONFIG = re.compile(
    r'\AAcquire::IndexTargets::deb::(?P<target>DEP-11-icons-hidpi|'
    r'DEP-11-icons-large-hidpi)::MetaKey "\$\(COMPONENT\)/dep11/'
    r'(?P<archive>icons-(?:64|128)x(?:64|128)@2\.tar)";\Z'
)
_APT_INDEX_TARGET_HIDPI = re.compile(
    r'\A(?P<component>main|restricted|universe|multiverse)/dep11/'
    r'(?P<archive>icons-64x64@2\.tar)\Z'
)
_NVIDIA_SIGNED_LABEL = re.compile(
    r"\ALabel: NVIDIA CORPORATION <(?P<address>cudatools@nvidia\.com)>\Z"
)
_NVIDIA_SIGNED_ORIGIN = "Origin: https://nvidia.github.io/libnvidia-container/stable"
_UBUNTU_ARCHIVE_GPGV = re.compile(
    r"gpgv: Signature made .*?\\ngpgv:\s+using RSA key F6ECB3762474EDA9D21B7022871920D1991BC93C"
    r"\\ngpgv:\s+Good signature from "
    r"\\?\"Ubuntu Archive Automatic Signing Key \(2018\) <(?P<address>ftpmaster@ubuntu\.com)>\\?\"",
    re.DOTALL,
)
_GIT_ENV = {k: v for k, v in os.environ.items()
            if k not in {"GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_CEILING_DIRECTORIES"}}


def _tracked_files(root: Path, scope: str) -> set[Path] | None:
    """Tracked files in one scope, independent of Git hook environment leakage."""
    try:
        result = subprocess.run(
            ["git", "ls-files", "-z", "--", scope], cwd=root, capture_output=True,
            check=True, timeout=GIT_SCAN_TIMEOUT, env=_GIT_ENV,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return {root / path for path in result.stdout.decode("utf-8", "replace").split("\0") if path}


def es_unidad_systemd(valor: str) -> bool:
    """True si `valor` (un match ENTERO de CORREO) es el nombre de una unit de systemd con instancia."""
    return bool(_UNIDAD_SYSTEMD.match(valor))


def es_archivo_iconos_dep11(valor: str) -> bool:
    """True si `valor` (un match ENTERO de CORREO) es un archivo de iconos HiDPI de DEP-11."""
    return bool(_ARCHIVO_ICONOS_DEP11.match(valor))


def es_dominio_de_ejemplo(valor: str) -> bool:
    """True si el dominio de `valor` es exactamente example.com/.net/.org (RFC 2606)."""
    return bool(_DOMINIO_DE_EJEMPLO.fullmatch(valor.rsplit("@", 1)[1]))


def es_ruta_dep11_release(linea: str, inicio: int) -> bool:
    """Only recognize the DEP-11 HiDPI archive as a path in a hash/size Release row."""
    match = _APT_RELEASE_DEP11_ROW.fullmatch(linea)
    if match is not None:
        return match.start("archive") <= inicio < match.end("archive")
    return any(
        match.start("archive") <= inicio < match.end("archive")
        for pattern in (_APT_INDEX_DEP11_ROW, _APT_INDEX_DEP11_SIX_FIELDS)
        for match in pattern.finditer(linea)
    )


def _unique_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON object key")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"invalid JSON constant: {value}")


def _json_object_span_for_key_line(
    text: str, line_start: int, line_end: int, key_name: str = "meta_key"
) -> tuple[int, int] | None:
    decoder = json.JSONDecoder()
    object_starts: list[int] = []
    object_ends: dict[int, int] = {}
    owner_start: int | None = None
    position = 0
    while position < len(text):
        character = text[position]
        if character == '"':
            value, string_end = decoder.raw_decode(text, position)
            following = string_end
            while following < len(text) and text[following].isspace():
                following += 1
            if (
                value == key_name
                and following < len(text)
                and text[following] == ":"
                and line_start <= position < line_end
                and object_starts
            ):
                owner_start = object_starts[-1]
            position = string_end
        elif character == "{":
            object_starts.append(position)
            position += 1
        elif character == "}":
            start = object_starts.pop()
            object_ends[start] = position + 1
            position += 1
        else:
            position += 1
    if owner_start is None or owner_start not in object_ends:
        return None
    return owner_start, object_ends[owner_start]


def _json_top_level_value_span(
    text: str, key_name: str, opener: str, closer: str
) -> tuple[int, int] | None:
    """Find a container value owned by an exact top-level JSON key."""
    decoder = json.JSONDecoder()
    stack: list[str] = []
    position = 0
    while position < len(text):
        character = text[position]
        if character == '"':
            value, string_end = decoder.raw_decode(text, position)
            following = string_end
            while following < len(text) and text[following].isspace():
                following += 1
            if (
                value == key_name
                and stack == ["{"]
                and following < len(text)
                and text[following] == ":"
            ):
                value_start = following + 1
                while value_start < len(text) and text[value_start].isspace():
                    value_start += 1
                if value_start < len(text) and text[value_start] == opener:
                    return _json_matching_container_end(
                        text, value_start, opener, closer, decoder
                    )
                return None
            position = string_end
        elif character in "{[":
            stack.append(character)
            position += 1
        elif character in "}]":
            if stack:
                stack.pop()
            position += 1
        else:
            position += 1
    return None


def _json_matching_container_end(
    text: str,
    container_start: int,
    opener: str,
    closer: str,
    decoder: json.JSONDecoder,
) -> tuple[int, int] | None:
    depth = 0
    position = container_start
    while position < len(text):
        if text[position] == '"':
            _value, position = decoder.raw_decode(text, position)
        elif text[position] == opener:
            depth += 1
            position += 1
        elif text[position] == closer:
            depth -= 1
            position += 1
            if depth == 0:
                return container_start, position
        else:
            position += 1
    return None


def _json_direct_string_property(
    text: str, object_span: tuple[int, int], key_name: str
) -> tuple[int, int, str] | None:
    """Find an exact direct string property, never a nested clone with the same key."""
    decoder = json.JSONDecoder()
    position = object_span[0] + 1
    while position < object_span[1] - 1:
        while position < object_span[1] and text[position].isspace():
            position += 1
        if position >= object_span[1] or text[position] == "}":
            return None
        key, key_end = decoder.raw_decode(text, position)
        position = key_end
        while position < object_span[1] and text[position].isspace():
            position += 1
        if position >= object_span[1] or text[position] != ":":
            return None
        position += 1
        while position < object_span[1] and text[position].isspace():
            position += 1
        value_start = position
        value, value_end = decoder.raw_decode(text, value_start)
        if key == key_name:
            return (
                (value_start, value_end, value)
                if isinstance(value, str)
                else None
            )
        position = value_end
        while position < object_span[1] and text[position].isspace():
            position += 1
        if position < object_span[1] and text[position] == ",":
            position += 1
    return None


def _json_direct_string_at_offset(
    text: str, object_span: tuple[int, int], key_name: str, source_offset: int
) -> tuple[str, int] | None:
    property_span = _json_direct_string_property(text, object_span, key_name)
    if property_span is None:
        return None
    value_start, value_end, value = property_span
    if not value_start <= source_offset < value_end - 1:
        return None
    prefix = json.loads(text[value_start:source_offset] + '"')
    return value, len(prefix)


def _json_meta_owner(lineas: list[str], numero: int) -> dict[str, object] | None:
    """Decode only the object owning this source line; malformed/ambiguous JSON stays visible."""
    if not 1 <= numero <= len(lineas):
        return None
    text = "\n".join(lineas)
    try:
        json.loads(
            text,
            object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
        )
    except (json.JSONDecodeError, RecursionError, ValueError):
        return None
    line_start = sum(len(line) + 1 for line in lineas[:numero - 1])
    line_end = line_start + len(lineas[numero - 1])
    span = _json_object_span_for_key_line(text, line_start, line_end)
    if span is None:
        return None
    owner_start, owner_end = span
    owner = json.loads(
        text[owner_start:owner_end],
        object_pairs_hook=_unique_json_object,
        parse_constant=_reject_json_constant,
    )
    return owner if isinstance(owner, dict) else None


def _json_string_at_offset(text: str, offset: int) -> tuple[str, int] | None:
    """Return decoded string token and its decoded offset for a raw source position."""
    decoder = json.JSONDecoder()
    position = 0
    while position < len(text):
        if text[position] != '"':
            position += 1
            continue
        value, end = decoder.raw_decode(text, position)
        if isinstance(value, str) and position <= offset < end - 1:
            prefix = json.loads(text[position:offset] + '"')
            return value, len(prefix)
        position = end
    return None


def _apt_config_meta_key_json(
    lineas: list[str], numero: int, valor: str, inicio: int
) -> bool:
    if not 1 <= numero <= len(lineas):
        return False
    text = "\n".join(lineas)
    try:
        doc = json.loads(
            text, object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
        )
    except (json.JSONDecodeError, RecursionError, ValueError):
        return False
    if not isinstance(doc, dict) or doc.get("command") != ["apt-config", "dump"]:
        return False
    config_lines = doc.get("selected_configuration_lines")
    if (
        doc.get("returncode") != 0
        or not isinstance(config_lines, list)
        or not all(isinstance(item, str) for item in config_lines)
    ):
        return False
    source_offset = sum(len(line) + 1 for line in lineas[:numero - 1]) + inicio
    token = _json_string_at_offset(text, source_offset)
    if token is None:
        return False
    config_line, token_offset = token
    array_span = _json_top_level_value_span(
        text, "selected_configuration_lines", "[", "]"
    )
    if config_line not in config_lines:
        return False
    if array_span is None or not array_span[0] < source_offset < array_span[1]:
        return False
    match = _APT_META_KEY_CONFIG.fullmatch(config_line)
    if match is None:
        return False
    archive = match.group("archive")
    return (
        valor == archive
        and token_offset == match.start("archive")
        and (match.group("target"), archive) in {
            ("DEP-11-icons-hidpi", "icons-64x64@2.tar"),
            ("DEP-11-icons-large-hidpi", "icons-128x128@2.tar"),
        }
    )


def _apt_index_row_json(
    lineas: list[str], numero: int, valor: str, inicio: int
) -> bool:
    if not 1 <= numero <= len(lineas):
        return False
    text = "\n".join(lineas)
    try:
        doc = json.loads(
            text, object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
        )
    except (json.JSONDecodeError, RecursionError, ValueError):
        return False
    query = _valid_apt_index_query(doc)
    if query is None:
        return False
    source_offset = sum(len(line) + 1 for line in lineas[:numero - 1]) + inicio
    index_query_span = _json_top_level_value_span(text, "index_query", "{", "}")
    if index_query_span is None:
        return False
    token = _json_direct_string_at_offset(
        text, index_query_span, "stdout", source_offset
    )
    if token is None:
        return False
    stdout, token_offset = token
    if stdout != query["stdout"]:
        return False
    return _apt_four_field_row(stdout, token_offset, valor)


def _valid_apt_index_query(doc: object) -> dict[str, object] | None:
    if not isinstance(doc, dict):
        return None
    query = doc.get("index_query")
    if not isinstance(query, dict):
        return None
    expected = [
        "apt-get", "indextargets",
        "--format=$(SITE)|$(RELEASE)|$(METAKEY)|$(IDENTIFIER)",
    ]
    if query.get("command") != expected or query.get("returncode") != 0:
        return None
    return query if isinstance(query.get("stdout"), str) else None


def _apt_four_field_row(stdout: str, token_offset: int, valor: str) -> bool:
    row_start = stdout.rfind("\n", 0, token_offset) + 1
    row_end = stdout.find("\n", token_offset)
    row = stdout[row_start:len(stdout) if row_end < 0 else row_end]
    fields = row.split("|")
    if len(fields) != 4:
        return False
    site, suite, meta_key, identifier = fields
    meta = _APT_INDEX_TARGET_HIDPI.fullmatch(meta_key)
    return (
        meta is not None
        and site == "http://ports.ubuntu.com/ubuntu-ports"
        and re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", suite) is not None
        and identifier == "DEP-11-icons-hidpi"
        and valor == meta.group("archive")
        and token_offset - row_start
        == len(site) + 1 + len(suite) + 1 + len(meta.group("component")) + len("/dep11/")
    )


def es_meta_key_dep11_json(lineas: list[str], numero: int, valor: str) -> bool:
    """Recognize only a JSON row whose sibling fields form the exact DEP-11 identity."""
    if not 1 <= numero <= len(lineas):
        return False
    meta = _APT_INDEX_DEP11_JSON_META_KEY.fullmatch(lineas[numero - 1])
    if meta is None or valor != "icons-64x64@2.tar":
        return False
    record = _json_meta_owner(lineas, numero)
    if record is None:
        return False
    filename = record.get("filename")
    filename_match = (
        _APT_INDEX_DEP11_JSON_FILENAME.fullmatch(filename)
        if isinstance(filename, str) else None
    )
    return (
        filename_match is not None
        and filename_match.group("suite") == record.get("suite")
        and filename_match.group("section") == meta.group("section")
        and record.get("meta_key") == f"{meta.group('section')}/dep11/{valor}"
        and record.get("site") == "http://ports.ubuntu.com/ubuntu-ports"
        and record.get("architecture") == "$(ARCHITECTURE)"
        and record.get("identifier") == "DEP-11-icons-hidpi"
    )


def es_contacto_firmante_ubuntu(valor: str, linea: str, inicio: int) -> bool:
    """Recognize only Ubuntu's published archive-key contact in its exact gpgv transcript."""
    match = _UBUNTU_ARCHIVE_GPGV.search(linea)
    return (valor == "ftpmaster@ubuntu.com" and match is not None
            and match.start("address") <= inicio < match.end("address"))


def es_contacto_etiqueta_nvidia(
    valor: str, lineas: list[str], numero: int, inicio: int
) -> bool:
    """Classify NVIDIA's public role contact in the exact Release-header shape.

    This is structural classification of a known institutional address, not
    cryptographic signature verification.
    """
    if valor != "cudatools@nvidia.com" or not 1 <= numero <= len(lineas):
        return False
    label = _NVIDIA_SIGNED_LABEL.fullmatch(lineas[numero - 1])
    return (
        label is not None
        and label.start("address") <= inicio < label.end("address")
        and lineas[:1] == ["-----BEGIN PGP SIGNED MESSAGE-----"]
        and _NVIDIA_SIGNED_ORIGIN in lineas
        and "-----BEGIN PGP SIGNATURE-----" in lineas
        and "-----END PGP SIGNATURE-----" in lineas
    )


def _correo_exento_por_contexto(
    valor: str, lineas: list[str], linea: str, numero: int, inicio: int
) -> bool:
    return (
        es_unidad_systemd(valor)
        or es_archivo_iconos_dep11(valor)
        or es_dominio_de_ejemplo(valor)
        or es_ruta_dep11_release(linea, inicio)
        or es_meta_key_dep11_json(lineas, numero, valor)
        or _apt_config_meta_key_json(lineas, numero, valor, inicio)
        or _apt_index_row_json(lineas, numero, valor, inicio)
        or es_contacto_firmante_ubuntu(valor, linea, inicio)
        or es_contacto_etiqueta_nvidia(valor, lineas, numero, inicio)
    )


def rfc_verificador_cuadra(valor: str) -> bool:
    """True si el ultimo caracter del RFC es el digito verificador del SAT (modulo 11).

    El RFC de persona moral (12) se alinea al de persona fisica (13) con un espacio a la
    izquierda. Todo caracter que RFC deja pasar esta en el alfabeto: no hay rama de error.
    """
    v = valor.replace("-", "").rjust(13)
    resto = sum(_RFC_ALFABETO.index(c) * (13 - i) for i, c in enumerate(v[:12])) % 11
    esperado = "0" if resto == 0 else "A" if resto == 1 else str(11 - resto)
    return v[12] == esperado


def curp_verificador_cuadra(valor: str) -> bool:
    """True si el caracter 18 de la CURP es el digito verificador de RENAPO (modulo 10)."""
    suma = sum(_CURP_ALFABETO.index(c) * (18 - i) for i, c in enumerate(valor[:17]))
    return valor[17] == str((10 - suma % 10) % 10)


def no_puede_ser_real(patron: re.Pattern[str], valor: str) -> bool:
    """True si el valor es demostrablemente de nadie: lo unico que una declaracion exime."""
    if patron is RFC:
        return not rfc_verificador_cuadra(valor)
    if patron is CURP:
        return not curp_verificador_cuadra(valor)
    if patron is CORREO:
        return bool(_DOMINIO_RESERVADO.search(valor.rsplit("@", 1)[1]))
    return False


def es_identificador_compuesto(linea: str, inicio: int) -> bool:
    """True si el match en `linea[inicio:]` esta pegado a un prefijo tipo `X-Y-`."""
    return bool(_PREFIJO_COMPUESTO.search(linea[:inicio]))


def es_texto(f: Path) -> bool:
    """Un fichero es texto si sus primeros 8 KiB no llevan un byte NUL.

    DECL-GOV-113 (declutter, 2026-09-06): este gate recorria `*.md` y nada mas,
    asi que los `.txt` de `tasks/evidence/` -- que el contrato de cierre de ficha
    OBLIGA a escribir -- no se miraban nunca. Medido en la flota: 1.686 ficheros
    invisibles en 13 repos frente a 4.971 `.md` recorridos; en este repo, 358
    invisibles de 1.016. El defecto no es el patron, es el alcance por extension.

    Se sniffea el contenido en vez de enumerar extensiones a proposito: una lista
    de extensiones es exactamente lo que acaba de fallar, y la siguiente extension
    que alguien invente volveria a quedar fuera en silencio. El coste es leer
    8 KiB por fichero, medido abajo en el propio repo.

    Un OSError NO se traga aqui: se propaga para que `main` lo cuente como
    COULD_NOT_RUN. Tragarlo devolviendo False convertiria "no pude leerlo" en "no
    es texto", que es un fichero saltado en silencio -- la misma clase de defecto
    que esta ficha cierra, reintroducida en la funcion que la cierra.
    """
    return b"\x00" not in f.open("rb").read(8192)


def enmascarar(valor: str) -> str:
    """Punta y cola, nunca el identificador entero.

    Un gate de PII que imprime el dato lo PUBLICA: su salida va al log de cada
    corrida de CI, a la telemetria y al mensaje de cada agente que lo relate.
    Cuatro caracteres de punta y dos de cola bastan para localizar la linea y no
    para reconstruir un RFC (12-13) ni una CURP (18). Senalado por declutter en el
    mismo informe que DECL-GOV-113.
    """
    if len(valor) <= 6:
        return "*" * len(valor)
    return f"{valor[:4]}{'*' * (len(valor) - 6)}{valor[-2:]}"


def permitidos(root: Path) -> tuple[set[str], list[str]]:
    """Los del repo, declarados una vez. Un allowlist explicito, nunca inferido.

    Vive en `tasks/pii_allow.txt`, NO en `.simplecode/`. Lo cazo la sesion aequitas_os al
    ponerlo y notar de pasada que su `.gitignore` ignora `.simplecode/*`; medido despues,
    **15 de los 18 repos lo ignoran**, asi que el allowlist no viajaria a ningun clone.

    Es la misma clase que CANON-017: una afirmacion FIRMADA que no sobrevive al clone. Un
    allowlist es exactamente eso -- alguien afirma «este RFC es nuestro y su uso aqui es
    legitimo»-- y si no esta en la historia, el proximo que clone ve 30 hallazgos y ninguna
    firma que los explique. Por eso vive dentro de `tasks/`, que esta versionado.

    `ledger/` se retiro de la flota el 2026-09-02 (una_sola_casa, canon_adoption.py): la ruta
    canonica no puede seguir siendo una carpeta que el canon prohibe que exista. Repuntada a
    `tasks/pii_allow.txt` -- misma correccion aplicada en aequitas_os y en Atlas (commit
    21e7fc2e, confirmado 2026-09-03: sin datos que migrar, ningun repo habia escrito todavia un
    pii_allow.txt real bajo la ruta vieja).
    """
    avisos: list[str] = []
    extra: set[str] = set()
    canonico = root / "tasks" / "pii_allow.txt"
    heredado = root / ".simplecode" / "pii_allow.txt"
    for p in (canonico, heredado):
        if not p.is_file():
            continue
        extra |= {l.split("#")[0].strip() for l in p.read_text(encoding="utf-8").splitlines()
                  if l.split("#")[0].strip()}
        if p is heredado:
            avisos.append(f"{p.relative_to(root)} se lee, pero esa carpeta esta en .gitignore "
                          f"en 15 de 18 repos: mueve las lineas a tasks/pii_allow.txt o la "
                          f"declaracion no sobrevive a un clone")
    return PERMITIDOS_FIJOS | extra, avisos


class Barrido:
    """What one sweep of one repo found, and what it could not look at.

    A plain tuple would do the same job; the point of naming it is that
    `revisados`, `ambitos_presentes` and `could_not_run` are the three fields a
    reader has to see TOGETHER to know whether `hallazgos == 0` means anything:
    zero findings over zero files examined is not a clean repo, and the absence
    of a scope is not the same fact as an empty scope. Keeping them in one
    object is what stops a caller from reading the findings without them.
    """

    def __init__(self) -> None:
        self.hallazgos: list[tuple[object, int, str]] = []
        self.could_not_run: list[str] = []
        self.revisados = 0
        self.ambitos_presentes: list[str] = []


def hallazgos_en_lineas(
    lineas: list[str], ok: set[str], id_del_archivo: list[str],
    archivo_sintetico: bool = False,
) -> list[tuple[int, str]]:
    """The third-party personal data in `lineas`, as `(numero_de_linea, valor)`.

    `archivo_sintetico` is the file-level declaration (the marker), which the
    caller reads; a line declares itself with EXENTA_LINEA. Either declaration
    only exempts a value that `no_puede_ser_real` proves synthetic -- a claim
    the gate cannot check is a claim that frees real data for one word.
    """
    encontrados: list[tuple[int, str]] = []
    for n, l in enumerate(lineas, 1):
        declarada = archivo_sintetico or bool(EXENTA_LINEA.search(l))
        for patron in (RFC, CURP, CORREO, TELEFONO):
            for match in patron.finditer(l):
                valor = match.group()
                if valor in ok or valor in id_del_archivo:
                    continue
                if declarada and no_puede_ser_real(patron, valor):
                    continue
                if es_identificador_compuesto(l, match.start()):
                    continue
                if patron is CORREO and _correo_exento_por_contexto(
                    valor, lineas, l, n, match.start()
                ):
                    continue
                encontrados.append((n, valor))
    return encontrados


def ficheros_en_ambito(root: Path, ambito: str) -> Iterator[Path]:
    """Every file of `root/ambito` this gate is allowed to open, in a stable order.

    Separated from `barrer` because "what counts as in-scope content" is a
    different question from "what is in it", and this half is where a silent
    over- or under-reach would live: `_tracked_files` returning None means git
    could not be asked, and the fallback is to walk everything rather than to
    walk nothing -- a PII gate that sees fewer files when git is unavailable
    would go green by looking away.
    """
    tracked = _tracked_files(root, ambito)
    for f in sorted((root / ambito).rglob("*")):
        if not f.is_file():
            continue
        if tracked is not None and f not in tracked:
            continue
        yield f


def barrer(root: Path, ok: set[str]) -> Barrido:
    """Sweep every declared scope of `root` for third-party personal data."""
    b = Barrido()
    # Un ambito AUSENTE y un ambito VACIO no son el mismo hecho. Sin ambitos el
    # gate no es aplicable en este repo y decirlo es la verdad; con el directorio
    # presente y cero ficheros de texto, el gate se apunto a algo y no vio nada,
    # que es COULD_NOT_RUN. Distinguirlos evita poner en rojo a los satelites que
    # legitimamente no tienen tasks/ ni docs/ mientras se sigue cerrando el hueco.
    for ambito in AMBITOS:
        base = root / ambito
        if not base.is_dir():
            continue
        b.ambitos_presentes.append(f"{ambito}/")
        for f in ficheros_en_ambito(root, ambito):
            try:
                if not es_texto(f):
                    continue
                lineas = f.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError as exc:
                b.could_not_run.append(f"{f}: {exc}")
                continue
            b.revisados += 1
            sintetico = bool(MARCADOR_SINTETICO.search("\n".join(lineas[:20])))
            # El nombre del archivo es un id, no un dato: si el id casa el patron, no cuenta.
            id_del_archivo = RFC.findall(f.stem)
            for n, valor in hallazgos_en_lineas(lineas, ok, id_del_archivo, sintetico):
                b.hallazgos.append((f.relative_to(root), n, valor))

    # Cero ficheros revisados NO es verde: es un gate que no miro nada y lo
    # reporto como limpio. Es la politica de reporte de la casa aplicada a su
    # propio instrumento, y el modo en que este defecto se mantuvo invisible --
    # `revisados=0 hallazgos=0` salia con rc=0 y leia igual que un repo limpio.
    # `and not b.could_not_run`: si ya hay una razon registrada (un fichero
    # ilegible, por ejemplo), esa ES la explicacion de por que no se examino nada.
    # Anadir aqui una segunda la duplicaria y haria que el conteo mintiera.
    if b.revisados == 0 and b.ambitos_presentes and not b.could_not_run:
        b.could_not_run.append(
            f"{', '.join(b.ambitos_presentes)} existe(n) pero no contiene(n) ningun fichero "
            f"de texto: no se examino nada"
        )
    return b


def imprimir_barrido(b: Barrido, avisos: list[str]) -> None:
    """Print the report. Every count prints, zeros included."""
    print(f"revisados={b.revisados} hallazgos={len(b.hallazgos)} "
          f"could_not_run={len(b.could_not_run)}")
    emit_hallazgos("[pii-scan]", len(b.hallazgos))
    for f, n, m in b.hallazgos[:40]:
        print(f"  PII {f}:{n}  {enmascarar(m)}")
    if len(b.hallazgos) > 40:
        print(f"  ... y {len(b.hallazgos) - 40} mas")
    for c in b.could_not_run:
        print(f"  [pii-scan] COULD_NOT_RUN: {c}")
    for a in avisos:
        print(f"  AVISO {a}")
    if not b.ambitos_presentes:
        print(f"  [pii-scan] NO APLICA: ningun ambito ({', '.join(AMBITOS)}) existe aqui")
    # Veredicto de condena TAGUEADO, por la misma razon que en coverage_target:
    # este modulo ya imprimia `[pii-scan] COULD_NOT_RUN` y nada tagueado en el
    # camino de hallazgo, asi que `gate_runner.gate_could_not_run` habria leido un
    # hallazgo REAL de PII como instrumento caido. Se imprime ademas de los
    # hallazgos, no en su lugar.
    if b.hallazgos:
        print(f"[pii-scan] FAIL: {len(b.hallazgos)} dato(s) personal(es) de terceros")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    args = ap.parse_args(argv)
    ok, avisos = permitidos(args.root)
    b = barrer(args.root, ok)
    imprimir_barrido(b, avisos)
    # Los dos condenan, y los dos por separado: un hallazgo dice algo del SUJETO,
    # un could_not_run dice que no se pudo mirar. Se suman en el rc porque
    # ninguno de los dos es un informe limpio, y el informe de arriba los imprime
    # en lineas distintas para que no se confundan al leerlos.
    return 1 if (b.hallazgos or b.could_not_run) else 0


if __name__ == "__main__":
    raise SystemExit(main())
