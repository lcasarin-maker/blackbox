#!/usr/bin/env python3
"""push_timing.py -- how long does a push take in a repo, what weighs, and what is paid twice?

Reads the same ledger as `push_attempts` (`.simplecode/evidence/telemetry.jsonl` and its
`.until-*.gz` archives, rows written by `simplecode.verification.gate_runner`) and answers
three questions with the ledger's own `duration_ms`, never an estimate:

  0. Grouping. One attempt is one `run_id` (see `regroup_by_run`), not a stretch of file lines.
  1. Wall time. An attempt's wall is its aggregate `check=pre-push` row (the whole
     concurrent suite) plus the sequential `gitleaks-outgoing` step that runs before it.
     Reported per attempt and per GREEN push: every attempt paid, blocked ones included,
     divided by the pushes that landed. That last number is what a push really costs.
  2. What weighs. Per gate: runs, mean, median, p90, total seconds, and `sets the wall`,
     the number of attempts in which that gate was the longest of the concurrent suite.
     Gates run concurrently, so a gate's total seconds is NOT its share of the wall;
     `sets the wall` is the column that says where a faster gate would shorten the push.
     `gate seconds per wall second` says how concurrent the suite is: 1.0 means the gates ran
     strictly one after another, 2.0 means two were running at any moment on average.
     `overlap ceiling` is the most that running gates side by side could ever remove: the suite
     wall minus its longest gate. It is an upper bound that ignores CPU contention, not a saving.
  3. What is paid more than once. (a) a gate with two rows inside ONE attempt;
     (b) a gate that was already green earlier in the same push (a retry after another gate
     blocked) and ran again: those are the "re-paid" gate-seconds.

Usage:

    python -m simplecode.verification.push_timing --repo . --since 2026-09-27
    python -m simplecode.verification.push_timing --fleet ~/projects --since 2026-09-27

Exit codes: 0 measured; 2 COULD_NOT_RUN (no telemetry, or no attempt in the window; in
`--fleet` mode, exit 2 when no repo could be measured).

Declared limits: concurrent gates are timed by their own rows, so the sum of gate seconds
exceeds the wall; the final `telemetry-disposition` step (about 0.2 s) is written after the
aggregate row and is attributed to no attempt's wall; a run killed before its aggregate row
merges into the next attempt (same limit as `push_attempts`).
"""
from __future__ import annotations

import argparse
import collections
import statistics
import sys
from pathlib import Path

from simplecode.verification.push_attempts import TELEMETRY, load_attempts, telemetry_sources

_AGGREGATE = "pre-push"
_SEQUENTIAL_BEFORE_SUITE = "gitleaks-outgoing"
_NOT_SUITE = frozenset({_AGGREGATE, _SEQUENTIAL_BEFORE_SUITE, "telemetry-disposition"})


def _seconds(row: dict) -> float:
    return float(row.get("duration_ms") or 0) / 1000.0


def attempt_wall(attempt: list[dict]) -> float:
    """Seconds one attempt took: the aggregate row plus the step that ran before it."""
    return _seconds(attempt[-1]) + sum(
        _seconds(r) for r in attempt[:-1] if r.get("check") == _SEQUENTIAL_BEFORE_SUITE)


def _unfinished_kind(rows: list[dict]) -> str:
    """Why a run has no aggregate row, from what it did write."""
    if len(rows) == 1 and rows[0].get("check") == _SEQUENTIAL_BEFORE_SUITE:
        return "stopped_at_gitleaks" if rows[0].get("status") != "ok" else "died_after_gitleaks"
    return "one_gate_run_by_hand" if len(rows) == 1 else "several_gates_no_aggregate"


def regroup_by_run(attempts: list[list[dict]]) -> tuple[list[list[dict]], dict[str, int]]:
    """(attempts, runs without an aggregate row by kind), grouped by `run_id`.

    `push_attempts` cuts attempts by file position: the `telemetry-disposition` row is written
    AFTER the aggregate row, so it lands in the NEXT attempt, and a run killed before its
    aggregate row merges into the one after it. Measured on simplecode since 2026-09-20: 54 of
    101 positional attempts mixed more than one `run_id`. One run is one `run_id`. Rows with
    no `run_id` (written before 2026-09-15) keep the positional attempt they came in.
    """
    runs: dict[str, list[dict]] = {}
    for index, attempt in enumerate(attempts):
        for row in attempt:
            runs.setdefault(row.get("run_id") or f"position-{index}", []).append(row)
    finished: list[list[dict]] = []
    killed: collections.Counter[str] = collections.Counter()
    for rows in runs.values():
        aggregate = [r for r in rows if r.get("check") == _AGGREGATE]
        if not aggregate:
            killed[_unfinished_kind(rows)] += 1
            continue
        finished.append([r for r in rows if r.get("check") != _AGGREGATE] + aggregate[-1:])
    finished.sort(key=lambda a: a[-1]["ts"])
    return finished, dict(killed)


def _pushes(attempts: list[list[dict]]) -> tuple[list[list[list[dict]]], list[list[dict]]]:
    """(landed pushes, attempts of the push still open): a push is its blocked attempts plus the green one."""
    landed: list[list[list[dict]]] = []
    current: list[list[dict]] = []
    for attempt in attempts:
        current.append(attempt)
        if attempt[-1].get("status") == "ok":
            landed.append(current)
            current = []
    return landed, current


def _percentile90(values: list[float]) -> float:
    ordered = sorted(values)
    return ordered[max(0, -(-len(ordered) * 9 // 10) - 1)]


def per_gate(attempts: list[list[dict]]) -> list[dict]:
    """One row per gate, heaviest total first."""
    seconds: dict[str, list[float]] = collections.defaultdict(list)
    sets_wall: collections.Counter[str] = collections.Counter()
    for attempt in attempts:
        suite = [r for r in attempt[:-1] if r.get("check") not in _NOT_SUITE]
        if suite:
            sets_wall[max(suite, key=_seconds)["check"]] += 1
        for row in attempt:
            seconds[row["check"]].append(_seconds(row))
    table = [
        {"gate": gate, "runs": len(values), "mean": statistics.mean(values),
         "median": statistics.median(values), "p90": _percentile90(values),
         "total": sum(values), "sets_the_wall": sets_wall[gate]}
        for gate, values in seconds.items()
    ]
    return sorted(table, key=lambda r: -r["total"])


def repeats(attempts: list[list[dict]]) -> dict:
    """What ran more than once: inside one attempt, and across the retries of one push."""
    inside_one_attempt: collections.Counter[str] = collections.Counter()
    for attempt in attempts:
        counts = collections.Counter(r["check"] for r in attempt)
        inside_one_attempt.update(check for check, n in counts.items() if n > 1)
    landed, open_push = _pushes(attempts)
    repaid: dict[str, float] = collections.defaultdict(float)
    for push in landed + ([open_push] if open_push else []):
        green_before: set[str] = set()
        for attempt in push:
            suite = [r for r in attempt[:-1] if r.get("check") not in _NOT_SUITE]
            for row in suite:
                if row["check"] in green_before:
                    repaid[row["check"]] += _seconds(row)
            green_before |= {r["check"] for r in suite if r.get("status") == "ok"}
    return {"inside_one_attempt": dict(inside_one_attempt), "repaid_seconds": dict(repaid)}


def measure(path: Path, since: str, until: str | None = None) -> dict | None:
    """The whole report for one ledger, or None when the window holds no attempt."""
    attempts, killed = regroup_by_run(load_attempts(path, since, until))
    if not attempts:
        return None
    landed, open_push = _pushes(attempts)
    green_walls = [attempt_wall(push[-1]) for push in landed]
    gate_seconds = sum(_seconds(r) for a in attempts for r in a[:-1] if r.get("check") not in _NOT_SUITE)
    suite_wall = sum(_seconds(a[-1]) for a in attempts)
    ceilings = [
        _seconds(a[-1]) - max(_seconds(r) for r in suite)
        for a in attempts if (suite := [r for r in a[:-1] if r.get("check") not in _NOT_SUITE])
    ]
    return {
        "attempts": len(attempts),
        "green_pushes": len(landed),
        "open_attempts": len(open_push),
        "runs_without_aggregate": killed,
        "wall_per_attempt_mean": statistics.mean(attempt_wall(a) for a in attempts),
        "wall_per_green_attempt_mean": statistics.mean(green_walls) if green_walls else None,
        "wall_paid_per_green_push": (
            sum(attempt_wall(a) for push in landed for a in push) / len(landed) if landed else None),
        "gates": per_gate(attempts),
        "repeats": repeats(attempts),
        "gate_seconds_total": gate_seconds,
        "gate_seconds_per_wall_second": gate_seconds / suite_wall if suite_wall else None,
        "overlap_ceiling_per_attempt": statistics.mean(ceilings) if ceilings else None,
    }


def _fmt(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.0f}s"


def _fmt2(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.2f}"


def render(name: str, report: dict, since: str) -> str:
    out = [f"[push-timing] repo={name} since={since}",
           f"  attempts={report['attempts']} green pushes={report['green_pushes']} "
           f"attempts of a push not yet landed={report['open_attempts']}",
           f"  runs with no aggregate row (not attempts, not in any wall): "
           f"{report['runs_without_aggregate'] or 0}",
           f"  wall per attempt: mean {_fmt(report['wall_per_attempt_mean'])}; "
           f"per green attempt: mean {_fmt(report['wall_per_green_attempt_mean'])}",
           f"  wall PAID per green push (every attempt, blocked ones included): "
           f"{_fmt(report['wall_paid_per_green_push'])}",
           f"  gate seconds per wall second: {_fmt2(report['gate_seconds_per_wall_second'])} "
           f"(1.00 = strictly one gate after another)",
           f"  most that running the gates side by side could remove per attempt: "
           f"{_fmt(report['overlap_ceiling_per_attempt'])} (upper bound = suite wall minus its longest gate; "
           f"ignores contention, NOT a saving)",
           f"  {'gate':26}{'runs':>6}{'mean':>8}{'median':>8}{'p90':>8}{'total':>9}{'sets the wall':>15}"]
    for g in report["gates"]:
        out.append(f"  {g['gate']:26}{g['runs']:>6}{g['mean']:>7.1f}s{g['median']:>7.1f}s"
                   f"{g['p90']:>7.1f}s{g['total']:>8.0f}s{g['sets_the_wall']:>15}")
    rep = report["repeats"]
    out.append(f"  gate with two rows inside ONE attempt: {rep['inside_one_attempt'] or 0}")
    repaid = sum(rep["repaid_seconds"].values())
    share = 100 * repaid / report["gate_seconds_total"] if report["gate_seconds_total"] else 0.0
    out.append(f"  re-paid (already green earlier in the same push, ran again): "
               f"{repaid:.0f} gate-seconds = {share:.0f}% of all suite gate-seconds")
    for gate, secs in sorted(rep["repaid_seconds"].items(), key=lambda kv: -kv[1]):
        out.append(f"    {gate}: {secs:.0f}s")
    return "\n".join(out)


def render_fleet_line(name: str, report: dict) -> str:
    suite = [g for g in report["gates"] if g["gate"] not in _NOT_SUITE]
    heaviest = suite[0]["gate"] if suite else "n/a"
    sets = max(suite, key=lambda g: g["sets_the_wall"])["gate"] if suite else "n/a"
    return (f"  {name:28}{report['attempts']:>6}{report['green_pushes']:>7}"
            f"{_fmt(report['wall_per_attempt_mean']):>9}{_fmt(report['wall_paid_per_green_push']):>10}"
            f"{_fmt2(report['gate_seconds_per_wall_second']):>7}"
            f"  sets the wall most: {sets}  heaviest by total: {heaviest}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    where = ap.add_mutually_exclusive_group()
    where.add_argument("--repo", default=".", help="repository root (default: .)")
    where.add_argument("--fleet", default=None, help="directory whose subdirectories are repositories")
    ap.add_argument("--since", default="0000", help="ISO timestamp lower bound, e.g. 2026-09-27")
    ap.add_argument("--until", default=None, help="ISO timestamp EXCLUSIVE upper bound")
    args = ap.parse_args(argv)

    if args.fleet is None:
        path = Path(args.repo) / TELEMETRY
        if not telemetry_sources(path)[0]:
            print(f"[push-timing] COULD_NOT_RUN: no telemetry at {path} or its archives", file=sys.stderr)
            return 2
        report = measure(path, args.since, args.until)
        if report is None:
            print(f"[push-timing] COULD_NOT_RUN: no push attempt since {args.since} in {path}", file=sys.stderr)
            return 2
        print(render(Path(args.repo).resolve().name, report, args.since))
        return 0

    measured: list[tuple[str, dict]] = []
    skipped: list[str] = []
    for repo in sorted(p for p in Path(args.fleet).expanduser().iterdir() if p.is_dir()):
        path = repo / TELEMETRY
        report = measure(path, args.since, args.until) if telemetry_sources(path)[0] else None
        if report is None:
            skipped.append(repo.name)
        else:
            measured.append((repo.name, report))
    print(f"[push-timing] fleet={args.fleet} since={args.since}")
    print(f"  {'repo':28}{'tries':>6}{'green':>7}{'wall/try':>9}{'paid/push':>10}{'conc.':>7}")
    for name, report in sorted(measured, key=lambda kv: -(kv[1]["wall_paid_per_green_push"] or 0)):
        print(render_fleet_line(name, report))
    print(f"  COULD NOT MEASURE (no telemetry or no attempt in the window): {', '.join(skipped) or 'none'}")
    if not measured:
        print("[push-timing] COULD_NOT_RUN: no repository in the fleet could be measured", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
