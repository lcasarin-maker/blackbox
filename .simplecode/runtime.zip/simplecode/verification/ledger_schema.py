#!/usr/bin/env python3
"""Valida el esquema tipado de `ledger/entries/*.md` y regenera `ledger/index.jsonl`.

Por qué existe: el defecto de fondo del repo es guardar datos en prosa y leerlos con regex
(DGX-411, seis errores de medición en una tarde). Este gate es la mitad que lo impide: cada
campo del que un gate depende tiene tipo y dominio CERRADO, y lo que no está en el dominio
no pasa. La prosa vive debajo del frontmatter y ningún gate la mira.

Reporta con los ceros puestos y distingue `could_not_run` de `failed`: un archivo que no se
pudo leer NO es un archivo válido ni uno inválido, y colapsarlos haría que un instrumento
caído fuera indistinguible de un sujeto sano.

Uso:
    python -m simplecode.verification.ledger_schema --root .            # valida
    python -m simplecode.verification.ledger_schema --root . --check    # sin escribir

Migrado el 2026-09-04 de `gates/ledger_schema.py`, copiado sin pasar por
`cli_new`/`satellite_sync` a cada satelite -- el canal de distribucion
paralelo que produjo los forks de RePic (109 lineas), declutter (43) y
Twiner (109), medidos el mismo dia por RePic corriendo `diff` sobre los 18
repos. Como modulo de `simplecode.verification`, este archivo viaja en
`runtime.zip`, y `--root` reemplaza el `ROOT` resuelto por `__file__` que
asumia vivir siempre en `<repo>/gates/`.

CORRECCION (2026-09-05): la frase que ocupaba este hueco decia que tras la
migracion "NINGUN satelite vuelve a tener su propia copia que pueda divergir:
hay una sola implementacion". **Era falsa el dia que se escribio y es falsa
hoy.** Medido por la sesion own_chats y re-medido aqui:

    copias de `gates/ledger_schema.py` que existen: 16
    repos que corren el modulo del kit:              2   (RePic, simplecode)
    repos que corren su propia copia:               15

Y ya divergieron, en SEIS tamanos distintos contra una madre de 701 lineas:

    274 lineas  x1        384 lineas  x1        469 lineas  x1
    336 lineas  x11       439 lineas  x1        470 lineas  x1

Que el fichero PUEDA viajar en `runtime.zip` no es que viaje: la migracion creo
el canal, no retiro las copias. La consecuencia concreta se midio el mismo dia
-- `exit_nonzero` se retiro de `EXPECT` en esta madre y **14 repos lo siguen
admitiendo** porque su copia lo lleva cableado.

Se deja escrito aqui, y no corregido en silencio, porque el defecto que este
modulo existe para cazar es exactamente ese: una afirmacion en prosa que ningun
gate lee y que nadie vuelve a medir.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import subprocess
import sys
from datetime import datetime, timezone
import re
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.tool_limits import GIT_O1_TIMEOUT
from typing import NamedTuple, NotRequired, TypedDict, Unpack, cast

logger = logging.getLogger(__name__)

ROOT = Path(".")
# UNA sola casa: `tasks/`. El `ledger/` se colapso aqui el 2026-09-02 por instruccion de Luis
# --*«suena estupido tener duplicado, son puntos de falla»*-- y el dato le daba la razon:
# `tasks/` YA separaba abierto de cerrado por carpeta y el kit YA lo leia asi, mientras el
# ledger duplicaba 2,133 fichas sin anadir esa separacion. Costo de haberlo duplicado: el
# migrador piso un cierre en Atlas, 18 en simplecode y 54 lineas de prosa en office2office.
#
# Las carpetas son el estado: backlog = ABIERTO, done = CERRADO.
# Las rutas antiguas se leen exclusivamente por `task_migration`, que las
# convierte o las rechaza de forma explicita; ningun gate las trata como estado.
# Documentos auxiliares que no constituyen fichas.
OMITIR = {"README.md", "BACKLOG.md", "FORMATO_JOBS.md", "RETIRED.md"}
# backlog = open. El kit llama backlog a lo abierto.
#
# `roadmap` entro el 2026-09-29 a pedido de Atlas (DGX-619, votado por Luis): Atlas creo
# `tasks/roadmap/` ese dia para 26 fichas de investigacion/diseno que un voto anterior saco
# del conteo de DEUDA, y este gate no sabia que la carpeta existia -- las 26 salian
# `could_not_run`, o sea sin validar esquema, y `no_perder_lineas` (que deriva de aqui) las
# dejaba sin proteccion contra perder lineas. Medido sobre un clon de Atlas en `a616a08df`:
#
#     ledger_schema     antes: checked=816 passed=639 failed=2 avisos=133 could_not_run=26
#                       despues: checked=842 passed=665 failed=2 avisos=139 could_not_run=0
#     no_perder_lineas  antes: candidatas=816 could_not_run=1   despues: candidatas=842 could_not_run=0
#
# 0 failed nuevos (los 2 son DGX-613 y un DEBT-gate-failure-coverage, previos); los 6 avisos
# nuevos son `title` de mas de 100 chars en 6 fichas de roadmap, consultivos. Control
# negativo corrido: borrar una linea de `roadmap/DGX-105.md` en el clon da `pierden=1` con
# este conjunto y `pierden=0 could_not_run=1` con el viejo. En los otros 16 repos con SPEC.md
# de `~/projects` ninguno tiene una carpeta `roadmap` bajo `tasks/` a ninguna profundidad, y
# sus cifras de este gate, `no_perder_lineas` y `canon_repair` salieron identicas antes y
# despues (solo cambia el texto «fuera de backlog/, done/, roadmap/» de aequitas_os).
#
# ESTE conjunto es el eje de ESQUEMA, no el de DEUDA, y los dos ya estaban separados antes de
# este cambio: la deuda abierta la cuenta `finding_backlog.open_tasks`, que lee SOLO
# `tasks/backlog/` (fijo en `ledger._task_files`), y `backlog_verifier.GOVERNED_TASK_DIRS`
# es un literal propio que no deriva de aqui. Por eso `roadmap` entra al esquema sin
# contarse como deuda --lo votado: esquema SI, deuda NO-- sin un segundo conjunto ni una
# bandera. En el mismo clon de Atlas `open_tasks` dio 23 antes y 23 despues. Guarda de la
# separacion: `tests/test_roadmap_gobernada_sin_contar_deuda.py`.
GOBERNADAS = ("backlog", "done", "roadmap")
ANULADAS = ("archive",)
# `evidence/` no es un estado: son los artefactos pass/fail/e2e que `evidence.*` referencia
# desde una ficha, mas notas de disposicion en prosa (sin frontmatter, nunca fichas). Se
# encontro real al correr la comprobacion de cobertura de mas abajo contra este mismo repo:
# `tasks/evidence/CONVERSATION_IMPORT_DISPOSITION.md` marco `could_not_run` por estar fuera
# de backlog/|done/, y es documentacion legitima, no una ficha sin mover.
# `hardening_proposals/` tampoco es un estado: son propuestas de parche que
# `red_team._propose_hardening_for_evasions()` escribe cuando el fuzzer adversarial
# encuentra una evasion real de un detector -- sin frontmatter, revisadas por un humano,
# nunca aplicadas solas. Encontrado real el 2026-09-04: correr `red_team` de verdad al
# investigar DEBT-HARDCODED-DYNAMIC-INVARIANTS dejo 4 propuestas ahi mismo.
NO_FICHAS = ("evidence", "hardening_proposals")
# ENTRIES/INDEX se calculan en main() a partir de --root; el modulo ya no
# fija una raiz al importarse.

# El `id` NO lleva restricción de FORMA, y eso lo decidió una medición del 2026-09-01: de los
# 182 ids reales de `tasks/done/` de este repo, **177 fallaban** el patrón que la primera versión
# del diseño imponía (`DEBT-ruff-rag-entity-graph-py-157-5-c901-buil-838a98d9` y compañía).
# Renombrarlos rompería las citas desde código, tests y dictámenes — la misma razón por la que
# DGX-416 conservó los 276 ids cerrados en vez de migrarlos. Un identificador se restringe por
# UNICIDAD y ESTABILIDAD, que es lo que un gate puede comprobar sin destruir referencias; su
# forma es cosmética, y el patrón estaba describiendo un corpus imaginario.
ID_RE = re.compile(r"^\S+$")
# Lineas que un merge sin resolver deja dentro del frontmatter. NO son comentarios
# ni lineas en blanco, y tratarlas como tales hacia que una ficha corrupta y una
# correcta recibieran el mismo veredicto.
CONFLICT_MARKER_RE = re.compile(r"^(<{7}|={7}|>{7})(\s|$)")
FAMILY_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")
# LA CASA DEL VOCABULARIO DE `close_check.expect`, y la unica.
#
# Tiene que ser un SUBCONJUNTO de `backlog_verifier.CLOSE_CHECK_EXPECT_VOCABULARY`:
# una palabra que este esquema admite y el verificador no sabe leer produce una ficha
# ESCRIBIBLE, VALIDA E INVERIFICABLE -- pasa el gate de commit y llega al de push
# convertida en `COULD_NOT_RUN`, y su autor se entera cuando ya la cerro.
#
# `exit_nonzero` se retiro el 2026-09-05 midiendo el uso, no argumentandolo, con la misma
# forma con la que se retiro `void` ese mismo dia. Recontado sobre las carpetas gobernadas
# (`backlog` + `done`) de los 20 repos de `~/projects`, 2.901 fichas:
#
#     exit_zero      2898
#     exit_nonzero      0   <- la unica que lo usaba (cuenza) cerro midiendo la PROPIEDAD
#     empty_stdout      0
#     sin close_check     2   (Imagen_Corporativa_Aequitas, Qubit)
#
# El unico `expect: exit_nonzero` que queda en la flota vive en `Atlas/tasks/archive/
# CANON-012.md`, que es `status: void` en una carpeta que ni este esquema ni
# `backlog_verifier.GOVERNED_TASK_DIRS` gobiernan, y cuya propia nota de cierre dice que su
# comando ya no mide nada. Retirar la palabra no lo toca.
#
# Y no hacia falta: `exit_nonzero` no puede distinguir «fallo como se esperaba» de «el
# instrumento esta caido» -- un `close_check` que espera fallo pasa cuando el comando falla
# por CUALQUIER razon. Afirmar la propiedad en un test con `expect: exit_zero` si las
# distingue, y es lo que hizo la unica ficha que lo usaba.
#
# `empty_stdout` se queda con 0 usos medidos, y eso es deliberado: el conteo cubre
# `~/projects` y nada mas, mientras que el verificador SI lo implementa (backlog_verifier
# ~2188). Un 0 que solo cubre lo que se pudo mirar no es evidencia de ausencia.
#
# POR QUE ESTA ESCRITO AQUI Y NO IMPORTADO DEL VERIFICADOR. Se intento y no se puede:
# `backlog_verifier` -> `finding_backlog` -> `ledger_schema`, asi que el import inverso es
# un ciclo. Medido el 2026-09-05 sobre una copia del paquete, entrando por el verificador:
# «ImportError: cannot import name 'CLOSE_CHECK_EXPECT_VOCABULARY' from partially
# initialized module 'simplecode.verification.backlog_verifier'». La direccion que SI existe
# es la contraria -- el verificador puede importar de aqui -- y mientras no lo haga, quien
# impide que las dos listas vuelvan a divergir en silencio es
# `tests/test_expect_vocabulario_unico.py`, que las compara.
EXPECT = {"exit_zero", "empty_stdout"}

# `close_check.timeout`: segundos que el verificador espera a ESTE comando, en lugar del
# presupuesto derivado del tamano del corpus (`backlog_verifier._task_verification_timeout`).
# Opcional. Pedido por office2office el 2026-10-06: cuatro fichas cerradas salian
# COULD_NOT_RUN con "timed out after 366s", un presupuesto que ninguna ficha podia subir
# (voto de Luis, mismo dia). Vive AQUI porque aqui se valida `close_check` y el verificador
# importa de este modulo, no al reves (ver el ciclo descrito arriba). El techo es una hora:
# un cierre que tarda mas no es una comprobacion, es una corrida de CI.
CLOSE_CHECK_TIMEOUT_MAX_SECONDS = 3600


def close_check_timeout_problem(valor: object) -> str | None:
    """None si `valor` es un `close_check.timeout` valido; si no, por que no lo es.

    `bool` se rechaza aunque Python lo cuente como `int`: `true` en el JSON de una ficha
    no es un numero de segundos."""
    if isinstance(valor, bool) or not isinstance(valor, (int, float)):
        return f"close_check.timeout no es un numero de segundos: {valor!r}"
    if not 0 < valor <= CLOSE_CHECK_TIMEOUT_MAX_SECONDS:
        return (f"close_check.timeout fuera de dominio: {valor!r} -- tiene que ser > 0 y "
                f"<= {CLOSE_CHECK_TIMEOUT_MAX_SECONDS} segundos")
    return None


def expect_del_kit() -> frozenset[str]:
    """El dominio de `expect`, para que un satelite lo DERIVE en vez de copiarlo.

    DEBT-QUINCE-COPIAS-DEL-ESQUEMA-DIVERGEN (voto de Luis, 2026-09-05): 15 satelites
    corren su propia copia escrita a mano de este modulo, y ya divergieron -- retirar
    `exit_nonzero` de `EXPECT` aqui no lo retiro de 14 repos que lo siguen admitiendo
    por su copia cableada.

    Esta funcion es el punto de derivacion que un satelite migrado debe llamar:

        from simplecode.verification import ledger_schema
        dominio = ledger_schema.expect_del_kit()

    **Sin literal de reserva.** Un satelite que envuelva esta llamada en
    `try/except ImportError: return {"exit_zero", "empty_stdout"}` reintroduce la
    lista escrita a mano exactamente en el unico momento en que importa -- cuando el
    kit no se puede leer. La forma correcta es dejar que el `ImportError` (o
    cualquier fallo de importacion) SUBA sin capturar, para que el hook del
    satelite falle en duro y diga por que, en vez de validar en silencio contra un
    dominio que puede llevar meses rancio. Ver
    `tests/test_ledger_schema_una_sola_fuente.py` para el contraste medido entre
    las dos formas.
    """
    return frozenset(EXPECT)


KIND = {"debt", "bug", "risk", "task"}
# DOS estados, no cinco. Luis, 2026-09-02: *«las tasks estan en open o done, solo 2 estados»*.
# Los otros tres se inventaron y no se usaban: medido al consolidar, `active` y `blocked` tenian
# CERO fichas en los 18 repos y `review` tenia una. `void` existia solo para las 1,947 de
# cosecha del harvester, que se borraron el mismo dia. Tres estados para 1 ficha real.
STATUS = {"open", "done", "done_unverified"}
SEVERITY = {"P0", "P1", "P2", "P3"}
ORIGIN = {"detected", "asserted"}
SCOPE = {"repo", "fleet", "kit"}
# Estado del que la ficha viene, cuando el contrato la reabrio. Opcional: su AUSENCIA significa
# «nunca estuvo cerrada», que es informacion tanto como su presencia.
PRIOR = {"done", "done_unverified"}
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class ClosingCommand(NamedTuple):
    """Que comando cierra una ficha, de que campo salio, y si la ficha se contradice.

    `conflict` no es "" cuando la ficha declara las DOS grafias con comandos
    DISTINTOS. Es un estado propio y no un veredicto silencioso: quien lo recibe
    condena la ficha por mal formada en vez de elegir una de las dos a espaldas
    del autor.
    """

    cmd: str
    field: str
    conflict: str | None


def _desentrecomillar(valor: str | None) -> str:
    """El comando sin las comillas que lo envuelven en el YAML.

    Va DENTRO de la funcion compartida, y esa es toda la leccion. Los dos
    lectores traian la comparacion en formatos distintos: `backlog_verifier.
    _extract_verification_command` quita las comillas desde siempre, y
    `ledger_schema.parse` las conserva (guarda el valor crudo de la linea).
    Comparar uno con otro sin normalizar hace que
    `'pytest tests/x.py'` y `'"pytest tests/x.py"'` sean "dos comandos
    distintos".

    Medido antes de cablearlo, corriendo el gate contra este repo con la
    normalizacion FUERA: `failed=92` de 160 fichas, las 92 acusadas de
    contradecirse consigo mismas por un par de comillas. Con ella: 1, y esa una
    declara de verdad dos comandos de sujetos distintos.
    """
    crudo = (valor or "").strip()
    if len(crudo) >= 2 and crudo[0] == crudo[-1] and crudo[0] in "\"'":
        crudo = crudo[1:-1].strip()
    return crudo


def resolve_closing_command(close_check_cmd: str | None,
                            verification_command: str | None) -> ClosingCommand:
    """LA fuente de verdad del comando de cierre, para TODO gate del kit.

    Existia por triplicado y con precedencias INCOMPATIBLES, que es el defecto
    que esta funcion cierra (DEBT-SURVEY-TWO-ORGANS-NEITHER-MENTIONS-THE-OTHER):

      - `backlog_verifier._declared_closing_command` prefería la grafía CLASICA
        (`verification_command`),
      - `ledger_schema._close_check_cmd` y `._enuncia_close_check` preferían la
        del CANON (`close_check.cmd`).

    Sobre una ficha que lleva las dos con comandos distintos, los dos organos del
    mismo kit leian obligaciones distintas y ninguno lo decia. Coste medido: la
    sesion `cuenza` reapunto su `close_check`, dejo el `verification_command`
    viejo, y el verificador **corrio el comando viejo y le acuso de FRAUDE** --
    la acusacion mas grave del kit, por un campo duplicado.

    Medido sobre las 3.010 fichas de `~/projects` (backlog/ + done/, 2026-09-06),
    que es lo que decide la precedencia en vez de argumentarla:

        llevan las dos grafias                     1845
        ... y declaran comandos DISTINTOS            47   <- ficha mal formada
        solo `close_check`                         1033
        solo `verification_command`                   0   <- ninguna

    Cero fichas viven solo de la grafia clasica, asi que preferirla era preferir
    un campo que ninguna ficha usa como unica declaracion. Y los 47 desacuerdos
    no son cosmeticos: en 22 de aequitas_os el `verification_command` es la
    compuerta entera del repo (`zero_debt --gate`) mientras el `close_check`
    nombra el test scoped del defecto -- correr el clasico es medir un sujeto
    ajeno al de la ficha.

    Precedencia, explicita: **`close_check.cmd` gana siempre**. Si
    `verification_command` existe Y dice otra cosa, la ficha esta MAL FORMADA y
    esta funcion lo devuelve como `conflict` -- no se elige en silencio.
    Si los dos coinciden, no hay conflicto y el campo que se reporta es
    `close_check`, que es el que gobierna.

    El marcador `expect:` clasico NO se pierde al cambiar la precedencia: vive
    fuera de esta funcion y `backlog_verifier` lo sigue aplicando ADEMAS del
    `close_check.expect`. Medido antes de tocar nada: 15 fichas de la flota
    llevan `expect:` a nivel de frontmatter, las 15 en simplecode, las 15 con las
    dos grafias -- si esta funcion hubiera arrastrado tambien el criterio, esas
    15 habrian pasado de "sale 0 Y imprime 'passed'" a solo "sale 0", que es un
    criterio MAS DEBIL introducido por un arreglo.
    """
    cc = _desentrecomillar(close_check_cmd)
    vc = _desentrecomillar(verification_command)
    if cc and vc and cc != vc:
        return ClosingCommand(cc, "close_check", (
            f"la ficha declara DOS comandos de cierre distintos: "
            f"close_check.cmd={cc!r} y verification_command={vc!r}. "
            "`close_check.cmd` es el que gobierna, pero un gate que elija por su "
            "cuenta entre dos declaraciones que se contradicen es como se acuso "
            "de FRAUDE a una ficha por correr su comando viejo: borra el campo "
            "`verification_command:` o hazlo identico al `close_check.cmd`"
        ))
    if cc:
        return ClosingCommand(cc, "close_check", None)
    if vc:
        return ClosingCommand(vc, "verification_command", None)
    return ClosingCommand("", "close_check", None)


def closing_command(fm: dict[str, object]) -> ClosingCommand:
    """`resolve_closing_command` sobre un frontmatter ya parseado."""
    cc: object = fm.get("close_check")
    if isinstance(cc, dict):
        crudo = str(_obj(cc).get("cmd", "") or "")
    elif isinstance(cc, str):
        crudo = cc
    else:
        crudo = ""
    return resolve_closing_command(crudo, str(fm.get("verification_command", "") or ""))


# Los tres campos que una deuda ACEPTADA tiene que traer, y por que son tres.
#
# `accepted` es la cuarta salida que el kit no tenia
# (DEBT-SURVEY-SHIP-FREEZE-INCENTIVE-INVERTED): deuda ABIERTA, medida, con dueno
# y con disparador de reapertura, que NO bloquea el envio y SI se imprime. Las
# tres que habia -- cerrar la ficha, declarar `backlog_baseline.json`, o
# apagar los hooks -- dejaban a `repic` sin ninguna: cuatro de sus siete deudas no
# cierran hoy ni con trabajo, acababa de retirar TODAS sus exenciones, y la
# tercera no es una salida. El resultado medido es el incentivo invertido:
# materializar deuda real en fichas -- que es lo correcto -- mato su push.
#
# Los tres campos separan una aceptacion de un bypass de hooks con otro nombre,
# y cada uno cierra una fuga distinta:
#   by       -- alguien la firma. Sin dueno, nadie responde de ella.
#   date     -- cuando se acepto. Una aceptacion sin fecha no envejece, y una
#               deuda que no envejece es permanente en silencio (el contrato de
#               suspension de este mismo repo se escribio por eso).
#   trigger  -- que la REABRE. Es el unico campo que puede salir negativo: sin
#               el, "aceptada" no se distingue de "olvidada".
# Vacio o ausente cualquiera de los tres, la ficha BLOQUEA como cualquier otra:
# un campo que exime sin comprobarse es la exencion que se documenta a si misma.
ACCEPTED_REQUIRED = ("by", "date", "trigger")

# Campos siempre obligatorios. `blast_radius` NO está: su poder distintivo vive en el 0.86%
# de las fichas de la flota (21 de 2,452), así que exigirlo en el 99% restante es impuesto.
#
# UNA sola declaracion de la lista, y esta es. `REQUIRED` se DERIVA de las claves de
# `FrontmatterCanon`, y `render_frontmatter` consume esa MISMA TypedDict via `Unpack`, asi
# que su firma tampoco la repite. Hasta el 2026-09-15 la lista vivia DOS veces --esta tupla
# y los nueve argumentos kw-only del renderizador-- y dos copias que hay que sincronizar a
# mano son el molde (c) de la taxonomia de instrumentos ciegos: el dia que alguien anade un
# campo a una sola, las dos siguen verdes y discrepan sobre que es obligatorio.
#
# Se deriva de `__annotations__` y NUNCA de `__required_keys__`, por dos razones medidas:
# `__required_keys__` es un frozenset (pierde el ORDEN, del que dependen los mensajes de
# `_validar_obligatorios_y_forma`), y bajo `from __future__ import annotations` --que este
# modulo usa-- CPython 3.11 no evalua los `NotRequired`, asi que devuelve las nueve claves
# como obligatorias; leerlo seria leer el instrumento en vez del sujeto.
class FrontmatterCanon(TypedDict):
    """Los nueve campos obligatorios de una ficha, EN SU ORDEN DE EMISION.

    `NotRequired` marca los tres que `render_frontmatter` RELLENA cuando el escritor
    los omite (`kind`, `origin`, `created`): son obligatorios en el FICHERO y
    opcionales en la LLAMADA. Esa diferencia es exactamente la que separa
    `__annotations__` (nueve) de lo que pyright exige en una llamada (seis).
    """

    id: str
    kind: NotRequired[str]
    title: str
    status: str
    severity: str
    origin: NotRequired[str]
    satd_family: str
    close_check: dict[str, str]
    created: NotRequired[str]


class Frontmatter(FrontmatterCanon, total=False):
    """Los nueve del canon mas los campos OPCIONALES que el kit pasa hoy.

    Medido sobre los OCHO puntos de llamada reales el 2026-09-15 (`finding_backlog`,
    `universal_harvester`, `adversarial_judge`, `debt_materializer` x4,
    `orphan_hunter`): `risk_score`, `blast_radius`, `lifespan`, `tag`, y nada mas.

    El conjunto es CERRADO a proposito, y eso es lo unico que cambia respecto al
    `**extra: object` abierto que habia antes. En EJECUCION no cambia nada: un campo
    no declarado aqui se sigue emitiendo tal cual y ningun escritor pierde datos (lo
    fija `test_extra_fields_survive_so_no_writer_loses_data_migrating`). Lo que se
    gana es lo que un `**extra` abierto no podia ver ni en principio: un campo extra
    MAL ESCRITO --`blast_radiuss: HIGH`-- se escribia en silencio dentro de la ficha,
    y ahora pyright lo condena en la linea del escritor. Anadir un campo nuevo cuesta
    una linea aqui, y ese es el precio entero.
    """

    risk_score: int
    blast_radius: str
    lifespan: str
    tag: str


REQUIRED = tuple(FrontmatterCanon.__annotations__)
CAMPOS_ESTRUCTURADOS = {"close_check", "evidence", "detector", "block_reason", "owns",
                        "accepted"}
# Fecha en que el contrato de cierre empezo a exigir `evidence`. Una ficha nacida en/despues de
# ella pudo producir su tríada desde el primer dia, asi que NO puede declararse
# `done_unverified`: sin esta linea el tercer estado deja de ser una declaracion honesta sobre
# el pasado y pasa a ser una salida disponible para cualquier deuda nueva, que es amnistia con
# otro nombre. Medido antes de cablearla: las 789 fichas que hoy lo usan (office2office) fueron
# creadas ANTES, asi que la guarda rompe cero y solo cierra el futuro.
CONTRATO_EVIDENCE = "2026-09-02"

# Fecha desde la que `evidence.{pass,fail,e2e}` tiene que ser una RUTA A UN
# ARTEFACTO y no su descripcion. Separada de `CONTRATO_EVIDENCE` a proposito: son
# dos exigencias distintas y la segunda llego tres dias despues.
#
# Existe porque la comprobacion de existencia se cableo SIN ella el 2026-09-05 y
# rompio RePic en el acto -- 49 fichas sin poder commitear. La medicion que la
# justifico ("459 rutas, 0 muertas") estaba hecha con un instrumento ciego: el
# barrido solo reconocia la forma de BLOQUE
#
#     evidence:
#       pass: tasks/evidence/X.pass.txt
#
# y no la forma INLINE, que es la que usan 8 repos:
#
#     evidence: {"pass": "python -m tools.verify_finding ... -> rc=0", ...}
#
# Remedido cubriendo LAS DOS: 1.273 rutas reales y **404 valores en prosa** en 8
# de 16 repos (RePic 138, aequitas_os 135, own_chats 75, office2office 30,
# Atlas 12, descargaSAT 6, maletin 6, cuenza 2). El cero original no describia la
# flota, describia lo que el barrido sabia mirar.
#
# La prosa NO es un descuido en esos repos: es su convencion, y lleva el comando
# con su salida literal, que es mas informacion que una ruta. Convertirla en
# violacion de golpe es cambiar el contrato sin migracion.
#
# Fijada en MAÑANA y no en hoy, medido: con 2026-09-05 quedaban 9 fichas creadas
# hoy mismo por sesiones que estaban cerrando de buena fe bajo la convencion
# vieja. Con 2026-09-06 rompe CERO y solo obliga a lo que nazca despues -- la
# misma forma y la misma razon que `CONTRATO_EVIDENCE` arriba.
CONTRATO_EVIDENCE_ARTEFACTO = "2026-09-06"

# --- Evidencia COMPARTIDA: una medicion cierra N fichas ----------------------------------
#
# Hasta hoy el contrato cobraba "una triada por ficha" y NADA decia que compartirla
# valiera. Medido por agente_inmobiliario sobre sus 153 fichas cerradas (2026-09-05):
#
#     fichas cerradas con triada: 153
#     triadas DISTINTAS:           75    -> 2.0 fichas por triada
#     la mas compartida:           12 fichas (un hallazgo partido en doce filas)
#     ficheros de evidencia:      228
#
# Compartir fue legitimo y el gate lo acepto POR OMISION, no por diseno -- *"asi que un
# agente prudente escribe treinta y seis ficheros y otro escribe tres"*. Lo que faltaba
# no era permiso: era el CONCEPTO de una medicion con id propio, citable desde varias
# fichas, en vez de N copias fisicamente separadas del mismo fichero.
#
#     evidence: {pass: "shared:survey-triada", fail: "shared:survey-triada", ...}
#         -> tasks/evidence/shared/survey-triada.pass.txt  (y .fail.txt, y .e2e.txt)
#
# NO hay fichero de registro de citas, y esa ausencia es deliberada. Quien cita el
# artefacto YA esta escrito en el frontmatter de cada ficha; un segundo fichero con la
# misma informacion es el molde (c) de la taxonomia de instrumentos ciegos -- dos copias
# del mismo dato que divergen en silencio el dia que alguien edita una sola. El registro
# se CALCULA en cada corrida (`main`) y se imprime con su reparto; borrar el artefacto
# mientras una ficha lo cita condena a TODAS las que lo citan, con sus nombres, que es
# exactamente la proteccion que un registro tenia que dar.
EVIDENCIA_COMPARTIDA_PREFIJO = "shared:"
EVIDENCIA_COMPARTIDA_DIR = "tasks/evidence/shared"
# Un id de artefacto es un NOMBRE, no una ruta: sin `/`, sin `..`, sin espacios. La
# contencion de `_es_ruta_existente` ya impide salir del repo; este patron impide ademas
# que un `shared:` se use como ruta arbitraria disfrazada de id, que volveria el prefijo
# en una segunda sintaxis de ruta con reglas distintas a la primera.
ARTEFACTO_COMPARTIDO_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")

# Senales de VACUIDAD en un `fail.txt`: la corrida existe, sale con el codigo que la
# ficha declara, y NO midio lo que la ficha afirma. Es el defecto que agente_inmobiliario
# nombro tras 153 fichas -- la pata `fail` capturo casi todo el valor real precisamente
# destapando un `pass` que guardaba `1 skipped` (un `importorskip` que no miraba) y un
# `verify` que pasaba CON el mutante puesto.
#
# `0 skipped` NO es vacuidad: es la linea que PRUEBA que no hubo saltos, y convertirla en
# violacion condenaria justo al que si publico su cero. El patron excluye el cero.
#
# `xfail` se admite CON razon en la misma linea (`XFAIL ... reason: ...`, que es lo que
# pytest imprime con `-rx`): un fallo esperado y explicado es una medicion; uno sin razon
# es un test apagado sin decir por que.
#
# Y se busca en las FORMAS EN QUE PYTEST LO REPORTA -- `XFAIL` en mayusculas (short
# summary, `-rx`) y `N xfailed` en la linea de conteo-- nunca la palabra suelta en
# minusculas. Encontrado en dogfooding el 2026-09-06: la primera version era
# case-insensitive y condeno el `fail.txt` de la propia ficha que la introduce, porque
# ese artefacto cita el comando que lo genero y ese comando lleva
# `-k "... or xfail or ..."` -- un selector de tests, no un resultado. Una palabra dentro
# de un `-k`, de un nombre de test o de la prosa no es evidencia de que nada se saltara,
# y afinar el patron a las formas reales no es aflojarlo: es la misma discriminacion que
# `SKIPPED` en mayusculas ya hacia. Arreglado el detector, no el artefacto: editar la
# evidencia para esquivar el gate es exactamente lo que el gate existe para impedir.
#
# Medido antes de cablearlo, sobre los 385 artefactos de `tasks/evidence/` de este repo:
# 0 los contienen, asi que bloquear rompe cero y solo cierra el futuro.
#
# MENCION contra USO, y esto lo decidio el segundo dogfooding del mismo dia. El limite que
# esta linea declaraba como hipotetico --«una ficha cuyo SUJETO sea el salto de tests
# queda condenada y no tiene escape»-- mordio de inmediato: el `fail.txt` de la ficha que
# introduce esta regla EXPLICA el defecto, y para explicarlo escribe la cadena
# `1 skipped` entre comillas invertidas. Ahi la cadena esta CITADA, no reportada.
#
# La discriminacion es la que el repo ya usa en todas partes: lo entrecomillado con
# backticks es una cita. Un `fail.txt` fraudulento pega la salida cruda de pytest, que
# nunca lleva backticks; poner backticks alrededor de `1 skipped` es un acto deliberado
# de citar, y si alguien EDITA la salida de pytest para anadirselos ya falsifico el
# artefacto, que es un delito distinto y uno que este patron nunca iba a cazar.
#
# LIMITE QUE QUEDA: un `fail.txt` que reporte de verdad un salto y ademas lo cite en
# backticks se juzga solo por la parte no citada. Y la regla no ve saltos que pytest no
# imprime -- la `s` del progreso en una corrida sin `-r` es indistinguible de un punto.
_CITA_RE = re.compile(r"`[^`]*`")
_VACUIDAD_FAIL = (
    ("SKIPPED", re.compile(r"\bSKIPPED\b")),
    ("N skipped", re.compile(r"\b(?!0\b)\d+\s+skipped\b", re.I)),
    ("XFAIL sin razon", re.compile(r"\bXFAIL\b")),
    ("N xfailed", re.compile(r"\b(?!0\b)\d+\s+xfailed\b", re.I)),
)
_RAZON_EN_LA_LINEA_RE = re.compile(r"\breason\b\s*[:=]", re.I)

# Tokens que describen el ESTADO DEL REPO y no el sujeto de una ficha. Se restan del
# conjunto con el que se juzga si un `e2e.txt` habla de SU ficha: sin restarlos, la
# palabra `tests` de cualquier `pytest tests/...` haria pasar a cualquier artefacto.
_TOKEN_GENERICO = frozenset({
    "debt", "test", "tests", "python", "simplecode", "verification", "venv", "root",
    "pytest",
})
_TOKEN_MINIMO = 4

# Una razon de menos de esto es una etiqueta, no una razon. El numero no es arbitrario: las 789
# que existen hoy tienen todas una razon sustantiva, y la mas corta las supera con holgura, asi
# que el listón describe la practica que ya hay en vez de inventar una.
RAZON_MINIMA = 60

# El titulo: se REPORTA por encima de 100 y solo BLOQUEA por encima de 200.
#
# Medido el 2026-09-03 sobre los 2,313 titulos de la flota: p50=67, p95=88, p99=115,
# max=162, y solo 59 (el 2.5%) pasan de 100. Ninguno de esos 59 hace falsa una sola
# afirmacion, y NADA en el kit consume `title` con restriccion de ancho -- se busco:
# el unico consumidor es `cli_adr._slug`, que es de ADRs y no de fichas.
#
# Hasta hoy los 59 BLOQUEABAN, y en aequitas_os eran las 60 ultimas fichas rojas tras
# reparar 521: un repo entero sin poder commitear por estilo. Un gate debe bloquear lo
# que hace falsa una afirmacion y reportar lo que solo la hace mas fea; es la misma
# forma que `unrecognised_closing_status` en el kit, que reporta y nunca condena.
#
# El 200 no es cosmetico: por encima de eso el campo dejo de ser un titulo y es un
# cuerpo, y eso si dice algo -- que quien la escribio no habia acotado el defecto.
TITULO_REPORTADO = 100
TITULO_MAXIMO = 200


def _parsear_campo_estructurado(clave: str, raw: str,
                                lines: list[str], idx: int) -> tuple[object, str | None]:
    """El valor de un campo declarado ESTRUCTURADO por el esquema (nunca por la forma
    del dato -- ver `parse`): JSON en linea, o un bloque YAML indentado debajo cuando la
    linea del campo viene vacia. Devuelve (valor, None) o (None, motivo_de_could_not_run).

    Extraida de `parse()` el 2026-09-04 (`ruff` C901/PLR0912, pre-existente desde antes
    de esta migracion -- ver DEBT-LEDGER-SCHEMA-COMPLEXITY.md).
    """
    if not raw:
        # Bloque YAML indentado, no objeto en linea. Las dos formas son el mismo dato y
        # el contrato pide un OBJETO, no una sintaxis. Lo escribio asi la sesion
        # Simplecode al cerrar 28 fichas, y es mas legible que el JSON en una linea.
        # El gate las reportaba como `could_not_run` --que era lo correcto: no fingio
        # que estuvieran vacias-- pero rechazar una forma valida por no haberla previsto
        # es imponer mi sintaxis sobre su dato.
        bloque: dict[str, str] = {}
        for sig in lines[idx + 1:]:
            if sig.strip() == "---" or not sig.startswith((" ", "\t")):
                break
            m2 = re.match(r"^\s+([a-z0-9_]+):\s*(.*)$", sig)
            if m2:
                bloque[m2.group(1)] = m2.group(2).strip().strip('"')
        if bloque:
            return bloque, None
        return None, f"campo {clave} vacio y sin bloque indentado debajo"
    try:
        return json.loads(raw), None
    except json.JSONDecodeError:
        return None, f"campo {clave} deberia ser JSON y no lo es: {raw[:60]!r}"


def parse(path: Path) -> tuple[dict[str, object] | None, str | None]:
    """Devuelve (frontmatter, None) o (None, motivo_de_could_not_run)."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        return None, f"ilegible: {exc}"
    lines = text.split("\n")
    if not lines or lines[0].strip() != "---":
        return None, "sin frontmatter en la primera línea"
    out: dict[str, object] = {}
    for idx in range(1, len(lines)):
        line = lines[idx]
        if line.strip() == "---":
            break
        if CONFLICT_MARKER_RE.match(line):
            # A merge conflict marker committed INSIDE the frontmatter. It is not
            # a comment and not a blank line, and skipping it silently is how a
            # corrupt ficha and a correct one earn the same verdict.
            #
            # Reported by the maletin_homeopatia session 2026-09-05, with the
            # control that isolates it: a marker block that does NOT duplicate a
            # key passed with rc=0. (Their first example failed, but only
            # incidentally -- the duplicated `status:` won and then demanded
            # `evidence`, so the gate convicted the wrong thing and never said
            # "conflict".) Returning a REASON, not a skip, is the difference
            # between the gate seeing it and the gate tripping over it.
            return None, (
                f"marcador de conflicto de merge sin resolver en el frontmatter, "
                f"linea {idx + 1}: {line.strip()!r} -- la ficha esta corrupta, no "
                f"incompleta; resuelve el merge antes de que ningun gate la juzgue"
            )
        m = re.match(r"^([a-z0-9_]+):\s*(.*)$", line)
        if not m:
            continue
        clave, raw = m.group(1), m.group(2).strip()
        # Se parsea JSON en los campos que el ESQUEMA declara estructurados, nunca por la FORMA
        # del valor. Medido el 2026-09-01 en office2office: 343 fichas dieron `could_not_run`
        # porque su `title` empieza con "[BUG | ...]" y el parser dedujo "empieza con corchete,
        # luego es JSON". Deducir el tipo de un dato de su apariencia es DGX-411 otra vez, esta
        # vez dentro del gate que existe para impedirlo.
        if clave not in CAMPOS_ESTRUCTURADOS:
            out[clave] = raw
            continue
        valor, motivo = _parsear_campo_estructurado(clave, raw, lines, idx)
        if motivo is not None:
            return None, motivo
        out[clave] = valor
    return out, None


def _obj(v: object) -> dict[str, object]:
    """Devuelve el objeto como mapa tipado, o vacio. Existe por pyright en modo ESTRICTO:
    dos repos de la flota (Twiner, maletin_homeopatia) lo corren asi, y un `dict` sin
    parametrizar --incluso tras `isinstance`-- es «partially unknown» ahi. Un gate que solo
    tipa bien donde el verificador es laxo no esta tipado: esta sin comprobar."""
    if not isinstance(v, dict):
        return {}
    crudo = cast("dict[object, object]", v)
    return {str(k): val for k, val in crudo.items()}


def _validar_obligatorios_y_forma(fm: dict[str, object]) -> list[str]:
    """Campos que faltan, y los que estan pero fuera de su patron o dominio.

    `void` no lleva `close_check`: una ficha anulada resulto NO ser deuda, y pedirle como
    se comprobaria su resolucion es pedir la comprobacion de algo que no existe. Lo que si
    le exige el esquema es `void_reason`, mas abajo.
    """
    bad: list[str] = []
    for k in REQUIRED:
        if k not in fm:
            bad.append(f"falta campo obligatorio `{k}`")
    if "id" in fm and not ID_RE.match(str(fm["id"])):
        bad.append(f"id fuera de patrón: {fm['id']!r}")
    for field, domain in (("kind", KIND), ("status", STATUS),
                          ("severity", SEVERITY), ("origin", ORIGIN)):
        if field in fm and fm[field] not in domain:
            extra = ""
            if field == "status" and str(fm[field]) in ("active", "blocked", "review"):
                # Naming the replacement, because the domain list alone does not
                # say what to DO with a ficha that is genuinely blocked.
                extra = (" -- ese estado no existe en este esquema; una ficha "
                         "bloqueada se queda `open` y dice por qué en el cuerpo")
            bad.append(
                f"{field} fuera de dominio: {fm[field]!r} no está en {sorted(domain)}{extra}")
    if "satd_family" in fm and not FAMILY_RE.match(str(fm["satd_family"])):
        bad.append(f"satd_family fuera de patrón: {fm['satd_family']!r}")
    if "title" in fm and len(str(fm["title"])) > TITULO_MAXIMO:
        bad.append(f"title de {len(str(fm['title']))} chars, máximo {TITULO_MAXIMO}: "
                   "por encima de eso no es un titulo, es un cuerpo")
    if "created" in fm and not DATE_RE.match(str(fm["created"])):
        bad.append(f"created no es ISO-8601: {fm['created']!r}")
    return bad


def _validar_close_check_y_metadatos(fm: dict[str, object]) -> list[str]:
    """`close_check` (la unica forma estructurada que este esquema valida a fondo,
    porque es el campo del que depende `backlog_verifier`), mas `prior_status`/`scope`."""
    bad: list[str] = []
    cc: object = fm.get("close_check")
    if cc is not None:
        ccd = _obj(cc)
        if not ccd:
            bad.append("close_check no es objeto o esta vacio")
        else:
            if not str(ccd.get("cmd") or "").strip():
                bad.append("close_check.cmd vacío: quien no puede enunciar cómo se sabría "
                           "que está resuelta, no entendió el defecto todavía")
            if ccd.get("expect") not in EXPECT:
                bad.append(f"close_check.expect fuera de dominio: {ccd.get('expect')!r} no esta en "
                           f"{sorted(EXPECT)} -- lo que este esquema admite y `backlog_verifier` "
                           "no sabe comprobar produce una ficha valida e inverificable")
            if "timeout" in ccd:
                problema = close_check_timeout_problem(ccd["timeout"])
                if problema:
                    bad.append(problema)
    # Estos dos imprimen SU DOMINIO, como ya hacia `_validar_obligatorios_y_forma`
    # unas lineas arriba. Sin el, el mensaje nombra la violacion y no lo que se
    # espera, y no hay forma de actuar sobre el sin leer el codigo del gate.
    #
    # Reportado por la sesion repic en la encuesta de flota (2026-09-05):
    # `prior_status fuera de dominio: 'open'` -- puso `open` porque la ficha
    # estaba abierta, que es lo que la palabra significa. *"Lo saque haciendo
    # grep sobre 34 fichas."* Siete de las ocho sesiones encuestadas reportaron
    # esta misma forma en algun campo: el mensaje nombra la violacion y no el
    # dominio. Imprimirlo cuesta una linea.
    if fm.get("prior_status") is not None and fm["prior_status"] not in PRIOR:
        bad.append(
            f"prior_status fuera de dominio: {fm['prior_status']!r} no esta en "
            f"{sorted(PRIOR)} -- declara de que estado viene una ficha que el "
            f"contrato REABRIO, no el estado que tiene ahora (eso es `status`)"
        )
    if fm.get("scope") is not None and fm["scope"] not in SCOPE:
        bad.append(f"scope fuera de dominio: {fm['scope']!r} no esta en {sorted(SCOPE)}")
    # Las dos grafias del comando de cierre, leidas por LA funcion compartida.
    # Que este esquema y `backlog_verifier` no puedan discrepar sobre cual
    # gobierna es el arreglo entero: antes cada uno tenia la suya, invertidas.
    conflicto = closing_command(fm).conflict
    if conflicto:
        bad.append(conflicto)
    return bad


def _validar_accepted(fm: dict[str, object]) -> list[str]:
    """`accepted`: deuda medida y aceptada, con dueno, fecha y disparador.

    Se valida AQUI, en el esquema, y no solo en la compuerta de envio, por la
    misma razon por la que se valida `close_check`: es un campo del que un gate
    DEPENDE para no bloquear, y un campo del que se depende sin tipo ni dominio
    es prosa leida con regex.

    Un `accepted` incompleto NO exime -- eso lo decide `finding_backlog`, que
    exige los tres campos antes de retirar la ficha de las bloqueantes -- y
    ademas se REPORTA aqui, para que quien lo escribio mal se entere en el gate
    barato en vez de descubrir en el push que su exencion nunca existio.
    """
    acc: object = fm.get("accepted")
    if acc is None:
        return []
    bad: list[str] = []
    accd = _obj(acc)
    if not accd:
        return ["accepted no es objeto o esta vacio -- exige "
                f"{list(ACCEPTED_REQUIRED)}; sin los tres no exime de nada"]
    faltan = [k for k in ACCEPTED_REQUIRED if not str(accd.get(k) or "").strip()]
    if faltan:
        bad.append(
            f"accepted incompleta: falta(n) {faltan} -- una deuda aceptada declara "
            "QUIEN la firma, CUANDO, y QUE la reabre. Sin el disparador, "
            "«aceptada» no se distingue de «olvidada», y el campo seria un "
            "bypass de gate disfrazado de excepcion documentada"
        )
    fecha = str(accd.get("date") or "").strip()
    if fecha and not DATE_RE.match(fecha):
        bad.append(f"accepted.date no es ISO-8601: {fecha!r}")
    if fm.get("status") not in (None, "open"):
        bad.append(
            f"accepted sobre status={fm.get('status')!r}: el campo declara deuda "
            "ABIERTA que no bloquea el envio. Una ficha cerrada no tiene nada que "
            "aceptar, y una `done_unverified` ya declara su propio limite"
        )
    return bad


def accepted_declaration(fm: dict[str, object]) -> tuple[dict[str, object] | None, list[str]]:
    """(declaracion, motivos): la declaracion `accepted` de `fm` cuando es
    valida, o None con los motivos de `_validar_accepted` cuando no lo es.

    `finding_backlog` es quien retira una ficha de las bloqueantes, y esta es
    la unica puerta que usa para decidirlo: sin campo -> `(None, [])`, sin
    exencion y sin culpa; con campo incompleto -> `(None, motivos)`, sin
    exencion y con la razon para el informe; con los tres campos -> el dict
    `accepted` tal cual, para imprimir dueno/fecha/disparador.
    """
    motivos = _validar_accepted(fm)
    if motivos:
        return None, motivos
    acc = fm.get("accepted")
    if not isinstance(acc, dict) or not acc:
        return None, []
    return acc, []


def _validar_status_activo_o_bloqueado(fm: dict[str, object]) -> list[str]:
    """Guards for `active` and `blocked` -- two states `STATUS` does not admit.

    Both were REMOVED, not fixed by loosening the domain. Reported by the
    aequitas session 2026-09-05 against their fork (`gates/ledger_schema.py:208`)
    where the domain check returns early, so the guard was literally
    unreachable: a guard with zero possible catches.

    In the kit both checks run, so it was worse than dead. A ficha with
    `status: blocked` collected BOTH lines:

        - status fuera de dominio: 'blocked' no está en ['done', 'done_unverified', 'open']
        - status=blocked exige `block_reason`

    The second says, in effect, "add `block_reason` and this will be fine". It
    will not: `blocked` is not in the domain and adding the field changes
    nothing. A guard that cannot be the deciding reason for a failure, and whose
    message implies a remedy that does not work, sends the reader to do work
    that cannot help -- which is more expensive than saying nothing.

    Kept as a function with an empty body rather than deleted at the call site,
    so the reason survives where the next person looks for it.
    """
    del fm
    return []


def render_frontmatter(**fields: Unpack[Frontmatter]) -> str:
    """El frontmatter canonico, en UN solo sitio, para todo escritor de fichas.

    Existe porque el kit tenia SIETE escritores y solo uno acertaba. Medido por la
    sesion agente_inmobiliario el 2026-09-04: `grep -rln 'category: debt'` daba seis
    modulos emitiendo el esquema viejo (`debt_materializer`, `universal_harvester`,
    `finding_backlog`, `adversarial_judge`, `satellite_sync`, `orphan_hunter`) y uno
    solo el canon (`ponytail_debt`). Consecuencia reproducida en un repo git limpio:
    quien corria `simplecode materialize` se quedaba SIN PODER COMMITEAR, porque
    `ledger-schema` es hook de pre-commit y rechazaba el archivo que el propio kit
    acababa de escribir -- `falta campo obligatorio` x5, rc=1.

    El desacuerdo no era entre dos contratos vivos. `backlog_verifier.py` ya declara
    por escrito que `close_check` es *"strictly STRONGER"* que `verification_command`,
    y `consumer_shapes.py` lo llama *"the canon's spelling"*. Eran seis escritores que
    se quedaron atras, desincronizados por copia-pega sin que nada avisara.

    Vive en `ledger_schema` A PROPOSITO, junto a `REQUIRED` y a `validate`: el
    renderizador y las reglas que debe satisfacer comparten archivo, y
    `test_ledger_schema` comprueba que lo que ESTA funcion emite pasa ESA validacion.
    Separarlos es exactamente como se produjo el defecto.

    LA FIRMA NO REPITE LA LISTA (2026-09-15). Hasta hoy los nueve campos estaban
    escritos DOS veces --`REQUIRED` y nueve argumentos kw-only-- y `ruff` condenaba la
    segunda copia con `PLR0913` (9 > 5). Ahora los dos DERIVAN de `Frontmatter`, la
    TypedDict de arriba, consumida aqui con `Unpack` (PEP 692, `typing` de 3.11, sin
    dependencia nueva). Las cuatro propiedades que eso conserva o gana, cada una
    medida el 2026-09-15 y no argumentada:

      - los OCHO puntos de llamada no cambian ni una linea: siguen escribiendo
        `render_frontmatter(id=..., title=...)` por nombre;
      - pyright sigue comprobandolos ESTATICAMENTE. Control negativo corrido, no
        razonado: campo obligatorio ausente -> *"Argument missing for parameter
        `title`"*; nombre mal escrito -> *"No parameter named `titel`"*; tipo
        equivocado -> *"`Literal[123]` is not assignable to `str`"*. Los tres sobre
        una llamada real a esta funcion, y los tres se ven en `pyright`;
      - `ruff` deja de convictar: un solo parametro;
      - la duplicacion DESAPARECE en vez de crecer. `REQUIRED = tuple(
        FrontmatterCanon.__annotations__)`.

    Y lo que NO se hizo, con su coste, porque las tres rutas que el bloque anterior
    de este docstring media siguen siendo peores y conviene que quede escrito:

    1. Un dataclass con los nueve campos. Crea una TERCERA declaracion de la misma
       lista (firma + `REQUIRED` + dataclass) y obliga a editar los ocho puntos de
       llamada en cinco ficheros. Es el reparto que el parrafo de arriba documenta
       como la forma en que nacio el defecto original -- siete escritores, seis
       equivocados.
    2. Esconder tres argumentos en `**extra` y sacarlos con `extra.pop(...)`. Baja el
       numero sin desacoplar nada: es la evasion que el propio repo nombra
       `parameter_hiding_kwargs`. Y el detector NO la atrapa en esa forma: medido,
       `kw.get()` condena a partir de 5 ocurrencias y `kw.pop()` no condena NUNCA, a
       ningun conteo. Que la compuerta este ciega a esa ruta es razon para no tomarla,
       no permiso.
    3. `render_frontmatter(**fields)` con `fields: dict[str, object]` derivado de
       `REQUIRED`. Cierra `PLR0913` y quita la duplicacion, pero cambia una
       comprobacion ESTATICA por una en tiempo de ejecucion. `Unpack` es esa misma
       ruta SIN pagar ese precio, y es la unica diferencia entre las dos.

    LIMITE DECLARADO de la ruta tomada (DEBT-KIT-EVIDENCE-PROSE-AND-WRITER-DRIFT): el conjunto de campos extra pasa a ser
    CERRADO (ver `Frontmatter`). En ejecucion no cambia nada y ningun escritor pierde
    datos; lo que cambia es que un campo extra no declarado ahi lo señala pyright, y
    anadirlo cuesta una linea. A cambio, un extra MAL ESCRITO --que antes se escribia
    en silencio dentro de la ficha-- ahora se condena en la linea del escritor.
    """
    # `fields` ES la `Frontmatter` de la que `REQUIRED` deriva, asi que la firma no puede
    # desincronizarse de la lista. El `cast` esta aqui porque pyright prohibe indexar una
    # TypedDict con una clave que no sea un literal, y debajo se recorre `REQUIRED`: el
    # objeto que existe en ejecucion es un dict normal y se declara como tal, que es la
    # misma razon por la que existe `_obj` unas lineas mas arriba.
    datos = cast("dict[str, object]", fields)
    # `created` por defecto = hoy en UTC. Que lo ponga el renderizador y no cada
    # escritor evita seis definiciones distintas de "hoy" -- y dos satelites en husos
    # distintos discrepando sobre el cumpleanos de una ficha. `is None` y no `not in`:
    # un escritor que pase `created=None` explicitamente recibe el mismo relleno que
    # quien lo omite, que es lo que hacia el `created: str | None = None` de la firma vieja.
    datos.setdefault("kind", "debt")
    datos.setdefault("origin", "asserted")
    if datos.get("created") is None:
        datos["created"] = datetime.now(timezone.utc).date().isoformat()
    # El `TypeError` que la firma kw-only daba gratis, ahora explicito y DERIVADO de
    # `REQUIRED` en vez de escrito a mano. Sin el, un campo obligatorio ausente reventaba
    # como `KeyError: 'title'` cinco lineas mas abajo: nombra la clave pero no dice que se
    # esperaba ni que la culpa es de la llamada. pyright lo caza ANTES de ejecutar nada
    # (control negativo en `tests/test_ledger_schema.py`), pero pyright no cubre los tests
    # (`include = ["src"]`) ni a un escritor que construya los campos en ejecucion.
    faltan = [k for k in REQUIRED if k not in datos]
    if faltan:
        raise TypeError(
            f"render_frontmatter: falta(n) los campos obligatorios {faltan} -- el "
            f"contrato de una ficha exige los nueve {list(REQUIRED)}, y `kind`, `origin` "
            "y `created` son los unicos que esta funcion rellena por ti"
        )
    datos["close_check"] = json.dumps(datos["close_check"], ensure_ascii=False,
                                      sort_keys=True)
    campos: list[tuple[str, object]] = [(k, datos[k]) for k in REQUIRED]
    campos += [(k, v) for k, v in datos.items() if k not in REQUIRED and v is not None]
    lineas = "\n".join(f"{k}: {v}" for k, v in campos)
    return f"---\n{lineas}\n---\n"


def _git_lo_ignora(root: Path, ruta: str) -> bool:
    """True cuando git ignora `ruta` bajo `root`. Nunca lanza.

    Reportado por la sesion maletin_homeopatia el 2026-09-05, y el consejo
    equivocado fue MIO: le dije que el `fail` sancionado de una ficha de
    gate-failure ya estaba en `.simplecode/evidence/gate_failures.jsonl` -- 804
    filas en su repo, sin fabricar nada. Es cierto que existe. Lo que no mire es
    que ESE FICHERO ESTA GITIGNORADO:

        .gitignore:23:.simplecode/*   .simplecode/evidence/gate_failures.jsonl

    Su ficha commiteada citaba un `ts=` de un fichero que nadie mas tiene y que
    se borra sin dejar rastro. El campo `fail` existe precisamente para que una
    verificacion pueda salir negativa **ante otro**; una evidencia que solo
    existe en una maquina es infalsificable para quien revisa, que es la forma
    exacta del fraude que el contrato cierra.

    Medido antes de cablearlo: 1.470 rutas de evidencia existentes en la flota,
    **0 ignoradas**. Rompe cero hoy y cierra la clase. Es la segunda vez en el
    dia que el mismo molde muerde -- la primera fue `build_tools.txt`, tambien
    mia, tambien encontrada en campo horas despues de publicarla.

    Un git inutilizable devuelve False: esto CONDENA, y condenar porque git no
    arranco seria acusar al sujeto de un fallo del instrumento.
    """
    try:
        out = subprocess.run(
            ["git", "check-ignore", "-q", ruta],
            cwd=root, capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return out.returncode == 0


def _git_lo_tiene_en_head(root: Path, ruta: str) -> bool | None:
    """True si `ruta` esta en el arbol de `HEAD` bajo `root`; False si no; None si git
    no se pudo consultar. Nunca lanza.

    CANON-017, reportado por Atlas el 2026-09-29: la comprobacion de existencia era
    SOLO de disco, asi que una ficha `done` cuya triada existia en el arbol de trabajo
    y nunca se `git add`eo pasaba el gate. Este corre en PRE-PUSH (ver el docstring de
    `genuine_task_closure`), cuando `HEAD` ya trae cada commit que se va a publicar:
    lo que no esta en `HEAD` ahi es evidencia que quien clone el repo despues del push
    no va a tener -- la misma infalsificabilidad que `_git_lo_ignora` cierra, por otro
    camino. El propio `test_tracked_evidence_passes` lo reproducia sin saberlo: `git
    init`, tres ficheros en disco, cero commits, y `validate()` devolvia `[]`.

    Pregunta a `HEAD` y no al indice (`git cat-file blob :<ruta>`, que es la pregunta
    de `staged_mode_guard`): lo staged todavia no viaja en un push. Misma primitiva que
    `audit_ledger` (`git ls-tree --name-only -z <commit> -- <ruta>`): rc=0 con salida
    vacia es «no esta», sin adivinar por el texto de stderr, que aqui sale traducido.

    TRES valores y no dos, a diferencia de `_git_lo_ignora`, y la asimetria es a
    proposito: alli el `False` de un git caido es «no probado ignorado», un default
    benigno. Aqui «no probado en HEAD» CONDENA, y condenar porque git no arranco es
    culpar al sujeto de un fallo del instrumento -- la confusion que `could_not_run`
    existe para separar. `ls-tree` sale 128 tanto con `HEAD` sin nacer como fuera de
    un repo, asi que ese caso se desempata con `rev-parse --verify -q HEAD` (medido:
    rc=1 sin nacer, 128 fuera de un repo). Un `HEAD` sin nacer es un repo sin un solo
    commit: ahi no hay nada commiteado, y eso SI es un veredicto.
    """
    try:
        out = subprocess.run(
            ["git", "ls-tree", "--name-only", "-z", "HEAD", "--", ruta],
            cwd=root, capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
        if out.returncode == 0:
            return bool(out.stdout)
        cabeza = subprocess.run(
            ["git", "rev-parse", "--verify", "-q", "HEAD"],
            cwd=root, capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return False if cabeza.returncode == 1 else None


def _es_ruta_existente(root: Path, valor: str) -> bool:
    """`valor` names a file that exists under `root`. Never raises.

    `Path.is_file()` is NOT total over strings. Given a value longer than
    NAME_MAX (255 bytes on Linux) it raises `OSError: [Errno 36] File name too
    long` instead of returning False -- and this function is fed the raw text of
    an `evidence` field, which in several repos is a paragraph of prose.

    Reported by the RePic session 2026-09-05, and it was MY regression: the
    check shipped the same day crashed their gate on a 250+ byte evidence value,
    so `ledger_schema` emitted no verdict on ANY of their 49 fichas -- not even
    the sound ones -- and blocked every commit in that repo. A gate that crashes
    is worse than a gate that fails: a failure is a verdict about the subject, a
    crash is the instrument falling over and taking the whole census with it.

    Every OSError is caught, not just ENAMETOOLONG: ELOOP, ENOTDIR and a
    permission error on a parent directory are all reachable from arbitrary
    text, and none of them means "this is a valid path that exists".
    """
    if not valor:
        return False
    try:
        candidato = (root / valor).resolve()
        # CONTAINMENT. Until 2026-09-05 this was a bare `(root / valor).is_file()`,
        # so an absolute path or a `../` chain satisfied the evidence contract
        # with a file that is not in this repo at all. Measured here, both
        # vectors, against the real function:
        #     '/etc/hostname'             -> True
        #     '../../../../etc/hostname'  -> True  (resolves to /etc/hostname)
        # `/etc/hostname` exists on every Linux box, so the contract that exists
        # precisely to stop a ficha closing without demonstrable evidence could
        # be satisfied three times over by one file nobody in the repo can read
        # in a review, on a reviewer's machine that may not even have it.
        # Found by making `probe_path_containment` execute this function instead
        # of grepping `src/` for the word `is_relative_to`.
        if not candidato.is_relative_to(root.resolve()):
            return False
        return candidato.is_file()
    except (OSError, ValueError):
        # ValueError joined OSError when `.resolve()` entered this function on
        # 2026-09-05: an embedded NUL makes posixpath raise ValueError, not
        # OSError, so the containment fix reintroduced exactly the crash the
        # RePic regression above exists to prevent. Caught by
        # test_the_path_check_is_total_over_arbitrary_text, which is the test
        # that guards totality over the raw prose these fields really carry.
        return False


def artefacto_compartido(valor: str) -> str | None:
    """El id del artefacto compartido que `valor` cita, o None si no cita ninguno.

    Publica porque el REGISTRO de citas (que ficha cita que medicion) se calcula
    recorriendo las fichas, no leyendo un fichero paralelo -- ver el bloque de
    `EVIDENCIA_COMPARTIDA_PREFIJO` para por que no hay tal fichero.
    """
    if not valor.startswith(EVIDENCIA_COMPARTIDA_PREFIJO):
        return None
    return valor[len(EVIDENCIA_COMPARTIDA_PREFIJO):].strip() or None


def resolver_evidencia(valor: str, leg: str) -> tuple[str, str | None]:
    """(ruta relativa a la raiz, motivo de rechazo).

    `shared:<id>` nombra la medicion compartida `tasks/evidence/shared/<id>.<leg>.txt`;
    cualquier otro valor es la ruta tal cual, que es lo unico que el contrato admitia
    hasta hoy -- una ficha que no comparte nada no cambia una letra.
    """
    ident = artefacto_compartido(valor)
    if ident is None:
        return valor, None
    if not ARTEFACTO_COMPARTIDO_RE.match(ident):
        return "", (
            f"evidence.{leg} cita un artefacto compartido con id invalido: {ident!r} -- "
            f"un id es un NOMBRE (letras, digitos, `.`, `-`, `_`; empieza por letra o "
            f"digito), nunca una ruta; el artefacto vive en "
            f"{EVIDENCIA_COMPARTIDA_DIR}/<id>.{leg}.txt"
        )
    return f"{EVIDENCIA_COMPARTIDA_DIR}/{ident}.{leg}.txt", None


def vacuidad_en_fail(texto: str) -> list[str]:
    """Las lineas de un `fail.txt` que declaran que la corrida NO midio lo que dice.

    Devuelve una descripcion por linea infractora, con su NUMERO DE LINEA y la linea
    literal: un veredicto que solo dice «hay vacuidad» obliga a buscarla a mano, y este
    modulo existe para no hacer eso.
    """
    hallazgos: list[str] = []
    for n, linea in enumerate(texto.split("\n"), start=1):
        # Lo entrecomillado con backticks es una CITA, no un reporte (ver `_CITA_RE`).
        # Se sustituye por un espacio y no por "" para no pegar dos palabras vecinas y
        # fabricar una coincidencia que no estaba en el texto.
        sin_citas = _CITA_RE.sub(" ", linea)
        for nombre, patron in _VACUIDAD_FAIL:
            if not patron.search(sin_citas):
                continue
            if nombre.startswith("XFAIL") and _RAZON_EN_LA_LINEA_RE.search(linea):
                continue
            hallazgos.append(f"linea {n} ({nombre}): {linea.strip()[:120]!r}")
            break
    return hallazgos


def _leer_artefacto(root: Path, ruta: str) -> str | None:
    """El texto del artefacto, o None si no se pudo leer. Nunca lanza: un artefacto
    ilegible NO es un artefacto vacio ni uno valido, y condenar por un fallo de lectura
    seria acusar al sujeto de un fallo del instrumento."""
    try:
        return (root / ruta).read_text(encoding="utf-8", errors="replace")
    except (OSError, ValueError):
        return None


def _tokens_del_sujeto(fm: dict[str, object]) -> set[str]:
    """Las palabras que identifican de que va ESTA ficha: las de su `id` y las de los
    argumentos con forma de ruta o modulo de su `close_check.cmd`, menos las genericas."""
    tokens: set[str] = set()
    tokens |= {t for t in re.split(r"[^a-z0-9]+", str(fm.get("id", "")).lower())
               if len(t) >= _TOKEN_MINIMO}
    cmd = str(_obj(fm.get("close_check")).get("cmd", "") or "")
    for arg in cmd.split():
        if "." in arg or "/" in arg:
            tokens |= {t for t in re.split(r"[^a-z0-9]+", arg.lower())
                       if len(t) >= _TOKEN_MINIMO}
    return tokens - _TOKEN_GENERICO


def e2e_no_nombra_su_sujeto(fm: dict[str, object], root: Path) -> bool | None:
    """True cuando el `e2e.txt` de la ficha no menciona ni un solo token de su sujeto.

    None = NO SE PUDO JUZGAR (no hay ruta, no existe, no se lee, o la ficha no aporta
    ningun token propio). Un `False` ahi seria decir «este artefacto habla de su ficha»
    sin haberlo comprobado, que es el molde exacto que este modulo persigue.

    Por que existe: tras 153 fichas, agente_inmobiliario no pudo nombrar UNA SOLA cosa
    que la pata `e2e` cazara y que `pass`+`fail` no cazaran ya. Sus 76 ficheros `e2e`
    dicen todos alguna variante de *"ruff limpio, pytest verde, pyright 0"* -- el estado
    del repo, que ya mide el pre-push, no la evidencia de esa ficha.

    Se AVISA, nunca condena: a esta escala no se puede distinguir «ceremonia» de «una
    corrida que legitimamente no nombra el fichero», y un gate con falsos positivos sobre
    historia real ensena a su lector a saltarselo.
    """
    ruta, motivo = resolver_evidencia(str(_obj(fm.get("evidence")).get("e2e", "")).strip(), "e2e")
    if motivo is not None or not ruta or not _es_ruta_existente(root, ruta):
        return None
    texto = _leer_artefacto(root, ruta)
    if texto is None:
        return None
    tokens = _tokens_del_sujeto(fm)
    if not tokens:
        return None
    bajo = texto.lower()
    return not any(t in bajo for t in tokens)


def _evidencia_fuera_de_head(root: Path, clave: str, ruta: str, sufijo: str,
                             no_juzgadas: list[str] | None) -> list[str]:
    """La violacion de una pata que existe en disco pero no esta commiteada en `HEAD`.

    Funcion propia por el mismo motivo que `_validar_rutas_de_evidencia`: en linea
    empujaba ese bucle mas alla del limite de ramas que `ruff` le vigila.

    Un git que no se pudo consultar NO devuelve violacion: anota el motivo en
    `no_juzgadas`, que `_evaluar_fichas` convierte en `could_not_run`. Quien llama sin
    colector (`no_juzgadas=None`) recibe lo mismo que antes de esta comprobacion --
    ningun veredicto --, nunca una condena inventada.

    Medido antes de cablearla (2026-09-29), con esta misma funcion sobre cada pata que
    ya pasaba existencia y `check-ignore` en fichas `done` nacidas desde
    `CONTRATO_EVIDENCE_ARTEFACTO`: 17 repos de `~/projects`, **2.520 rutas, 2.520 en
    HEAD, 0 fuera, 0 sin poder consultar** (simplecode 453, declutter 546, Atlas 497).
    Rompe cero hoy y cierra la clase, asi que va bajo la puerta que ya existe y no
    lleva fecha propia.
    """
    en_head = _git_lo_tiene_en_head(root, ruta)
    if en_head is None:
        if no_juzgadas is not None:
            no_juzgadas.append(
                f"evidence.{clave}: git no se pudo consultar para saber si {ruta!r} esta "
                "commiteado en HEAD -- sin veredicto, ni a favor ni en contra"
            )
        return []
    if en_head:
        return []
    return [
        f"evidence.{clave} existe en disco pero NO esta commiteado en HEAD: {ruta!r} -- "
        "este gate corre en pre-push, cuando HEAD ya trae todo lo que se va a publicar; "
        "lo que no esta ahi, quien clone el repo despues del push no lo tiene. Una "
        "prueba que solo vive en el arbol de trabajo de esta maquina es infalsificable "
        "para el que revisa, igual que una gitignorada. `git add` el artefacto y "
        f"commitealo con la ficha{sufijo}"
    ]


def _validar_rutas_de_evidencia(ev: dict[str, object], root: Path,
                                no_juzgadas: list[str] | None = None) -> list[str]:
    """Las tres patas apuntan a un artefacto que EXISTE, que git no ignora y que esta
    commiteado en `HEAD` (CANON-017, ver `_git_lo_tiene_en_head`).

    Extraida de `_validar_status_done` al anadir `shared:`: la resolucion del valor a una
    ruta pasa a ser un paso propio, y meterlo en linea habria empujado a esa funcion mas
    alla del limite de ramas que `ruff` ya le vigila.
    """
    bad: list[str] = []
    for clave in ("pass", "fail", "e2e"):
        crudo = str(ev.get(clave, "")).strip()
        ruta, motivo = resolver_evidencia(crudo, clave)
        if motivo is not None:
            bad.append(motivo)
            continue
        compartido = artefacto_compartido(crudo)
        # Un `shared:` que no existe no es "una ruta mal escrita": es una medicion que
        # varias fichas pueden estar citando, asi que el mensaje lo dice con esas
        # palabras -- quien la borro tiene que saber que no borro un fichero suyo.
        sufijo = (f" (artefacto COMPARTIDO {compartido!r}: otras fichas pueden estar "
                  f"citando esta misma medicion)") if compartido else ""
        if _es_ruta_existente(root, ruta) and _git_lo_ignora(root, ruta):
            bad.append(
                f"evidence.{clave} existe pero git lo IGNORA: {ruta!r} -- "
                "para cualquier revisor que no sea esta maquina, esa evidencia "
                "no existe. El campo entero existe para que una verificacion "
                "pueda salir negativa ANTE OTRO; una prueba infalsificable por "
                "el que revisa es exactamente lo que el contrato impide. "
                "Copia la fila o la salida a un artefacto trackeado bajo "
                f"tasks/evidence/ y cita ese{sufijo}"
            )
            continue
        if not _es_ruta_existente(root, ruta):
            bad.append(
                f"evidence.{clave} apunta a algo que no existe: {ruta!r} — el "
                "contrato pide el ARTEFACTO, no su descripcion; una ruta muerta "
                "es exactamente el `evidence` que se inventa para que el gate "
                f"no se queje{sufijo}"
            )
            continue
        bad += _evidencia_fuera_de_head(root, clave, ruta, sufijo, no_juzgadas)
    return bad


def _validar_fail_no_vacio(ev: dict[str, object], root: Path) -> list[str]:
    """El `fail.txt` no puede declarar por escrito que no midio nada.

    Se aplica a TODA ficha `done` cuyo `fail` resuelva a un artefacto legible, sin la
    puerta de `CONTRATO_EVIDENCE_ARTEFACTO` que si lleva la comprobacion de existencia.
    La razon es medida, no estetica: de los 385 artefactos de `tasks/evidence/` de este
    repo, 0 contienen una senal de vacuidad, asi que la regla fuerte rompe cero. Una
    ficha con `fail` en prosa (la convencion vieja de 8 repos) no resuelve a un fichero
    y sale de aqui sin tocar, igual que antes.
    """
    ruta, motivo = resolver_evidencia(str(ev.get("fail", "")).strip(), "fail")
    if motivo is not None or not ruta or not _es_ruta_existente(root, ruta):
        return []
    texto = _leer_artefacto(root, ruta)
    if texto is None:
        return []
    hallazgos = vacuidad_en_fail(texto)
    if not hallazgos:
        return []
    return [
        f"evidence.fail es VACUO: {ruta!r} declara {len(hallazgos)} senal(es) de que la "
        f"corrida no midio lo que la ficha afirma -- {hallazgos[0]}. Un `fail` que salta "
        "el test no es un control negativo: es la misma corrida que el `pass`, sin el "
        "sujeto. Corre el control contra el codigo PRE-fix y pega esa salida"
    ]


def _validar_status_done(fm: dict[str, object], root: Path | None = None,
                         no_juzgadas: list[str] | None = None) -> list[str]:
    """`done` exige `evidence` con pass, fail y e2e -- y que los tres EXISTAN.

    Hasta el 2026-09-04 esto comprobaba unicamente que las tres claves fueran no
    vacias, asi que cualquier cadena las satisfacia: una ficha podia citar tres
    rutas inventadas y salir en verde. Medido por la sesion agente_inmobiliario
    ese mismo dia -- un agente al que se le dio el contrato POR ESCRITO cerro 8
    fichas escribiendo descripciones donde van rutas, y el gate las paso
    (`checked=144 passed=13 failed=0`, con 24 rutas muertas comprobadas con
    `.exists()` FUERA del gate).

    Por que es P1 y no cosmetico: `evidence` existe para impedir cerrar sin poder
    demostrar el veredicto contrario. Un contrato satisfacible con prosa deja
    `done_unverified` -- que es honesto, porque DECLARA que no hay evidencia --
    como el estado mas limpio del ledger, y a la ficha que miente como verde.
    El comentario de este mismo archivo ya nombraba el defecto: *"el `evidence`
    que se inventaba para que el gate no se quejara"*.

    `root=None` conserva la comprobacion antigua (solo no-vacio). No es una
    puerta trasera: es lo que puede prometer quien valida un frontmatter suelto
    sin saber contra que arbol resolver una ruta relativa. Quien tiene el arbol
    -- `main`, y por tanto el hook -- pasa `root` y obtiene la fuerte.

    `no_juzgadas` recoge lo que no se pudo comprobar (hoy: git caido al preguntar por
    `HEAD`); ver `_evidencia_fuera_de_head`.
    """
    if fm.get("status") != "done":
        return []
    bad: list[str] = []
    ev: object = fm.get("evidence")
    if not ev:
        bad.append("status=done exige `evidence`")
    elif not all(_obj(ev).get(k) for k in ("pass", "fail", "e2e")):
        bad.append("evidence incompleta: el contrato exige pass, fail Y e2e — una "
                   "verificación que no puede salir negativa no es una verificación")
    elif root is not None:
        # La comprobacion de EXISTENCIA solo pisa a las fichas nacidas bajo el contrato
        # de artefacto. Una anterior conserva la de no-vacio: su prosa se escribio cuando
        # eso era lo pedido, y convertirla en violacion retroactiva bloquea 8 repos por
        # algo que nadie hizo mal.
        if str(fm.get("created", "")) >= CONTRATO_EVIDENCE_ARTEFACTO:
            bad += _validar_rutas_de_evidencia(_obj(ev), root, no_juzgadas)
        # La de VACUIDAD si pisa a todas, y por eso lleva su propia medicion delante
        # (ver el docstring de `_validar_fail_no_vacio`): 0 de 385 artefactos la violan.
        bad += _validar_fail_no_vacio(_obj(ev), root)
    if not fm.get("closed_at"):
        bad.append("status=done exige `closed_at`")
    return bad


def _validar_status_done_unverified(fm: dict[str, object]) -> list[str]:
    """`done_unverified` (2026-09-02, propuesto por la sesión 020 tras medir 790 fichas de
    office2office cerradas antes de que este contrato exigiera evidence): cerrada, sin
    verificación ejecutable, y ESO ES LO QUE DECLARA -- no se le exige lo que no puede dar
    sin inventarlo. Cero de las 790 puede producir un `fail` real sin fabricarlo, y `fail`
    es exactamente el campo que la regla del control negativo (CLAUDE.md) existe para
    proteger: una verificación que no puede salir negativa no es una verificación, así que
    fabricar ese campo sería peor que no tenerlo. No pasa como `done` (no está probada) ni
    bloquea como violación (no es un descuido: es honesta sobre su propio límite). Un solo
    requisito, y es el mismo que ya exige `blocked`: decir POR QUÉ no se puede verificar.
    """
    if fm.get("status") != "done_unverified":
        return []
    bad: list[str] = []
    razon = str(fm.get("unverified_reason") or "").strip()
    if not razon:
        bad.append("status=done_unverified exige `unverified_reason` (por qué no hay evidence)")
    elif len(razon) < RAZON_MINIMA:
        bad.append(f"unverified_reason de {len(razon)} chars: por debajo de {RAZON_MINIMA} es "
                   "una etiqueta y no una razon -- di POR QUE esta ficha no puede producir "
                   "una corrida negativa sin fabricarla")
    creada = str(fm.get("created") or "")
    if DATE_RE.match(creada) and creada >= CONTRATO_EVIDENCE:
        bad.append(f"created={creada} es de {CONTRATO_EVIDENCE} en adelante: una ficha nacida "
                   "bajo el contrato pudo producir `evidence` desde el primer dia, asi que "
                   "no puede declararse `done_unverified`. Ese estado declara un limite "
                   "historico, no es una salida disponible para deuda nueva")
    return bad


def validate(fm: dict[str, object], root: Path | None = None,
             no_juzgadas: list[str] | None = None) -> list[str]:
    """Lista de violaciones. Vacía = ninguna condena.

    Vacia NO siempre es «pasa»: con `root`, lo que no se pudo juzgar (git caido al
    preguntar si la evidencia esta en `HEAD`) no condena y se anota en `no_juzgadas`
    si el llamador pasa una lista. `main` la pasa y lo reporta como `could_not_run`.

    Dividida en familias el 2026-09-04 (`ruff` C901/PLR0912/PLR0915: 26 ramas, 52
    sentencias, ambas pre-existentes en `gates/ledger_schema.py` desde antes de esta
    migracion -- ver DEBT-LEDGER-SCHEMA-COMPLEXITY.md, resuelta aqui en la misma sesion
    en vez de dejada abierta, con la suite de `test_ledger_schema.py` ya cubriendo cada
    rama de forma individual como red de seguridad). Cada familia es un `if` por
    condicion que el diseno original ya tenia: esta funcion solo les puso nombre.
    """
    bad: list[str] = []
    bad += _validar_obligatorios_y_forma(fm)
    bad += _validar_close_check_y_metadatos(fm)
    bad += _validar_status_activo_o_bloqueado(fm)
    bad += _validar_status_done(fm, root, no_juzgadas)
    bad += _validar_status_done_unverified(fm)
    bad += _validar_accepted(fm)
    if fm.get("origin") == "detected" and not fm.get("detector"):
        bad.append("origin=detected exige `detector`")
    return bad


def avisos(fm: dict[str, object], root: Path | None = None) -> list[str]:
    """Lo que se dice y NO bloquea. Vacia = nada que reportar.

    Existe para que «no bloquea» no signifique «no se ve»: un aviso que no se imprime
    es indistinguible de una comprobacion que no se hizo.
    """
    notas: list[str] = []
    largo = len(str(fm.get("title", "")))
    if TITULO_REPORTADO < largo <= TITULO_MAXIMO:
        notas.append(f"title de {largo} chars, por encima de {TITULO_REPORTADO} recomendado")
    # El aviso de `e2e` generico se emite ficha a ficha SOLO para las nacidas bajo el
    # contrato de artefacto. Medido aqui el 2026-09-06: de los 128 `e2e` existentes en
    # este repo, 45 no nombran su sujeto. Avisar de los 45 uno a uno anadiria 45 filas a
    # un informe de 22 -- que es literalmente el defecto de la ficha hermana
    # (REPORT-NOISE-KILLS-SIGNAL). El numero historico no se esconde: `_reportar` lo
    # imprime como UN conteo, que es un numero que alguien puede bajar.
    if root is not None and str(fm.get("created", "")) >= CONTRATO_EVIDENCE_ARTEFACTO:
        if e2e_no_nombra_su_sujeto(fm, root):
            notas.append(
                "e2e no nombra el sujeto de su ficha: el artefacto no menciona ni el `id` "
                "ni un argumento de su `close_check` -- si dice el estado del repo (ruff "
                "limpio, pytest verde) eso ya lo mide el pre-push, y no es evidencia de "
                "ESTA ficha"
            )
    return notas


def _fichas_sin_gobernar(entries: Path, gobernadas: tuple[str, ...],
                         omitir: set[str]) -> list[Path]:
    """`.md` bajo `tasks/` que ni `paths` ni `sin_prueba` llegan a mirar. Extraida de
    `main()` el 2026-09-04 para no empujar su complejidad ciclomatica mas alla de lo
    que ya tenia (`ruff` C901/PLR0912): la logica es la misma, solo tiene nombre propio."""
    gobernadas_y_anuladas = set(gobernadas) | set(ANULADAS) | set(NO_FICHAS)
    return sorted(
        p for p in entries.rglob("*.md")
        if p.name not in omitir
        and (p.parent == entries or p.parent.name not in gobernadas_y_anuladas)
    )


def _es_par_sombra(p: Path, otro: Path) -> bool:
    """Un id duplicado puede ser un descuido, o puede ser el PAR sombra/original que
    el contrato anti-amnistia genera al reabrir una ficha `done` sin evidence: crea
    una copia en backlog/ con `status: open` y `prior_status: done`, y esa copia
    declara en su propia prosa "Migrada de tasks/<ruta>". Reportarlo como el mismo
    "id duplicado" generico oculta la relacion y empuja a "resolverlo" borrando una
    de las dos, que destruye la mitad de los campos (evidence/closed_at viven en el
    original; kind/close_check/severity los genero el contrato en la sombra).
    Medido por la sesion 020 (2026-09-04): 26 ids duplicados / 52 archivos, 24 de
    los 26 con esa prosa exacta senalando a su par."""
    texto_propio = p.read_text(encoding="utf-8", errors="replace")
    texto_otro = otro.read_text(encoding="utf-8", errors="replace")
    return (("Migrada de" in texto_propio and otro.name in texto_propio)
            or ("Migrada de" in texto_otro and p.name in texto_otro))


def _evaluar_ficha(p: Path, seen: dict[str, Path], root: Path | None = None) -> dict[str, object]:
    """Una ficha, clasificada. Extraida de `main()` el 2026-09-04 junto con las dos
    funciones de arriba: el cuerpo del `for` que clasificaba cada archivo era el grueso
    de la complejidad ciclomatica que `ruff` (C901/PLR0912) senalaba en `main()`, y
    moverlo aqui no cambia el veredicto de una sola ficha -- solo le pone nombre.

    `seen` se muta: registra el PRIMER archivo visto para cada id, para que el
    siguiente con el mismo id sepa contra quien compararse.
    """
    fm, motivo = parse(p)
    # Se comprueba `fm is None` y no `motivo`: son la misma condicion para el humano y NO
    # para el verificador de tipos, que no puede saber que van emparejados. Lo reporto la
    # sesion aequitas_os -- dos errores de pyright aqui bloqueaban su pre-push, y el archivo
    # estaba distribuido en los 17 repos, asi que el bloqueo era de la flota entera.
    if fm is None:
        return {"could_not_run": motivo or "sin frontmatter legible"}
    no_juzgadas: list[str] = []
    bad = validate(fm, root, no_juzgadas)
    ident = str(fm.get("id", ""))
    if ident in seen:
        otro = seen[ident]
        if _es_par_sombra(p, otro):
            bad.append(f"id duplicado: par SOMBRA/ORIGINAL con {otro.name} (contrato "
                       "anti-amnistia, prosa 'Migrada de') -- fusionar los campos de "
                       "ambos, no borrar ninguno a ciegas")
        else:
            bad.append(f"id duplicado, ya usado por {otro.name}")
    else:
        seen[ident] = p
    return {"could_not_run": None, "bad": bad, "fm": fm, "avisos": avisos(fm, root),
            "no_juzgadas": no_juzgadas,
            # `None` = no se pudo juzgar, y viaja como None hasta el conteo: fundirlo
            # con `False` haria que "no lo miramos" y "lo miramos y estaba bien"
            # imprimieran el mismo numero.
            "e2e_generico": (e2e_no_nombra_su_sujeto(fm, root) if root is not None else None)}


def _close_check_cmd(fm: dict) -> str:
    """El comando que la ficha enuncia como criterio de cierre, o "".

    Delegado a `closing_command` el 2026-09-06. Tenia su propia precedencia
    escrita a mano y era la CONTRARIA a la de `backlog_verifier`: dos organos
    del mismo kit leyendo obligaciones distintas de la misma ficha, que es
    literalmente la deuda que este cambio cierra. Se conserva el nombre porque
    lo llama `_criterio_mas_compartido`.
    """
    return closing_command(fm).cmd


def _criterio_mas_compartido(fichas: list[tuple[str, dict]]) -> tuple[str, int, int]:
    """El `close_check` que más fichas comparten, con cuántos TEMAS distintos.

    Hallazgo de la sesión o2o, 2026-09-05: de sus 715 `close_check` con
    comando, 358 son el MISMO -- `pytest tests/test_biff_bool_formula.py`, nueve
    funciones sobre fórmulas booleanas BIFF de Excel -- estampado sobre 343
    `WARN-d3-docstring-gap-*` que son huecos de docstring en `wpd_parser.py` y
    compañía. No hay relación; alguna migración lo estampó.

    Y pasa el contrato entero: el comando existe, está en la lista blanca, tiene
    forma de módulo y sale 0. Verifica algo real. No verifica NADA de lo que esas
    358 afirman. Es una clase peor que «un `close_check` que no puede fallar»:
    éste SÍ puede fallar y aun así no acredita nada, porque el sujeto que mide no
    es el sujeto de la ficha. Ejecutable, falsable y ajeno.

    Lo que se cuenta es el TEMA, no la repetición, y esa distinción es de o2o:
    sus 20 `ruff --select C901 parsers/doc_binary_parser.py` repetidos son
    legítimos -- el mismo defecto medido en varias fichas, y el comando CITA el
    fichero que la ficha nombra. El `test_biff_bool_formula` no cita nada de las
    343. Medido aquí el mismo día: `test_satellite_sync.py` lo comparten 12
    fichas y las 12 son `DEBT-SYNC-*` (un tema, cohesivo), mientras
    `test_task_contract_verifier.py` lo comparten 7 repartidas en 6 temas.

    Se REPORTA, nunca acusa, y el umbral no existe a propósito. A esta escala no
    puedo distinguir «estampado» de «legítimo» -- las 7 de arriba bien pueden ser
    correctas, porque el arreglo estaba en el verificador de contratos -- y un
    gate con falsos positivos sobre historia real enseña a su lector a saltárselo
    (medido en `commit_msg_claims`: 15 de 36 en la primera versión). El número va
    con su reparto y el lector juzga.
    """
    por_cmd: dict[str, list[str]] = {}
    for name, fm in fichas:
        cmd = _close_check_cmd(fm)
        if cmd:
            por_cmd.setdefault(cmd, []).append(name)
    if not por_cmd:
        return "", 0, 0
    cmd, names = max(por_cmd.items(), key=lambda kv: len(kv[1]))
    temas = {n.split("-")[1] if "-" in n else n for n in names}
    return cmd, len(names), len(temas)


def _enuncia_close_check(fm: dict) -> bool:
    """La ficha DICE como se sabria que esta resuelta (no que se haya corrido).

    Reportado y medido por la sesion o2o el 2026-09-05, con la correccion del
    caso a medias delante. La exencion de `close_check.cmd` para
    `done_unverified` es correcta a medias: de sus 103 CONV-DEBT, 71 no son
    afirmaciones tecnicas -- narracion de sesion, log historico, preguntas
    pendientes -- y para esas no existe un comando honesto, asi que exigirlo
    obliga a fabricar. Pero la exencion, tal cual, dejo a `ledger_schema` con
    CERO capturas: sus 89 fallos no se resolvieron, se reclasificaron.

    La salida no es volver a bloquear ni dejarlo pasar: es CONTAR lo que no
    bloquea. De sus 789 `done_unverified`, 700 SI enuncian como se sabria que
    estan resueltas y 89 no enuncian nada. Son dos estados distintos, el
    segundo es estrictamente peor, y fundirlos en un `unverified=789` es lo que
    convierte una exencion en amnistia. `rc` no cambia -- nadie tiene que
    fabricar -- pero el numero deja de poder esconderse, y es un numero que
    alguien puede bajar.

    Va en la PRIMERA linea a proposito, no en la fila 700: o2o le hace `head -1`
    a un informe de 879 lineas con 10% de senal, y si esa es la unica linea que
    se lee, ahi es donde tiene que estar el residuo.
    """
    return bool(closing_command(fm).cmd)


# Donde vive la huella de la corrida anterior. Es una CACHE, no evidencia: nada la cita
# desde una ficha, se puede borrar sin perder nada (la siguiente corrida vuelve a
# imprimir el detalle entero) y por eso puede vivir bajo `.simplecode/`, que git ignora.
ESTADO_INFORME_RELPATH = ".simplecode/evidence/ledger_schema_report_state.json"


def _huella_unverified(nombres: list[str]) -> str:
    """Huella estable del CONJUNTO de filas UNVERIFIED. Ordenada a proposito: que dos
    corridas listen las mismas fichas en otro orden no es un cambio que nadie deba leer."""
    return hashlib.sha256("\n".join(sorted(nombres)).encode("utf-8")).hexdigest()


def _estado_informe_previo(root: Path | None) -> dict[str, object] | None:
    """La huella de la corrida anterior, o None si no la hay o no se pudo leer.

    Nunca lanza y nunca condena: una cache ilegible tiene que degradar a «imprime el
    detalle», que es el comportamiento de siempre, no a un veredicto sobre las fichas.
    """
    if root is None:
        return None
    try:
        datos = json.loads((root / ESTADO_INFORME_RELPATH).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return datos if isinstance(datos, dict) else None


def _guardar_estado_informe(root: Path | None, huella: str, filas: int) -> None:
    """Sella la huella de ESTA corrida. Un fallo de escritura no altera el veredicto:
    solo hace que la siguiente corrida imprima el detalle, que es el lado seguro."""
    if root is None:
        return
    destino = root / ESTADO_INFORME_RELPATH
    try:
        atomic_io.write_text_durable(
            destino,
            json.dumps({"unverified_sha256": huella, "filas": filas,
                        "ts": datetime.now(timezone.utc).isoformat(timespec="seconds")},
                       ensure_ascii=False, sort_keys=True) + "\n",
        )
    except OSError as exc:
        logger.warning("no se pudo sellar %s: %s", ESTADO_INFORME_RELPATH, exc)


def _reportar(total_paths: int, resultados: dict[str, list], *,
              root: Path | None = None, verbose: bool = False) -> None:
    """El reporte. `resultados` trae `ok`, `failed`, `unverified`, `avisados`,
    `could_not_run` -- un dict y no cinco parametros posicionales, para no cambiar un
    PLR0912 (demasiadas ramas) por un PLR0913 (demasiados argumentos).

    YA NO ES PURO TEXTO, y conviene decirlo donde se lee: con `root` sella la huella del
    conjunto UNVERIFIED en `.simplecode/` para poder callarlo cuando no cambia. Medido
    por o2o sobre office2office el 2026-09-05:

        ledger_schema --check: 879 lineas · 89 accionables (FAIL) · 700 de ruido
                               (UNVERIFIED identicas corrida tras corrida) · 10% de senal

    *"No lo leo. Le hago `head -1`."* Y own_chats lo formula como principio: *"un gate
    cuya salida no cambia nunca deja de leerse, y entonces el dia que cambie tampoco"*.

    Los `FAIL` se imprimen SIEMPRE enteros, cambien o no: son la unica captura accionable
    que este organo produce, y callarlos por repetidos convertiria el arreglo en el
    defecto. Lo que se calla es exactamente lo que el conteo de la primera linea ya dice.
    `--verbose` devuelve el detalle completo sin tocar nada mas.
    """
    ok = resultados["ok"]
    failed = resultados["failed"]
    unverified = resultados["unverified"]
    avisados = resultados["avisados"]
    could_not_run = resultados["could_not_run"]
    # Counted across BOTH populations, and that is the whole correction.
    #
    # o2o found this within hours of receiving the first version, 2026-09-05,
    # and it is the same defect the counter was built to fix, reproduced by the
    # fix: in THIS schema an empty `close_check.cmd` is rejected
    # unconditionally, so a `done_unverified` ficha with no stated criterion
    # lands in `failed` and never reaches `unverified` -- and the line printed
    # "sin close_check enunciado: 0" while a member of that exact class sat in
    # `failed`, three lines below, for that exact reason. The class was not
    # absent. It was counted somewhere else.
    #
    # Their repo runs a FORK (`python gates/ledger_schema.py --check`) that
    # exempts `done_unverified` from needing a runnable `cmd`, so there the same
    # fichas do reach `unverified` -- 89 of their 789. One number, two schemas,
    # and the counter was only true under theirs.
    #
    # Reading both populations makes it true under both, which is better than
    # the three exits they offered (adopt the exemption / drop the split /
    # explain the zero) because none of those makes the NUMBER right.
    mudas = [name for name, fm in unverified if not _enuncia_close_check(fm)]
    mudas += [
        name for name, _bad, fm in failed
        if isinstance(fm, dict)
        and str(fm.get("status", "")).strip() == "done_unverified"
        and not _enuncia_close_check(fm)
    ]
    # El cero se imprime igual que el 89: sin el, "no hay ninguna" y "nadie lo
    # midio" salen iguales, que es el defecto que este informe persigue.
    print(f"checked={total_paths} passed={len(ok)} failed={len(failed)} "
          f"unverified={len(unverified)} (sin close_check enunciado: {len(mudas)}) "
          f"avisos={len(avisados)} could_not_run={len(could_not_run)}")
    for name, nota in avisados:
        print(f"  AVISO {name}: {nota}")
    for name, motivo in could_not_run:
        print(f"  COULD_NOT_RUN {name}: {motivo}")
    for name, bad, _ in failed:
        print(f"  FAIL {name}")
        for b in bad:
            print(f"        - {b}")
    # `unverified` se imprime SIEMPRE, no sólo cuando alguien lo pide: un repo con 790 fichas
    # sin verificar no es un repo limpio, aunque ninguna de las 790 esté violando el contrato
    # que declaran cumplir. Callar el número sería repetir el defecto que esta guarda existe
    # para cerrar -- el `evidence` que se inventaba para que el gate no se quejara.
    # Las tres poblaciones juntas: el criterio estampado no distingue entre una
    # ficha que pasa y una que no, asi que contarlo solo sobre `unverified`
    # subestimaria el reparto en un repo cuyas fichas estampadas si pasan.
    todas = list(unverified)
    todas += [(n, fm) for n, _bad, fm in list(ok) + list(failed) if isinstance(fm, dict)]
    cmd_top, n_fichas, n_temas = _criterio_mas_compartido(todas)
    if cmd_top and n_fichas > 1:
        print(f"  criterio de cierre mas compartido: {n_fichas} ficha(s) en "
              f"{n_temas} tema(s) -> {cmd_top}")

    _reportar_compartidos(resultados.get("compartidos", []))
    _reportar_e2e_genericos(resultados.get("e2e_genericos", []))

    mudas_set = set(mudas)
    nombres = [name for name, _ in unverified]
    huella = _huella_unverified(nombres)
    previo = _estado_informe_previo(root)
    # `nombres` vacio NO produce linea de resumen. El conteo ya esta en la primera linea
    # (`unverified=0`), asi que «0 fila(s) IDENTICAS a la corrida anterior» seria una fila
    # de informe que no dice nada -- exactamente lo que esta funcion existe para quitar.
    # Encontrado corriendo el escenario e2e de la ficha hermana, no razonando sobre el.
    sin_cambios = (bool(nombres) and not verbose and previo is not None
                   and previo.get("unverified_sha256") == huella)
    if sin_cambios:
        print(f"  UNVERIFIED: {len(unverified)} fila(s) IDENTICAS a la corrida anterior "
              f"({previo.get('ts', 'sin fecha') if previo else 'sin fecha'}) -- no se "
              f"repiten; --verbose para el detalle")
    else:
        for name in nombres:
            sufijo = "  <- sin close_check enunciado" if name in mudas_set else ""
            print(f"  UNVERIFIED {name}{sufijo}")
    _guardar_estado_informe(root, huella, len(unverified))


def _reportar_compartidos(compartidos: list[tuple[str, str]]) -> None:
    """El registro de citas de cada medicion compartida, CALCULADO en esta corrida.

    Se imprime solo si alguien comparte: en un repo donde nadie lo hace, una linea que
    diga «compartidos: 0» seria una fila mas en el informe que la ficha hermana existe
    para adelgazar. Que exista el reparto es lo que impide borrar una medicion en
    silencio -- si el artefacto desaparece, cada ficha que lo cita FALLA por su nombre.
    """
    if not compartidos:
        return
    por_id: dict[str, list[str]] = {}
    for ident, ficha in compartidos:
        por_id.setdefault(ident, []).append(ficha)
    print(f"  mediciones compartidas: {len(por_id)} artefacto(s) citado(s) por "
          f"{len({f for _, f in compartidos})} ficha(s)")
    for ident, fichas in sorted(por_id.items()):
        print(f"    shared:{ident} <- {len(set(fichas))} ficha(s): "
              f"{', '.join(sorted(set(fichas)))}")


def _reportar_e2e_genericos(veredictos: list[tuple[str, bool | None]]) -> None:
    """UN conteo, no una fila por ficha. La pata `e2e` es la que agente_inmobiliario no
    pudo acreditar tras 153 fichas, y el numero es el hallazgo; imprimir 45 filas en un
    informe de 22 seria cometer la ficha hermana para reportar esta.

    Se imprime CON su denominador y CON los que no se pudieron juzgar, porque «45 de 128»
    y «45 de los 45 que miramos» son afirmaciones distintas.
    """
    if not veredictos:
        return
    juzgados = [v for _, v in veredictos if v is not None]
    if not juzgados:
        return
    genericos = sum(1 for v in juzgados if v)
    no_juzgados = len(veredictos) - len(juzgados)
    print(f"  e2e que no nombran el sujeto de su ficha: {genericos} de {len(juzgados)} "
          f"juzgados ({no_juzgados} sin artefacto legible que juzgar) -- avisados uno a "
          f"uno solo los nacidos desde {CONTRATO_EVIDENCE_ARTEFACTO}")


def _sin_repetir(propias: list[str], ajenas: list[str]) -> list[str]:
    """Las violaciones propias mas las del contrato que no digan ya lo mismo.

    Los dos organos comparten funciones ahora, asi que la MISMA causa llega por
    los dos caminos: `close_check` contra `verification_command` sale aqui como
    la frase suelta y del contrato como `Task X: <la misma frase>`. Imprimirla
    dos veces le dice al lector que hay dos defectos donde hay uno, y ensena a
    descontar los numeros del informe -- que es como se aprende a saltarse un
    gate. Se compara por CONTENIDO (una propia contenida en la ajena), no por
    igualdad: el prefijo del contrato es justamente lo que las hace distintas.
    """
    fuera = [a for a in ajenas if not any(p and p in a for p in propias)]
    return propias + fuera


def _breaches_de_contrato(root: Path) -> dict[str, list[str]]:
    """Lo que `backlog_verifier` condenaria de estas mismas fichas, por ruta.

    ESTA es la mitad del arreglo que le faltaba a la funcion compartida de
    arriba. Un gate temprano que valida el 60% del contrato y calla sobre el
    resto **da permiso**: la sesion `agente_inmobiliario` cerro 21 fichas
    verificando con este esquema y **las 21 salieron en CONTRACT BREACH** del
    verificador de pre-push, con los commits ya encima. Este esquema aceptaba
    una ficha `done` sin `## Root Cause`, sin `## Regression Test`, y con un
    `close_check` que usa `sh -c` o una ruta de script; el verificador condena
    las cuatro.

    Lo que NO se hace, a proposito: reimplementar esas comprobaciones aqui.
    Duplicarlas es exactamente como nacieron las dos precedencias incompatibles
    del comando de cierre. Se llama a `audit_task_contracts`, que es LA misma
    funcion que corre en el push -- con sus cohortes y su fecha de corte
    incluidas, para que este gate no condene lo que aquel perdona (una ficha
    `legacy` o `done_unverified` sigue exenta de la forma, igual que alli).

    El import es diferido y no de cabecera: `backlog_verifier` importa
    `finding_backlog`, que importa este modulo, asi que en cabecera seria un
    ciclo -- la misma razon y la misma forma que ya usa
    `finding_backlog._verify_finding_reproduces`. No lleva `try/except
    ImportError`: la primera linea de este fichero ya importa
    `simplecode.utils.tool_limits`, asi que un entorno donde el paquete no se
    pueda importar no llega hasta aqui, y una rama que no puede ejecutarse
    nunca es un adorno que se lee como proteccion.

    Coste medido en este repo (2026-09-06, 160 fichas gobernadas): `breaches 0`,
    o sea que folddar el contrato aqui no condena ni una ficha que el push ya
    no condenara. Lo que cambia es CUANDO se entera quien la escribe.
    """
    from simplecode.verification import backlog_verifier

    fuera: dict[str, list[str]] = {}
    for path, motivo in backlog_verifier.audit_task_contracts(root).breaches:
        fuera.setdefault(f"{path.parent.name}/{path.name}", []).append(motivo)
    return fuera


def _evaluar_fichas(paths: list[Path], contrato: dict[str, list[str]], root: Path) -> dict[str, list]:
    """El bucle de evaluacion por ficha, extraido de `main()` para bajar su
    complejidad ciclomatica bajo el techo que `ruff` vigila (C901) --
    DEBT-LEDGER-SCHEMA-COMPLEXITY, re-medido 2026-09-07 tras sumar la
    reconciliacion de `resolve_closing_command` y `accepted`: la funcion
    volvio a subir sobre el limite de 10 que este mismo ticket ya habia
    cerrado el 2026-09-04, la misma clase de regresion que este ticket
    describe (una compuerta que se arregla una vez y se destapa con el
    siguiente cambio real, no con uno cosmetico).

    `could_not_run` aqui es SOLO lo que este bucle descubre por ficha
    (`_evaluar_ficha` devolviendo un motivo); `main()` lo suma al de
    `_fichas_sin_gobernar`, que se calcula antes y por separado.
    """
    ok: list[tuple[str, list[str], dict[str, object]]] = []
    failed: list[tuple[str, list[str], dict[str, object]]] = []
    unverified: list[tuple[str, dict[str, object]]] = []
    avisados: list[tuple[str, str]] = []
    could_not_run: list[tuple[str, str]] = []
    # El REGISTRO de citas de las mediciones compartidas: se calcula aqui, recorriendo las
    # fichas, en vez de leerse de un fichero paralelo que pudiera divergir de ellas.
    compartidos: list[tuple[str, str]] = []
    e2e_genericos: list[tuple[str, bool | None]] = []
    seen: dict[str, Path] = {}
    for p in paths:
        r = _evaluar_ficha(p, seen, root)
        if r["could_not_run"] is not None:
            could_not_run.append((p.name, cast("str", r["could_not_run"])))
            continue
        bad = _sin_repetir(cast("list[str]", r["bad"]),
                           contrato.get(f"{p.parent.name}/{p.name}", []))
        fm = cast("dict[str, object]", r["fm"])
        for nota in cast("list[str]", r["avisos"]):
            avisados.append((p.name, nota))
        for clave in ("pass", "fail", "e2e"):
            ident = artefacto_compartido(str(_obj(fm.get("evidence")).get(clave, "")).strip())
            if ident:
                compartidos.append((ident, p.name))
        if fm.get("status") == "done":
            e2e_genericos.append((p.name, cast("bool | None", r["e2e_generico"])))
        no_juzgadas = cast("list[str]", r["no_juzgadas"])
        # Sin condena pero con algo que no se pudo juzgar NO es `passed`: seria imprimir
        # como verificada una ficha cuya evidencia nadie comprobo que viaje en el push.
        # Con condena, la ficha ya falla por lo que si se juzgo y eso es un veredicto.
        if not bad and no_juzgadas:
            could_not_run.append((p.name, "; ".join(no_juzgadas)))
        elif not bad and fm.get("status") == "done_unverified":
            unverified.append((p.name, fm))
        else:
            (failed if bad else ok).append((p.name, bad, fm))
    return {"ok": ok, "failed": failed, "unverified": unverified, "avisados": avisados,
            "could_not_run": could_not_run, "compartidos": compartidos,
            "e2e_genericos": e2e_genericos}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--check", action="store_true",
                    help="vestigial: el modulo nunca escribe, aceptado por compatibilidad "
                         "con hooks existentes que ya lo pasan")
    ap.add_argument("--verbose", action="store_true",
                    help="imprime cada fila UNVERIFIED aunque el conjunto sea identico al "
                         "de la corrida anterior (los FAIL salen enteros siempre)")
    ap.add_argument("--strict-warnings", action="store_true",
                    help="convierte avisos consultivos en fallo para cierres que declaran "
                         "expresamente que no debe quedar ninguno")
    args = ap.parse_args(argv)
    entries = args.root / "tasks"
    if not entries.is_dir():
        print(f"could_not_run: {entries} no existe")
        print(f"[ledger-schema] COULD_NOT_RUN: {entries} no existe -- no hay fichas que revisar", file=sys.stderr)
        return 1
    # `README.md` documenta la carpeta, no es una ficha. Se excluye por NOMBRE y no por
    # "no tiene frontmatter": un archivo sin frontmatter que SI pretende ser ficha tiene que
    # seguir saliendo como could_not_run, o el gate se volveria ciego justo a lo que busca.
    # Se gobiernan las carpetas del kit (`backlog_verifier.GOVERNED_TASK_DIRS`) MAS
    # `roadmap/`. Hasta el 2026-09-29 eran las mismas una a una y este comentario lo afirmaba;
    # la diferencia es deliberada (ver el bloque de `GOBERNADAS`): una ficha de roadmap debe
    # tener esquema valido y no perder lineas, pero no es deuda, y `GOVERNED_TASK_DIRS` es el
    # conjunto de la auditoria de contratos de cierre, no el del esquema.
    # `archive/` queda fuera a proposito: son fichas archivadas como ruido --Atlas tiene 1,947
    # en dos lotes cuyo nombre lo declara-- y meterlas daba `could_not_run=1385`, un numero que
    # ahoga la senal real. Que el kit y este gate miren lo mismo en backlog/ y done/ evita que
    # un repo este limpio para uno y sucio para el otro, que es el defecto que el canon existe
    # para eliminar.
    paths = sorted(p for c in GOBERNADAS for p in (entries / c).glob("*.md")
                   if p.name not in OMITIR)
    ok: list[tuple[str, list[str], dict[str, object]]] = []
    failed: list[tuple[str, list[str], dict[str, object]]] = []
    unverified: list[tuple[str, dict[str, object]]] = []
    avisados: list[tuple[str, str]] = []
    could_not_run: list[tuple[str, str]] = []
    # Cobertura: un `.md` que vive bajo `tasks/` pero fuera de GOBERNADAS (y no es
    # archive/, que se excluye a proposito unas lineas arriba) es una ficha que ESTE gate
    # nunca ve -- `checked=N` se lee como "revisamos tasks/ entero" y no lo es. Medido en
    # declutter (2026-09-04): 21 fichas `done` sueltas directamente en `tasks/` (ni
    # backlog/ ni done/) pasaban invisibles -- `checked=72` sobre 106 archivos reales, con
    # las 21 sin `evidence` y el gate en verde. Sin esta rama, moverle el contrato a un
    # repo no protege nada si nadie mueve tambien sus fichas sueltas.
    for p in _fichas_sin_gobernar(entries, GOBERNADAS, OMITIR):
        could_not_run.append((
            str(p.relative_to(entries)),
            f"fuera de {'/, '.join(GOBERNADAS)}/: este gate no la revisa y "
            "checked= no la cuenta -- muevela a una carpeta gobernada",
        ))
    contrato = _breaches_de_contrato(args.root)
    resultados = _evaluar_fichas(paths, contrato, args.root)
    could_not_run += resultados["could_not_run"]
    ok, failed, unverified, avisados = (
        resultados["ok"], resultados["failed"], resultados["unverified"], resultados["avisados"])

    _reportar(len(paths), {"ok": ok, "failed": failed, "unverified": unverified,
                          "avisados": avisados, "could_not_run": could_not_run,
                          "compartidos": resultados["compartidos"],
                          "e2e_genericos": resultados["e2e_genericos"]},
              root=args.root, verbose=args.verbose)

    # Unconditional at this point: `failed` is the fully-scanned count on
    # every branch below (FAIL failed, COULD_NOT_RUN could_not_run, FAIL
    # strict_warnings, OK) -- the same count the "[ledger-schema] FAIL: ..."
    # line prints. The early `entries.is_dir()` bail above (nothing scanned
    # yet) never reaches here.
    emit_hallazgos("[ledger-schema]", len(failed))

    # El indice que este bloque regeneraba se retiro el 2026-09-02: lo generaba este gate y
    # lo leia SOLO `owns_collision`, que se retiro por llevar 0 capturas en 17 repos. Un
    # artefacto generado sin lector es trabajo que hay que mantener a cambio de nada -- el
    # print quedo huerfano referenciando `omitidas`, una variable que la escritura ya
    # retirada calculaba y que aqui nunca se definio (reportUndefinedVariable, pyright).

    # Un reporte con could_not_run > 0 NO es un reporte limpio, por muchas filas que pasen.
    if failed:
        first_name, first_bad, _ = failed[0]
        print(
            f"[ledger-schema] FAIL: {len(failed)} ficha(s) con esquema invalido; "
            f"primera tasks/{first_name} ({first_bad[0]})"
        )
        return 1
    if could_not_run:
        first_name, first_reason = could_not_run[0]
        print(
            f"[ledger-schema] COULD_NOT_RUN: {len(could_not_run)} ficha(s) no analizadas; "
            f"primera tasks/{first_name} ({first_reason})",
            file=sys.stderr,
        )
        return 1
    if args.strict_warnings and avisados:
        print(
            f"[ledger-schema] FAIL: {len(avisados)} aviso(s) bajo --strict-warnings; "
            f"primero tasks/{avisados[0][0]} ({avisados[0][1]})"
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
