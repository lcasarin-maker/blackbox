# -*- coding: utf-8 -*-
"""prek_vendor.py -- fork&own (ADR-0009) vendoring of the `prek` binary.

`prek` (https://github.com/j178/prek, MIT) is a drop-in replacement for
`pre-commit` that reads the SAME `.pre-commit-config.yaml` unchanged and
runs its hooks concurrently instead of one at a time -- measured live on
this repo (2026-08-31): 197s wall time for the full 16-hook pre-push suite,
with direct process-tree confirmation that `coverage-100` ran alongside
`observe` and later alongside `backlog-verifier`, not sequentially.

Not a pip dependency: it ships as a single compiled binary, no Python
wheel. Vendored here rather than left to `cargo install`/`brew install`
because most of the fleet (14 of 17 satellites, measured 2026-08-31) run
this project's bundled Python runtime with no other package manager
present -- the mother repo downloads once, verifies the checksum against
the value pinned below (from the SAME GitHub release, fetched
independently of the download itself), and the cached, verified binary
travels with the rest of `.simplecode/` to every satellite via the
existing runtime-sync mechanism. Never re-resolved against upstream HEAD;
only a deliberate version bump here changes what gets fetched.
"""
from __future__ import annotations

import hashlib
import platform
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from simplecode.utils import atomic_io

# ADR-0009 fork&own pin -- ref is the full commit SHA the `v0.5.5` tag
# pointed to at pin time (2026-10-06), resolved independently via the
# GitHub API (`git/ref/tags/v0.5.5` -> commit 77cca67), not trusted from
# the tag name alone. See .simplecode/fork_own.json for the registry entry.
#
# Bumped from v0.5.4/77c4056 by Luis's ballot of 2026-10-06 (after the review of
# 2026-10-05 in DEBT-upstream-watch-fork-own-upstream-j178-pr-b608864f: 45
# commits / 95 files, 77c4056..19609fe, none changes the only call this kit
# makes, `prek run --config ... --stage pre-push --all-files`, hook_install.py).
# v0.5.5 is a published release (draft=false, prerelease=false, 24 assets,
# 2026-10-05) and its tag points to 77cca67 "Bump version to 0.5.5", an
# ancestor of the reviewed head. Linux x86_64 and aarch64: the sha256 was
# computed locally over the downloaded tarball (x86_64 6060487 bytes; aarch64 by
# this module's own verification on an aarch64 host) and matched both the
# release's own `<asset>.sha256` file and the GitHub API asset digest -- three
# sources. The two Darwin pins matched on those two sources only; their
# tarballs were not downloaded for this bump. (v0.5.4 had all four computed
# locally.)
#
# Known risk accepted with the vote (row 4): since v0.5.4 `prek run` reads
# the user's prek config (`FilesystemOptions::user()`) on every run, so a
# malformed ~/.config/prek config makes `prek run` fail where v0.5.3
# ignored it. The pre-push launcher does NOT fall back to pre-commit on a
# failing `prek run` -- only on ensure_prek() returning None -- so such a
# config blocks the push. Measured 2026-09-28, see the ficha. Launcher:
# hook_install._PREFER_PREK, `[ "$rc" = 0 ] || exit "$rc"` right after
# `prek run`; the pre-commit fallback sits only behind an empty PREK_BIN.
PREK_VERSION = "v0.5.5"
PREK_REF_SHA = "77cca6719ea8e3d9cc7a973e2c9e7648f4b0381d"

_RELEASE_URL = f"https://github.com/j178/prek/releases/download/{PREK_VERSION}/{{asset}}"

# (platform.system(), platform.machine()) -> (release asset name, sha256).
# Checksums fetched from the release's own .sha256 files, independently of
# the tarball download below -- a corrupted or tampered download fails
# verification against a value that never came from the same request.
_PLATFORM_ASSETS: dict[tuple[str, str], tuple[str, str]] = {
    ("Linux", "x86_64"): (
        "prek-x86_64-unknown-linux-gnu.tar.gz",
        "5470e4aa0fc0ad9d3de7dfaf088fb746d59c2eda3b173c06418e7c8861a520eb",
    ),
    ("Linux", "aarch64"): (
        "prek-aarch64-unknown-linux-gnu.tar.gz",
        "420451a13aaf3de670dfe73b25e18dbca0d96bc3b153cc3924b9d01c3b7caa12",
    ),
    ("Darwin", "x86_64"): (
        "prek-x86_64-apple-darwin.tar.gz",
        "9ea09639374a34b6f0b7d2a2567c175221cd37e44004e9b1cf591f31f9dda1b3",
    ),
    ("Darwin", "arm64"): (
        "prek-aarch64-apple-darwin.tar.gz",
        "e4bc3132023b50020e62b073bc3147082828bf250d8b9282850c6f2bed5471b6",
    ),
}

_CACHE_RELPATH = Path(".simplecode") / "bin" / "prek"
_VERSION_MARKER_RELPATH = Path(".simplecode") / "bin" / "prek.version"
_DOWNLOAD_TIMEOUT = 30.0
# `prek --version` is a single-pass, no-network, no-repo-scan invocation --
# 10s is generous headroom over what a static binary printing its own
# version string could plausibly take, not a budget that scales with
# anything (unlike e.g. TASK_VERIFICATION_WHOLE_REPO_SCAN_TIMEOUT).
_SMOKE_TEST_TIMEOUT = 10.0


def _platform_asset() -> tuple[str, str] | None:
    """The (asset name, sha256) for this machine, or None if unsupported --
    callers must treat that as "prek unavailable here", never an error."""
    key = (platform.system(), platform.machine())
    return _PLATFORM_ASSETS.get(key)


def _sha256_of(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _cached_binary_is_current(root: Path) -> bool:
    marker = root / _VERSION_MARKER_RELPATH
    binary = root / _CACHE_RELPATH
    if not binary.is_file():
        return False
    try:
        return marker.read_text(encoding="utf-8").strip() == PREK_VERSION
    except OSError:
        return False


def _download_and_verify(asset_name: str, expected_sha256: str) -> bytes | None:
    url = _RELEASE_URL.format(asset=asset_name)
    try:
        with urllib.request.urlopen(url, timeout=_DOWNLOAD_TIMEOUT) as resp:
            data = resp.read()
    except (urllib.error.URLError, TimeoutError, OSError):
        return None
    if _sha256_of(data) != expected_sha256:
        return None
    return data


def _extract_binary(tarball: bytes, dest: Path) -> bool:
    try:
        with tempfile.TemporaryDirectory(prefix="prek_vendor_") as tmp:
            archive_path = Path(tmp) / "prek.tar.gz"
            archive_path.write_bytes(tarball)
            with tarfile.open(archive_path, "r:gz") as tf:
                member = next((m for m in tf.getmembers() if m.name.endswith("/prek") or m.name == "prek"), None)
                if member is None:
                    return False
                tf.extract(member, path=tmp, filter="data")
                extracted = Path(tmp) / member.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            # `archive_path` above stays a plain write on purpose: it lives
            # inside a TemporaryDirectory and never outlives this call. `dest`
            # does -- a torn write leaves a corrupt executable on disk that the
            # next pre-push would try to run.
            atomic_io.write_bytes_durable(dest, extracted.read_bytes())
            dest.chmod(dest.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    except (tarfile.TarError, OSError):
        return False
    return True


def ensure_prek(root: Path) -> Path | None:
    """Return a working, verified `prek` binary path for `root`, downloading
    and caching it under `.simplecode/bin/` if not already present at the
    pinned version. None on ANY failure (unsupported platform, no network,
    checksum mismatch, extraction failure) -- callers must fall back to
    plain `pre-commit`, never treat this as fatal."""
    if _cached_binary_is_current(root):
        binary = root / _CACHE_RELPATH
        return binary if _smoke_test(binary) else None

    asset = _platform_asset()
    if asset is None:
        return None
    asset_name, expected_sha256 = asset

    tarball = _download_and_verify(asset_name, expected_sha256)
    if tarball is None:
        return None

    binary = root / _CACHE_RELPATH
    if not _extract_binary(tarball, binary):
        return None
    if not _smoke_test(binary):
        return None

    try:
        marker = root / _VERSION_MARKER_RELPATH
        marker.parent.mkdir(parents=True, exist_ok=True)
        atomic_io.write_text_durable(marker, PREK_VERSION)
    except OSError:
        pass  # cache still usable this run; just re-verified next time
    return binary


def _smoke_test(binary: Path) -> bool:
    try:
        result = subprocess.run(
            [str(binary), "--version"], capture_output=True, text=True, timeout=_SMOKE_TEST_TIMEOUT, check=False
        )
    except OSError:
        return False
    return result.returncode == 0 and "prek" in result.stdout.lower()


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    print_path_only = "--print-path" in argv
    root = Path(".").resolve()
    binary = ensure_prek(root)
    if binary is None:
        if not print_path_only:
            print("[prek-vendor] COULD_NOT_RUN: unsupported platform, no network, or verification failed", file=sys.stderr)
        return 2
    if print_path_only:
        print(binary)
    else:
        print(f"[prek-vendor] OK: {binary} ({PREK_VERSION})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
