# -*- coding: utf-8 -*-
"""prek_vendor.py -- fork&own (ADR-0009) vendoring of the `prek` binary.

`prek` (https://github.com/j178/prek, MIT) is a drop-in replacement for
`pre-commit` that reads the SAME `.pre-commit-config.yaml` unchanged and
runs its hooks concurrently instead of one at a time -- measured live on
this repo (2026-08-31): 197s wall time for the full 16-hook pre-push suite,
with direct process-tree confirmation that `coverage-100` ran alongside
`observe` and later alongside `backlog-verifier`, not sequentially.

Not a pip dependency: it ships as a single compiled binary, no Python
wheel. Vendored here rather than left to `cargo install`/`brew install`
because most of the fleet (14 of 17 satellites, measured 2026-08-31) run
this project's bundled Python runtime with no other package manager
present -- the mother repo downloads once, verifies the checksum against
the value pinned below (from the SAME GitHub release, fetched
independently of the download itself), and the cached, verified binary
travels with the rest of `.simplecode/` to every satellite via the
existing runtime-sync mechanism. Never re-resolved against upstream HEAD;
only a deliberate version bump here changes what gets fetched.
"""
from __future__ import annotations

import hashlib
import platform
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from simplecode.utils import atomic_io

# ADR-0009 fork&own pin -- ref is the full commit SHA the `v0.5.4` tag
# pointed to at harvest time (2026-09-28), resolved independently via the
# GitHub API (`git/ref/tags/v0.5.4` -> commit 77c4056), not trusted from
# the tag name alone. See .simplecode/fork_own.json for the registry entry.
#
# Bumped from v0.5.3/b7eb602 by Luis's vote of 2026-09-28 (row 10 of the
# "Review 2026-09-28" in DEBT-upstream-watch-fork-own-upstream-j178-pr-
# b608864f): the 26 commits / 93 files between the two refs were read at
# patch level there and none changes the only call this kit makes, `prek
# run --config ... --stage pre-push --all-files` (hook_install.py).
# v0.5.4 is a published release (draft=false, prerelease=false, 23 assets).
# Every sha256 below was computed locally over the downloaded tarball and
# matched both the release's own `<asset>.sha256` file and the GitHub
# API asset digest -- three sources, one value each.
#
# Known risk accepted with the vote (row 4): since v0.5.4 `prek run` reads
# the user's prek config (`FilesystemOptions::user()`) on every run, so a
# malformed ~/.config/prek config makes `prek run` fail where v0.5.3
# ignored it. The pre-push launcher does NOT fall back to pre-commit on a
# failing `prek run` -- only on ensure_prek() returning None -- so such a
# config blocks the push. Measured 2026-09-28, see the ficha. Launcher:
# hook_install._PREFER_PREK, `[ "$rc" = 0 ] || exit "$rc"` right after
# `prek run`; the pre-commit fallback sits only behind an empty PREK_BIN.
PREK_VERSION = "v0.5.4"
PREK_REF_SHA = "77c4056ce76b600de77d5d425e52844a76652a58"

_RELEASE_URL = f"https://github.com/j178/prek/releases/download/{PREK_VERSION}/{{asset}}"

# (platform.system(), platform.machine()) -> (release asset name, sha256).
# Checksums fetched from the release's own .sha256 files, independently of
# the tarball download below -- a corrupted or tampered download fails
# verification against a value that never came from the same request.
_PLATFORM_ASSETS: dict[tuple[str, str], tuple[str, str]] = {
    ("Linux", "x86_64"): (
        "prek-x86_64-unknown-linux-gnu.tar.gz",
        "6147dfe64051af590f4bfc2c073a0780fb5e2cc37d9eab8e47fe9fe26c7dfb80",
    ),
    ("Linux", "aarch64"): (
        "prek-aarch64-unknown-linux-gnu.tar.gz",
        "5478e436210b5226b8db3dccdd1a2e9094b1c63d81155d96bfa8b83f0398885c",
    ),
    ("Darwin", "x86_64"): (
        "prek-x86_64-apple-darwin.tar.gz",
        "bc3ddd3a5686fa97120ec2d09db9e7353df4311a85e7b00944342ddd9c4a2035",
    ),
    ("Darwin", "arm64"): (
        "prek-aarch64-apple-darwin.tar.gz",
        "88eec06dd10fd61a9b345223fafc9bedb6746ee4cc47377551239d89d752b365",
    ),
}

_CACHE_RELPATH = Path(".simplecode") / "bin" / "prek"
_VERSION_MARKER_RELPATH = Path(".simplecode") / "bin" / "prek.version"
_DOWNLOAD_TIMEOUT = 30.0
# `prek --version` is a single-pass, no-network, no-repo-scan invocation --
# 10s is generous headroom over what a static binary printing its own
# version string could plausibly take, not a budget that scales with
# anything (unlike e.g. TASK_VERIFICATION_WHOLE_REPO_SCAN_TIMEOUT).
_SMOKE_TEST_TIMEOUT = 10.0


def _platform_asset() -> tuple[str, str] | None:
    """The (asset name, sha256) for this machine, or None if unsupported --
    callers must treat that as "prek unavailable here", never an error."""
    key = (platform.system(), platform.machine())
    return _PLATFORM_ASSETS.get(key)


def _sha256_of(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _cached_binary_is_current(root: Path) -> bool:
    marker = root / _VERSION_MARKER_RELPATH
    binary = root / _CACHE_RELPATH
    if not binary.is_file():
        return False
    try:
        return marker.read_text(encoding="utf-8").strip() == PREK_VERSION
    except OSError:
        return False


def _download_and_verify(asset_name: str, expected_sha256: str) -> bytes | None:
    url = _RELEASE_URL.format(asset=asset_name)
    try:
        with urllib.request.urlopen(url, timeout=_DOWNLOAD_TIMEOUT) as resp:
            data = resp.read()
    except (urllib.error.URLError, TimeoutError, OSError):
        return None
    if _sha256_of(data) != expected_sha256:
        return None
    return data


def _extract_binary(tarball: bytes, dest: Path) -> bool:
    try:
        with tempfile.TemporaryDirectory(prefix="prek_vendor_") as tmp:
            archive_path = Path(tmp) / "prek.tar.gz"
            archive_path.write_bytes(tarball)
            with tarfile.open(archive_path, "r:gz") as tf:
                member = next((m for m in tf.getmembers() if m.name.endswith("/prek") or m.name == "prek"), None)
                if member is None:
                    return False
                tf.extract(member, path=tmp, filter="data")
                extracted = Path(tmp) / member.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            # `archive_path` above stays a plain write on purpose: it lives
            # inside a TemporaryDirectory and never outlives this call. `dest`
            # does -- a torn write leaves a corrupt executable on disk that the
            # next pre-push would try to run.
            atomic_io.write_bytes_durable(dest, extracted.read_bytes())
            dest.chmod(dest.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    except (tarfile.TarError, OSError):
        return False
    return True


def ensure_prek(root: Path) -> Path | None:
    """Return a working, verified `prek` binary path for `root`, downloading
    and caching it under `.simplecode/bin/` if not already present at the
    pinned version. None on ANY failure (unsupported platform, no network,
    checksum mismatch, extraction failure) -- callers must fall back to
    plain `pre-commit`, never treat this as fatal."""
    if _cached_binary_is_current(root):
        binary = root / _CACHE_RELPATH
        return binary if _smoke_test(binary) else None

    asset = _platform_asset()
    if asset is None:
        return None
    asset_name, expected_sha256 = asset

    tarball = _download_and_verify(asset_name, expected_sha256)
    if tarball is None:
        return None

    binary = root / _CACHE_RELPATH
    if not _extract_binary(tarball, binary):
        return None
    if not _smoke_test(binary):
        return None

    try:
        marker = root / _VERSION_MARKER_RELPATH
        marker.parent.mkdir(parents=True, exist_ok=True)
        atomic_io.write_text_durable(marker, PREK_VERSION)
    except OSError:
        pass  # cache still usable this run; just re-verified next time
    return binary


def _smoke_test(binary: Path) -> bool:
    try:
        result = subprocess.run(
            [str(binary), "--version"], capture_output=True, text=True, timeout=_SMOKE_TEST_TIMEOUT, check=False
        )
    except OSError:
        return False
    return result.returncode == 0 and "prek" in result.stdout.lower()


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    print_path_only = "--print-path" in argv
    root = Path(".").resolve()
    binary = ensure_prek(root)
    if binary is None:
        if not print_path_only:
            print("[prek-vendor] COULD_NOT_RUN: unsupported platform, no network, or verification failed", file=sys.stderr)
        return 2
    if print_path_only:
        print(binary)
    else:
        print(f"[prek-vendor] OK: {binary} ({PREK_VERSION})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
