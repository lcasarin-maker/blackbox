# -*- coding: utf-8 -*-
"""hardening_proposal.py -- Propose-and-verify remediation for red-team evasions
(ADR-0012 "middle ground": local-LLM-assisted drafting + mechanical verification
+ adversarial review, NEVER auto-applied to real source).

The full autonomous version of this (fuzzer discovers an evasion -> system
writes and SHIPS its own patch to a security-relevant detector, no human in
the loop) was explicitly rejected as a starting point: a system whose only
check on its own security-code changes is itself has no independent signal
that a patch is actually correct, only that it's internally consistent with
whatever generated it. A patch that "fixes" the exact synthesized mutation
that triggered it while opening a different, unmeasured gap would ship green.

This module keeps a human decision at the only point that matters -- whether
a proposal becomes a real code change -- while automating everything before
that: drafting a candidate (local LLM), proving it actually works (a REAL
subprocess-isolated test run against the genuine detector, not an opinion),
and getting a second, independently-prompted pass of adversarial commentary
(local LLM again, told to be skeptical) before the proposal is ever written
down for a human to look at. Nothing here ever writes to
`ast_normalizer.py`/`red_team.py` themselves outside a temp-patch-then-
restore cycle used only to run the mechanical check.
"""
from __future__ import annotations

import ast
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from simplecode.verification import red_team
from simplecode.utils import atomic_io

# Two local model servers were measured live before choosing (2026-08-31):
#   Ollama (qwen2.5-coder:7b): `curl .../api/generate` for a 1-word reply
#     took 15s; a second, still-tiny prompt took >30s with no response.
#     `curl localhost:11434/api/ps` showed `"size_vram": 0` -- Ollama has NO
#     GPU memory (vLLM below already holds ~50GB of it) and is silently
#     running on CPU. Unusable for this task at any reasonable timeout.
#   vLLM (nemotron-3.5-lightning-30b, OpenAI-compatible on :8000): the SAME
#     kind of prompt (50 tokens) returned in 0.78s -- real GPU inference,
#     dedicated reserved memory, `vllm:num_requests_running == 0` (idle).
# vLLM is also Atlas's own shared production RAG gateway -- a real, ongoing
# consideration, confirmed fine with Atlas's own session (cross-session
# message, 2026-08-31) given this pipeline's occasional/low-volume use --
# but it is fast and idle, while Ollama is neither available nor fast
# right now. Measured reality overrides the earlier, reasonable-sounding
# preference for the smaller dedicated model.
#
# Endpoint choice within vLLM also measured, not assumed: the raw
# `/v1/completions` endpoint applies no chat template, so an
# instruction-tuned model doesn't reliably follow instructions there -- it
# free-associates text continuation instead, observed live fabricating a
# fake "HINT:" section that was never part of the prompt, then reasoning
# about ITS OWN hallucinated hint.
#
# `/v1/chat/completions` with this server's default reasoning
# (`--reasoning-parser nemotron_v3`) reliably burned the ENTIRE token
# budget on chain-of-thought without ever reaching `content` for this
# module's real (moderately complex) prompts -- reproduced at 600, 2000,
# AND 3000 max_tokens (11,049 reasoning chars, finish_reason "length",
# content None at 3000); a plain system-prompt instruction to "answer
# directly, no step-by-step reasoning" did NOT suppress it either. The
# working fix, verified live: `chat_template_kwargs: {"enable_thinking":
# false}` in the request body -- reasoning drops to 0 chars, real content
# comes back in <1s.
LOCAL_LLM_URL = "http://localhost:8000/v1/chat/completions"
LOCAL_LLM_MODEL = "nemotron-local"
LOCAL_LLM_TIMEOUT = 60.0
LOCAL_LLM_MAX_TOKENS = 800

# Mechanical verification never touches the network -- a single conviction
# probe and a narrow pytest file, both local subprocesses -- so these budgets
# are much tighter than LOCAL_LLM_TIMEOUT.
CONVICTION_PROBE_TIMEOUT = 15.0
NORMALIZER_TEST_TIMEOUT = 30.0

_NORMALIZER_RELPATH = Path("src") / "simplecode" / "guards" / "ast_normalizer.py"
_INSERTION_MARKER = "        return node\n\n\ndef normalize_ast"

# Cada regla de `ASTEvasionNormalizer.visit_Call` va envuelta en
# `# rule: <id>` / `# endrule: <id>`. No es documentacion: es lo que permite
# QUITAR una regla ya enviada de la COPIA que esta funcion verifica, y con eso
# fabricar el hueco que el control negativo necesita en vez de tomarlo prestado
# de una carencia real del normalizador.
#
# Por que existe (2026-09-06): el control negativo de
# `tests/test_hardening_proposal.py` era una evasion que el normalizador enviado
# todavia NO cubria. Esa forma caduca cuando el codigo MEJORA -- cerrar la
# evasion deja el arnes acreditando un parche inerte como arreglo real -- y se
# midio caducando tres veces en dos dias: `vars()[...]` -> `__dict__[...]` ->
# `globals()[...]`. Peor: el inventario de huecos es finito, asi que la forma
# vieja obligaba a dejar evasiones ABIERTAS a proposito para conservar el
# instrumento. Con la excision el hueco se fabrica y el inventario se puede
# cerrar entero.
_RULE_BEGIN = "        # rule: {rule_id}\n"
_RULE_END = "        # endrule: {rule_id}\n"


class RuleNotFound(Exception):
    """El id de regla pedido no esta marcado en el fuente -- COULD_NOT_RUN,
    nunca "pues no quito nada y sigo", que devolveria un veredicto sobre un
    sujeto distinto del que se pidio juzgar."""


def excise_rule(source: str, rule_id: str) -> str:
    """Devuelve `source` sin el bloque marcado `# rule: <id>` ... `# endrule: <id>`.

    Levanta `RuleNotFound` si cualquiera de los dos marcadores falta o van en
    orden invertido: un recorte silencioso a medias dejaria un fuente que
    compila y no hace lo que el llamante cree.
    """
    begin = _RULE_BEGIN.format(rule_id=rule_id)
    end = _RULE_END.format(rule_id=rule_id)
    i = source.find(begin)
    j = source.find(end)
    if i < 0 or j < 0 or j < i:
        raise RuleNotFound(
            f"rule markers for {rule_id!r} not found in ast_normalizer.py "
            f"(begin={i}, end={j})"
        )
    return source[:i] + source[j + len(end):]


# DEBT-RED-TEAM-SE-CURA-SOLO-Y-DUPLICA (segunda mitad): el bug medido fue que
# nada comparaba un bloque propuesto contra lo que YA estaba en
# `ast_normalizer.py` antes de anadirlo -- el fichero acumulo tres copias
# EXACTAS de un bloque de 12 lineas para la misma evasion, de las cuales solo
# la primera era alcanzable. `extract_rule_bodies` lee el mismo delimitador
# `# rule:`/`# endrule:` que `excise_rule` ya usaba para QUITAR una regla, esta
# vez para listarlas todas.
_RULE_BLOCK_RE = re.compile(
    r"^ {8}# rule: (?P<rule_id>\S+)\n"
    r"(?P<body>.*?)"
    r"^ {8}# endrule: (?P=rule_id)\n",
    re.MULTILINE | re.DOTALL,
)


def extract_rule_bodies(source: str) -> dict[str, str]:
    """Return `{rule_id: raw_body}` for every `# rule: <id>` ... `# endrule:
    <id>` delimited block in `source`. This is what a freshly-drafted patch
    gets compared against before it is ever proposed to a human."""
    return {m.group("rule_id"): m.group("body") for m in _RULE_BLOCK_RE.finditer(source)}


def _structural_key(code: str) -> str | None:
    """AST-shape fingerprint of a candidate rule body: ignores comments,
    blank lines, and incidental indentation -- but NOT identifiers or
    literals, so `x.y` and `obj.attr` are still different rules even when
    shaped the same (the ticket is explicit: two rules reaching the same
    behavior via different variable names are NOT necessarily duplicates).
    Returns None when `code` doesn't parse standalone (an inert or
    syntactically broken draft) so callers fall back to the textual check."""
    try:
        tree = ast.parse(textwrap.dedent(code))
    except SyntaxError:
        return None
    return ast.dump(tree, annotate_fields=True, include_attributes=False)


def _textual_key(code: str) -> str:
    """Byte-identical-after-whitespace-normalization form: dedented, each
    line right-stripped, blank lines dropped. Comments are kept -- this is
    what catches the measured bug (three byte-for-byte copies, comments
    included); the AST check above is what also catches a fresh draft that
    reaches the same rule without the shipped rule's explanatory prose."""
    lines = (line.rstrip() for line in textwrap.dedent(code).splitlines())
    return "\n".join(line for line in lines if line.strip())


def find_duplicate_rule(known_rules: dict[str, str], candidate_body: str) -> str | None:
    """Return the id of the rule in `known_rules` that `candidate_body`
    duplicates -- byte-identical after whitespace normalization, or
    AST-identical -- or None if it is genuinely new. Deliberately narrow: the
    simplest comparison that resolves the measured case (exact duplicates),
    never a rename-insensitive fuzzy match that would also flag two
    legitimately different rules."""
    candidate_text = _textual_key(candidate_body)
    candidate_ast = _structural_key(candidate_body)
    for rule_id, body in known_rules.items():
        if _textual_key(body) == candidate_text:
            return rule_id
        if candidate_ast is not None and _structural_key(body) == candidate_ast:
            return rule_id
    return None


class LocalLLMUnavailable(Exception):
    """The local model server could not be reached or returned nothing
    usable -- COULD_NOT_RUN, never silently treated as "no proposal needed"."""


def call_local_llm(
    prompt: str, model: str = LOCAL_LLM_MODEL, timeout: float = LOCAL_LLM_TIMEOUT,
    max_tokens: int = LOCAL_LLM_MAX_TOKENS,
) -> str:
    """One-shot chat completion from the LOCAL vLLM server (never a cloud
    API -- this repo's own detectors would convict a network call to draft
    security-relevant code changes as data exfiltration, and rightly so).
    Raises `LocalLLMUnavailable` on any connection/timeout/malformed-response
    failure, on a reasoning-only response that never reached `content`
    (finish_reason "length" mid-thought), or on an empty answer -- never
    returns an empty or fabricated string.
    """
    payload = json.dumps(
        {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.2,
            "chat_template_kwargs": {"enable_thinking": False},
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        LOCAL_LLM_URL, data=payload, headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise LocalLLMUnavailable(f"local LLM at {LOCAL_LLM_URL} unreachable or malformed: {exc}") from exc
    choices = body.get("choices") or []
    message = choices[0].get("message") if choices else None
    content = message.get("content") if message else None
    if not content or not content.strip():
        finish_reason = choices[0].get("finish_reason") if choices else None
        raise LocalLLMUnavailable(
            f"local LLM returned no usable content (finish_reason={finish_reason!r}, "
            f"reasoning_len={len((message or {}).get('reasoning') or '')}): consider raising max_tokens"
        )
    return _strip_markdown_fence(content.strip())


def _strip_markdown_fence(text: str) -> str:
    """The model wraps code in a ```python ... ``` fence despite being asked
    for "ONLY the code" -- strip a single leading/trailing fence pair if
    present; leave the text alone if it isn't fenced (never assume the shape
    that isn't there)."""
    lines = text.splitlines()
    if lines and lines[0].strip().startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


_DRAFT_PROMPT = """You are a Python AST normalization engineer working on a security detector's evasion-resistance layer.

A fuzzer found that this code evades detection by wrapping a real attribute-access call in an indirection trick.

Detector: {detector_id}
Mutation type: {mutation_type}
Original code (correctly convicted by the detector): {original_code}
Mutated code (EVADED -- the detector did NOT catch this): {mutated_code}

The normalizer lives in a method `ASTEvasionNormalizer.visit_Call(self, node)` that already handles other indirection tricks by returning `ast.Attribute(value=..., attr=..., ctx=ast.Load())` to desugar them back to plain `target.attr` form. Propose ONE new `if` block, as raw Python source ready to paste inside that method (matching its existing style: `isinstance()` checks on `node.func`, ending in a `return ast.Attribute(...)`), that would desugar THIS mutation's specific AST shape.

Return ONLY the Python `if` block. No prose, no markdown code fences, no explanation."""

_REVIEW_PROMPT = """You are an adversarial security code reviewer. Below is a PROPOSED patch to a Python AST normalizer used to close evasion gaps in security detectors. Be skeptical, not agreeable.

Proposed patch:
{proposed_patch}

It claims to fix this evasion:
Original (correctly convicted): {original_code}
Mutated (evaded before the patch): {mutated_code}

In 3-5 plain-text sentences (no markdown): does this patch plausibly do what it claims? Could it be too broad (rewriting code that should NOT be rewritten) or too narrow (missing an obvious variant)? Is there any way this specific rewrite could itself introduce a new evasion?"""


def draft_patch(
    mutation: red_team.RedTeamMutation, model: str = LOCAL_LLM_MODEL
) -> str:
    """Ask the local LLM to draft a normalization rule for one evaded mutation."""
    prompt = _DRAFT_PROMPT.format(
        detector_id=mutation.detector_id,
        mutation_type=mutation.mutation_type,
        original_code=mutation.original_code,
        mutated_code=mutation.mutated_code,
    )
    return call_local_llm(prompt, model=model)


def review_patch(
    patch_code: str, mutation: red_team.RedTeamMutation, model: str = LOCAL_LLM_MODEL
) -> str:
    """A SEPARATE local-LLM call, deliberately prompted to be adversarial
    about a proposal -- independent framing from `draft_patch`, not the same
    call grading its own output."""
    prompt = _REVIEW_PROMPT.format(
        proposed_patch=patch_code,
        original_code=mutation.original_code,
        mutated_code=mutation.mutated_code,
    )
    return call_local_llm(prompt, model=model)


def _indent_patch(patch_code: str) -> str:
    lines = patch_code.strip("\n").splitlines()
    return "\n".join(f"        {line}" if line.strip() else line for line in lines)


def mechanically_verify_patch(
    patch_code: str, mutation: red_team.RedTeamMutation, root: Path,
    excised_rule: str | None = None,
    known_rule_bodies: dict[str, str] | None = None,
) -> tuple[bool, str]:
    """The real gate: apply `patch_code` to a COPY of the source tree, run a
    fresh subprocess to check the specific evaded mutation is now convicted by
    the real detector AND the existing normalizer test suite still passes.

    This is a real command's real exit code, not the LLM's opinion of its own
    patch. `draft_patch`/`review_patch` can hallucinate; this cannot.

    **Antes de nada, compara contra lo que ya hay.** DEBT-RED-TEAM-SE-CURA-SOLO-Y-DUPLICA
    (segunda mitad): `ast_normalizer.py` acumulo tres copias EXACTAS del mismo
    bloque de 12 lineas porque nada comparaba el candidato contra las reglas
    YA marcadas `# rule:`/`# endrule:` antes de anadirlo. Aqui se compara
    contra esas reglas (leidas de `source`, ya excisado si `excised_rule` lo
    pide) MAS lo que el llamante pase en `known_rule_bodies` -- que
    `_propose_hardening_for_evasions` va llenando con cada regla que esta
    misma funcion verifica en la MISMA corrida, para que la evasion #2 que
    produce el mismo parche que la #1 se rechace sin correr nada. Si hay
    coincidencia, se devuelve sin tocar el sistema de ficheros ni lanzar un
    solo subprocess -- el rechazo es tan barato como la comparacion misma.

    **La copia es el arreglo, no un detalle.** Hasta el 2026-09-06 esta funcion
    parcheaba el `src/simplecode/guards/ast_normalizer.py` REAL y lo restauraba
    en un `finally`. Una restauracion no sobrevive a dos corridas solapadas: la
    segunda lee como "original" el fichero YA parcheado por la primera, y al
    restaurar deja ese parche puesto para siempre. Ocurrio de verdad ese dia --
    el `_WORKING_PATCH` de `tests/test_hardening_proposal.py` apareció, byte a
    byte, como codigo enviado en `ast_normalizer.py`, sin que nadie lo aplicara,
    y rompio `test_the_control_mutation_is_still_uncovered_by_the_shipped_normalizer`,
    que existe justo para que el arnes no acredite un parche inerte.

    Era alcanzable porque la suite corre en paralelo con xdist y esos tests NO
    llevan el marcador `mutates_real_source` que existe para mandarlos al carril
    serie -- `coverage_target` ya decia por escrito que "this repository marks no
    test `mutates_real_source`". Marcarlos habria coordinado el acceso al recurso
    compartido; copiarlo hace que no haya recurso compartido. Coste medido: 10 ms
    por copia de un `src/` de 6,6 MB y 93 ficheros, dentro de una funcion que ya
    lanza un pytest con timeout de 30 s.

    Es ademas el principio que este repo declara en otros gates: la compuerta
    JUZGA, no escribe en el arbol que juzga.
    """
    normalizer_path = root / _NORMALIZER_RELPATH
    if not normalizer_path.is_file():
        return False, f"COULD_NOT_RUN: {normalizer_path} not found"
    source = normalizer_path.read_text(encoding="utf-8")
    if _INSERTION_MARKER not in source:
        return False, "COULD_NOT_RUN: insertion marker not found in ast_normalizer.py"

    if excised_rule is not None:
        try:
            source = excise_rule(source, excised_rule)
        except RuleNotFound as exc:
            return False, f"COULD_NOT_RUN: {exc}"

    existentes = extract_rule_bodies(source)
    if known_rule_bodies is not None:
        existentes = {**existentes, **known_rule_bodies}
    duplicado = find_duplicate_rule(existentes, patch_code)
    if duplicado is not None:
        return False, f"DUPLICATE: regla propuesta ya existe como {duplicado!r}, no se duplica"

    indented = _indent_patch(patch_code)
    patched_source = source.replace(
        _INSERTION_MARKER, f"{indented}\n\n{_INSERTION_MARKER}", 1
    )
    tmp = tempfile.mkdtemp(prefix="simplecode-hardening-")
    try:
        arbol = Path(tmp) / "src"
        shutil.copytree(root / "src", arbol)
        (Path(tmp) / _NORMALIZER_RELPATH).write_text(patched_source, encoding="utf-8")

        probe = (
            "import sys; "
            f"sys.path.insert(0, {str(arbol)!r}); "
            "from simplecode.guards import pattern_detectors as pd; "
            f"detector = next((fn for fn, name, _ in pd.PATTERN_DETECTORS if name == {mutation.detector_id!r}), None); "
            f"code = {mutation.mutated_code!r}; "
            "sys.exit(0 if (detector is None or detector(code)) else 1)"
        )
        conviction_check = subprocess.run(
            [sys.executable, "-c", probe], capture_output=True, text=True, timeout=CONVICTION_PROBE_TIMEOUT,
        )
        mutation_now_convicted = conviction_check.returncode == 0

        entorno = dict(os.environ)
        entorno["PYTHONPATH"] = str(arbol) + os.pathsep + entorno.get("PYTHONPATH", "")
        # `-o pythonpath=<copia>` NO es redundante con la variable de entorno de
        # arriba, y la variable sola NO bastaba. Medido el 2026-09-06: el
        # `pyproject.toml` de este repo declara `pythonpath = ["src"]`, y pytest
        # inserta eso en `sys.path[0]` -- por delante de `PYTHONPATH`. Resultado:
        # esta mitad de la compuerta llevaba corriendo contra el arbol REAL, no
        # contra la copia parcheada, mientras su propio comentario afirmaba lo
        # contrario. Se descubrio porque la excision de `vars_subscript` daba
        # `existing ast_normalizer tests: PASS` con un parche INERTE, cuando
        # `test_normalize_vars_subscript_call` no puede pasar sin esa regla.
        # Control negativo de este arreglo, en el docstring de
        # `test_the_excision_actually_reopens_the_gap`.
        test_check = subprocess.run(
            [sys.executable, "-m", "pytest", "tests/test_ast_normalizer.py", "-q",
             "-p", "no:cacheprovider", "-o", f"pythonpath={arbol}"],
            cwd=root, capture_output=True, text=True, timeout=NORMALIZER_TEST_TIMEOUT,
            env=entorno,
        )
        existing_tests_pass = test_check.returncode == 0

        verified = mutation_now_convicted and existing_tests_pass
        evidence = (
            f"{'excised rule: ' + excised_rule + chr(10) if excised_rule else ''}"
            f"mutation now convicted: {mutation_now_convicted}"
            f"{'' if mutation_now_convicted else ' (stderr: ' + conviction_check.stderr[-300:] + ')'}\n"
            f"existing ast_normalizer tests: {'PASS' if existing_tests_pass else 'FAIL'}\n"
            f"{test_check.stdout[-500:]}"
        )
        if verified and known_rule_bodies is not None:
            # Registrada para que la SIGUIENTE llamada de esta misma corrida
            # (otra evasion, mismo parche) la vea como "ya existente" y se
            # rechace arriba sin correr nada. La clave es sintetica -- todavia
            # no tiene un rule_id real, porque nadie la ha pegado en
            # ast_normalizer.py -- pero sirve igual como cuerpo con el que
            # comparar.
            known_rule_bodies[f"{mutation.detector_id}/{mutation.mutation_type}"] = patch_code
        return verified, evidence
    except subprocess.TimeoutExpired as exc:
        return False, f"COULD_NOT_RUN: verification subprocess timed out: {exc}"
    finally:
        # Ya no hay rollback que pueda perderse: el arbol parcheado era una copia
        # y desaparece entera. `ignore_errors` porque un temporal que no se pudo
        # borrar es basura en /tmp, nunca un veredicto sobre el sujeto.
        shutil.rmtree(tmp, ignore_errors=True)


@dataclass(frozen=True)
class HardeningProposal:
    mutation: red_team.RedTeamMutation
    proposed_patch: str
    mechanically_verified: bool
    mechanical_evidence: str
    review_commentary: str | None


def propose_hardening_for_evasion(
    mutation: red_team.RedTeamMutation, root: Path, model: str = LOCAL_LLM_MODEL,
    excised_rule: str | None = None,
    known_rule_bodies: dict[str, str] | None = None,
) -> HardeningProposal:
    """Full pipeline for one evaded mutation: draft -> mechanically verify ->
    (if verified) adversarial review. Never touches real source outside the
    verify step's own temp-patch-then-restore cycle.

    `known_rule_bodies`, when given, is forwarded to `mechanically_verify_patch`
    so a duplicate of an already-verified rule from the SAME run (see
    `red_team._propose_hardening_for_evasions`) is refused before any
    subprocess runs, instead of drafting a second, redundant proposal."""
    patch = draft_patch(mutation, model=model)
    verified, evidence = mechanically_verify_patch(
        patch, mutation, root, excised_rule=excised_rule, known_rule_bodies=known_rule_bodies,
    )
    review = review_patch(patch, mutation, model=model) if verified else None
    return HardeningProposal(mutation, patch, verified, evidence, review)


def write_proposal_file(proposal: HardeningProposal, out_dir: Path) -> Path:
    """Write the proposal as a markdown artifact for human review. This is
    the ONLY output of the whole pipeline that persists -- never a commit,
    never a write to real source.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_type = proposal.mutation.mutation_type.replace("/", "_")
    path = out_dir / f"{stamp}-{proposal.mutation.detector_id}-{safe_type}.md"
    status = "MECHANICALLY VERIFIED" if proposal.mechanically_verified else "NOT VERIFIED -- do not apply"
    content = f"""# Hardening proposal: {proposal.mutation.detector_id} / {proposal.mutation.mutation_type}

**Status: {status}**

This is a DRAFT proposal, not applied to any real file. A human must review
and apply it manually if it looks correct.

## Evasion

- Detector: `{proposal.mutation.detector_id}`
- Mutation type: `{proposal.mutation.mutation_type}`
- Original (convicted): `{proposal.mutation.original_code}`
- Mutated (evaded): `{proposal.mutation.mutated_code}`

## Proposed patch (drafted by local LLM, unverified until mechanically checked)

```python
{proposal.proposed_patch}
```

## Mechanical verification (a real subprocess run, not an opinion)

```
{proposal.mechanical_evidence}
```

## Adversarial review (local LLM, independently prompted)

{proposal.review_commentary or "(skipped -- mechanical verification failed, nothing to review)"}
"""
    atomic_io.write_text_durable(path, content)
    return path
