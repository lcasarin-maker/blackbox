#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""telemetry_dispositions.py -- durable disposition ledger for blocked telemetry rows.

DECL-GOV-080: a `git push` that blocked (telemetry.jsonl row with
``status == "blocked"``) is evidence of SOMETHING, but ``telemetry.jsonl``
itself never says what -- a real defect the gate correctly caught, a false
positive in the gate itself, or a deliberately planted canary proving the
gate still convicts. Nothing in this repo turned that evidence into a
durable, reviewable verdict. This module is that verdict layer.

Hard invariants (all deliberate, none negotiable):

* ``telemetry.jsonl`` is NEVER read for anything but its content -- never
  opened for writing here. Every disposition and every legacy-migration
  record lives in its own append-only ledger under
  ``.simplecode/evidence/``.
* No disposition is ever invented. ``record_disposition`` refuses any
  ``event_id`` that does not correspond to a REAL row currently in
  ``telemetry.jsonl`` (via :func:`derive_event_id`), and refuses an empty
  ``evidence`` string -- a disposition with no evidence is exactly the
  "decorative ledger" DECL-GOV-080 was written to prevent.
* A blocked row a caller never dispositioned reports as ``could_not_dispose``,
  never silently as clean and never miscounted into another bucket. A report
  with ``could_not_dispose > 0`` is not clean (same reporting politics as
  ``audit_ledger.py``'s ``COULD_NOT_RUN`` bucket).
* Legacy rows (blocked, no ``event_id`` field -- telemetry written before
  ``gate_runner`` started stamping one) get a derived, content-addressed
  identity (``legacy:<sha256 of the row's own canonical JSON>``) instead of
  being silently dropped from the report. The migration ledger records WHEN
  each legacy row was first given that identity; it is idempotent (a second
  migration run over an unchanged telemetry.jsonl appends nothing new).

Declared limit of the automatic disposition pass
(:func:`auto_dispose_by_evidence`): its whole evidence base is
``read_telemetry_rows``, which reads ONLY the telemetry of the tree where the
hook runs. A push from a git worktree therefore cannot be auto-disposed by the
green rows sitting in main's own ``.simplecode/evidence/telemetry.jsonl`` --
the worktree has its own file and never sees them. Those rows stay
``could_not_dispose`` and still need a human verdict; nothing here merges
telemetry across trees, and nothing here pretends to.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.verification.gate_runner import HOOK_RECHECK

_TELEMETRY_RELPATH = Path(".simplecode") / "evidence" / "telemetry.jsonl"
_DISPOSITIONS_RELPATH = Path(".simplecode") / "evidence" / "telemetry_dispositions.jsonl"
_MIGRATION_RELPATH = Path(".simplecode") / "evidence" / "telemetry_legacy_migration.jsonl"

# DEBT-CABLEAR-DISPOSICION-CON-FECHA-DE-CORTE (voted by Luis 2026-09-05):
# require disposition only for blocked rows AFTER the day this gate got
# wired, and declare everything before that as historical -- reconstructing
# 600+ pre-existing rows across the fleet by hand was measured infeasible
# (own_chats: 28 of 32 reconstructed, 4 irreconstructible with the method
# exhausted). Committed (like backlog_baseline.json/hook_receipt_baseline.json)
# so the cutoff is a durable, fleet-visible decision, not a local clock read.
#
# TRACKED, and therefore NEVER written from inside a gate (DEBT-PUSH-LOOP-03,
# voted by Luis 2026-09-15). Until that vote `ensure_cutoff_declared` created
# this file on first use, and first use was `build_report` -- which runs inside
# the pre-push gate. Measured on the fleet 2026-09-15: 7 of 18 satellites
# (blog_ciudadano_x, maletin_homeopatia, migracion_atom, poe_normare,
# poe_systems, red_python, sistemas_estocasticos_ruleta) had no cutoff file at
# all, so each one's first pre-push would have had the gate write a tracked
# file mid-run -- `gate_runner._working_tree_fingerprint` sees it
# (`tree_changed_during_run`) and `clean_worktree` reports it as an
# uncommitted change. The declaration now happens only where a tracked file is
# written ON PURPOSE: `cli_new._write_project` (scaffold) and
# `satellite_sync._sync_cutoff_declaration` (a deliberate `--fix`), plus the
# explicit `--declare-cutoff` flag. The gate READS it and reports
# COULD_NOT_RUN when it is absent.
_CUTOFF_RELPATH = Path(".simplecode") / "telemetry_disposition_cutoff.json"

# The exact command a COULD_NOT_RUN message prescribes. One constant, so the
# message the operator reads and the flag that repairs it cannot drift apart.
DECLARE_CUTOFF_COMMAND = (
    "python -m simplecode.verification.telemetry_dispositions --root . --declare-cutoff"
)

# own_chats measured 7 new blocked rows in 2 minutes on a live repo --
# `--gate` demanding a hard zero on rows this fresh is red by construction.
# 5 minutes is real margin over that measurement, not a guess.
_GRACE_SECONDS = 300.0

# Names of the audit layer's OWN gate_runner-wrapped invocations, never a
# finding about the subject:
#   - "telemetry-disposition": this hook reporting on ITSELF (see the
#     `build_report` docstring below).
#   - "pre-push": `hook_install.py`'s generated `.git/hooks/pre-push` wraps
#     the ENTIRE `pre-commit run --all-files` under this one gate_runner
#     call, alongside (not instead of) each individual hook's own
#     gate_runner wrapping in `.pre-commit-config.yaml`. Its blocked row is
#     therefore always redundant with whichever real hook(s) actually
#     failed -- their OWN rows already carry the finding -- and it suffers
#     the identical grace-window self-reference as telemetry-disposition,
#     just triggered by ANY hook blocking rather than only by this one.
#     Reported live by aequitas_os (2026-09-07), traced to
#     `src/simplecode/verification/hook_install.py`'s `_PREFER_PREK` /
#     plain-pre-commit exec lines, confirmed identical in this repo's own
#     generated `.git/hooks/pre-push`.
_SELF_REFERENTIAL_CHECKS = frozenset({"telemetry-disposition", "pre-push"})

# The three states a human/agent may assert about a blocked row, each
# requiring real evidence (DECL-GOV-080 constraint: "no inventes
# disposiciones para eventos sin evidencia"). Deliberately NOT including
# `legacy_migrated`/`could_not_dispose` here -- those are REPORT-derived
# buckets (see build_report), never something a caller asserts directly.
VALID_DISPOSITIONS = ("confirmed_defect", "false_positive", "controlled_canary")

REPORT_BUCKETS = (
    "confirmed_defect", "false_positive", "controlled_canary",
    "legacy_migrated", "could_not_dispose",
    # Cutoff-era buckets (see _CUTOFF_RELPATH): never gate could_not_dispose.
    "historical_undisposed", "pending_grace",
    # DEBT-AEQUITAS-06: telemetry-disposition auditing its OWN prior blocked
    # run. Never gates -- see `_is_self_referential`.
    "self_referential",
    # DEBT-AEQUITAS-06 (second half, voted by Luis 2026-09-15): a row stamped
    # with the run id of the push currently executing. Never gates -- nobody
    # can have judged a row its own run produced seconds ago. This is the
    # identity-based replacement for `pending_grace`'s clock, which was
    # measured shorter than a single run. `is_clean` is untouched: it still
    # reads could_not_dispose and nothing else.
    "same_run",
)


class DispositionError(ValueError):
    """Raised when a disposition or migration write is refused."""


class CutoffUndeclared(DispositionError):
    """Raised when this repo has no cutoff declaration yet.

    NOT an invitation to write one: see :data:`_CUTOFF_RELPATH`. The callers
    that classify rows (:func:`build_report`, :func:`auto_dispose_by_evidence`)
    raise this instead of declaring a cutoff themselves, and :func:`main`
    turns it into a COULD_NOT_RUN with the repair command -- reporting
    politics, not a verdict about the subject.
    """


class CutoffMalformed(DispositionError):
    """Raised when the cutoff file exists but is not a readable declaration.

    Distinct from :class:`CutoffUndeclared` because the repair is different:
    an absent declaration is declared by a command, a broken TRACKED file is
    repaired by a human. Before DEBT-PUSH-LOOP-03 this case was silently
    overwritten with a fresh "now" -- which moved the cutoff of a repo whose
    history nobody had looked at, inside a gate, without a word.
    """


def _telemetry_path(root: Path) -> Path:
    return root / _TELEMETRY_RELPATH


def _dispositions_path(root: Path) -> Path:
    return root / _DISPOSITIONS_RELPATH


def _migration_path(root: Path) -> Path:
    return root / _MIGRATION_RELPATH


def _cutoff_path(root: Path) -> Path:
    return root / _CUTOFF_RELPATH


def read_cutoff(root: Path) -> dict[str, Any] | None:
    """The durable cutoff declaration, or ``None`` when this repo has none.

    Read-only, always: this function NEVER creates and NEVER repairs the file
    (DEBT-PUSH-LOOP-03 -- it is tracked, and its writers are
    :func:`declare_cutoff`'s callers outside any gate). ``None`` means "not
    declared yet", which the classifying callers turn into
    :class:`CutoffUndeclared`.

    An existing file that cannot be read, or that does not carry a non-empty
    string ``cutoff``, raises :class:`CutoffMalformed` naming the path. It is
    NOT re-declared: a tracked file a human never saw break is repaired by the
    human who owns it, and rewriting it here would move the cutoff of that
    repo's whole history silently.
    """
    path = _cutoff_path(root)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CutoffMalformed(
            f"cutoff file {path} exists but cannot be read as JSON ({exc}) -- it is a TRACKED "
            "file, so it is repaired by hand, never rewritten by this tool"
        ) from exc
    if not (isinstance(data, dict) and isinstance(data.get("cutoff"), str) and data["cutoff"]):
        raise CutoffMalformed(
            f"cutoff file {path} exists but declares no non-empty string `cutoff` -- it is a "
            "TRACKED file, so it is repaired by hand, never rewritten by this tool"
        )
    return data


def declare_cutoff(root: Path, owner: str = "simplecode") -> dict[str, Any]:
    """Declare today as this repo's cutoff, and return the declaration.

    Called ONLY from paths that write tracked files on purpose -- the
    `simplecode new` scaffold, a deliberate `sync-satellites --fix`, and the
    explicit `--declare-cutoff` flag. Never from a gate.

    Idempotent: an already-valid declaration is returned untouched (byte for
    byte -- nothing is rewritten), so a second `--fix` over the same satellite
    leaves the tree alone. A malformed one raises :class:`CutoffMalformed` and
    writes nothing, for the reason spelled out in :func:`read_cutoff`.
    """
    existing = read_cutoff(root)
    if existing is not None:
        return existing
    now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    declaration = {
        "declared": now,
        "cutoff": now,
        "owner": owner,
        "reason": (
            "DEBT-CABLEAR-DISPOSICION-CON-FECHA-DE-CORTE (voted by Luis "
            "2026-09-05): blocked rows before this moment are historical -- "
            "reconstructing them was measured infeasible at fleet scale. "
            "Only rows blocked AFTER this timestamp require a disposition."
        ),
    }
    atomic_io.write_text_durable(
        _cutoff_path(root), json.dumps(declaration, indent=2, sort_keys=True) + "\n"
    )
    return declaration


def _cutoff_ts_or_raise(root: Path) -> float | None:
    """The declared cutoff as epoch seconds, for the callers that classify rows.

    Raises :class:`CutoffUndeclared` (naming the repair command) when there is
    no declaration, and lets :class:`CutoffMalformed` through from
    :func:`read_cutoff`. Returns ``None`` only when the declaration exists but
    its timestamp cannot be parsed -- the pre-existing "cannot classify the
    era" case every caller already handles by not treating rows as historical.
    """
    declaration = read_cutoff(root)
    if declaration is None:
        raise CutoffUndeclared(
            f"no cutoff declared at {_CUTOFF_RELPATH} -- a gate never writes a tracked file; "
            f"declare it outside the gate and commit it: {DECLARE_CUTOFF_COMMAND}"
        )
    return _parse_ts(declaration.get("cutoff"))


def _parse_ts(raw: object) -> float | None:
    """A telemetry row's ``ts`` (or a cutoff's own timestamp) as epoch
    seconds, or ``None`` when it cannot be parsed -- a row/cutoff whose time
    cannot be read is neither historical nor current, and callers treat
    that as "cannot classify", never as a guessed era."""
    if not isinstance(raw, str) or not raw:
        return None
    try:
        from datetime import datetime
        return datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Every well-formed JSON-object line in ``path``, or ``[]`` if absent.

    A malformed line is skipped, never raised -- the same "a corrupt row is
    not evidence of anything, but it must not crash the whole read" stance
    ``read_telemetry_rows`` takes on ``telemetry.jsonl`` itself.
    """
    if not path.is_file():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            rows.append(data)
    return rows


def _append_jsonl(path: Path, row: dict[str, Any]) -> None:
    """Append one row to a JSONL ledger via atomic whole-file replace.

    Not a POSIX append syscall -- the same durability pattern every other
    ledger in this repo uses (``findings_ratchet.save_registry``,
    ``audit_ledger``'s own record write): read the full current content,
    add the new line in memory, atomically replace the file with a
    post-write hash verification. Logically append-only (no prior line is
    ever read back out and dropped), just not append-only at the syscall
    level.
    """
    existing = path.read_text(encoding="utf-8") if path.is_file() else ""
    if existing and not existing.endswith("\n"):
        existing += "\n"
    new_line = json.dumps(row, sort_keys=True, ensure_ascii=False)
    atomic_io.write_text_durable(path, existing + new_line + "\n")


def read_telemetry_rows(root: Path, telemetry_path: Path | None = None) -> list[dict[str, Any]]:
    """Every well-formed telemetry row -- read-only, this module never
    writes to ``telemetry.jsonl``.

    ``telemetry_path`` overrides the default ``root/.simplecode/evidence/
    telemetry.jsonl`` location -- needed by callers (e.g. `gate_effectiveness`,
    which already accepts its own `--telemetria` flag) that read a telemetry
    file living somewhere other than the conventional path, most commonly a
    sandboxed test fixture."""
    return _read_jsonl(telemetry_path if telemetry_path is not None else _telemetry_path(root))


def derive_event_id(row: dict[str, Any]) -> str:
    """A row's stable identity: its own ``event_id`` if present (the modern
    shape ``gate_runner`` stamps -- see gate_runner.py's own sha256-of-the-
    record derivation), or a content-addressed ``legacy:<sha256>`` id
    derived the SAME way (canonical sort_keys JSON of the row) when absent.

    Purely a function of the row's own content -- no I/O, so two calls on
    byte-identical rows (from telemetry.jsonl or from a migration ledger
    entry) always agree, which is what makes the migration ledger's
    hash-verifiability real rather than asserted.
    """
    event_id = row.get("event_id")
    if isinstance(event_id, str) and event_id:
        return event_id
    canonical = json.dumps(row, sort_keys=True, ensure_ascii=False, default=str)
    return "legacy:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _is_blocked(row: dict[str, Any]) -> bool:
    # A `push_recheck` row re-observes a gate whose own blocked row already needs a verdict:
    # it is not a second finding, so it asks for no second disposition.
    return row.get("status") == "blocked" and row.get("hook") != HOOK_RECHECK


def migrate_legacy_events(root: Path) -> list[dict[str, Any]]:
    """Give every legacy (no ``event_id``) BLOCKED telemetry row a durable,
    content-addressed identity, recorded in the migration ledger.

    Idempotent: re-running over an unchanged ``telemetry.jsonl`` finds every
    derived id already present in the ledger and appends nothing. Only
    BLOCKED rows are migrated -- an ``ok`` row was never evidence of
    anything DECL-GOV-080 cares about disposing.

    Returns the full current migration ledger (existing entries plus any
    just appended).
    """
    ledger_path = _migration_path(root)
    existing = _read_jsonl(ledger_path)
    known_ids = {entry.get("legacy_id") for entry in existing}
    for row in read_telemetry_rows(root):
        if not _is_blocked(row) or (isinstance(row.get("event_id"), str) and row["event_id"]):
            continue
        legacy_id = derive_event_id(row)
        if legacy_id in known_ids:
            continue
        entry = {
            "legacy_id": legacy_id,
            "migrated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "check": row.get("check", "<unknown>"),
            "ts": row.get("ts", "<unknown>"),
        }
        _append_jsonl(ledger_path, entry)
        existing.append(entry)
        known_ids.add(legacy_id)
    return existing


def _known_event_ids(root: Path) -> set[str]:
    """Every id a disposition may legally reference: every currently-blocked
    telemetry row's derived id (modern event_id or legacy: id), whether or
    not that legacy row has been migrated yet -- migration only durably
    RECORDS the id, it does not create it (derive_event_id is pure)."""
    return {derive_event_id(row) for row in read_telemetry_rows(root) if _is_blocked(row)}


@dataclass(frozen=True)
class Verdict:
    """WHAT is asserted about a blocked row: the state, and the evidence for it.

    The two travel as ONE parameter because neither half is a disposition
    without the other, and this module ALREADY refused every combination where
    one was missing: :func:`record_disposition` raised
    :class:`DispositionError` on a state outside :data:`VALID_DISPOSITIONS` and
    on evidence that was empty or whitespace-only. Those two refusals now live
    HERE, in the value, so they hold the moment a verdict is constructed rather
    than only on the one code path that appends one.

    What that buys, stated exactly and not one word more: an invalid verdict
    cannot EXIST, so no code path can be holding one. ``Verdict("confirmed_defect", "")``
    raises.

    What it does NOT buy, because the honest limit belongs next to the claim:
    static inexpressibility. The refusal is still a RUNTIME check -- moved
    earlier and concentrated in one place, neither removed nor promoted to a
    type error. That line above still parses and still type-checks; it raises
    when it runs. Anyone reading this as "the illegal case is now unwritable"
    is reading more than is here.

    Same shape as `entities.Finding`, which validates its own `severity`
    against `VALID_SEVERITIES` in `__post_init__`: this is that pattern reused
    one module over, not a new one invented for this file.

    Frozen on purpose. `__post_init__` runs once, so a verdict whose fields
    could be reassigned afterwards would put both refusals back out of reach.

    Evidence is stored exactly as given; the ``.strip()`` that normalizes what
    lands in the ledger stays at the write in :func:`record_disposition`, byte
    for byte the behaviour before this type existed.
    """

    state: str
    evidence: str

    def __post_init__(self) -> None:
        if self.state not in VALID_DISPOSITIONS:
            raise DispositionError(
                f"refusing disposition: {self.state!r} is not one of {VALID_DISPOSITIONS}"
            )
        if not self.evidence or not self.evidence.strip():
            raise DispositionError(
                f"refusing disposition with state {self.state!r}: no evidence given "
                "(a disposition with no evidence is exactly the decorative-ledger failure this guards against)"
            )


def record_disposition(
    root: Path, event_id: str, verdict: Verdict, source: str = "manual",
) -> dict[str, Any]:
    """Append a disposition, refusing anything not backed by real evidence.

    FIVE parameters since 2026-09-15 (Luis voted RESTRUCTURE over renewing the
    suppression that used to sit on this line). The pair that moved is
    ``state``+``evidence``, now :class:`Verdict` -- see there for what the
    grouping does and does not achieve. The other four did NOT move, and the
    argument for each is the one the removed suppression made:

    * ``root`` says which repo's telemetry the refusal is checked against;
    * ``event_id`` identifies the row, independently refusable (below);
    * ``source`` records whether a human or :func:`auto_dispose_by_evidence`
      wrote it, which is what makes an auto-disposition auditable afterwards;

    Refuses (raises :class:`DispositionError`, appends nothing) when:
    * ``verdict.state`` is not one of :data:`VALID_DISPOSITIONS`,
    * ``verdict.evidence`` is empty/whitespace-only,
      -- both of those at :class:`Verdict` construction, which is strictly
      BEFORE this function is entered; the rejection did not disappear into
      the grouping, it moved one call earlier. `Verdict`'s own docstring says
      why that is not the same thing as making it unwritable;
    * ``event_id`` does not match any currently-blocked telemetry row.

    The public path always checks the current telemetry file. The batch
    auto-disposer uses a private snapshot path below so the safety contract of
    this function cannot be bypassed by a caller-provided set.
    """
    if event_id not in _known_event_ids(root):
        raise DispositionError(
            f"refusing disposition: {event_id!r} does not match any currently-blocked "
            "row in telemetry.jsonl -- no evidence this event exists"
        )
    return _append_disposition(root, event_id, verdict, source)


def _record_disposition_from_snapshot(
    root: Path, event_id: str, verdict: Verdict, source: str, known_ids: set[str],
) -> dict[str, Any]:
    """Batch-only path whose IDs were derived from the telemetry rows in hand."""
    if event_id not in known_ids:
        raise DispositionError(f"refusing disposition: {event_id!r} is absent from the telemetry snapshot")
    return _append_disposition(root, event_id, verdict, source)


def _append_disposition(root: Path, event_id: str, verdict: Verdict, source: str) -> dict[str, Any]:
    entry = {
        "event_id": event_id,
        "state": verdict.state,
        "evidence": verdict.evidence.strip(),
        "source": source,
        "recorded_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    _append_jsonl(_dispositions_path(root), entry)
    return entry


def load_dispositions(root: Path) -> dict[str, dict[str, Any]]:
    """The latest disposition per event_id (append-only ledger, last write
    for a given id wins -- a correction is a new appended row, never an
    edit to a prior one)."""
    latest: dict[str, dict[str, Any]] = {}
    for entry in _read_jsonl(_dispositions_path(root)):
        eid = entry.get("event_id")
        if isinstance(eid, str) and eid:
            latest[eid] = entry
    return latest


def _current_run_id(run_id: str | None) -> str:
    """The run id this call should treat as "the push happening right now".

    ``None`` means "read the environment" (the id `gate_runner.main` minted
    for this push); an explicit string -- including ``""`` -- is taken as
    given, which is what lets a test pin it. An EMPTY id never matches
    anything: see the guards in :func:`build_report` and
    :func:`auto_dispose_by_evidence`, both of which require a non-empty id
    before comparing. That is deliberate and is the whole blast radius of
    this feature -- without it, an empty id would equal the empty ``run_id``
    of every row written before this field existed, and one unstamped push
    would excuse the entire historical file.
    """
    return os.environ.get("SIMPLECODE_RUN_ID", "") if run_id is None else run_id


def auto_dispose_by_evidence(
    root: Path, telemetry_path: Path | None = None, *, run_id: str | None = None,
) -> list[dict[str, Any]]:
    """Dispose blocked rows the telemetry itself already answered.

    DEBT-AEQUITAS-06 (voted by Luis 2026-09-15). The evidence is narrow and
    stated in full: a row blocked check ``C`` against subject ``S``, and a
    LATER row in the same file shows check ``C`` green against a DIFFERENT
    subject ``S'``. The subject moved and the check now passes on it, so the
    blocked row recorded a real defect in ``S`` that ``S'`` no longer has --
    ``confirmed_defect``, ``source="auto"``, with the green row's sha and ts
    written into the evidence string so a reader can go find it.

    What it deliberately refuses to dispose, each leaving the row as
    ``could_not_dispose`` for a human:

    * a green row with the SAME ``subject_sha`` -- the subject never changed,
      so the check convicted and acquitted the identical thing. That is a
      flaky gate, which is a finding, not a disposition;
    * a blocked row with no ``subject_sha`` -- with no identity for the
      subject there is nothing a later green row could be evidence ABOUT;
    * a green row EARLIER in the file -- order is the entire argument. A
      green that predates the block says nothing about the block;
    * a row belonging to the push currently running (``same_run``), which
      :func:`build_report` exempts anyway and which no evidence in this file
      can speak to yet;
    * a self-referential check (:data:`_SELF_REFERENTIAL_CHECKS`) -- already
      exempt, and auto-disposing it would put a fabricated verdict in the
      ledger for a row that was never a finding;
    * a row blocked AT OR BEFORE the cutoff (``historical_undisposed``) --
      it never gates, and the cutoff vote already ruled it out of scope.

    Idempotent: a row already carrying ANY disposition (human or automatic)
    is skipped, so a second pass over unchanged telemetry appends nothing.

    A write that fails (:class:`DispositionError` or :class:`OSError`) is
    printed to stderr and the pass CONTINUES. It never takes the gate down
    with it: the row simply stays undisposed and :func:`build_report` gives
    the verdict, which is the reporting politics this repo runs on -- the
    instrument reports what it could not do, it does not convert its own
    failure into a verdict about the subject.

    Returns the disposition entries it actually wrote.
    """
    current_run_id = _current_run_id(run_id)
    rows = read_telemetry_rows(root, telemetry_path)
    dispositions = load_dispositions(root)
    # Scoped to rows AFTER the cutoff, the only ones that can gate. Measured
    # live 2026-09-15 on this repo before the scope existed: 25 rows
    # auto-disposed, 24 of them `historical_undisposed` -- rows the cutoff
    # decision (voted 2026-09-05) had already declared not reconstructible,
    # so disposing them by proximity contradicts that vote and inflates
    # gate_effectiveness's confirmed_defect count with pre-cutoff history.
    cutoff_ts = _cutoff_ts_or_raise(root)
    # Computed ONCE from the rows already in hand -- see `record_disposition`'s
    # `known_ids` for why (re-deriving per row is quadratic).
    known_ids = {derive_event_id(row) for row in rows if _is_blocked(row)}
    written: list[dict[str, Any]] = []

    for index, row in enumerate(rows):
        if not _is_blocked(row):
            continue
        event_id = derive_event_id(row)
        if event_id in dispositions:
            continue
        if current_run_id and row.get("run_id") == current_run_id:
            continue
        subject_sha = row.get("subject_sha")
        if not subject_sha:
            continue
        check = row.get("check")
        if check in _SELF_REFERENTIAL_CHECKS:
            continue
        row_ts = _parse_ts(row.get("ts"))
        if row_ts is not None and cutoff_ts is not None and row_ts <= cutoff_ts:
            continue
        green = next(
            (
                later for later in rows[index + 1:]
                if later.get("check") == check
                and later.get("status") == "ok"
                and later.get("subject_sha")
                and later.get("subject_sha") != subject_sha
            ),
            None,
        )
        if green is None:
            continue
        evidence = (
            f"auto: later green row for check={check} "
            f"subject_sha={green.get('subject_sha')} ts={green.get('ts')} "
            f"supersedes blocked subject_sha={subject_sha}"
        )
        try:
            entry = _record_disposition_from_snapshot(
                root, event_id, Verdict("confirmed_defect", evidence), "auto", known_ids,
            )
        except (DispositionError, OSError) as exc:
            print(
                f"[telemetry-disposition] COULD_NOT_DISPOSE {event_id} "
                f"({check}, {row.get('ts', '<unknown>')}): {exc}",
                file=sys.stderr,
            )
            continue
        dispositions[event_id] = entry
        written.append(entry)
    return written


@dataclass
class DispositionReport:
    counts: dict[str, int] = field(default_factory=dict)
    rows: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    def is_clean(self) -> bool:
        return self.counts.get("could_not_dispose", 0) == 0


def build_report(
    root: Path, telemetry_path: Path | None = None, *, now: float | None = None,
    run_id: str | None = None,
) -> DispositionReport:
    """Classify every BLOCKED telemetry row into exactly one of
    :data:`REPORT_BUCKETS`.

    * A disposed row (modern or migrated legacy id with a recorded
      disposition) lands in its recorded state's bucket.
    * A legacy row with a migration entry but NO recorded disposition lands
      in ``legacy_migrated`` -- identified, not yet judged.
    * Everything else needs the cutoff (see :func:`read_cutoff` and
      :data:`_CUTOFF_RELPATH`, DEBT-CABLEAR-DISPOSICION-CON-FECHA-DE-CORTE) to
      decide. The cutoff is READ, never declared here: a repo with no
      declaration raises :class:`CutoffUndeclared` and a repo whose
      declaration is broken raises :class:`CutoffMalformed`, both of which
      `main` reports as COULD_NOT_RUN with the repair command. This function
      writes nothing, tracked or otherwise. Given a declaration: a row blocked
      AT OR BEFORE the cutoff is ``historical_undisposed`` (never gates -- it
      predates the day disposition was required); a row blocked AFTER the
      cutoff but within :data:`_GRACE_SECONDS` of ``now`` is
      ``pending_grace`` (too fresh to have been judged yet, never gates); a
      row blocked after the cutoff AND past its grace window with no
      disposition is ``could_not_dispose`` -- the only bucket that gates.
      A row whose ``ts`` cannot be parsed is conservatively ``could_not_dispose``:
      an unreadable timestamp is not evidence it is safely historical.
    * A row whose ``check`` names an audit-layer self-report
      (:data:`_SELF_REFERENTIAL_CHECKS`: this hook itself, or the aggregate
      ``pre-push`` wrapper `hook_install.py` generates) and carries no
      explicit disposition is ``self_referential`` -- never gates. See
      DEBT-AEQUITAS-06: this hook is one of the LAST in the pre-push stage,
      so an upstream gate that blocks EARLY in the same run produces a
      fresh row whose age, by the time THIS hook's own check point is
      reached minutes later, can already exceed :data:`_GRACE_SECONDS` --
      tripping `could_not_dispose` on this hook's OWN run, every run, for as
      long as the suite takes longer than the grace window to reach here.
      The ``pre-push`` wrapper suffers the identical defect for the exact
      same reason, triggered by ANY hook blocking rather than only by this
      one. Classifying either self-report proves nothing about the subject
      (the substantive gate's OWN blocked row is still tracked and still
      gates normally); it only proves the pipeline is slower than 300s,
      which is not a finding.

    * A row carrying the run id of the push executing RIGHT NOW is
      ``same_run`` -- never gates. Nobody can have judged a row that this
      very run produced seconds ago, and demanding it is how the 300s grace
      window came to convict itself (a run takes longer than the window, so
      the row aged out before the hook reached its own check point: 33 red
      pushes in simplecode and 20 in Atlas over 12 days). ``run_id`` defaults
      to ``$SIMPLECODE_RUN_ID`` (minted by the outermost `gate_runner` and
      inherited by every child). An EMPTY current id matches NOTHING, by
      construction -- rows written before the field existed carry no
      ``run_id``, and one unstamped push must not excuse all of them.
      :data:`_GRACE_SECONDS` stays wired as the fallback for exactly those
      rows.

    ``telemetry_path`` is forwarded to :func:`read_telemetry_rows` -- see
    there for why a caller would override it. ``now`` defaults to the real
    clock; tests pin it so the grace window is deterministic.
    """
    current_run_id = _current_run_id(run_id)
    dispositions = load_dispositions(root)
    migrated_ids = {entry.get("legacy_id") for entry in _read_jsonl(_migration_path(root))}
    cutoff_ts = _cutoff_ts_or_raise(root)
    now_ts = time.time() if now is None else now
    counts = {bucket: 0 for bucket in REPORT_BUCKETS}
    rows: dict[str, list[dict[str, Any]]] = {bucket: [] for bucket in REPORT_BUCKETS}

    for row in read_telemetry_rows(root, telemetry_path):
        if not _is_blocked(row):
            continue
        event_id = derive_event_id(row)
        disposition = dispositions.get(event_id)
        if disposition is not None:
            bucket = disposition["state"]
        elif current_run_id and row.get("run_id") == current_run_id:
            bucket = "same_run"
        elif event_id in migrated_ids:
            bucket = "legacy_migrated"
        elif row.get("check") in _SELF_REFERENTIAL_CHECKS:
            bucket = "self_referential"
        else:
            row_ts = _parse_ts(row.get("ts"))
            if row_ts is not None and cutoff_ts is not None and row_ts <= cutoff_ts:
                bucket = "historical_undisposed"
            elif row_ts is not None and (now_ts - row_ts) < _GRACE_SECONDS:
                bucket = "pending_grace"
            else:
                bucket = "could_not_dispose"
        counts[bucket] += 1
        rows[bucket].append({"event_id": event_id, "check": row.get("check", "<unknown>"), "ts": row.get("ts", "<unknown>")})

    return DispositionReport(counts=counts, rows=rows)


def _print_auto(written: list[dict[str, Any]]) -> None:
    """What the automatic pass did, INCLUDING the zero. A pass that disposed
    nothing prints "auto-disposed: 0" rather than staying silent -- silence
    reads as "did not run", and those are different facts."""
    print(f"[telemetry-disposition] auto-disposed by evidence: {len(written)}")
    for entry in written:
        print(f"  AUTO {entry['event_id']} -> {entry['state']} :: {entry['evidence']}")


def _print_report(report: DispositionReport) -> None:
    total = sum(report.counts.values())
    emit_hallazgos("[telemetry-disposition]", report.counts["could_not_dispose"])
    print(f"[telemetry-disposition] blocked rows classified: {total}")
    for bucket in REPORT_BUCKETS:
        print(f"[telemetry-disposition]   {bucket}: {report.counts[bucket]}")
    for row in report.rows["same_run"][:10]:
        print(f"  SAME_RUN {row['event_id']} ({row['check']}, {row['ts']})")
    for row in report.rows["could_not_dispose"][:10]:
        print(f"  UNDISPOSED {row['event_id']} ({row['check']}, {row['ts']})")
    if report.is_clean():
        print("[telemetry-disposition] OK: could_not_dispose == 0.")
    else:
        print(
            f"[telemetry-disposition] NOT CLEAN: could_not_dispose="
            f"{report.counts['could_not_dispose']} (blocked telemetry with no recorded verdict)."
        )


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="simplecode telemetry-disposition",
        description="DECL-GOV-080: durable disposition ledger for blocked telemetry rows.",
    )
    ap.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    ap.add_argument("--migrate-legacy", action="store_true", help="Give every legacy blocked row a durable id")
    ap.add_argument("--record", nargs=2, metavar=("EVENT_ID", "STATE"), default=None, help="Record a disposition")
    ap.add_argument("--evidence", default="", help="Evidence text (required with --record)")
    ap.add_argument("--source", default="manual", help="Origin of the disposition (with --record)")
    ap.add_argument("--report", action="store_true", help="Print the classification report")
    ap.add_argument("--gate", action="store_true", help="Exit 1 if could_not_dispose > 0")
    ap.add_argument(
        "--no-auto-dispose", action="store_true",
        help="Skip the automatic evidence pass (diagnostics: see what the gate says WITHOUT it)",
    )
    ap.add_argument(
        "--declare-cutoff", action="store_true",
        help=(
            "Declare this repo's disposition cutoff (writes the TRACKED "
            ".simplecode/telemetry_disposition_cutoff.json -- deliberately, outside any gate)"
        ),
    )
    args = ap.parse_args(argv)
    root = args.root.resolve()

    if args.migrate_legacy:
        migrated = migrate_legacy_events(root)
        print(f"[telemetry-disposition] legacy migration ledger: {len(migrated)} entr(y/ies)")

    if args.declare_cutoff:
        # The ONLY command-line path that writes the tracked cutoff file. It is
        # its own early return so `--declare-cutoff` alone never falls into the
        # report branch below (whose `not args.migrate_legacy` default would
        # otherwise run a gate the operator did not ask for).
        try:
            declaration = declare_cutoff(root)
        except CutoffMalformed as exc:
            print(f"[telemetry-disposition] COULD_NOT_RUN: {exc}")
            return 2
        print(
            f"[telemetry-disposition] cutoff declared: {declaration['cutoff']} "
            f"(owner={declaration.get('owner', '<unknown>')}, file={_CUTOFF_RELPATH}) "
            "-- commit it: it is tracked on purpose."
        )
        return 0

    if args.record is not None:
        event_id, state = args.record
        try:
            entry = record_disposition(
                root, event_id, Verdict(state, args.evidence), args.source,
            )
        except DispositionError as exc:
            # The event id is printed HERE because `Verdict` does not carry it:
            # the state/evidence refusals now raise from the value's own
            # constructor, which knows what was asserted but not about which
            # row. Dropping it from the message would have traded five
            # parameters for a refusal that names no subject.
            print(f"[telemetry-disposition] REFUSED {event_id}: {exc}")
            return 1
        print(f"[telemetry-disposition] recorded {entry['event_id']} -> {entry['state']}")
        return 0

    if args.gate or args.report or not args.migrate_legacy:
        # BEFORE the report, so the report grades the ledger the pass just
        # wrote rather than the one it found. `--no-auto-dispose` is the
        # negative control: same command, pass disabled, and a row the pass
        # would have disposed must then show up as could_not_dispose.
        # Reporting politics: an instrument that cannot run says so and exits
        # 2 (COULD_NOT_RUN), never 0 (which would read as a clean subject) and
        # never 1 (which would read as a finding about the telemetry). The
        # message carries the literal repair command, because the operator who
        # meets this is pushing a satellite enrolled minutes ago.
        try:
            if not args.no_auto_dispose:
                _print_auto(auto_dispose_by_evidence(root))
            report = build_report(root)
        except (CutoffUndeclared, CutoffMalformed) as exc:
            print(f"[telemetry-disposition] COULD_NOT_RUN: {exc}")
            return 2
        _print_report(report)
        if args.gate:
            return 0 if report.is_clean() else 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
