"""Move legacy task queues into the two-directory canonical task contract.

The canonical state is the directory: ``tasks/backlog`` is open work and
``tasks/done`` is closed work.  This command is intentionally separate from
kit synchronization; an update of verification tooling must never rewrite a
project's work records.
"""
from __future__ import annotations

import argparse
import os
import re
from dataclasses import dataclass
from pathlib import Path

from simplecode.utils import atomic_io


_LEGACY_RELATIVE_DIRS = (
    Path("ledger") / "entries",
    Path("backlog"),
    Path("tasks") / "active",
    Path("tasks") / "blocked",
    Path("tasks") / "review",
)
_ID_RE = re.compile(r"^id:\s*(\S+)\s*$", re.MULTILINE)
_STATUS_RE = re.compile(r"^status:\s*(\S+)\s*$", re.MULTILINE)
_SKIP_NAMES = frozenset({"README.md", "BACKLOG.md", "FORMATO_JOBS.md", "RETIRED.md"})


@dataclass(frozen=True)
class MigrationRow:
    source: Path
    target: Path
    task_id: str
    state: str
    detail: str

    @property
    def is_conflict(self) -> bool:
        return self.state == "CONFLICT"


def _task_id(path: Path) -> str:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return path.stem
    found = _ID_RE.search(text)
    return found.group(1) if found else path.stem


def _task_status(path: Path) -> str:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return "unreadable"
    found = _STATUS_RE.search(text)
    return found.group(1).strip().lower() if found else "missing"


def _canonical_content(path: Path) -> str:
    """Retire a legacy status while preserving every other byte of the record."""
    text = path.read_text(encoding="utf-8")
    closed = _task_status(path) in {"done", "closed", "cerrado", "resolved-verified"}
    return _STATUS_RE.sub("status: done" if closed else "status: open", text, count=1)


def legacy_task_files(root: Path) -> list[Path]:
    """Return every legacy task file once, preserving the operator's evidence."""
    files: set[Path] = set()
    for relative in _LEGACY_RELATIVE_DIRS:
        directory = root / relative
        if directory.is_dir():
            files.update(path for path in directory.rglob("*.md") if path.name not in _SKIP_NAMES)
    return sorted(files)


def plan(root: Path) -> list[MigrationRow]:
    """Build a no-write migration plan and refuse ambiguous destinations."""
    planned: dict[Path, Path] = {}
    rows: list[MigrationRow] = []
    for source in legacy_task_files(root):
        task_id = _task_id(source)
        status = _task_status(source)
        in_ledger = root / "ledger" / "entries" in source.parents
        destination = root / "tasks" / (
            "done" if in_ledger and status in {"done", "closed", "cerrado", "resolved-verified"} else "backlog"
        )
        target = destination / source.name
        if status in {"done", "closed", "cerrado", "resolved-verified"}:
            if not in_ledger:
                rows.append(MigrationRow(source, target, task_id, "CONFLICT", "closed status in an open legacy queue"))
                continue
        prior = planned.get(target)
        if prior is not None:
            rows.append(MigrationRow(source, target, task_id, "CONFLICT", f"shares destination with {prior}"))
            continue
        planned[target] = source
        if target.exists():
            rows.append(MigrationRow(source, target, task_id, "CONFLICT", "destination already exists"))
            continue
        detail = f"move to canonical {destination.name}"
        if status in {"active", "blocked", "review", "backlog", "pending"}:
            detail += "; normalize status to open"
        rows.append(MigrationRow(source, target, task_id, "READY", detail))
    return rows


def apply(root: Path) -> list[MigrationRow]:
    """Apply a complete plan or refuse all conflicts before the first write."""
    rows = plan(root)
    if any(row.is_conflict for row in rows):
        return rows
    for row in rows:
        content = _canonical_content(row.source)
        row.target.parent.mkdir(parents=True, exist_ok=True)
        atomic_io.write_text_durable(row.target, content, encoding="utf-8")
        os.unlink(row.source)
    return [
        MigrationRow(row.source, row.target, row.task_id, "MOVED", row.detail)
        for row in rows
    ]


def _print(rows: list[MigrationRow], applied: bool) -> int:
    conflicts = sum(row.is_conflict for row in rows)
    moved = sum(row.state == "MOVED" for row in rows)
    ready = sum(row.state == "READY" for row in rows)
    for row in rows:
        print(f"[{row.state}] {row.source} -> {row.target} ({row.task_id}: {row.detail})")
    print(
        f"[task-migration] planned={len(rows)} moved={moved} ready={ready} "
        f"conflicts={conflicts} applied={str(applied).lower()}"
    )
    return 1 if conflicts else 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--apply", action="store_true", help="Move all unambiguous legacy task files")
    args = parser.parse_args(argv)
    rows = apply(args.root) if args.apply else plan(args.root)
    return _print(rows, args.apply)
