#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""finding_backlog -- a finding that only ever printed is a finding nobody owns.

Every guard in this kit prints and exits. Under a zero-debt policy that is not
enough: a finding that scrolls past in a hook is indistinguishable from one that
never happened, and the owner has no way to know what is outstanding. This organ
persists each finding as its own markdown task, deduplicated by content hash,
and deletes the task when the finding stops reproducing.

Three properties, each paid for by a measured failure:

  * DEDUP BY CONTENT. The task id carries a sha1 of the finding text, so a
    repeat run of an already-filed finding is a no-op. Without it, every hook
    run appends duplicates and the directory becomes unreadable within a day.

  * PRUNE WHAT NO LONGER REPRODUCES. A task whose finding is gone is deleted;
    git log is the record. A backlog that only grows is a landfill.

  * NEVER OVERWRITE A HUMAN DECISION. A task whose `status:` was moved off
    `backlog` is left untouched, including when its finding no longer fires.
    The tool owns generation; the human owns triage.

And one property this kit's own history demands. The ancestor of this organ
generated 2,523 tickets, of which the six most frequent kinds were all
docstring-completeness nags: the mechanism was sound and its INPUT was noise, so
the directory was abandoned and the mechanism died with it. So: what feeds this
must be findings whose detector fires on a small fraction of the tree. Measured
on the live fleet at admission time, three detectors fired on 59.6%, 24.8% and
20.9% of files -- those three alone would have reproduced the burial. A finding
worth a durable ticket is a finding that is rare.

Usage:
    python3 finding_backlog.py --root REPO --findings-file F  # file, one per line
    python3 finding_backlog.py --root REPO --gate             # exit 1 if any open
Exit 0: nothing outstanding.  Exit 1 (with --gate): open debt exists, or --
once `COULD_NOT_RUN_BLOCKS` is armed -- an open task file sits outside the
`DEBT-*` corpus and was therefore never judged.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import re
import subprocess
import sys
from datetime import date, datetime
from pathlib import Path
from typing import NamedTuple

from simplecode.verification import ledger_schema
from simplecode.verification import ledger
from simplecode.verification import gate_effectiveness, presupuestos, sunset_audit
from simplecode.worktree import hook_suspension

from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos

logger = logging.getLogger("finding_backlog")

PREFIX = "DEBT"
KIT_ROOT = Path(__file__).resolve().parent.parent
ESCAPE_HATCH = "SIMPLECODE_FORCE_BACKLOG_WRITE"
FINDINGS_START = "<!-- findings:start -->"
FINDINGS_END = "<!-- findings:end -->"

# BacklogTask status: canonical set is {"open", "done"}. Measured 2026-08-23
# across every task file under tasks/ in this repo: 43 carry `status: done`,
# versus 1 `status: closed` and 1 `status: cerrado` -- both are the same
# terminal state under a different name, and `done` is what the fleet
# actually writes. Both legacy synonyms are accepted on READ (normalized to
# "done") so existing task files keep working; neither is ever WRITTEN again
# -- `_TEMPLATE` above only ever writes "open", and every writer in this
# module that closes a task must write "done", not "closed"/"cerrado".
CANONICAL_OPEN_STATUS = "open"
CANONICAL_DONE_STATUS = "done"
_LEGACY_DONE_SYNONYMS = ("done", "closed", "cerrado")


def normalize_backlog_status(raw: str | None) -> str:
    """Map a task file's `status:` value to its canonical form.

    Any of the legacy synonyms for "resolved" (`done`, `closed`, `cerrado`)
    normalize to `CANONICAL_DONE_STATUS`. Anything else -- including the
    empty/missing case -- normalizes to `CANONICAL_OPEN_STATUS`, matching
    this module's strict zero-debt invariant: only a verified-done status is
    exempt from blocking, every other label (including typos, "backlog",
    "triaged", "deferred") counts as outstanding.
    """
    value = (raw or "").strip().lower()
    if value in _LEGACY_DONE_SYNONYMS:
        return CANONICAL_DONE_STATUS
    return CANONICAL_OPEN_STATUS

_TEMPLATE = """{frontmatter}

# Technical Debt [BUG | FINDING_BACKLOG_DEBT]: {title}

## Finding

{start}
- {finding}
{end}

## Acceptance

- [ ] The finding no longer reproduces (resolved in code and pruned), OR
- [ ] Marked as `status: closed` with verifiable justification and evidence.

## Root Cause

_(Fill in when closing: what defect caused this finding, not just where.)_

## Regression Test

_(Fill in when closing: the specific test that proves it, e.g. `{verification_command}`.)_

## Verification Evidence

_(Fill in when closing: the literal command run and its literal output.)_

```json queue-job
{{
  "name": "remediate_{id}",
  "command": "{verification_command}",
  "artifact": "tasks/backlog/{id}.md"
}}
```
"""


def would_dirty_own_repo(root: Path) -> bool:
    """True when this write would be the test suite dirtying the kit's own repo.

    Ported from `dimensions/_warn_tasks.py:_suite_write_to_own_repo` (marked
    CC-81), found in the cemetery by the orphan-consumer sweep. Not theoretical:
    before this guard, `PYTEST_CURRENT_TEST=x python3 -c 'write_findings(".", [...])'`
    run from the kit produced an untracked `tasks/` directory inside simplecode
    itself. The prune path makes it worse than noise -- it can DELETE real triage.

    Deliberately narrow, and it must stay narrow: it fires only under pytest AND
    only when aimed at this very checkout. A guard that fired merely "under
    pytest" would break every legitimate test that writes to a tmp_path fixture,
    and a broken guard gets deleted.
    """
    if "PYTEST_CURRENT_TEST" not in os.environ:
        return False
    try:
        target = Path(root).resolve()
    except OSError:
        return False
    if target != KIT_ROOT:
        return False
    # Conscious escape, recorded rather than silent: a test that genuinely needs
    # to exercise the real path says so by name.
    return os.environ.get(ESCAPE_HATCH) != "1"


def stamp_verdict(root: Path, verdict: str, open_count: int) -> Path | None:
    """Record the verdict tied to the TREE it was computed over.

    Ported from `_warn_tasks.py:_stamp_verdict`. `tree_clean` is the field that
    earns its place: a verdict computed over a dirty working tree is not a
    verdict about a commit, and downstream tooling that reads the stamp without
    it would attribute one run's findings to the wrong HEAD.
    """
    try:
        def git(*args: str) -> str:
            return subprocess.run(["git", "-C", str(root), *args],
                                  capture_output=True, text=True).stdout.strip()

        head = git("rev-parse", "HEAD") or None
        # `git status --porcelain` returns an empty string BOTH for a clean tree
        # and for a directory that is not a repository at all, so reading it
        # alone stamps `tree_clean: true` over a non-repo. Absence never
        # approves: with no HEAD there is nothing to be clean relative to.
        tree_clean = (git("status", "--porcelain") == "") if head else None
        out = Path(root) / ".simplecode" / "last_backlog_verdict.json"
        # Per-repo gate output is durable state: route it through the atomic,
        # post-write-verified writer (Axiom 13) instead of a raw write_text that
        # can leave a torn or unverified file behind. write_text_durable creates
        # the parent directory itself.
        atomic_io.write_text_durable(out, json.dumps({
            "verdict": verdict,
            "open_tasks": open_count,
            "head": head,
            "tree_clean": tree_clean,
            "timestamp": datetime.now().isoformat(),
            "project": Path(root).name,
        }, indent=2))
        return out
    except OSError as exc:
        logger.warning("verdict stamp not written: %s", exc)
        return None


def _slug(text: str, limit: int = 40) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", text.lower()).strip("-")
    return slug[:limit].strip("-") or "finding"


def normalize_finding_key(finding: str) -> str:
    """Normalize finding to an invariant key (file + rule + symbol), stripping volatile line/column numbers.

    A line-number anchor (e.g. `file.py:157:5:`) breaks when any refactor shifts code lines,
    causing task_id hash drift and false resolution/reopening.
    Invariant key: strips `:line[:col]` from the path and normalizes spaces.
    """
    normalized = re.sub(r"([\w./\-]+\.\w{1,4}):\d+(?::\d+)?:?", r"\1:", finding)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized


def task_id(finding: str) -> str:
    """Stable id: normalized finding (file + rule + symbol) always maps to the same file."""
    norm = normalize_finding_key(finding)
    digest = hashlib.sha1(norm.encode("utf-8"), usedforsecurity=False).hexdigest()[:8]  # nosec B324
    return f"{PREFIX}-{_slug(norm)}-{digest}"


def backlog_dir(root: Path) -> Path:
    return Path(root) / "tasks" / "backlog"


def done_dir(root: Path) -> Path:
    return Path(root) / "tasks" / "done"


def _reopen_task_content(content: str, today: str) -> str:
    """A closed task's text, flipped back to open for reopening in place.

    Regex over the raw text, not a YAML parse -- the rest of this module reads
    `status:` the same way (`prune_finding`, `_is_task_prunable`), and a line
    named `status:`/`closed_at:`/`created:` only ever occurs once, in the
    frontmatter, so the first match is always the right one.
    """
    content = re.sub(r"^status:\s*.*$", "status: open", content, count=1, flags=re.M)
    if re.search(r"^closed_at:\s*.*$", content, re.M):
        content = re.sub(r"^closed_at:\s*.*$", f"reopened_at: {today}", content, count=1, flags=re.M)
    elif re.search(r"^reopened_at:\s*.*$", content, re.M):
        content = re.sub(r"^reopened_at:\s*.*$", f"reopened_at: {today}", content, count=1, flags=re.M)
    else:
        content = re.sub(r"^(created:\s*.*)$", rf"\1\nreopened_at: {today}", content, count=1, flags=re.M)
    return content


def _replace_finding_block(content: str, finding: str) -> str:
    """Swap the `## Finding` block's row for the finding that just reproduced.

    Needed because a reopen can carry a different verbatim finding than the one
    that was closed (e.g. an upstream watch citing a new observed SHA) even
    though both normalize to the same `task_id`. Leaving the stale row in place
    would make `prune_resolved` compare the live finding set against text that
    no longer matches anything, and prune the task out from under itself.
    """
    if FINDINGS_START not in content or FINDINGS_END not in content:
        return content
    before, rest = content.split(FINDINGS_START, 1)
    _old_row, after = rest.split(FINDINGS_END, 1)
    return f"{before}{FINDINGS_START}\n- {finding}\n{FINDINGS_END}{after}"


def _reopen_done_task(prior: Path, finding: str, today: str) -> str:
    """The content to write back to `tasks/backlog/` for a task found in `tasks/done/`.

    The prior closure is kept as history, not discarded: a `## Reopened`
    section is inserted ahead of `## Root Cause` (or appended, if that heading
    is missing) so a reader sees both the original resolution and why it did
    not hold, the same shape used to fix this by hand in commit 9f223551.
    """
    content = _replace_finding_block(
        _reopen_task_content(prior.read_text(encoding="utf-8"), today), finding)
    note = (
        f"\n## Reopened {today}\n\n"
        f"Previously closed and moved to `{prior.as_posix()}`. The finding reproduced "
        "again, so this task is reopened in place instead of being filed as a new one -- "
        "`task_id` is content-hashed and carries no timestamp (see `review_finding()` in "
        "`guards/upstream_watch.py`), so one repo always maps to one task file whether the "
        "prior copy is still in `tasks/backlog/` or has already moved to `tasks/done/`. "
        "The closure below is the prior resolution, preserved as history.\n"
    )
    marker = "\n## Root Cause"
    idx = content.find(marker)
    return f"{content[:idx]}{note}{content[idx:]}" if idx != -1 else content.rstrip("\n") + "\n" + note


def _reopen_if_closed(target: Path, prior: Path, finding: str, today: str) -> bool:
    """Write the reopened task to `target` and remove `prior`. True on success.

    Split out of `write_findings`'s loop body so that loop stays as simple as
    it was before this existed -- one more branch inline would have pushed it
    over the same complexity ceiling `main()` already sits above.
    """
    try:
        atomic_io.write_text_durable(target, _reopen_done_task(prior, finding, today))
        prior.unlink()
    except OSError as exc:
        logger.warning("could not reopen %s: %s", prior.name, exc)
        return False
    return True


def backlog_is_ignored(root: Path) -> str:
    """The .gitignore rule that swallows this repo's backlog, or "".

    Measured 2026-08-17 across the fleet: office2office ignores `tasks/`
    (.gitignore:63), so its 8 registered debt tasks are tracked by git ZERO
    times. Every finding this organ ever filed there was written to a directory
    the repo cannot see -- local state wearing a registry's clothes, invisible to
    review, to another machine, and to the next clone. Writing into it silently
    is the exact failure this kit exists to refuse: the call reported success and
    the debt did not exist anywhere anyone would look.
    """
    # Two corrections, both found by using this on the repo it was written for.
    #
    # 1. Probe the FILE this organ writes, never the directory. office2office now
    #    carries `tasks/backlog/*` plus `!tasks/backlog/DEBT-*.md`, so the
    #    directory and a WARN-* answer differently from a DEBT-*, and only the
    #    DEBT-* answer is about this organ's output.
    # 2. Decide with the exit code of a NON-verbose call. `git check-ignore -v`
    #    exits 0 whenever any pattern matched -- INCLUDING a negation -- so the
    #    first version reported office2office as ignoring a backlog it had just
    #    been fixed to track. Verified: `-q` gives rc=1 (not ignored) where `-v`
    #    gives rc=0 and prints `!tasks/backlog/`. -v is used only for the text.
    probe = f"tasks/backlog/{PREFIX}-probe.md"
    quiet = subprocess.run(["git", "check-ignore", "-q", "--", probe],
                           cwd=root, capture_output=True, text=True)
    if quiet.returncode != 0:
        return ""
    verbose = subprocess.run(["git", "check-ignore", "-v", "--", probe],
                             cwd=root, capture_output=True, text=True)
    return verbose.stdout.strip() or f"ignored (rule not reported) -- {probe}"


_FINDING_PATH = re.compile(r"^\s*(?:\[[A-ZÓÑ]+\]\s*)?([\w./\-]+\.\w{1,4}):\d+")


def _names_untracked_file(root: Path, finding: str) -> bool:
    """True if the finding opens with a `path:line` that git does not track.

    Only when a path is actually parsed out: a finding that names no file is not
    evidence of anything, so it is never reported here.
    """
    m = _FINDING_PATH.match(finding)
    if not m:
        return False
    out = subprocess.run(["git", "ls-files", "--error-unmatch", "--", m.group(1)],
                         cwd=root, capture_output=True, text=True)
    return out.returncode != 0


# The `(detector: X)` tag a harvested finding carries to name the instrument that
# must re-check it. X has to be a PATTERN_DETECTORS key; when it is not, no organ
# in the repo can read the claim.
_DETECTOR_TAG = re.compile(r"\(detector:\s*([\w.\-]+)\s*\)")


def unregistered_detector(finding: str) -> str | None:
    """The finding's `(detector: X)` tag when X is NOT a registered detector.

    Returns None for an untagged finding (it claims no instrument, which is a
    different thing) and for one whose tag names a real key.
    """
    tag = _DETECTOR_TAG.search(finding)
    if tag is None:
        return None
    from simplecode.guards.pattern_detectors import PATTERN_DETECTORS
    if tag.group(1) in {key for _fn, key, _msg in PATTERN_DETECTORS}:
        return None
    return tag.group(1)


def _reject_bogus_detectors(findings: list[str]) -> list[str]:
    """Drop findings whose detector tag is unregistered, logging each one in full."""
    kept = []
    for finding in findings:
        tag = unregistered_detector(finding)
        if tag is None:
            kept.append(finding)
            continue
        logger.warning(
            "REFUSED to file a finding tagged `(detector: %s)`: that key is not in "
            "simplecode.guards.pattern_detectors.PATTERN_DETECTORS, so no organ could "
            "ever re-check it. Re-file with a registered detector or with no tag. "
            "Full text preserved here: %s", tag, finding)
    return kept


def normalize_verification_command(raw_cmd: str) -> str:
    """Ensure a generated verification command adheres to GS2-214 whitelist and is portable."""
    from simplecode.verification import backlog_verifier
    cleaned = raw_cmd.strip().replace('"', "")
    ok, _ = backlog_verifier._validate_verification_cmd(cleaned, as_task_verification=True)
    if ok:
        return cleaned
    return "python3 -m simplecode.verification.finding_backlog --root . --gate"


def write_findings(
    root: Path,
    findings: list[str],
    today: str | None = None,
    verification_command: str = "pytest",
) -> int:
    """Persist each finding as its own task. Returns how many are now open
    that were not before this call -- freshly created, or reopened from
    `tasks/done/`.

    `task_id` is content-hashed and carries no timestamp on purpose (see
    `review_finding()` in `guards/upstream_watch.py`): "so one repo always
    maps to one task file, updated in place ... rather than by rewriting the
    task." That promise held only while the prior file stayed in
    `tasks/backlog/` -- once a task closed and moved to `tasks/done/`, a
    finding that reproduced again minted a SECOND file at the identical id,
    which `ledger_schema` then rejected as a duplicate at push time.
    Reproduced 2026-09-14 in this repo's own history: `DEBT-upstream-watch-
    fork-own-upstream-j178-pr-b608864f` closed 2026-09-07, then upstream
    advanced again and the next `upstream_watch` run wrote a fresh backlog
    file under the same id instead of reopening the one in `done/`. Fixed by
    hand that time (commit 9f223551); this is the code fix, so it does not
    need doing by hand again.

    So before creating anything, both governed directories are checked for an
    existing file at this id -- `tasks/backlog/` (unchanged: already open, a
    no-op) and `tasks/done/` (reopened in place via `_reopen_done_task`,
    which flips `status:` back to `open` and keeps the prior closure as
    history rather than discarding it).

    A finding whose `(detector: X)` tag names an unregistered detector is
    REFUSED, not filed: fail-fast instead of fail-forever. Measured live on
    Atlas 2026-08-24 -- `(detector: import_no_resuelve)`, a key that was never in
    PATTERN_DETECTORS, made its task read as reproducing on every run however
    thoroughly the code was fixed, because no organ could re-check the claim.
    A finding that names an instrument which does not exist is not a verified
    finding; letting it into the backlog manufactures work nobody can discharge.

    The refusal is LOSSLESS in the record and lossy in the backlog, and that
    trade-off is deliberate: the full text of every rejected finding is logged at
    WARNING with the tag that killed it, so a real observation behind a
    hallucinated tag is recoverable by re-filing it with a tag that exists (or
    with none). It does NOT reach the backlog on its own.
    """
    if not findings:
        return 0
    findings = _reject_bogus_detectors(findings)
    if not findings:
        return 0
    if would_dirty_own_repo(root):
        logger.warning("refusing to write into the kit's own repo under pytest "
                       "(set %s=1 to override)", ESCAPE_HATCH)
        return 0
    verification_command = normalize_verification_command(verification_command)
    untracked = [f for f in findings if _names_untracked_file(root, f)]
    if untracked:
        # Measured 2026-08-17: 3 of the 16 findings that a triage round declared
        # false positives were files under `office2office/.protocol/snapshots/`,
        # a tree the repo ignores (`.gitignore:75:.protocol/`). Nobody was ever
        # going to fix a snapshot of a file, and three agents spent a turn each
        # proving it. A finding about a file the repo does not track is not debt;
        # it is the enumeration leaking outside the repo.
        logger.warning("%d finding(s) name a file git does not track in %s; "
                       "filing them anyway, but they are almost certainly the "
                       "enumeration leaking outside the repo: %s", len(untracked),
                       root, ", ".join(f[:60] for f in untracked[:3]))
    ignored = backlog_is_ignored(root)
    if ignored:
        # Said, not swallowed, and said on every call: this is not a reason to
        # refuse the write (the operator may want the local file) but it IS a
        # reason no caller may report these as "registered".
        logger.warning("tasks/backlog is git-ignored in %s (%s) -- %d finding(s) "
                       "will be written where git cannot see them", root, ignored,
                       len(findings))
    today = today or date.today().isoformat()
    target = backlog_dir(root)
    target.mkdir(parents=True, exist_ok=True)
    return sum(_write_or_reopen_one(root, target, f, today, verification_command) for f in findings)


def _write_or_reopen_one(root: Path, target: Path, finding: str, today: str,
                          verification_command: str) -> int:
    """Handle exactly one finding. Returns 1 if the corpus now holds one more
    open task than before this call, 0 if it was already open or the write
    failed.

    Split out of `write_findings` so that function's own branching stays
    below `main()`'s existing complexity ceiling rather than adding to it --
    every branch this organ needs to reopen-not-duplicate a closed task
    (DEBT-upstream-watch-fork-own-upstream-j178-pr-b608864f, reproduced
    2026-09-14) lives here instead.
    """
    tid = task_id(finding)
    path = target / f"{tid}.md"
    if path.exists():
        return 0
    prior = done_dir(root) / f"{tid}.md"
    if prior.is_file():
        return 1 if _reopen_if_closed(path, prior, finding, today) else 0
    title = finding.strip().lstrip("[").split("]", 1)[-1].strip()[:80] or finding[:80]
    try:
        content = _TEMPLATE.format(
            frontmatter=ledger_schema.render_frontmatter(
                id=tid, title=title, status="open", severity="P1",
                satd_family="FINDING_BACKLOG_DEBT",
                close_check={"cmd": verification_command, "expect": "exit_zero"},
                created=today, risk_score=8, blast_radius="HIGH",
                lifespan="introduced", tag="BUG",
            ),
            id=tid,
            title=title,
            start=FINDINGS_START,
            finding=finding,
            end=FINDINGS_END,
            verification_command=verification_command,
        )
        atomic_io.write_text_durable(path, content)
    except OSError as exc:
        logger.warning("could not write %s: %s", path.name, exc)
        return 0
    return 1


def prune_finding(root: Path, finding: str) -> bool:
    """Remove one still-open task generated for an exact finding."""
    path = backlog_dir(root) / f"{task_id(finding)}.md"
    if not path.is_file():
        return False
    try:
        content = path.read_text(encoding="utf-8")
        status = re.search(r"^status:\s*(.+?)\s*$", content, re.M)
        if status and normalize_backlog_status(status.group(1)) == CANONICAL_DONE_STATUS:
            return False
        if FINDINGS_START not in content or FINDINGS_END not in content:
            return False
        block = content.split(FINDINGS_START, 1)[1].split(FINDINGS_END, 1)[0]
        rows = [line.strip()[2:].strip() for line in block.splitlines() if line.strip().startswith("- ")]
        if finding not in rows:
            return False
        path.unlink()
        return True
    except OSError as exc:
        logger.warning("could not prune %s: %s", path.name, exc)
        return False


# A prune wipes triage, so a partial input must not be able to trigger one. The
# caller's contract is that `live` is the COMPLETE current finding set; when it
# is a fragment instead, every task outside the fragment looks resolved.
# Measured 2026-08-16: running this organ against a repo holding 11 tasks with a
# one-finding file deleted all 11 in a single call. They were regenerable that
# time -- luck, not design. Above this ratio the prune refuses and says so.
_PRUNE_CLIFF = 0.5


def _is_task_prunable(path: Path, alive_norm: set[str]) -> bool:
    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return False
    status = re.search(r"^status:\s*(.+?)\s*$", content, re.M)
    if status is not None and normalize_backlog_status(status.group(1)) == CANONICAL_DONE_STATUS:
        return False
    if FINDINGS_START not in content:
        return False
    block = content.split(FINDINGS_START, 1)[1].split(FINDINGS_END, 1)[0]
    rows = [ln.strip()[2:] for ln in block.splitlines() if ln.strip().startswith("- ")]
    return bool(rows and not any(normalize_finding_key(r) in alive_norm for r in rows))


def prune_resolved(root: Path, live: list[str], force: bool = False) -> int:
    """Delete generated tasks whose finding no longer reproduces."""
    if would_dirty_own_repo(root):
        logger.warning("refusing to prune inside the kit's own repo under pytest")
        return 0
    target = backlog_dir(root)
    if not target.is_dir():
        return 0
    alive_norm = {normalize_finding_key(r) for r in live}
    doomed = [p for p in sorted(target.glob(f"{PREFIX}-*.md")) if _is_task_prunable(p, alive_norm)]

    existing = len(list(target.glob(f"{PREFIX}-*.md")))
    if not force and existing and len(doomed) / existing > _PRUNE_CLIFF:
        logger.warning(
            "refusing to prune %d of %d tasks from %d finding(s): that ratio means "
            "a partial findings file, not debt paid down. Pass the complete set, "
            "or force=True if the sweep really did resolve them.",
            len(doomed), existing, len(live))
        return 0

    pruned = 0
    for path in doomed:
        try:
            path.unlink()
        except OSError as exc:
            logger.warning("could not delete %s: %s", path.name, exc)
            continue
        pruned += 1
    return pruned


_NEGATIVE_CONTROL_MARKERS = (
    "control negativo", "negative control", "mutant", "mutante", "rc=1",
)


def _has_negative_control(content: str) -> bool:
    """Whether a closure records that its verification CAN fail.

    Running the declared `verification_command` and seeing rc=0 is not enough,
    and this is the measured reason: the RePic session audited 26 tasks closed
    that way and found 9 whose finding still reproduced. In most of them the
    code HAD changed -- the defect was that the cited test could not have caught
    the bug. `cargo check` cited for a runtime argument-forwarding bug;
    `import repic.gui` cited for a Tk thread-safety bug, proved inert by
    reverting the fix and watching the import still pass. A gate demanding only
    "it ran and exited 0" approves every one of those, with apparent good
    reason. Only the failing direction asks the question that matters: can this
    command convict THIS defect?

    So a closure must record BOTH outputs, the green and the red. Where the red
    is genuinely unobtainable the honest verdict is that the task does not
    close -- also RePic's, who returned CANNOT_VERIFY rather than a closure when
    no labelled corpus existed.

    DECLARED WEAKNESS, named by RePic the day this landed: it is a substring
    match, so writing the words over no control at all satisfies it. That is a
    large step up from counting rc=0 -- it asks for the failing direction rather
    than the passing one -- and it is not proof. The hardening they asked for is
    the right one and is not more keywords: the task should record the TWO
    literal outputs, green and red, as separate fields. A human can read whether
    the red one exists; an `in` cannot.

    Their second point belongs here too. This convicted 3 of 59 tasks across the
    fleet on the day it landed, and that is a low ceiling, not an acquittal: old
    tasks lack the words because nobody asked for them, so a small catch count
    says the bar is new, not that the closures were sound.
    """
    low = content.lower()
    return any(m in low for m in _NEGATIVE_CONTROL_MARKERS)


TASK_GLOBS = (f"{PREFIX}-*.md", "CONV-DEBT-*.md", "*-DEBT-*.md")

# ---------------------------------------------------------------------------
# The corpus the REPO declares (SPEC.md `debt:`) vs the one the KIT assumes
# ---------------------------------------------------------------------------
#
# `TASK_GLOBS` is a naming convention this kit invented. The fleet canon then
# made every repo declare, in typed front-matter, where its debt lives -- and
# this gate had that declaration in front of it and read its own convention
# instead. A repo that declared its corpus and still came out `never judged` is
# the instrument reading itself rather than the subject, which is the exact
# defect this organ exists to refuse, one storey up.
#
# Censused 2026-09-05 over `~/projects/*/SPEC.md` with `ledger_schema.parse` --
# the canon's own parser, so `debt:` is read by the code that demanded it:
#
#   declare `debt: tasks/`                17 repos
#   SPEC.md carrying no `debt:`            1 repo   (Atlas; declares `ledger:`)
#   no SPEC.md at all                      3 repos  (Qubit, RePic-references,
#                                                    Imagen_Corporativa_Aequitas)
#   declare anything OTHER than `tasks/`   0 repos
#   SPEC.md that fails to parse            0 repos
#
# The two zeros are the load-bearing rows and they cut both ways. Every
# declaration in the fleet names the tree this gate already reads, so honouring
# it RELOCATES nothing today: what the declaration is worth is not the path, it
# is the authority to stop filtering by filename inside it. And a repo whose
# declaration this gate cannot reach is a case that has never occurred -- which
# is precisely why it could sit here unhandled and unnoticed. Before this
# change a repo declaring `debt: fichas/`, with no `tasks/`, printed
# `open debt: 0 (of 0 entries...)` and exited 0: a filter over the void coming
# out clean, over a corpus its owner had declared in writing.
SPEC_RELPATH = Path("SPEC.md")

# Everything in the declared corpus, judged by the `status:` field each ficha
# carries. A declaration says "this is my debt"; filtering it by filename after
# that is the kit overruling the repo.
DECLARED_GLOBS = ("*.md",)

# The one tree `ledger.read_corpus` is able to open: `ledger._task_files`
# hardcodes `<root>/tasks/backlog`. A declaration pointing anywhere else cannot
# be honoured HERE, and saying so out loud is the whole difference between a
# could_not_run and a reassuring zero.
READABLE_DEBT_DIR = "tasks"


class CorpusScope(NamedTuple):
    """Which files this run judges, and whether the repo's declaration held.

    `could_not_run` is "" when the declaration was honoured AND when there is
    no declaration to honour. Those two are not the same thing and the `note`
    keeps them apart in the printout; only a declaration that exists and cannot
    be reached convicts.
    """

    globs: tuple[str, ...]
    declared: str
    note: str
    could_not_run: str


def corpus_scope(root: Path) -> CorpusScope:
    """Read the repo's `debt:` declaration and say what this run will judge.

    Four outcomes, and the third is the one this function was written for:

    1. No SPEC.md, or a SPEC.md declaring no `debt:` -> the `DEBT-*` prefix,
       byte-identical to the behaviour before this existed. Atlas, Qubit,
       Imagen_Corporativa_Aequitas and RePic-references are here, measured.
    2. A declaration this gate can reach -> the declared corpus, every ficha in
       it judged by its `status:` field, no prefix filter. Whether that set
       reaches the EXIT CODE is `COULD_NOT_RUN_BLOCKS`'s business, not this
       function's: honouring the declaration by default moves 83 fichas into the
       open count and flips 5 repos that pass today (measured below), and that
       flip is a fleet act reserved to the owner.
    3. A declaration that cannot be reached -- the directory does not exist, or
       it is not the tree `ledger.read_corpus` opens -> COULD_NOT_RUN. Never a
       zero. This is the only branch here that convicts on its own, and it can
       afford to: measured 2026-09-05, 0 of 21 repos are in it, so arming it
       costs the fleet nothing and closes the hole while it is still empty.
    4. A SPEC.md that will not parse -> COULD_NOT_RUN too. A `debt:` that was
       never read cannot be reported as absent; absent and unreadable are the
       two verdicts this kit spends its life keeping apart.
    """
    root = Path(root)
    spec = root / SPEC_RELPATH
    prefijo = f"corpus by {PREFIX}-* prefix"
    if not spec.is_file():
        return CorpusScope(TASK_GLOBS, "", f"no {SPEC_RELPATH.as_posix()}; {prefijo}", "")
    fm, motivo = ledger_schema.parse(spec)
    if fm is None:
        return CorpusScope(
            TASK_GLOBS, "", f"{SPEC_RELPATH.as_posix()} did not parse; {prefijo}",
            f"{SPEC_RELPATH.as_posix()} could not be parsed ({motivo}), so its "
            f"`debt:` declaration -- if it carries one -- was never read; the "
            f"{PREFIX}-* fallback below is a guess, not a reading of the subject")
    declared = str(fm.get("debt") or "").strip()
    if not declared:
        return CorpusScope(
            TASK_GLOBS, "", f"{SPEC_RELPATH.as_posix()} declares no `debt:`; {prefijo}", "")
    if not (root / declared).is_dir():
        return CorpusScope(
            TASK_GLOBS, declared, f"declared `debt: {declared}`, which does not exist; {prefijo}",
            f"{SPEC_RELPATH.as_posix()} declares `debt: {declared}` and "
            f"{declared} is not a directory in this repo, so the declared "
            f"corpus was never opened; `open debt: 0` here would be a filter "
            f"over the void, not an audit")
    if (root / declared).resolve() != (root / READABLE_DEBT_DIR).resolve():
        return CorpusScope(
            TASK_GLOBS, declared,
            f"declared `debt: {declared}`, which this gate cannot read; {prefijo}",
            f"{SPEC_RELPATH.as_posix()} declares `debt: {declared}`, and this "
            f"gate reads only {READABLE_DEBT_DIR}/backlog "
            f"(`ledger._task_files` hardcodes it); it judged the wrong tree or "
            f"no tree at all, and either way it did not judge the declared one")
    if not backlog_dir(root).is_dir():
        return CorpusScope(
            TASK_GLOBS, declared,
            f"declared `debt: {declared}`, whose backlog shelf is missing; {prefijo}",
            f"{SPEC_RELPATH.as_posix()} declares `debt: {declared}` but "
            f"{backlog_dir(root).relative_to(root).as_posix()} does not exist, "
            f"so the declared corpus has no shelf this gate can read")
    if not COULD_NOT_RUN_BLOCKS:
        return CorpusScope(
            TASK_GLOBS, declared,
            f"declared `debt: {declared}` and READ; the rollout switch is off, so "
            f"the judged corpus is still {PREFIX}-* and the rest is named in the "
            f"could_not_run ledger below", "")
    return CorpusScope(
        DECLARED_GLOBS, declared,
        f"declared `debt: {declared}`; every task file in it is judged by its "
        f"`status:` field, with no prefix filter", "")


def unevaluated_task_files(root: Path) -> list[str]:
    """Task files in the backlog that `open_tasks` never looks at.

    `PREFIX` is "DEBT", so the globs below reach `DEBT-*`, `CONV-DEBT-*` and
    `*-DEBT-*` and nothing else. Measured by the RePic session 2026-09-01: a
    `TASK-*.md` carrying `status: open`, severity P2, blast_radius HIGH was
    reported as `open debt: 0` -- not miscounted, never opened. Renaming that
    same file to `DEBT-*`, one byte of content unchanged, flips the verdict to
    BLOCKED.

    This does not widen the gate; widening it would reopen files across 12
    satellites with nobody able to size it first (in office2office alone, 343
    WARN and 103 CONV declare `status: open`). It makes the gate stop presenting
    a partial count as a total, so the gap is a number somebody can decide about
    instead of a silence nobody investigates.
    """
    target = backlog_dir(root)
    if not target.is_dir():
        return []
    # The SAME globs `open_tasks` judges with, taken from the same place. They
    # were two hardcoded copies until 2026-09-05, and a copy that drifts turns
    # this list into a denominator for a numerator it no longer matches -- a
    # file would drop out of BOTH the open count and the unevaluated one, which
    # is a silent zero built out of two honest halves.
    evaluated = {p.name for pattern in corpus_scope(root).globs for p in target.glob(pattern)}
    return sorted(p.name for p in target.glob("*.md") if p.name not in evaluated)


def unevaluated_open_task_files(root: Path) -> list[str]:
    """The unevaluated files that ALSO declare an open status -- the could_not_run set.

    `unevaluated_task_files` answers "which files did the globs miss"; this
    answers "which of those misses hide live debt", and only the second is a
    candidate for the exit code. The difference is not cosmetic: measured across
    the fleet 2026-09-05, 252 files sit outside the globs and 243 of them are
    open, so 9 are already `done` and blocking on them would be inventing debt
    that was paid.

    The status is read with `normalize_backlog_status`, the same function
    `open_tasks` judges `DEBT-*` files with, so a file cannot change verdict by
    being renamed -- which is the exact evasion this organ's own BLOCKED message
    claims to refuse.
    """
    out = []
    for name in unevaluated_task_files(root):
        try:
            content = (backlog_dir(root) / name).read_text(encoding="utf-8")
        except OSError as exc:
            # Unreadable is not clean. It goes in the could_not_run set, which
            # is where a file nobody could open belongs.
            logger.warning("could not read %s: %s", name, exc)
            out.append(name)
            continue
        status = re.search(r"^status:\s*(.+?)\s*$", content, re.M)
        if normalize_backlog_status(status.group(1) if status else None) == CANONICAL_OPEN_STATUS:
            out.append(name)
    return out


# Whether a could_not_run file is allowed to set the exit code.
#
# The accounting above is unconditional and always prints. THIS switch governs
# only the rc. It was False until 2026-09-05 because arming it is a fleet act,
# not a module edit -- pre-arming measurement, kept as a dated record rather
# than updated (a number in a comment ages without saying so; this one is a
# DATED OBSERVATION, not a standing claim), by calling `open_tasks`/
# `unevaluated_task_files`/`load_baseline` directly over all 20 repos under
# ~/projects that carry `tasks/` (no `main()`, so no verdict stamp was written
# into anybody's tree):
#
#   repos that passed the gate THEN and would have blocked once armed: 8 of 20
#     Atlas 154 · Twiner 46 · aequitas_os 14 · declutter 11 · red_python 2 ·
#     Qubit 1 · Imagen_Corporativa_Aequitas 1 · poe_normare 1
#   repos that already blocked and would not change verdict: 12 of 20
#   open files outside the globs, fleet-wide: 243 of 252
#
# Atlas and Twiner were the two most active satellites, and `.simplecode/run.py`
# hot-pulls from the mother's WORKING tree (its own comment: "The mother's
# WORKING tree is what runs in every satellite"), so flipping this default
# would land in all 20 satellites about 60 seconds after the file is saved,
# with no commit -- a fleet stop, not a proposal, which is why the flip waited
# on baselines actually being in place first (see ARMADO below) rather than
# arming and letting each repo scramble after the fact.
#
# Since 2026-09-05 this ALSO governs `corpus_scope`: while it is False the
# judged corpus stays `DEBT-*` even in the 17 repos that declare one, and the
# declared-but-unjudged fichas are named in the could_not_run ledger. Remeasured
# that day on replicas of all 20 repos carrying `tasks/` (no `main()` against a
# real tree, so no `last_backlog_verdict.json` was written into anybody's repo),
# honouring the declaration moves +83 fichas into the open count and flips 5
# repos that pass today:
#
#   Twiner +46 · aequitas_os +10 · declutter +10 · red_python +2 · poe_normare +1
#   (already blocking, count grows: blog_ciudadano_x +3 · maletin_homeopatia +3 ·
#    descargaSAT +2 · office2office +2 · sistemas_estocasticos_ruleta +2 ·
#    migracion_atom +1 · poe_systems +1)
#   unchanged: Atlas, Qubit, Imagen_Corporativa_Aequitas (they declare no
#   `debt:`, so they fall to the prefix -- the fallback, measured on real repos)
#
# ONE switch and not two, on purpose. A second disarmed flag would be a second
# thing to forget, and both flags would be answering the same question: whether
# the fleet is ready to stop at the debt it has already written down.
# ARMADO el 2026-09-05 por voto de Luis, con las 8 declaraciones en su sitio y verificadas
# ANTES de tocar esta linea -- ese era el contenido del voto, no un detalle de ejecucion:
#
#   Atlas        expires 2026-12-04. Su cifra MEDIDA AL ARMAR eran 155 = 155 (commit
#                170b1b35) y a los pocos minutos era 157 = 157 (commit de7fce76): su
#                swarm siguio creando fichas. Se deja el rastro de las dos y NO se
#                actualiza este comentario cada vez, porque una cifra en un comentario
#                envejece sin avisar -- es una OBSERVACION FECHADA, no una afirmacion
#                vigente. Lo que gobierna es el fichero del repo, leido en cada corrida.
#                Ellos lo cazaron escribiendo tests/test_backlog_baseline.py, que fija
#                que las entradas coincidan con las fichas vivas COMO CONJUNTO y no por
#                tamano; un comando puntual solo prueba el instante en que se corre.
#   declutter    10 vivas nombradas, expires 2026-09-19; 96 ya cerradas RETIRADAS de su
#                declaracion vieja y 3 nacidas despues anadidas -- una exencion para deuda
#                que ya no existe es ruido que oculta la que si
#   Twiner       SIN declarar sus 46, por voto propio de Luis del mismo dia: el gate debe
#                decir `open debt: 46` y rc=1, y cada push lo justifica o cierra de verdad
#   aequitas_os, red_python, poe_normare, Qubit, Imagen_Corporativa_Aequitas:
#                generadas de la lista viva y verificadas en 30/30 brazos
#
# Los cuatro brazos por repo, sobre replicas y nunca contra el arbol real: sin declaracion
# bloquea; con ella pasa; con `expires` en el pasado vuelve a bloquear ENTERO; y una ficha
# nueva no nombrada bloquea aunque las demas esten cubiertas. El tercero es el que prueba que
# la caducidad no es decorado.
#
# TRES REPOS donde armar es INERTE HOY y latente manana, y va dicho porque nadie lo recordara:
# `Qubit` e `Imagen_Corporativa_Aequitas` NO son repos git, y `poe_normare` no tiene upstream.
# Ninguno puede publicar, asi que este interruptor no les cambia nada hasta el dia que alguien
# les ponga remoto. Ese dia el gate llevara armado y nadie lo sabra. Necesitan upstream o una
# nota de por que quedan fuera.
#
# Y lo que este interruptor NO hace, medido: el corpus se queda en `tasks/backlog/`. Ensancharlo
# a `tasks/done/` meteria +2.084 fichas, porque `ledger.Entry.is_open` cuenta `done_unverified`
# como ABIERTA (1.966 en la flota) mientras `backlog_verifier` la trata como cohorte cerrada.
# Dos organos del mismo kit clasificando lo mismo distinto: ficha aparte, no se arregla aqui.
COULD_NOT_RUN_BLOCKS = True


def open_tasks(root: Path) -> list[str]:
    """Generated tasks that are not verified as closed/done -- outstanding debt.

    Strict zero-debt invariant: There are only two valid realities:
    1. Verified resolved ('closed', 'done', 'cerrado', 'done_unverified' -- owes evidence
       that its check can come out NEGATIVE, same as any other closed entry; see the block
       below).
    2. Any evasion or non-closed label ('open', 'backlog', 'triaged', 'deferred', etc.) -> BLOCKS.

    `done_unverified` joined `_DONE_SYNONYMS` 2026-09-22 (DEBT-done-unverified-two-organs-disagree,
    Luis's decision) so it no longer counts as unconditionally OPEN here -- but Luis's
    follow-up correction the same day was explicit: it still owes real evidence, the same as
    any other closed entry. It does NOT skip the evidence-owing branch below. A
    `done_unverified` ficha with no `evidence.fail`/negative control still reaches `out`,
    just under the "closed with no evidence the test can FAIL" message instead of a bare
    open label -- the escape valve for a genuinely-honest-but-unverified entry is
    `.simplecode/backlog_baseline.json` (which reads the label directly, not `is_open`), not
    a free pass built into this function.
    """
    corpus = ledger.read_corpus(root, corpus_scope(root).globs)
    out = []
    for entry in sorted(corpus.values(), key=lambda e: (e.source, str(e.path))):
        # A `tasks/` entry keeps its bare filename: that string is what every
        # existing consumer and message prints. A `ledger/` entry is prefixed,
        # so a reader can tell which tree a finding came from without a legend.
        label = (
            entry.path.name if entry.source == ledger.SOURCE_TASKS
            else f"{ledger.SOURCE_LEDGER}/{entry.path.name}"
        )
        if entry.is_open:
            out.append(label)
            continue
        # Closed. It owes evidence that its check can come out NEGATIVE --
        # a verification that cannot fail is not a verification.
        #
        # Judged by what the entry CARRIES, not by which tree supplied it. This
        # branched on the source until 2026-09-02, when the fleet canon retired
        # `ledger/` entirely -- "duplicar 2,116 fichas sin anadir nada" -- and
        # merged its typed fields, `evidence` among them, into the frontmatter
        # of the tasks that already existed. After that a task could hold a
        # perfectly good `evidence.fail` and still be judged by a prose marker,
        # which reported ten entries closed with real paired artifacts as
        # "closed with no evidence the test can FAIL".
        #
        # An `evidence.fail` path is the stronger signal and is checked first;
        # the prose marker remains for entries written before the field existed.
        if ledger.evidence_fail_path(entry.content):
            continue
        if not _has_negative_control(entry.content):
            out.append(f"{label}: closed with no evidence the test can FAIL")
    return out


def accepted_open_tasks(root: Path) -> tuple[dict[str, dict], list[tuple[str, list[str]]]]:
    """(validas, invalidas) entre las fichas de `open_tasks` con este ciclo.

    `validas`: label -> el dict `accepted` (dueno, fecha, disparador) -- la
    unica clase que `main()` retira de las bloqueantes. `invalidas`: (label,
    motivos) para una ficha que SI declaro `accepted` pero incompleto -- estas
    NO eximen y siguen bloqueando igual que si no lo hubieran declarado, y se
    reportan por separado para que el autor se entere de por que.

    DEBT-SURVEY-SHIP-FREEZE-INCENTIVE-INVERTED: la cuarta salida que faltaba
    entre cerrar la ficha, declarar `backlog_baseline.json`, o apagar los hooks.
    Deuda ABIERTA, medida, con dueno y disparador, que NO bloquea el envio y
    SI se imprime.

    Falla hacia BLOQUEAR: una ficha cuyo frontmatter `ledger_schema.parse` no
    puede leer no ha declarado nada, y menos una aceptacion -- el riesgo de
    este campo es asimetrico (eximir de mas es invisible; bloquear de mas se
    ve en el acto), asi que una lectura rota nunca exime.
    """
    corpus = ledger.read_corpus(root, corpus_scope(root).globs)
    validas: dict[str, dict] = {}
    invalidas: list[tuple[str, list[str]]] = []
    for entry in sorted(corpus.values(), key=lambda e: (e.source, str(e.path))):
        if not entry.is_open:
            continue
        label = (
            entry.path.name if entry.source == ledger.SOURCE_TASKS
            else f"{ledger.SOURCE_LEDGER}/{entry.path.name}"
        )
        fm, _motivo = ledger_schema.parse(entry.path)
        if fm is None:
            continue
        decl, motivos = ledger_schema.accepted_declaration(fm)
        if decl is not None:
            validas[label] = decl
        elif motivos:
            invalidas.append((label, motivos))
    return validas, invalidas


# ---------------------------------------------------------------------------
# Declared baseline (owner's ballot, 2026-09-02)
# ---------------------------------------------------------------------------
#
# A baseline is a legalized evasion, so it obeys the suspension contract: it
# carries an EXPIRY and an OWNER, and it names the specific entries it covers.
# Measured in this fleet: a suspension with no expiry becomes permanent in
# silence (Cerberus's 59 hooks, "temporarily" disabled 2026-08-01, never
# restored). This one cannot, because past its expiry it simply stops applying
# and the gate blocks in full.
#
# It is a LIST, not a number. A baseline that only counts is satisfied by
# closing one entry and opening another, which is how a ceiling becomes a
# ratchet nobody notices. Anything open that the list does not name blocks.

BASELINE_RELPATH = Path(".simplecode") / "backlog_baseline.json"


def load_baseline(root: Path) -> tuple[dict, str]:
    """The declared baseline and a note, or ({}, why-not).

    Absent, malformed, or expired all mean NO baseline: the gate blocks on
    everything. Failing toward blocking is the only direction that keeps an
    expiry honest.
    """
    path = root / BASELINE_RELPATH
    if not path.is_file():
        return {}, f"no {BASELINE_RELPATH.as_posix()} declared"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        expires = date.fromisoformat(str(data["expires"]))
        owner = str(data["owner"]).strip()
        entries = [str(x) for x in data["entries"]]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return {}, (f"COULD_NOT_RUN: {BASELINE_RELPATH.as_posix()} is unreadable or "
                    f"incomplete ({exc}); it needs `expires`, `owner` and `entries`. "
                    f"No baseline applies.")
    if not owner or not entries:
        return {}, f"{BASELINE_RELPATH.as_posix()} declares no owner or no entries; no baseline applies"
    today = date.today()
    if today > expires:
        return {}, (f"BASELINE EXPIRED on {expires.isoformat()} (owner: {owner}); "
                    f"it no longer applies and every entry below blocks again")
    left = (expires - today).days
    return (
        {"expires": expires, "owner": owner, "entries": set(entries), "reason": str(data.get("reason", ""))},
        f"baseline of {len(entries)} entry/entries, owner {owner}, expires "
        f"{expires.isoformat()} ({left} day(s) left)",
    )


def outside_baseline(outstanding: list[str], baseline: dict) -> list[str]:
    """Open findings the baseline does not name -- the ones that still block."""
    if not baseline:
        return list(outstanding)
    named = baseline["entries"]
    return [row for row in outstanding if row.split(":")[0].strip() not in named]


def report_could_not_run(root: Path, baseline: dict, gate: bool) -> tuple[bool, list[str]]:
    """Print the could_not_run ledger and say whether it convicts.

    A report with `could_not_run > 0` is not a clean report however many rows
    pass, so this prints on every run, zeros included, and it prints what it
    WOULD do as well as what it does. Until 2026-09-05 the unevaluated files
    were printed and then dropped: `bloqueantes` came only from `outstanding`,
    so a repo whose whole backlog sat outside the globs reported `open debt: 0`
    with rc=0 -- an acquittal of a subject nobody opened. Measured in own_chats
    2026-09-04: 2 open files, 2 of 2 unevaluated, rc=0.

    They go through the SAME baseline door debt does. A could_not_run a repo has
    declared -- owner, expiry, named entries -- is a legalized evasion that
    expires; one nobody declared is not.
    """
    cnr = unevaluated_open_task_files(root)
    cnr_bloq = outside_baseline(cnr, baseline)
    armado = "blocking" if COULD_NOT_RUN_BLOCKS else (
        "NOT blocking (COULD_NOT_RUN_BLOCKS is False; the rc below ignores them)")
    print(f"[backlog] could_not_run: {len(cnr)} open file(s) the globs never opened; "
          f"outside the baseline: {len(cnr_bloq)}; {armado}")
    # The REASON, not a slogan. `prefix outside DEBT-*` was printed even where
    # the repo had declared this very directory as its debt corpus, which told
    # the reader the file was exotic when the truth was that the gate declined
    # to honour a declaration it had already parsed.
    declarado = corpus_scope(root).declared
    motivo = (f"open, inside the corpus this repo declares (`debt: {declarado}`), "
              f"judged by neither prefix nor status" if declarado
              else f"open, prefix outside {PREFIX}-*, never judged")
    for name in cnr_bloq[:20]:
        print(f"  ?? COULD_NOT_RUN: {name} -- {motivo}")
    if len(cnr_bloq) > 20:
        print(f"  ... and {len(cnr_bloq) - 20} more COULD_NOT_RUN")
    return bool(gate and COULD_NOT_RUN_BLOCKS and cnr_bloq), cnr_bloq


def explain_verdict(
    verdict: str,
    has_baseline: bool,
    bloqueantes: list[str] | None = None,
    cnr_bloq: list[str] | None = None,
    scope_could_not_run: str = "",
) -> int:
    """Say what the verdict means and what discharges it; return the exit code.

    The two convicting verdicts are kept apart on purpose. `BLOCKED` is open
    debt: the subject was read and judged. `COULD_NOT_RUN` is an open file the
    globs never opened, which is an INSTRUMENT failure, and a reader who cannot
    tell the two apart cannot tell a dirty repo from a blind gate -- the exact
    confusion that let `open debt: 0` with rc=0 stand over a backlog that was
    100% unevaluated. Both exit 1; only one of them means the debt is known.
    """
    bloqueantes = bloqueantes or []
    cnr_bloq = cnr_bloq or []
    if verdict == "BLOCKED":
        print("BLOCKED [backlog] - zero-debt policy: debt cannot be bypassed with renaming.")
        print("Every finding must either be fixed in code or verified with status: closed.")
        if has_baseline:
            print("A declared baseline covers the rest; these are NOT in it, so they are "
                  "new debt and block on their own.")
        # gate_runner's _SUBJECT_VERDICT regex needs the tag BEFORE the verdict
        # word ("[tag] FAIL ...") -- the human-readable line above puts the
        # word first ("BLOCKED [backlog] ...") and never matched it, so a real
        # conviction here was invisible to could_not_run classification.
        first = bloqueantes[0] if bloqueantes else "?"
        print(
            f"[ship-freeze] FAIL: {len(bloqueantes)} finding(s) of open debt not covered "
            f"by the baseline; first {first}"
        )
        return 1
    if verdict == "COULD_NOT_RUN":
        print("COULD_NOT_RUN [backlog] - the files above are open and were never judged; "
              "a partial count is not a clean report.")
        print("Rename them into the DEBT-* corpus, close them, or declare them in "
              f"{BASELINE_RELPATH.as_posix()} with an owner and an expiry.")
        print(f"If the line above is about `debt:`, fix the declaration in "
              f"{SPEC_RELPATH.as_posix()} instead: a corpus this gate cannot open "
              f"is not a corpus with nothing in it.")
        if cnr_bloq:
            print(
                f"[ship-freeze] COULD_NOT_RUN: {len(cnr_bloq)} open file(s) the globs never "
                f"opened, outside the baseline; first {cnr_bloq[0]}",
                file=sys.stderr,
            )
        else:
            print(
                f"[ship-freeze] COULD_NOT_RUN: the declared corpus is broken: {scope_could_not_run}",
                file=sys.stderr,
            )
        return 1
    return 0


def _print_accepted_summary(root: Path) -> dict[str, dict]:
    """Corre `accepted_open_tasks` y reporta el resultado, devolviendo solo
    las validas (lo unico que `main` necesita despues, para retirarlas del
    calculo de la linea base). Movido fuera de `main` para no volver a subir
    su conteo de sentencias sobre el que ya vigila `ruff` (PLR0915)."""
    aceptadas, invalidas = accepted_open_tasks(root)
    print(f"[backlog] accepted (deuda ABIERTA, no bloquea el envio, SI cuenta): {len(aceptadas)}")
    for label, decl in sorted(aceptadas.items()):
        print(f"  ACCEPTED {label} -- {decl.get('by')}, {decl.get('date')}, "
              f"se reabre si: {decl.get('trigger')}")
    if invalidas:
        print(f"[backlog] accepted DECLARADA E INVALIDA: {len(invalidas)}")
        for label, motivos in invalidas:
            for motivo in motivos:
                print(f"  !! {label}: {motivo}")
    return aceptadas


# DEBT-LO-DIFERIDO-NO-ENTRA-EN-NINGUN-TOTAL (reportado por blackbox, 2026-09-28):
# `open debt: 0` se imprimia sobre un repo con 22 endurecimientos diferidos por
# escrito -- exenciones sunset-reviewed, una suspension, un organo inaplicable,
# un presupuesto firmado -- porque cada organo decia su propio cero y ninguno
# sumaba. Es deuda ACEPTADA con la misma forma que la fila `accepted`, asi que
# se cuenta igual: no bloquea el envio, SI cuenta, y se imprime aunque sea cero.
# Cada clase la lee el organo que ya la conoce; aqui solo se suma.
DEFERRED_WARN_DAYS = 14


class Diferido(NamedTuple):
    """Una clase de deuda diferida: sus items `(etiqueta, caducidad)`, el motivo
    si su fuente no se pudo leer, y la caducidad mas proxima cuando no es una
    fecha (sunset vence por version)."""
    items: list[tuple[str, date | None]]
    could_not_run: str | None = None
    proxima: str = ""


def _diferidos_sunset(root: Path) -> Diferido:
    """Exenciones ETIQUETADAS `sunset-reviewed`: aceptadas hasta el siguiente
    minor. Las SIN etiqueta son violaciones de `sunset_audit`, no diferidos."""
    try:
        records = sunset_audit.scan_exemptions(root)
    except (OSError, UnicodeError) as exc:
        return Diferido([], f"sunset_audit could not scan {root} ({exc})")
    tagged = [r for r in records if r.version_reviewed]
    versiones = sorted({r.version_reviewed or "" for r in tagged},
                       key=lambda v: tuple(int(p) for p in v.split(".")))
    items: list[tuple[str, date | None]] = [
        (f"{r.path.relative_to(root)}:{r.line_number}", None) for r in tagged]
    proxima = (f"version {versiones[0]} (expires with the next minor, not by date)"
               if versiones else "")
    return Diferido(items, None, proxima)


def _diferidos_suspendidos(root: Path) -> Diferido:
    """Suspensiones abiertas de ESTE repo en el manifiesto de `hook_suspension`."""
    try:
        manifest = hook_suspension._load_manifest(hook_suspension.default_manifest_path())
    except hook_suspension.ManifestError as exc:
        return Diferido([], str(exc))
    items: list[tuple[str, date | None]] = []
    for entry in manifest["entries"]:
        if entry["restored"] or Path(entry["repo"]).resolve() != root:
            continue
        fecha = hook_suspension._DATE_RE.search(str(entry["expiry"]))
        items.append((f"{entry['repo']} {entry['hook']}",
                      date.fromisoformat(fecha.group()) if fecha else None))
    return Diferido(items)


def _diferidos_inaplicables(root: Path) -> Diferido:
    """Organos declarados inaplicables, validados por `gate_effectiveness`. Una
    declaracion caducada o rechazada ya no difiere nada: alli vuelve a bloquear."""
    entries, nota = gate_effectiveness.load_inapplicable(root)
    if nota.startswith("COULD_NOT_RUN"):
        return Diferido([], nota)
    if not entries:
        return Diferido([])
    # Solo `expires`, ya validado por `load_inapplicable` en esta misma corrida:
    # el organo no expone la fecha y su nota es prosa.
    data = json.loads((root / gate_effectiveness.INAPPLICABLE_RELPATH).read_text(encoding="utf-8"))
    expira = date.fromisoformat(str(data["expires"]))
    return Diferido([(organo, expira) for organo in sorted(entries)])


def _diferidos_presupuestos(root: Path) -> Diferido:
    """Presupuestos firmados `tasks/presupuesto_*.json`, validados por el lector
    del kit (`presupuestos`): uno incompleto o malformado es COULD_NOT_RUN."""
    try:
        leidos = presupuestos.leer_todos(root)
    except presupuestos.PresupuestoInvalido as exc:
        return Diferido([], str(exc))
    return Diferido([(p.fichero, p.expires) for p in leidos])


def _proxima(clase: Diferido, hoy: date) -> str:
    if clase.proxima or not clase.items:
        return clase.proxima or "none"
    fechas = [f for _, f in clase.items if f is not None]
    if not fechas:
        return "none readable"
    return f"{min(fechas).isoformat()} ({(min(fechas) - hoy).days} day(s))"


def _aviso(nombre: str, etiqueta: str, fecha: date | None, hoy: date) -> str | None:
    """La linea que NOMBRA un item que caduca pronto, ya caduco, o no tiene fecha."""
    if fecha is None:
        return None if nombre == "sunset" else f"  !! NO READABLE EXPIRY: {nombre} {etiqueta}"
    dias = (fecha - hoy).days
    if dias > DEFERRED_WARN_DAYS:
        return None
    cuando = f"EXPIRES IN {dias} DAY(S)" if dias >= 0 else f"EXPIRED {-dias} DAY(S) AGO"
    return f"  !! {cuando}: {nombre} {etiqueta} ({fecha.isoformat()})"


def _print_deferred_summary(root: Path) -> tuple[int, int]:
    """La fila `deferred`, junto a `accepted`. Devuelve `(total, clases_cnr)`.
    Impresa siempre, ceros incluidos; una clase ilegible es COULD_NOT_RUN y no 0."""
    hoy = date.today()
    clases = {
        "sunset": _diferidos_sunset(root),
        "suspended": _diferidos_suspendidos(root),
        "organ_inapplicable": _diferidos_inaplicables(root),
        "signed_budgets": _diferidos_presupuestos(root),
    }
    total = sum(len(c.items) for c in clases.values())
    partes = ", ".join(f"{n}: {'COULD_NOT_RUN' if c.could_not_run else len(c.items)}"
                       for n, c in clases.items())
    print(f"[backlog] deferred: {total} ({partes}) -- deuda ABIERTA diferida por "
          f"escrito, no bloquea el envio, SI cuenta")
    for nombre, clase in clases.items():
        if clase.could_not_run:
            print(f"  !! COULD_NOT_RUN {nombre}: {clase.could_not_run}")
            continue
        print(f"  {nombre}: {len(clase.items)} -- nearest expiry: {_proxima(clase, hoy)}")
        avisos = (_aviso(nombre, etiqueta, fecha, hoy) for etiqueta, fecha in clase.items)
        for aviso in filter(None, avisos):
            print(aviso)
    return total, sum(1 for c in clases.values() if c.could_not_run)


def _print_not_zero_debt(outstanding: int, deferred: int, cnr_clases: int) -> None:
    """Con `open debt: 0`, el informe dice en voz alta que NO es cero deuda si
    hay diferidos o si no pudo contarlos todos."""
    if outstanding or not (deferred or cnr_clases):
        return
    print(f"[backlog] NOT zero-debt: open debt 0 but deferred {deferred}"
          + (f", and {cnr_clases} class(es) COULD_NOT_RUN so that total is incomplete"
             if cnr_clases else ""))


def _write_findings_path(root: Path, findings_file: Path) -> None:
    """The `--findings-file` half: turn incoming findings into owned tasks.

    Split out of `main` because it is the only half that WRITES, and mixing a
    writer into the verdict path is how a gate ends up changing the corpus it is
    about to judge. Nothing here decides an exit code.
    """
    raw = sys.stdin.read() if str(findings_file) == "-" else \
        findings_file.read_text(encoding="utf-8")
    findings = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    before = len(open_tasks(root))
    created = write_findings(root, findings)
    pruned = prune_resolved(root, findings)
    after = len(open_tasks(root))
    # Before/after around every write, from `_warn_tasks.py`'s evidence log:
    # `created` and `pruned` are what the code INTENDED; before/after is what
    # the directory actually holds, and a guard that silently refused shows
    # up as the gap between them.
    print(f"[backlog] findings: {len(findings)} · new tasks: {created} · "
          f"pruned: {pruned} · open {before} -> {after}")


def _print_corpus(root: Path, outstanding: list[str]) -> CorpusScope:
    """Print the subject of this run -- what was considered, what was not, and
    what is open -- and return the scope so the caller can read its
    `could_not_run`.

    Everything here prints on every run, zeros included: a gate that does not
    say what it took as its subject cannot be audited on whether it read one.
    """
    # Printed at zero too: a debt that stops being counted stops being paid.
    no_evaluados = unevaluated_task_files(root)
    # Print the scope, always, including the zeros: a bare "open debt: 0" reads
    # as a total and it is not one. The denominator comes from the SAME corpus
    # the numerator does -- both trees, deduplicated -- because the previous
    # version counted `tasks/backlog/` files against a numerator that had since
    # learned to read `ledger/` too, and printed "111 of 5".
    scope = corpus_scope(root)
    print(f"[backlog] corpus: {scope.note}")
    if scope.could_not_run:
        print(f"  !! COULD_NOT_RUN: {scope.could_not_run}")
    counts = ledger.census(ledger.read_corpus(root, scope.globs))
    print(f"[backlog] open debt: {len(outstanding)} "
          f"(of {counts['total']} entries: {counts['from_ledger']} from ledger/, "
          f"{counts['from_tasks']} from tasks/; "
          f"{len(no_evaluados)} file(s) with another prefix NOT evaluated)")
    for nombre in no_evaluados[:10]:
        print(f"  [NOT EVALUATED] {nombre} -- prefix outside {PREFIX}-*")
    if len(no_evaluados) > 10:
        print(f"  ... and {len(no_evaluados) - 10} more NOT EVALUATED")
    for name in outstanding[:20]:
        print(f"  - {name}")
    if len(outstanding) > 20:
        print(f"  ... and {len(outstanding) - 20} more")
    return scope


def _print_baseline(
    root: Path, outstanding: list[str], aceptadas: dict[str, dict]
) -> tuple[dict, list[str]]:
    """Print the baseline's real coverage and return `(baseline, bloqueantes)`.

    `bloqueantes` -- open, unaccepted debt the baseline does not name -- is the
    ONLY list that reaches `BLOCKED`, so it is computed here and nowhere else.
    """
    # Solo las fichas SIN aceptacion valida entran al calculo de la linea
    # base: una aceptada ya salio por su propia puerta y no puede volver a
    # contar como "cubierta por la base" -- una base MUERTA que no cubre nada
    # no puede leerse como protegida porque otra cosa, distinta, exime.
    no_aceptadas = [o for o in outstanding if o not in aceptadas]
    baseline, baseline_note = load_baseline(root)
    bloqueantes = outside_baseline(no_aceptadas, baseline)
    # The baseline always prints, whether or not one exists, and says how many
    # of its named entries are still open. A legalized evasion that is not read
    # aloud on every run is the kind that becomes permanent in silence.
    cubiertas = len(no_aceptadas) - len(bloqueantes)
    print(f"[backlog] {baseline_note}; covered by it: {cubiertas}; still blocking: {len(bloqueantes)}")
    # Una linea base que NOMBRA entradas y no cubre ninguna es un instrumento
    # muerto que se lee como proteccion. Reportado por la sesion declutter
    # (2026-09-05): tras renombrar `ledger/<ficha>.md` a `<ficha>.md`, su base
    # de **103 entradas coincidia con 0** y estuvo **tres dias sin proteger
    # nada** -- parseando, sin caducar, con dueno y fecha, asi que quien la veia
    # asumia cobertura. El propio gate ya imprimia el numero; lo que faltaba era
    # que DOLIERA. Sus palabras: *"no es que faltara la medicion, es que el
    # numero no dolia"*.
    #
    # Se dice siempre, incluso con `outstanding` vacio: una base que no cubre
    # nada porque no hay nada abierto es informacion distinta de una rota, y
    # callar la primera ensena a ignorar la linea.
    declaradas = baseline.get("entries", set()) if baseline else set()
    if declaradas and cubiertas == 0:
        print(
            f"[backlog] !! LINEA BASE MUERTA: declara {len(declaradas)} entrada(s) "
            f"y no cubre NINGUNA de las {len(outstanding)} abiertas. Una declaracion con "
            f"dueno y caducidad que no protege nada se lee como proteccion y no lo es -- "
            f"revisa si los nombres siguen coincidiendo (un renombrado de ruta la rompe "
            f"entera sin cambiar su cuenta)."
        )
    if baseline and baseline.get("reason"):
        print(f"[backlog] baseline reason: {baseline['reason']}")
    for name in bloqueantes[:20]:
        print(f"  !! NOT COVERED BY THE BASELINE: {name}")
    return baseline, bloqueantes


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Persist guard findings as owned tasks.")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--findings-file", type=Path,
                    help="File with one finding per line; '-' reads stdin.")
    ap.add_argument("--gate", action="store_true",
                    help="Exit 1 if any debt task is not verified and closed (zero-debt policy).")
    args = ap.parse_args(argv)
    root = args.root.resolve()

    # Warn on EVERY gate run, not only when findings happen to be written. The
    # write path reaches backlog_is_ignored via write_findings, but that returns
    # early on an empty findings set, so a plain `--gate` run over an ignored
    # tasks/ dir used to pass in silence -- the exact invisible-registry failure
    # this check exists to announce. Say it here so the gate always says it.
    if args.gate:
        ignored = backlog_is_ignored(root)
        if ignored:
            logger.warning("tasks/backlog is git-ignored in %s (%s) -- registered "
                           "debt is written where git cannot see it", root, ignored)

    if args.findings_file:
        _write_findings_path(root, args.findings_file)

    # Read AFTER the write path, never before: the findings just persisted are
    # part of the corpus this run judges.
    outstanding = open_tasks(root)
    scope = _print_corpus(root, outstanding)

    # La cuarta salida (DEBT-SURVEY-SHIP-FREEZE-INCENTIVE-INVERTED): deuda
    # ABIERTA, medida, con dueno y disparador, que NO bloquea el envio y SI
    # se imprime -- y que SIGUE contando en `open debt` de arriba, nunca se
    # retira de `outstanding` en si. Impresa siempre, incluso en cero: una
    # exencion que no se ve es la que se vuelve permanente en silencio.
    aceptadas = _print_accepted_summary(root)
    deferred, cnr_clases = _print_deferred_summary(root)
    _print_not_zero_debt(len(outstanding), deferred, cnr_clases)

    baseline, bloqueantes = _print_baseline(root, outstanding, aceptadas)

    cnr_condena, cnr_bloq = report_could_not_run(root, baseline, gate=args.gate)
    # A broken declaration convicts WITHOUT `COULD_NOT_RUN_BLOCKS`. That switch
    # governs a rollout -- 243 open files across 8 repos that would stop the
    # fleet the moment it flips -- and this is a different animal: measured
    # 2026-09-05, 0 of 21 repos declare a corpus this gate cannot reach, so the
    # conviction costs nothing today and the hole is closed while it is empty.
    # A gate armed only after it has something to catch is a gate that let the
    # first one through.
    declaracion_rota = bool(args.gate and scope.could_not_run)
    verdict = ("BLOCKED" if (args.gate and bloqueantes)
               else "COULD_NOT_RUN" if (
                   args.gate and (cnr_condena or declaracion_rota or cnr_clases)
               ) else "OK")
    if not would_dirty_own_repo(root):
        stamp_verdict(root, verdict, len(outstanding))
    # Unconditional: `bloqueantes` is already the fully-scanned count by this
    # point on every branch (OK, BLOCKED, COULD_NOT_RUN alike) -- the same
    # count `explain_verdict`'s "[ship-freeze] FAIL: ..." line prints.
    emit_hallazgos("[ship-freeze]", len(bloqueantes))
    return explain_verdict(
        verdict, bool(baseline),
        bloqueantes=bloqueantes,
        cnr_bloq=cnr_bloq,
        scope_could_not_run=scope.could_not_run,
    )


if __name__ == "__main__":
    sys.exit(main())
