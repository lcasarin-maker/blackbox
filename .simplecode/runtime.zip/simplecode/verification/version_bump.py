# -*- coding: utf-8 -*-
"""Semantic version bump derived from Conventional Commits.

`pyproject.toml`'s `[project].version` is a human-maintained field with no
mechanism forcing it to move -- measured live in this repo (2026-08-26): 15
real `feat`/`fix` commits landed in one session and the version sat still at
3.7.0 the whole time, because nobody remembered to bump it. That number is
also the "big change" signal `cli_new._source_version`/`satellite_sync`'s
drift report rely on, so a version that never moves quietly defeats them.

This module answers one question mechanically: since the version field was
last actually changed, has a commit landed whose Conventional Commits type
implies a new version is warranted (`feat` -> minor, `fix`/`perf` -> patch, a
`!` after the type/scope or a `BREAKING CHANGE:` footer -> major)? If yes,
`--gate` blocks until someone runs `--apply` to write the bump for real.

The TYPE is a label the author writes, so it cannot be the only signal. A
commit that changes PRODUCT code (see :func:`untyped_product_changes`) under a
type that implies no bump (`chore`, `refactor`, `docs`, none at all) now
requires a PATCH. Measured 2026-09-26 (DEBT-GATE-ENGANABLE-VERSION-BUMP): a new
function under `src/` committed as `chore: tidy` passed `--gate` with rc=0.
PATCH, not MINOR, and on purpose: the gate reads that product changed, never
whether a capability was added -- that answer lives in the author's head --
and PATCH is the lowest level that makes the version move. It is also the row
ADR-0013 D1 gives to "no new capability", which is the most the gate can
honestly assert about an untyped change, and it triggers no Sunset Audit. A
real feature hidden under `chore:` still ships as a patch: the gate closes
"the version did not move at all", not "the version moved by the wrong amount".
Reopened and fixed on Luis's decision of 2026-09-28; accepted cost: more pushes
ask for a bump.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tomllib
from pathlib import Path

from simplecode.utils.git_utils import run_git
from simplecode.verification.audit_ledger import (
    AUDIT_BLOCKED,
    AUDIT_COULD_NOT_RUN,
    AUDIT_EXIT_CODES,
    AUDIT_OK,
    audit_verdict_worse,
    describe_tree_provenance,
    verify_audit_fresh,
    verify_audit_fresh_at_commit,
)
from simplecode.worktree.ratchet import bump_version_string
from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos

_TYPE_RE = re.compile(r"^(?P<type>[a-zA-Z]+)(?:\([^)]*\))?(?P<bang>!)?:\s")
_BREAKING_FOOTER_RE = re.compile(r"^BREAKING[ -]CHANGE:", re.MULTILINE)
_MINOR_TYPES = frozenset({"feat"})
_PATCH_TYPES = frozenset({"fix", "perf"})
_SEVERITY = {"none": 0, "patch": 1, "minor": 2, "major": 3}


def classify_commit(message: str) -> str:
    """"major"/"minor"/"patch"/"none" for one commit's full message (subject
    line + body). A bare `type: subject` with no recognized type (docs,
    test, chore, style, ci, build, refactor, ...) is "none" -- it does not
    warrant a new version on its own."""
    subject = message.splitlines()[0] if message else ""
    match = _TYPE_RE.match(subject)
    if _BREAKING_FOOTER_RE.search(message) or (match and match.group("bang")):
        return "major"
    if match and match.group("type") in _MINOR_TYPES:
        return "minor"
    if match and match.group("type") in _PATCH_TYPES:
        return "patch"
    return "none"


def required_bump(messages: list[str]) -> str:
    """The highest-severity bump level implied by any commit in `messages`."""
    level = "none"
    for message in messages:
        classified = classify_commit(message)
        if _SEVERITY[classified] > _SEVERITY[level]:
            level = classified
    return level


def current_version(root: Path) -> str | None:
    """The project's declared version from `pyproject.toml`, falling back to
    a one-line `VERSION.txt`, or `None` when the project declares a version
    in neither -- this gate simply does not apply to a project that declares
    no version anywhere (`main` treats that as N/A, not a failure). Raises `ValueError` (caught by `main` as
    COULD_NOT_RUN, never an unhandled traceback) only when a `pyproject.toml`
    DOES exist but has no `[project].version` field -- a real gap, distinct
    from "not applicable".

    Reported live (Atlas, 2026-08-26): a consuming repo with no
    `pyproject.toml` at all (its own config lives in `ruff.toml`, and it
    isn't a Python package) crashed this gate outright at pre-push. Unlike
    `unselected_rules`'s earlier fix for the same repo (a real equivalent
    second location, `ruff.toml`, existed to fall back to), a semver version
    has no natural home outside `pyproject.toml` -- blocking forever with no
    honest fix path would be wrong, so absence is N/A, not a violation.
    """
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        # Second real home, same shape as `unselected_rules`' `ruff.toml`
        # fallback: a project that is not a Python package can still version
        # itself, and several do it in a one-line `VERSION.txt`. Measured on
        # cuenza (.NET + React) 2026-09-05: the hook was wired at pre-push
        # announcing "version reflects what shipped", `current_version`
        # returned None, and the gate reported N/A rc=0 on all 18 of its runs
        # -- zero blocks. A gate that cannot see its subject is not a lenient
        # gate, it is an absent one that still advertises a promise.
        return _version_from_version_txt(root)
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    version = data.get("project", {}).get("version")
    if not version:
        raise ValueError(f"no [project].version in {pyproject}")
    return str(version)


def _version_from_version_txt(root: Path) -> str | None:
    """The version declared in a one-line `VERSION.txt`, or None when there is
    no such file -- absence stays N/A, exactly as a missing `pyproject.toml`
    was before this fallback existed.

    Raises ValueError (which `main` catches as COULD_NOT_RUN, never an
    unhandled traceback) when the file EXISTS but holds nothing that looks
    like a version: that is a real gap, distinct from "not applicable", and
    is the same distinction `pyproject.toml` already draws above.
    """
    version_txt = root / "VERSION.txt"
    if not version_txt.is_file():
        return None
    try:
        crudo = version_txt.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise ValueError(f"could not read {version_txt}: {exc}") from exc
    linea = _first_version_line(crudo)
    if linea is None:
        raise ValueError(f"no version in {version_txt}")
    return linea


def _first_version_line(text: str) -> str | None:
    """First non-empty, non-comment line of a `VERSION.txt` body: the file is
    a declaration, not a changelog, but a leading comment is cheap to tolerate.
    Shared by the working-tree read and `_version_at_commit`, so the two cannot
    disagree about what the same bytes declare."""
    for linea in text.splitlines():
        linea = linea.strip()
        if linea and not linea.startswith("#"):
            return linea
    return None


def _version_source_relpath(root: Path) -> str | None:
    """`"pyproject.toml"` or `"VERSION.txt"`, whichever this project actually
    uses to declare its version, or `None` if neither exists.

    Every git-log-based helper below (`_last_version_change_sha`,
    `head_changes_version`, `unpushed_version_change`) must ask THIS instead
    of hardcoding `pyproject.toml`: a VERSION.txt project's diffs never touch
    pyproject.toml at all, so hardcoding it made every one of those checks
    permanently return "no version change happened" for such a project --
    `commits_since_last_bump`'s baseline never advances (every commit in the
    repo's WHOLE history counts, forever, after every real bump), and
    `release_audit_status` never requires a fresh H1 ledger at that project's
    actual release boundary. Caught reviewing this fallback before it shipped:
    the happy path (read a version, apply a bump) worked in isolation while
    the gate's own "is a bump due" signal stayed silently wrong for the exact
    class of consumer this fallback exists for.
    """
    if (root / "pyproject.toml").is_file():
        return "pyproject.toml"
    if (root / "VERSION.txt").is_file():
        return "VERSION.txt"
    return None


# `pyproject.toml` carries many lines besides the version, so only a commit
# that touched the `version = "..."` line itself counts -- `-G` is a content
# pickaxe, not a path pickaxe. `VERSION.txt` is a single line depicting
# nothing else, so a plain path-scoped log (no `-G`) is already exact: any
# commit that touched the file at all touched its version.
_VERSION_LINE_PICKAXE = r'^version\s*=\s*"'


def _last_version_change_sha(root: Path) -> str | None:
    """The most recent commit whose diff to the project's real version
    source (`pyproject.toml` or `VERSION.txt`, see :func:`_version_source_relpath`)
    touched the version -- the baseline `commits_since_last_bump` counts
    forward from. `None` if the version has never been committed (or this
    is not a git repository, or neither version source exists), in which
    case every reachable commit counts."""
    source = _version_source_relpath(root)
    if source is None:
        return None
    args = ["log", "--format=%H", "--first-parent"]
    if source == "pyproject.toml":
        args += ["-G", _VERSION_LINE_PICKAXE]
    args += ["--", source]
    rc, stdout, _ = run_git(args, root)
    if rc != 0:
        return None
    shas = [line for line in stdout.decode("utf-8", "surrogateescape").splitlines() if line.strip()]
    return shas[0] if shas else None


def commits_since_last_bump(root: Path) -> list[str]:
    """Full commit messages (subject + body) landed since the version field
    was last actually changed. Empty if nothing has landed since, or if
    there is no commit history at all."""
    baseline = _last_version_change_sha(root)
    range_spec = f"{baseline}..HEAD" if baseline else "HEAD"
    rc, stdout, _ = run_git(["log", "--format=%B%x00", range_spec], root)
    if rc != 0:
        return []
    # git inserts a newline after each commit's formatted output by default,
    # which becomes a leading blank line on every entry but the first once
    # split on the NUL separator -- strip it, or classify_commit's
    # `splitlines()[0]` reads an empty "subject" instead of the real one.
    text = stdout.decode("utf-8", "surrogateescape")
    return [message.strip() for message in text.split("\x00") if message.strip()]


def _is_product_path(rel: str, targets: tuple[str, ...]) -> bool:
    """Whether repo-relative `rel` lives under one of the product `targets`
    and is not a test. A target may be a directory (`src`, `pkg`), a flat
    module name (`red` for `red.py`) or a dotted one (`pkg.sub`), the three
    shapes `coverage_targets` already accepts."""
    from simplecode.verification.coverage_target import _TEST_DIR_NAMES, _is_test_file
    parts = rel.split("/")
    if _is_test_file(Path(rel)) or _TEST_DIR_NAMES.intersection(parts[:-1]):
        return False
    for target in targets:
        base = os.path.normpath(target).replace(os.sep, "/")
        dotted = target.replace(".", "/")
        if rel == base or rel.startswith(base + "/") or rel == dotted + ".py" or rel.startswith(dotted + "/"):
            return True
    return False


def untyped_product_changes(root: Path) -> list[str] | None:
    """Product files changed, since the last bump, by commits whose TYPE
    implies no bump (`classify_commit(...) == "none"`). `None` when git could
    not answer -- an unknown, never read as "nothing changed".

    What is "product" is not decided here: it is exactly what the coverage
    floor measures, `coverage_target.resolve_targets` (the declared
    `coverage_targets`, else `src/` if it holds Python, else every top-level
    package with an `__init__.py`), minus test files and test directories
    inside it. Any file there counts, not only `.py`: a template under `src/`
    ships as much as a module does.

    Reads `git log -z --name-only`: `-z` NUL-terminates both the formatted
    header and each pathname and, distinct from `core.quotePath=false` alone
    (which still C-quotes a `"` or a newline embedded in a name), turns off
    path quoting entirely. Closed DEBT-VERSION-BUMP-QUOTED-PATHS 2026-09-28 --
    with `core.quotePath=false` and no `-z`, a product path containing a `"`
    or a newline was still printed quoted/escaped by `git log`, so it never
    matched `_is_product_path`'s literal comparison and the change went
    unreported. Per commit, the raw bytes look like
    `\\x1e<message>\\x1f\\x00\\n<name1>\\x00<name2>\\x00...`: `\\x1e` opens the
    entry, `\\x1f\\x00` is `%x1f` followed by `-z`'s own NUL terminator for the
    formatted header, and (when the commit touched any file) a single leading
    `\\n` -- the blank line git always inserts before a name list -- precedes
    the NUL-terminated names. Parsed on bytes, never decoded first, since a
    path can carry non-UTF-8 bytes that only `surrogateescape` per-piece
    decoding survives.
    """
    from simplecode.verification.coverage_target import resolve_targets
    targets = resolve_targets(root)
    if not targets:
        return []
    baseline = _last_version_change_sha(root)
    range_spec = f"{baseline}..HEAD" if baseline else "HEAD"
    rc, stdout, _ = run_git(
        ["-c", "core.quotePath=false", "log", "-z", "--format=%x1e%B%x1f", "--name-only", range_spec], root
    )
    if rc != 0:
        return None
    found: list[str] = []
    for entry in stdout.split(b"\x1e"):
        if not entry:
            continue
        message_bytes, sep, rest = entry.partition(b"\x1f\x00")
        if not sep or classify_commit(message_bytes.decode("utf-8", "surrogateescape").strip()) != "none":
            continue
        names_region = rest[1:] if rest[:1] == b"\n" else rest
        for rel_bytes in names_region.split(b"\x00"):
            if not rel_bytes:
                continue
            rel = rel_bytes.decode("utf-8", "surrogateescape")
            if rel not in found and _is_product_path(rel, targets):
                found.append(rel)
    return found


def head_changes_version(root: Path) -> bool:
    """Whether HEAD is the release commit that changed project version.

    Reads whichever real version source this project has (see
    :func:`_version_source_relpath`) -- a VERSION.txt project's release
    commit never touches pyproject.toml, so hardcoding that path made this
    always False for such a project, and every commit read as "not a
    release" forever.

    `--root` matters and is easy to miss: `git diff-tree` prints nothing for
    a repository's FIRST commit unless told to diff it against the empty
    tree, so a project whose very first commit is the one declaring its
    version (measured while testing this fallback's VERSION.txt path, but
    true of pyproject.toml too, just never exercised by an existing test)
    silently read as "not a release" on its own release commit.
    """
    source = _version_source_relpath(root)
    if source is None:
        return False
    rc, stdout, _ = run_git(
        ["diff-tree", "--no-commit-id", "--unified=0", "-r", "--root", "HEAD", "--", source], root
    )
    if rc != 0:
        return False
    diff_text = stdout.decode("utf-8", "surrogateescape")
    if source == "VERSION.txt":
        return bool(diff_text.strip())
    return bool(re.search(r'^[+-]version\s*=\s*"', diff_text, re.M))


def _release_is_outgoing_without_upstream(root: Path, source: str) -> bool:
    """Whether a commit that changed the version is present locally and on NO
    remote -- the honest outgoing range for a branch with no `@{upstream}`.

    This exists because the HEAD-only fallback it replaced was a hole in the
    release boundary, not a conservative simplification. With no upstream
    configured, `unpushed_version_change` used to answer with
    `head_changes_version`, which reads HEAD ALONE: a release commit at HEAD~1
    or deeper (anything committed on top of it -- a docs tweak, a ledger
    refresh) made it return False, `release_audit_status` returned clean
    WITHOUT EVER CALLING `verify_audit_fresh`, and the push carried the release
    commit with H1 never consulted at all. `git push -u origin <branch>` runs
    pre-push before `branch.<name>.remote` exists, so "no upstream" is not an
    exotic state; it is the first push of every new branch.

    `HEAD --not --remotes` is the answer that needs no upstream: a commit
    present on any remote-tracking ref is already published, and everything
    else is what this push would send. It is also commit-wise rather than a
    two-dot tree diff, so a bump-then-revert pair inside the range still reads
    as a release rather than cancelling out.

    Fails CLOSED (True, i.e. H1 is required) when we are demonstrably inside a
    git repo with remotes and git still cannot answer: an unknown read as "no
    release here" is exactly the silence this function was written to remove.
    Fails OPEN (delegating to `head_changes_version`) only in the two cases
    that are genuinely not a release boundary: a repo with no remote-tracking
    refs at all (nothing has ever been pushed anywhere -- true
    initialization), and an unborn HEAD (no commits, so nothing to push).

    Takes `source` from its caller rather than resolving it again: the caller
    has already established the project HAS a version source, so a second
    `if source is None` here would be a branch no call can reach -- an
    unreachable guard is not caution, it is a line no test can ever exercise.
    """
    refs_rc, refs_out, _ = run_git(["for-each-ref", "--format=%(refname)", "refs/remotes/"], root)
    if refs_rc != 0 or not refs_out.strip():
        return head_changes_version(root)
    head_rc, _, _ = run_git(["rev-parse", "--verify", "HEAD"], root)
    if head_rc != 0:
        return False
    args = ["log", "--format=%H", "--first-parent"]
    if source == "pyproject.toml":
        args += ["-G", _VERSION_LINE_PICKAXE]
    args += ["HEAD", "--not", "--remotes", "--", source]
    rc, stdout, _ = run_git(args, root)
    if rc != 0:
        return True
    return bool(stdout.strip())


def unpushed_version_change(root: Path) -> bool:
    """Whether the commits awaiting the configured upstream contain a release.

    Looking across the whole outgoing range prevents a harmless docs commit
    placed after the version commit from bypassing H1. Repositories without an
    upstream ask `_release_is_outgoing_without_upstream`, which reads the whole
    not-yet-published range instead of HEAD alone -- see its docstring for the
    hole that answer closes.
    """
    source = _version_source_relpath(root)
    if source is None:
        return False
    upstream_rc, _, _ = run_git(["rev-parse", "--verify", "@{upstream}"], root)
    if upstream_rc != 0:
        return _release_is_outgoing_without_upstream(root, source)
    rc, stdout, _ = run_git(["diff", "@{upstream}..HEAD", "--", source], root)
    if rc != 0:
        return False
    diff_text = stdout.decode("utf-8", "surrogateescape")
    if source == "VERSION.txt":
        return bool(diff_text.strip())
    return bool(re.search(r'^[+-]version\s*=\s*"', diff_text, re.M))


def unpushed_release_commits(root: Path) -> list[str] | None:
    """The SHAs of outgoing commits that changed the version, newest first.

    `None` means git could not answer -- distinct from `[]`, which means git
    answered that the outgoing range carries no release commit.

    This exists because `unpushed_version_change` answers a BOOLEAN over the
    whole outgoing range, and a boolean cannot say WHICH commit. Measured in
    this repo 2026-09-15: one push carried THREE releases (`2bfd0dfa` 6.5.0,
    `a65cc9af` 6.5.1, `f457f5d63a25` 6.5.2) inside 38 commits, and the single
    verdict H1 produced was about none of them. Judging "the" release commit
    would still miss two of those three, so the gate asks about every one.

    DIVERGENCE FROM `unpushed_version_change`, stated because it is real and
    because leaving it silent is how a hole survives: with an upstream
    configured that function uses a two-dot `git diff`, while this one uses
    `git log` over the same range. A bump-and-revert pair inside one push
    cancels out in the diff and does not in the log, so the two can disagree.
    The caller (`release_audit_status`) turns that disagreement into a
    COULD_NOT_RUN instead of a pass: a boolean saying "there is a release here"
    while the enumeration names none of them is an unknown, and an unknown read
    as "nothing to audit" is the exact silence this module keeps closing.
    """
    source = _version_source_relpath(root)
    if source is None:
        return []
    args = ["log", "--format=%H", "--first-parent"]
    # Same content pickaxe as `_release_is_outgoing_without_upstream`: a
    # `pyproject.toml` carries many lines besides the version, a `VERSION.txt`
    # does not. Not factored out with that function: the two build DIFFERENT
    # ranges, and a shared helper taking the range as an argument would be one
    # indirection over two lines that read plainly where they are.
    if source == "pyproject.toml":
        args += ["-G", _VERSION_LINE_PICKAXE]
    upstream_rc, _, _ = run_git(["rev-parse", "--verify", "@{upstream}"], root)
    args += ["@{upstream}..HEAD"] if upstream_rc == 0 else ["HEAD", "--not", "--remotes"]
    args += ["--", source]
    rc, stdout, _ = run_git(args, root)
    if rc != 0:
        return None
    return [line for line in stdout.decode("utf-8", "surrogateescape").splitlines() if line.strip()]


def release_audit_status(root: Path) -> tuple[str, list[str]]:
    """Require H1 only at the release boundary, not on ordinary commits.

    Returns a VERDICT WORD, not a bool: `AUDIT_OK`, `AUDIT_BLOCKED` or
    `AUDIT_COULD_NOT_RUN`. The third value is the point of the signature change
    (2026-09-15) -- "the release commit's ledger was not green" and "git could
    not tell me what ledger that commit had" are opposite facts, and while this
    returned a bool one of them had to be reported as the other.

    A word rather than the 0/1/2 exit code it maps to (`AUDIT_EXIT_CODES`),
    because a leftover caller from the bool contract returns `False` and
    `False == 0` in Python: with integer verdicts that stale `False` would BE the
    OK verdict and would turn its gate green while meaning the opposite. Two
    stubs in this repo's own tests did exactly that during this change. Against
    a word, `False` matches no verdict and `audit_verdict_worse` /
    `AUDIT_EXIT_CODES` both treat an unrecognized verdict as BLOCKED.

    Two subjects, both required, because they answer different questions:

    * `verify_audit_fresh(root)` -- the WORKING TREE. Unchanged, and kept: it is
      what tells whoever is pushing that the ledger in front of them is green.
    * `verify_audit_fresh_at_commit(root, sha)` for EVERY outgoing release
      commit -- the commit's OWN ledger blob against the commit's OWN governing
      documents. This is the half that was missing, and its absence is measured
      in DEBT-PUSH-LOOP-07: H1 judged the tip of a 38-commit push and two
      releases inside it were never the subject of any verdict.

    Strictly additive: it can block where the old answer passed, never pass
    where the old answer blocked. And it blocks by CONTENT AT THE COMMIT, never
    by distance or by tree hash -- the tree seal was retired by Luis's vote the
    same day and nothing here brings it back under another name.
    """
    if not unpushed_version_change(root):
        return AUDIT_OK, []

    tree_ok, reasons = verify_audit_fresh(root)
    worst = AUDIT_OK if tree_ok else AUDIT_BLOCKED

    releases = unpushed_release_commits(root)
    if releases is None:
        return AUDIT_COULD_NOT_RUN, [
            *reasons,
            "git could not enumerate which outgoing commits changed the version, so "
            "whether the release commits carried a green H1 ledger is UNKNOWN -- "
            "this is not a pass",
        ]
    if not releases:
        # `unpushed_version_change` said there IS a release in the outgoing
        # range and the enumeration named none. See that function's DIVERGENCE
        # note: the two read the range differently, and the honest verdict for a
        # disagreement is "I do not know which commit to audit".
        return AUDIT_COULD_NOT_RUN, [
            *reasons,
            "the outgoing range changes the version but no outgoing commit could be "
            "named as the release commit, so which ledger was in force at the "
            "release is UNKNOWN -- this is not a pass",
        ]

    for sha in releases:
        verdict, commit_reasons = verify_audit_fresh_at_commit(root, sha)
        reasons.extend(commit_reasons)
        worst = audit_verdict_worse(worst, verdict)
    return worst, reasons


def _rewrite_line(path: Path, pattern: str, replacement: str) -> bool:
    """Substitute the first match of `pattern` in `path` with `replacement`,
    returning whether a match was found and the file rewritten."""
    if not path.is_file():
        return False
    content = path.read_text(encoding="utf-8")
    updated = re.sub(pattern, replacement, content, count=1)
    if updated == content:
        return False
    # Durable: this rewrites the project's real version in pyproject.toml, and
    # a torn write leaves the manifest that every gate and build reads in a
    # half-state. Not theoretical on this hardware -- Atlas measured 20 dirty
    # shutdowns in 37 boots (DGX-393), with ext4 delayed allocation losing
    # dirty pages that then read back as NUL.
    atomic_io.write_text_durable(path, updated)
    return True


def _rewrite_cargo_toml_version(path: Path, new_version: str) -> str | None:
    """Rewrite a Rust crate's `[package].version` in `path`, returning the
    crate's `name` (needed to key its entry in the sibling `Cargo.lock`), or
    `None` when there is nothing here to rewrite: no such file, no
    `[package]` table, or a `[package].version` that is not a literal string
    -- a workspace member declaring `version.workspace = true` inherits its
    number from the workspace root's own `[workspace.package]` instead, and
    bumping THAT is a different, unhandled case, not this one silently
    matching the wrong line.

    Scoped to the `[package]` block specifically, not a bare pickaxe for any
    `^version\\s*=` line: a `[dependencies.foo]` table can carry its own
    `version = "..."` line, and rewriting the first such line anywhere in the
    file would silently retarget an unrelated dependency pin instead of the
    crate's own version.
    """
    if not path.is_file():
        return None
    content = path.read_text(encoding="utf-8")
    try:
        data = tomllib.loads(content)
    except tomllib.TOMLDecodeError:
        return None
    package = data.get("package")
    if not isinstance(package, dict):
        return None
    name = package.get("name")
    if not isinstance(name, str) or not isinstance(package.get("version"), str):
        return None
    lines = content.splitlines(keepends=True)
    start = next((i for i, line in enumerate(lines) if line.strip() == "[package]"), None)
    if start is None:
        return None
    end = len(lines)
    for i in range(start + 1, len(lines)):
        if lines[i].strip().startswith("["):
            end = i
            break
    for i in range(start + 1, end):
        if re.match(r'^version\s*=\s*"', lines[i]):
            lines[i] = re.sub(r'"[^"]*"', f'"{new_version}"', lines[i], count=1)
            atomic_io.write_text_durable(path, "".join(lines))
            return name
    return None


def _rewrite_cargo_lock_version(path: Path, crate_name: str, new_version: str) -> bool:
    """Rewrite `crate_name`'s `version` inside its `[[package]]` block in a
    Cargo.lock, returning whether a matching entry was found and rewritten.

    Cargo always emits `name` immediately before `version` within a block, so
    scanning forward from each `[[package]]` header for the first `version =`
    line before the next `[`-prefixed line lands on the right one exactly --
    it does not need to be a full TOML round-trip (which would also lose
    Cargo.lock's own comment header and exact formatting on write).
    """
    if not path.is_file():
        return False
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    target = f'name = "{crate_name}"'
    i = 0
    while i < len(lines):
        if lines[i].strip() != "[[package]]":
            i += 1
            continue
        j = i + 1
        entry_name = None
        version_idx = None
        while j < len(lines) and not lines[j].strip().startswith("["):
            stripped = lines[j].strip()
            if entry_name is None and stripped.startswith("name ="):
                entry_name = stripped
            elif version_idx is None and stripped.startswith("version ="):
                version_idx = j
            j += 1
        if entry_name == target and version_idx is not None:
            lines[version_idx] = re.sub(r'"[^"]*"', f'"{new_version}"', lines[version_idx], count=1)
            atomic_io.write_text_durable(path, "".join(lines))
            return True
        i = j
    return False


def _rewrite_cargo_manifests(root: Path, new_version: str) -> None:
    """Bump `[package].version` in every Cargo.toml this project owns -- at
    the root, or one level down (`fleet_inventory._detect_tech_stack` already
    treats `*/Cargo.toml` as this project's Rust crate: RePic pairs
    `pyproject.toml` with `repic-rs/Cargo.toml` this way) -- plus the
    matching entry in that crate's sibling Cargo.lock.

    Before this existed, `--apply` bumped pyproject.toml alone: measured live
    on RePic (2026-09-06), `repic-rs/Cargo.toml` and `Cargo.lock` sat
    untouched across two consecutive bumps (3.2.1->3.2.2, 3.2.2->3.2.3), and
    the paired-bump convention already established in that repo's own
    history (commit 4523c62) had to be restored by hand each time: edit
    Cargo.toml, run `cargo check` to refresh Cargo.lock, fold both into the
    release commit. Absence of any Cargo.toml is not an error -- most
    projects this tool runs against have none, same as SPEC.md above.
    """
    for cargo_toml in [root / "Cargo.toml"] + sorted(root.glob("*/Cargo.toml")):
        crate_name = _rewrite_cargo_toml_version(cargo_toml, new_version)
        if crate_name is None:
            continue
        _rewrite_cargo_lock_version(cargo_toml.parent / "Cargo.lock", crate_name, new_version)


def _apply_bump(root: Path, new_version: str) -> bool:
    """Write `new_version` into `pyproject.toml`, returning whether a
    version line was found to rewrite.

    Also syncs `SPEC.md`'s own `Template version: X.Y.Z` line, which
    `worktree.drift.version_deviations` requires to match pyproject.toml's
    version exactly -- a pre-existing invariant this module didn't know
    about in its first version, caught live when applying its own first
    real bump (3.7.0 -> 3.8.0) broke that check. `SPEC.md` is optional: a
    project without one (not every `simplecode new` scaffold ships it) is
    not an error.

    Also syncs any Cargo.toml this project owns (see
    `_rewrite_cargo_manifests`) and that crate's Cargo.lock entry, for a
    project that pairs a Python `pyproject.toml` with a Rust crate the way
    RePic does. Also optional, same reasoning as SPEC.md.

    Callers must have already cleared any pre-write gate (ADR-0013's
    sunset-audit, on a minor/major bump) BEFORE calling this -- this
    function performs the actual disk write with no rollback. It used to
    compute AND write the bump in one step, with the sunset-audit check
    running only afterward: a failing check left pyproject.toml already
    bumped, uncommitted, with no way back short of a manual edit. A second
    `--apply` then recomputed a bump on top of that already-bumped-but-
    unconfirmed state instead of retrying the same one -- reproduced live
    (2026-08-30): two failed-then-retried attempts landed at 3.5.0 instead
    of the intended 3.4.0. Splitting "compute" from "write" lets the caller
    gate on the prospective version BEFORE any file changes, so a blocked
    bump leaves the tree exactly as it found it.
    """
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        # The version's other real home. Without this branch the gate could
        # DEMAND a bump on a `VERSION.txt` project and `--apply` could never
        # deliver it: with no pyproject.toml at all, there is nothing for
        # `_rewrite_line` to rewrite. Writing a pyproject.toml instead would
        # be worse -- one consuming repo (cuenza, .NET + React) explicitly
        # refused a fictional one, and inventing a Python manifest to satisfy
        # a gate is the kind of subject-fabrication these gates exist to
        # prevent.
        version_txt = root / "VERSION.txt"
        if not version_txt.is_file():
            return False
        atomic_io.write_text_durable(version_txt, f"{new_version}\n")
    elif not _rewrite_line(
        pyproject, r'(?m)^version\s*=\s*"[^"]*"', f'version = "{new_version}"'
    ):
        # A REAL pyproject.toml exists but has no matching version line --
        # a genuinely different problem from "no pyproject.toml at all", and
        # NOT a case for the VERSION.txt fallback. Checked first (`is_file()`
        # above), not inferred from `_rewrite_line`'s return value: that
        # value is ambiguous between "file absent" and "file present, no
        # match", and conflating them here would silently write the bump
        # into a stray VERSION.txt while leaving a real, broken
        # pyproject.toml unreported -- exactly the kind of subject
        # confusion this whole fallback exists to prevent, not commit.
        return False
    _rewrite_line(
        root / "SPEC.md",
        r"Template version:\s*[0-9]+\.[0-9]+\.[0-9]+",
        f"Template version: {new_version}",
    )
    _rewrite_cargo_manifests(root, new_version)
    return True


def _print_pending_bump_audit_note(root: Path) -> None:
    """With a bump still PENDING under `--gate`, say what H1 will need after it.

    The bump is the verdict in that branch; this is a HEADS-UP and changes no
    return code. Before it existed, `main` consulted the ledger only in the
    `bump == "none"` branch, so a push carrying a feat/fix hit the bump first
    and the H1 failure stayed invisible until the NEXT push -- a sequential
    dependency hidden inside a single gate (fix the bump, push, discover the
    ledger, fix the ledger, push), measured at >= 3 attempts per such push.

    `verify_audit_fresh`, NOT `release_audit_status`: the latter asks
    `unpushed_version_change` first, which is False precisely BECAUSE the bump
    has not happened yet -- it would return clean and skip the check in exactly
    the case this function exists for.

    A separate function rather than five lines inline: `main`'s branch count is
    already over ruff's PLR0912/C901 thresholds (28 functions in this repo are,
    and no wired hook enforces them), and adding to a number already in the red
    is how it stays in the red.
    """
    audit_ok, audit_reasons = verify_audit_fresh(root)
    if not audit_ok:
        print(
            "[version-bump] además, tras el bump el ledger H1 necesitará: "
            + "; ".join(audit_reasons),
            file=sys.stderr,
        )


def _is_major_bump(version: str, new_version: str, bump: str) -> bool:
    """Whether the version about to be written is a MAJOR release in ADR-0013's
    sense -- the row of its table that demands a "Full fleet Sunset Audit".

    The MAJOR digit CHANGING is the trigger, not `bump == "major"`, and that is
    the whole point. ADR-0013's rollover rule makes the major digit advance by
    arithmetic: `6.9.0` + a MINOR bump is `7.0.0`, so the release that made this
    gap visible (simplecode 7.0.0, 2026-09-15) was classified `minor` by the
    commits and MAJOR by the number. Keying off `bump` alone would have read
    that release as a minor and skipped the audit again -- the exact failure
    being closed here. `bump == "major"` is kept as the second arm for a real
    `!`/`BREAKING CHANGE:` commit, whose paradigm shift is the case the ADR
    describes in prose.
    """
    if bump == "major":
        return True
    return version.split(".")[0] != new_version.split(".")[0]


def _sunset_audit_is_due(version: str, new_version: str, bump: str) -> bool:
    """Whether ADR-0013 demands a Sunset Audit for this bump at all.

    True when the MAJOR or the MINOR digit moves; False for a pure PATCH, whose
    row of ADR-0013's D1 table says "None".

    The `".".join(...[:2])` comparison rather than `split(".")[1]`: a version may
    be two-part or even one-part (`bump_version_string` accepts and preserves
    `X.Y`), and indexing `[1]` on `"1"` is an IndexError -- a traceback where a
    verdict belongs. Joining a slice answers the same question for every shape.

    Extracted because this exact expression was written out twice, in the
    `--apply` branch and again in the `--gate` branch, and is now needed a third
    time by `_fleet_audit_row`. Three copies of a gate's trigger condition is
    three places for it to stop agreeing with itself.
    """
    if bump in ("minor", "major"):
        return True
    return ".".join(version.split(".")[:2]) != ".".join(new_version.split(".")[:2])


def _fleet_audit_row(version: str, new_version: str, bump: str) -> str | None:
    """Which row of ADR-0013's D1 table demands a FLEET Sunset Audit here.

    Returns `"MAJOR"`, `"MINOR"`, or None for a pure PATCH.

    ADR-0013 D1, cited literally because the MINOR half of it went unwired for
    two weeks and a half-read table is how that happens:

        | MAJOR  | Paradigm shift: ... | Full fleet Sunset Audit   |
        | MINOR  | New feature: ...    | Fleet Sunset Audit        |
        | PATCH  | Bugfix, coverage, doc tweak -- no new capability | None |

    and D2, which names the trigger outright: "The pre-push hook calls it
    automatically when `version_bump` detects a MINOR or MAJOR bump."

    So MINOR demands the fleet audit in the ADR's own words, and PATCH demands
    nothing. Wired on Luis's vote of 2026-09-15 (DEBT-PUSH-LOOP-08), whose
    previous closure had deliberately left the MINOR row out and had tests
    fixing that MINOR did NOT invoke it; those tests now fix the opposite, and
    the PATCH half of them is unchanged and still load-bearing.

    DECLARED LIMIT, not invented away: the table says "Full fleet Sunset Audit"
    for MAJOR and "Fleet Sunset Audit" for MINOR, and the ADR defines no second,
    lesser audit anywhere -- there is exactly one `run_fleet_audit`. Both rows
    therefore run the SAME audit here, and the row name is carried into the
    report so a reader sees which row asked. Inventing a reduced fleet scan to
    match an adjective the ADR never defines would be fabricating a mechanism.
    """
    if _is_major_bump(version, new_version, bump):
        return "MAJOR"
    if _sunset_audit_is_due(version, new_version, bump):
        return "MINOR"
    return None


def _run_fleet_sunset_audit(root: Path, version: str, new_version: str, row: str) -> None:
    """ADR-0013's fleet Sunset Audit for a MAJOR **or MINOR** bump: RUN it and
    print what it found. Reports, never blocks -- and that is a decision, not an
    omission. `row` is which D1 row demanded it, `"MAJOR"` or `"MINOR"`, and it
    is printed so the reader knows which line of the table is speaking.

    Voted by Luis 2026-09-15 (DEBT-PUSH-LOOP-08): blocking the kit's own
    release on the fleet's exemption state would put publication at the mercy
    of repos this checkout does not own. Measured here the same day,
    `sunset_audit --fleet --gate` -> rc 1 with 150 unreviewed exemptions across
    6 of the 11 repos carrying the kit (Twiner 99, poe_normare 21,
    blog_ciudadano_x 15, declutter 7, aequitas_os 6, RePic 2). The ADR asks for
    the AUDIT, not for the block. What it does buy: a release cannot complete
    without this having executed and its output being on screen, so nobody
    discovers the fleet's state a week later. The local repo's own exemptions
    keep blocking exactly as before -- that gate runs before this call.

    THE MINOR ROW, added 2026-09-15 on a second vote by Luis. The first closure
    of DEBT-PUSH-LOOP-08 wired MAJOR only and left "Fleet Sunset Audit" in the
    MINOR row of D1 with no executor, plus D2's own sentence naming the trigger
    ("when `version_bump` detects a MINOR or MAJOR bump"). Same contract as
    MAJOR: runs, prints, never blocks.

    Accepted cost, re-measured for this change and stated so it is not
    rediscovered as a surprise: every MAJOR **and every MINOR** bump now takes as
    long as the fleet scan does -- measured 2026-09-15 over 11 repos at 5.49 s
    and 5.48 s on two consecutive runs (`sunset_audit --root . --fleet --gate`,
    rc 1 both times).

    AND THE UNCOMFORTABLE HALF OF THAT COST, which is not the seconds. Today the
    fleet is RED: 6 of 11 repos FAIL, 150 unreviewed exemptions. So this prints a
    failing report on every minor bump, routinely, and a report that is always
    red carries as little information as a gate that never catches anything --
    Luis's own reporting law, read in the other direction. Measured 2026-09-15 on
    the real output: 1477 lines total, of which 150 (10.2%) are the actionable
    STALE/UNTAGGED rows and 1283 are OK/PERMANENT rows nobody needs to read.
    NOT silenced here, because silencing it is the one move that cannot be
    undone by a reader: the closing summary names the denominator, the FAIL
    count, the PASS count and every failing repo, so the legible signal is
    the LAST thing on screen rather than buried at line 700 of 1477. Whether the
    per-repo detail should shrink to its failing rows, or be compared against a
    recorded baseline so a reader sees 150 -> 171 instead of red -> red, is a
    decision with its own cost and it is LUIS'S, raised in DEBT-PUSH-LOOP-08 and
    not taken here.

    DECLARED LIMIT, visible in the output: this runs BEFORE `_apply_bump`, so
    the mother repo's own row in the fleet report reads the version still on
    disk (`version=6.9.0`) while the local gate two lines above already judged
    the prospective one (`7.0.0`). Left that way on purpose -- moving the call
    after the write would spend the whole scan on a bump that can still come
    back COULD_NOT_RUN -- and stated because a reader sees both numbers.

    An audit that CANNOT run prints COULD_NOT_RUN and says why, at two
    different scopes. PER REPO, which is the common case and is the audit's
    own job: a declared satellite with no readable `pyproject.toml` gets a
    COULD_NOT_RUN row instead of vanishing from the report -- 8 of the 18
    satellites `fleet.toml` declares, measured 2026-09-15, which is why the
    summary below prints that count beside FAIL and PASS. WHOLE AUDIT, here:
    `OSError` escaping `run_fleet_audit` at all (an unreadable fleet root in a
    container or a detached checkout). A fleet audit that quietly scanned
    nothing would report PASS over an unknown, which is the blind instrument
    this ficha exists to remove.
    """
    print(f"[version-bump] {row} bump {version} -> {new_version}: ADR-0013's {row} row "
          f"requires a fleet Sunset Audit. Running it now (reports, does not block).")
    try:
        from simplecode.verification.sunset_audit import fleet_summary_lines, run_fleet_audit
        resultados = run_fleet_audit(root)
    except OSError as exc:
        print(f"[version-bump] COULD_NOT_RUN: the fleet Sunset Audit ADR-0013 requires "
              f"for a {row} bump could not be executed: {exc}. The fleet's exemption "
              f"state for {new_version} is UNKNOWN -- this is not a PASS.", file=sys.stderr)
        return
    for repo, resultado in resultados.items():
        print(f"\n=== {repo.name} ===")
        resultado.print_report()
    # The denominator and the zeros, all printed, and COULD_NOT_RUN counted
    # APART from FAIL: "3 repos FAIL" over 11 and over 3 are the same number
    # and opposite facts; "0 FAIL" over 0 repos scanned is an absent audit
    # wearing a green verdict; and a repo that was never read is neither a
    # PASS nor a finding. `fleet_summary_lines` owns that wording so this
    # call site and `sunset-audit --fleet` cannot drift apart.
    print()
    for linea in fleet_summary_lines(resultados):
        print(linea)
    if any(not resultado.passed for resultado in resultados.values()):
        print(f"[version-bump] this report does NOT block the {new_version} bump: a "
              f"satellite's exemptions are its own debt, and a satellite that could "
              f"not be read is a gap in the fleet's records rather than a defect in "
              f"this release. It is printed because ADR-0013's {row} row asks for "
              f"the audit.")


def _is_kit_repo(root: Path) -> bool:
    """Whether `root` is the kit's OWN checkout -- the repo whose source is
    what `cli_new._runtime_bundle()` freezes -- rather than a satellite that
    consumes a bundle built somewhere else.

    Two conditions, both necessary: `root` carries a `.simplecode/kit.lock`
    to compare against, AND the installed `simplecode` package that would be
    bundled lives INSIDE `root` (an editable install of this very checkout).
    A satellite fails the second -- its package comes from a wheel in its own
    venv -- so nothing this predicate guards applies to it and its
    version_bump behaviour stays exactly what it was before this existed.

    Measured on this repo 2026-09-15 (DEBT-PUSH-LOOP-06): the generated
    `.git/hooks/pre-push` launches its wrapper and its final step through
    `python .simplecode/run.py`, i.e. the frozen `runtime.zip`, while the
    `.pre-commit-config.yaml` hooks run `python -m` from src. The bundle was
    serving 6.4.2 against a tree at 6.8.0 and no gate looked at the distance.
    In a satellite that distance is `doctor.runtime_freshness`'s job; here
    nothing ran it at all, which is why this check is scoped to the kit.
    """
    if not (root / ".simplecode" / "kit.lock").is_file():
        return False
    from simplecode import cli_new
    # The package must be the REAL source tree of `root`, not merely a path
    # that looks like it lives under it. Measured the hard way on Atlas
    # 2026-09-15, minutes after the first version of this predicate shipped:
    # a satellite runs the kit through `python .simplecode/run.py`, so
    # `cli_new.__file__` is `<satellite>/.simplecode/runtime.zip/simplecode/cli_new.py`
    # -- a zip member path, which `relative_to(root)` accepts because it IS
    # under the satellite. The predicate said True, `--apply` rebuilt a bundle
    # out of the zip's own members, and Atlas's kit.lock came out declaring
    # version 3.8.3 with the sha256 of the empty string as its content hash.
    # Comparing against the file that must exist ON DISK closes it: a zip
    # member is not `is_file()`, and a satellite's wheel install is not this
    # path either.
    source = root.resolve() / "src" / "simplecode" / "cli_new.py"
    if not source.is_file():
        return False
    return Path(cli_new.__file__).resolve() == source


def _kit_lock_version(root: Path) -> str:
    """The `simplecode_version` recorded in `root/.simplecode/kit.lock`.

    Raises `ValueError` -- which `main` reports as COULD_NOT_RUN, never as a
    pass -- when the lock exists (`_is_kit_repo` already established that)
    but cannot be read, is not JSON, or names no version. The file whose
    single job is to say which kit the generated hooks execute does not get
    the benefit of the doubt: an unreadable lock is an unknown, and an
    unknown read as "matches" is the blind instrument this check exists to
    remove.
    """
    lock_path = root / ".simplecode" / "kit.lock"
    try:
        data = json.loads(lock_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError(f"unreadable {lock_path}: {exc}") from exc
    if not isinstance(data, dict) or not data.get("simplecode_version"):
        raise ValueError(f"no simplecode_version in {lock_path}")
    return str(data["simplecode_version"])


def _rebuild_kit_bundle(root: Path) -> str:
    """Rewrite `.simplecode/runtime.zip` and `.simplecode/kit.lock` from the
    kit's own source, returning the version the new lock declares.

    `cli_new._runtime_bundle()` reads the version for its manifest straight
    off `pyproject.toml` on every call (`cli_new._source_version`, no
    caching), so calling it AFTER `_apply_bump` has rewritten that file
    freezes the NEW version. That is the whole property `--apply` depends on
    and the one `test_apply_rebuilds_the_kit_bundle_with_the_version_it_just_wrote`
    pins: the test's stub reads pyproject at call time and the assertion is
    that it saw the bumped number, not the old one.

    Durable writes, same reason `_rewrite_line` uses them: a torn
    `runtime.zip` is the artifact every generated hook executes.
    """
    from simplecode import cli_new
    bundle = cli_new._runtime_bundle()
    lock = cli_new.kit_lock_bytes(cli_new._portable_runner(), bundle)
    atomic_io.write_bytes_durable(root / ".simplecode" / "runtime.zip", bundle)
    atomic_io.write_bytes_durable(root / ".simplecode" / "kit.lock", lock)
    return str(json.loads(lock.decode("utf-8")).get("simplecode_version", "unknown"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--gate", action="store_true", help="Exit 1 if a bump is due but hasn't happened")
    parser.add_argument("--apply", action="store_true", help="Write the required bump to pyproject.toml")
    parser.add_argument(
        "--rebuild-bundle", action="store_true",
        help="Kit checkout only: regenerate .simplecode/{runtime.zip,kit.lock} and nothing else",
    )
    args = parser.parse_args(argv)
    root = args.root.resolve()

    try:
        version = current_version(root)
    except ValueError as exc:
        print(f"[version-bump] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 2
    if version is None:
        print("[version-bump] N/A: neither pyproject.toml nor VERSION.txt declares "
              "a version -- this project has no version for this gate to check.")
        return 0

    kit_repo = _is_kit_repo(root)

    if args.rebuild_bundle:
        if not kit_repo:
            print("[version-bump] N/A: --rebuild-bundle only applies to the kit's own "
                  "checkout, and this project consumes a bundle built elsewhere "
                  "(a satellite's distance is doctor's runtime_freshness). "
                  "Nothing was written.", file=sys.stderr)
            return 2
        print(f"[version-bump] kit runtime bundle rebuilt: kit.lock now says "
              f"{_rebuild_kit_bundle(root)}.")
        return 0

    # The kit's bundle is checked ALONGSIDE the version checks below, in the
    # same run, never as a cascade: a tree with both a pending bump and a
    # stale bundle names both faults at once instead of teaching whoever
    # fixes the first one that there was only ever one.
    #
    # Skipped under `--apply`, which rebuilds the bundle itself a few lines
    # down -- reporting the pre-bump state there would be a verdict on a file
    # this same run is about to rewrite. DECLARED LIMIT: `--apply` on a tree
    # with no bump due returns through the `bump == "none"` branch without
    # rebuilding and without reporting a stale bundle; `--gate` (which every
    # push runs) and `--rebuild-bundle` are what catch that case.
    bundle_stale = False
    if kit_repo and not args.apply:
        try:
            locked = _kit_lock_version(root)
        except ValueError as exc:
            print(f"[version-bump] COULD_NOT_RUN: {exc}", file=sys.stderr)
            return 2
        if locked != version:
            bundle_stale = True
            print(
                f"[version-bump] BLOCKED: the kit's own runtime bundle is stale: "
                f"kit.lock says {locked}, pyproject says {version} -- the generated "
                f"pre-push runs the bundle, so the hooks would execute {locked} while "
                f"the tree is {version}. Rebuild: python -m "
                f"simplecode.verification.version_bump --root . --rebuild-bundle",
                file=sys.stderr,
            )

    rc = _version_checks(root, args, version)
    # `max`, not a short-circuit: a COULD_NOT_RUN (2) from the version checks
    # outranks this block, and a clean 0 there still has to carry this 1.
    return max(rc, 1) if (bundle_stale and args.gate) else rc


def _verdict_when_no_bump_is_due(root: Path, args: argparse.Namespace, version: str, bump: str) -> int:
    """The whole path taken when the commits since the last bump need no bump.

    Extracted from `_version_checks` (DEBT-LINT-OWNERLESS-01, 2026-09-15), which sat at
    complexity 16 with 15 branches and 59 statements because it held four unrelated
    verdicts in one body. The split is by RESPONSIBILITY: this branch, the apply path
    and the gate path each end in their own exit code and none of them falls through --
    established by walking the AST before touching anything, not by reading.

    The exit-code contract is why this is delicate, and it is preserved verbatim: 0 is
    nothing to do, 1 is a finding, 2 is COULD_NOT_RUN. Those are three different
    statements about the world, and collapsing any two turns "I could not measure" into
    "I found a defect" -- or, worse, into a pass.
    """
    audit_verdict, audit_reasons = release_audit_status(root)
    # `AUDIT_EXIT_CODES.get(..., 1)`: an unrecognized verdict word -- which is
    # what a caller still speaking the retired bool contract produces -- is
    # read as BLOCKED, never as 0. Fail closed on the unknown.
    audit_rc = AUDIT_EXIT_CODES.get(audit_verdict, AUDIT_EXIT_CODES[AUDIT_BLOCKED])
    if audit_rc == AUDIT_EXIT_CODES[AUDIT_COULD_NOT_RUN]:
        # rc 2 regardless of `--gate`, and BEFORE the blocked branch below:
        # a COULD_NOT_RUN is not a milder block, it is a different verdict,
        # and `main` already spends 2 on every other unanswerable question
        # in this module. Reported even without `--gate` because the thing
        # that could not be determined does not become determined by the
        # caller not having asked for teeth.
        print("[version-bump] COULD_NOT_RUN: whether the release commit(s) in "
              "this push carried a green H1 ledger is UNKNOWN. This is NOT a "
              "pass and NOT a block -- the state is undetermined:",
              file=sys.stderr)
        for reason in audit_reasons:
            print(f"  - {reason}", file=sys.stderr)
        return 2
    if audit_rc != AUDIT_EXIT_CODES[AUDIT_OK]:
        print("[version-bump] BLOCKED: release commit has no complete green H1 "
              "ledger for the current claims.", file=sys.stderr)
        # The reasons ARE the "what is missing" list: changed claims,
        # violations, unaudited claims, results with no evidence, or no
        # readable ledger at all. Each is a different job, so each is
        # printed as itself rather than collapsed into "stale".
        for reason in audit_reasons:
            print(f"  - {reason}", file=sys.stderr)
        print(f"  Tree provenance (informative, does not gate): "
              f"{describe_tree_provenance(root)}", file=sys.stderr)
        # HOW to refresh it. repic, 2026-09-05: the message gave the old
        # and new fingerprints and stopped, so they had to discover
        # `--extract-claims`, hand-write a results JSON in a shape the
        # message never described, and call `--record --panel --results` --
        # dug out of `main()` inside `runtime.zip`.
        print("  To refresh it:", file=sys.stderr)
        print("    python -m simplecode.cli audit --root . --extract-claims",
              file=sys.stderr)
        print("      -> the claims and their fingerprint: the gate seals "
              "against these, so this says which claims must be audited.",
              file=sys.stderr)
        print("    python -m simplecode.cli audit --root . --record "
              "--results <results.json> --panel '<who ran it, what they found>'",
              file=sys.stderr)
        print("  A CHANGED claims fingerprint means those claims must be "
              "re-audited, not carried: the verdicts on record were taken "
              "against different text.", file=sys.stderr)
        return 1 if args.gate else 0
    print(f"[version-bump] OK: version {version} is current, no feat/fix/breaking commit since last bump.")
    return 0


def _is_kit_source_run_from_its_bundle(root: Path) -> bool:
    """The kit's own checkout, but this process imported the kit from its frozen `runtime.zip`.

    `_is_kit_repo` answers False there on purpose (a satellite's zip member path must never be
    taken for the kit's source), so `--apply` launched as `python .simplecode/run.py ...` bumped
    the version and skipped the bundle rebuild without a word. The pre-push then blocked on a
    `kit.lock` one version behind `pyproject.toml`: a second, foreseeable failed push
    (DEBT-PUSH-LOOP-02, 2026-09-25). What tells this apart from a satellite is a real
    `src/simplecode/cli_new.py` on disk next to a `kit.lock`, which no satellite has.
    """
    return ((root / ".simplecode" / "kit.lock").is_file()
            and (root / "src" / "simplecode" / "cli_new.py").is_file())


def _rebuild_bundle_in_a_source_subprocess(root: Path) -> int:
    """Rebuild the bundle in a child that imports the kit from `root/src`, where `_is_kit_repo` holds.

    Same function, same guard; only the import origin changes, so the Atlas corruption (a bundle
    built from a zip's own members) stays impossible. 2 (COULD_NOT_RUN) when the child fails: the
    bump is already written, and saying nothing about a stale bundle is the defect this fixes.
    """
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join(
        [str(root.resolve() / "src")] + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
    done = subprocess.run(
        [sys.executable, "-m", "simplecode.verification.version_bump",
         "--root", str(root), "--rebuild-bundle"],
        env=env, capture_output=True, text=True, check=False)
    sys.stdout.write(done.stdout)
    if done.returncode != 0:
        print(f"[version-bump] COULD_NOT_RUN: the bump was written but the kit bundle could not be "
              f"rebuilt from src (rc={done.returncode}); run `python -m simplecode.verification."
              f"version_bump --root . --rebuild-bundle`.\n{done.stderr}", file=sys.stderr)
        return 2
    return 0


def _apply_the_bump(root: Path, args: argparse.Namespace, version: str, bump: str, messages: list[str]) -> int:
    """The `--apply` path: write the new version, and everything that guards it.

    Extracted from `_version_checks` (DEBT-LINT-OWNERLESS-01, 2026-09-15). Same
    exit-code contract as its siblings, preserved verbatim: 0 written, 1 a finding, 2
    COULD_NOT_RUN. This is the only one of the three that MUTATES the repo, which is
    reason enough to give it a name: a reader looking for "what writes the version" no
    longer has to scan 226 lines to find out.
    """
    new_version = bump_version_string(version, bump)
    # `old_minor` used to live here as the other half of the inlined
    # "is a sunset audit due" comparison; `_sunset_audit_is_due` owns that
    # question now, so keeping the variable would be a dead local the
    # deadcode gate is right to flag. `new_minor` survives because the
    # blocked-bump message tells the reader which tag to write.
    new_minor = ".".join(new_version.split(".")[:2])

    # ADR-0013: on MINOR or MAJOR bump, sunset-audit gates BEFORE any
    # write happens -- a blocked bump must leave pyproject.toml/SPEC.md
    # untouched, not bumped-and-uncommitted (see _apply_bump's docstring
    # for the incident this replaced).
    if _sunset_audit_is_due(version, new_version, bump):
        from simplecode.verification.sunset_audit import scan_exemptions, check_stale
        records = scan_exemptions(root)
        audit = check_stale(records, new_version)
        audit.print_report()
        if not audit.passed:
            print(
                "[version-bump] BLOCKED: sunset-audit would fail after this version bump "
                f"({version} -> {new_version}); nothing was written.\n"
                "  Tag all stale/untagged exemptions with:\n"
                f"  # sunset-reviewed: {new_minor} -- REASON",
                file=sys.stderr,
            )
            return 1

    # ADR-0013's MAJOR row demands a full FLEET Sunset Audit, and until this
    # call existed nothing ran it -- not this module, not a hook, not the
    # cron. Placed AFTER the local gate (a blocked bump writes nothing, so
    # spending 4-8 s on the fleet would be spent on a release that is not
    # happening) and BEFORE `_apply_bump`, so the bump cannot complete
    # without the audit having executed and printed.
    fleet_row = _fleet_audit_row(version, new_version, bump)
    if fleet_row is not None:
        _run_fleet_sunset_audit(root, version, new_version, fleet_row)

    if not _apply_bump(root, new_version):
        print(f"[version-bump] COULD_NOT_RUN: no version line found in {root / 'pyproject.toml'}", file=sys.stderr)
        return 2
    print(f"[version-bump] bumped {version} -> {new_version} ({bump}, {len(messages)} commit(s) since last bump)")
    if _is_kit_repo(root):
        # The bump is the release boundary, and in THIS repo the release
        # boundary is also when the frozen bundle the generated pre-push
        # executes has to stop being a different kit from the tree.
        print(f"[version-bump] kit runtime bundle rebuilt: kit.lock now says "
              f"{_rebuild_kit_bundle(root)} (the generated pre-push executes this "
              f"bundle, not src).")
    elif _is_kit_source_run_from_its_bundle(root):
        return _rebuild_bundle_in_a_source_subprocess(root)
    return 0


def _warn_if_the_version_source_is_dirty(root: Path, messages: list[str]) -> None:
    """Say so when the version source carries uncommitted changes, and return nothing.

    Extracted from `_version_checks` (DEBT-LINT-OWNERLESS-01, 2026-09-15). Unlike its
    three siblings this path has NO exit code -- checked on the AST, it returned on no
    path at all -- so it is annotated `None` to keep it that way. An edit that made it
    return an int would be a new verdict smuggled in under a warning.
    """
    _rc_est, _out_est, _ = run_git(["status", "--porcelain", "--", "pyproject.toml"], root)
    sucio = _out_est.decode("utf-8", "surrogateescape").strip() if _rc_est == 0 else ""
    if sucio:
        print(
            f"[version-bump] the version in pyproject.toml is UNCOMMITTED, so "
            f"the {len(messages)} commit(s) below are still counted against the "
            f"last COMMITTED version. Commit the bump and run again -- raising "
            f"the number a second time will not change this message.",
            file=sys.stderr,
        )


def _gate_verdict(root: Path, args: argparse.Namespace, version: str, bump: str) -> int:
    """The `--gate` path: the verdict, and no write.

    Extracted from `_version_checks` (DEBT-LINT-OWNERLESS-01, 2026-09-15). Same
    exit-code contract, preserved verbatim, and its siblings' COULD_NOT_RUN arm stays
    2. This is the path a generated pre-push hook runs, so these codes are read by
    machinery and not only by a person.
    """
    _print_pending_bump_audit_note(root)

    # ADR-0013 says the pre-push hook runs sunset-audit automatically on a
    # MINOR/MAJOR bump. It did not: the sunset call lived only inside
    # `if args.apply:`, and the hook wires `--gate` with no `--apply`, so
    # the gate path returned here BEFORE reaching it. Measured 2026-09-01 by
    # an adversarial panel reading the control flow rather than the happy
    # path -- the audit had never fired at push time since the ADR landed.
    # Run it here too: at the gate, a bump that would fail sunset must be
    # reported now, not discovered by whoever later runs `--apply`.
    new_version = bump_version_string(version, bump)
    if _sunset_audit_is_due(version, new_version, bump):
        sunset_rc = _sunset_verdict(root, new_version, f"pending {bump} bump ({version} -> {new_version})")
    else:
        # A PATCH pending on top of a hand-committed MINOR release: the pending
        # bump owes no audit, the committed one does. See
        # `_committed_release_sunset_verdict`.
        sunset_rc = _committed_release_sunset_verdict(root)
    if sunset_rc:
        return 1
    print("[version-bump] BLOCKED -- run with --apply to write the bump.", file=sys.stderr)
    return 1


def _sunset_verdict(root: Path, target_version: str, what: str) -> int:
    """Run ADR-0013's sunset audit against `target_version`; 1 blocks, 0 passes.

    ONE call path for every gate-time sunset check -- the pending bump and the
    committed release -- so the two cannot drift in what they scan or in the
    procedure they print. `what` names the release being judged in the block
    message (`pending minor bump (A -> B)` / `committed release (A -> B)`).
    """
    from simplecode.verification.sunset_audit import check_stale, scan_exemptions
    audit = check_stale(scan_exemptions(root), target_version)
    audit.print_report()
    if not audit.passed:
        # The procedure, not just the verdict. Reported by the
        # maletin_homeopatia session 2026-09-05: this branch printed a
        # HYPOTHETICAL failure of ANOTHER gate at a version that does
        # not exist yet, named none of the 19 exemptions, and said
        # neither what "review" means nor how to declare one permanent.
        # They had to fish the list out of sunset-audit's own dump in
        # the same output. Measured in their telemetry: version-bump
        # blocks 11 of 14 runs, the most of any organ there, and it was
        # the only one whose message did not say what to touch.
        #
        # The `--apply` branch above already carried this guidance. The
        # `--gate` branch is the one everybody actually hits, and it had
        # none -- the asymmetry, not the wording, was the defect.
        # `getattr` rather than attribute access: this guidance block
        # already crashed once on the day it was written (an
        # UnboundLocalError on `new_minor`), and a message that
        # crashes is strictly worse than the silence it replaces --
        # it takes down the verdict it was meant to explain. The
        # count is cosmetic; the procedure below is the payload.
        pendientes = list(getattr(audit, "stale", ())) + list(
            getattr(audit, "untagged", ()))
        emit_hallazgos("[version-bump]", len(pendientes))
        # Computed here rather than reused: `new_minor` is a local
        # of the `--apply` branch, and reaching for it from this one
        # raised UnboundLocalError the first time this ran -- a
        # guidance message that crashes is worse than the silence it
        # replaced.
        minor_objetivo = ".".join(target_version.split(".")[:2])
        print(
            f"[version-bump] BLOCKED: sunset-audit would fail after the {what}.",
            file=sys.stderr,
        )
        print(
            f"  {len(pendientes)} exemption(s) need a review before this "
            f"bump can land. They are listed above, each with its file "
            f"and line.",
            file=sys.stderr,
        )
        print(
            "  A REVIEW is a question with a real answer: has this line "
            "CHANGED since anyone last looked at it? Answer it, do not "
            "stamp it -- `git show <sha>:<file>` and compare the line.",
            file=sys.stderr,
        )
        print(
            f"  Then re-date it to the version being cut:  "
            f"# sunset-reviewed: {minor_objetivo} -- <why it is still correct>",
            file=sys.stderr,
        )
        print(
            "  There is no way to retire the clock: TODA exencion caduca "
            "(decision de Luis, 2026-09-15). `permanent` fue abolido "
            "porque dejo a la mitad `stale` de la compuerta sin un solo "
            "sujeto -- 86 de 86 exenciones de este repo lo llevaban, y el "
            "gate devolvia PASS contra cualquier version futura. Si la "
            "razon de verdad no depende de la version, sigue re-fechandola "
            "cada minor: ese roce es el precio de que alguien la relea.",
            file=sys.stderr,
        )
        return 1
    return 0


def _version_at_commit(root: Path, rev: str, source: str) -> str | None:
    """The version `source` declared at `rev`, or None when git cannot show the
    file there (a root commit's parent, a commit before the file existed) or
    the file there declares none."""
    rc, stdout, _ = run_git(["show", f"{rev}:{source}"], root)
    if rc != 0:
        return None
    text = stdout.decode("utf-8", "surrogateescape")
    if source == "VERSION.txt":
        return _first_version_line(text)
    try:
        version = tomllib.loads(text).get("project", {}).get("version")
    except tomllib.TOMLDecodeError:
        return None
    return str(version) if version else None


def _committed_minor_release(root: Path) -> tuple[str, str] | None:
    """`(previous, released)` for the NEWEST outgoing release commit whose
    version crosses a MINOR or MAJOR boundary against its parent, else None.

    Reuses `unpushed_release_commits` (the same outgoing range H1 judges) and
    `_sunset_audit_is_due` (the same trigger the pending-bump path uses).

    DECLARED LIMITS: a commit whose parent declares no readable version (the
    first commit that declares one) has no boundary to cross and is skipped.
    When git cannot enumerate the releases (`None`) this returns None: that
    exact failure is already reported as COULD_NOT_RUN (rc 2) by
    `release_audit_status`, which outranks the 1 this check could add.
    """
    source = _version_source_relpath(root)
    if source is None:
        return None
    for sha in unpushed_release_commits(root) or ():
        released = _version_at_commit(root, sha, source)
        previous = _version_at_commit(root, f"{sha}^", source)
        if previous and released and _sunset_audit_is_due(previous, released, "none"):
            return previous, released
    return None


def _committed_release_sunset_verdict(root: Path) -> int:
    """ADR-0013's sunset audit for a MINOR/MAJOR release that is already
    COMMITTED and still outgoing.

    The gate used to audit only a PENDING bump. A release written by hand
    (edit the version, commit) leaves no bump pending, so the gate took the
    no-bump path and never ran the sunset check for that release. Measured by
    the r6 H1 audit (ADR-0013, sentence 2) in a scratch clone with a planted
    untagged `# noqa`: pending bump -> "BLOCKED: sunset-audit would fail ...
    (8.8.5 -> 8.9.0)"; the same bump committed by hand -> blocked only on H1,
    no sunset line. Judged against the RELEASED version, the one the
    exemptions must now be re-dated to.
    """
    crossing = _committed_minor_release(root)
    if crossing is None:
        return 0
    previous, released = crossing
    return _sunset_verdict(root, released, f"committed release ({previous} -> {released})")


def _version_checks(root: Path, args: argparse.Namespace, version: str) -> int:
    """Everything `main` did before the kit-bundle check was added to it.

    Split out so `main` can report BOTH faults in one run (see the comment at
    its call site) without threading a flag through the dozen return points
    below -- and because `main`'s branch count was already over ruff's
    PLR0912/C901 thresholds before this feature, so growing it further is how
    a number in the red stays in the red.
    """
    messages = commits_since_last_bump(root)
    bump = required_bump(messages)
    # The type is the author's label; the diff is the subject. Only asked when
    # the label implies nothing and there ARE commits: a feat/fix already
    # demands at least this, and an empty history has nothing to read.
    product_files = untyped_product_changes(root) if bump == "none" and messages else []
    if product_files is None:
        print("[version-bump] COULD_NOT_RUN: git could not list the files the commits "
              "since the last bump changed, so whether they touched product code is "
              "UNKNOWN -- this is not a pass.", file=sys.stderr)
        return 2
    if product_files:
        bump = "patch"

    if bump == "none":
        rc = _verdict_when_no_bump_is_due(root, args, version, bump)
        # A hand-committed MINOR/MAJOR release lands here (no bump pending) and
        # still owes ADR-0013's sunset audit. `max`, so a COULD_NOT_RUN (2)
        # from the H1 verdict is never masked, and both faults print in one run.
        return max(rc, _committed_release_sunset_verdict(root)) if args.gate else rc

    if args.apply:
        return _apply_the_bump(root, args, version, bump, messages)


    # "Bumped but not committed" is its OWN state. Printing the bump-due
    # message with the NEW number instead reads as "your bump does not count",
    # whose natural conclusion is that another bump is needed.
    #
    # Measured by repic 2026-09-05, and it cost them a cycle:
    #     run 1: MINOR bump due: 7 commit(s) since 2.8.2 ...
    #     (they raise pyproject + Cargo.toml to 2.9.0, uncommitted)
    #     run 2: MINOR bump due: 7 commit(s) since 2.9.0 ...
    # The same sentence with the new number. The real blocker only surfaced
    # after committing, and it was the stale H1 ledger -- the version number
    # was never the problem.
    # `run_git`, not a fresh subprocess import: this module already has one way
    # to call git, and a second is a second thing to keep consistent.
    _warn_if_the_version_source_is_dirty(root, messages)
    if product_files:
        print(
            f"[version-bump] PATCH bump due: {len(messages)} commit(s) since {version} carry "
            f"no feat/fix/breaking type but change product code: {', '.join(product_files)}. "
            "The type is a label; what shipped is the diff.",
            file=sys.stderr,
        )
    else:
        print(
            f"[version-bump] {bump.upper()} bump due: {len(messages)} commit(s) since {version} "
            "include a feat/fix/breaking change with no version bump yet.",
            file=sys.stderr,
        )
    if args.gate:
        return _gate_verdict(root, args, version, bump)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
