# -*- coding: utf-8 -*-
"""time_budget.py -- Behavioral verification for gratuitous time-based waits (Fase 3, Goodhart remediation).

`blocking_sleep` asks "does this code call time.sleep()?" -- gameable the
same way the test-quality and atomicity detectors were: a busy-loop polling
`time.time()` in a spin, `threading.Event().wait(N)`, or any indirection
`ast_normalizer` hasn't been taught (and never can be taught exhaustively --
that's the bloat trap the project's own ADR-0012 explicitly wants
to avoid) all achieve the same real effect -- wasted wall-clock time -- while
evading a syntax check that only knows to look for `time.sleep(`.

This asks the question that doesn't care which primitive was used: if the
system clock genuinely didn't have to advance N real seconds for a test to
reach its correct outcome, running that test with time VIRTUALIZED --
`time.sleep()` returns instantly, `time.time()`/`time.monotonic()` still
advance by the requested amount so any elapsed-time or timeout logic in the
code under test keeps behaving correctly -- collapses its real duration
toward zero. A test genuinely bottlenecked on real I/O (a subprocess, a
socket, disk) is UNAFFECTED by virtualizing time; it stays slow, for a
different and legitimate reason this module correctly leaves alone.

Scope, honestly stated: only `time.sleep`/`time.time`/`time.monotonic` are
virtualized. `threading.Event.wait`, `select.select`, and `asyncio.sleep`
(legitimately exempt already -- yielding control there IS the cooperative-
multitasking mechanism, not a code smell) are NOT virtualized -- a test
whose real slowness comes from one of those reads as GENUINE here. A real
limitation, not a silent one; callers checking a survived-with-full-duration
verdict see that plainly in `virtual_duration`, not a false conviction.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time as time_module
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

# GRATUITOUS_WAIT_RATIO calibration: measured directly (2026-08-30) via
# `_run_pytest_node_timed` against throwaway `time.sleep(N)` tests --
#   sleep(2): normal 3.069s, virtual 1.050s -> ratio 0.342 (noisy: re-run
#             measured 3.506s / 1.878s -> ratio 0.536 -- ABOVE 0.5, a false
#             GENUINE). Interpreter+pytest subprocess startup overhead
#             (measured separately below at ~1.0-1.2s) is NOT small relative
#             to a 2s sleep, so the ratio for short sleeps is genuinely
#             unstable run to run.
#   sleep(4): normal 5.131s, virtual 1.139s -> ratio 0.222, a clean margin
#             under 0.5 both times.
# Real, honest limitation this constant carries: detection is reliable for
# sleeps well above the measured startup floor (~1-1.5s) and gets noisy as a
# sleep's duration approaches that floor -- a `time.sleep(0.2)` is not
# reliably distinguishable from subprocess-launch noise by this method. That
# also happens to match what actually matters: a fraction-of-a-second wait
# is not the CI-killing problem a multi-second one is.
GRATUITOUS_WAIT_RATIO = 0.5

# Below this real duration, comparing ratios is noise (subprocess/interpreter
# startup dominates, not the test body) -- never convict a fast test, and
# skip the second (virtualized) subprocess launch entirely rather than pay
# it for nothing. Measured directly (2026-08-30) via `_run_pytest_node_timed`
# on a bare `assert 1 == 1` test, 3 runs: 1.159s, 0.987s, 0.966s -- interpreter
# + pytest collection overhead alone sits close to 1s on this machine. 2.0
# leaves real margin above that measured floor rather than guessing a value
# below it (0.5 was the ORIGINAL, unmeasured guess in this module -- it was
# lower than the real startup floor, so it never actually skipped anything).
MIN_REAL_DURATION_TO_JUDGE = 2.0


class _VirtualClock:
    """A `time` module stand-in: `sleep()` advances a virtual offset instead
    of actually blocking; `time()`/`monotonic()` report real elapsed time
    PLUS that offset, so code computing elapsed durations keeps seeing
    consistent values as if the sleep had really happened."""

    def __init__(self, real_time, real_monotonic):
        self._real_time = real_time
        self._real_monotonic = real_monotonic
        self._offset = 0.0

    def sleep(self, seconds: float) -> None:
        if seconds > 0:
            self._offset += seconds

    def time(self) -> float:
        return self._real_time() + self._offset

    def monotonic(self) -> float:
        return self._real_monotonic() + self._offset


@contextmanager
def virtualize_time(monkeypatch):
    """While active, `time.sleep` never actually blocks; `time.time()` and
    `time.monotonic()` still advance as if it had. Reusable directly by a
    test author (mirrors `fault_inject`'s primitives) to prove their OWN
    test's wait is gratuitous, without needing the subprocess orchestration
    below.
    """
    clock = _VirtualClock(time_module.time, time_module.monotonic)
    monkeypatch.setattr(time_module, "sleep", clock.sleep)
    monkeypatch.setattr(time_module, "time", clock.time)
    monkeypatch.setattr(time_module, "monotonic", clock.monotonic)
    yield clock


# Runs in a FRESH subprocess (not this process's `time` module) so a global,
# unscoped patch is safe -- the interpreter exits right after the one
# measurement, nothing else in this process is affected. Imports
# `_VirtualClock` from THIS module rather than re-embedding its logic as a
# second, string-literal copy: a prior version duplicated the class body
# here, and a negative control caught it for real -- mutating `_VirtualClock`
# alone didn't break the subprocess-based tests at all, because they never
# ran the mutated code; they ran an untouched, independently-drifting copy.
# One implementation, imported twice, cannot silently diverge like that.
_VIRTUALIZED_PYTEST_RUNNER = """
import sys, time
from simplecode.verification.time_budget import _VirtualClock

_vc = _VirtualClock(time.time, time.monotonic)
time.sleep = _vc.sleep
time.time = _vc.time
time.monotonic = _vc.monotonic

import pytest
sys.exit(pytest.main(sys.argv[1:]))
"""


def _run_pytest_node_timed(
    root: Path, test_file: Path, test_name: str, timeout: float, virtualized: bool,
) -> tuple[bool, float]:
    """(passed, real_wall_clock_seconds) for one test node."""
    node_id = f"{test_file.relative_to(root)}::{test_name}"
    args = [sys.executable]
    if virtualized:
        args += ["-c", _VIRTUALIZED_PYTEST_RUNNER]
    else:
        args += ["-m", "pytest"]
    args += [node_id, "-q", "-p", "no:cacheprovider"]

    start = time_module.perf_counter()
    try:
        result = subprocess.run(args, cwd=root, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return False, time_module.perf_counter() - start
    return result.returncode == 0, time_module.perf_counter() - start


@dataclass(frozen=True)
class TimeBudgetVerdict:
    test_file: Path
    test_name: str
    status: str  # "GRATUITOUS_WAIT" | "GENUINE" | "COULD_NOT_RUN"
    real_duration: float = 0.0
    virtual_duration: float = 0.0


def verify_wait_is_genuine(
    root: Path, test_file: Path, test_name: str, timeout: float = 60.0,
) -> TimeBudgetVerdict:
    """Run `test_name` twice -- normally, then with time virtualized -- and
    compare real wall-clock durations. A test whose slowness evaporates
    under virtualization was never waiting on anything real.
    """
    passed, real_duration = _run_pytest_node_timed(root, test_file, test_name, timeout, virtualized=False)
    if not passed:
        return TimeBudgetVerdict(test_file, test_name, "COULD_NOT_RUN", real_duration=real_duration)

    if real_duration < MIN_REAL_DURATION_TO_JUDGE:
        return TimeBudgetVerdict(test_file, test_name, "GENUINE", real_duration, real_duration)

    v_passed, virtual_duration = _run_pytest_node_timed(root, test_file, test_name, timeout, virtualized=True)
    if not v_passed:
        # Passes for real but not under a virtualized clock: its correctness
        # depends on wall-clock semantics this module doesn't fake -- not
        # evidence of a gratuitous wait, and not safe to claim GENUINE either.
        return TimeBudgetVerdict(test_file, test_name, "COULD_NOT_RUN", real_duration, virtual_duration)

    ratio = virtual_duration / real_duration if real_duration else 1.0
    status = "GRATUITOUS_WAIT" if ratio < GRATUITOUS_WAIT_RATIO else "GENUINE"
    return TimeBudgetVerdict(test_file, test_name, status, real_duration, virtual_duration)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Behavioral verification of a test's time-based wait.")
    parser.add_argument("test_file", type=Path)
    parser.add_argument("test_name")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--gate", action="store_true", help="Exit 1 on GRATUITOUS_WAIT or COULD_NOT_RUN")
    args = parser.parse_args(argv)

    verdict = verify_wait_is_genuine(args.root, args.test_file, args.test_name, args.timeout)
    print(
        f"[time-budget] {verdict.test_file}::{verdict.test_name} -> {verdict.status} "
        f"(real={verdict.real_duration:.3f}s, virtual={verdict.virtual_duration:.3f}s)"
    )

    if args.gate and verdict.status != "GENUINE":
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
