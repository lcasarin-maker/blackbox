#!/usr/bin/env python3
"""Look at the building FIRST, choose what applies to it, then run.

Luis, 2026-09-05: *"simple no deberia ver primero el edificio, escoger que
aplica al edificio y luego correr? [...] y si por ejemplo el edificio es .net
desconecta lo que no aplique y genera deuda para simple para que pueda analizar
.net; si es rust lo mismo."*

WHY THE CURRENT ORDER IS BACKWARDS
----------------------------------
Today the kit ships a fixed hook list and every gate independently discovers
whether it has a subject. A gate typed `[python]` in a Rust repo finds no files,
reports nothing, and exits 0 -- so ABSENCE OF A SUBJECT AND ABSENCE OF DEFECTS
produce the same green. Measured across the fleet 2026-09-05:

    RePic        Rust 10,486 lines   Python 689     5 python-typed gates
    cuenza       C#   20,897 lines   Python 10,406  5 python-typed gates
    poe_systems  JS    5,771 lines   Python 4,345   5 python-typed gates

RePic measured `zero_debt` reporting `files scanned: 4` -- all four tooling --
over an engine of 10,486 Rust lines, and their words for the verdict were exact:
*"lo que no es cierto es que 'nueve compuertas en verde' describa el producto"*.
cuenza: *"los gates miden el andamio y son ciegos al edificio"*.

WHAT THIS DOES INSTEAD
----------------------
1. SURVEY the subject: tracked source, by language, with line counts.
2. SELECT the organs that can actually read it, and DISCONNECT the rest by name
   rather than letting them run blind and report green.
3. Emit the gap as DEBT ON THE KIT: a language present in the product that no
   organ can analyse becomes a named ficha with an owner, not a silence.

Point 3 is the one that changes the incentive. A satellite whose product the kit
cannot read stops looking clean and starts holding a receipt for what the kit
owes it -- and the kit's own backlog carries the item, where it can be ranked
against everything else instead of being rediscovered by each satellite in turn.

WHAT THIS IS NOT
----------------
It does not teach any organ a new language, and it does not silence one. It
decides WHICH organs have a subject and says so out loud. An organ that applies
and finds nothing is still reporting a clean measurement; an organ that was
disconnected reported nothing at all, and the difference is now printed.
"""
from __future__ import annotations

import argparse
import logging
import subprocess
import sys
from collections import Counter
from pathlib import Path

from simplecode.utils.tool_limits import GIT_SCAN_TIMEOUT

logger = logging.getLogger(__name__)

# Extension -> the language a reader would name. Only what the fleet actually
# holds; an unlisted extension is counted as `other` and reported, never
# silently dropped.
LANGUAGES: dict[str, str] = {
    ".py": "Python", ".rs": "Rust", ".ts": "TypeScript", ".tsx": "TypeScript",
    ".js": "JavaScript", ".jsx": "JavaScript", ".cs": "C#", ".go": "Go",
    ".java": "Java", ".kt": "Kotlin", ".rb": "Ruby", ".php": "PHP",
    ".swift": "Swift", ".c": "C", ".h": "C", ".cpp": "C++", ".hpp": "C++",
}

# What the kit can actually ANALYSE, as opposed to what it can count. Python
# has full AST-level detectors (`pattern_detectors`, `agent_threats`). The
# four added 2026-09-05 (DEBT-KIT-CANNOT-ANALYSE-{CSHARP,JAVASCRIPT,RUST,
# TYPESCRIPT}) each have exactly ONE real regex-based detector in
# `guards/multilang_detectors.py` that convicts a real, well-known vice in
# that language -- not parser-level parity with Python, which those tickets
# explicitly do not ask for. See that module's docstring for what a
# regex-based check does not claim to catch, and for the fleet-wide pipeline
# wiring (a new pre-commit hook, satellite_sync's template) that is a
# SEPARATE, larger decision this entry does not by itself make.
ANALYSABLE = frozenset({"Python", "C#", "JavaScript", "Rust", "TypeScript"})

# Organs whose reading is language-bound, and therefore have no subject in a
# repo whose product is not Python. `pii_scan`, `no_perder_lineas`,
# `corruption_guard` and the ficha gates read TEXT or GIT and are not listed:
# they apply to any repo.
LANGUAGE_BOUND = (
    "zero_debt", "angry_path", "coverage_target", "pyright", "orphan_hunter",
)

# A product line under one of these is scaffolding, not the building.
_NOT_PRODUCT = {
    ".git", ".venv", "node_modules", "__pycache__", "build", "dist",
    ".simplecode", ".pytest_cache", ".ruff_cache", ".mypy_cache", "vendor",
}


def _tracked(root: Path) -> list[Path]:
    """Tracked files, or a filesystem walk when git cannot answer.

    A walk is the fail-LOUD side: it counts more, so a repo never looks smaller
    than it is because git was unavailable.
    """
    try:
        out = subprocess.run(
            ["git", "ls-files"], cwd=root, capture_output=True, text=True,
            check=False, timeout=GIT_SCAN_TIMEOUT,
        )
        if out.returncode == 0:
            return [root / p for p in out.stdout.splitlines() if p.strip()]
        logger.warning(
            "subject survey: git ls-files exited %s (%s); falling back to a "
            "filesystem walk of %s",
            out.returncode,
            out.stderr.strip() or "no diagnostic",
            root,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        # The walk below still runs (it counts MORE, never less), but the swap of
        # instrument is said, not hidden -- same channel as an unreadable file.
        logger.warning("subject survey: git ls-files could not run (%s); "
                       "falling back to a filesystem walk of %s", exc, root)
    return [p for p in root.rglob("*") if p.is_file()]


def survey(root: Path) -> dict[str, int]:
    """Lines of product source per language. Scaffolding excluded, by name.

    Unreadable files are COUNTED under the `unreadable` key, never skipped in
    silence -- `zero_debt` convicted the first version of this function for
    exactly that (`silent_io_loop_swallow`), in the module whose whole point is
    that an unexamined subject must not read as a clean one. A survey that
    quietly drops what it could not open is the same defect it exists to report.
    """
    loc: Counter[str] = Counter()
    for f in _tracked(root):
        if _NOT_PRODUCT & set(f.parts):
            continue
        lang = LANGUAGES.get(f.suffix.lower())
        if lang is None:
            continue
        try:
            with f.open(encoding="utf-8", errors="replace") as fh:
                loc[lang] += sum(1 for _ in fh)
        except OSError as exc:
            logger.warning("subject survey could not read %s: %s", f, exc)
            loc["unreadable"] += 1
    return dict(loc)


def unanalysable(loc: dict[str, int]) -> dict[str, int]:
    """Languages present in the product that no organ of the kit can read."""
    return {k: v for k, v in loc.items()
            if k not in ANALYSABLE and k != "unreadable" and v > 0}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Survey the subject before choosing gates.")
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--gate", action="store_true",
                    help="exit 1 when the product holds a language no organ can read")
    args = ap.parse_args(argv)
    root = args.root.resolve()

    loc = survey(root)
    if not loc:
        print("[subject] COULD NOT RUN: no source files found under "
              f"{root} -- nothing was surveyed, which is not the same as a clean repo",
              file=sys.stderr)
        return 2

    total = sum(loc.values())
    print(f"[subject] product source in {root.name}: {total:,} line(s)")
    for lang, n in sorted(loc.items(), key=lambda kv: -kv[1]):
        mark = "analysable" if lang in ANALYSABLE else "NOT ANALYSABLE by any organ"
        print(f"    {n:>9,}  {lang:<12} {mark}")

    gaps = unanalysable(loc)
    covered = sum(v for k, v in loc.items() if k in ANALYSABLE)
    print(f"[subject] {covered:,} of {total:,} line(s) ({100 * covered // total}%) "
          f"are in a language the kit can analyse")

    if not gaps:
        print("[subject] OK: every language in this product has organs that read it.")
        return 0

    print(f"[subject] the kit OWES this repo {len(gaps)} language(s):")
    for lang, n in sorted(gaps.items(), key=lambda kv: -kv[1]):
        print(f"    {lang}: {n:,} line(s) of product that NO organ opens. The gates "
              f"typed for Python ({', '.join(LANGUAGE_BOUND)}) have no subject here; "
              f"their green describes the tooling, not the building.")
    print("[subject] This is DEBT ON THE KIT, not on this repo. Report it upstream "
          "as DEBT-KIT-CANNOT-ANALYSE-<LANG> so it is ranked with everything else "
          "instead of being rediscovered by each satellite in turn.")
    return 1 if args.gate else 0


if __name__ == "__main__":
    sys.exit(main())
