#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""consumer_shapes -- the kit is tested against ONE shape of consumer, and says so.

On 2026-09-02 four satellites reported four real defects in this kit in one day,
each with its own paired control, and every one of them was invisible from this
repository BY CONSTRUCTION -- not by oversight, by shape:

    this repo has one interpreter        so a verdict that did not name its
                                         interpreter looked fine
    this repo uses no bundled runtime    so a launcher that guarded on one file
                                         and linked two never showed it
    this repo writes one evidence form   so a reader that grepped where the
                                         canon parsed always agreed with itself
    this repo marks both coverage lanes  so `pytest` exiting 5 for an empty
                                         phase-2 lane never arose

The suite was green throughout. A green suite here is evidence about one shape
of consumer, never about the kit.

What this module fixes is NOT that the repository cannot vary -- all four
defects turned out to be reproducible in a `tmp_path` fixture the moment someone
knew to write one, and all four such fixtures were written that same afternoon.
What was missing is the enumeration: nobody had written down the dimensions
along which a consumer varies, so nobody could see that every test covered the
same combination.

So the dimensions are declared here, tests mark which value they exercise, and
`--gate` prints every value's count INCLUDING the zeros. A value at zero blocks
unless it is declared in `NOT_EXERCISED` with a reason.

DECLARED LIMIT, and it is the honest bound: this makes a silent zero impossible,
not an omission. A dimension nobody thought to declare stays invisible exactly
as before -- the fifth one will still arrive as a satellite's report. What it
buys is that the four we now know about, and every one added after, cannot
quietly stop being covered.
"""
from __future__ import annotations

import argparse
import ast
import sys
from collections import defaultdict
from pathlib import Path

MARKER = "shape"

# dimension -> {value: why this value is a DIFFERENT consumer, not a variant}
SHAPES: dict[str, dict[str, str]] = {
    "runtime": {
        "editable": "the kit itself: `pip install -e .`, gates invoked as `python -m <module>`",
        "bundled": ("a satellite: `.simplecode/runtime.zip` + `run.py`. The launcher guarded on "
                    "`run.py` alone while linking two files, so a worktree with the runner and no "
                    "bundle skipped the linking and died inside python (Atlas DGX-434, 9 tests)"),
    },
    "checkout": {
        "main": "the primary checkout, where `.simplecode/` exists",
        "worktree": ("a linked `git worktree`, where `.git` is a FILE and `.simplecode/` is "
                     "gitignored and absent. A bare `(root/'.git').is_dir()` answered False for a "
                     "real repository in five separate places in this kit"),
    },
    "evidence_form": {
        "nested": "`evidence:` written as a YAML block -- the only form this repo writes",
        "inline": ("`evidence: {\"pass\": ..., \"fail\": ...}` on one line, which the fleet canon "
                   "writes. Both parse to the same mapping; a reader that grepped instead of "
                   "parsing reported 23 entries with artifacts on disk as having none"),
    },
    "coverage_lanes": {
        "both_marked": "the kit: tests exist on both sides of `mutates_real_source`",
        "phase2_empty": ("a repo marking no test that way, where `pytest` exits 5 for "
                         "'no tests collected' and it was propagated as a gate failure with "
                         "coverage comfortably above the watermark (aequitas_os)"),
    },
    "closing_schema": {
        "queue_job": "the classic contract: a ```json queue-job``` block plus `verification_command`",
        "close_check": ("the canon's spelling, `close_check: {cmd, expect}`, which convicted all 21 "
                        "CANON-*.md entries until it was accepted as equivalent"),
    },
}

# Values NOT exercised here, each with the reason. Anything at zero and absent
# from this table blocks: that is the whole mechanism.
NOT_EXERCISED: dict[str, str] = {
    "product_language:non_python": (
        "no fixture in this repo builds a Rust or TypeScript product, so the gates typed "
        "`python` are exercised only against Python sources. Tracked as "
        "DEBT-KIT-ASSUMES-PYTHON; the ticket records that a longer whitelist is NOT the fix, "
        "so a fixture that merely adds one language would be modelling the wrong thing"
    ),
}


def _marked_values(tests_dir: Path) -> tuple[dict[str, int], list[str]]:
    """Count `@pytest.mark.shape("dim:value")` occurrences, and NAME what it could not read.

    Parsed rather than searched on purpose: a string in a docstring or a fixture
    is not a marker, and this repo spent 2026-09-02 fixing three places where a
    reader grepped where another parsed.

    The unreadable files come back with the counts because a count over an
    unknown denominator is not a measurement. A file that will not parse is
    skipped -- the matrix must not fall over because one test file is broken --
    but it is skipped OUT LOUD. Caught by this repo's own `silent_io_loop_swallow`
    detector on this very function, in the commit that introduced it.
    """
    counts: dict[str, int] = defaultdict(int)
    unreadable: list[str] = []
    for path in sorted(tests_dir.rglob("test_*.py")):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (OSError, SyntaxError) as exc:
            unreadable.append(f"{path.name}: {type(exc).__name__}: {exc}")
            continue
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for dec in node.decorator_list:
                if not isinstance(dec, ast.Call):
                    continue
                func = dec.func
                if not (isinstance(func, ast.Attribute) and func.attr == MARKER):
                    continue
                for arg in dec.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        counts[arg.value] += 1
    return dict(counts), unreadable


def report(root: Path) -> tuple[list[str], dict[str, int], list[str]]:
    """Every declared value with its count, the ones at zero that block, and the
    test files that could not be read at all."""
    counts, unreadable = _marked_values(root / "tests")
    blocking = []
    for dimension, values in SHAPES.items():
        for value in values:
            key = f"{dimension}:{value}"
            if counts.get(key, 0) == 0 and key not in NOT_EXERCISED:
                blocking.append(key)
    return blocking, counts, unreadable


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Which consumer shapes the suite actually exercises")
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--gate", action="store_true", help="Exit 1 on a declared shape with zero tests")
    args = parser.parse_args(argv)

    root = args.root.resolve()
    blocking, counts, unreadable = report(root)
    print("[shapes] consumer shapes this suite exercises (zeros included):")
    for dimension, values in SHAPES.items():
        for value in values:
            key = f"{dimension}:{value}"
            n = counts.get(key, 0)
            mark = "🟢" if n else ("🟡" if key in NOT_EXERCISED else "🔴")
            print(f"  {mark} {key:<34} {n} test(s)")
    for key, reason in NOT_EXERCISED.items():
        print(f"  🟡 {key:<34} 0 test(s) -- DECLARED: {reason}")
    print(f"[shapes] test files read: {len(list((root / 'tests').rglob('test_*.py'))) - len(unreadable)}"
          f" · unreadable: {len(unreadable)}")
    for row in unreadable:
        print(f"  ? {row}")
    unknown = sorted(k for k in counts if k not in
                     {f"{d}:{v}" for d, vs in SHAPES.items() for v in vs})
    if unknown:
        print(f"[shapes] marked but not declared in SHAPES: {unknown}")
    if blocking:
        print(f"[shapes] BLOCKED: {len(blocking)} declared shape(s) with no test and no reason: {blocking}")
        print("  Add a test that exercises it, or declare it in NOT_EXERCISED with why.")
        print(
            f"[consumer-shapes] FAIL: {len(blocking)} declared shape(s) with zero tests "
            f"and no declared NOT_EXERCISED reason; first: {blocking[0]}"
        )
        return 1 if args.gate else 0
    print("[shapes] OK: every declared shape is exercised or declared unexercised with a reason.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
