# -*- coding: utf-8 -*-
"""fleet_telemetry.py -- what each organ has actually CAUGHT, across every repo.

Why this exists, and it is one specific hole rather than a general wish.

`gate_effectiveness` lets a repo declare that a mute organ has no case it could
ever catch there (`.simplecode/organ_inapplicable.json`), and `_refutadas`
exists to make that claim falsifiable. It refutes with the SUBJECT's own
telemetry: an organ that has blocked, found something, or caught a planted
control demonstrably has work to do.

The cuenza session broke it within an hour of receiving it, 2026-09-05, and the
break is structural rather than a slip. **A blind organ has zero blocks, zero
findings and zero canaries BY DEFINITION.** So the refuter works exactly where
it is not needed -- a productive organ -- and is blind exactly where it is:
mould (a). They declared `truncation_guard` inapplicable in cuenza with a reason
that read, literally, "AFIRMACION FALSA: es el ataque", and it was accepted --
while that same organ, same wiring, had 490 runs with 7 real catches in
simplecode.

I caught their attack by hand, and the way I caught it is the whole design here:
I went and looked at ANOTHER repo's numbers. That is the only falsifier anyone
has found for "no case exists here", and both cuenza and o2o arrived at the same
formulation independently.

WHAT THIS DOES **NOT** PROVE, stated first because it is the part that would
otherwise be overclaimed. Fleet evidence does NOT prove a case exists in a given
repo. `version_bump` catches constantly in simplecode (180 runs, 80 blocks) and
genuinely has nothing to catch in a satellite that does not version itself --
that declaration is honest and fleet evidence must not overturn it. Meanwhile
`truncation_guard` catches in simplecode and its subject IS reachable in cuenza,
so the identical evidence shape means the opposite thing.

So a fleet catch is not an automatic refutation. What it does is convert a bare
assertion into a claim that must answer a named counterexample: the declaration
has to say WHY this repo differs from the repos where the organ demonstrably
fires. A declaration that cannot answer that is refused; one that answers it is
printed with the counterexample beside it, so a reader can judge the answer
instead of taking it.

Read-only. It opens each repo's `.simplecode/evidence/telemetry.jsonl` and
writes one index here. It never writes into another repo.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io
from simplecode.verification import gate_effectiveness as ge

INDEX_RELPATH = Path(".simplecode") / "fleet_telemetry.json"
CATALOG_RELPATH = Path(".simplecode") / "fleet_catalog.json"
TELEMETRY_RELPATH = Path(".simplecode") / "evidence" / "telemetry.jsonl"


def _repos_del_catalogo(root: Path) -> tuple[list[tuple[str, Path]], str]:
    """(name, path) per fleet repo, plus a note, or ([], why-not).

    The catalog is read rather than the filesystem globbed: a directory under
    `~/projects` is not necessarily a fleet repo, and inventing membership is
    how a report starts describing a fleet nobody declared.
    """
    path = root / CATALOG_RELPATH
    if not path.is_file():
        return [], f"no {CATALOG_RELPATH.as_posix()}; nothing to harvest"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        proyectos = list(data["projects"])
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return [], (f"COULD_NOT_RUN: {CATALOG_RELPATH.as_posix()} is unreadable "
                    f"or has no `projects` ({exc})")
    salida: list[tuple[str, Path]] = []
    for p in proyectos:
        if isinstance(p, dict) and p.get("name") and p.get("path"):
            salida.append((str(p["name"]), Path(str(p["path"]))))
    return salida, f"{len(salida)} repo(s) declared in the catalog"


def cosechar(root: Path) -> dict[str, Any]:
    """Read every fleet repo's telemetry and index it per organ.

    `leer_estado` does the parsing -- the same function `gate_effectiveness`
    uses on its own file, so a row counts here exactly as it counts there. A
    second parser would drift, and a drifting denominator is how two organs
    end up disagreeing while both stay green.
    """
    repos, nota = _repos_del_catalogo(root)
    # `int | bool | None`, not `int`: the counters are ints, `cableado` is a
    # tri-state (wired / not wired / could not read that repo's hook config)
    # and collapsing its None into a bool would print "not wired there" for a
    # repo whose config was simply unreadable.
    organos: dict[str, dict[str, dict[str, int | bool | None]]] = {}
    leidos: list[str] = []
    ausentes: list[str] = []
    ilegibles: list[str] = []

    for nombre, ruta in repos:
        telemetria = ruta / TELEMETRY_RELPATH
        if not telemetria.is_file():
            # Absent is not empty. A repo with no telemetry has never run the
            # kit's gates; counting it as "zero catches everywhere" would let
            # an unadopted repo dilute every organ's evidence.
            ausentes.append(nombre)
            continue
        try:
            # Attributed to the repo that OWNS the row, not to the file it sits
            # in. declutter's ledger carries 4,371 seeded rows of simplecode's
            # history from the day it was adopted; without this the index would
            # credit declutter with runs and catches that happened here.
            #
            # Conditional for the same reason as in `gate_effectiveness`: an
            # unconditional filter empties a ledger whose rows carry a name
            # that is not the directory's -- a renamed repo, or a fixture --
            # and an index that silently reports nothing is worse than one that
            # reports a known-imperfect something.
            poblacion = ge.repos_en_el_archivo(telemetria)
            solo = nombre if len(poblacion) > 1 and nombre in poblacion else None
            estado = ge.leer_estado(telemetria, solo_repo=solo)
        except OSError as exc:
            ilegibles.append(f"{nombre}: {exc}")
            continue
        leidos.append(nombre)
        cableados = ge._modulos_cableados(ruta)
        for organo, c in estado.corridas.items():
            fila = organos.setdefault(organo, {})
            fila[nombre] = {
                "corridas": int(c["corridas"]),
                "bloqueos_reales": int(c["bloqueos_reales"]),
                "hallazgos": int(c["hallazgos"]),
                "controles": int(c["controles"]),
                # None means "could not read that repo's hook config", which is
                # not the same as "not wired there" and must not print as it.
                "cableado": None if cableados is None else organo in cableados,
            }

    return {
        "generated": datetime.now(timezone.utc).isoformat(),
        "catalog_note": nota,
        "repos_read": sorted(leidos),
        "repos_without_telemetry": sorted(ausentes),
        "repos_unreadable": sorted(ilegibles),
        "organs": organos,
    }


def cargar(root: Path) -> tuple[dict[str, Any], str]:
    """The harvested index and a note, or ({}, why-not).

    Absent or malformed both mean NO fleet evidence, and the caller must treat
    that as "unknown", never as "this organ catches nowhere". An index that
    could not be read is the loudest possible reason not to conclude anything
    from its silence.
    """
    path = root / INDEX_RELPATH
    if not path.is_file():
        return {}, (f"no {INDEX_RELPATH.as_posix()}; fleet evidence unavailable "
                    f"(run `python -m simplecode.verification.fleet_telemetry --harvest`)")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        organs = dict(data["organs"])
        leidos = list(data["repos_read"])
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return {}, (f"COULD_NOT_RUN: {INDEX_RELPATH.as_posix()} is unreadable or "
                    f"incomplete ({exc}); fleet evidence unavailable")
    if not leidos:
        return {}, f"{INDEX_RELPATH.as_posix()} read 0 repos; fleet evidence unavailable"
    return (
        {"organs": organs, "repos_read": leidos, "generated": str(data.get("generated", ""))},
        f"fleet evidence from {len(leidos)} repo(s), harvested {data.get('generated', '?')}",
    )


def capturas_ajenas(indice: dict[str, Any], organo: str, este_repo: str) -> list[str]:
    """Repos OTHER than this one where `organo` demonstrably caught something.

    "Caught" is `bloqueos_reales` or `controles`, never `hallazgos` on its own:
    until 2026-09-05 `gate_runner` fabricated `hallazgos` as `int(rc != 0)`, so
    every historical row's value is a copy of the block bit. Counting it as an
    independent signal here would double-count the same event and make the
    evidence look twice as strong as it is.
    """
    filas = dict(indice.get("organs", {})).get(organo, {})
    testigos = []
    for repo, c in sorted(filas.items()):
        if repo == este_repo:
            continue
        reales = int(c.get("bloqueos_reales", 0))
        controles = int(c.get("controles", 0))
        if reales or controles:
            testigos.append(
                f"{repo} ({c.get('corridas', 0)} runs, {reales} real block(s), "
                f"{controles} planted control(s))"
            )
    return testigos


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--harvest", action="store_true",
                    help="read every fleet repo's telemetry and write the index")
    ap.add_argument("--organ", help="print what this organ has caught fleet-wide")
    args = ap.parse_args(argv)
    root = args.root.resolve()

    if args.harvest:
        indice = cosechar(root)
        destino = root / INDEX_RELPATH
        destino.parent.mkdir(parents=True, exist_ok=True)
        atomic_io.write_text_durable(
            destino, json.dumps(indice, indent=2, ensure_ascii=False) + "\n")
        # The zeros print. A harvest that read 3 of 22 repos and said only
        # "harvested" would be describing itself, not the fleet.
        print(f"[fleet-telemetry] {indice['catalog_note']}")
        print(f"[fleet-telemetry] repos read: {len(indice['repos_read'])} · "
              f"without telemetry: {len(indice['repos_without_telemetry'])} · "
              f"unreadable: {len(indice['repos_unreadable'])}")
        for nombre in indice["repos_without_telemetry"]:
            print(f"  ~ {nombre}: no telemetry -- never ran the kit's gates, "
                  f"NOT 'zero catches'")
        for linea in indice["repos_unreadable"]:
            print(f"  ?? COULD_NOT_RUN {linea}")
        print(f"[fleet-telemetry] organs indexed: {len(indice['organs'])} -> {destino}")
        return 0

    indice, nota = cargar(root)
    print(f"[fleet-telemetry] {nota}")
    if not indice:
        return 0
    if args.organ:
        testigos = capturas_ajenas(indice, args.organ, root.name)
        print(f"[fleet-telemetry] {args.organ}: caught something in "
              f"{len(testigos)} other repo(s)")
        for t in testigos:
            print(f"  + {t}")
        return 0

    filas = []
    for organo, repos in indice["organs"].items():
        testigos = capturas_ajenas(indice, organo, root.name)
        total = sum(int(c.get("bloqueos_reales", 0)) for c in repos.values())
        filas.append((len(testigos), total, organo, len(repos)))
    print(f"{'organo':32} {'repos':>6} {'catching':>9} {'blocks':>8}")
    for testigos, total, organo, n_repos in sorted(filas, reverse=True):
        print(f"{organo:32} {n_repos:>6} {testigos:>9} {total:>8}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
