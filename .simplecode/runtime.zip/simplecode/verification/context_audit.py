"""Fail only demonstrably broken local context references and commands."""
from __future__ import annotations

import argparse
import importlib.util
import re
from pathlib import Path

from simplecode import profiles

DOC_NAMES = {"AGENTS.md", "CLAUDE.md", "CONTEXT.md", "README.md", "SPEC.md"}
STANDARD_CONTEXT_DIRS = (Path("."), Path("docs"), Path(".agents"), Path(".claude"), Path(".codex"))
LINK = re.compile(r"\[[^]]*\]\(([^)#]+)(?:#[^)]*)?\)")
MODULE = re.compile(r"\bpython(?:3)?\s+-m\s+(simplecode(?:\.[A-Za-z_][\w]*)+)")


def context_files(root: Path) -> list[Path]:
    """Read conventional context homes, never arbitrary project documentation."""
    files: set[Path] = set()
    for relative in STANDARD_CONTEXT_DIRS:
        directory = root / relative
        if directory.is_dir():
            candidates = directory.glob("*.md") if relative == Path(".") else directory.rglob("*.md")
            files.update(p for p in candidates if p.name in DOC_NAMES)
    return sorted(files)


def findings(root: Path) -> tuple[list[str], list[str]]:
    bad: list[str] = []
    unreadable: list[str] = []
    for document in context_files(root):
        try:
            text = document.read_text(encoding="utf-8")
        except OSError:
            unreadable.append(str(document.relative_to(root)))
            continue
        rel = document.relative_to(root)
        for target in LINK.findall(text):
            if "://" not in target and not target.startswith("mailto:") and not (document.parent / target).exists():
                bad.append(f"{rel}: missing local link {target}")
        for module in MODULE.findall(text):
            if importlib.util.find_spec(module) is None:
                bad.append(f"{rel}: unavailable command module {module}")
    return bad, unreadable


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--gate", action="store_true")
    args = parser.parse_args(argv)
    root = args.root.resolve()
    active, error = profiles.enabled(root, "context")
    if error:
        print(f"[context-audit] COULD_NOT_RUN: {error}")
        return 2
    if not active:
        print("[context-audit] context profile disabled")
        return 0
    bad, unreadable = findings(root)
    print(f"[context-audit] checked={len(context_files(root))} failed={len(bad)} could_not_run={len(unreadable)}")
    for finding in bad:
        print(f"  FAIL {finding}")
    for item in unreadable:
        print(f"  COULD_NOT_RUN {item}")
    return 1 if args.gate and (bad or unreadable) else 0
