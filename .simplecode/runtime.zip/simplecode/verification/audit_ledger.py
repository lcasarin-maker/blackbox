# -*- coding: utf-8 -*-
"""audit_ledger.py -- Adversarial Audit Ledger (ADR-0006, H1 form b).

simplecode owns the deterministic, offline parts of the adversarial-audit loop:
claim extraction, a claims-sealed ledger, and a completeness+evidence+green gate.
The agent-driven adversarial panel itself lives in the harness/operator; it writes
a ledger here and this module verifies it.

WHAT THIS GATE PROVES -- and what it does NOT
---------------------------------------------
`--gate` passes only when a ledger exists that agrees with the current CLAIM SET
(SPEC.md plus every Accepted ADR and the active contract), has a result for every
claim, carries evidence on every result, and carries no violations. That is:
SEALED AGAINST THE CLAIMS, COMPLETE (every claim audited), EVIDENCED, and GREEN
(no violations).

Since 2026-09-27 each claim is ALSO sealed with the content of every file it or
its evidence cites (``claim_seal``): a code change stales exactly the claims about
that code, ``--stale`` lists them, and ``--record --merge`` re-seals only those.
Measured that day, the old whole-set text seal had kept a 2026-09-17 ledger
"fresh" across 13 releases while 36 of its 60 claims had become false.

The TREE the verdicts were taken against is recorded and printed as PROVENANCE;
it gates nothing (amended 2026-09-15, see ADR-0006). It used to: the ledger had
to match the current working tree exactly, so every commit broke the seal and the
only way through was a refresh commit copying the previous verdicts verbatim.
Measured: 38 of 38 refreshes since 2026-08-20 were verbatim copies, 49 such
commits in simplecode since 2026-09-01, and 27 (simplecode) + 20 (Atlas) push
attempts were lost to that and nothing else. A gate whose only affordable escape
is a verbatim copy teaches the copy, not the audit.

It does NOT -- and cannot -- prove that the audit behind the ledger was genuinely
adversarial or independent. The ledger is FORGEABLE: an actor can write
"0 violations" for every claim without running a real panel, and this module
would accept it. This is the honest limit of form (b) (see ADR-0006). The gate
raises the bar (you must produce a complete, per-claim, evidenced ledger matching
these exact claims), and H3 converts each real finding into an unforgeable
deterministic detector, shrinking the space the ledger must be trusted for. Since
the tree no longer gates, the ledger does not by itself force anyone to look at
the code delta between the audit and the push -- H2/H3 watch the code; a
"block after N commits" threshold is a separate decision, not taken.
The limitation is stated, not hidden -- a gate with a blind spot must say so.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io

LEDGER_RELPATH = Path(".simplecode") / "audit_ledger.json"
SPEC_RELPATH = Path("SPEC.md")
ADR_DIRPATH = Path("docs") / "adr"
REDESIGN_RELPATH = Path("docs") / "REDESIGN_KIT_V2.md"

# Every path ``governing_claims`` reads to build the claim set, named ONCE so
# that a caller which has to reconstruct that claim set from somewhere other
# than the working tree (``verify_audit_fresh_at_commit``, reading a git
# commit) extracts exactly the paths the extractor will then look for. A second
# hand-kept list would drift the moment a governing document is added, and the
# drift would be invisible: the at-commit claim set would quietly omit the new
# document and the two gates would disagree about what H1 must cover.
GOVERNING_RELPATHS = (SPEC_RELPATH, ADR_DIRPATH, REDESIGN_RELPATH)

# Verdicts of ``verify_audit_fresh_at_commit`` and ``release_audit_status``.
# "green", "blocked" and "I could not determine what the ledger said" are THREE
# facts, and the bool these functions used to return had to spend one of them --
# spending the third is how an unknown gets reported as a pass.
#
# STRINGS, and not the 0/1/2 return codes they map onto, for a reason measured
# while making this change (2026-09-15). With integer verdicts, a caller or test
# stub left over from the bool contract returns ``False`` -- and ``False == 0``
# in Python, so ``False`` IS the OK verdict: two stubs in
# ``tests/test_version_bump.py`` returning ``(False, [reasons])`` to mean
# "blocked" silently turned their gate green, which is a gate passing for the
# wrong reason. A string verdict cannot collide with ``False``/``True``/``0``, so
# a stale bool matches no known verdict and the mapping below fails CLOSED
# (blocks) instead of open -- the same adversarial posture ``_PASS_VERDICTS``
# already takes for a panel's unrecognized verdict word.
AUDIT_OK = "OK"
AUDIT_BLOCKED = "BLOCKED"
AUDIT_COULD_NOT_RUN = "COULD_NOT_RUN"

# How bad each verdict is, so a caller judging SEVERAL subjects (one per release
# commit in a push) can keep the worst without hardcoding an order.
_AUDIT_SEVERITY = {AUDIT_OK: 0, AUDIT_BLOCKED: 1, AUDIT_COULD_NOT_RUN: 2}

# Process exit code per verdict. COULD_NOT_RUN is 2 everywhere in this kit, and
# an UNRECOGNIZED verdict is 1 (blocked), never 0: see the note above.
AUDIT_EXIT_CODES = {AUDIT_OK: 0, AUDIT_BLOCKED: 1, AUDIT_COULD_NOT_RUN: 2}


def audit_verdict_worse(left: str, right: str) -> str:
    """Whichever of two verdicts is worse; an unknown verdict word is BLOCKED.

    Fails closed on a verdict this module does not recognize rather than sorting
    it as harmless -- an unrecognized verdict is an unread instrument, and the
    stale-``False`` collision this vocabulary exists to prevent arrives exactly
    as an unrecognized value.
    """
    lo = _AUDIT_SEVERITY.get(left, _AUDIT_SEVERITY[AUDIT_BLOCKED])
    ro = _AUDIT_SEVERITY.get(right, _AUDIT_SEVERITY[AUDIT_BLOCKED])
    return left if lo >= ro else right

# Sentinel returned by tree_fingerprint when git cannot be consulted. It is
# recorded in the ledger as the honest value of an unobtainable provenance --
# it no longer blocks the gate, because the tree no longer gates (2026-09-15).
GIT_UNAVAILABLE = "GIT_UNAVAILABLE"

# Also accept the vocabulary the adversarial panels in this repo actually use
# (V1-V3 audits, the dogfood self-audit): a panel that says CONFIRMED means the
# claim held. Silently mapping an unrecognized-but-legitimate verdict word to
# "violation" is itself a false conviction -- normalize known synonyms instead
# of trusting every panel to speak the ledger's exact four words.
_PASS_SYNONYMS = frozenset({"confirmed", "supported", "verified"})

# Verdict strings that count as passing; ANY other verdict (including unknown
# ones) is treated as a violation -- fail closed, the adversarial posture.
_PASS_VERDICTS = frozenset({"pass", "green", "ok", "clean"})

# A boundary/interface bullet shorter than this is treated as too thin to be an
# auditable claim ("with substance"). The same bar is applied to a result's
# ``evidence`` -- same question, same answer, one constant.
#
# Measured 2026-09-01, and the reason this bar exists at all: a ledger carrying
# a PASS for all 59 claims with `evidence: ""` on every one, from a panel named
# "panel-que-no-existio", passed `verify_audit_fresh` with ok=True and zero
# reasons. The module's own docstring promised an "evidenced" ledger; nothing
# enforced it. 30 rather than the observed floor of 70: real panel evidence runs
# 70..660 chars (median 255), so 30 leaves 2.3x headroom and still kills every
# vacuous form ("", "ok", "PASS", "n/a", "-"). A bar set AT the observed minimum
# is a ratchet with no margin -- it convicts the next honest short answer.
_MIN_BULLET_LEN = 30

_CHECKBOX = re.compile(r"^\s*-\s*\[[ xX]\]\s+(.+\S)\s*$")
_AXIOM = re.compile(r"^\s*\d+\.\s+\*\*(.+\S)\s*$")
_BULLET = re.compile(r"^\s*[-*]\s+(.+\S)\s*$")


@dataclass(frozen=True)
class Claim:
    """One auditable claim extracted from SPEC.md, with a line-anchored stable id."""

    id: str
    section: str
    text: str


@dataclass
class AuditLedger:
    """An adversarial audit panel's per-claim verdicts, sealed against the claim
    set it audited. ``tree_fingerprint`` records WHICH tree the panel read; it is
    provenance the gate prints, not a condition the gate enforces."""

    tree_fingerprint: str
    claims_fingerprint: str
    timestamp: str
    panel: str
    profile: str = "general"
    results: list[dict[str, Any]] = field(default_factory=list)
    violations: list[dict[str, Any]] = field(default_factory=list)

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True, indent=2)

    @classmethod
    def from_json(cls, text: str) -> AuditLedger:
        data = json.loads(text)
        return cls(
            tree_fingerprint=str(data.get("tree_fingerprint", "")),
            claims_fingerprint=str(data.get("claims_fingerprint", "")),
            timestamp=str(data.get("timestamp", "")),
            panel=str(data.get("panel", "")),
            profile=str(data.get("profile", "general")),
            results=list(data.get("results", [])),
            violations=list(data.get("violations", [])),
        )


def _norm(text: str) -> str:
    """Normalize claim text: drop bold markers, collapse whitespace."""
    return re.sub(r"\s+", " ", text.replace("**", "")).strip()


def _is_table_separator(stripped: str) -> bool:
    """A markdown table separator row (``|---|:--:|``), not a data row."""
    body = stripped.strip("|")
    return "-" in body and set(body) <= set("-: |")


def _line_claim_text(raw: str, section: str) -> str | None:
    """Return the normalized claim text of a checkbox / axiom / boundary bullet
    line, or None if the line is not one of those claim shapes."""
    checkbox = _CHECKBOX.match(raw)
    if checkbox:
        return _norm(checkbox.group(1))
    axiom = _AXIOM.match(raw)
    if axiom:
        return _norm(axiom.group(1))
    section_lower = section.lower()
    if "boundar" in section_lower or "interface" in section_lower:
        bullet = _BULLET.match(raw)
        if bullet:
            content = _norm(bullet.group(1))
            if len(content) >= _MIN_BULLET_LEN:
                return content
    return None


def extract_claims(spec_path: Path) -> list[Claim]:
    """Deterministically extract auditable claims from SPEC.md.

    A claim is one of:
      * a checkbox line (``- [ ]`` / ``- [x]``) in any section,
      * a numbered axiom (``N. **...**``) in any section,
      * a data row of a table in a section whose heading mentions "risk",
      * a boundary/interface bullet with substance (a ``-``/``*`` bullet, at
        least ``_MIN_BULLET_LEN`` chars after normalization, in a section whose
        heading mentions "boundar" or "interface").

    Each claim gets a stable line-anchored id ``SPEC-L<lineno>`` (1-based). The
    order follows the file, so extraction is fully deterministic.
    """
    claims: list[Claim] = []
    section = ""
    in_table_body = False
    # SPEC is a governing input. Treating a read error as an empty set would
    # let an ADR-only ledger pass while the contract is missing or unreadable.
    text = spec_path.read_text(encoding="utf-8")

    for lineno, raw in enumerate(text.splitlines(), start=1):
        stripped = raw.strip()

        if stripped.startswith("#"):
            section = stripped.lstrip("#").strip()
            in_table_body = False
            continue

        if "risk" in section.lower() and stripped.startswith("|"):
            if _is_table_separator(stripped):
                in_table_body = True
            elif in_table_body:
                claims.append(Claim(f"SPEC-L{lineno}", section, _norm(stripped.strip("|"))))
            continue
        in_table_body = False

        text_claim = _line_claim_text(raw, section)
        if text_claim is not None:
            claims.append(Claim(f"SPEC-L{lineno}", section, text_claim))

    return claims


def _spec_claims(root: Path, errors: list[str] | None) -> list[Claim]:
    try:
        return extract_claims(root / SPEC_RELPATH)
    except OSError as exc:
        message = f"cannot read governing SPEC {root / SPEC_RELPATH}: {exc}"
        if errors is None:
            raise
        errors.append(message)
        return []


def _governing_adr_paths(root: Path, errors: list[str] | None) -> list[Path]:
    adr_dir = root / ADR_DIRPATH
    try:
        with os.scandir(adr_dir) as entries:
            return sorted(
                (adr_dir / entry.name for entry in entries
                 if entry.is_file() and re.fullmatch(r"[0-9]{4}-.+\.md", entry.name)),
                key=lambda path: path.name,
            )
    except FileNotFoundError:
        return []
    except OSError as exc:
        message = f"cannot enumerate governing ADR directory {adr_dir}: {exc}"
        if errors is None:
            print(f"[audit] COULD_NOT_RUN: {message}", file=sys.stderr)
        else:
            errors.append(message)
        return []


def governing_claims(root: Path, errors: list[str] | None = None) -> list[Claim]:
    """SPEC claims plus the governing documents whose decisions constrain it.

    Each accepted ADR and the active redesign contract is one auditable claim.
    Treating the whole document as the claim prevents H1 from certifying SPEC
    while silently omitting a contradictory architectural decision.
    """
    claims = _spec_claims(root, errors)
    for path in _governing_adr_paths(root, errors):
        try:
            content = path.read_text(encoding="utf-8")
        except OSError as exc:
            message = f"cannot read governing ADR {path}: {exc}"
            if errors is None:
                print(f"[audit] COULD_NOT_RUN: {message}", file=sys.stderr)
            else:
                errors.append(message)
            continue
        if "**Status**: Accepted" in content:
            claims.append(Claim(f"ADR-{path.stem}", "Accepted architectural decisions", _norm(content)))
    redesign = root / REDESIGN_RELPATH
    if redesign.is_file():
        try:
            content = redesign.read_text(encoding="utf-8")
        except OSError as exc:
            message = f"cannot read redesign contract {redesign}: {exc}"
            if errors is None:
                print(f"[audit] COULD_NOT_RUN: {message}", file=sys.stderr)
            else:
                errors.append(message)
            content = None
        if content is not None:
            claims.append(Claim("CONTRACT-REDESIGN-KIT-V2", "Active migration contract", _norm(content)))
    return claims


def claims_fingerprint(claims: list[Claim]) -> str:
    """SHA-256 over the ordered ``(id, text)`` pairs of the claim set.

    Auditor and gate compute this from the same SPEC so neither can quietly
    disagree about which claims must be audited.
    """
    hasher = hashlib.sha256()
    for claim in claims:
        hasher.update(claim.id.encode("utf-8"))
        hasher.update(b"\x1f")
        hasher.update(claim.text.encode("utf-8"))
        hasher.update(b"\x1e")
    return hasher.hexdigest()


# Per-claim seal (Luis 2026-09-27, "que no quede stale"). The whole-set text
# fingerprint above sealed WHAT the claims say, never the code they describe:
# measured 2026-09-27, the 2026-09-17 ledger kept the same claims fingerprint
# across 13 releases (7.4.1..8.7.1) and ~160 commits, so `version-bump` passed
# 40 times on verdicts nobody re-took. A claim is now sealed with its own text
# AND the content of every file it cites, so changing `corruption_guard.py`
# stales exactly the claims that talk about it -- and only those need a re-audit.
#
# Excluded from the citable universe: tool state and the files a release commit
# itself rewrites (version lines, the kit bundle, the governing documents whose
# text is already in the seal). Citing them would make every bump stale its own
# ledger, the circularity that killed the tree seal on 2026-09-15.
_UNCITABLE_DIRS = frozenset({
    ".git", ".simplecode", ".venv", "venv", "node_modules", "__pycache__",
    ".claude", "build", "dist", ".mypy_cache", ".pytest_cache", ".ruff_cache",
})
_UNCITABLE_FILES = frozenset({"pyproject.toml", "VERSION.txt", "CHANGELOG.md"})
_CITABLE_SUFFIXES = frozenset({".py", ".sh", ".yaml", ".yml", ".toml", ".json", ".cfg", ".ini"})
_PATH_TOKEN = re.compile(r"[A-Za-z0-9_./-]+\.(?:py|sh|ya?ml|toml|json|cfg|ini)\b")
_NAME_TOKEN = re.compile(r"`([A-Za-z_][A-Za-z0-9_.-]*)`")


def _citable_index(root: Path) -> dict[str, list[str]]:
    """``{relpath: [relpath]}`` plus ``{stem: [relpaths]}`` over the citable files."""
    index: dict[str, list[str]] = {}
    governing = {str(rp) for rp in GOVERNING_RELPATHS}
    for path in sorted(root.rglob("*")):
        rel_parts = path.relative_to(root).parts
        if (not path.is_file() or path.suffix not in _CITABLE_SUFFIXES
                or _UNCITABLE_DIRS & set(rel_parts) or any(p.endswith(".egg-info") for p in rel_parts)):
            continue
        rel = path.relative_to(root).as_posix()
        if rel in _UNCITABLE_FILES or any(rel == g or rel.startswith(g + "/") for g in governing):
            continue
        index.setdefault(rel, []).append(rel)
        index.setdefault(path.stem, []).append(rel)
    return index


def cited_files(claim: Claim, index: dict[str, list[str]], evidence: str = "") -> list[str]:
    """The repo files ``claim`` names, plus those its audit ``evidence`` names:
    explicit paths, and backticked module or file names (`zero_debt`,
    `simplecode.verification.version_bump`) resolved against ``index``. A name
    matching several files cites all of them -- a claim about `cli` is about
    every `cli.py` it could mean.

    The evidence counts because 17 of the 60 claims measured 2026-09-27 name no
    file in their own text (risk-table rows, principles); the auditor's
    `file.py:line` anchors are what tie those verdicts to code."""
    text = f"{claim.text}\n{evidence}"
    found: set[str] = set()
    for token in _PATH_TOKEN.findall(text):
        token = token.removeprefix("./")
        found.update(rel for rel in index.get(Path(token).stem, []) if rel.endswith(token))
    for name in _NAME_TOKEN.findall(text):
        found.update(index.get(name, index.get(name.rsplit(".", 1)[-1], [])))
    return sorted(found)


# A MINOR/MAJOR release re-dates every `# sunset-reviewed: X.Y` tag in the tree
# (`sunset_redate`, required by ADR-0013), and those tags live in cited files.
# Measured 2026-09-28: the 8.9.0 bump re-dated 92 lines and staled 22 of 61
# claims, so the release could not carry its own ledger. The version inside a
# sunset tag is release bookkeeping, not the behaviour a claim describes.
_SUNSET_TAG_VERSION = re.compile(rb"(sunset-reviewed:\s*)\d+\.\d+")


def _sealed_digest(path: Path) -> str:
    """sha256 of ``path`` with sunset-tag versions blanked (see above)."""
    return hashlib.sha256(_SUNSET_TAG_VERSION.sub(rb"\1<v>", path.read_bytes())).hexdigest()


def claim_seal(
    root: Path, claim: Claim, index: dict[str, list[str]], evidence: str = ""
) -> tuple[str, dict[str, str]]:
    """``(seal, {cited relpath: sha256})`` for one claim at ``root``."""
    files = {rel: _sealed_digest(root / rel) for rel in cited_files(claim, index, evidence)}
    hasher = hashlib.sha256(f"{claim.id}\x1f{claim.text}".encode("utf-8"))
    for rel, digest in files.items():
        hasher.update(f"\x1e{rel}\x1f{digest}".encode("utf-8"))
    return hasher.hexdigest(), files


# Evidence that names nothing checkable, or that is the same sentence stamped on
# several claims, is a template, not an audit. Measured 2026-09-27: the
# 2026-09-17 ledger carried "Verified implementation and tests for claim <id>"
# on all 60 claims -- 50 chars, over the 30-char floor, and the gate took it.
_EVIDENCE_ANCHOR = re.compile(r"[\w/-]+\.(?:py|md|sh|ya?ml|toml|json)\b|`[^`]{3,}`|:\d+\b")


def _template_evidence(results: list[dict[str, Any]]) -> list[str]:
    """claim ids whose evidence is unanchored or shared with another claim."""
    rows = [r for r in results if isinstance(r, dict) and isinstance(r.get("evidence"), str)]
    shapes: dict[str, list[str]] = {}
    for r in rows:
        cid = str(r.get("claim_id", "?"))
        shapes.setdefault(" ".join(r["evidence"].replace(cid, "<id>").split()), []).append(cid)
    flagged = {cid for ids in shapes.values() if len(ids) > 1 for cid in ids}
    flagged |= {str(r.get("claim_id", "?")) for r in rows if not _EVIDENCE_ANCHOR.search(r["evidence"])}
    return sorted(flagged)


def _run_git(root: Path, args: list[str]) -> tuple[int, str] | None:
    """Run a git command under ``root``; return (returncode, stdout) or None.

    None means git could not be invoked at all (binary missing / OS error) --
    distinct from a nonzero return, so a clean (empty-output) status is not
    confused with git being unavailable.
    """
    try:
        res = subprocess.run(
            ["git", "-C", str(root), *args],
            capture_output=True,
            text=True,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return res.returncode, res.stdout


def _committed_tree_fingerprint(root: Path) -> str:
    """Fingerprint of what HEAD commits, excluding ``.simplecode/`` entries.

    Deliberately NOT ``git rev-parse HEAD^{tree}``: that oid covers the whole
    tree, including any ``.simplecode/`` path a project happens to track
    (e.g. the negated gitignore entries for tombstones.yaml/fork_own.json,
    or a project that tracks audit_ledger.json itself). A ledger written to
    describe "the tree after this commit" would then depend on its own future
    blob hash -- a preimage-style circular reference no commit can satisfy
    (reported live from declutter, 2026-08-31: two consecutive --record +
    commit/--amend attempts each produced a fresh, different, still-stale
    fingerprint). Listing entries and dropping ``.simplecode/*`` before
    hashing makes the fingerprint insensitive to that directory's own
    contents, matching the exclusion this function already applies to the
    working-tree status below.
    """
    listing = _run_git(root, ["ls-tree", "-r", "HEAD"])
    if listing is None or listing[0] != 0:
        return "NO_HEAD"
    kept_lines = [
        line for line in listing[1].splitlines()
        if "\t" in line and not line.split("\t", 1)[1].startswith(".simplecode/")
    ]
    return hashlib.sha256("\n".join(kept_lines).encode("utf-8")).hexdigest()


def tree_fingerprint(root: Path) -> str:
    """Fingerprint of the CURRENT working tree, using cheap git objects.

    Covers two things, so any change a commit would capture -- and any
    uncommitted change -- moves the fingerprint:
      * the tree that HEAD commits, minus ``.simplecode/`` entries (see
        ``_committed_tree_fingerprint``), or the marker ``NO_HEAD`` before
        the first commit exists, and
      * the porcelain status (``git status --porcelain=v1 -z``), which reflects
        staged, unstaged, and untracked deviations from HEAD.

    simplecode's own state directory (``.simplecode/``) is excluded from
    BOTH halves: writing this very ledger there must NOT change the
    fingerprint of the tree the ledger describes, and that directory is tool
    evidence, not the subject under audit.

    Returns the ``GIT_UNAVAILABLE`` sentinel when git cannot be consulted (not a
    repo / git missing): the ledger then records honestly that its provenance
    could not be obtained, instead of a fabricated digest. Since 2026-09-15 that
    sentinel does not block the gate -- a fact that no longer gates cannot gate
    through its own absence either.
    """
    status = _run_git(root, ["status", "--porcelain=v1", "-z", "--", ".", ":(exclude).simplecode"])
    if status is None or status[0] != 0:
        return GIT_UNAVAILABLE
    head_tree = _committed_tree_fingerprint(root)
    digest = hashlib.sha256(f"{head_tree}\x00{status[1]}".encode("utf-8")).hexdigest()
    return digest


def _is_pass(verdict: Any) -> bool:
    if not isinstance(verdict, str):
        return False
    v = verdict.strip().lower()
    return v in _PASS_VERDICTS or v in _PASS_SYNONYMS


def _is_evidenced(result: Any) -> bool:
    """Whether a result carries evidence, not just a verdict.

    A passing verdict with no evidence is an assertion, and an assertion is the
    thing this ledger exists to refuse. Fail closed on anything that is not a
    string of at least ``_MIN_BULLET_LEN`` characters after stripping.
    """
    if not isinstance(result, dict):
        return False
    evidence = result.get("evidence")
    return isinstance(evidence, str) and len(evidence.strip()) >= _MIN_BULLET_LEN


def record_ledger(
    root: Path, panel: str, results: list[dict[str, Any]], profile: str = "general",
    merge: bool = False,
) -> AuditLedger:
    """Build and durably write a ledger from the CURRENT tree and SPEC.

    ``results`` is a list of ``{claim_id, verdict, evidence}`` records. Each is
    sealed here with ``claim_seal`` -- the recorder seals, never the auditor, so
    a panel cannot hand in a seal for a tree it did not read. A result becomes a
    violation if its verdict is not passing, if it carries no evidence, or if
    its evidence is a template (``_template_evidence``).

    ``merge`` keeps the previous ledger's results for claims whose seal still
    matches and that ``results`` does not re-judge: re-auditing only the stale
    claims is what makes keeping H1 fresh cheap enough to actually happen.
    Results for claims that no longer exist are dropped.
    """
    governance_errors: list[str] = []
    claims = governing_claims(root, governance_errors)
    if governance_errors:
        raise OSError("COULD_NOT_RUN: governing claim set is incomplete: " + "; ".join(governance_errors))
    index = _citable_index(root)
    by_id = {c.id: c for c in claims}
    given = {str(r.get("claim_id")): dict(r) for r in results if isinstance(r, dict)}
    previous = _load_ledger(root / LEDGER_RELPATH) if merge else None
    prior = [r for r in (previous.results if previous else [])
             if isinstance(r, dict) and r.get("claim_id") in by_id and r.get("claim_id") not in given]
    stale_ids = {cid for cid, _ in stale_claims(root, previous, claims)} if previous else set()
    kept = [r for r in prior if r["claim_id"] not in stale_ids]
    sealed = []
    for cid, row in given.items():
        if cid in by_id:
            row["seal"], row["cited"] = claim_seal(root, by_id[cid], index, str(row.get("evidence", "")))
        sealed.append(row)
    merged = sorted(kept + sealed, key=lambda r: str(r.get("claim_id")))
    templated = set(_template_evidence(merged))
    violations = [
        r for r in merged
        if not _is_pass(r.get("verdict")) or not _is_evidenced(r) or r.get("claim_id") in templated
    ]
    ledger = AuditLedger(
        tree_fingerprint=tree_fingerprint(root),
        claims_fingerprint=claims_fingerprint(claims),
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        panel=panel,
        profile=profile,
        results=merged,
        violations=violations,
    )
    atomic_io.write_text_durable(root / LEDGER_RELPATH, ledger.to_json())
    return ledger


def _load_ledger(path: Path) -> AuditLedger | None:
    try:
        return AuditLedger.from_json(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def describe_tree_provenance(root: Path, ledger: AuditLedger | None = None) -> str:
    """One line saying WHICH tree the recorded verdicts were taken against.

    Provenance, not a verdict: this line gates nothing and is printed on a
    passing gate and a blocking one alike. It exists because removing the tree
    seal (2026-09-15) removed the only place the reader ever saw that distance
    -- a number nobody can see is a number nobody can judge.

    ``ledger`` defaults to the one on disk under ``root`` so a caller that has
    not loaded it (``version_bump``) can print the same line.

    The commit count comes from ``git rev-list --count --since=<ledger
    timestamp> HEAD``. When git cannot answer -- not a repo, git missing, a
    timestamp git refuses to parse -- the line says "commit count unavailable".
    It does NOT say 0: "no commits since the audit" and "I could not count"
    are opposite facts, and printing the reassuring one for the unknown is the
    blind-instrument mould this repo keeps measuring.
    """
    if ledger is None:
        ledger = _load_ledger(root / LEDGER_RELPATH)
    if ledger is None:
        return f"no ledger at {LEDGER_RELPATH} to read tree provenance from"

    count: int | None = None
    stamp = ledger.timestamp.strip()
    if stamp:
        result = _run_git(root, ["rev-list", "--count", f"--since={stamp}", "HEAD"])
        if result is not None and result[0] == 0 and result[1].strip().isdigit():
            count = int(result[1].strip())
    tail = f"{count} commit(s) since" if count is not None else "commit count unavailable"
    return (
        f"verdicts recorded against tree {ledger.tree_fingerprint[:12]} "
        f"at {ledger.timestamp}; {tail}"
    )


def stale_claims(root: Path, ledger: AuditLedger, claims: list[Claim]) -> list[tuple[str, str]]:
    """``(claim id, why)`` for every audited claim whose seal no longer matches.

    ``why`` names what moved -- the claim's own text, or which cited files -- so
    the re-audit knows where to look. A result with no seal predates per-claim
    seals and is stale by definition: it certified text, never code. Unaudited
    claims are reported separately by the caller.
    """
    index = _citable_index(root)
    by_id = {r.get("claim_id"): r for r in ledger.results if isinstance(r, dict)}
    out: list[tuple[str, str]] = []
    for claim in claims:
        row = by_id.get(claim.id)
        if row is None:
            continue
        if "seal" not in row:
            out.append((claim.id, "recorded before per-claim seals"))
            continue
        seal, files = claim_seal(root, claim, index, str(row.get("evidence", "")))
        if row["seal"] == seal:
            continue
        cited = row.get("cited")
        old: dict[str, str] = cited if isinstance(cited, dict) else {}
        moved = sorted(rel for rel in set(old) | set(files) if old.get(rel) != files.get(rel))
        out.append((claim.id, "changed: " + ", ".join(moved[:5]) if moved else "claim text changed"))
    return out


def _judge_ledger(
    ledger: AuditLedger, claims: list[Claim], profile: str | None, root: Path
) -> list[str]:
    """Every reason ``ledger`` fails to certify ``claims``; empty means green.

    The five conditions live HERE, in one place, and not inside
    ``verify_audit_fresh``, because there are now two gates asking the same
    question of two different subjects: the working tree
    (``verify_audit_fresh``) and a specific commit
    (``verify_audit_fresh_at_commit``). Duplicating the conditions would let a
    condition added to one be absent from the other, and the direction of that
    drift is the dangerous one -- the RELEASE gate would silently be the weaker
    of the two, which is the whole defect this function was extracted to close.

    ``claims`` is passed in rather than derived from a root: which claim set the
    ledger is judged against is exactly what distinguishes the two callers, so
    it is the parameter, not a hidden lookup.
    """
    reasons: list[str] = []

    if profile is not None and ledger.profile != profile:
        reasons.append(f"ledger profile {ledger.profile!r} does not satisfy required {profile!r}")

    stale = stale_claims(root, ledger, claims)
    if stale:
        shown = "; ".join(f"{cid} ({why})" for cid, why in stale[:10])
        reasons.append(f"{len(stale)} stale claim(s), re-audit them: {shown}")

    if ledger.violations:
        reasons.append(f"{len(ledger.violations)} violation(s) present in ledger")

    nonpassing = [
        str(r.get("claim_id", "?")) if isinstance(r, dict) else "<unreadable row>"
        for r in ledger.results
        if not isinstance(r, dict) or not _is_pass(r.get("verdict"))
    ]
    if nonpassing:
        reasons.append(
            f"{len(nonpassing)} result(s) have a non-passing or unreadable verdict: "
            f"{', '.join(nonpassing[:10])}"
        )

    # `r.get` on a row that is not a dict raises AttributeError and takes the
    # whole gate down with a traceback instead of a verdict -- a crashed gate is
    # not a clean report, and a ledger written by hand can hold any JSON at all.
    # A row we cannot read contributes no claim_id, so it fails closed as
    # unaudited AND unevidenced rather than being skipped.
    audited = {r.get("claim_id") for r in ledger.results if isinstance(r, dict)}
    unaudited = [c.id for c in claims if c.id not in audited]
    if unaudited:
        shown = ", ".join(unaudited[:10])
        reasons.append(f"{len(unaudited)} unaudited claim(s): {shown}")

    # Re-checked HERE and not only in record_ledger: a ledger.json written by
    # hand never passes through record_ledger, so enforcing evidence only at
    # write time leaves the gate itself unable to tell a real panel from a
    # fabricated one. This is the load-bearing half.
    unevidenced = [
        str(r.get("claim_id", "?")) if isinstance(r, dict) else "<unreadable row>"
        for r in ledger.results
        if not _is_evidenced(r)
    ]
    if unevidenced:
        shown = ", ".join(unevidenced[:10])
        reasons.append(
            f"{len(unevidenced)} claim(s) recorded with no evidence "
            f"(under {_MIN_BULLET_LEN} chars): {shown}"
        )

    templated = _template_evidence(ledger.results)
    if templated:
        reasons.append(
            f"{len(templated)} claim(s) whose evidence is a template (shared with another "
            f"claim, or naming no file, `command` or :line): {', '.join(templated[:10])}"
        )

    return reasons


def verify_audit_fresh(root: Path, profile: str | None = None) -> tuple[bool, list[str]]:
    """The gate: is a complete, evidenced, green ledger present for THESE claims?

    Returns ``(ok, reasons)``. ``ok`` is False (NOT clean) if ANY of:
      * the ledger file is missing or unreadable,
      * the ledger's profile does not satisfy the required one,
      * any current claim's per-claim seal (text + cited files) no longer matches,
      * any result's evidence is a template (shared, or naming no file/command/line),
      * the ledger carries any violation,
      * any extracted claim has no result in the ledger (unaudited claim),
      * any recorded result carries no evidence.

    The TREE is deliberately absent from that list since 2026-09-15: the ledger
    records which tree the panel read (``describe_tree_provenance`` prints it),
    and a moved tree is no longer a reason. The name stays ``verify_audit_fresh``
    because every caller and hook in the fleet spells it that way; "fresh" now
    means fresh against the CLAIMS, which is the thing a re-audit actually
    re-examines.

    Every failing condition appends a specific reason. An incomplete, unevidenced
    or claims-stale ledger is NOT a clean report.
    """
    reasons: list[str] = []
    ledger_path = root / LEDGER_RELPATH

    if not ledger_path.is_file():
        reasons.append(f"ledger file missing at {LEDGER_RELPATH}")
        return False, reasons

    ledger = _load_ledger(ledger_path)
    if ledger is None:
        reasons.append(f"ledger file at {LEDGER_RELPATH} is unreadable or corrupt")
        return False, reasons
    governance_errors: list[str] = []
    claims = governing_claims(root, governance_errors)
    reasons.extend(f"COULD_NOT_RUN: {error}" for error in governance_errors)
    if not governance_errors:
        reasons.extend(_judge_ledger(ledger, claims, profile, root))
    return (not reasons), reasons


def _snapshot_governance_at_commit(root: Path, commit: str, dest: Path) -> str | None:
    """Extract ``commit``'s governing documents and ledger into ``dest``.

    Returns ``None`` on success, or a human-readable reason git could not
    answer. A reason is a COULD_NOT_RUN, never a verdict about the ledger: "the
    commit's ledger was not green" and "I could not read the commit's ledger"
    are opposite facts and the second one must not be able to wear the first
    one's clothes.

    ``git archive`` rather than reading blobs one at a time: extracting a
    subtree of a commit is something git already does, and the extracted files
    then feed the EXISTING ``governing_claims`` unchanged, so the at-commit
    claim set is computed by the same code as the working-tree one instead of a
    parallel reimplementation that could disagree with it.

    Since 2026-09-27 the WHOLE commit is extracted (see the comment below);
    before that, only ``GOVERNING_RELPATHS`` plus the ledger were. Measured in this repo 2026-09-15: the whole tree is 104.8 ms and
    10321920 tar bytes per commit, the filtered paths 9.1 ms and 184320 bytes --
    11x, and a push can carry several release commits. A path absent from the
    commit is simply left out of the archive (git refuses an archive naming a
    path it does not have), and ``governing_claims`` already treats an absent
    document as contributing no claim: git answering "that file is not in this
    tree" is an ANSWER, not an unknown, so it is not a COULD_NOT_RUN.
    """
    # The WHOLE commit since the per-claim seal (2026-09-27): a claim is sealed
    # with the files it cites, and judging it at a release commit needs those
    # files as that commit had them. The 11x saving measured below bought a
    # snapshot in which every cited file read as deleted.
    wanted = ["."]
    present = _run_git(root, ["ls-tree", "--name-only", "-z", commit, "--", *wanted])
    if present is None:
        return "git could not be invoked to list the commit's governing documents"
    if present[0] != 0:
        return f"git could not resolve {commit} (ls-tree returned {present[0]})"
    # `check=False` + an explicit returncode read, and OSError caught: a missing
    # `git`/`tar` binary raises instead of returning, and an exception escaping
    # here would crash the gate rather than answer COULD_NOT_RUN -- a crashed
    # gate is not a clean report.
    try:
        archive = subprocess.run(
            ["git", "-C", str(root), "archive", "--format=tar", commit],
            capture_output=True, check=False,
        )
        if archive.returncode != 0:
            return (f"git archive of {commit} failed ({archive.returncode}): "
                    f"{archive.stderr.decode('utf-8', 'replace').strip()}")
        extract = subprocess.run(
            ["tar", "-x", "-C", str(dest)], input=archive.stdout, capture_output=True, check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return f"extracting {commit}'s governing documents could not be run: {exc}"
    if extract.returncode != 0:
        return (f"extracting {commit}'s governing documents failed "
                f"({extract.returncode}): {extract.stderr.decode('utf-8', 'replace').strip()}")
    return None


def verify_audit_fresh_at_commit(
    root: Path, commit: str, profile: str | None = None
) -> tuple[str, list[str]]:
    """Was the ledger THAT COMMIT CARRIED green for the claims THAT COMMIT had?

    Returns ``(verdict, reasons)`` with verdict one of ``AUDIT_OK``,
    ``AUDIT_BLOCKED``, ``AUDIT_COULD_NOT_RUN``.

    WHY THIS EXISTS, measured. ``verify_audit_fresh`` reads
    ``root / LEDGER_RELPATH`` and ``governing_claims(root)`` -- both the WORKING
    TREE. At a release boundary the working tree is the TIP of the outgoing
    range, which is not the release commit. Measured in this repo 2026-09-15
    from ``.simplecode/evidence/telemetry.jsonl``: the last green ``version-bump``
    push before the 6.5.x releases was 2026-09-10T07:11:51
    (``subject_sha=54aa2cb80575``) and the next was 2026-09-13T15:59:54
    (``aba281aa59bc``); ``git rev-list --count 54aa2cb80575..aba281aa59bc`` = 38,
    and that ONE push carried the releases ``2bfd0dfa`` (6.5.0) and ``a65cc9af``
    (6.5.1) together with the refreshed ledger ``f457f5d63a25``. H1 ran and
    passed -- on the tip, whose ledger had been sealed one commit earlier. Asked
    about their OWN commits with this function, those two releases come back
    BLOCKED: "stale claims" plus 15 unaudited claims. The verdict had never been
    about the release commit at all.

    WHAT THIS DELIBERATELY IS NOT. The tree seal (``tree_fingerprint``) was
    removed from ``verify_audit_fresh`` on 2026-09-15 by Luis's vote, because it
    manufactured "pure tree-refresh" commits (27 of them since 2026-09-01,
    titled ``docs(audit): pure tree-refresh H1 ledger``; 40 with
    "tree-refresh" anywhere in the subject; re-measured 2026-09-28) and
    was the second cause of push retries. Nothing here restores it and nothing
    here measures a DISTANCE: the subject is the CONTENT of that commit -- its
    ledger blob and its governing documents -- so how many commits piled up
    afterwards is not an input. Measured, and this is the control in the
    permissive direction: ``f457f5d63a25``, whose ledger was green at its own
    commit, still comes back OK today with ``git rev-list --count
    f457f5d63a25..HEAD`` = 120 commits between it and the tip. A distance rule
    would have blocked it; this does not.

    Cost: 10..15 ms per commit in this repo (2026-09-15), dominated by the
    filtered ``git archive``.
    """
    # Creating the workspace is its OWN failure mode and it is NOT inside the
    # snapshot helper's try: a read-only or full `TMPDIR` raises here, and an
    # OSError escaping this function would take the gate down with a traceback
    # instead of a verdict. Found by probing this path while writing the
    # end-to-end evidence for DEBT-PUSH-LOOP-07, 2026-09-15 -- the first draft
    # crashed. A crashed gate is not a clean report, it is an absent one.
    # Caught narrowly, around the creation only, so a genuine failure further in
    # still reaches the specific branch that describes it.
    try:
        workspace = tempfile.TemporaryDirectory(prefix="simplecode-h1-at-commit-")
    except OSError as exc:
        return AUDIT_COULD_NOT_RUN, [
            f"the H1 ledger in force at release commit {commit} is UNKNOWN, not "
            f"green and not stale: no workspace could be created to read it "
            f"into: {exc}"
        ]
    with workspace as td:
        snapshot = Path(td)
        failure = _snapshot_governance_at_commit(root, commit, snapshot)
        if failure is not None:
            return AUDIT_COULD_NOT_RUN, [
                f"the H1 ledger in force at release commit {commit} is UNKNOWN, "
                f"not green and not stale: {failure}"
            ]

        ledger_path = snapshot / LEDGER_RELPATH
        if not ledger_path.is_file():
            return AUDIT_BLOCKED, [
                f"release commit {commit} carries no ledger at {LEDGER_RELPATH}"
            ]
        ledger = _load_ledger(ledger_path)
        if ledger is None:
            return AUDIT_BLOCKED, [
                f"the ledger in release commit {commit} is unreadable or corrupt"
            ]

        governance_errors: list[str] = []
        claims = governing_claims(snapshot, governance_errors)
        if governance_errors:
            return AUDIT_COULD_NOT_RUN, [
                f"the governing claim set for release commit {commit} is incomplete: {error}"
                for error in governance_errors
            ]
        reasons = [
            f"release commit {commit}: {reason}"
            for reason in _judge_ledger(ledger, claims, profile, snapshot)
        ]
    verdict = AUDIT_BLOCKED if reasons else AUDIT_OK
    return verdict, reasons


def _cmd_extract_claims(root: Path) -> int:
    errors: list[str] = []
    claims = governing_claims(root, errors)
    if errors:
        for error in errors:
            print(f"[audit] COULD_NOT_RUN: {error}", file=sys.stderr)
        return 1
    payload = {
        "claims_fingerprint": claims_fingerprint(claims),
        "count": len(claims),
        "claims": [asdict(c) for c in claims],
    }
    print(json.dumps(payload, indent=2))
    return 0


def _cmd_stale(root: Path) -> int:
    """JSON of every claim that needs an audit now -- unaudited, stale or failing --
    with its text and cited files: the exact input a re-audit needs (/h1)."""
    errors: list[str] = []
    claims = governing_claims(root, errors)
    if errors:
        for error in errors:
            print(f"[audit] COULD_NOT_RUN: {error}", file=sys.stderr)
        return 1
    ledger = _load_ledger(root / LEDGER_RELPATH)
    results = {r.get("claim_id"): r for r in (ledger.results if ledger else []) if isinstance(r, dict)}
    why = dict(stale_claims(root, ledger, claims)) if ledger else {}
    bad = {str(v.get("claim_id")) for v in (ledger.violations if ledger else []) if isinstance(v, dict)}
    bad |= set(_template_evidence(ledger.results)) if ledger else set()
    index = _citable_index(root)
    todo = []
    for claim in claims:
        reason = ("unaudited" if claim.id not in results else why.get(claim.id)
                  or ("failing or template evidence" if claim.id in bad else None))
        if reason:
            todo.append({**asdict(claim), "why": reason, "cited": cited_files(claim, index)})
    print(json.dumps({"count": len(todo), "of": len(claims), "claims": todo}, indent=2, ensure_ascii=False))
    return 0


def _cmd_record(root: Path, panel: str | None, results_path: Path | None, profile: str,
                merge: bool = False) -> int:
    if not panel or results_path is None:
        print("[audit] --record requires --panel <name> and --results <file.json>")
        return 2
    try:
        raw = json.loads(results_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        print(f"[audit] COULD_NOT_RUN: cannot read results file {results_path}: {exc}")
        return 1
    results = raw.get("results", raw) if isinstance(raw, dict) else raw
    if not isinstance(results, list):
        print("[audit] COULD_NOT_RUN: results must be a JSON list of {claim_id, verdict, evidence}")
        return 1
    try:
        ledger = record_ledger(root, panel, results, profile, merge=merge)
    except OSError as exc:
        print(f"[audit] COULD_NOT_RUN: {exc}")
        return 1
    print(
        f"[audit] ledger written to {LEDGER_RELPATH} "
        f"(panel={ledger.panel}, profile={ledger.profile}, results={len(ledger.results)}, "
        f"violations={len(ledger.violations)}, tree={ledger.tree_fingerprint[:12]})"
    )
    return 0


def _cmd_gate(root: Path, profile: str | None) -> int:
    ok, reasons = verify_audit_fresh(root, profile)
    # Reporting politics: print the zeros too. An incomplete ledger is not clean.
    print(f"[audit] not-clean reasons: {len(reasons)}")
    for reason in reasons:
        print(f"  - {reason}")
    # Printed on BOTH verdicts, and deliberately not phrased as a reason: the
    # tree is provenance now. A passing gate that hid this line would be the
    # quieter half of the same blindness the seal's removal traded away.
    print(f"[audit] tree provenance (informative, does not gate): {describe_tree_provenance(root)}")
    if ok:
        # Deliberately weak-but-true wording: this proves completeness/evidence/
        # green against the claims, NOT that the audit was genuinely adversarial
        # (the ledger is forgeable), and NOT anything about the code delta since.
        print("[audit] complete green ledger present for the current claims.")
        return 0
    print("[audit] NOT CLEAN: no complete green ledger for the current claims (blocking).")
    return 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="simplecode audit",
        description="Adversarial audit ledger (ADR-0006): extract claims, record a ledger, gate on complete+evidenced+green.",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--extract-claims", action="store_true", help="Emit SPEC claims as JSON")
    parser.add_argument("--record", action="store_true", help="Write a ledger from an audit results file")
    parser.add_argument("--merge", action="store_true",
                        help="With --record: keep prior results whose per-claim seal still matches")
    parser.add_argument("--stale", action="store_true",
                        help="Emit, as JSON, every claim that needs an audit now (unaudited, stale, failing)")
    parser.add_argument("--panel", default=None, help="Who/what ran the panel (with --record)")
    parser.add_argument("--results", type=Path, default=None, help="Audit results JSON (with --record)")
    parser.add_argument("--profile", choices=("general", "security"), default="general",
                        help="Evidence profile to record or require")
    parser.add_argument("--gate", action="store_true",
                        help="Verify a complete, evidenced, green ledger for the current claims; exit 1 if not")
    args = parser.parse_args(argv)

    root = args.root.resolve()
    if args.extract_claims:
        return _cmd_extract_claims(root)
    if args.stale:
        return _cmd_stale(root)
    if args.record:
        return _cmd_record(root, args.panel, args.results, args.profile, merge=args.merge)
    if args.gate:
        return _cmd_gate(root, args.profile)
    parser.print_usage()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
