#!/usr/bin/env python3
"""El corpus adversarial con memoria: un caso cazado no puede desaparecer en silencio.

Mecanismo tomado de Bratan (Atlas, cosecha 2026-09-06), de las citas que resuelven
contra la captura CRUDA del upstream y no contra prosa del modelo:

    "Append-only test set + human-anchored ground truth | Old cases never
     deleted. Every red-team case is verified against the corpus before it
     enters the loop. Regressions are hard failures."

**Lo que lo justifica no es la idea, es la medicion del sujeto.** `red_team`
regenera sus mutaciones en cada corrida como funcion pura de
`detector_controls.CONTROLS` x 4 sintetizadores; no persiste ni un caso. Medido el
2026-09-06 quitando un control real:

    mutaciones: 91 -> 87   (4 casos dejan de probarse)
    veredicto:  Convicted: 87 | Evasions: 0   rc=0

Verde, y ninguna linea dice que la prueba encogio. Un conjunto de pruebas que es
funcion del codigo que prueba no puede detectar que el codigo dejo de probarse.

## Por que el gate NO escribe aqui

Grabar es un paso APARTE (`--record`), nunca un efecto del `--gate`. Es la misma
separacion que `audit_ledger` ya hace, y la leccion que costo cara el mismo dia:
`hardening_proposal` verificaba parcheando el fuente enviado y una carrera dejo un
fixture de test dentro de `ast_normalizer.py`. Una compuerta que escribe en el
arbol que juzga acaba acreditandose a si misma.

## El retiro es explicito y firmado

Un caso puede dejar de generarse por una razon legitima -- se retiro el detector, o
el sintetizador cambio. Para eso existe `retired`: una fecha y un motivo escritos
por una persona. Sin ese campo, un caso que desaparece es un FALLO, no un cambio.
Esa es la diferencia entre una prueba que encoge por decision y una que encoge
sola.
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils import atomic_io

# Versionado a proposito: un corpus que viviera en `.simplecode/` no sobrevive al
# clone -- medido en `pii_scan.permitidos`, 15 de 18 repos ignoran esa carpeta.
_CORPUS_RELPATH = Path("tasks") / "red_team_corpus.json"


class CorpusError(ValueError):
    """El corpus no se pudo leer o una escritura se rechaza."""


@dataclass(frozen=True)
class CasoAusente:
    caso_id: str
    visto_por_primera_vez: str


def corpus_path(root: Path) -> Path:
    return root / _CORPUS_RELPATH


def caso_id(detector_id: str, mutation_type: str) -> str:
    """La identidad de un caso: que detector, evadido de que forma.

    NO incluye el codigo mutado: ese cambia cuando el codigo positivo del control
    se reescribe, y un caso que cambia de id cada vez que alguien edita un fixture
    no tiene memoria de nada.
    """
    return f"{detector_id}/{mutation_type}"


def load(root: Path) -> dict[str, dict[str, Any]]:
    """Los casos registrados, por id. Un corpus ausente es un dict vacio.

    Un corpus ILEGIBLE no lo es: se levanta, para que el gate lo reporte como
    instrumento caido en vez de como "no habia nada registrado", que es la mentira
    que este modulo existe para impedir.
    """
    path = corpus_path(root)
    if not path.is_file():
        return {}
    try:
        datos = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise CorpusError(f"{_CORPUS_RELPATH.as_posix()} ilegible o malformado: {exc}") from exc
    casos = datos.get("casos") if isinstance(datos, dict) else None
    if not isinstance(casos, dict):
        raise CorpusError(
            f"{_CORPUS_RELPATH.as_posix()} no tiene un objeto `casos`; "
            f"encontrado: {type(casos).__name__}"
        )
    return casos


def ausentes(registrados: dict[str, dict[str, Any]], generados_hoy: set[str]) -> list[CasoAusente]:
    """Casos que el corpus recuerda y la corrida de hoy ya no genera.

    Un caso con `retired` no cuenta: alguien firmo su retirada con fecha y motivo.
    """
    faltan = []
    for cid, entrada in sorted(registrados.items()):
        if cid in generados_hoy:
            continue
        if isinstance(entrada, dict) and entrada.get("retired"):
            continue
        primera = ""
        if isinstance(entrada, dict):
            primera = str(entrada.get("first_seen", ""))
        faltan.append(CasoAusente(caso_id=cid, visto_por_primera_vez=primera))
    return faltan


def record(root: Path, generados_hoy: set[str], *, hoy: str | None = None) -> tuple[int, int]:
    """Append-only: anade los casos nuevos y NO borra ninguno. Devuelve (nuevos, total).

    Nunca se llama desde `--gate`. Ver el docstring del modulo.
    """
    registrados = load(root)
    fecha = hoy or date.today().isoformat()
    nuevos = 0
    for cid in sorted(generados_hoy):
        if cid not in registrados:
            registrados[cid] = {"first_seen": fecha}
            nuevos += 1
    path = corpus_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_io.write_text_durable(
        path,
        json.dumps({"casos": registrados}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return nuevos, len(registrados)


def _generados_hoy() -> set[str]:
    from simplecode.verification import red_team

    return {caso_id(m.detector_id, m.mutation_type) for m in red_team.synthesize_all_mutations()}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--record", action="store_true",
                    help="Anade los casos de hoy al corpus (append-only). Nunca lo hace --gate.")
    ap.add_argument("--gate", action="store_true",
                    help="Falla si un caso registrado dejo de generarse sin retirada firmada")
    args = ap.parse_args(argv)
    root = args.root

    try:
        hoy = _generados_hoy()
    except (AttributeError, TypeError, KeyError, ValueError, SyntaxError, ImportError) as exc:
        # Las formas reales de "el registro de detectores esta roto": una entrada
        # con la forma equivocada, un modulo que no importa, un codigo positivo que
        # no parsea. NO se captura en ciego: `angry_path` lo caza -- y con razon,
        # porque un `except Exception` que imprime y devuelve convierte cualquier
        # fallo inesperado en un COULD_NOT_RUN tranquilizador. Lo que no este en
        # esta lista debe reventar con su traza, que es mas util que un mensaje.
        print(f"[red-team-corpus] COULD_NOT_RUN: no se pudieron generar los casos de hoy: "
              f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    if not hoy:
        print("[red-team-corpus] COULD_NOT_RUN: 0 casos generados hoy; no hay con que "
              "comparar el corpus", file=sys.stderr)
        return 1

    if args.record:
        nuevos, total = record(root, hoy)
        print(f"[red-team-corpus] registrados {nuevos} caso(s) nuevo(s); el corpus tiene {total}")
        return 0

    try:
        registrados = load(root)
    except CorpusError as exc:
        print(f"[red-team-corpus] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 1

    faltan = ausentes(registrados, hoy)
    print(f"[red-team-corpus] casos registrados: {len(registrados)} | generados hoy: {len(hoy)} "
          f"| registrados que hoy NO se generan: {len(faltan)}")
    emit_hallazgos("[red-team-corpus]", len(faltan))
    for c in faltan[:20]:
        print(f"  AUSENTE {c.caso_id} (registrado el {c.visto_por_primera_vez or '<sin fecha>'})")

    if faltan and args.gate:
        primero = faltan[0]
        print(
            f"[red-team-corpus] FAIL: {len(faltan)} caso(s) adversarial(es) que el corpus "
            f"recuerda ya no se generan; primero {primero.caso_id} (registrado el "
            f"{primero.visto_por_primera_vez or '<sin fecha>'}). Si la retirada es "
            f"deliberada, firmala en {_CORPUS_RELPATH.as_posix()} con "
            f'"retired": "YYYY-MM-DD motivo"',
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
