#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""H3 findings ratchet (ADR-0008): crystallize audit findings into permanent detectors.

The anti-fragile loop: H1 (``audit_ledger``) FINDS a defect class an audit
convicts; the operator writes a deterministic detector plus its H2 positive
control; **H3 records the link** here so the class can never silently regress.
This module owns the deterministic, offline half: a git-tracked registry
(``ratchet_registry.json`` at the repo root -- durable institutional knowledge
that must travel with the repo, NOT under ``.simplecode/``) and a gate that
proves every recorded class still maps to a LIVE, non-blind detector.

Each registry entry is ``{finding_class_id, description, source, detector_key,
recorded}``. The gate (``verify_ratchet``) asserts, for every entry, that its
``detector_key`` is still present in ``detector_controls.live_registry()`` (the
class is still gated) AND that the detector is not blind -- it still convicts its
own H2 positive control. A recorded class whose detector was deleted or went
blind is a BROKEN ratchet: a defect that was supposed to be permanently gated is
not, and the gate fails.

HONEST LIMIT (ADR-0008, stated not hidden): H3 only guarantees that RECORDED
classes stay gated. A defect class an audit never found, or found but nobody
recorded, is NOT covered. H3 makes the ratchet monotonic; it does not make the
audits exhaustive -- that is H1's (unbounded) job. A broken ratchet is never a
clean report, and an empty registry is not proof the codebase is clean.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io
from simplecode.utils.tool_limits import SMOKE_SUITE_TIMEOUT
from simplecode.verification import detector_controls

RATCHET_RELPATH = Path("ratchet_registry.json")

H3_LIMIT = (
    "H3 guarantees only that RECORDED defect classes stay gated; it does NOT make "
    "audits exhaustive -- an unfound or unrecorded class is not covered (that is H1)."
)

_ENTRY_KEYS = ("finding_class_id", "description", "source", "detector_key", "recorded")

# --- Enforcement points that are NOT pattern detectors (DEBT-SPEC8-RATCHET-BEYOND-DETECTORS)
# H3 links a recorded class to the organ that keeps it gated. Until 2026-09-04 that
# organ could only be a key in the pattern-detector registry, so two whole families
# of defect class were ungateable BY CONSTRUCTION -- SPEC named them and nothing
# enforced it:
#
#   * scanner-level  -- zero_debt's `UnparseableSource` -> COULD_NOT_RUN
#   * verifier-level -- backlog_verifier's command whitelist
#
# Both are held by TESTS, not by detectors, so a regression in either broke no
# ratchet. An entry may now name `test_node` instead of `detector_key`.
#
# The asymmetry is real and is NOT papered over. A detector entry is checked
# against H2, which PROVES the detector still convicts its own positive control.
# A test entry cannot be checked that cheaply -- proving a test can still fail
# means mutating the source and re-running it, which is not a gate-time cost. So a
# test entry must cite a `control` artifact: the recorded `.fail.txt` from a real
# mutant run, the same evidence the closing contract already requires. The gate
# verifies the test is still COLLECTABLE and the control artifact still exists.
#
# What that buys: a test deleted, renamed, or moved out from under a recorded class
# is convicted. What it does NOT buy, stated plainly: a test whose body was gutted
# while keeping its name still collects, and this gate will pass it. That is
# strictly weaker than the detector branch, and `verify_ratchet` reports the two
# populations separately so nobody reads one number as if it covered both.
_TEST_ENTRY_KEYS = ("finding_class_id", "description", "source", "test_node", "control", "recorded")


class RatchetError(ValueError):
    """Raised when a crystallization is refused (hollow: missing or blind detector)."""


def registry_path(root: Path) -> Path:
    """Absolute path to the git-tracked ratchet registry for ``root``."""
    return root / RATCHET_RELPATH


def load_registry(root: Path) -> list[dict[str, Any]]:
    """Load the registry entries, or ``[]`` when no registry file exists yet.

    Raises ``RatchetError`` when the file exists but is not a JSON list of
    entries: a corrupt registry is never silently treated as an empty one.
    """
    path = registry_path(root)
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise RatchetError(f"ratchet registry unreadable at {RATCHET_RELPATH}: {exc}") from exc
    if not isinstance(data, list):
        raise RatchetError(f"ratchet registry at {RATCHET_RELPATH} is not a JSON list")
    return [dict(entry) for entry in data]


def save_registry(root: Path, entries: list[dict[str, Any]]) -> Path:
    """Durably write the registry (atomic replace + post-write hash verify)."""
    text = json.dumps(entries, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    return atomic_io.write_text_durable(registry_path(root), text)


def _live_keys() -> set[str]:
    """The set of detector keys currently registered in the live production registry."""
    return {key for _fn, key, _msg in detector_controls.live_registry()}


def _control_failures() -> tuple[set[str], dict[str, str]]:
    """Collect blind and un-runnable detector controls from one H2 audit."""
    blind: set[str] = set()
    crashed: dict[str, str] = {}
    for finding in detector_controls.audit_detector_controls():
        prefix, sep, remainder = finding.partition(": ")
        if not sep:
            continue
        if prefix in ("detector_does_not_convict", "detector_without_control"):
            blind.add(remainder.strip())
        elif prefix == "detector_crashed":
            key, detail_sep, detail = remainder.partition(": ")
            if key.strip():
                crashed[key.strip()] = detail if detail_sep else "control raised"
    return blind, crashed


def _blind_keys() -> set[str]:
    """Detector keys reported blind by the shared H2 control audit."""
    return _control_failures()[0]


def verify_ratchet(root: Path) -> tuple[bool, list[str]]:
    """The GATE: every recorded class still maps to a live, non-blind detector.

    Returns ``(ok, findings)``. ``ok`` is False (NOT clean) when any entry's
    detector is missing or blind:

      * ``ratchet_broken_missing_detector: <class_id> -> <detector_key>`` when the
        detector_key is no longer in the live registry (the class is un-gated), or
      * ``ratchet_broken_blind_detector: <class_id> -> <detector_key>`` when the
        detector is present but no longer convicts its own H2 positive control.

    A corrupt registry yields ``ratchet_registry_unreadable: <reason>``. An empty
    registry is vacuously OK, but that is not evidence the codebase is clean.
    """
    try:
        entries = load_registry(root)
    except RatchetError as exc:
        return False, [f"ratchet_registry_unreadable: {exc}"]

    live = _live_keys()
    blind, crashed = _control_failures()
    findings: list[str] = []
    for entry in entries:
        class_id = entry.get("finding_class_id", "<unknown>")
        if entry.get("test_node"):
            findings.extend(_verify_test_entry(root, entry, class_id))
            continue
        key = entry.get("detector_key", "<unknown>")
        if key not in live:
            findings.append(f"ratchet_broken_missing_detector: {class_id} -> {key}")
        elif key in crashed:
            findings.append(f"ratchet_detector_could_not_run: {key}: {crashed[key]}")
        elif key in blind:
            findings.append(f"ratchet_broken_blind_detector: {class_id} -> {key}")
    return (not findings), findings


def entry_populations(root: Path) -> dict[str, int]:
    """How many recorded classes are held by each kind of enforcement point.

    Reported separately and always, because the two kinds are NOT verified to the
    same depth (see `_TEST_ENTRY_KEYS`): a single "N classes ratcheted" number
    would let the weaker guarantee hide inside the stronger one.
    """
    try:
        entries = load_registry(root)
    except RatchetError:
        return {"detector": 0, "test": 0, "unreadable": 1}
    tests = sum(1 for e in entries if e.get("test_node"))
    return {"detector": len(entries) - tests, "test": tests, "unreadable": 0}


def _verify_test_entry(root: Path, entry: dict[str, Any], class_id: str) -> list[str]:
    """A test-backed class: the test still collects and its mutant control survives."""
    node = str(entry.get("test_node", ""))
    control = str(entry.get("control", ""))
    findings: list[str] = []

    if not control:
        findings.append(f"ratchet_test_entry_without_control: {class_id} -> {node}")
    elif not (root / control).is_file():
        findings.append(f"ratchet_broken_missing_control: {class_id} -> {control}")

    file_part = node.split("::", 1)[0]
    if not file_part or not (root / file_part).is_file():
        findings.append(f"ratchet_broken_missing_test_file: {class_id} -> {node}")
        return findings

    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", "--collect-only", "-q", "-p", "no:cov", node],
            cwd=root, capture_output=True, text=True, check=False,
            # tool_limits, not a literal: a hardcoded timeout is itself a ratcheted
            # defect class here (hardcoded_dynamic_invariants), and this gate blocked
            # its own commit over the 120 that used to sit on this line.
            timeout=SMOKE_SUITE_TIMEOUT,
        )
    except subprocess.TimeoutExpired as exc:
        return [f"ratchet_test_could_not_run: {class_id} -> {node}: timeout after {exc.timeout}s"]
    except OSError as exc:
        return [f"ratchet_test_could_not_run: {class_id} -> {node}: {type(exc).__name__}: {exc}"]
    if proc.returncode != 0:
        # COULD_NOT_RUN is never folded into "the class is still gated": an
        # uncollectable node is reported as broken, which is the fail-closed side.
        findings.append(f"ratchet_broken_uncollectable_test: {class_id} -> {node}")
    return findings


def record_crystallization(
    root: Path,
    class_id: str,
    detector_key: str,
    description: str,
    source: str,
) -> dict[str, Any]:
    """Append a crystallization AFTER proving its detector is live and convicting.

    Refuses to record a hollow entry -- one pointing at a detector that does not
    exist in the live registry or that is blind (never convicts its own control).
    Recording such an entry would be theater: the ratchet would claim a class is
    permanently gated while nothing catches it. Raises ``RatchetError`` instead.
    Returns the appended entry.
    """
    if detector_key not in _live_keys():
        raise RatchetError(
            f"refusing hollow crystallization: detector_key {detector_key!r} "
            f"is not in the live registry (class {class_id!r})"
        )
    blind, crashed = _control_failures()
    if detector_key in crashed:
        detail = crashed[detector_key]
        raise RatchetError(
            f"refusing hollow crystallization: detector {detector_key!r} control crashed: {detail}"
        )
    if detector_key in blind:
        raise RatchetError(
            f"refusing hollow crystallization: detector {detector_key!r} is blind "
            f"(does not convict its own H2 control; class {class_id!r})"
        )

    entries = load_registry(root)
    entry: dict[str, Any] = {
        "finding_class_id": class_id,
        "description": description,
        "source": source,
        "detector_key": detector_key,
        "recorded": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    entries.append(entry)
    save_registry(root, entries)
    return entry


def _print_gate(root: Path, ok: bool, findings: list[str]) -> None:
    try:
        count = len(load_registry(root))
    except RatchetError:
        count = 0
    pops = entry_populations(root)
    print(f"[ratchet] recorded defect classes: {count} "
          f"(detector-backed={pops['detector']}, test-backed={pops['test']})")
    print(f"[ratchet] broken-ratchet findings: {len(findings)}")
    for finding in findings:
        print(f"  FINDING {finding}")
    # Reporting politics: print the zeros beside the non-zeros.
    def _n(prefix: str) -> int:
        return sum(1 for f in findings if f.startswith(prefix))

    print(
        f"[ratchet] missing_detector={_n('ratchet_broken_missing_detector')} "
        f"blind_detector={_n('ratchet_broken_blind_detector')} "
        f"detector_could_not_run={_n('ratchet_detector_could_not_run')} "
        f"registry_unreadable={_n('ratchet_registry_unreadable')}"
    )
    print(
        f"[ratchet] missing_test_file={_n('ratchet_broken_missing_test_file')} "
        f"uncollectable_test={_n('ratchet_broken_uncollectable_test')} "
        f"test_could_not_run={_n('ratchet_test_could_not_run')} "
        f"missing_control={_n('ratchet_broken_missing_control')} "
        f"test_without_control={_n('ratchet_test_entry_without_control')}"
    )
    if pops["test"]:
        # The asymmetry, stated on every run rather than buried in a docstring.
        print(
            "[ratchet] NOTE: a test-backed class is verified only as 'still collectable "
            "+ mutant control on disk'. A detector-backed class is verified against H2, "
            "which proves it still convicts. The second is a stronger promise."
        )
    print(f"[ratchet] limit: {H3_LIMIT}")
    if ok:
        print("[ratchet] OK - every recorded class maps to a live, convicting detector.")
        return

    # Untagged on purpose: this is a human-readable header, not the gate's
    # tagged verdict line. `[ratchet] BLOCKED ...` would match the same
    # `\[tag\]\s+(?:FAIL|BLOCKED|...)` shape `gate_runner` looks for to mean
    # "the subject was condemned" -- printed unconditionally here, it would
    # say that even on a run whose only finding is a corrupt, unread registry
    # (an instrument failure), hiding a dead instrument behind a false
    # conviction. The two tagged verdicts below carry that distinction.
    print("ratchet BLOCKED - a recorded defect class is no longer gated (broken ratchet).")
    # `ratchet_registry_unreadable` means the gate never got to look at any
    # entry -- an instrument failure -- while every other finding prefix means
    # it read the registry and convicted a specific broken class. Folding both
    # into one tagged line would let a corrupt registry (nothing was checked)
    # read as "the ratchet is broken" (something WAS checked and failed).
    cnr_findings = [f for f in findings if f.startswith("ratchet_registry_unreadable:")]
    fail_findings = [f for f in findings if not f.startswith("ratchet_registry_unreadable:")]
    if fail_findings:
        print(
            f"[ratchet-audit] FAIL: {len(fail_findings)} recorded defect class(es) no longer "
            f"gated; first: {fail_findings[0]}"
        )
    if cnr_findings:
        print(
            f"[ratchet-audit] COULD_NOT_RUN: registry unreadable, 0 of the recorded classes "
            f"could be checked; first: {cnr_findings[0]}",
            file=sys.stderr,
        )


def _print_report(root: Path) -> None:
    try:
        entries = load_registry(root)
    except RatchetError as exc:
        print(f"[ratchet] registry unreadable: {exc}")
        return
    live = _live_keys()
    blind = _blind_keys()
    print(f"[ratchet] recorded defect classes: {len(entries)}")
    for entry in entries:
        key = entry.get("detector_key", "<unknown>")
        status = "missing" if key not in live else ("blind" if key in blind else "live+convicts")
        print(
            f"  {entry.get('finding_class_id', '<unknown>'):40s} -> "
            f"{key:34s} [{status}]  ({entry.get('source', '?')})"
        )
    print(f"[ratchet] limit: {H3_LIMIT}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="simplecode ratchet-audit",
        description="H3 findings ratchet (ADR-0008): recorded defect classes stay gated forever.",
    )
    ap.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    ap.add_argument(
        "--gate", action="store_true",
        help="Exit 1 if any recorded class's detector is missing or blind (broken ratchet)",
    )
    ap.add_argument(
        "--record", nargs=2, metavar=("CLASS_ID", "DETECTOR_KEY"), default=None,
        help="Record a crystallization (refused unless the detector is live and convicting)",
    )
    ap.add_argument("--description", default="", help="Human description of the defect class (with --record)")
    ap.add_argument("--source", default="audit", help="Origin of the finding: audit/ADR/session (with --record)")
    ap.add_argument("--report", action="store_true", help="Print the recorded-class table (the default)")
    args = ap.parse_args(argv)

    root = args.root.resolve()

    if args.record is not None:
        class_id, detector_key = args.record
        try:
            entry = record_crystallization(root, class_id, detector_key, args.description, args.source)
        except RatchetError as exc:
            print(f"[ratchet] REFUSED: {exc}")
            print(f"[ratchet-audit] FAIL: refused hollow crystallization for {class_id!r} -> {detector_key!r}: {exc}")
            return 1
        print(f"[ratchet] recorded {entry['finding_class_id']} -> {entry['detector_key']}")
        return 0

    if args.gate:
        ok, findings = verify_ratchet(root)
        _print_gate(root, ok, findings)
        return 0 if ok else 1

    _print_report(root)
    return 0


if __name__ == "__main__":
    sys.exit(main())
