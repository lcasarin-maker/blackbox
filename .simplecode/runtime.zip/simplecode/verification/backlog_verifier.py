#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""backlog_verifier -- cryptographic and mechanical anti-fraud for closed debt tasks.

Zero-Debt Invariant:
A task cannot simply be declared 'done', 'closed', or moved to `tasks/done/`.
For a task to be validly resolved, the finding it records MUST NO LONGER REPRODUCE
in the working tree.

If a task is marked as closed or placed in `tasks/done/` but its finding still reproduces,
this organ flags a FRAUD_DETECTED error, returns the task to `tasks/backlog/`,
and exits with code 1 to block the gate.
"""
from __future__ import annotations

import argparse
import contextlib
import contextvars
import hashlib
import json
import logging
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import tomllib
from concurrent.futures import ThreadPoolExecutor

import yaml
from collections import Counter
from collections.abc import Mapping
from datetime import date, datetime
from pathlib import Path
from typing import NamedTuple

from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_detectores, emit_hallazgos
from simplecode.utils.tool_limits import GIT_O1_TIMEOUT, compute_proportional_timeout, xdist_workers
from simplecode.utils.unified_memory_slots import unified_memory_slots
from simplecode.verification import close_check_trace, finding_backlog, ledger_schema

logger = logging.getLogger("backlog_verifier")
logging.basicConfig(level=logging.INFO, format="%(message)s")

PREFIX = "DEBT"
FINDINGS_START = "<!-- findings:start -->"
FINDINGS_END = "<!-- findings:end -->"

# Trusted executables for verification_command and queue-job commands (SPEC GS2-214).
# `make` and `pre-commit` were REMOVED (W1C): both dispatch to arbitrary,
# unwhitelisted shell (a Makefile recipe and a hook `entry:` are shell lines),
# which defeats the Axiom 11 ban on `-c`, `--eval` and pipes. Measured before
# removal: 0 of 46 task files under tasks/ used either one.
COMMAND_WHITELIST = (
    "pytest",
    "ruff",
    "python",
    "python3",
    "simplecode",
    "pyright",
)
PROHIBITED_COMMANDS = ("echo", "true", "false", "sleep", "exit", "touch", "rm", "cat", "eval")
SHELL_OPERATORS_RE = re.compile(r"[;&|`$><]")
# Runners the kit keeps out on purpose (`make` runs any recipe; `pre-commit` is
# allowed in one exact shape): a build_tools.txt line must not re-admit them
# wholesale. H1 SPEC-L243, 2026-09-28; no fleet repo declared either.
_UNDECLARABLE = ("make", "pre-commit")

# --- Non-Python toolchains (DEBT-KIT-ASSUMES-PYTHON, 2026-09-04) --------------
# `COMMAND_WHITELIST` above is the KIT's baseline, and the kit is written in
# Python. A satellite whose product is not Python could name no build tool at
# all: cargo, go, npm, mvn and dotnet were all REJECTED, so RePic's 33 tasks each
# ended in `python -m tools.verify_finding cargo-test`, a Python wrapper that
# shells out to cargo. Their words: "no es ingenio, es la unica forma de
# expresarlo".
#
# The decisive argument is not convenience. `verification_command` is the field
# the whole closing contract rests on, and forcing a wrapper puts A LAYER BETWEEN
# THE GATE AND THE SUBJECT: if the wrapper breaks or lies, the gate reads the
# wrapper. That is the failure family this fleet spent two days cataloguing --
# reading the instrument instead of the subject -- installed by contract.
#
# THE FIX IS NOT A LONGER LIST. Adding cargo/go/npm/mvn/dotnet here breaks again
# at the next language, which is the same answer DEBT-ZERO-DEBT-BLIND-TO-UNTRACKED
# explicitly rules out for directories, citing this very ficha. Instead the REPO
# declares its own toolchain, once, in a reviewable file:
#
#     .simplecode/build_tools.txt      # one bare executable name per line
#     cargo                            # '#' comments allowed
#
# What that buys: the kit stops enumerating the world's languages, and a
# satellite's toolchain becomes a declaration someone signed rather than an
# omission someone routed around with a wrapper.
#
# What it does NOT relax, and this is the whole safety argument: a declared name
# goes through `_validate_verification_cmd` UNCHANGED -- the no-op ban, the
# operator ban and the inline-code ban all still apply. The declaration widens
# WHICH BINARY may be named. It never widens what may be done to it.
#
# What stays rejected on purpose: a bare name only. No path separator (so a
# declaration cannot point at a script in the repo), and nothing already in
# PROHIBITED_COMMANDS. `make` and `npm run` remain nameable by a repo that
# declares them -- with the cost stated here rather than hidden: both dispatch
# arbitrary shell from a manifest (a Makefile recipe, a package.json script), so
# a repo declaring them accepts that its verification_command's real body lives
# somewhere this validator cannot read. W1C removed them from the KIT baseline
# for exactly that reason, and that removal stands; what changes is that the
# choice now belongs to the repo that bears it.
BUILD_TOOLS_RELPATH = Path(".simplecode") / "build_tools.txt"


def _is_gitignored(root: Path, relpath: Path) -> bool:
    """True when git would ignore `relpath` under `root`. Never raises.

    An unusable git answers False: this powers a WARNING, and a warning printed
    because git was missing would be noise about the wrong thing.
    """
    try:
        out = subprocess.run(
            ["git", "check-ignore", "-q", relpath.as_posix()],
            cwd=root, capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return out.returncode == 0


def declared_build_tools(root: Path | None) -> tuple[str, ...]:
    """Executables this repo declared for its own toolchain, validated.

    An unreadable or absent declaration yields `()` -- the kit baseline alone,
    which is the fail-closed side: a repo whose declaration cannot be read gets
    LESS permission, never more.
    """
    if root is None:
        return ()
    path = root / BUILD_TOOLS_RELPATH
    if not path.is_file():
        return ()
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ()
    # A declaration git will not carry is a local workaround wearing the shape of
    # a contract. Reported by the cuenza session HOURS after this shipped: their
    # `.gitignore` swallows `.simplecode/*` with only two negations, so the file
    # stayed on the machine that wrote it and vanished in any clone -- where
    # `dotnet test` is rejected again. Measured across the fleet the same day:
    # 13 of 16 repos would ignore it.
    #
    # The check is here, in the reader, because this is where both facts are
    # known at once: that a declaration exists, and that it will not travel. It
    # WARNS rather than refusing -- the toolchain is still correct for this
    # working tree, and turning a distribution problem into a local rejection
    # would block the repo that did nothing wrong.
    if _is_gitignored(root, BUILD_TOOLS_RELPATH):
        print(
            f"[build-tools] WARNING: {BUILD_TOOLS_RELPATH} is git-ignored in this "
            f"repo, so this toolchain declaration will NOT travel to a clone or a "
            f"satellite -- there, every command it authorises is rejected again. "
            f"Add `!{BUILD_TOOLS_RELPATH.as_posix()}` to .gitignore after the "
            f"`.simplecode/*` line.",
            file=sys.stderr,
        )
    tools: list[str] = []
    for line in raw.splitlines():
        name = line.split("#", 1)[0].strip()
        if not name:
            continue
        # A declaration is a NAME, never a path and never a command line.
        if "/" in name or "\\" in name or " " in name:
            continue
        if name in PROHIBITED_COMMANDS or name in _UNDECLARABLE or SHELL_OPERATORS_RE.search(name):
            continue
        tools.append(name)
    return tuple(dict.fromkeys(tools))


def _unquoted(raw: str) -> str:
    """`raw` with the contents of quoted regions removed.

    Second site named in the same ficha: the contract rejected `;`, `|` and `&&`
    inside a QUOTED argument, where they are DATA. Nothing is executed through a
    shell -- the command runs as `_run_bounded(shlex.split(cmd))` with no
    `shell=True` -- so an operator inside a quoted token is one literal argv
    character and can start nothing. Rejecting it refused legitimate commands
    (a regex argument, a JSON literal) for a risk the execution path does not
    carry. Operators OUTSIDE quotes stay banned, unchanged.
    """
    out: list[str] = []
    quote: str | None = None
    for ch in raw:
        if quote is None and ch in ("'", '"'):
            quote = ch
        elif quote is not None and ch == quote:
            quote = None
        elif quote is None:
            out.append(ch)
    return "".join(out)

# gate_runner writes verification_command = " ".join(the command it just ran)
# (gate_runner.py:172) into every finding it registers. In a satellite with a
# vendored runtime (.simplecode/run.py + runtime.zip, not a pip-installed
# simplecode package -- see cli_new._portable_runner), that command is ALWAYS
# one of these two exact, self-authored shapes -- never user-typed. Measured
# on Atlas 2026-08-25: with neither shape trusted, 9 gate_runner-authored
# findings had NO valid verification_command in ANY of the 4 forms a satellite
# can execute (`python .simplecode/run.py <mod>` rejected as a script path,
# `python -m simplecode.X` ModuleNotFoundError with no installed package,
# `pre-commit run ...` off the whitelist, `simplecode check` needs a Makefile
# a satellite doesn't have) -- a contract the gate itself cannot satisfy.
#
# Trusting the literal pre-commit invocation string (not the `pre-commit`
# binary generally) closes that gap without reopening the arbitrary-shell risk
# W1C removed: only this exact gate_runner-generated shape is accepted, so an
# attacker-supplied verification_command still cannot smuggle a custom
# `--hook-stage`/hook selection or extra flags through pre-commit's `entry:`
# shell lines.
#
# EXCEPTION (closes DEBT-FLEET-20's documented residual gap): the pre-push
# stage shape is REJECTED as a task's verification_command. That command is
# executed by the fraud audit, which itself runs inside the pre-push hook, so
# the invocation is self-recursive by construction -- it relaunches the whole
# pre-push suite (pyright, coverage, this very audit) and can only time out as
# COULD_NOT_RUN (measured: migracion_atom, ticket
# DEBT-gate-failure-pre-push-command-pre-commit-3d267f50, reverted as fraud
# 2026-08-28 and re-closed with a scoped command; its commit f97a937 records
# the measured timeout). The rejection is loud at contract time -- not a
# silent execution skip -- so the author is pointed at a scoped command. The
# shape stays trusted for queue-job commands, which a headless runner
# dispatches OUTSIDE the pre-push hook, where it is not recursive.
_TRUSTED_PRE_COMMIT_INVOCATION_RE = re.compile(
    r"^pre-commit run --config \.pre-commit-config\.yaml --hook-stage (pre-commit|pre-push)(?: --all-files)?$"
)
_SELF_RECURSIVE_PRE_PUSH_FRAGMENT = "--hook-stage pre-push"

# --- EXPECT-contract verification dispositions (ADR-0005 M1) ------------------
# The verification path decides between THREE outcomes, never two. Collapsing
# "the instrument could not run here" into "the finding reproduces" is the exact
# conflation this harvest removes: a bare whole-suite `pytest` that cannot start
# (missing dep, offline, timeout) is NOT evidence the fix regressed.
#
#   PASS           -- the command ran to completion and exited 0 (and, when a
#                     task declares `expect:`, that success marker was present in
#                     the combined stdout+stderr).
#   REPRODUCES     -- the command ran to completion and exited nonzero, OR it
#                     exited 0 but a declared `expect:` marker was absent. For a
#                     done-task this stays FRAUD_DETECTED (severity unchanged).
#   COULD_NOT_RUN  -- the command could not execute at all: executable not found
#                     (FileNotFoundError / OSError launching it) or it timed out
#                     (subprocess.TimeoutExpired). Reported honestly as
#                     instrument-down: never a silent pass, never mislabeled
#                     FRAUD, and (unlike a genuine reproduce) never auto-reverted.
#   NOT_APPLICABLE -- the command was deliberately NOT run, because running it
#                     here cannot answer the question: it re-invokes this very
#                     audit (recursion) or the allowlist refuses it. Counted and
#                     listed with ids, never blocking, never COULD_NOT_RUN -- no
#                     instrument went down (voto de Luis, 2026-10-06, C/D).
VERIFY_OK = "OK"
VERIFY_REPRODUCES = "REPRODUCES"
VERIFY_COULD_NOT_RUN = "COULD_NOT_RUN"
VERIFY_NOT_APPLICABLE = "NOT_APPLICABLE"

# The declared, non-blocking verdicts a closed ficha can receive instead of
# COULD_NOT_RUN. Each prints on its own line with the ficha ids; see
# `_report_declared_verdicts`.
NOT_APPLICABLE_RECURSION = "recursion"
NOT_APPLICABLE_OUTSIDE_ALLOWLIST = "outside allowlist"
VERDICT_PROSE_NOT_RECHECKABLE = "prose findings not re-checkable"

# A fenced ```json queue-job block (the ```json + inline `{"name": ...}` form
# emitted by older generators is accepted too).
QUEUE_JOB_BLOCK_RE = re.compile(r"```json(?:[ \t]+queue-job)?[ \t]*\n(.*?)```", re.S)

# Directories under tasks/ whose task files MUST satisfy the full contract.
# A task is either open (`backlog`) or closed (`done`); candidates that are not
# tasks belong in project documentation, never in a hidden task queue.
#
# Deliberately NOT derived from `ledger_schema.GOBERNADAS`, which since 2026-09-29 also
# governs `roadmap/` (Atlas DGX-619): a roadmap ficha must be schema-valid and keep its
# lines, but it is not debt and its close_check is not re-run here. The two sets answer
# different questions; `tests/test_roadmap_gobernada_sin_contar_deuda.py` pins both.
GOVERNED_TASK_DIRS = ("backlog", "done")

# --- verification_command execution bound (replaces a flat timeout=30) -------
# The old fixed 30s killed any legitimate suite that outgrew it. `pytest` cost
# scales with the test corpus, which IS measurable before the call, so the
# pytest case gets a proportional bound and everything else keeps a fixed one.
#
# MEASURED BASIS (this repo, 2026-08-23):
#   $ python3 -c "..."  -> tests/**/*.py = 350,198 bytes
#   $ /usr/bin/time python3 -m pytest -q -> WALL 2.54 s
#   => 137,873 bytes of test source processed per second.
# TASK_VERIFICATION_BYTES_PER_SEC was set to 10,000 B/s: a deliberate ~14x
# headroom over the measured rate, so a suite may become fourteen times slower
# per byte (cold caches, slower CI box, added I/O-bound tests) before the
# bound fires. It is a hang detector, not a performance budget.
# Re-measured live (aequitas_os, 2026-08-28): this repo's tests aren't pure
# unit tests like simplecode's own -- they hit real Postgres/services per
# test, a fundamentally heavier cost per byte. `_test_corpus_bytes` =
# 1,682,665; a real, clean `coverage_target -q` run took 220.65s wall
# (1812 passed, 7 skipped). Effective rate: 1,682,665 / 220.65 ~= 7,625 B/s
# -- SLOWER than the 10,000 B/s divisor above, meaning that budget had
# negative headroom for this repo's actual corpus, not just thin margin:
# the computed 198s bound was timing out a real, passing 220.65s run.
# Lowered to 5,000 B/s: 30 + 1,682,665/5,000 ~= 367s, ~1.66x margin over the
# 220.65s measurement (same margin philosophy as
# TASK_VERIFICATION_WHOLE_REPO_SCAN_TIMEOUT's own re-baseline above).
TASK_VERIFICATION_BYTES_PER_SEC = 5_000.0
# Interpreter startup + plugin import + collection, none of which scales with
# the corpus bytes; also the whole bound for non-pytest commands (ruff, a
# module run), which are single-pass and bounded by design.
TASK_VERIFICATION_BASE_TIMEOUT = 30.0
# Whole-repo scanners (zero_debt, backlog_verifier, adversarial_judge) are
# NOT single-pass by cost -- they walk every tracked file / every governed
# task, so they scale with repo size exactly like pytest scales with test
# corpus size. Measured live (this repo, 2026-08-27): a task file citing
# `backlog_verifier --gate` as its OWN verification_command timed out at the
# flat 30s bound once the repo grew to ~944 tracked files / ~800 task files
# (real wall time ~90s), false-flagging a passing gate as COULD_NOT_RUN. A
# fixed generous allowance, not a full proportional model like pytest's (no
# single cheap byte-count proxy for "cost of scanning the whole repo" the way
# test-source bytes proxy pytest cost) -- same spirit as the pytest fix
# above, narrower scope.
# Re-measured live (aequitas_os, 2026-08-27, later same day): task count grew
# past ~970 files and the real wall time grew to 281s, exceeding the 240s
# bound set above from that morning's ~90s measurement -- this budget scales
# with a repo's growing task count and needs headroom above the latest
# measurement, not just the first one. 450s gives ~1.6x margin over 281s.
TASK_VERIFICATION_WHOLE_REPO_SCAN_TIMEOUT = 450.0
# A satellite's own whole-repo scanner (Atlas's `tools.finding_has_mechanism`: 43.8s and 43.5s, rc=0,
# against the 30s base bound, so a passing close_check read as COULD_NOT_RUN) is not a kit module, and
# listing it in the tuple below would couple the kit to one satellite's script. The repo declares its
# own, in `.simplecode/whole_repo_scan_commands.json`, using the optional declaration format:
#
#     {"owner": "...", "date": "YYYY-MM-DD", "reason": "...", "commands": ["tools.finding_has_mechanism"]}
#
# Each command is matched as an EXACT token of the close_check (a module name after `-m`, or a script
# path), never a substring. Missing or malformed: nothing declared (opt-in), and the note is printed by
# `main`, so a typo shows instead of silently withdrawing the longer budget.
WHOLE_REPO_SCAN_DECLARATION_RELPATH = Path(".simplecode") / "whole_repo_scan_commands.json"


def load_declared_whole_repo_scan_commands(root: Path) -> tuple[frozenset[str], str]:
    """(declared command tokens, note). Empty set plus the reason when nothing is declared."""
    path = root / WHOLE_REPO_SCAN_DECLARATION_RELPATH
    label = WHOLE_REPO_SCAN_DECLARATION_RELPATH.as_posix()
    if not path.is_file():
        return frozenset(), f"{label} not declared"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return frozenset(), f"{label} is unreadable ({exc}); nothing declared"
    if not isinstance(data, dict):
        return frozenset(), f"{label} is not a JSON object; nothing declared"
    missing = [f for f in ("owner", "date", "reason") if not str(data.get(f, "")).strip()]
    commands = data.get("commands")
    if missing or not isinstance(commands, list) or not commands or not all(isinstance(c, str) and c.strip() for c in commands):
        return frozenset(), f"{label} needs owner, date, reason and a non-empty list of `commands`; nothing declared"
    return frozenset(c.strip() for c in commands), f"{label}: {len(commands)} command(s) declared by {data['owner']} ({data['date']})"


TASK_VERIFICATION_WHOLE_REPO_SCAN_MODULES = (
    "simplecode.worktree.zero_debt",
    "simplecode.verification.backlog_verifier",
    "simplecode.verification.adversarial_judge",
)
# Hard ceiling. A verification command still running after ten minutes is
# hung or interactive; either way the gate must not wait on it forever.
TASK_VERIFICATION_MAX_TIMEOUT = 600.0

# pyright is single-pass but its cost scales with how much python source it
# has to type-check, the same shape as pytest scaling with test-corpus bytes.
# Measured live (aequitas_os worktree busy-jackson-375a20, 2026-08-28): pyright
# over backend/ (915 files, 145,818 lines, 5,202,888 bytes) took 46.189s cold
# / 27.482s warm -- both exceed the flat 30s base bound regardless of anything
# in that repo. Measured rate: 5,202,888 B / 46.189s ~= 112,635 B/s.
# TASK_VERIFICATION_PYRIGHT_BYTES_PER_SEC is set to 10,000 B/s, the same ~11x
# headroom philosophy as TASK_VERIFICATION_BYTES_PER_SEC above.
TASK_VERIFICATION_PYRIGHT_BYTES_PER_SEC = 10_000.0

# Modules whose ENTIRE job is to shell out to a bare `pytest` invocation
# internally -- their declared verification_command is a one-level wrapper
# (`python .simplecode/run.py <module>` or `python -m <module>`), not the
# `pytest ...` shape `_is_pytest_invocation` matches, so they need to be
# named explicitly to get the same proportional bound.
# Measured live (aequitas_os worktree busy-jackson-375a20, 2026-08-28):
# `simplecode.verification.coverage_target`'s verification_command is
# `python .simplecode/run.py simplecode.verification.coverage_target -q`;
# internally it does `subprocess.run(["pytest", ...])`. Two clean runs took
# 207.79s / 201.99s (1812 tests) -- as proportional to test-corpus bytes as
# a bare pytest call, since a bare pytest call is what it makes -- but the
# wrapper shape never matched `_is_pytest_invocation`, so it fell through to
# the flat 30s bound.
TASK_VERIFICATION_PYTEST_WRAPPER_MODULES = (
    "simplecode.verification.coverage_target",
)


def _reject_inline_code_flags(tokens: list[str], raw_cmd: str,
                              prefixes: tuple[str, ...] = ("-c", "-e"),
                              long_flags: tuple[str, ...] = ("--eval",)) -> str | None:
    """Rule 1 of 2: no way to smuggle a PROGRAM into the interpreter.

    Returns the rejection reason, or None when nothing prohibited is present.
    A separate function from the target scan below because it is a different
    security rule with a different failure: this one refuses code supplied
    INLINE, the other refuses a target that is a FILE instead of a module.
    Neither subsumes the other -- `python3 -c...` has no target to find, and
    `python3 evil.py` carries no inline flag.
    """
    # Reject inline-code / eval evasion in EVERY attached form, not just the
    # spaced `-c` / `-e` / `--eval` tokens. `shlex.split` keeps an interpreter
    # flag glued to its value as one token, so `python3 -cprint(1)` and
    # `python3 -c__import__(os).system(id)` arrive as a single `-c...`/`-e...`
    # token that the old exact-match check waved through -- and this string is
    # then EXECUTED via _run_bounded(shlex.split(cmd)) whenever a verifier runs
    # the command (by hand since 2026-09-27; no hook runs the fraud audit).
    # Convict any argument whose first two characters are one of `prefixes`,
    # plus the bare `-` token (reads the program from stdin).
    for index, tok in enumerate(tokens[1:], start=1):
        if any(tok == flag or tok.startswith(f"{flag}=") for flag in long_flags):
            return f"Prohibited inline code execution flag in verification_command: {raw_cmd}"
        if tok == "-":
            return f"Prohibited stdin program source ('-') in verification_command: {raw_cmd}"
        is_python = _is_python_executable(Path(tokens[0]).name)
        is_module_dispatch = is_python and (
            tok == "-m"
            or re.fullmatch(r"-(?:[bBdEhiIOPqRsSuvVx]*m(?:[A-Za-z_][\w.]*)?)", tok) is not None
        )
        is_simplecode_dispatch = is_python and tok == ".simplecode/run.py"
        if is_module_dispatch or is_simplecode_dispatch:
            target = tokens[index + 1] if index + 1 < len(tokens) else ""
            attached_module = is_python and tok != "-m" and re.fullmatch(
                r"-(?:[bBdEhiIOPqRsSuvVx]*m[A-Za-z_][\w.]*)", tok
            ) is not None
            if attached_module or (target and not target.startswith("-")):
                break  # remaining tokens belong to the dispatched module
        if _short_option_has_inline_code(tok, prefixes, python_tool=is_python):
            return f"Prohibited inline code execution flag in verification_command: {raw_cmd}"
    return None


def _short_option_has_inline_code(
    tok: str, prefixes: tuple[str, ...], *, python_tool: bool,
) -> bool:
    if not tok.startswith("-") or tok.startswith("--"):
        return False
    for letter in tok[1:]:
        if f"-{letter}" in prefixes:
            return True
        if python_tool and letter in "WX":
            return False  # remaining characters are the option's attached value
        # Declared tools may cluster tool-specific flags (`bash -lc ...`).
        # Continue searching the cluster so an unknown leading flag cannot
        # hide an inline-code flag later in the same token.
    return False


def _parse_python_option_cluster(
    tokens: list[str], index: int, raw_cmd: str
) -> tuple[bool | None, int, str | None]:
    """Parse a short Python flag cluster; None means keep scanning options."""
    flags = tokens[index][1:]
    for offset, letter in enumerate(flags):
        if letter == "m":
            attached_target = flags[offset + 1:]
            target_index = index + 1
            target = attached_target or (tokens[target_index] if target_index < len(tokens) else "")
            if not target.strip() or (not attached_target and target.startswith("-")):
                return False, index + 1, f"Missing target module name after -m in verification_command: {raw_cmd}"
            return True, target_index + (0 if attached_target else 1), None
        if letter in "WX":
            if offset == len(flags) - 1:
                value_index = index + 1
                if value_index >= len(tokens) or not tokens[value_index]:
                    return False, index + 1, f"Missing value for Python interpreter option -{letter}: {raw_cmd}"
                return None, value_index + 1, None
            return None, index + 1, None  # attached -W/-X value consumes the remainder
        if letter not in "bBdEhiIOPqRsSuvVx":
            return False, index + 1, f"Unsupported Python interpreter option in verification_command: {raw_cmd}"
    return None, index + 1, None


def _module_target(tokens: list[str], index: int, flag: str, raw_cmd: str) -> tuple[bool, str]:
    target_index = index + 1
    if target_index >= len(tokens) or not tokens[target_index].strip() or tokens[target_index].startswith("-"):
        return False, f"Missing target module name after {flag} in verification_command: {raw_cmd}"
    return True, "OK"


def _require_module_execution_target(tokens: list[str], raw_cmd: str) -> tuple[bool, str]:
    """Rule 2 of 2: the command must dispatch a MODULE, never a script path.

    The only function here that returns True: reaching a valid `-m <module>`
    or `.simplecode/run.py <module>` is what ACCEPTS a command, so every
    other exit below is a refusal. Kept as one function because the walk
    carries an index across flag-with-argument pairs (`-W`, `-X`) -- cutting
    it further would mean passing that cursor between halves, which is the
    extraction that buys a smaller number and a worse read.
    """
    # Scan for execution target: must find `-m <module>` or `.simplecode/run.py <module>`.
    # A bare script path (`python3 evil.py` or `python -u evil.py`) runs arbitrary in-repo code
    # inside the gate, so it is refused -- the remediation contract must dispatch a module, not a file.
    i = 1
    while i < len(tokens):
        tok = tokens[i]
        if tok == "-m":
            return _module_target(tokens, i, tok, raw_cmd)
        if tok == ".simplecode/run.py":
            return _module_target(tokens, i, tok, raw_cmd)
        if not tok.startswith("-"):
            return (
                False,
                "Python command must use the module form 'python -m <module>' or the vendored "
                f"'python .simplecode/run.py <module>' launcher, not a script path: {raw_cmd}",
            )
        if tok.startswith("--"):
            return False, f"Unsupported Python interpreter option in verification_command: {raw_cmd}"
        accepted, next_index, error = _parse_python_option_cluster(tokens, i, raw_cmd)
        if error:
            return False, error
        if accepted:
            return True, "OK"
        i = next_index

    return (
        False,
        "Python command must specify a target module via '-m <module>' or the vendored "
        f"'.simplecode/run.py <module>' launcher: {raw_cmd}",
    )


def _python_module_dispatch(tokens: list[str]) -> tuple[str, list[str]] | None:
    """Return the dispatched module and its arguments for either supported launcher."""
    index = 1
    while index < len(tokens):
        argument = tokens[index]
        if argument == ".simplecode/run.py":
            return (tokens[index + 1], tokens[index + 2:]) if index + 1 < len(tokens) else None
        if argument == "-m":
            return (tokens[index + 1], tokens[index + 2:]) if index + 1 < len(tokens) else None
        if not argument.startswith("-") or argument.startswith("--"):
            return None
        accepted, next_index, error = _parse_python_option_cluster(tokens, index, " ".join(tokens))
        if error:
            return None
        flags = argument[1:]
        if accepted:
            module = flags.split("m", 1)[1]
            if module:
                return module, tokens[index + 1:]
            return (tokens[index + 1], tokens[index + 2:]) if index + 1 < len(tokens) else None
        index = next_index
    return None


def _trusted_pre_commit_verdict(
    normalized: str, *, as_task_verification: bool, original: str,
) -> tuple[bool, str]:
    """Validate the one gate_runner-authored pre-commit argument shape."""
    if not _TRUSTED_PRE_COMMIT_INVOCATION_RE.fullmatch(normalized):
        return False, (
            f"pre-commit is restricted to the trusted gate_runner invocation "
            f"shape: {original}"
        )
    if as_task_verification and _SELF_RECURSIVE_PRE_PUSH_FRAGMENT in normalized:
        return False, (
            f"verification_command '{original}' relaunches the whole pre-push suite from "
            "inside the pre-push fraud audit that executes it -- self-recursive by "
            "construction. Use a scoped command that proves the specific fix, e.g. "
            "'python3 -m simplecode.verification.finding_backlog --root . --gate'"
        )
    return True, "OK"


def _validate_python_pre_commit_dispatch(
    tokens: list[str], raw_cmd: str, *, as_task_verification: bool, root: Path | None,
) -> tuple[bool, str]:
    """Validate the interpreter before restricting a pre-commit module dispatch."""
    trusted_verdict = _validate_trusted_binary(tokens, raw_cmd, Path(tokens[0]).name, root)
    if not trusted_verdict[0]:
        return trusted_verdict
    dispatch = _python_module_dispatch(tokens)
    if dispatch is None or dispatch[0] != "pre_commit":
        return trusted_verdict
    _, arguments = dispatch
    normalized = "pre-commit" + (f" {shlex.join(arguments)}" if arguments else "")
    return _trusted_pre_commit_verdict(
        normalized, as_task_verification=as_task_verification, original=raw_cmd,
    )


def _validate_python_invocation(tokens: list[str], raw_cmd: str) -> tuple[bool, str]:
    """Both rules, in order, over a `python`-family verification_command.

    Order is LOAD-BEARING and not cosmetic: the inline-code refusal must run
    FIRST, because `python3 -cprint(1)` contains no execution target at all,
    so the target scan alone would refuse it with the wrong reason ("must
    specify a target module") and hide that an inline-code evasion was
    attempted. The string this validates is subsequently EXECUTED via
    `_run_bounded(shlex.split(cmd))` by the fraud audit (run by hand since
    2026-09-27), so the accurate reason is the whole point.
    """
    reason = _reject_inline_code_flags(tokens, raw_cmd)
    if reason is not None:
        return False, reason
    return _require_module_execution_target(tokens, raw_cmd)


# The one path-qualified launcher accepted: the repo's own venv, repo-relative,
# naming a kit tool. Relied on by tasks/done/DEBT-DISPOSICION-DE-BLOQUEOS-SIN-CABLEAR.md
# (`.venv/bin/python -m pytest ...`) and four Atlas fichas (`.venv/bin/python3 ...`).
# Any other path is refused (H1 SPEC-L243): the whitelist used to read only
# `Path(tokens[0]).name`, so `/tmp/evil/pytest` passed as `pytest` and ran
# whatever file sat there. The launcher is trusted only while git confirms `.venv` is
# NOT tracked: a committed `.venv/bin/python` is repo code under a trusted name
# (see `_venv_tracked_reason`).
_VENV_LAUNCHERS = frozenset(f".venv/bin/{name}" for name in COMMAND_WHITELIST)

# A declared tool's interpreter flags: node's `-p`/`--print` evaluate a program
# like `-e`. Kept off the kit's python on purpose -- `python -m pytest -p
# no:cacheprovider` is the common, legitimate form, and python has no `-p`.
_DECLARED_TOOL_INLINE_PREFIXES = ("-c", "-e", "-p")
_DECLARED_TOOL_INLINE_LONG_FLAGS = ("--eval", "--print")


def _is_python_executable(bin_name: str) -> bool:
    """Recognize supported Python interpreter names, including versioned Python 3."""
    return bin_name in {"python", "python3"} or re.fullmatch(r"python3\.\d+", bin_name) is not None


def _venv_tracked_reason(root: Path | None) -> str | None:
    """None when git confirms `.venv` is untracked in `root` (cwd when None); a reason
    otherwise. Fails closed: a git that cannot answer cannot prove the venv untracked."""
    repo = root if root is not None else Path.cwd()
    try:
        out = subprocess.run(
            ["git", "ls-files", "--", ".venv"],
            cwd=repo, capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return f"could not tell whether .venv is tracked in {repo} ({exc})"
    if out.returncode != 0:
        return (f"could not tell whether .venv is tracked in {repo} "
                f"(git ls-files rc={out.returncode}: {out.stderr.strip()[-200:]})")
    if out.stdout.strip():
        return (f".venv is tracked by git in {repo}, so .venv/bin/<tool> runs committed "
                "code, not an installed tool")
    return None


def _reject_path_qualified_executable(executable: str, raw_cmd: str, root: Path | None) -> str | None:
    """The executable must be a bare name resolved by PATH, or an untracked venv launcher."""
    if "/" not in executable and "\\" not in executable:
        return None
    if executable not in _VENV_LAUNCHERS:
        return (
            f"Executable '{executable}' is a path: the whitelist trusts a tool by name, and "
            "a path runs whatever file sits there under that name. Use the bare name, "
            f"or the repo-relative .venv/bin/<tool> for a kit tool: {raw_cmd}"
        )
    reason = _venv_tracked_reason(root)
    if reason is not None:
        return f"Executable '{executable}' refused: {reason}: {raw_cmd}"
    return None


def _validate_trusted_binary(tokens: list[str], raw_cmd: str, bin_name: str,
                             root: Path | None) -> tuple[bool, str]:
    """The whitelist proper: kit baseline or repo declaration, then per-family rules.

    A declared tool gets the inline-code ban (`-c`, `-e`, `-p`, `--eval`,
    `--print`) that the kit's python gets: declaring `bash` or `node` widens which
    binary may be named, never lets it take a program inline (H1 SPEC-L243).
    """
    declared = declared_build_tools(root)
    if bin_name not in COMMAND_WHITELIST and bin_name not in declared:
        hint = (
            f" This repo declares {list(declared)} in {BUILD_TOOLS_RELPATH}."
            if declared else
            f" A non-Python toolchain declares its build tool in {BUILD_TOOLS_RELPATH}"
            " (one bare executable name per line) rather than hiding behind a Python"
            " wrapper, which would put a layer between the gate and the subject."
        )
        return False, (
            f"Executable '{bin_name}' is not in trusted COMMAND_WHITELIST "
            f"{COMMAND_WHITELIST}.{hint}"
        )
    if _is_python_executable(bin_name):
        return _validate_python_invocation(tokens, raw_cmd)
    if bin_name not in COMMAND_WHITELIST:
        reason = _reject_inline_code_flags(
            tokens, raw_cmd, _DECLARED_TOOL_INLINE_PREFIXES, _DECLARED_TOOL_INLINE_LONG_FLAGS)
        if reason is not None:
            return False, reason
    return True, "OK"


def _validate_verification_cmd(raw_cmd: str, *, as_task_verification: bool = True,
                               root: Path | None = None) -> tuple[bool, str]:
    """Whitelist a command (Axiom 11). `as_task_verification=True` means the
    command is a task's verification_command -- the thing the fraud audit
    (run by hand since 2026-09-27) will itself execute -- which additionally
    bans the self-recursive trusted pre-push invocation (see _TRUSTED_PRE_COMMIT_INVOCATION_RE).

    `root`, when given, lets the repo's own `.simplecode/build_tools.txt`
    declaration name a non-Python build tool (DEBT-KIT-ASSUMES-PYTHON). Every
    other check applies to a declared tool unchanged.
    """
    if not raw_cmd:
        return False, "Empty verification_command"
    if SHELL_OPERATORS_RE.search(_unquoted(raw_cmd)):
        return False, f"Prohibited shell injection or pipeline operators in verification_command: {raw_cmd}"
    try:
        tokens = shlex.split(raw_cmd)
    except ValueError as exc:
        return False, f"Malformed verification_command syntax: {exc}"
    if not tokens:
        return False, "Empty verification_command"
    path_reason = _reject_path_qualified_executable(tokens[0], raw_cmd, root)
    if path_reason is not None:
        return False, path_reason
    bin_name = Path(tokens[0]).name
    if bin_name in PROHIBITED_COMMANDS:
        return False, f"Prohibited no-op command '{bin_name}' in verification_command"
    if bin_name == "pre-commit" and _TRUSTED_PRE_COMMIT_INVOCATION_RE.fullmatch(raw_cmd):
        return _trusted_pre_commit_verdict(
            raw_cmd, as_task_verification=as_task_verification, original=raw_cmd,
        )
    if _is_python_executable(bin_name):
        return _validate_python_pre_commit_dispatch(
            tokens, raw_cmd, as_task_verification=as_task_verification, root=root,
        )
    return _validate_trusted_binary(tokens, raw_cmd, bin_name, root)


def _extract_verification_command(content: str) -> str | None:
    """Return the declared verification_command, or None when the field is absent."""
    cmd_m = re.search(r"^verification_command:\s*(.*)$", content, re.M)
    if cmd_m is None:
        return None
    raw_cmd = cmd_m.group(1).strip()
    if (raw_cmd.startswith('"') and raw_cmd.endswith('"')) or (raw_cmd.startswith("'") and raw_cmd.endswith("'")):
        raw_cmd = raw_cmd[1:-1].strip()
    return raw_cmd


def _extract_expect(content: str) -> str | None:
    """Return the optional `expect:` success marker, or None when absent.

    When present, a verification PASSES only if the command exits 0 AND this
    marker is a substring of the combined stdout+stderr (ADR-0005 M1). When the
    field is absent the check keeps exit-code-0 semantics exactly, so no existing
    task changes behavior. An empty/blank marker normalizes to None (a marker
    that matches everything would add nothing and only invite confusion).
    """
    m = re.search(r"^expect:\s*(.*)$", content, re.M)
    if m is None:
        return None
    raw = m.group(1).strip()
    if (raw.startswith('"') and raw.endswith('"')) or (raw.startswith("'") and raw.endswith("'")):
        raw = raw[1:-1]
    return raw or None


def _validate_queue_job(content: str, root: Path | None = None) -> tuple[bool, str]:
    """Validate the mandatory executable ```json queue-job``` block (GS2-214).

    Returns (True, "OK") when at least one fenced json block parses and carries a
    non-empty ``name`` plus a ``command`` that survives the same whitelist as a
    verification_command. Returns (False, "") when no fenced json block exists at
    all -- the caller composes that message, because it depends on what else the
    task is missing.
    """
    blocks = QUEUE_JOB_BLOCK_RE.findall(content)
    if not blocks:
        return False, ""
    last_err = "```json queue-job block is not executable"
    for raw in blocks:
        try:
            job = json.loads(raw)
        except ValueError as exc:
            last_err = f"```json queue-job block is not valid JSON: {exc}"
            continue
        if not isinstance(job, dict) or not str(job.get("name", "")).strip():
            last_err = "```json queue-job block is missing a non-empty 'name' field"
            continue
        job_cmd = str(job.get("command", "")).strip()
        if not job_cmd:
            last_err = "```json queue-job block is missing a non-empty 'command' field"
            continue
        # A queue-job is dispatched by a headless runner OUTSIDE the pre-push
        # hook, so the trusted pre-push invocation is not recursive there.
        ok_cmd, cmd_msg = _validate_verification_cmd(job_cmd, as_task_verification=False, root=root)
        if not ok_cmd:
            last_err = f"```json queue-job command is not executable: {cmd_msg}"
            continue
        return True, "OK"
    return False, last_err


def _is_exempt_done_task(task_path: Path, content: str) -> bool:
    """Check if task is a non-debt historical artifact like a handoff.

    Narrowed under the hardened gate: a session handoff is a dated record of what
    happened, not a unit of work, so it has no remediation job to queue and a
    fabricated one would be decorative. To claim the exemption the file must look
    like exactly that -- HANDOFF- filename, ``id:`` equal to the filename stem,
    and NO ``status:`` field, since a task with lifecycle state is a task. That
    closes the rename escape: moving a governed debt task to HANDOFF-*.md now
    also requires stripping its status and rewriting its id.
    """
    if not task_path.name.startswith("HANDOFF-"):
        return False
    id_m = re.search(r"^id:\s*(\S+)", content, re.M)
    if id_m is None or id_m.group(1).strip() != task_path.stem:
        return False
    return re.search(r"^status:\s*\S+", content, re.M) is None


_CANONICAL_SECTION_NAMES = ("Root Cause", "Regression Test", "Verification Evidence")

# Los niveles de encabezado que valen para una seccion canonica. `##` es el canon y
# `###` se admite porque una seccion colgada de un `## Cierre` es la MISMA seccion,
# escrita por alguien que estaba organizando su ficha.
_NIVELES_CANONICOS = (2, 3)
_ENCABEZADO_RE = re.compile(r"^(#{1,6})\s+(.*?)\s*$")


def _seccion_canonica(content: str, name: str) -> tuple[str | None, str, str | None]:
    """(encabezado aceptado, cuerpo, encabezado descartado) para la seccion `name`.

    Hasta hoy esto era `re.compile(r"^##\\s+Root Cause\\s*$...")`: el encabezado tenia
    que ser EXACTO, asi que `## Root Cause -- the scale hypothesis is dead` y un
    `### Root Cause` colgando de un `## Cierre` se rechazaban con el contenido correcto
    debajo. Lo reportaron `o2o` y `agente_inmobiliario` en la encuesta de flota
    (2026-09-05): *"Eso no mejoro ninguna ficha; solo la hizo pasar."* Es formato
    disfrazado de contrato.

    Lo que se conserva es el anclaje: el encabezado tiene que EMPEZAR por el nombre
    canonico (`## Root Cause ...`), no contenerlo en cualquier sitio, para que
    `## Sobre el Root Cause hablamos manana` siga sin ser la seccion.

    El cierre de la seccion es un encabezado de nivel MENOR O IGUAL al suyo, y por eso
    esto es una funcion y no un regex: `(?=^##\\s|\\Z)` no puede expresar «de mi nivel o
    mas alto», asi que un `## Root Cause` con un `### Detalle` dentro habria perdido el
    cuerpo entero al relajar el patron -- un falso rechazo nuevo introducido por el
    arreglo de otro.

    El tercer valor es el encabezado que existe con ese nombre pero NO en un nivel
    valido (`# Root Cause`, `#### Root Cause`): sigue habiendo rechazo, y sigue habiendo
    un mensaje que dice que se encontro y donde, en vez de un «falta» que manda al
    lector a buscar una seccion que esta delante de sus ojos.
    """
    lineas = content.split("\n")
    descartado: str | None = None
    for idx, linea in enumerate(lineas):
        m = _ENCABEZADO_RE.match(linea)
        if m is None:
            continue
        nivel, titulo = len(m.group(1)), m.group(2)
        if not re.match(rf"^{re.escape(name)}\b", titulo):
            continue
        if nivel not in _NIVELES_CANONICOS:
            descartado = descartado or linea.strip()
            continue
        cuerpo: list[str] = []
        for siguiente in lineas[idx + 1:]:
            m2 = _ENCABEZADO_RE.match(siguiente)
            if m2 is not None and len(m2.group(1)) <= nivel:
                break
            cuerpo.append(siguiente)
        return linea.strip(), "\n".join(cuerpo), descartado
    return None, "", descartado

# The exact scaffold `finding_backlog._TEMPLATE` seeds each section with (an
# italic "fill in when closing" placeholder). A section still holding only
# this line was never actually filled in -- closing a task without editing it
# out is the same as leaving the section empty.
_PLACEHOLDER_LINE_RE = re.compile(r"^_\(Fill in when closing:.*\)_$", re.M)


def _validate_resolution_narrative(task_path: Path, content: str) -> tuple[bool, str]:
    """A closed task must carry the ONE canonical resolution narrative (PI-011 / CC-56).

    `validate_task_contract`'s other checks prove a `verification_command`
    EXISTS and is well-formed; they do not prove anyone recorded WHY the
    finding is gone. A task is "closed" by the same canon `_check_task_fraud`
    uses -- `finding_backlog.normalize_backlog_status` mapping to
    `CANONICAL_DONE_STATUS`, or physical placement under `tasks/done/` --
    never the bare string `resolved` (which normalizes to OPEN, not closed).
    Exactly one canonical heading name per section: a prior version accepted
    whatever heading family a given task happened to use (`Gap`, `I · Issue`,
    `Resolution Audit`, ...), which meant new tasks could pick any shape and
    still pass. The producer (`finding_backlog._TEMPLATE`) now scaffolds these
    three headings on every new task; this validator enforces them non-empty
    on close.
    """
    status_val = _task_status_label(content)
    is_in_done = task_path.parent.name == "done"
    is_closed = (
        finding_backlog.normalize_backlog_status(status_val) == finding_backlog.CANONICAL_DONE_STATUS
        or is_in_done
    )
    if not is_closed:
        return True, "OK"

    missing = []
    near_misses = []
    for name in _CANONICAL_SECTION_NAMES:
        _heading, body, descartado = _seccion_canonica(content, name)
        body = _PLACEHOLDER_LINE_RE.sub("", body).strip()
        if not body:
            missing.append(name)
            # Naming what was actually FOUND, when the heading exists at a level the
            # contract does not accept. Reported by the session declutter for the exact
            # -title era: a plain "missing" sends the reader looking in the wrong place
            # for a section that is right there. Since 2026-09-06 a `##`/`###` heading
            # that STARTS with the canonical name is accepted outright, so what reaches
            # here is `# Root Cause` or `#### Root Cause` -- a real level violation, not
            # a suffix.
            if descartado is not None:
                near_misses.append((name, descartado))
    if missing:
        detail = (
            f"Task {task_path.name} is closed but missing required resolution "
            f"section(s): {', '.join(missing)}."
        )
        if near_misses:
            detail += (
                f" Found at a heading level the contract does not accept (use "
                f"{' or '.join('#' * n for n in _NIVELES_CANONICOS)}): " + "; ".join(
                    f"{found!r} instead of '## {name}'" for name, found in near_misses
                )
            )
        return False, detail
    return True, "OK"


# Four mandatory fields, not nine. Measured across 2,780 tasks with real
# frontmatter in 18 repos (fleet canon design, 2026-09-01), the five that were
# dropped either had no consumer or no discriminating power:
#
#   field         present  values  dominant  read anywhere in simplecode
#   risk_score     88.2%     10     57.8%    0 sites
#   blast_radius   88.2%      5     60.8%    0 sites
#   category       75.4%     20     94.6%    0 sites  (one value in 19 of 20)
#   tag            75.2%     28     83.1%    5 sites, all WRITES, no reads
#   lifespan       75.2%      6     92.9%    0 sites
#
# `risk_score` decided it: `universal_harvester._compute_risk_score` emits only
# four fixed tuples from a severity regex (P0->10/HIGH, P1->8/HIGH, P2->5/MEDIUM,
# P3->3/LOW), so 1,323 of 2,094 tasks carry pure redundancy of `severity:`,
# while 771 carry combinations the function CANNOT emit -- P2/8/HIGH appears 389
# times and is impossible under the formula. A 1-to-10 number with no auditable
# rule and no consumer is a tax on every new task.
#
# `satd_family` SURVIVES, against the design's first draft: at 44 values with a
# 36.1% mode it is the most discriminating field in the schema -- more than
# `severity` at 53.1% -- it has cited provenance (`classify_satd_family`, the
# Li et al. / SATDBailiff four-family taxonomy) and it IS read
# (adversarial_judge.py:509). The measurement overruled the intuition.
#
# `blast_radius` is optional rather than deleted: FLEET/KIT capture the one
# thing severity cannot -- whether the debt crosses the repo boundary -- but
# that is 21 of 2,452 tasks (0.86%), so requiring it of the other 99% is a tax.
_MANDATORY_FRONTMATTER_FIELDS = ("id", "status", "severity", "satd_family")


def _validate_mandatory_frontmatter(content: str) -> str | None:
    """The first missing canonical frontmatter field, or None if all present."""
    for field in _MANDATORY_FRONTMATTER_FIELDS:
        if not re.search(rf"^{field}:\s*\S+", content, re.M):
            return f"Missing required frontmatter field '{field}:' in task contract"
    return None


_CLOSE_CHECK_LINE_RE = re.compile(r"^close_check:\s*(.+)$", re.M)

# The canon's `close_check.expect` is a VOCABULARY, not the classic `expect:`
# substring marker, and confusing the two silently breaks every canon task:
# the literal string "exit_zero" appears in no pytest output, so feeding it to
# the substring check would convict all of them. Measured 2026-09-05 over the
# 17 satellites that have a `tasks/done/`:
#
#     2534  exit_zero        the command must exit 0
#       13  empty_stdout     ... and print nothing on stdout
#        0  anything else
#
# An unrecognised word is NOT downgraded to exit-code-only. A gate that checks
# something weaker than the ficha declared, and then prints OK, is the exact
# defect this execution path exists to close -- so it lands in COULD_NOT_RUN,
# named, and the operator sees that this ficha was not judged.
CLOSE_CHECK_EXPECT_EXIT_ZERO = "exit_zero"
CLOSE_CHECK_EXPECT_EMPTY_STDOUT = "empty_stdout"

# DERIVED from the schema, not restated. Until 2026-09-05 this tuple was an
# independent literal, and the two organs disagreed: `ledger_schema.EXPECT` held
# `exit_nonzero` and this one did not, so a ficha could declare a word the canon
# accepted and the verifier refused. Measured across the fleet at the time:
# exit_zero 2892 uses, exit_nonzero 1, empty_stdout 0 -- and that single
# exit_nonzero was a ficha about the polarity problem itself. Support was
# INVERTED with respect to use.
#
# The own_chats session settled the vocabulary (dropping `exit_nonzero`, whose
# danger is that a close_check expecting failure passes when the command fails
# for ANY reason -- a missing file, a broken interpreter, a timeout -- so an
# instrument that is down reads as a closed ficha). What is fixed HERE is the
# structure: one source of truth instead of two lists that happened to agree.
#
# The direction matters and is not arbitrary. `ledger_schema` imports nothing
# from `simplecode.verification`, so this import adds no cycle; the reverse
# (schema importing the verifier) would close one through `finding_backlog`.
# A test comparing two lists warns after they diverge. An import cannot diverge.
CLOSE_CHECK_EXPECT_VOCABULARY = tuple(sorted(ledger_schema.EXPECT))


def _close_check_field(content: str) -> dict | None:
    """The parsed canon `close_check:` mapping, or None when it is absent or is
    not a mapping. One place knows the field's YAML shape, so `cmd` and
    `expect` can never be read off two different parses of the same line."""
    match = _CLOSE_CHECK_LINE_RE.search(content)
    if match is None:
        return None
    try:
        data = yaml.safe_load(match.group(1))
    except yaml.YAMLError as exc:
        # Narrow, and it says what it swallowed. A `close_check:` line that does
        # not parse is a task that has not stated its obligation, which the
        # caller reports as a breach -- but silently returning "" for ANY
        # exception would have hidden a real bug in this parser behind a task's
        # verdict.
        logger.warning("close_check is not parseable YAML (%s)", exc)
        return None
    return data if isinstance(data, dict) else None


def _close_check_command(content: str) -> str | None:
    """The `cmd` of a canon `close_check:` field, or None if there is no such field.

    The fleet canon spells the same obligation differently: `close_check:
    {"cmd": ..., "expect": ...}` instead of a ```json queue-job``` block plus a
    `verification_command:`. Returns None when the field is absent, and "" when
    it is present but carries no usable command -- those are different facts and
    the caller treats them differently.
    """
    if _CLOSE_CHECK_LINE_RE.search(content) is None:
        return None
    data = _close_check_field(content)
    if data is None:
        return ""
    cmd = data.get("cmd")
    return str(cmd).strip() if isinstance(cmd, str) and cmd.strip() else ""


def _close_check_expect(content: str) -> str:
    """The `expect:` word inside a canon `close_check:`, defaulting to
    `exit_zero`.

    The default is the meaning 2534 of the fleet's 2547 close_checks spell out
    explicitly, and it is also the weakest of the vocabulary -- a ficha that
    omitted the word gets the check everyone else declared, never a stricter one
    it never agreed to.
    """
    data = _close_check_field(content)
    if data is None:
        return CLOSE_CHECK_EXPECT_EXIT_ZERO
    word = data.get("expect")
    return word.strip() if isinstance(word, str) and word.strip() else CLOSE_CHECK_EXPECT_EXIT_ZERO


class DeclaredCheck(NamedTuple):
    """The command a closed task offers as proof, in whichever spelling it used.

    `field` is which frontmatter field actually carried it, so a failure names
    the field the reader can go and open -- reporting `verification_command` at
    a canon ficha that has no such field sends them looking for nothing.

    `conflict` carries the ficha's self-contradiction (both spellings, different
    commands) so the contract validator can convict it instead of this function
    picking one behind the author's back. It defaults to None because every
    other construction site here is a task with nothing to contradict.
    """

    cmd: str
    expect: str | None
    expect_mode: str | None
    field: str
    conflict: str | None = None
    # `close_check.timeout`, only when it passes `ledger_schema.close_check_timeout_problem`.
    # An invalid value is the schema gate's conviction; this verifier never runs on it and
    # keeps the derived budget instead.
    timeout: float | None = None


def _declared_closing_command(content: str) -> DeclaredCheck:
    """The executable closing proof a task declares, in EITHER spelling.

    Classic (SPEC GS2-214): `verification_command:` plus an optional `expect:`
    substring marker. Canon: `close_check: {"cmd": ..., "expect": ...}`.

    Until 2026-09-05 only the CLASSIC spelling was ever executed. The canon's
    field went through `_validate_verification_cmd` -- module shape, executable
    whitelist, no pipes, no injection -- and then nothing ever ran it, so a hook
    the satellites call "closed debt has executable evidence" checked the FORM
    of the evidence and never the evidence. Measured that day on a disposable
    repo with four `done` fichas: in the `close_check` spelling the gate printed
    `OK: all tasks verified ... frauds: 0`, rc=0, while by hand one of those
    commands exited 1 and another exited 4; the SAME four fichas rewritten with
    `verification_command:` gave `frauds: 2`, rc=1. The spelling, and only the
    spelling, decided whether the command ran.

    WHICH SPELLING WINS IS NOT DECIDED HERE ANY MORE (2026-09-06). The rule and
    its measurement live in `ledger_schema.resolve_closing_command`, which this
    schema's own readers call too, so the two organs cannot disagree about the
    same ficha -- and until today they did, with INVERTED precedences: this one
    preferred the classic spelling, `ledger_schema._close_check_cmd` preferred
    the canon's. The sentence this docstring used to end with -- *"no task in
    the fleet declares the two with different commands"* -- was measured false
    the day it was checked: **47 of 3,010 fichas do**, in 7 repos.

    Classic-wins was also wrong in the direction that costs most: in 22 of
    aequitas_os's divergent fichas the `verification_command` is the repo's
    whole gate (`zero_debt --gate`) while the `close_check` names the scoped
    test of the actual defect, so the winning spelling ran a subject unrelated
    to the ficha.

    What this function still owns is the CRITERION, and it now composes both:
    a ficha carrying the classic `expect:` substring marker keeps it even when
    the canon's `close_check` supplies the command. Both were declared by the
    same author, applying both is strictly stronger than either, and dropping
    the substring would have silently weakened the 15 fichas in this repo that
    carry `expect: "passed"` alongside a `close_check`.
    """
    raw_cmd = _extract_verification_command(content)
    close_cmd = _close_check_command(content)
    resolved = ledger_schema.resolve_closing_command(close_cmd, raw_cmd)
    if not resolved.cmd:
        return DeclaredCheck("", None, None, "verification_command")
    # The substring marker is a property of the CLASSIC spelling and survives
    # whichever field supplies the command; the vocabulary word only exists when
    # the ficha actually carries a `close_check:` field.
    expect = _extract_expect(content) if raw_cmd else None
    mode = _close_check_expect(content) if resolved.field == "close_check" else None
    timeout = None
    if resolved.field == "close_check":
        declared = (_close_check_field(content) or {}).get("timeout")
        # The isinstance only narrows the type for pyright; the schema's own check decides.
        if isinstance(declared, (int, float)) and ledger_schema.close_check_timeout_problem(declared) is None:
            timeout = float(declared)
    return DeclaredCheck(resolved.cmd, expect, mode, resolved.field, resolved.conflict, timeout)


def _validate_payload(content: str, raw_cmd: str | None, root: Path | None = None) -> str | None:
    """A task must carry an EXECUTABLE closing obligation, in one of two spellings.

    Classic (SPEC GS2-214): a ```json queue-job``` block AND a non-empty
    `verification_command:`. Those two are not alternatives to each other -- the
    queue-job is what a headless runner dispatches, the command is what proves
    the fix -- and a structured findings block substitutes for neither.

    Canon: a `close_check: {"cmd": ..., "expect": ...}` field, which carries the
    same executable command in the schema the fleet canon writes. Accepted as
    equivalent from 2026-09-02, after Atlas landed the canon and measured all 21
    of its `CANON-*.md` entries convicted with "missing structured findings block
    and the mandatory queue-job block" -- 1 finding before the merge, 23 after.
    The canon's form is strictly STRONGER, not weaker: alongside `close_check` it
    requires `evidence` with pass, fail and e2e artifacts on a done entry, which
    the classic form never asked for.

    What is NOT relaxed: whichever spelling a task uses, its command goes through
    `_validate_verification_cmd` unchanged. Exempting `close_check` from the
    whitelist would turn the canon's schema into the escape hatch from it, and
    that whitelist is itself already recorded as too narrow
    (DEBT-KIT-ASSUMES-PYTHON) -- a limit to fix in the open, never to route
    around.
    """
    close_check = _close_check_command(content)
    if close_check is not None:
        if not close_check:
            return "Task declares `close_check:` with no usable `cmd`"
        valid, msg = _validate_verification_cmd(close_check, root=root)
        return None if valid else msg

    has_findings = FINDINGS_START in content and FINDINGS_END in content
    qj_ok, qj_msg = _validate_queue_job(content, root=root)
    if not qj_ok:
        if qj_msg:
            return qj_msg
        if not has_findings:
            return "Task is missing structured findings block and the mandatory ```json queue-job block"
        return "Task is missing the mandatory ```json queue-job block (a findings block does not substitute for it)"
    if not raw_cmd:
        return "Task is missing a mandatory non-empty verification_command"
    return None


def _repo_root_of_task(task_path: Path) -> Path | None:
    """Repo root for a task file, or None when the path is not under `tasks/`.

    None means "no declaration visible", which falls back to the kit baseline --
    the fail-closed direction.
    """
    for parent in task_path.resolve().parents:
        if parent.name == "tasks":
            return parent.parent
    return None


def validate_task_contract(task_path: Path, content: str) -> tuple[bool, str]:
    """Validate that a task has a complete machine-executable contract (GS2-214)."""
    if _is_exempt_done_task(task_path, content):
        return True, "OK"

    # 0. The task must declare ONE closing obligation, not two that disagree.
    #    Checked before anything else because every check below reads "the"
    #    command, and there is no such thing while two fields name different
    #    ones: whichever this gate picked, the author's other field is what the
    #    NEXT reader would open. Measured across 3,010 fleet fichas: 47 carry
    #    exactly this contradiction, and the one it already cost was `cuenza`,
    #    accused of FRAUD because the verifier ran the field they had left
    #    behind.
    conflict = _declared_closing_command(content).conflict
    if conflict:
        return False, f"Task {task_path.name}: {conflict}"

    # 1. Verification command validation (when the field is present at all;
    #    its ABSENCE is convicted by _validate_payload, after the frontmatter audit).
    raw_cmd = _extract_verification_command(content)
    # The repo root is the parent of `tasks/`, which is where a task file always
    # lives (tasks/backlog/x.md, tasks/done/x.md). Passed so the repo's own
    # build-tool declaration is visible to the whitelist check.
    root = _repo_root_of_task(task_path)
    if raw_cmd is not None:
        valid_cmd, cmd_msg = _validate_verification_cmd(raw_cmd, root=root)
        if not valid_cmd:
            return False, cmd_msg

    # 2. Frontmatter (canonical fields per SPEC).
    frontmatter_error = _validate_mandatory_frontmatter(content)
    if frontmatter_error:
        return False, frontmatter_error

    # 3. Payload (queue-job block + verification_command).
    payload_error = _validate_payload(content, raw_cmd, root=root)
    if payload_error:
        return False, payload_error

    # 4. Resolution narrative (only enforced once the task is actually closed).
    narrative_ok, narrative_msg = _validate_resolution_narrative(task_path, content)
    if not narrative_ok:
        return False, narrative_msg

    return True, "OK"


# ---------------------------------------------------------------------------
# GS2-214 retroactivity cut-off (DECISIONS.md 2026-09-01)
# ---------------------------------------------------------------------------
#
# The hardened task contract convicted 787 of 788 closed tasks in office2office:
# it was applied to a corpus written before it existed. The cut-off splits the
# audit into two stages that answer different questions.
#
#   Stage 1 -- what the task ASSERTS about itself. A file living in `tasks/done/`
#              while declaring an open status contradicts its own location. That
#              is a false statement, not a missing field, and age never excuses
#              it: stage 1 runs on every governed task whether or not it can be
#              dated.
#   Stage 2 -- what SHAPE the task was written in (frontmatter, queue-job block,
#              verification_command, the three resolution sections). Those are
#              contract, not assertion. A task written before the contract
#              existed could not have obeyed it, and backfilling them
#              mechanically produces text shaped like a root cause rather than a
#              root cause -- the exact failure the contract exists to prevent.
#
# Stage 1 is CONSTRUCTED here, never inherited. office2office pre-registered the
# baseline before this code existed (their `scripts/cutoff_prereg.json`):
#
#     declaring_open                            346
#     declaring_open_convicted_at_all           346
#     declaring_open_convicted_for_the_claim      0
#
# All 346 were convicted incidentally -- 344 of them for a missing `severity:`
# field, which is stage 2. Leaning on that conviction would have whitewashed
# exactly those 346 at the moment the cut-off withdrew it.

CUTOFF_CONFIG_RELPATH = Path(".simplecode") / "task_contract_cutoff.json"
# Same declared-cut-off mechanism for the findings contract (docs/agent_findings): its own file, because
# the date a repo starts governing findings is not the date it starts governing tasks.
FINDINGS_CUTOFF_CONFIG_RELPATH = Path(".simplecode") / "findings_contract_cutoff.json"
FINDINGS_DIR_RELPATH = Path("docs") / "agent_findings"

COHORT_GOVERNED = "governed"
COHORT_LEGACY = "legacy"
COHORT_UNDATABLE = "undatable"
# A task closed ON PURPOSE without executable evidence. `ledger_schema.py`'s
# canon has had this state since 2026-09-02 and reports it as its own count
# (office2office 2026-09-04: `checked=804 passed=15 failed=128 unverified=661`),
# but this module only taught it to `unrecognised_closing_status` -- so the SAME
# declared state was honoured by one organ of the kit and convicted by two.
#
# Measured in office2office 2026-09-04 with the cut-off measured dead there
# (a .gitignore rewrite re-dated 454 of 804 tasks to one day, so no date
# separates the cohorts): 796 breaches, of which 660 are the three resolution
# sections and 128 an empty `close_check.cmd`, ALL on tasks that already carry
# `status: done_unverified`. Three gates blocked on one cohort, and the operator
# learned to skip all three -- which is what `SKIP` in that repo's push has been
# doing since 2026-09-02.
#
# This is NOT an amnesty, and the difference is the report: the count prints on
# its own line, a repo with 661 of these cannot call itself clean, and stage 1
# still runs on every one of them. Backfilling the sections mechanically is the
# thing this contract exists to prevent -- text SHAPED like a root cause is
# worse than an admitted gap.
COHORT_UNVERIFIED = "unverified"


class ContractAudit(NamedTuple):
    """Result of the two-stage task-contract audit, cohorts included.

    `breaches` is what blocks. `cohorts` and `undatable` exist so the report can
    print what it did NOT evaluate beside what it did -- a count of zero
    breaches over a corpus the gate never looked at is the failure this record
    makes impossible to hide.
    """

    breaches: list[tuple[Path, str]]
    cohorts: dict[str, int]
    undatable: list[Path]
    cutoff_note: str
    date_source_warning: str = ""
    unrecognised_status: list[str] = []


def load_contract_cutoff(
    root: Path, relpath: Path = CUTOFF_CONFIG_RELPATH
) -> tuple[date | None, str]:
    """The declared contract cut-off date and a note describing it.

    ABSENT MEANS NO CUT-OFF: every task is governed by the full contract, which
    is this repo's own state and the strictest reading. A repo that needs the
    cut-off declares it in a reviewed commit; nothing is inferred from history,
    from a `created:` field, or from the shape of the corpus. A malformed
    declaration falls back to no cut-off (fail closed) and says so.
    """
    cfg = root / relpath
    if not cfg.is_file():
        return None, f"no {relpath.as_posix()} declared: everything is governed"
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
        parsed = date.fromisoformat(str(data["cutoff"]))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return None, (
            f"COULD_NOT_RUN: {relpath.as_posix()} is unreadable or malformed "
            f"({exc}); falling back to NO cut-off, everything governed"
        )
    reason = str(data.get("reason", "")).strip() if isinstance(data, dict) else ""
    note = f"cut-off {parsed.isoformat()}"
    return parsed, f"{note} -- {reason}" if reason else note


def task_add_dates(root: Path, pathspec: str = "tasks/") -> dict[str, date]:
    """Earliest commit that ADDED each tracked path under `tasks/`, by relpath.

    The date source is git, never a `created:` frontmatter field: a self-declared
    date is the very assertion this gate audits. Renames are deliberately NOT
    followed (`--diff-filter=A` without `-M`), so a task moved from `backlog/`
    into `done/` is dated by the commit that closed it -- which is what
    "created or closed after the contract landed" means.
    """
    proc = subprocess.run(
        [
            "git", "-C", str(root), "log", "--diff-filter=A",
            "--format=%x00%aI", "--name-only", "--", pathspec,
        ],
        capture_output=True,
        text=True,
        check=False,
        timeout=GIT_O1_TIMEOUT,
    )
    dates: dict[str, date] = {}
    if proc.returncode != 0:
        return dates
    current: date | None = None
    for line in proc.stdout.splitlines():
        if line.startswith("\x00"):
            try:
                current = datetime.fromisoformat(line[1:]).date()
            except ValueError:
                current = None
            continue
        rel = line.strip()
        if not rel or current is None:
            continue
        seen = dates.get(rel)
        if seen is None or current < seen:
            dates[rel] = current
    return dates


def _git_ignored(root: Path, rels: list[str]) -> set[str]:
    """Of `rels`, the ones git is configured to ignore (empty on any failure)."""
    if not rels:
        return set()
    proc = subprocess.run(
        ["git", "-C", str(root), "check-ignore", "--stdin"],
        input="\n".join(rels),
        capture_output=True,
        text=True,
        check=False,
        timeout=GIT_O1_TIMEOUT,
    )
    return {line.strip() for line in proc.stdout.splitlines() if line.strip()}


def _task_cohort(rel: str, dates: dict[str, date], cutoff: date, ignored: set[str]) -> str:
    """Which cohort a task belongs to under a declared cut-off."""
    added = dates.get(rel)
    if added is not None:
        return COHORT_LEGACY if added < cutoff else COHORT_GOVERNED
    # Never committed, which splits into two very different cases.
    #  - gitignored: git cannot date it now and never will -> third cohort,
    #    counted and named, folded into neither side.
    #  - merely untracked: the commit about to land it will date it, so it is
    #    new by construction and governed. Without this split, writing a task
    #    and not committing it would escape the contract at pre-commit stage.
    return COHORT_UNDATABLE if rel in ignored else COHORT_GOVERNED


# A git add-date measures when a file stopped being IGNORED, not when the work
# happened -- and a .gitignore change rewrites it wholesale. Measured in
# office2office 2026-09-02: commit 54782e18 added `!tasks/done/DEBT-*.md` to
# .gitignore, and 304 of 341 datable tasks (89%) are dated to that one day.
# Written in July and August, dated 29 August. So the cut-off freed nothing
# there: `legacy: 0` beside `governed: 342`.
#
# No better source survives the same test -- `mtime` is rewritten by any
# sanitising sweep, and `created:` is the self-declaration the gate audits. So
# this does not fix the date; it makes the corpus SAY when the date is an
# artifact, instead of every satellite discovering it separately.
_DATE_PILEUP_MIN_TASKS = 20
_DATE_PILEUP_SHARE = 0.5


def _date_source_warning(dates: dict[str, date], relpaths: list[str]) -> str:
    """Warn when most datable tasks share one add-date, or "" when they do not."""
    fechas = [dates[rel] for rel in relpaths if rel in dates]
    if len(fechas) < _DATE_PILEUP_MIN_TASKS:
        return ""
    modal, cuenta = Counter(fechas).most_common(1)[0]
    if cuenta / len(fechas) < _DATE_PILEUP_SHARE:
        return ""
    return (
        f"DATE SOURCE UNRELIABLE HERE: {cuenta} of {len(fechas)} datable tasks "
        f"({cuenta / len(fechas):.0%}) were first committed on {modal.isoformat()}. "
        f"A git add-date records when a file stopped being gitignored, not when "
        f"the work happened, and one .gitignore change rewrites it for the whole "
        f"corpus. Read this repo's legacy/governed split as an artifact of that "
        f"commit, not as history."
    )


# Statuses that actually ASSERT the work is still outstanding. Stage 1 convicts
# on these and on nothing else.
#
# It used to convict on "anything that does not normalize to done", and that was
# wrong in a way that blocked a satellite's master push within hours of
# shipping. `normalize_backlog_status` maps every unrecognised label to OPEN --
# correct for the zero-debt count, where an unknown label must not exempt
# anything -- but stage 1 is a different question. It accuses a file of
# CONTRADICTING ITSELF, and `status: resolved` inside `tasks/done/` does not: it
# asserts closed in another vocabulary. The message even said "its own
# frontmatter asserts open", which about those files was simply false.
#
# Measured by the Atlas session 2026-09-02 with the control that makes it a
# regression and not new debt: the same judge passed twice that night over the
# same 36 files under the previous runtime. And by atlas-48 across the fleet:
# 176 tasks declare closure in forms this repo does not list --
# `resolved` 38, `pagada-<date>` 97, `cerrada` 3.
_ASSERTS_OPEN = frozenset({
    "open", "abierta", "abierto", "backlog", "todo", "pending", "pendiente",
    "active", "activa", "in-progress", "in progress", "wip", "blocked",
    "bloqueada", "triaged", "deferred", "reopened", "reabierta",
})

# A status this vocabulary KNOWS, but that is neither "asserts open" nor
# "confirmed done": `done_unverified` (`ledger_schema.py`'s canon, 2026-09-02)
# means closed-but-unverified on purpose -- fabricating an `evidence.fail` for
# a pre-contract closure would be worse than admitting the gap. It still
# counts as OPEN for `normalize_backlog_status` (unverified is not verified),
# but it is a NAMED word, not a mystery one: declutter measured 85 identical
# `unrecognised_closing_status` warnings for it in one repo (2026-09-03) --
# noise at that volume is exactly where a REAL unrecognised status would go
# unnoticed. Recognising it here silences the warning without changing what
# it counts as; `_stage1_assertion_breach` never sees it either way, since it
# only checks membership in `_ASSERTS_OPEN`.
_KNOWN_UNVERIFIED_STATUS = frozenset({"done_unverified"})


def _stage1_assertion_breach(task_path: Path, content: str) -> str | None:
    """Stage 1: a task in `tasks/done/` declaring an OPEN status contradicts itself.

    The one conviction the cut-off never withdraws. It audits what the file
    ASSERTS, not the shape it was written in, so it needs no date. A task with
    no `status:` field at all makes no assertion and is not convicted here --
    the missing field is stage 2's business, and conflating the two is how the
    conviction would end up leaning on `severity:` again.

    A status that is neither in `_ASSERTS_OPEN` nor a recognised done synonym is
    NOT convicted either. It is an unrecognised closing vocabulary, and this
    function cannot tell `pagada-2026-08-20` from a typo -- so it says nothing
    rather than accusing the file of a contradiction it may not contain.
    `unrecognised_closing_status` reports those separately, which is the honest
    version of the same information.
    """
    if task_path.parent.name != "done":
        return None
    status_val = _task_status_label(content)
    if status_val not in _ASSERTS_OPEN:
        return None
    return (
        f"Task {task_path.name} declares `status: {status_val}` while living in "
        "tasks/done/: its location asserts closed and its own frontmatter asserts "
        "open. Move it back to tasks/backlog/ or close it for real."
    )


def unrecognised_closing_status(task_path: Path, content: str) -> str | None:
    """A `tasks/done/` status this repo's vocabulary does not know, or None.

    Reported and counted, never convicted: a count of zero here and a count of
    ninety-seven are different facts, and the second is what the fleet actually
    has. Blocking on it would repeat the regression this function exists beside.
    """
    if task_path.parent.name != "done":
        return None
    status_val = _task_status_label(content)
    if not status_val or status_val in _ASSERTS_OPEN or status_val in _KNOWN_UNVERIFIED_STATUS:
        return None
    if finding_backlog.normalize_backlog_status(status_val) == finding_backlog.CANONICAL_DONE_STATUS:
        return None
    return f"{task_path.name}: `status: {status_val}` is not in this repo's closing vocabulary"


def _cohort_for(content: str, rel: str, dates: dict[str, date],
                cutoff: date | None, ignored: set[str]) -> str:
    """Which cohort one task belongs to. Exactly one, decided before counting.

    Only a task the cut-off would have GOVERNED can become `unverified`: the
    legacy and undatable cohorts already skip stage 2, and folding one of them
    in here would hide WHY its shape went unevaluated -- which is the whole
    reason these counts print separately.
    """
    cohort = COHORT_GOVERNED if cutoff is None else _task_cohort(rel, dates, cutoff, ignored)
    if cohort == COHORT_GOVERNED and _task_status_label(content) in _KNOWN_UNVERIFIED_STATUS:
        return COHORT_UNVERIFIED
    return cohort


def _governed_task_candidates(root: Path) -> list[Path]:
    """Every task file this audit is willing to judge, in a stable order.

    Split out of ``audit_task_contracts`` because WHICH files are in scope is
    the question a reader asks first and separately -- a directory missing
    from ``GOVERNED_TASK_DIRS`` makes the whole audit silently narrower
    without any count going to zero.
    """
    candidates: list[Path] = []
    for sdir in [root / "tasks" / name for name in GOVERNED_TASK_DIRS]:
        if sdir.is_dir():
            candidates.extend(sorted(sdir.glob("*.md")))
    return candidates


def _resolve_cutoff_dates(
    root: Path, candidates: list[Path], cutoff: date | None, pathspec: str = "tasks/"
) -> tuple[dict[str, date], set[str]]:
    """When a cut-off is declared: each task's git add-date, and which of the
    UNDATABLE ones git merely ignores.

    Returns two EMPTY collections when no cut-off is declared, which is not the
    same as "measured and found none": with no cut-off every task is governed,
    so no date is needed and none is claimed. Keeping that early exit here,
    rather than inside the per-task loop, is what stops an empty `dates` from
    reading as "git could date nothing".
    """
    if cutoff is None or not candidates:
        return {}, set()
    dates = task_add_dates(root, pathspec)
    undated_rels = [
        p.relative_to(root).as_posix()
        for p in candidates
        if p.relative_to(root).as_posix() not in dates
    ]
    return dates, _git_ignored(root, undated_rels)


def audit_task_contracts(root: Path) -> ContractAudit:
    """Audit every governed task file in two stages, and report the cohorts."""
    cutoff, note = load_contract_cutoff(root)
    candidates = _governed_task_candidates(root)
    dates, ignored = _resolve_cutoff_dates(root, candidates, cutoff)

    breaches: list[tuple[Path, str]] = []
    cohorts = {COHORT_GOVERNED: 0, COHORT_LEGACY: 0, COHORT_UNDATABLE: 0, COHORT_UNVERIFIED: 0}
    undatable: list[Path] = []
    unrecognised: list[str] = []

    for task_path in candidates:
        try:
            content = task_path.read_text(encoding="utf-8")
        except OSError as exc:
            breaches.append((task_path, f"COULD_NOT_RUN: Failed reading task ({exc})"))
            continue

        rel = task_path.relative_to(root).as_posix()
        cohort = _cohort_for(content, rel, dates, cutoff, ignored)
        cohorts[cohort] += 1
        if cohort == COHORT_UNDATABLE:
            undatable.append(task_path)

        unknown = unrecognised_closing_status(task_path, content)
        if unknown:
            unrecognised.append(unknown)
        stage1 = _stage1_assertion_breach(task_path, content)
        if stage1:
            breaches.append((task_path, stage1))
            continue
        # Stage 2 is contract SHAPE. `COHORT_UNVERIFIED` skips it because
        # `done_unverified` DECLARES the shape was never produced -- on purpose,
        # the closure predating the contract -- and convicting it asks for the one
        # thing the state exists to refuse to invent. Stage 1 already ran above:
        # a file that ASSERTS open while living in `done/` is still convicted,
        # whatever its status word.
        if cohort != COHORT_GOVERNED:
            continue
        valid, msg = validate_task_contract(task_path, content)
        if not valid:
            breaches.append((task_path, msg))

    aviso = _date_source_warning(dates, [p.relative_to(root).as_posix() for p in candidates])
    return ContractAudit(
        breaches=breaches,
        cohorts=cohorts,
        undatable=undatable,
        cutoff_note=note,
        date_source_warning=aviso,
        unrecognised_status=unrecognised,
    )


def verify_tasks_contract_compliance(root: Path) -> list[tuple[Path, str]]:
    """Breaches only, for callers that do not print the cohorts.

    Back-compat entry point over :func:`audit_task_contracts`; anything that
    reports to a human should use that instead, so the legacy and undatable
    counts print beside the breach count.
    """
    return audit_task_contracts(root).breaches


def extract_findings_from_task(task_content: str) -> list[str]:
    """Extract registered findings list from task markdown body.

    A finding's `(detector: X)` tag is sometimes written as a wrapped
    continuation line -- indented, not itself starting with ``- `` -- rather
    than inline on the bullet. Dropping that line (the old behavior: only
    ``- ``-prefixed lines survived) silently strips the one signal
    ``verify_finding_reproduces`` needs to dispatch to the real detector
    re-check, so a finding written that way could never be verified resolved
    no matter how thoroughly the code was fixed -- it fell through to the
    fail-closed "assume it still reproduces" default forever. Measured live
    on Atlas: 10 tasks with genuinely-fixed, detector-clean code still read
    as reproducing until this fold was added. Continuation lines are folded
    into the preceding bullet, space-joined.
    """
    if FINDINGS_START not in task_content or FINDINGS_END not in task_content:
        return []
    block = task_content.split(FINDINGS_START, 1)[1].split(FINDINGS_END, 1)[0]
    findings: list[str] = []
    for raw_line in block.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("- "):
            findings.append(line[2:].strip())
        elif findings:
            findings[-1] = f"{findings[-1]} {line}"
    return findings


def _find_symbol_in_tree(root: Path, symbol: str) -> list[Path]:
    """Find all python files where a given function or class symbol is defined."""
    matches = []
    for py in root.rglob("*.py"):
        if any(part.startswith(".") for part in py.parts):
            continue
        try:
            txt = py.read_text(encoding="utf-8", errors="replace")
            if f"def {symbol}" in txt or f"class {symbol}" in txt:
                matches.append(py)
        except OSError as exc:
            logger.debug("Could not read %s: %s", py, exc)
    return matches


def _target_is_kit_exempt(root: Path, rel_file: str) -> bool:
    """True when the kit's own config or built-in rules declare `rel_file`
    out of scope -- the SAME exemptions `scan_all_detectors` applies during a
    real zero-debt sweep (`is_fixture`, `is_vendored`, `declares_corpus`; see
    zero_debt.py).

    Every mechanism in `_FINDING_MECHANISMS` that re-runs a detector or
    linter DIRECTLY against a file's current content -- as opposed to
    `_verify_zero_debt_finding`, which already delegates to the exemption-
    aware `scan_all_detectors` -- must consult this first. Measured on
    Atlas 2026-08-25: a finding on `playbooks/cutile-kernels/assets/...`
    (declared in `.simplecode/corpus_exempt.yaml`'s `vendored_paths`,
    confirmed by zero-debt's own `EXEMPT_VENDORED=5` count) still reproduced
    via the raw-detector path and got the task auto-reverted as fraud on a
    defect the kit's own config says is not this repo's to fix.
    """
    from simplecode.worktree.zero_debt import declares_corpus, is_fixture, is_vendored

    return bool(is_fixture(rel_file) or is_vendored(root, rel_file) or declares_corpus(root, rel_file))


def _verify_ruff_finding(root: Path, finding: str) -> bool | None:
    match = re.match(r"^ruff: ([\w./\-]+\.py):\d+:\d+: ([A-Z0-9]+)", finding)
    if not match:
        return None
    rel_file, rule_code = match.group(1), match.group(2)
    if _target_is_kit_exempt(root, rel_file):
        return False
    target_path = root / rel_file
    if not target_path.is_file():
        return False
    ruff_bin = shutil.which("ruff")
    if not ruff_bin:
        return True
    cmd = [ruff_bin, "check", "--select", rule_code, "--output-format", "concise", str(target_path)]
    res = subprocess.run(cmd, capture_output=True, text=True, check=False)
    return res.returncode != 0


_ZERO_DEBT_SCAN_CACHE: dict[Path, tuple] = {}
# Guards the compute-and-populate branch of _zero_debt_findings_snapshot below.
# audit_closed_tasks now classifies tasks concurrently (ThreadPoolExecutor), and this cache's
# own docstring already measured the compute it guards at 22.4-35.1s -- several threads
# hitting this cold on the very first batch (a common case: `classify_finding` is called for
# EVERY finding of EVERY task) would otherwise race to each launch that scan. A double-checked
# lock keeps the compute itself at MOST once per root per run, matching the guarantee the
# cache already promises across separate audit_closed_tasks calls.
_ZERO_DEBT_SCAN_LOCK = threading.Lock()

def _zero_debt_findings_snapshot(root: Path) -> tuple:
    """One whole-repo zero-debt scan per audit run, not one per finding.

    Reported live (aequitas_os, 2026-08-31, measured across 70 real pre-push
    runs / 11.22h of telemetry): 13 closed tasks each cite a zero-debt
    finding, and `_verify_zero_debt_finding` re-ran the SAME full-repo
    `findings_per_file` scan independently for every one of them --
    22.4-35.1s each, 269-421s wasted per push for an identical result every
    time, since nothing in the working tree changes between one task's check
    and the next within a single audit run. Cached per root, cleared at the
    start of :func:`audit_closed_tasks` so a long-lived process (fleet-wide
    satellite auditing) never serves a snapshot from a DIFFERENT run.

    Reported live (this repo, 2026-08-31): even with the per-run cache above,
    this still ran its OWN full `findings_per_file` scan in a SEPARATE
    process from the standalone `zero-debt-repo` hook that just scanned the
    identical tree seconds earlier in the same push -- duplicate work, not a
    caching risk, since nothing could have changed between two hooks in one
    invocation. A whole-repo `--mode zero` sweep that just proved GREEN means
    zero findings anywhere, so any zero-debt finding a task cites is provably
    resolved without scanning again.
    """
    cached = _ZERO_DEBT_SCAN_CACHE.get(root)
    if cached is not None:
        return cached
    with _ZERO_DEBT_SCAN_LOCK:
        # Re-check inside the lock: another thread may have finished the compute
        # while this one was waiting for it.
        cached = _ZERO_DEBT_SCAN_CACHE.get(root)
        if cached is None:
            from simplecode.worktree.zero_debt import findings_per_file
            cached = findings_per_file(root, staged=False)
            _ZERO_DEBT_SCAN_CACHE[root] = cached
    return cached


def _verify_zero_debt_finding(root: Path, finding: str) -> bool | None:
    match = re.match(r"^zero-debt: ([\w./\-]+\.py): \d+ finding", finding)
    if not match:
        return None
    rel_file = match.group(1)
    target_path = root / rel_file
    if not target_path.is_file():
        return False
    counts, _, _, _ = _zero_debt_findings_snapshot(root)
    return counts.get(rel_file, 0) > 0


def _verify_detector_finding(root: Path, finding: str) -> bool | None:
    """Re-run the raw pattern detector directly against the file's current
    content. See `_target_is_kit_exempt` for why the exemption check comes
    first."""
    from simplecode.guards.pattern_detectors import PATTERN_DETECTORS

    detector_map = {k: fn for fn, k, _ in PATTERN_DETECTORS}
    for key, fn in detector_map.items():
        if key in finding:
            match_file = re.search(r"([\w./\-]+\.py)", finding)
            if match_file:
                rel_file = match_file.group(1)
                if _target_is_kit_exempt(root, rel_file):
                    return False
                target_path = root / rel_file
                if not target_path.is_file():
                    return False
                try:
                    code = target_path.read_text(encoding="utf-8", errors="replace")
                    return bool(fn(code))
                except OSError as exc:
                    logger.debug("Could not read %s: %s", target_path, exc)
                    return False
    return None


def _verify_angry_path_finding(root: Path, finding: str) -> bool | None:
    if any(k in finding.lower() for k in ("except", "swallow", "blind", "angry")):
        match_file = re.search(r"([\w./\-]+\.py)", finding)
        if match_file:
            raw_p = match_file.group(1)
            if not Path(raw_p).is_absolute() and _target_is_kit_exempt(root, raw_p):
                return False
            target_path = Path(raw_p) if Path(raw_p).is_absolute() else (root / raw_p)
            if not target_path.is_file():
                return False
            from simplecode.guards.angry_path import inspect_angry_path
            try:
                code = target_path.read_text(encoding="utf-8", errors="replace")
                issues = inspect_angry_path(target_path, code)
                return len(issues) > 0
            except OSError as exc:
                logger.debug("Could not inspect angry path in %s: %s", target_path, exc)
                return False
    return None


def _verify_corruption_finding(root: Path, finding: str) -> bool | None:
    if any(k in finding.lower() for k in ("mojibake", "corruption", "crlf", "bom", "nul byte", "zero-width")):
        match_file = re.search(r"([\w./\-]+\.[a-zA-Z0-9]+)", finding)
        if match_file:
            raw_p = match_file.group(1)
            if not Path(raw_p).is_absolute() and _target_is_kit_exempt(root, raw_p):
                return False
            target_path = Path(raw_p) if Path(raw_p).is_absolute() else (root / raw_p)
            if not target_path.is_file():
                return False
            from simplecode.guards.corruption_guard import scan
            return len(scan([target_path])) > 0
    return None


# The `(detector: X)` tag a harvested finding carries to name the instrument
# that must re-check it. X is a PATTERN_DETECTORS key; when it is not, no organ
# in the repo can read the claim (see classify_finding).
_DETECTOR_TAG_RE = re.compile(r"\(detector:\s*([\w.\-]+)\s*\)")

# A finding that never adopted the `ruff: file:line:col: CODE` shape but still
# names a .py file and a ruff rule code -- e.g. "src/complex.py: PLR0913
# `too_many_args` has too many arguments", the form the chaos harness fires.
# Before the COULD_NOT_RUN state existed, findings written this way were caught
# only by the unfalsifiable fallback (assume-it-reproduces), which happened to
# be right here and wrong on Atlas. Reading the rule code and RUNNING ruff makes
# the same conviction falsifiable. The code shape is `[A-Z]{1,5}` + 3-4 digits
# (PLR0913, C901, F821, RUF100); an unknown code makes `ruff check --select`
# exit nonzero, which reads as reproducing -- still fail-closed.
_RUFF_LOOSE_RE = re.compile(r"([\w./\-]+\.py)(?!\w).*?\b([A-Z]{1,5}\d{3,4})\b", re.S)

# ruff sale 2 cuando no pudo ni empezar (selector desconocido, fichero
# ilegible, configuración rota). No es un veredicto sobre el sujeto.
_RUFF_USAGE_ERROR = 2

# The Rust half of the ruff-loose read (RePic, 2026-09-03): every mechanism
# above matches `.py` -- measured live, `pattern_detectors.py` names Python 97
# times against Rust 8 -- so a finding whose subject is a `.rs` file can NEVER
# be claimed by anything here and falls to COULD_NOT_RUN forever, in every
# repo whose product is Rust. That is not fail-closed on a real defect, it is
# an entire ecosystem's findings landing in the one bucket meant to be rare.
# Same falsifiability contract as `_RUFF_LOOSE_RE`: a `.rs` path plus a real
# `clippy::lint_name` makes the conviction re-runnable, not asserted.
_CARGO_CLIPPY_RE = re.compile(r"([\w./\-]+\.rs)(?!\w).*?\bclippy::([a-z_][a-z0-9_]*)\b", re.S)


def _verify_cargo_finding(root: Path, finding: str) -> bool | None:
    """Re-run `cargo clippy` for a finding that names a `.rs` file and a real
    `clippy::` lint. Returns None (not my jurisdiction) for anything else --
    in particular, a finding with no lint name (a design/process judgment like
    "no labelled corpus exists") is NOT this mechanism's business: clippy has
    no opinion on test corpus adequacy, and pretending otherwise would convict
    or clear a claim this organ cannot actually read.
    """
    match = _CARGO_CLIPPY_RE.search(finding)
    if not match:
        return None
    rel_file, lint_name = match.group(1), match.group(2)
    if not Path(rel_file).is_absolute() and _target_is_kit_exempt(root, rel_file):
        return False
    target_path = Path(rel_file) if Path(rel_file).is_absolute() else (root / rel_file)
    if not target_path.is_file():
        return False
    if not (root / "Cargo.toml").is_file():
        return None  # no crate here to run clippy against -- unclaimed, not cleared
    cargo_bin = shutil.which("cargo")
    if not cargo_bin:
        return True  # can't verify absence of the lint; fail-closed like the ruff twin
    cmd = [cargo_bin, "clippy", "--message-format=short", "--", "-W", f"clippy::{lint_name}"]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False, cwd=root)
    combined = result.stdout + result.stderr
    return (rel_file in combined) and (lint_name in combined)


def _verify_loose_ruff_finding(root: Path, finding: str) -> bool | None:
    match = _RUFF_LOOSE_RE.search(finding)
    if not match:
        return None
    rel_file, rule_code = match.group(1), match.group(2)
    if not Path(rel_file).is_absolute() and _target_is_kit_exempt(root, rel_file):
        return False
    target_path = Path(rel_file) if Path(rel_file).is_absolute() else (root / rel_file)
    if target_path.is_file():
        targets = [target_path]
    else:
        # ANTI-RENAME. A missing file is not proof the vice is gone: moving the
        # offending function to a new path erases the finding's address, not the
        # finding. _find_symbol_in_tree exists for exactly this and was never
        # wired to anything but a coverage test; it is the mechanism here. With
        # no backticked symbol to chase there is nothing to read, so the finding
        # stays unclaimed (COULD_NOT_RUN) rather than being waved through.
        symbol = re.search(r"`(\w+)`", finding)
        if symbol is None:
            return None
        targets = _find_symbol_in_tree(root, symbol.group(1))
        if not targets:
            return False
    ruff_bin = shutil.which("ruff")
    if not ruff_bin:
        return True
    for target in targets:
        cmd = [ruff_bin, "check", "--select", rule_code, "--output-format", "concise", str(target)]
        completed = subprocess.run(cmd, capture_output=True, text=True, check=False)
        # ruff: 0 = limpio, 1 = violaciones, 2 = NO ARRANCÓ. Ese 2 es el que
        # importa, y colapsarlo con el 1 es el fallo que esta casa persigue: un
        # instrumento caído indistinguible de un sujeto roto.
        #
        # `_RUFF_LOOSE_RE` adivina el código de regla de un texto en prosa, y
        # adivina mal en cuanto el repo numera sus fichas con la forma de una
        # regla. Medido en office2office 2026-09-04: el finding de `TASK-F106`
        # cita `tests/test_fidelity_canaries.py` y, más adelante en la misma
        # frase, `TASK-F100`. El patrón extrae `F100`, `ruff --select F100`
        # contesta `Unknown rule selector` con rc=2, y la ficha quedaba
        # condenada como FRAUDE **para siempre**: ninguna corrección del código
        # podía cambiar ese veredicto, porque no dependía del código. Ese repo
        # tiene fichas F-006, F-011, F-020, F-037, TASK-F100..F107 -- la
        # colisión no es rara ahí, es sistemática.
        #
        # Devolver None deja el finding SIN RECLAMAR, que es lo honesto: cae a
        # COULD_NOT_RUN y `_check_task_fraud` escala al `verification_command`
        # de la propia ficha, que sí es prueba ejecutable.
        if completed.returncode >= _RUFF_USAGE_ERROR:
            return None
        if completed.returncode != 0:
            return True
    return False


_UNSELECTED_RULE_RE = re.compile(r"^pyproject\.toml: missing mandatory rule `?(\w+)`?$")


def _verify_unselected_rules_finding(root: Path, finding: str) -> bool | None:
    match = _UNSELECTED_RULE_RE.match(finding.strip())
    if not match:
        return None
    from simplecode.guards.unselected_rules import audit_linter_rules
    return match.group(1) in audit_linter_rules(root)


_GATE_FAILURE_RE = re.compile(r"^gate-failure: [\w.\-]+: command `(.+)` exited nonzero$")


def _verify_gate_failure_finding(root: Path, finding: str) -> bool | None:
    match = _GATE_FAILURE_RE.match(finding.strip())
    if not match:
        return None
    command = match.group(1)
    if _skips_execution(command, root):
        # The task-contract verifier separately reports this whitelist breach;
        # this instrument also keeps the finding unreadable because it did not run.
        return None
    disposition, _ = _classify_task_verification(root, command)
    if disposition == VERIFY_COULD_NOT_RUN:
        return None
    return disposition == VERIFY_REPRODUCES


# Ordered: every named mechanism gets first refusal, and the loose ruff/cargo
# reads are LAST so they only ever rescue a finding that would otherwise be
# unreadable -- neither can outbid a registered detector for a finding that
# mentions a code.
_FINDING_MECHANISMS = (
    _verify_ruff_finding,
    _verify_zero_debt_finding,
    _verify_angry_path_finding,
    _verify_corruption_finding,
    _verify_detector_finding,
    _verify_unselected_rules_finding,
    _verify_gate_failure_finding,
    _verify_loose_ruff_finding,
    _verify_cargo_finding,
)


def classify_finding(root: Path, finding: str) -> str:
    """Classify one registered finding THREE ways, never two.

    Returns ``VERIFY_OK`` (a mechanism ran and the finding is gone),
    ``VERIFY_REPRODUCES`` (a mechanism ran and the finding is still there), or
    ``VERIFY_COULD_NOT_RUN`` (NO mechanism could read this finding at all).

    The third state is the one this function exists for. The five mechanisms
    each answer ``None`` for "not my jurisdiction", and the old code collapsed
    "nobody claimed it" into ``True`` -- *the finding reproduces* -- without
    looking at anything. That is not fail-closed, it is unfalsifiable: a finding
    tagged with a detector that is not registered (measured live on Atlas:
    `(detector: import_no_resuelve)`, absent from PATTERN_DETECTORS) reads as
    reproducing forever, however thoroughly the code is fixed, and the task is
    auto-reverted as FRAUD every time. Naming the state instead lets
    :func:`_check_task_fraud` escalate to the task's own mandatory
    ``verification_command`` -- machine-executable proof, whitelisted and
    no-op-filtered -- and, failing that, report an instrument that is down
    rather than convict the subject.

    Fail-closed is preserved where it means something: a finding a mechanism DID
    claim is judged by that mechanism, and the scalar façade
    :func:`verify_finding_reproduces` still reads the unclaimed case as
    reproducing.
    """
    for mechanism in _FINDING_MECHANISMS:
        verdict = mechanism(root, finding)
        if verdict is not None:
            return VERIFY_REPRODUCES if verdict else VERIFY_OK
    return VERIFY_COULD_NOT_RUN


def _unreadable_finding_detail(finding: str) -> str:
    """Say WHY no mechanism could read this finding, naming the missing organ."""
    tag = _DETECTOR_TAG_RE.search(finding)
    if tag is not None:
        from simplecode.guards.pattern_detectors import PATTERN_DETECTORS
        if tag.group(1) not in {key for _fn, key, _msg in PATTERN_DETECTORS}:
            return (
                f"{finding}\n      -> tagged `(detector: {tag.group(1)})`, which is NOT registered "
                "in simplecode.guards.pattern_detectors.PATTERN_DETECTORS: no organ can re-check it"
            )
    return (
        f"{finding}\n      -> no registered mechanism (ruff / zero-debt / angry-path / corruption / "
        "detector) matches this text: no organ can re-check it"
    )


def verify_finding_reproduces(root: Path, finding: str) -> bool:
    """Scalar façade over :func:`classify_finding` (Fail-Closed).

    Collapses the three dispositions into the historical ``bool``: anything that
    is not a clean PASS reads as reproducing, so a finding no mechanism could
    read stays conservative for every caller that wants one bit. Callers that
    must tell a genuine reproduce from an instrument that could not run call
    :func:`classify_finding` directly.
    """
    return classify_finding(root, finding) != VERIFY_OK


def _revert_fraud_task(root: Path, task_path: Path, content: str) -> None:
    new_content = re.sub(r"^status:\s*.+?$", "status: open", content, flags=re.M)
    backlog_dir = root / "tasks" / "backlog"
    backlog_dir.mkdir(parents=True, exist_ok=True)
    target_path = backlog_dir / task_path.name
    atomic_io.write_text_durable(target_path, new_content)
    if task_path != target_path:
        try:
            task_path.unlink()
        except OSError as exc:
            logger.debug("Could not unlink reverted task %s: %s", task_path, exc)
            return
        # `unlink()` only touches the working tree; a task previously closed
        # in a real commit stays in git's INDEX (`git ls-files` still lists
        # it) until someone stages the deletion. Every reader that trusts
        # `tracked_files()` -- dangling_refs among them -- then hits a file
        # the index promises exists but disk does not: a spurious
        # "cannot read" for a path this very function deleted on purpose.
        # `git rm --cached` reconciles the index with the working tree right
        # here, so the gap never outlives this call. Reported live on Atlas
        # 2026-08-29 (atlas-8b): 3 closed tasks reverted in an earlier
        # satellite_sync pass stayed tracked-but-missing across sessions.
        try:
            subprocess.run(
                ["git", "rm", "--cached", "--ignore-unmatch", "-q", "--", str(task_path)],
                cwd=root, capture_output=True, text=True, timeout=GIT_O1_TIMEOUT, check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            logger.debug("Could not stage deletion of reverted task %s: %s", task_path, exc)


def _configured_test_paths(root: Path) -> tuple[str, ...]:
    """`testpaths` declared in pyproject.toml's `[tool.pytest.ini_options]`, if any.

    Reported live (aequitas_os, busy-jackson-375a20 worktree, 2026-08-28):
    `_test_corpus_bytes` hardcoded `root / "tests"` as pytest's whole payload,
    but aequitas_os declares `testpaths = ["tests", "backend/tests"]` -- the
    root `tests/` it measured is 10 files / 30,530 bytes of tooling tests;
    the real corpus pytest actually collects, `backend/tests/`, is 1,648,784
    bytes (~54x larger) and was never counted, timing the coverage_target
    wrapper's proportional bound out at 33s (30s base + 30,530/10,000)
    against a real ~195s run.

    Known residual gap, not fixed here: `pytest.ini`/`setup.cfg`/`tox.ini`
    `[pytest] testpaths` (ini format, not TOML) isn't read -- no repo in the
    fleet has been reported using that form; `pyproject.toml` is the modern
    default and the only shape measured live so far.
    """
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        return ()
    try:
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except (tomllib.TOMLDecodeError, OSError, UnicodeDecodeError):
        return ()
    testpaths = data.get("tool", {}).get("pytest", {}).get("ini_options", {}).get("testpaths", [])
    if not isinstance(testpaths, list):
        return ()
    return tuple(p for p in testpaths if isinstance(p, str) and p.strip())


def _test_corpus_bytes(root: Path) -> int:
    """Total bytes of python test sources under every configured testpath.

    Falls back to `root/tests` alone when pyproject.toml declares no
    `testpaths` -- the pre-existing behavior for every repo that doesn't
    split its suite across multiple directories.
    """
    configured = _configured_test_paths(root)
    test_dirs = tuple(root / p for p in configured) if configured else (root / "tests",)
    total = 0
    seen: set[Path] = set()
    for test_dir in test_dirs:
        if not test_dir.is_dir():
            continue
        for py in sorted(test_dir.rglob("*.py")):
            if py in seen:
                continue
            seen.add(py)
            try:
                total += py.stat().st_size
            except OSError as exc:
                logger.debug("Could not stat test file %s: %s", py, exc)
    return total


def _source_tree_bytes(root: Path) -> int:
    """Total bytes of python source under root -- the pyright type-check payload.

    Same proxy shape as `_test_corpus_bytes` for pytest. Mirrors
    `_find_symbol_in_tree`'s hidden-dir exclusion so `.venv`/`.git`/cache
    trees don't inflate the count with source pyright never actually reads.
    """
    total = 0
    for py in root.rglob("*.py"):
        if any(part.startswith(".") for part in py.parts):
            continue
        try:
            total += py.stat().st_size
        except OSError as exc:
            logger.debug("Could not stat source file %s: %s", py, exc)
    return total


def _is_pytest_wrapper_invocation(tokens: list[str]) -> bool:
    """True for a module whose whole job is to shell out to bare `pytest`.

    See TASK_VERIFICATION_PYTEST_WRAPPER_MODULES above for the measured case
    this exists for: a one-level wrapper (`python .simplecode/run.py <module>`
    or `python -m <module>`) is not the `pytest ...` shape
    `_is_pytest_invocation` matches, even though its real cost is exactly as
    proportional to test-corpus bytes as a bare pytest call.
    """
    if len(tokens) < 3:
        return False
    if tokens[1] not in ("-m", ".simplecode/run.py"):
        return False
    return tokens[2] in TASK_VERIFICATION_PYTEST_WRAPPER_MODULES


def _is_pytest_invocation(tokens: list[str]) -> bool:
    """True for a bare `pytest ...` AND for `python[3] -m pytest ...`.

    Reported live (this repo, 2026-08-27): `DEBT-REDESIGN-05`'s
    `verification_command` is `python -m pytest tests/test_artifact_verifier.py
    tests/test_backlog_behavior.py -q` -- a genuinely slow suite (builds and
    installs a real wheel/sdist), measured at 29.6s wall time, right at the
    edge of the flat 30s base bound this task got instead of the proportional
    one, because `tokens[0]` is `python`, not `pytest`. The base-vs-proportional
    split exists so a suite's own real cost decides its bound; a command
    shaped `python -m pytest` is exactly as proportional-cost as a bare
    `pytest` invocation, just spelled differently.
    """
    if not tokens:
        return False
    if Path(tokens[0]).name.startswith("pytest"):
        return True
    return (
        Path(tokens[0]).name.startswith("python")
        and len(tokens) >= 3
        and tokens[1] == "-m"
        and tokens[2] == "pytest"
    )


def _task_verification_timeout(root: Path, raw_cmd: str) -> float:
    """Honest execution bound for a verification_command (see constants above)."""
    tokens = shlex.split(raw_cmd)
    # An empty command has no token to read a cost class off, and until 2026-09-06 the
    # `Path(tokens[0])` further down raised IndexError on it. Inside the gate that was
    # unreachable -- validation rejects the empty command first -- so it was a latent
    # crash waiting for a second caller, and `check_close_check` is exactly that: it
    # asks for the budget of whatever the author typed, including nothing. The base
    # bound is the honest answer: there is nothing here proportional to anything.
    if not tokens:
        return TASK_VERIFICATION_BASE_TIMEOUT
    if _is_pytest_invocation(tokens) or _is_pytest_wrapper_invocation(tokens):
        return compute_proportional_timeout(
            _test_corpus_bytes(root),
            base_timeout_sec=TASK_VERIFICATION_BASE_TIMEOUT,
            bytes_per_sec=TASK_VERIFICATION_BYTES_PER_SEC,
            max_timeout_sec=TASK_VERIFICATION_MAX_TIMEOUT,
        )
    if any(module in tokens for module in TASK_VERIFICATION_WHOLE_REPO_SCAN_MODULES):
        return TASK_VERIFICATION_WHOLE_REPO_SCAN_TIMEOUT
    if load_declared_whole_repo_scan_commands(root)[0].intersection(tokens):
        return TASK_VERIFICATION_WHOLE_REPO_SCAN_TIMEOUT
    # The trusted gate_runner-authored pre-commit invocation runs EVERY
    # pre-commit-stage gate over --all-files -- a whole-repo multi-scan by
    # construction, same cost class as the modules above, not a single-pass
    # command. Measured live (aequitas_os, 2026-08-29): a real, PASSING run
    # took ~3-4 min and the flat 30s base bound false-flagged it as
    # COULD_NOT_RUN on every closed-task spot-check, blocking pre-push over a
    # genuinely closed task. 450s keeps ~1.9x margin over that measurement.
    if _TRUSTED_PRE_COMMIT_INVOCATION_RE.match(raw_cmd.strip()):
        return TASK_VERIFICATION_WHOLE_REPO_SCAN_TIMEOUT
    if Path(tokens[0]).name == "pyright":
        return compute_proportional_timeout(
            _source_tree_bytes(root),
            base_timeout_sec=TASK_VERIFICATION_BASE_TIMEOUT,
            bytes_per_sec=TASK_VERIFICATION_PYRIGHT_BYTES_PER_SEC,
            max_timeout_sec=TASK_VERIFICATION_MAX_TIMEOUT,
        )
    return TASK_VERIFICATION_BASE_TIMEOUT


# The ficha's declared `close_check.timeout`, set for the length of ONE
# `_judge_declared_command` call. A context variable and not a parameter, measured
# reasons: `_classify_task_verification` already sits at ruff's PLR0913 ceiling (5
# arguments), and `tests/test_backlog_verify_persistent_cache.py` monkeypatches
# `_classify_uncached` with a three-argument stub. `set` inside a ThreadPoolExecutor
# worker changes only that thread's context, so one ficha's budget never reaches another.
_DECLARED_TIMEOUT: contextvars.ContextVar[float | None] = contextvars.ContextVar(
    "declared_close_check_timeout", default=None)


def _classify_task_verification(
    root: Path,
    raw_cmd: str,
    expect: str | None = None,
    cache: dict[str, tuple[str, str | None]] | None = None,
    *,
    expect_mode: str | None = None,
) -> tuple[str, str | None]:
    """Run a task's declared closing command and classify the outcome three ways.

    Returns ``(disposition, detail)`` where ``disposition`` is one of
    ``VERIFY_OK`` / ``VERIFY_REPRODUCES`` / ``VERIFY_COULD_NOT_RUN`` and
    ``detail`` is None on PASS and a human-readable line otherwise. The cache is
    keyed by ``(raw_cmd, expect, expect_mode)`` because the same command may be
    judged against different success criteria by different tasks -- and
    `empty_stdout` is a STRICTER criterion than `exit_zero`, so a key that
    ignored the mode would let one ficha's pass answer for another's stricter
    question.
    """
    # The declared budget is part of the question: the same command under 900s and under
    # the derived 30s can come back OK and COULD_NOT_RUN, so neither may answer for the other.
    key = f"{raw_cmd}\x00{expect or ''}\x00{expect_mode or ''}\x00{_DECLARED_TIMEOUT.get() or ''}"
    if cache is None:
        return _classify_uncached_for(root, raw_cmd, expect, expect_mode)
    # Check-then-run under the key's own lock (DEBT-backlog-verifier-no-dedup-close-check-identico):
    # `audit_closed_tasks` classifies fichas from a thread pool, and without this every ficha
    # sharing one command found the cache empty AT THE SAME TIME and ran it itself -- 6 fichas
    # sharing `pytest tests/ -q` ran the suite 6 times in one pass (declutter, 2026-09-28).
    # The verdict is shared as-is: a REPRODUCES or COULD_NOT_RUN answers every ficha that
    # asked the same question with that same disposition, never as OK.
    with _command_key_lock(cache, key):
        if key in cache:
            return cache[key]
        result = _classify_uncached_for(root, raw_cmd, expect, expect_mode)
        cache[key] = result
    return result


class CommandVerdictCache(dict):
    """The in-pass command cache, plus one lock per key so concurrent callers asking
    the same question wait for the first answer instead of each running the command.
    A plain dict (single-threaded callers, older tests) still works, unlocked."""

    def __init__(self) -> None:
        super().__init__()
        self._guard = threading.Lock()
        self._locks: dict[str, threading.Lock] = {}

    def lock_for(self, key: str) -> threading.Lock:
        with self._guard:
            return self._locks.setdefault(key, threading.Lock())


def _command_key_lock(cache: dict, key: str) -> threading.Lock | contextlib.nullcontext:
    if isinstance(cache, CommandVerdictCache):
        return cache.lock_for(key)
    return contextlib.nullcontext()


def _classify_uncached_for(
    root: Path, raw_cmd: str, expect: str | None, expect_mode: str | None
) -> tuple[str, str | None]:
    # The canon criterion is passed ONLY when there is one. The classic path --
    # every call that existed before the canon's `expect:` vocabulary did --
    # keeps reaching `_classify_uncached` with the exact three-argument shape it
    # always had, which is what `tests/test_backlog_verify_persistent_cache.py`
    # monkeypatches with a three-argument stub. Declared cost: a canon-path
    # monkeypatch of the same function must accept the keyword.
    if expect_mode is None:
        return _classify_traced(root, raw_cmd, lambda: _classify_uncached(root, raw_cmd, expect))
    return _classify_traced(
        root, raw_cmd, lambda: _classify_uncached(root, raw_cmd, expect, expect_mode=expect_mode)
    )


def _pre_commit_verified_nothing(combined_output: str) -> bool:
    """True when a `pre-commit run` invocation's own terminal output shows
    every hook Skipped and not one Passed -- rc=0 either way, but "nothing
    matched any hook's file filter" and "every hook ran and found nothing
    wrong" print identically as far as the exit code goes. Only the words
    pre-commit itself prints tell them apart."""
    return "Skipped" in combined_output and "Passed" not in combined_output


# `NAME=<n>` or `NAME: <n>` -- the counter WITH its value, which is the only
# form that can say "zero instruments went down" as opposed to merely naming
# the concept.
_COULD_NOT_RUN_VALUED = re.compile(
    r"\bCOULD(?:_| )NOT(?:_| )RUN\b\s*[:=]\s*(\d+)", re.I
)
_COULD_NOT_RUN_ANY = re.compile(r"\bCOULD(?:_| )NOT(?:_| )RUN\b", re.I)


def _self_reported_could_not_run(combined_output: str) -> bool:
    """True when a trusted verifier says its instrument/acquisition failed.

    Reads the counter's VALUE, not its NAME. The previous implementation
    grepped the name alone, and every gate in this kit prints its counters
    unconditionally -- including the zeros, which is the reporting doctrine
    ("print the zeros"). So a perfectly clean run that printed
    `COULD_NOT_RUN=0` tripped the same pattern as a run whose instruments
    really had gone down, and a REAL conviction (`CONVICTED=1`,
    `COULD_NOT_RUN=0`, rc=1) was classified "instrument-down, not fraud" --
    the verdict got buried by the very line that proves it should not be.
    Measured 2026-09-05 on cuenza against verbatim `zero_debt` output.

    A bare mention with no value (`COULD_NOT_RUN: could not read the
    subject`) still counts as instrument-down: that form IS how a command
    with no counters reports the condition, and it is the behaviour this
    function had before. Values and bare mentions can appear in the same
    output, so a zero counter never silences a bare report elsewhere in it.
    """
    valores = [int(v) for v in _COULD_NOT_RUN_VALUED.findall(combined_output)]
    if any(v > 0 for v in valores):
        return True
    # Strip the `NAME=<n>` pairs already judged above; whatever mention of
    # the name survives is a valueless one, and those still count.
    residual = _COULD_NOT_RUN_VALUED.sub("", combined_output)
    return bool(_COULD_NOT_RUN_ANY.search(residual))


# A trusted verifier's conviction counter WITH its value. `failed=` is what
# `ledger_schema` and most kit gates print; `CONVICTED=` is the zero_debt form
# `_self_reported_could_not_run` already documents.
_FAILED_VALUED = re.compile(r"\b(?:failed|convicted)\s*[:=]\s*(\d+)", re.I)


def _self_reported_failures(combined_output: str) -> bool:
    """True when a trusted verifier says it CONVICTED something (`failed=N`, N > 0).

    Measured 2026-10-06 in office2office: `ledger_schema --root .` exited 1 printing
    `failed=19 ... could_not_run=1` -- nineteen fichas with an invalid schema and one
    it could not parse. The rc came from the nineteen (`main` returns on `failed`
    before it looks at could_not_run), yet the `could_not_run=1` beside them made this
    module call the whole run instrument-down. A conviction is evidence even when
    another part of the same run could not execute -- the same rule
    `_check_task_fraud` applies across findings."""
    return any(int(v) > 0 for v in _FAILED_VALUED.findall(combined_output))


def _venv_prepended_env(root: Path) -> dict[str, str] | None:
    """Environment for a verification_command subprocess, with ``root``'s own
    ``.venv/bin`` prepended to PATH when one exists -- mirroring
    ``hook_install._preamble``'s ``[ ! -d "$ROOT/.venv/bin" ] || PATH=...``
    exactly, so a bare ``python`` in a task's verification_command resolves
    the same way here as it would inside a real git hook for that repo.

    Without this, whoever CALLS this classifier (a real pre-push hook inside
    ``root``, but also -- reported live by Atlas, 2026-08-26 -- fleet-wide
    ``satellite_sync --fix`` auditing a satellite's closed tasks from a
    DIFFERENT shell entirely) determines which python answers "python": a
    real hook's own process already has ``root``'s ``.venv/bin`` on PATH, but
    a cross-repo caller's ambient PATH has no reason to, so the same task
    verified from a fleet-sync run silently resolves a different, unrelated
    interpreter -- one with none of ``root``'s own dependencies installed --
    and reports fraud that has nothing to do with the task's actual fix.
    Returns None (meaning: inherit the caller's own environment untouched)
    when ``root`` has no ``.venv/bin`` at all, so behavior for such repos is
    byte-identical to before this existed.
    """
    venv_bin = root.resolve() / ".venv" / "bin"  # absolute: a child that changes cwd must find it
    env = None
    if venv_bin.is_dir():
        env = os.environ.copy()
        env["PATH"] = f"{venv_bin}{os.pathsep}{env.get('PATH', '')}"
    trace_dir = _TRACE_DIR.get()
    if trace_dir is None:
        return env
    # Inside `_classify_traced`: the close_check traces what it reads (close_check_trace).
    return close_check_trace.traced_env(os.environ if env is None else env, trace_dir, root)


# DEBT-BACKLOG-VERIFIER-INDIRECT-RECURSION-20261007. `_is_self_referential` reads only the
# close_check's own command line; a close_check like `pytest tests/test_x.py` whose test spawns
# `backlog_verifier --gate` on the same repo recursed without bound (blackbox, 2026-10-06: the
# pre-push hung over an hour). Every close_check is launched with the resolved roots being audited
# above it, this one APPENDED (a -> b -> a is caught on the way back to a; a nested run over a
# different root, as simplecode's own tests do, is audited normally).
ACTIVE_ROOTS_ENV = "SIMPLECODE_BACKLOG_VERIFIER_ACTIVE_ROOTS"
# The refusal's own way back to the close_check launch that caused it: a file in that launch's trace
# dir. A close_check that hides its child's output (a test asserting only `returncode == 0` prints
# `assert 2 == 0`) never shows the COULD_NOT_RUN line; measured 2026-10-07, the parent was FRAUD.
REENTRY_FLAG_ENV = "SIMPLECODE_BACKLOG_VERIFIER_REENTRY_FLAG"
_REENTRY_FLAG_NAME = "backlog_verifier_reentered"


class AuditReentered(RuntimeError):
    """`audit_closed_tasks` was started on a root a backlog_verifier above it is already auditing.
    The message carries the bare word COULD_NOT_RUN, so the outer run reads its close_check as
    instrument-down (`_self_reported_could_not_run`), never as the finding reproducing."""


def _active_roots(environ: Mapping[str, str]) -> list[str]:
    return [r for r in environ.get(ACTIVE_ROOTS_ENV, "").split(os.pathsep) if r]


def _close_check_env(root: Path) -> dict[str, str]:
    """The environment a close_check runs with: `_venv_prepended_env`'s (PATH, tracer), plus this
    run's resolved root appended to the marker -- added last, so neither rebuild can drop it."""
    env = dict(_venv_prepended_env(root) or os.environ)
    env[ACTIVE_ROOTS_ENV] = os.pathsep.join([*_active_roots(env), str(root.resolve())])
    trace_dir = _TRACE_DIR.get()
    env[REENTRY_FLAG_ENV] = os.path.join(trace_dir, _REENTRY_FLAG_NAME) if trace_dir else ""
    return env


_SELF_MODULE = "simplecode.verification.backlog_verifier"


def _is_self_referential(raw_cmd: str) -> bool:
    """True when a task's OWN verification_command re-invokes backlog_verifier.

    Reported live (Atlas, 2026-08-27): with no guard, verifying such a task
    spawns a nested backlog_verifier run that re-scans every closed task --
    including this same self-referential one -- spawning another nested run,
    unbounded. When the outer git push eventually times out and gets killed,
    only the top of that tree receives the signal; orphaned descendants
    (reparented to the OS's subreaper) keep running, still spawning new
    children if the recursion hadn't been cut yet (measured: 20 live
    `backlog_verifier --gate` processes, then 17 an hour later, no legitimate
    wrapper above any of them).

    Its cost also scales with total task count -- the same count THIS run is
    already busy growing every time it closes a ticket -- so a fixed timeout
    keeps losing that race as the repo grows (measured live, aequitas_os,
    2026-08-27, same session: 90s -> 240s -> 281s -> still timing out at
    450s). A bigger constant is not a fix; it is chasing a moving target.
    The outer run's eventual exit is unavailable to this inner classification
    until the audit finishes. Treating that future result as proof would skip
    the task's declared command and could falsely accept an unobserved expect
    marker. Return NOT_APPLICABLE (recursion) without spawning; the recursion
    is stopped, and the audit does not claim evidence it never observed. It was
    COULD_NOT_RUN until 2026-10-06, which blocked the push over an instrument
    that never went down (voto de Luis, C/D).
    """
    return _SELF_MODULE in shlex.split(raw_cmd)


def _skips_execution(raw_cmd: str, root: Path | None = None) -> bool:
    """True when `raw_cmd` must never actually be run: either the contract
    verifier's own jurisdiction (an unwhitelisted/malformed command --
    classifying it NOT_APPLICABLE avoids calling it fraud while still refusing
    to report a pass), or a
    self-referential re-invocation of backlog_verifier (see
    `_is_self_referential`).

    `root` MUST be threaded through, and its absence was a live hole. The
    "unwhitelisted commands are the contract verifier's jurisdiction" bargain
    only holds while both organs answer the whitelist question the same way.
    `validate_task_contract` passes `root`, so a repo's own
    `.simplecode/build_tools.txt` declaration makes `cargo test` VALID there and
    it reports no breach; this call did not, so the same command read as invalid
    HERE and was waved through as PASS -- and nobody blocked. Measured
    2026-09-05 on a disposable repo declaring `zigbuild` (a binary this machine
    does not have, `which zigbuild` rc=1): a `done` ficha closing on
    `zigbuild test --all` produced frauds: 0, could_not_run: 0,
    contract_breaches: 0, rc=0. With `root` threaded it lands in COULD_NOT_RUN,
    named -- the command could not launch, so it proved nothing.
    """
    valid_cmd, _ = _validate_verification_cmd(raw_cmd, root=root)
    return not valid_cmd or _is_self_referential(raw_cmd)


_PERSISTENT_VERIFY_CACHE_RELPATH = Path(".simplecode") / "backlog_verify_cache.json"
# Guards _record_persistent_verify_pass's read-merge-write against the file above. See that
# function's own comment for why the read under this lock must stay a FRESH one.
_PERSISTENT_CACHE_WRITE_LOCK = threading.Lock()

# DEBT-BACKLOG-VERIFIER-INCREMENTAL-MODE-20261006. A cached PASS is reused only when every input
# the close_check was OBSERVED reading (`close_check_trace`) is unchanged. It replaces a key that
# hashed every tracked `.py`, the caller's PATH/interpreter and a clean-tree requirement -- which,
# measured 2026-10-06, re-executed everything in office2office after any commit or version bump,
# in declutter after the hook wrote its own untracked schedule file, and in simplecode whenever
# a different caller ran it. What the tracer cannot see is never cached (see that module).
_TRACE_DIR: contextvars.ContextVar[str | None] = contextvars.ContextVar("bv_trace_dir", default=None)
# (root, raw_cmd) -> (observed inputs, None) or (None, why they cannot be sealed), for the
# commands this run actually executed. Filled under the command's own dedup lock.
_RUN_SEALS: dict[tuple[Path, str], tuple[dict | None, str | None]] = {}
_RUN_SEALS_LOCK = threading.Lock()
# Per-run digest memo: one read per input file, however many fichas share it.
_DIGEST_MEMO: dict[str, str] = {}
# Per-root declaration counters for this run (`incremental_summary`), and roots run with --full.
_INCREMENTAL: dict[Path, Counter] = {}
_UNSEALABLE_REASONS: dict[Path, Counter] = {}
_FULL_RUN: set[Path] = set()
_INCREMENTAL_LOCK = threading.Lock()
# ponytail: the clock is an input no tracer observes (a check comparing an expiry date with
# today goes stale with no file changing), so an entry expires after one day; ceiling: such a
# verdict can be stale up to this long; trigger: a --full run convicting a ficha incremental passed.
_INCREMENTAL_MAX_AGE_S = 24 * 3600
# Roots inside `audit_closed_tasks`: their fresh entries are written ONCE, at the end of the run.
# One read-merge-write per PASS rewrote the whole file 236 times in one run (6.8 MB each time,
# measured 2026-10-06); a run killed midway loses only its new entries, which re-execute next run.
_PENDING_ENTRIES: dict[Path, dict[str, dict]] = {}
# A PASS whose close_check ran a non-Python child inside the repo (`close_check_trace`'s
# "repo_bound": a VCS log, a tar of the tree) is reused only while the WHOLE repo is the same
# snapshot: `verdict_cache.compute_key` (HEAD + clean tree, the whole-repo scanners' key) plus
# every ref. Taken once per run, at the first repo-bound ficha (a run with none spawns nothing
# for it); entries recorded while the repo moved are dropped when the run ends.
_REPO_SNAPSHOT: dict[Path, str | None] = {}
_REPO_SNAPSHOT_LOCK = threading.Lock()


def _run_snapshot(root: Path) -> str | None:
    root = root.resolve()
    with _REPO_SNAPSHOT_LOCK:
        if root not in _REPO_SNAPSHOT:
            _REPO_SNAPSHOT[root] = _repo_snapshot(root)
        return _REPO_SNAPSHOT[root]


def _repo_snapshot(root: Path) -> str | None:
    from simplecode.worktree import verdict_cache

    try:
        refs = subprocess.run(
            ["git", "for-each-ref", "--format=%(refname) %(objectname)"],
            cwd=root, capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if refs.returncode:
        return None
    return verdict_cache.compute_key(root, "backlog-verifier:repo-bound", registry_source_paths=(), extra=refs.stdout)


def _count(root: Path, key: str, reason: str | None = None) -> None:
    root = root.resolve()
    with _INCREMENTAL_LOCK:
        _INCREMENTAL.setdefault(root, Counter())[key] += 1
        if reason is not None:
            _UNSEALABLE_REASONS.setdefault(root, Counter())[reason.split(":")[0]] += 1


def _launcher(root: Path, raw_cmd: str) -> str | None:
    """Absolute path argv[0] resolves to in the environment the command runs with."""
    argv0 = shlex.split(raw_cmd)[0]
    if os.sep in argv0:
        return str((root / argv0).absolute())
    env = _venv_prepended_env(root) or os.environ
    return shutil.which(argv0, path=env.get("PATH"))


def _command_seal(root: Path, raw_cmd: str, inputs: dict) -> str:
    env = _venv_prepended_env(root) or os.environ
    return close_check_trace.seal(root, inputs, _launcher(root, raw_cmd), env, _DIGEST_MEMO)


def _classify_traced(root: Path, raw_cmd: str, run) -> tuple[str, str | None]:
    """Run `run()` with the close_check traced; keep what a PASS read for the cache to seal."""
    with tempfile.TemporaryDirectory(prefix="bv-trace-") as trace_dir:
        token = _TRACE_DIR.set(trace_dir)
        try:
            disposition, detail = run()
        finally:
            _TRACE_DIR.reset(token)
        if disposition == VERIFY_REPRODUCES and os.path.exists(os.path.join(trace_dir, _REENTRY_FLAG_NAME)):
            return VERIFY_COULD_NOT_RUN, (
                f"'{raw_cmd}' COULD_NOT_RUN: a backlog_verifier it started refused to re-audit a repo "
                f"already being audited above it (indirect recursion; not the finding reproducing) -- {detail}"
            )
        if disposition == VERIFY_OK:
            inputs, reason = close_check_trace.collect(trace_dir, os.getpid())
            if inputs is not None:
                inputs = close_check_trace.drop_transient_stats(root, inputs)
            with _RUN_SEALS_LOCK:
                _RUN_SEALS[(root.resolve(), raw_cmd)] = (inputs, reason)
    return disposition, detail


def incremental_summary(root: Path) -> str:
    """The declaration ficha condition 1 asks for: how many close_checks were NOT re-executed,
    and why every other one was -- every count printed, zeros included."""
    root = root.resolve()
    counts = _INCREMENTAL.get(root, Counter())
    consulted = sum(counts[k] for k in ("reused", "no_entry", "changed", "expired", "full"))
    if root in _FULL_RUN:
        return (f"full run (--full): every declared close_check re-executed, 0 reused "
                f"({counts['full']} consulted)")
    reasons = ", ".join(f"{n} {r}" for r, n in _UNSEALABLE_REASONS.get(root, Counter()).most_common())
    return (
        f"incremental: {counts['reused']} of {consulted} declared close_check(s) NOT re-executed "
        "(cached PASS, every observed input unchanged) · "
        f"{consulted - counts['reused']} re-executed: {counts['no_entry']} no cached PASS, "
        f"{counts['changed']} inputs changed, {counts['expired']} older than "
        f"{_INCREMENTAL_MAX_AGE_S // 3600}h · of the PASSes observed now, {counts['unsealable']} "
        f"cannot be cached and re-execute every run ({reasons or 'none'}) · --full re-executes all"
    )


# Path-like tokens a task's own markdown text or its verification_command
# names -- deliberately broad (any extension a task might cite: source,
# test, doc, config), narrowed to real files by `_cited_files` itself.
_CITED_FILE_RE = re.compile(r"[\w][\w./\-]*\.(?:py|md|yaml|yml|toml|json)\b")


def _cited_files(root: Path, raw_cmd: str, content: str) -> list[Path]:
    """Every file that exists under `root` and is named either by
    `raw_cmd` or anywhere in the task's own markdown body.

    A task's Issue/Root-Cause/Resolution prose in this repo's own house
    style names every file it touched (see e.g. `DEBT-ATLAS-05`) -- that
    text, plus the command's own file arguments, is treated as the task's
    declared dependency set. This does not see an UNDECLARED transitive
    import (a conftest.py never mentioned in either place); the tradeoff
    is deliberate, matching exactly what was asked upstream (hash of the
    command plus the files it cites), not a claim of full dependency
    tracking.
    """
    candidates = set(_CITED_FILE_RE.findall(raw_cmd)) | set(_CITED_FILE_RE.findall(content))
    paths = []
    for rel in sorted(candidates):
        candidate = root / rel
        if candidate.is_file():
            paths.append(candidate)
    return paths


def _read_bytes_or_empty(path: Path) -> bytes:
    """A cited file that vanished between the existence check and this read
    (TOCTOU) hashes as an empty read -- its absence is part of what changed,
    not silently ignored, since the caller folds every file's bytes into one
    hash regardless of which one came back empty."""
    try:
        return path.read_bytes()
    except OSError:
        return b""


def _files_content_hash(paths: list[Path]) -> str:
    """Hash of the concatenated content of `paths`, in the given (already
    sorted) order -- an empty or unreadable file hashes as an empty read,
    so a file cited but missing is part of what changed, not ignored."""
    h = hashlib.sha256()
    for p in paths:
        h.update(_read_bytes_or_empty(p))
        h.update(b"\0")
    return h.hexdigest()


def _load_persistent_verify_cache(root: Path) -> dict:
    path = root / _PERSISTENT_VERIFY_CACHE_RELPATH
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


# One read+parse of the persistent cache file per root per run, not one per task with a
# declared command. Measured against Atlas's real 344 KB backlog_verify_cache.json (764 governed
# tasks): 0.62s spent re-reading and re-parsing the SAME unchanged file, entirely inside what is
# now the ThreadPoolExecutor-parallel section of audit_closed_tasks -- pure held-GIL CPU that
# dilutes the concurrency win the profiling motivated. Same pattern as _ZERO_DEBT_SCAN_CACHE
# just above: a snapshot taken once at the top of a run, cleared there too, so a long-lived
# process (fleet-wide satellite auditing) never serves a snapshot from a DIFFERENT run.
#
# This is the READ path only. _record_persistent_verify_pass's write path must keep reading the
# file FRESH (never this snapshot) at write time, under its own lock: a fresh PASS from one task
# must be merged against whatever OTHER tasks' threads have already written, not against a
# stale run-start copy that would silently clobber them on save.
_PERSISTENT_CACHE_READ_SNAPSHOT: dict[Path, dict] = {}
_PERSISTENT_CACHE_READ_LOCK = threading.Lock()


def _load_persistent_verify_cache_cached(root: Path) -> dict:
    cached = _PERSISTENT_CACHE_READ_SNAPSHOT.get(root)
    if cached is not None:
        return cached
    with _PERSISTENT_CACHE_READ_LOCK:
        cached = _PERSISTENT_CACHE_READ_SNAPSHOT.get(root)
        if cached is None:
            cached = _load_persistent_verify_cache(root)
            _PERSISTENT_CACHE_READ_SNAPSHOT[root] = cached
    return cached


def persistent_verify_cache_summary(root: Path) -> str:
    """One line declaring how many verdicts this run MAY reuse from
    `backlog_verify_cache.json` and how old the oldest of them is.

    DEBT-AEQUITAS-09: the report never said a `frauds: 0` could be serving a
    verdict recorded days ago -- measured live in declutter, a PASS recorded
    2026-09-11 was still being served four days and three mother-version-
    bumps later. This does not fix that (the `cited == []` fix above does);
    it is the cheaper half the ficha also asked for, so a stale entry that
    DOES have real cited files (and can legitimately still be trusted) is at
    least visible, not silent. Threading a live per-run hit counter through
    `_persistent_verify_shortcut` was tried and dropped: it pushed that
    function's argument count over the repo's own PLR0913 ceiling (the
    comment on `_judge_declared_command` already flags this constraint) --
    a static read of the cache file says the same thing more cheaply.
    """
    cache = _load_persistent_verify_cache(root)
    if not cache:
        return "0 cached verdict(s) on file"
    ages = [e.get("recorded_at") for e in cache.values() if isinstance(e, dict)]
    ages = [a for a in ages if isinstance(a, (int, float))]
    if not ages:
        return f"{len(cache)} cached verdict(s) on file, none with a readable timestamp"
    oldest_days = (time.time() - min(ages)) / 86400
    return f"{len(cache)} cached verdict(s) on file, oldest recorded {oldest_days:.1f}d ago"


def _persistent_verify_shortcut(
    root: Path, task_rel: str, raw_cmd: str, expect: str | None, cited: list[Path]
) -> tuple[str, str | None] | None:
    """A task's own last recorded PASS, reused only when the exact command, the exact `expect:`
    criterion, the files its prose cites, and EVERY input the command was observed reading
    (`close_check_trace.seal`) are all unchanged, and the entry is younger than
    `_INCREMENTAL_MAX_AGE_S`. Every outcome is counted for `incremental_summary`.

    Only ever a hit on a past VERIFY_OK -- `_record_persistent_verify_pass` is called from
    nowhere else, so a REPRODUCES or COULD_NOT_RUN is never cached: a stale cache can only skip
    work that would have re-confirmed something already proven. An entry without a seal (written
    before observation existed, or by hand) is never trusted, whatever it claims: that includes
    DEBT-AEQUITAS-09's external-state entries keyed on an empty cited list.
    """
    if root.resolve() in _FULL_RUN:
        _count(root, "full")
        return None
    entry = _load_persistent_verify_cache_cached(root).get(task_rel)
    if not isinstance(entry, dict) or not isinstance(entry.get("inputs"), dict) or "seal" not in entry:
        _count(root, "no_entry")
        return None
    recorded_at = entry.get("recorded_at")
    if not isinstance(recorded_at, (int, float)) or time.time() - recorded_at > _INCREMENTAL_MAX_AGE_S:
        _count(root, "expired")
        return None
    rels = sorted(str(p.relative_to(root)) for p in cited)
    if (
        entry.get("raw_cmd") != raw_cmd or entry.get("expect") != expect
        or entry.get("cited_files") != rels or entry.get("files_hash") != _files_content_hash(cited)
        or entry["seal"] != _command_seal(root, raw_cmd, entry["inputs"])
        or not _snapshot_holds(root, entry)
    ):
        _count(root, "changed")
        return None
    _count(root, "reused")
    return VERIFY_OK, None


def _snapshot_holds(root: Path, entry: dict) -> bool:
    """A repo-bound PASS (see `_REPO_SNAPSHOT`) needs this run's snapshot to exist and match."""
    if not entry["inputs"].get("repo_bound"):
        return True
    current = _run_snapshot(root)
    return current is not None and entry.get("snapshot") == current


def _record_persistent_verify_pass(
    root: Path, task_rel: str, raw_cmd: str, expect: str | None, cited: list[Path]
) -> None:
    """Record a fresh PASS with the seal of everything the command was observed reading, so the
    NEXT run can skip it while all of that is unchanged. A PASS whose inputs could not be
    observed (`_RUN_SEALS` holds the reason) is not recorded and is counted as such. A write
    failure only costs the next run its cache hit -- the verdict this call is recording
    already ran and already reported, so it is swallowed, not raised.
    """
    with _RUN_SEALS_LOCK:
        inputs, reason = _RUN_SEALS.get(
            (root.resolve(), raw_cmd), (None, "not executed by this run: its verdict was not observed here")
        )
    snapshot = _run_snapshot(root) if inputs and inputs.get("repo_bound") else None
    if inputs is not None and inputs.get("repo_bound") and snapshot is None:
        inputs, reason = None, f"repo-bound, and the repo is not a clean commit: {inputs['repo_bound'][0]}"
    if inputs is None:
        _count(root, "unsealable", reason)
        return
    entry = {
        "raw_cmd": raw_cmd,
        "expect": expect,
        "cited_files": sorted(str(p.relative_to(root)) for p in cited),
        "files_hash": _files_content_hash(cited),
        "inputs": close_check_trace.keys_only(inputs),
        # Digested from the values the command OBSERVED, not from the disk now: an input
        # rewritten while it ran is sealed as what it read.
        "seal": _command_seal(root, raw_cmd, inputs),
        "snapshot": snapshot,
        "recorded_at": time.time(),
    }
    with _INCREMENTAL_LOCK:
        pending = _PENDING_ENTRIES.get(root.resolve())
        if pending is not None:
            pending[task_rel] = entry
            return
    _write_persistent_verify_entries(root, {task_rel: entry})


def _write_persistent_verify_entries(root: Path, entries: dict[str, dict]) -> None:
    path = root / _PERSISTENT_VERIFY_CACHE_RELPATH
    # Read-merge-write against the WHOLE file, under a lock: two writers racing a
    # read-then-full-overwrite would lose whichever one wrote second's view of the FIRST one's
    # fresh entries -- silent loss of just-recorded cache hits, not a crash, so nothing would
    # flag it. Deliberately a FRESH read here (never _load_persistent_verify_cache_cached's
    # run-start snapshot): this merge must see every write so far, not a copy from before.
    with _PERSISTENT_CACHE_WRITE_LOCK:
        data = _load_persistent_verify_cache(root)
        data.update(entries)
        try:
            atomic_io.write_text_durable(path, json.dumps(data, sort_keys=True, separators=(",", ":")))
        except OSError as exc:
            logger.warning("backlog-verifier cache write failed at %s: %s", path, exc)


def _check_field_label(expect_mode: str | None) -> str:
    """Which frontmatter field declared the command a message is about.

    Not a parameter: the canon `close_check:` is the only spelling that carries
    an `expect_mode` at all (see `_declared_closing_command`), so the mode's
    presence IS the spelling. One fact, derived in one place, instead of two
    arguments that can be threaded out of agreement with each other.
    """
    return "close_check" if expect_mode is not None else "verification_command"


def _verdict_from_completed(
    completed: subprocess.CompletedProcess, raw_cmd: str, expect: str | None, expect_mode: str | None
) -> tuple[str, str | None]:
    """Judge a command that actually finished. Split out from
    `_classify_uncached` so that function keeps only the LAUNCH concerns
    (shortcut, timeout, could-not-launch) and this one keeps only the
    criteria -- the two grew past ruff's C901 limit as one body once the
    canon's `expect:` vocabulary landed."""
    field = _check_field_label(expect_mode)
    combined_output = (getattr(completed, "stdout", "") or "") + (getattr(completed, "stderr", "") or "")
    if completed.returncode != 0:
        if _self_reported_could_not_run(combined_output) and not _self_reported_failures(combined_output):
            return VERIFY_COULD_NOT_RUN, (
                f"{field} '{raw_cmd}' COULD_NOT_RUN: its trusted verifier "
                "reported instrument/acquisition failure; this is not the finding reproducing"
            )
        if _INSTRUMENT_BUSY.search(combined_output):
            return VERIFY_COULD_NOT_RUN, (
                f"{field} '{raw_cmd}' {_BUSY_VERDICT} -- another control holds the lock "
                "this command needs, so it refused to run and never examined the finding "
                "(not the finding reproducing)"
            )
        # Reported live (Atlas, 2026-08-26): a fraud verdict that names only
        # the exit code, never the command's own stdout/stderr, gave nobody
        # -- not the task author, not the person diagnosing a fleet-wide
        # false positive -- anything to actually read. The tail (not head) is
        # kept: a traceback's actual error line is usually the LAST thing
        # printed, and the command's own output can be arbitrarily long
        # (a verbose test run). Same redaction gate_runner already applies to
        # its own captured output, reused here rather than re-invented.
        from simplecode.verification.gate_runner import _redact
        snippet = _redact(combined_output).strip()
        if len(snippet) > 500:
            snippet = snippet[-500:]
        detail_suffix = f" -- output: {snippet!r}" if snippet else " -- (no output captured)"
        return VERIFY_REPRODUCES, (
            f"{field} '{raw_cmd}' failed with exit code {completed.returncode}{detail_suffix}"
        )
    if _TRUSTED_PRE_COMMIT_INVOCATION_RE.match(raw_cmd.strip()) and _pre_commit_verified_nothing(combined_output):
        # Atlas 2026-08-25, literal output: two hooks, BOTH
        # "(no files to check)Skipped", overall rc=0. A pre-commit run whose
        # every hook was Skipped checked NOTHING -- that is not the same as a
        # clean run, and the anti-fraud audit already distinguishes exactly
        # this shape (a verification a mechanism cannot read is
        # COULD_NOT_RUN, never convicted as reproducing OR waved through as
        # OK). Without this, the task-contract's own mandatory
        # verification_command silently certified a no-op as proof.
        return VERIFY_COULD_NOT_RUN, (
            f"{field} '{raw_cmd}' exited 0 but every hook reported Skipped "
            "(no files to check) -- nothing was actually verified, not the same as clean"
        )
    if expect_mode == CLOSE_CHECK_EXPECT_EMPTY_STDOUT:
        # 13 fichas in the fleet close on a tool that exits 0 while still
        # PRINTING its findings (`ruff check . --output-format=concise` is every
        # one of them). For those, exit code alone certifies nothing.
        stdout = (getattr(completed, "stdout", "") or "").strip()
        if stdout:
            return VERIFY_REPRODUCES, (
                f"{field} '{raw_cmd}' exited 0 but its declared expect: "
                f"{CLOSE_CHECK_EXPECT_EMPTY_STDOUT!r} was not met -- stdout: {stdout[-500:]!r}"
            )
    if expect is not None and expect not in combined_output:
        return VERIFY_REPRODUCES, (
            f"{field} '{raw_cmd}' exited 0 but the declared expect: marker "
            f"{expect!r} was not found in its output"
        )
    return VERIFY_OK, None


# A command that mutates the tree under a lock (Atlas's mutation controls take /tmp/atlas_mutacion*.lock)
# exits nonzero WITHOUT having examined the ficha when a sibling holds the lock. Measured 2026-10-04 in
# Atlas with the watchdog paused (DGX-625): 95 of 102 reported "frauds" were that refusal, and a FRAUD verdict
# auto-reverts the ficha. A refusal to run is an instrument that did not execute, never the finding reproducing.
# `INSTRUMENT_BUSY` is the token a harness prints to say so on purpose; the two Spanish phrases are Atlas's
# literal messages. A harness with any other wording prints the token.
_INSTRUMENT_BUSY = re.compile(
    r"\bINSTRUMENT_BUSY\b|control de mutaci[oó]n CORRIENDO|tomado por otro control de mutaci[oó]n",
    re.IGNORECASE,
)
# The words that verdict carries, read back by `_is_busy` to pick the fichas for the serial lane.
_BUSY_VERDICT = "COULD_NOT_RUN: instrument busy"

# After the deadline a command is asked to stop, not killed: SIGINT first (a Python harness unwinds its
# `finally` and restores the file it mutated), then SIGTERM, then SIGKILL only if the group is still alive.
# `subprocess.run(timeout=)` went straight to SIGKILL on the direct child, which leaves a mutated tree behind.
_STOP_GRACE_SECONDS = 15.0


def _signal_group(pgid: int, sig: signal.Signals) -> None:
    with contextlib.suppress(ProcessLookupError, PermissionError):
        os.killpg(pgid, sig)


def _stop_group(proc: subprocess.Popen) -> None:
    """Escalate SIGINT -> SIGTERM -> SIGKILL on `proc`'s process group, waiting `_STOP_GRACE_SECONDS` between."""
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGKILL):
        _signal_group(proc.pid, sig)
        try:
            proc.communicate(timeout=_STOP_GRACE_SECONDS)
        except subprocess.TimeoutExpired:
            continue
        return


def _run_bounded(
    argv: list[str], *, cwd: Path, timeout: float, env: dict[str, str] | None,
) -> subprocess.CompletedProcess:
    """`subprocess.run` with a graceful stop. Raises `subprocess.TimeoutExpired` after the group has stopped."""
    proc = subprocess.Popen(
        argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        env=env, start_new_session=True,
    )
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except BaseException:
        _stop_group(proc)
        raise
    return subprocess.CompletedProcess(argv, proc.returncode, stdout, stderr)


def _classify_uncached(
    root: Path,
    raw_cmd: str,
    expect: str | None,
    *,
    expect_mode: str | None = None,
) -> tuple[str, str | None]:
    field = _check_field_label(expect_mode)
    if expect_mode is not None and expect_mode not in CLOSE_CHECK_EXPECT_VOCABULARY:
        # Refused BEFORE spawning anything: there is no point running a command
        # whose verdict this gate cannot read, and reporting OK after checking
        # something weaker than the ficha declared is the defect, not the fix.
        return VERIFY_COULD_NOT_RUN, (
            f"{field} '{raw_cmd}' COULD_NOT_RUN: its declared expect: {expect_mode!r} is not a "
            f"criterion this gate knows how to check (known: {', '.join(CLOSE_CHECK_EXPECT_VOCABULARY)}) "
            "-- the command was NOT run, and nothing about this task was verified"
        )
    # Recursion and the allowlist are NOT_APPLICABLE, not COULD_NOT_RUN (voto de Luis,
    # 2026-10-06, C/D): nothing went down -- running the command here cannot answer the
    # question, so it is not run, and the ficha is counted and named apart.
    if _is_self_referential(raw_cmd):
        return VERIFY_NOT_APPLICABLE, (
            f"{field} '{raw_cmd}' NOT_APPLICABLE ({NOT_APPLICABLE_RECURSION}): running "
            "backlog_verifier would re-enter this audit; the outer run's eventual exit is "
            "unavailable as evidence here, so its exit code and expect marker were not verified"
        )
    if _skips_execution(raw_cmd, root):
        return VERIFY_NOT_APPLICABLE, (
            f"{field} '{raw_cmd}' NOT_APPLICABLE ({NOT_APPLICABLE_OUTSIDE_ALLOWLIST}): the command "
            "was rejected by the task-contract whitelist, so it was NOT executed and its declared "
            "success criterion was not observed"
        )
    # A ficha's declared `close_check.timeout` replaces the derived budget (voto de Luis,
    # 2026-10-06, B); a ficha without one keeps the derived default.
    timeout = _DECLARED_TIMEOUT.get() or _task_verification_timeout(root, raw_cmd)
    try:
        completed = _run_bounded(
            shlex.split(raw_cmd), cwd=root, timeout=timeout, env=_close_check_env(root),
        )
    except subprocess.TimeoutExpired:
        # The wrapping timeout is a hang detector, not a verdict on the subject.
        return VERIFY_COULD_NOT_RUN, (
            f"{field} '{raw_cmd}' COULD_NOT_RUN: timed out after {timeout:.0f}s "
            "(instrument-down, not the finding reproducing)"
        )
    except OSError as exc:
        # FileNotFoundError (executable absent) is an OSError subclass; so is any
        # other launch failure. The command never ran, so it proves nothing.
        return VERIFY_COULD_NOT_RUN, (
            f"{field} '{raw_cmd}' COULD_NOT_RUN: could not launch ({exc}) "
            "(instrument-down, not the finding reproducing)"
        )
    return _verdict_from_completed(completed, raw_cmd, expect, expect_mode)


def _run_task_verification_cmd(
    root: Path,
    raw_cmd: str,
    cache: dict[str, str | None] | None = None,
) -> str | None:
    """Back-compat scalar façade over :func:`_classify_task_verification`.

    Returns None on PASS and the detail string on any non-passing disposition
    (REPRODUCES or COULD_NOT_RUN). Callers that must distinguish a genuine
    reproduce from an instrument that could not run use
    :func:`_classify_task_verification` directly; this collapses the two into the
    historical ``str | None`` contract (no `expect:` marker, exit-code semantics).
    """
    if cache is not None and raw_cmd in cache:
        return cache[raw_cmd]
    _disposition, detail = _classify_task_verification(root, raw_cmd)
    if cache is not None:
        cache[raw_cmd] = detail
    return detail


def _task_status_label(content: str) -> str:
    """The task's declared `status:` value, lowercased ("" when absent)."""
    match = re.search(r"^status:\s*(.+?)\s*$", content, re.M)
    return match.group(1).strip().lower() if match else ""


class ClosedAuditRows(list):
    """The could_not_run rows, plus -- in `.not_applicable` -- the closed fichas that got a
    DECLARED, non-blocking verdict instead (voto de Luis, 2026-10-06): NOT_APPLICABLE
    (recursion / outside allowlist) and prose findings not re-checkable. Rows there are
    `(path, kind, detail)`.

    A list subclass so `audit_closed_tasks` keeps returning `(frauds, could_not_run)`
    to every existing caller while `len(could_not_run)` stops counting what is not
    instrument-down. The declared rows are never silent: `main` prints their count and
    ids, zeros included."""

    def __init__(self) -> None:
        super().__init__()
        self.not_applicable: list[tuple[Path, str, str]] = []
        # DGX-637: the fichas refused "instrument busy" in the parallel pass and retried once,
        # serially, after it; `busy_unresolved` is the subset still busy after that retry.
        self.busy_retried: list[Path] = []
        self.busy_unresolved: list[Path] = []


def _declare_verdict(sink: list | None, task_path: Path, kind: str, detail: str) -> bool:
    """File a declared verdict in `sink.not_applicable`; False when the sink has no such
    place (a plain list from an older caller), so the caller files the old
    COULD_NOT_RUN row instead -- failing toward blocking, never dropping the row."""
    declared = getattr(sink, "not_applicable", None)
    if declared is None:
        return False
    declared.append((task_path, kind, detail))
    return True


def _judge_declared_command(
    root: Path,
    task_path: Path,
    content: str,
    command_cache: dict[str, tuple[str, str | None]] | None,
    could_not_run: list[tuple[Path, str, tuple[str, ...]]] | None,
) -> tuple[str, str | None]:
    """Run a closed task's declared closing command and file the honest row.

    Reads EITHER spelling (see `_declared_closing_command`): the classic
    `verification_command:` or the canon `close_check:`. Only the first was ever
    executed before 2026-09-05, which is what let a `close_check` naming a test
    file that does not exist close a ficha with the gate printing rc=0.

    Returns the ``(disposition, detail)`` pair for the caller to act on, and --
    on COULD_NOT_RUN only -- appends the instrument-down row to the sink, since
    that outcome ends the audit of this task either way.
    """
    check = _declared_closing_command(content)
    raw_cmd = check.cmd
    expect = check.expect
    task_rel = str(task_path.relative_to(root))
    cited = _cited_files(root, raw_cmd, content)

    # The cache's `expect` slot holds the task's success CRITERION, not only the
    # classic substring marker. A canon ficha puts its vocabulary word there
    # (`close_check:exit_zero`), so two fichas naming the same command under
    # DIFFERENT criteria can never answer for each other -- `empty_stdout` is
    # strictly stricter than `exit_zero` -- and an entry written before this
    # vocabulary existed (slot holds a bare marker or None) can never answer for
    # a `close_check` at all, since it never observed that criterion. Encoded
    # here rather than as a sixth parameter: both cache functions are called
    # positionally from tests outside this change's ownership, and a sixth
    # argument trips PLR0913 whether it is positional or keyword-only (measured).
    cache_expect = expect if check.expect_mode is None else f"close_check:{check.expect_mode}"
    # Reject an unreadable criterion before any cache-context git probes. A
    # verdict cannot be reused when this verifier cannot interpret its contract.
    shortcut = None
    # The serial lane re-asks a ficha the parallel pass already looked up: the answer is the same
    # (nothing is written until the run ends) and asking twice would count it twice.
    if not _SERIAL_RETRY.get() and (
            check.expect_mode is None or check.expect_mode in CLOSE_CHECK_EXPECT_VOCABULARY):
        shortcut = _persistent_verify_shortcut(root, task_rel, raw_cmd, cache_expect, cited)
    if shortcut is not None:
        return shortcut

    budget = _DECLARED_TIMEOUT.set(check.timeout)
    try:
        disposition, cmd_detail = _classify_task_verification(
            root, raw_cmd, expect, command_cache, expect_mode=check.expect_mode
        )
    finally:
        _DECLARED_TIMEOUT.reset(budget)
    if disposition == VERIFY_OK:
        _record_persistent_verify_pass(root, task_rel, raw_cmd, cache_expect, cited)
    if disposition == VERIFY_NOT_APPLICABLE and cmd_detail is not None and _declare_verdict(
        could_not_run, task_path,
        NOT_APPLICABLE_RECURSION if _is_self_referential(raw_cmd) else NOT_APPLICABLE_OUTSIDE_ALLOWLIST,
        cmd_detail,
    ):
        return disposition, cmd_detail
    if disposition in (VERIFY_COULD_NOT_RUN, VERIFY_NOT_APPLICABLE) and could_not_run is not None and cmd_detail is not None:
        could_not_run.append((
            task_path,
            f"Task is marked as {_task_status_label(content) or 'done'}, but its verification "
            f"COULD_NOT_RUN here (instrument-down, NOT the finding reproducing):\n  - {cmd_detail}",
            (cmd_detail,),
        ))
    return disposition, cmd_detail


def _apply_declared_command_verdict(
    disposition: str,
    cmd_detail: str | None,
    still_reproducing: list[str],
) -> None:
    """Apply independent command evidence while leaving unavailable findings reportable."""
    if disposition == VERIFY_COULD_NOT_RUN:
        return
    if disposition == VERIFY_REPRODUCES and cmd_detail is not None:
        still_reproducing.append(cmd_detail)


def _check_task_fraud(
    root: Path,
    task_path: Path,
    auto_revert: bool,
    command_cache: dict[str, tuple[str, str | None]] | None = None,
    could_not_run: list[tuple[Path, str, tuple[str, ...]]] | None = None,
) -> tuple[Path, str] | None:
    """Return a ``(path, detail)`` FRAUD row, or None.

    A finding classified COULD_NOT_RUN is not itself evidence of fraud: it is
    appended to the ``could_not_run`` sink (when provided). Independently
    confirmed reproducing findings still convict the task, even if the declared
    command or another finding's instrument is unavailable.
    """
    try:
        content = task_path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.debug("Could not read task file %s: %s", task_path, exc)
        return None

    # A non-debt historical artifact (a genuine HANDOFF-*) carries no
    # reproducible finding, so the fraud audit must be SYMMETRIC with the
    # contract validator, which already exempts it via _is_exempt_done_task.
    # Otherwise a dated handoff that happens to declare a whole-suite
    # verification_command false-flags as fraud on any unrelated red test. The
    # exemption reuses the SAME narrow rule (HANDOFF- name, id == stem, no
    # status:), so a governed debt task renamed to HANDOFF-*.md -- which keeps a
    # status field -- stays fully audited; the rename escape remains closed.
    if _is_exempt_done_task(task_path, content):
        return None

    is_in_done = task_path.parent.name == "done"
    status_val = _task_status_label(content)

    # One canon for "is this task closed?", shared with finding_backlog. The old
    # ad-hoc tuple counted `resolved` as closed here while
    # finding_backlog.normalize_backlog_status maps `resolved` -> open, so one
    # file was simultaneously "closed" to the fraud check and "open/blocking" to
    # the backlog gate. `resolved` is NOT in the canonical done synonym set
    # (done|closed|cerrado); it normalizes to open, and both organs now agree a
    # `resolved` task is outstanding, not terminal. A task physically in
    # tasks/done/ is still treated as closed regardless of label.
    is_marked_closed = (
        finding_backlog.normalize_backlog_status(status_val)
        == finding_backlog.CANONICAL_DONE_STATUS
        or is_in_done
    )
    if not is_marked_closed:
        return None

    findings = extract_findings_from_task(content)
    dispositions = [(f, classify_finding(root, f)) for f in findings]
    still_reproducing = [f for f, d in dispositions if d == VERIFY_REPRODUCES]
    # Findings NO registered mechanism can read. They are not evidence of
    # anything yet -- neither that the vice is gone nor that it is still there.
    unreadable = [f for f, d in dispositions if d == VERIFY_COULD_NOT_RUN]

    # The escalation ladder for those. The declared closing command is a
    # MANDATORY, non-empty contract field (validate_task_contract refuses a task
    # carrying neither spelling) that is whitelisted, no-op-filtered and
    # shell-operator-free: it is already the repo's declared proof that a task's
    # finding is discharged. The audit simply was not consulting it whenever ANY
    # finding was registered, so the mandatory proof sat unread while an
    # unreadable finding convicted the task. It is consulted now when the task
    # has no findings at all (unchanged) or when at least one finding is
    # unreadable.
    #
    # Reading it through `_declared_closing_command` is what makes the canon's
    # `close_check:` execute at all. A canon ficha carries no findings block and
    # no `verification_command:`, so before 2026-09-05 BOTH gates here were shut:
    # `findings` was empty and `raw_cmd` was None, and the function returned None
    # -- no fraud, no could_not_run, nothing run. That is the whole of the
    # defect: 17 of own_chats' 19 closed fichas were never executed by the hook
    # the satellites call "closed debt has executable evidence".
    raw_cmd = _declared_closing_command(content).cmd
    disposition = None
    if raw_cmd and (not findings or unreadable):
        disposition, cmd_detail = _judge_declared_command(
            root,
            task_path,
            content,
            command_cache,
            could_not_run,
        )
        _apply_declared_command_verdict(disposition, cmd_detail, still_reproducing)

    # No organ can re-read the unreadable findings. With the ficha's own close_check
    # PASSING they are prose about a closed ficha -- declared on their own line, with
    # the id, not COULD_NOT_RUN (voto de Luis, 2026-10-06, A). Otherwise nothing proved
    # them: report that hole independently, never silently pass it or treat it as the
    # evidence for an unrelated fraud.
    if unreadable and could_not_run is not None:
        listed = "\n".join(f"  - {_unreadable_finding_detail(f)}" for f in unreadable)
        if not (disposition == VERIFY_OK and _declare_verdict(
                could_not_run, task_path, VERDICT_PROSE_NOT_RECHECKABLE,
                f"close_check passed; {len(unreadable)} finding(s) no organ can re-read:\n{listed}")):
            could_not_run.append((
                task_path,
                f"Task is marked as {status_val or 'done'}, but {len(unreadable)} finding(s) "
                f"COULD_NOT_RUN here (no instrument can read them, NOT the finding reproducing):\n{listed}",
                tuple(unreadable),
            ))

    if still_reproducing:
        detail = f"Task is marked as {status_val or 'done'}, but {len(still_reproducing)} finding(s) still reproduce:\n" + "\n".join(f"  - {f}" for f in still_reproducing)
        if auto_revert:
            _revert_fraud_task(root, task_path, content)
            detail += "\n-> Task was AUTOMATICALLY REVERTED to status: open and moved to tasks/backlog/"
        return task_path, detail

    return None


def _check_task_fraud_worker(
    root: Path, task_path: Path, command_cache: dict[str, tuple[str, str | None]],
) -> tuple[tuple[Path, str] | None, list[tuple[Path, str, tuple[str, ...]]]]:
    """Thread-pool-safe wrapper around `_check_task_fraud`, for `audit_closed_tasks`'s
    parallel classification pass.

    Two things this changes on purpose, neither touching `_check_task_fraud`'s own
    classification logic:

    1. Always calls it with `auto_revert=False`. Reverting a confirmed-fraud task runs
       `git rm --cached` against this repo's ONE `.git` index (see `_revert_fraud_task`);
       two tasks legitimately convicted at the same time, reverted from two threads, can
       collide on `.git/index.lock` -- and that subprocess's result is never checked
       (`check=False`), so a lost race would fail SILENTLY, leaving exactly the
       tracked-but-missing dangling state `_revert_fraud_task` exists to prevent
       (atlas-8b, 2026-08-29). Fixed by construction, not by a lock: classification stays
       parallel and pure; `audit_closed_tasks` does every revert itself, serially, in the
       main thread, after the pool has finished.
    2. Gives this call its OWN private `could_not_run` list instead of the one shared
       across the whole audit. `list.append` cannot corrupt under the GIL, but a list
       shared across threads fills in whatever order threads happen to FINISH in, not
       the order tasks were submitted -- breaking this repo's own order-determinism
       convention (two runs over an identical tree must emit findings in the same order,
       "Axiom 9" elsewhere in this codebase). `audit_closed_tasks` extends the real
       `could_not_run` list with each call's private one, in `executor.map`'s
       submission-order result sequence, so the merged order matches today's sequential
       output exactly.
    """
    local_could_not_run = ClosedAuditRows()
    fraud = _check_task_fraud(
        root, task_path, auto_revert=False, command_cache=command_cache,
        could_not_run=local_could_not_run,
    )
    return fraud, local_could_not_run


# DGX-637 (Atlas, 2026-10-06 18:05: 121 of 133 could_not_run were "instrument busy"). A harness
# close_check holds a lock for minutes and every pytest on the same tree refuses while it runs, so
# in the parallel pass the verifier's own fichas refuse each other. The refused ones are re-asked
# ONCE, one at a time, after the pool drains; the kit does not try to know which checks take a lock.
_SERIAL_RETRY: contextvars.ContextVar[bool] = contextvars.ContextVar("bv_serial_retry", default=False)


def _is_busy(result: tuple) -> bool:
    _fraud, rows = result
    return any(_BUSY_VERDICT in finding for _path, _detail, findings in rows for finding in findings)


def _retry_busy_serially(root: Path, task_files: list[Path], results: list, rows: ClosedAuditRows) -> None:
    """Replace each busy result in `results` with one serial re-run, under the ficha's own timeout
    (`_judge_declared_command` sets it). A PASS here is sealed and cached like any other."""
    lane_cache = CommandVerdictCache()
    token = _SERIAL_RETRY.set(True)
    try:
        for index in [i for i, result in enumerate(results) if _is_busy(result)]:
            results[index] = _check_task_fraud_worker(root, task_files[index], lane_cache)
            rows.busy_retried.append(task_files[index])
            if _is_busy(results[index]):
                rows.busy_unresolved.append(task_files[index])
    finally:
        _SERIAL_RETRY.reset(token)


def audit_closed_tasks(
    root: Path, auto_revert: bool = False, *, full: bool = False
) -> tuple[list[tuple[Path, str]], list[tuple[Path, str, tuple[str, ...]]]]:
    """Audit every closed task and split the outcome into two honest buckets.

    Returns ``(frauds, could_not_run)``. ``frauds`` are tasks whose finding
    genuinely still reproduces (exit-nonzero or a declared `expect:` marker
    missing); ``could_not_run`` are tasks whose verification could not execute in
    this environment. Keeping the second bucket separate is the whole point of
    the harvest: instrument failure is reported, never counted as fraud.

    Classification runs across up to `xdist_workers()` threads (DEBT-PUSH-LOOP-02 follow-up,
    2026-09-21): profiled on this repo, 91% of this function's wall time is the parent
    BLOCKED waiting on a task's declared-command subprocess (`select.poll`, not parent CPU) --
    the textbook case for real concurrent progress despite the GIL, since a blocking
    `subprocess.run` releases it. Reverting a confirmed fraud stays serial, in this function,
    after the pool closes -- see `_check_task_fraud_worker`'s docstring for why. Results are
    collected via `executor.map`, which yields in SUBMISSION order (the sorted task list),
    never completion order, so the report's order is unchanged from the old sequential loop.
    """
    root_key = root.resolve()
    if str(root_key) in _active_roots(os.environ):
        if os.environ.get(REENTRY_FLAG_ENV):
            with contextlib.suppress(OSError):
                Path(os.environ[REENTRY_FLAG_ENV]).write_text(str(root_key), encoding="utf-8")
        raise AuditReentered(
            f"[backlog-verifier] COULD_NOT_RUN: {root_key} is already being audited by a "
            f"backlog_verifier above this one ({ACTIVE_ROOTS_ENV}): a closed ficha's close_check "
            "re-entered the audit of its own repo, so no closed ficha was re-executed here "
            "(indirect recursion stopped; not the finding reproducing)"
        )
    fraud_findings: list[tuple[Path, str]] = []
    could_not_run = ClosedAuditRows()
    command_cache: dict[str, tuple[str, str | None]] = CommandVerdictCache()
    _ZERO_DEBT_SCAN_CACHE.pop(root, None)
    _PERSISTENT_CACHE_READ_SNAPSHOT.pop(root, None)
    task_files = _governed_task_candidates(root)
    # `full` (`--full`): re-execute every declared close_check; still records fresh seals.
    with _INCREMENTAL_LOCK:
        _INCREMENTAL.pop(root_key, None)
        _UNSEALABLE_REASONS.pop(root_key, None)
        _DIGEST_MEMO.clear()
        (_FULL_RUN.add if full else _FULL_RUN.discard)(root_key)
        _PENDING_ENTRIES[root_key] = {}
    with _REPO_SNAPSHOT_LOCK:
        _REPO_SNAPSHOT.pop(root_key, None)

    # El tope por proceso (xdist_workers) no basta: cada hilo lanza un pytest
    # HIJO que importa el backend e inicializa CUDA, y el pool de memoria
    # unificada es uno para toda la maquina. N coders correctamente topados a
    # 6 son 6N hijos -- tres coders llegan a 18, por encima de los 16 que
    # cruzaron el precipicio el 2026-09-22. El contador global reconcilia las
    # dos cosas: se pide el tope por proceso y se recibe lo que quede libre.
    try:
        with unified_memory_slots(xdist_workers()) as _slots:
            with ThreadPoolExecutor(max_workers=_slots) as pool:
                results = list(pool.map(
                    lambda task_file: _check_task_fraud_worker(root, task_file, command_cache),
                    task_files,
                ))
            _retry_busy_serially(root, task_files, results, could_not_run)
            for fraud, local_could_not_run in results:
                could_not_run.extend(local_could_not_run)
                could_not_run.not_applicable.extend(getattr(local_could_not_run, "not_applicable", ()))
                if fraud is None:
                    continue
                task_path, detail = fraud
                if auto_revert:
                    try:
                        content = task_path.read_text(encoding="utf-8")
                    except OSError as exc:
                        logger.debug("Could not re-read %s for revert: %s", task_path, exc)
                    else:
                        _revert_fraud_task(root, task_path, content)
                        detail += "\n-> Task was AUTOMATICALLY REVERTED to status: open and moved to tasks/backlog/"
                fraud_findings.append((task_path, detail))
    finally:
        with _RUN_SEALS_LOCK:
            for key in [k for k in _RUN_SEALS if k[0] == root_key]:
                del _RUN_SEALS[key]
        with _INCREMENTAL_LOCK:
            pending = _PENDING_ENTRIES.pop(root_key, {})
        _drop_repo_bound_if_the_repo_moved(root, pending)
        if pending:
            _write_persistent_verify_entries(root, pending)
    return fraud_findings, could_not_run


def _drop_repo_bound_if_the_repo_moved(root: Path, pending: dict[str, dict]) -> None:
    """A repo-bound PASS sealed on the snapshot this run took is void if the repo moved while the
    run executed: what its non-Python child read may be neither snapshot."""
    bound = [rel for rel, entry in pending.items() if entry.get("snapshot") is not None]
    if bound and _repo_snapshot(root) != _run_snapshot(root):
        for rel in bound:
            del pending[rel]
            _count(root, "unsealable", "repo-bound, and the repo moved while the run executed: snapshot")


def run_anti_fraud_audit(root: Path, auto_revert: bool = False) -> list[tuple[Path, str]]:
    """Scan all done/closed tasks and return only the genuine FRAUD rows.

    Back-compat entry point: callers that want the could-not-run bucket too call
    :func:`audit_closed_tasks` directly.
    """
    frauds, _could_not_run = audit_closed_tasks(root, auto_revert=auto_revert)
    return frauds


verify_closed_tasks = run_anti_fraud_audit


_UNDATABLE_PRINT_LIMIT = 20


def _print_cohorts(audit: ContractAudit) -> None:
    """Print the cohort counts, their zeros, and any date-source caveat.

    `legacy` and `undatable` are tasks whose CONTRACT SHAPE this run did not
    evaluate; they do not block (that is the point of the cut-off), and printing
    them is what keeps "0 breaches" from reading as "0 problems" over a corpus
    nobody looked at.
    """
    cohorts = audit.cohorts
    print(
        f"[backlog-verifier] task cohorts ({audit.cutoff_note}) -> "
        f"governed: {cohorts[COHORT_GOVERNED]} · "
        f"legacy pre-cut-off, contract shape NOT evaluated: {cohorts[COHORT_LEGACY]} · "
        f"undatable by git, contract shape NOT evaluated: {cohorts[COHORT_UNDATABLE]} · "
        f"declared `done_unverified`, contract shape NOT evaluated: {cohorts.get(COHORT_UNVERIFIED, 0)}"
    )
    if audit.date_source_warning:
        print(f"\033[33m[backlog-verifier] {audit.date_source_warning}\033[0m")
    # Counted and named, never blocking. Zero and ninety-seven are different
    # facts, and blocking on the second would repeat the regression that
    # narrowing stage 1 fixed.
    print(f"[backlog-verifier] done-tasks whose status is outside this repo's "
          f"closing vocabulary (reported, NOT blocking): {len(audit.unrecognised_status)}")
    for row in audit.unrecognised_status[:_UNDATABLE_PRINT_LIMIT]:
        print(f"    ? {row}")
    for path in audit.undatable[:_UNDATABLE_PRINT_LIMIT]:
        print(f"    ~ {path}")
    hidden = len(audit.undatable) - _UNDATABLE_PRINT_LIMIT
    if hidden > 0:
        print(f"    ~ ... and {hidden} more undatable task file(s)")


# ---------------------------------------------------------------------------
# Declared could_not_run: a human confirms a finding is real and NO organ can
# re-check it, ever, in this ecosystem -- RePic, 2026-09-03 (M-03,
# `repic-rs/src/duplicate_detector.rs`: no labelled corpus for recall
# measurement is a process judgment, not a lint or a test, in ANY language).
#
# This is NOT the same axis as `finding_backlog.load_baseline`: that one
# declares an open TASK safe to not block on. This declares one FINDING TEXT
# unreadable by construction, independent of the task's own openness. A task
# can be correctly reopened (no amnesty) and STILL cite a finding no organ can
# verify -- the two decisions are orthogonal and conflating them is how RePic's
# baseline entry for M-03 left `could_not_run` unchanged: it fixed the wrong
# axis.
#
# Same suspension contract as the backlog baseline: owner + expiry, or it is
# not a baseline. Keyed by a hash of the finding TEXT, not a task id -- if the
# finding's wording changes even slightly, the old entry stops matching and
# the finding blocks again until a human re-reads and re-declares it.
COULD_NOT_RUN_BASELINE_RELPATH = Path(".simplecode") / "could_not_run_baseline.json"


def _finding_key(finding: str) -> str:
    return hashlib.sha256(finding.strip().encode("utf-8")).hexdigest()[:16]


# The budget in "timed out after 336s" is DERIVED from the size of the repo's test corpus
# (`_task_verification_timeout`), not wording a human wrote. Declutter measured it moving 336, 340,
# 343, 345 and 345.8s in two days, and since the key hashes the whole text, every move demanded a new
# declaration for the same finding (2026-09-25). Only that number is normalised; any other change of
# wording still stops matching, which is the reason the key hashes text at all.
_TIMEOUT_SECONDS = re.compile(r"(timed out after )\d+(s)")


def _stable_finding_key(finding: str) -> str:
    return _finding_key(_TIMEOUT_SECONDS.sub(r"\1<N>\2", finding))


def _declared_reason(declared_entries: dict, finding: str) -> str | None:
    """The declared reason for `finding`, under its exact key (every entry written before the
    normalisation) or its seconds-independent key (what a new declaration should use)."""
    exact = declared_entries.get(_finding_key(finding))
    return exact if exact is not None else declared_entries.get(_stable_finding_key(finding))


def load_could_not_run_baseline(root: Path) -> tuple[dict, str]:
    """The declared could_not_run entries and a note, or ({}, why-not).

    Absent, malformed, or expired all mean NO declared entries: everything in
    `could_not_run` blocks. Failing toward blocking is the only direction that
    keeps an expiry honest.
    """
    path = root / COULD_NOT_RUN_BASELINE_RELPATH
    if not path.is_file():
        return {}, f"no {COULD_NOT_RUN_BASELINE_RELPATH.as_posix()} declared"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        expires = date.fromisoformat(str(data["expires"]))
        owner = str(data["owner"]).strip()
        entries = {str(k): str(v) for k, v in dict(data["entries"]).items()}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return {}, (f"COULD_NOT_RUN: {COULD_NOT_RUN_BASELINE_RELPATH.as_posix()} is unreadable or "
                    f"incomplete ({exc}); it needs `expires`, `owner` and `entries`. "
                    f"No declared entries apply.")
    if not owner or not entries:
        return {}, f"{COULD_NOT_RUN_BASELINE_RELPATH.as_posix()} declares no owner or no entries; none apply"
    if date.today() > expires:
        return {}, (f"COULD_NOT_RUN BASELINE EXPIRED on {expires.isoformat()} (owner: {owner}); "
                    f"every entry below blocks again")
    left = (expires - date.today()).days
    return (
        {"owner": owner, "entries": entries},
        f"{len(entries)} declared could_not_run entry/entries, owner {owner}, "
        f"expires {expires.isoformat()} ({left} day(s) left)",
    )


def check_close_check(cmd: str, expect: str = CLOSE_CHECK_EXPECT_EXIT_ZERO,
                      root: Path | None = None, timeout: str | None = None) -> tuple[bool, list[str]]:
    """(¿pasaria el gate?, lineas de informe) para un `close_check` ANTES de escribirlo.

    Propuesta de `own_chats` en la encuesta de flota (2026-09-05), y cierra la clase de
    raiz: hoy los cuatro limites del `close_check` --presupuesto de tiempo, vocabulario
    de `expect`, prohibicion de `-c` y de operadores de shell, `git` fuera de la
    whitelist-- se descubren cada uno con un ciclo de cierre FALLIDO. Cada instancia de
    la tabla de esa ficha costo al menos uno.

    LLAMA A LAS MISMAS FUNCIONES QUE EL GATE, y eso es el punto entero: `_validate_
    verification_cmd` es la que corre en el push, `CLOSE_CHECK_EXPECT_VOCABULARY` es el
    vocabulario derivado de `ledger_schema.EXPECT`, y `_task_verification_timeout` es la
    que calcula el bound real. Una reimplementacion paralela que aconsejara distinto del
    gate seria peor que no tener el subcomando: convertiria un ciclo de cierre fallido
    en un ciclo de cierre fallido DESPUES de que una herramienta dijera que estaba bien.

    Informa SIEMPRE el presupuesto, pase o no: es el limite que nadie descubre leyendo,
    porque no produce un mensaje de rechazo -- produce un `COULD_NOT_RUN` mucho despues.
    """
    lineas: list[str] = []
    ok, msg = _validate_verification_cmd(cmd, as_task_verification=True, root=root)
    if ok:
        lineas.append(f"OK   cmd: {cmd!r} pasa la whitelist del gate")
    else:
        lineas.append(f"FAIL cmd: {msg}")
    if expect in CLOSE_CHECK_EXPECT_VOCABULARY:
        lineas.append(f"OK   expect: {expect!r}")
    else:
        ok = False
        lineas.append(
            f"FAIL expect: {expect!r} no esta en el vocabulario que este gate sabe "
            f"comprobar ({', '.join(CLOSE_CHECK_EXPECT_VOCABULARY)}) -- una palabra que "
            f"el esquema admite y el verificador no sabe leer produce una ficha valida "
            f"e INVERIFICABLE, que llega al push como COULD_NOT_RUN"
        )
    # `--timeout` es el `close_check.timeout` que la ficha declararia: se valida con la
    # MISMA funcion que el esquema, y si vale, ES el presupuesto que el gate usara.
    if timeout is not None:
        try:
            segundos: object = float(timeout)
        except ValueError:
            segundos = timeout
        problema = ledger_schema.close_check_timeout_problem(segundos)
        if problema:
            ok = False
            lineas.append(f"FAIL timeout: {problema}")
        else:
            lineas.append(f"INFO presupuesto: {timeout}s declarado en close_check.timeout -- "
                          f"reemplaza al derivado del corpus; pasado ese tiempo el cierre se lee "
                          f"como COULD_NOT_RUN")
            return ok, lineas
    # El presupuesto solo se puede calcular sobre un comando que al menos se puede
    # partir en tokens; sobre uno malformado seria inventarlo.
    try:
        presupuesto = _task_verification_timeout(root or Path("."), cmd)
    except ValueError as exc:
        lineas.append(f"?    presupuesto: no calculable ({exc})")
    else:
        lineas.append(
            f"INFO presupuesto: {presupuesto:.0f}s en este repo -- pasado ese tiempo el "
            f"cierre no se lee como fallo sino como COULD_NOT_RUN"
        )
    return ok, lineas


def check_close_check_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="simplecode check-close-check",
        description="Valida un close_check ANTES de escribir la ficha, con el mismo "
                    "validador que corre en el push",
    )
    parser.add_argument("cmd", help="El comando del close_check, entre comillas")
    parser.add_argument("--expect", default=CLOSE_CHECK_EXPECT_EXIT_ZERO,
                        help=f"El criterio de exito (por defecto {CLOSE_CHECK_EXPECT_EXIT_ZERO})")
    parser.add_argument("--root", type=Path, default=Path("."),
                        help="Raiz del repo: decide el presupuesto y las build tools declaradas")
    parser.add_argument("--timeout", default=None,
                        help="El close_check.timeout que declararia la ficha, en segundos "
                             f"(> 0 y <= {ledger_schema.CLOSE_CHECK_TIMEOUT_MAX_SECONDS})")
    args = parser.parse_args(argv)
    ok, lineas = check_close_check(args.cmd, args.expect, args.root, args.timeout)
    for linea in lineas:
        print(f"[check-close-check] {linea}")
    return 0 if ok else 1


def _report_breaches_and_frauds(
    contract_breaches: list[tuple[Path, str]], frauds: list[tuple[Path, str]]
) -> None:
    """Print the two BLOCKING classes. Pure output: computes no verdict."""
    if contract_breaches:
        print(f"\033[31m[backlog-verifier] CONTRACT BREACH: Found {len(contract_breaches)} tasks violating machine-executable standards:\033[0m")
        for p, reason in contract_breaches:
            print(f"  🔴 {p.name}: {reason}")

    if frauds:
        print(f"\033[31m[backlog-verifier] FRAUD DETECTED: Found {len(frauds)} closed tasks whose findings still reproduce:\033[0m")
        for p, detail in frauds:
            print(f"  🔴 {p.name}:\n{detail}")


def _report_could_not_run(
    could_not_run: list[tuple[Path, str, tuple[str, ...]]],
    declared_entries: dict[str, str],
) -> list[tuple[Path, str]]:
    """Print every COULD_NOT_RUN task and RETURN the UNDECLARED ones.

    The only block in this report that computes rather than prints, which is
    why it is its own function: `could_not_run` is not a finding and not a
    pass -- it is a third verdict, and splitting it into declared (printed,
    not blocking) and undeclared (printed AND blocking) is the decision the
    exit code then rests on.

    The `findings and` in `findings and all(...)` is an UNREACHABLE fail-closed
    guard today, and is documented as such rather than as verified. Measured
    2026-09-15: `could_not_run` has exactly two producers, and both build a
    non-empty findings tuple by construction -- `(cmd_detail,)` guarded by
    `cmd_detail is not None`, and `tuple(unreadable)` guarded by `if
    unreadable`. So no input this module can produce reaches the empty case,
    and a mutant that deletes the guard survives the whole 23-file suite. That
    survival is a property of the SUBJECT (no producer can reach it), not a
    weak test: the mutant is NOT equivalent -- fed an empty-findings entry
    directly, the guarded code blocks and the unguarded code prints
    "DECLARED, not blocking -- " with an empty reason and waves it through.
    The guard stays because that is the fail-toward-blocking direction and it
    costs one `and`; `test_empty_findings_could_not_run_entry_never_counts_as_declared`
    pins it directly so a future third producer cannot break it in silence.
    """
    undeclared: list[tuple[Path, str]] = []
    if not could_not_run:
        return undeclared
    print(f"\033[33m[backlog-verifier] COULD_NOT_RUN: {len(could_not_run)} closed task(s) whose verification could not execute here (instrument-down, NOT fraud):\033[0m")
    for p, detail, findings in could_not_run:
        # Keyed on each RAW finding text, never on `detail`'s first line:
        # that line is a shared header ("Task is marked as done, but N
        # finding(s) COULD_NOT_RUN here...") that varies only by count, so
        # hashing it would let ONE declared entry cover every finding of
        # every task that happens to share a count -- measured live by
        # RePic, 2026-09-04: a baseline entry for one finding kept
        # printing OK after the finding text was replaced outright with an
        # unrelated one. Every finding in this task must be declared for
        # the task to count as covered; one undeclared finding blocks the
        # whole task, same fail-toward-blocking direction as the baseline
        # loader itself.
        reasons = [_declared_reason(declared_entries, f) for f in findings]
        if findings and all(r is not None for r in reasons):
            # `if r is not None` removes nothing here -- the branch condition
            # already proved every reason is a string. It is written so the type
            # is CHECKABLE rather than asserted: while `declared_entries` was an
            # untyped `Any` inside `main`, pyright could not see that
            # `dict.fromkeys(reasons)` has key type `str | None`, and annotating
            # this function is what made the latent hole visible (0 -> 3 pyright
            # errors on extraction, all three mine).
            joined = "; ".join(dict.fromkeys(r for r in reasons if r is not None))
            print(f"  🟡 {p.name} (DECLARED, not blocking -- {joined}):\n{detail}")
        else:
            print(f"  🟡 {p.name}:\n{detail}")
            undeclared.append((p, detail))
    return undeclared


def _report_declared_verdicts(rows: list[tuple[Path, str, str]]) -> str:
    """Print the closed fichas this run did NOT re-check and why, and return their counts
    for the summary (voto de Luis, 2026-10-06, A and C/D).

    Both lines print on every run, zeros and `none` included: a verdict that does not
    block is exactly the one that must never become a silent zero (closing condition 1
    of DEBT-BACKLOG-VERIFIER-COULD-NOT-RUN-ROOT-CAUSES-20261006)."""
    def ids(kind: str) -> list[str]:
        return [p.stem for p, k, _ in rows if k == kind]

    prose = ids(VERDICT_PROSE_NOT_RECHECKABLE)
    recursion = ids(NOT_APPLICABLE_RECURSION)
    allowlist = ids(NOT_APPLICABLE_OUTSIDE_ALLOWLIST)
    print(f"[backlog-verifier] {len(prose)} closed fichas with {VERDICT_PROSE_NOT_RECHECKABLE} "
          f"({', '.join(prose) or 'none'})")
    print(f"[backlog-verifier] NOT_APPLICABLE: {len(recursion) + len(allowlist)} closed fichas "
          f"({NOT_APPLICABLE_RECURSION}: {', '.join(recursion) or 'none'}; "
          f"{NOT_APPLICABLE_OUTSIDE_ALLOWLIST}: {', '.join(allowlist) or 'none'})")
    return (f"not_applicable: {len(recursion) + len(allowlist)} · "
            f"prose_not_recheckable: {len(prose)}")


def _report_busy_retries(could_not_run: list) -> str:
    """Print the serial lane's outcome (DGX-637) and return its counts for the summary. Prints on
    every run, zeros included: a retry that resolved nothing must say so."""
    retried = getattr(could_not_run, "busy_retried", [])
    unresolved = getattr(could_not_run, "busy_unresolved", [])
    resolved = len(retried) - len(unresolved)
    print(f"[backlog-verifier] instrument busy: {len(retried)} closed ficha(s) retried one at a time "
          f"after the parallel pass: {resolved} resolved, {len(unresolved)} still busy "
          f"(retried, unresolved: {', '.join(p.stem for p in unresolved) or 'none'})")
    return f"busy_retried: {len(retried)} ({resolved} resolved, {len(unresolved)} unresolved)"


def _report_verdict(*, summary: str, blocking: bool, unverified: int, gate: bool,
                    not_rechecked: int = 0) -> int:
    """Print the counts and return the EXIT CODE. The only place either happens.

    Reporting-politics law: the counts always print, zeros included. A report
    with UNDECLARED could_not_run > 0 is NOT clean, however many rows pass --
    so the gate blocks on it just as it blocks on frauds and contract
    breaches. A DECLARED entry still prints (never hidden) but does not
    block: a human already read that exact finding text and confirmed no
    organ in this ecosystem can re-check it -- the same shape as the backlog
    baseline, applied to the finding-verification axis instead of the
    task-openness axis.

    Two exit codes, and `unverified` is in NEITHER of them. It rides in the
    same summary and changes the WORDING only: those tasks are closed on
    purpose without executable evidence, so they are not violations -- but
    "all tasks verified" over a cohort this run never evaluated is the
    sentence a report must not print. COMPLETE describes the report, never
    the subject. A refactor that let `unverified` reach the return value
    would turn 22 deliberate declarations into 22 blocking defects.

    Takes the already-formatted `summary` rather than the five collections it
    counts, on purpose: writing the counts twice is how a report starts
    disagreeing with itself. Caught while writing this split -- an earlier
    draft rebuilt the string here and fed `undeclared_could_not_run` to BOTH
    the total and the parenthesised subset. On this repo today, where both are
    0, the printed line was byte-identical, so no gate and no test would have
    said a word until the day a real COULD_NOT_RUN appeared and the total
    under-reported it.
    """
    if not blocking:
        # Same rule for the declared verdicts (A, C/D of 2026-10-06): measured on this repo
        # that day, 73 fichas moved to "prose findings not re-checkable" and this line read
        # "all tasks verified" over them.
        if not_rechecked:
            print(f"[backlog-verifier] OK, WITH {not_rechecked} CLOSED FICHA(S) NOT RE-CHECKED "
                  f"(declared above) AND {unverified} TASK(S) NEVER VERIFIED: no violations "
                  f"among the ones this run could judge (counts -> {summary}).")
        elif unverified:
            print(f"[backlog-verifier] OK, WITH {unverified} TASK(S) NEVER VERIFIED: "
                  f"no violations among the ones this run could judge (counts -> {summary}).")
        else:
            print(f"[backlog-verifier] OK: all tasks verified (counts -> {summary}).")
        return 0

    print(f"[backlog-verifier] NOT CLEAN (counts -> {summary}).")
    return 1 if gate else 0


_FINDING_TELEMETRY_RE = re.compile(
    r"command:\s*|comando:\s*|raw_log:\s*|##\s*telemetr[íi]a|```bash", re.I
)


def _finding_breaches(fpath: Path, backlog_text: str) -> list[tuple[Path, str]]:
    """The two contract breaches of ONE finding file: not cited, and no telemetry.

    `backlog_text` is the citation surface: BACKLOG.md's content (when the file exists) PLUS
    every governed tasks/{backlog,done}/*.md file's content, concatenated (see
    `_citation_surface` in `audit_findings_contract`). A repo that has frozen or deleted
    BACKLOG.md that still exists after migration must still be
    able to satisfy this contract by citing a finding from a real tasks/ ficha instead --
    before this fix, a frozen-but-not-deleted BACKLOG.md's STATIC content could never mention
    a finding written after the freeze, so every governed finding fell into UNCITED_FINDING
    forever, with no way to clear it short of un-freezing. `backlog_text == ""` (BACKLOG.md
    missing entirely, e.g. after full deletion) is the harder failure this also fixes: the OLD
    `if backlog_text and ...` guard treated an empty string as "nothing to check against" and
    skipped the breach check silently -- a repo with no BACKLOG.md at all got a free pass on
    citation instead of being held to the same contract via tasks/.
    """
    breaches: list[tuple[Path, str]] = []
    if fpath.name not in backlog_text:
        breaches.append(
            (fpath, "UNCITED_FINDING -- finding file is not linked or cited in BACKLOG.md "
                    "or in a tasks/{backlog,done}/*.md ficha")
        )
    content = fpath.read_text(encoding="utf-8", errors="replace")
    if not _FINDING_TELEMETRY_RE.search(content):
        breaches.append(
            (fpath, "MISSING_TELEMETRY -- finding file lacks reproducible CLI command/telemetry")
        )
    return breaches


def _citation_surface(root: Path) -> str:
    """Every place a finding could legitimately be cited from, concatenated: BACKLOG.md (when
    it still exists), the evidence and harvest indexes (when present), plus every governed
    tasks/{backlog,done}/*.md ficha's full text.

    A repo that has migrated away from BACKLOG.md
    still needs a real place to cite a finding -- tasks/ is where the canon already says new
    debt goes (task_migration.py), so it is the natural second half of this surface, not a
    bolt-on. Reads whole-file content rather than just filenames on purpose: a finding is
    routinely cited in a ficha's prose ("ver docs/agent_findings/X.md") without necessarily
    being the ficha's own filename, the exact same citation shape `_cited_files` already
    trusts elsewhere in this module.
    """
    parts = []
    for index in (
        root / "BACKLOG.md",
        root / "docs" / "INDEX_WATCH_EVIDENCE.md",
        root / "docs" / "INDEX_COSECHA.md",
    ):
        if index.is_file():
            try:
                parts.append(index.read_text(encoding="utf-8", errors="replace"))
            except OSError as exc:
                logger.debug("Could not read %s for citation surface: %s", index, exc)
    for task_path in _governed_task_candidates(root):
        try:
            parts.append(task_path.read_text(encoding="utf-8", errors="replace"))
        except OSError as exc:
            logger.debug("Could not read %s for citation surface: %s", task_path, exc)
    return "\n".join(parts)


def audit_findings_contract(root: Path) -> tuple[list[tuple[Path, str]], dict[str, int], str]:
    """Audit docs/agent_findings/*.md; returns (breaches, cohorts, cut-off note).

    ABSENT CUT-OFF MEANS EVERY FINDING IS GOVERNED -- the strict reading, and what this audit did
    before a cut-off existed. A repo whose corpus predates the contract declares
    `.simplecode/findings_contract_cutoff.json` in a reviewed commit; findings ADDED to git before
    that date are the `legacy` cohort: counted and reported, contract NOT evaluated. The date is
    git's add-date, never a field the file declares. A finding written and not yet committed is
    governed by construction. Neither breach is relaxed for the governed cohort.
    """
    findings_dir = root / FINDINGS_DIR_RELPATH
    cohorts = {COHORT_GOVERNED: 0, COHORT_LEGACY: 0, COHORT_UNDATABLE: 0}
    if not findings_dir.is_dir():
        return [], cohorts, ""
    cutoff, note = load_contract_cutoff(root, FINDINGS_CUTOFF_CONFIG_RELPATH)
    paths = sorted(findings_dir.glob("*.md"))
    dates, ignored = _resolve_cutoff_dates(
        root, paths, cutoff, FINDINGS_DIR_RELPATH.as_posix() + "/"
    )
    backlog_text = _citation_surface(root)
    breaches: list[tuple[Path, str]] = []
    for fpath in paths:
        cohort = COHORT_GOVERNED
        if cutoff is not None:
            cohort = _task_cohort(fpath.relative_to(root).as_posix(), dates, cutoff, ignored)
        cohorts[cohort] += 1
        if cohort == COHORT_GOVERNED:
            breaches.extend(_finding_breaches(fpath, backlog_text))
    return breaches, cohorts, note


def audit_findings_indexing_and_telemetry(root: Path) -> list[tuple[Path, str]]:
    """Audit docs/agent_findings/*.md for indexing in BACKLOG.md and telemetry blocks."""
    return audit_findings_contract(root)[0]


def _report_findings_cohorts(cohorts: dict[str, int], note: str) -> None:
    """Say how many findings this run did NOT evaluate, on its own line, when a cut-off is declared."""
    if not note or not any(cohorts.values()) or note.endswith("everything is governed"):
        return
    print(
        f"[backlog-verifier] findings contract ({note}): governed {cohorts[COHORT_GOVERNED]} · "
        f"legacy pre-cut-off, contract NOT evaluated: {cohorts[COHORT_LEGACY]} · "
        f"undatable by git, NOT evaluated: {cohorts[COHORT_UNDATABLE]}"
    )


def _effectiveness_detector_counts(
    frauds: list, could_not_run: list, contract_breaches: list, unverified: int,
) -> dict[str, int]:
    """Keep telemetry categories distinct; a blocked row alone is not a fraud."""
    return {
        "closure_reproduces": len(frauds),
        "could_not_run": len(could_not_run),
        "contract_breach": len(contract_breaches),
        "unverified_task": unverified,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    parser.add_argument("--auto-revert", action="store_true", help="Revert fraudulent closed tasks back to tasks/backlog/")
    parser.add_argument("--no-revert", action="store_true", help="Do not revert fraudulent closed tasks back to tasks/backlog/")
    parser.add_argument("--gate", action="store_true", help="Exit 1 if fraudulent tasks or invalid contracts found")
    parser.add_argument("--full", action="store_true",
                        help="Re-execute every declared close_check; reuse no cached PASS")
    args = parser.parse_args(argv)

    root = args.root.resolve()
    auto_revert = args.auto_revert and not args.no_revert
    # `full` is passed only when asked, so callers' stand-ins for audit_closed_tasks keep their shape.
    try:
        frauds, could_not_run = audit_closed_tasks(
            root, auto_revert=auto_revert, **({"full": True} if args.full else {})
        )
    except AuditReentered as exc:
        print(exc)
        return 2  # COULD_NOT_RUN across this kit

    print(f"[backlog-verifier] persistent verify cache: {persistent_verify_cache_summary(root)}")
    print(f"[backlog-verifier] {incremental_summary(root)}")
    contract_audit = audit_task_contracts(root)
    contract_breaches = list(contract_audit.breaches)
    
    finding_breaches, finding_cohorts, finding_note = audit_findings_contract(root)
    _report_findings_cohorts(finding_cohorts, finding_note)
    if finding_breaches:
        for fpath, fb in finding_breaches:
            print(f"[backlog-verifier] 🔴 {fpath.name}: {fb}")
        contract_breaches.extend(finding_breaches)

    _report_breaches_and_frauds(contract_breaches, frauds)

    declared, declared_note = load_could_not_run_baseline(root)
    undeclared_could_not_run = _report_could_not_run(could_not_run, declared.get("entries", {}))
    declared_verdicts = _report_declared_verdicts(getattr(could_not_run, "not_applicable", []))
    busy_counts = _report_busy_retries(could_not_run)

    # Every branch above NAMES a ficha and prints the fields this gate reads
    # from it. Those fields are not the whole contract: a ficha may reconcile
    # in its own body an apparent mismatch between them -- and the reader who
    # stops at this message concludes the mismatch is real.
    #
    # Measured 2026-09-05 in maletin_homeopatia. A ficha declared
    # `--hook-stage pre-commit` while the ledger key said `--hook-stage
    # pre-push`. Both fields were correct and they contradicted each other, so
    # the session reported it to me as a hole in the kit with no procedure,
    # and I told them not to close the ficha on the strength of it. The ficha's
    # own Root Cause section explained the divergence with three reasons --
    # among them that running `--hook-stage pre-push` from THAT ficha
    # re-invokes this gate from inside itself, the 30s recursion the whole
    # family exists to avoid. The finding was false and the ficha closed.
    #
    # This line costs nothing and removes the half of that error the message
    # caused. The other half -- reading the body -- it cannot enforce.
    if contract_breaches or frauds or could_not_run:
        print("[backlog-verifier] the fields above are what THIS gate reads; a "
              "ficha may reconcile them in its own body -- read it before "
              "concluding its declaration is wrong")

    # The declared-baseline line prints even when could_not_run is empty, same
    # reason the backlog baseline always prints its note: silence here is how
    # a stale or missing declaration goes unnoticed until it matters.
    print(f"[backlog-verifier] could_not_run baseline: {declared_note}")
    scan_note = load_declared_whole_repo_scan_commands(root)[1]
    if "not declared" not in scan_note:
        print(f"[backlog-verifier] whole-repo scan commands: {scan_note}")

    # The cohorts print for the same reporting-politics reason `_report_verdict`
    # documents below. `legacy` and `undatable` are tasks whose CONTRACT SHAPE
    # this run did not evaluate; they do not block (that is the whole point of
    # the cut-off), and printing them is what keeps "0 breaches" from reading as
    # "0 problems" over a corpus nobody looked at.
    _print_cohorts(contract_audit)

    unverified = contract_audit.cohorts.get(COHORT_UNVERIFIED, 0)
    # The counts are formatted HERE, where all five collections are in scope, and
    # handed to the verdict as one string -- see `_report_verdict`'s docstring for
    # the drift this prevents. `could_not_run` is the TOTAL; the parenthesised
    # number is the undeclared subset. They are different numbers that happen to
    # agree whenever both are zero.
    summary = (
        f"frauds: {len(frauds)} · could_not_run: {len(could_not_run)} "
        f"({len(undeclared_could_not_run)} undeclared) · "
        f"contract_breaches: {len(contract_breaches)} · "
        f"unverified: {unverified} · {declared_verdicts} · {busy_counts}"
    )
    emit_detectores(
        "[backlog-verifier]",
        _effectiveness_detector_counts(frauds, could_not_run, contract_breaches, unverified),
    )
    emit_hallazgos(
        "[backlog-verifier]",
        len(frauds) + len(could_not_run) + len(contract_breaches) + unverified,
    )
    return _report_verdict(
        summary=summary,
        blocking=bool(frauds or contract_breaches or undeclared_could_not_run),
        unverified=unverified,
        gate=args.gate,
        not_rechecked=len(getattr(could_not_run, "not_applicable", [])),
    )


if __name__ == "__main__":
    sys.exit(main())
