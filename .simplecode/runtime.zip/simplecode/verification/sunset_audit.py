# -*- coding: utf-8 -*-
"""Exemption Sunset Audit — ADR-0013.

Every "legalized evasion" (skip marker, noqa comment, gitignore entry, etc.)
must carry a sunset tag on the same line (or immediately above, for .gitignore
entries):

    # noqa: E501  # sunset-reviewed: 3.3 -- ARCH-001: generated alignment

When the MAJOR.MINOR version increments the tag becomes stale and the evasion
must be re-confirmed or removed before the next push is permitted.

This module is intentionally dependency-light: stdlib only, no AST parsing --
with one exception, `yaml`, added 2026-09-10 for `_load_vendored_path_prefixes`
below. It is not a new dependency for the kit: `dangling_refs.py` already
imports it for the sibling `foreign_corpus_prefixes` key of the same
`corpus_exempt.yaml`, so this module gains nothing the process didn't already
carry.

The `< 500 ms` this line used to claim for the fleet-wide scan was never run.
Measured 2026-09-05 on 24 repos: 4.6 s at that point, 3.5 s after the pruning
described below. The number is kept here as a MEASURED figure so the next
person can tell whether they made it worse, which the old one could not do.

ONE subprocess, added 2026-09-05 and measured rather than argued: a single
`git ls-files --others --ignored --exclude-standard --directory` per root, to
learn which trees git ignores so the walk can prune them before descending.
See `_git_ignored_roots` for the measurement that bought it and for what the
gate now declines to say.

VENDORED code is pruned the same way, added 2026-09-10. Measured on Atlas:
`playbooks/` is a byte-for-byte copy of `nvidia/dgx-spark-playbooks` (Luis's
decision 2026-08-26, `.simplecode/corpus_exempt.yaml`'s `vendored_path_prefixes`
-- editing it in place already cost 50 forked files once), and this gate had
no way to know that. It reported 312 UNTAGGED sites under that one prefix,
every one of them a file the repo is contractually forbidden to touch, which
in turn blocked `version_bump --apply` from EVER succeeding -- not a one-time
failure, a permanent one, since those 312 sites could never legitimately gain
a tag. `ruff` (`extend-exclude` in `ruff.toml`) and `pyright` already skip this
tree for the same reason; this module did not. See `_load_vendored_path_prefixes`.
"""

from __future__ import annotations

import ast
import io
import os
import re
import subprocess
import tokenize
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

import yaml

# ---------------------------------------------------------------------------
# Exemption taxonomy
# ---------------------------------------------------------------------------

_PYTHON_EXEMPTIONS: list[tuple[str, str]] = [
    ("test-silencer", r"@pytest\.mark\.skip|@pytest\.mark\.xfail|pytest\.skip\(|skipIf\("),
    ("lint-suppress", r"#\s*noqa|#\s*type:\s*ignore|#\s*pylint:\s*disable"),
    ("hook-bypass",   r"--no-verify|SKIP\s*="),  # pattern (exclude message/receipt)
    ("corpus-override", r"#\s*simplecode:corpus|#\s*simplecode:allow"),
    # These 3 are pattern_detectors.py's OWN escape hatch (`_ticket_justification_re`,
    # tag words "blocking-sleep"/"unmanaged-open"/"destructive-input"), each already
    # requiring a real ADR/DGX/SC/DEBT ticket citation on the same line -- but that
    # citation is a DIFFERENT convention than this module's `sunset-reviewed: X.Y`
    # tag, and was invisible to this taxonomy entirely until measured 2026-08-30:
    # `sunset_audit.scan_python_file` on tests/test_time_budget.py, which carries 4
    # real `# blocking-sleep: ... -- DEBT-...` comments, returned zero exemptions.
    # An escape hatch a version bump can never re-examine is exactly the blind spot
    # ADR-0013 exists to close -- these three just weren't in scope on day one.
    ("blocking-sleep-override", r"#\s*blocking-sleep:"),
    ("unmanaged-open-override", r"#\s*unmanaged-open:"),
    ("destructive-input-override", r"#\s*destructive-input:"),
]

_PYTHON_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (kind, re.compile(pat)) for kind, pat in _PYTHON_EXEMPTIONS
]

# A sunset tag looks like:  # sunset-reviewed: 3.3 -- ...
# El UNICO valor admitido es un MAJOR.MINOR. TODA exencion caduca -- decision
# de Luis, 2026-09-15: "no debe haber nada permanent exempt, todo exempt debe
# de tener fecha de caducidad siempre".
#
# El literal `permanent` existio hasta esa fecha y se abolio por lo que le hizo
# a su propio instrumento. Medido en simplecode el 2026-09-15: las 86 exenciones
# del repo estaban etiquetadas `permanent` y NINGUNA versionada, asi que la
# mitad `stale` de `check_stale` se quedo sin un solo sujeto posible y devolvia
# `stale=0` contra cualquier version objetivo -- comprobado contra 7.1.0, 9.0.0
# y 99.0.0, las tres PASS. Ese cero no decia "revisado y limpio", decia "no hay
# nada que mirar", y la politica de reportes de esta casa lee un gate sin
# capturas como un defecto del gate, nunca como prueba de que el sujeto este
# limpio.
#
# El comentario que ocupaba estas lineas afirmaba que `PERMANENT_REASON_MINIMA`
# exigia sustancia en la razon. Esa constante NO EXISTIA -- ni en este modulo ni
# en el repo ni en la flota (`find -print0 | xargs grep`, un solo acierto: el
# propio comentario que lo prometia). Nada juzgaba la prosa, y una etiqueta
# `# sunset-reviewed: permanent` sin ninguna razon pasaba como OK, verificado
# con fixture plantada. La puerta que el comentario decia vigilar estaba abierta
# y 86 de 86 exenciones habian pasado por ella.
_SUNSET_TAG_RE = re.compile(r"#\s*sunset-reviewed:\s*(\d+\.\d+)\b")

# .gitignore: a sunset-reviewed comment must appear on the line immediately above
_GITIGNORE_COMMENT_RE = re.compile(r"^#\s*sunset-reviewed:\s*(\d+\.\d+)\b")

# Techo para la UNICA llamada a subprocess de este modulo. `git ls-files` sobre
# un repo grande es E/S de indice, no de arbol: en la flota de 24 repos la mas
# lenta tarda decimas de segundo. Treinta es dos ordenes de magnitud por encima
# de eso, es decir un techo que solo salta si git se ha colgado -- que es lo
# unico que un timeout debe distinguir. Sin el, un `git` bloqueado en un lock
# cuelga el hook para siempre y sin mensaje.
_GIT_TIMEOUT_SECONDS = 30


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class ExemptionRecord:
    """One legalized evasion found in a file."""
    path: Path
    line_number: int          # 1-based
    line_content: str
    kind: str                 # e.g. "test-silencer", "gitignore"
    version_reviewed: str | None  # "3.3" (MAJOR.MINOR), or None when untagged


@dataclass
class AuditResult:
    """Outcome of a sunset audit run.

    `could_not_run` carries a THIRD verdict, not a variety of PASS: a repo
    whose version or whose files could not be read has an UNKNOWN exemption
    state. Reporting zero findings over it would be the blind instrument
    ADR-0013 exists to remove, so `passed` is False whenever it is set --
    the audit is never green over something it did not read -- and the fleet
    summary counts it apart from FAIL, because a repo that was never read is
    not a repo with findings (measured 2026-09-15: the fleet audit reported
    "11 repos, 6 FAIL, 5 PASS" while 8 declared satellites of 18 had never
    been looked at, and printed not one COULD_NOT_RUN).
    """
    version: str | None
    stale: list[ExemptionRecord] = field(default_factory=list)
    untagged: list[ExemptionRecord] = field(default_factory=list)
    ok: list[ExemptionRecord] = field(default_factory=list)
    could_not_run: str | None = None
    # Exenciones ETIQUETADAS en un repo que no declara version: se sabe que
    # existen y no se puede decir si vencieron. Es el COULD_NOT_RUN de la mitad
    # de caducidad, contado aparte para que no se lea ni como OK ni como stale.
    undatable: list[ExemptionRecord] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        """Nunca verde sobre algo que no se pudo juzgar -- `undatable` incluido."""
        return (
            self.could_not_run is None
            and not self.stale
            and not self.untagged
            and not self.undatable
        )

    def _print_sin_version(self) -> None:
        """El repo se leyo entero; lo que falta es el denominador.

        Se imprime lo que SI se decidio (las sin etiqueta) junto a lo que no
        (las etiquetadas, que no se pueden fechar), con las dos cifras a la
        vista. Antes esto era un COULD_NOT_RUN que no nombraba ni una exencion.
        """
        total = len(self.untagged) + len(self.undatable)
        print(f"[sunset-audit] version=UNDECLARED ({total} exemption(s) found). "
              "El arbol se leyo entero; lo que falta es la VERSION del repo.")
        for rec in self.untagged:
            donde = ("en la linea INMEDIATAMENTE ANTERIOR" if rec.kind == "gitignore"
                     else "en la MISMA linea")
            print(f"  UNTAGGED   {rec.path}:{rec.line_number}  [{rec.kind}]  "
                  f"-- falta `# sunset-reviewed: X.Y -- razon` {donde}")
        print(f"[sunset-audit] untagged: {len(self.untagged)} of {total} "
              "exemption(s) -- ESTO SI se decide sin version: una exencion sin "
              "etiqueta lo esta pase lo que pase.")
        print(f"[sunset-audit] stale: COULD_NOT_RUN sobre {len(self.undatable)} "
              "exencion(es) etiquetada(s) -- este repo no declara version, asi "
              "que no hay con que compararlas. No es un OK.")
        if self.passed:
            # Cero exenciones y ninguna version: no hay nada que fechar, asi que
            # no hay nada que reprochar. Se dice que el PASS es vacuo igual.
            print("[sunset-audit] PASS (VACUO) -- este repo no declara version, "
                  "pero tampoco tiene una sola exencion que fechar.")
        else:
            print("[sunset-audit] FAIL -- declara una version "
                  "(`[project].version` en pyproject.toml) para que sus "
                  "exenciones puedan caducar.")

    def print_report(self) -> None:
        """Write a human-readable summary to stdout."""
        if self.could_not_run is not None:
            print(f"[sunset-audit] COULD_NOT_RUN: {self.could_not_run}. This repo's "
                  "exemption state is UNKNOWN -- it is not a PASS.")
            return
        if self.version is None:
            self._print_sin_version()
            return
        minor_key = ".".join(self.version.split(".")[:2])
        total = len(self.stale) + len(self.untagged) + len(self.ok)
        print(f"[sunset-audit] version={self.version} ({total} exemption(s) found)")
        # El DENOMINADOR, no solo el cero. Un `stale: 0` a secas se lee como
        # "revisadas y al dia"; cuando no hay sujetos versionados significa
        # "no habia nada que comparar", que es lo contrario de una revision.
        # Las dos frases tienen que ser distinguibles en la salida, porque en
        # este repo la segunda fue verdad durante todo 7.0 y el reporte decia
        # PASS (86 exenciones, 0 versionadas, 0 stale contra cualquier version).
        versionadas = len(self.stale) + len(self.ok)
        if versionadas:
            print(f"[sunset-audit] stale: {len(self.stale)} of {versionadas} "
                  f"versioned exemption(s), compared against {minor_key}")
        else:
            print(f"[sunset-audit] stale: 0 of 0 versioned exemption(s) -- NO "
                  f"SUBJECTS: nothing was compared against {minor_key}, so this "
                  f"is not a review. A zero here is a defect in the gate, not "
                  f"evidence the repo is clean.")
        for rec in self.untagged:
            # DEBT-SURVEY-LIMITS-DISCOVERED-BY-COLLISION (Twiner): naming the
            # violation without naming the fix meant a tag placed on the wrong
            # line (or in a docstring/comment block instead of inline) looked
            # identical to no tag at all -- indistinguishable failures with one
            # message. Say exactly where the tag belongs for THIS kind.
            donde = (
                "en la linea INMEDIATAMENTE ANTERIOR"
                if rec.kind == "gitignore"
                else "en la MISMA linea"
            )
            print(
                f"  UNTAGGED   {rec.path}:{rec.line_number}  [{rec.kind}]  "
                f"-- falta `# sunset-reviewed: X.Y -- razon` {donde}"
            )
        for rec in self.stale:
            print(f"  STALE({rec.version_reviewed})  {rec.path}:{rec.line_number}  [{rec.kind}]"
                  f"  (current: {minor_key})")
        for rec in self.ok:
            print(f"  OK({rec.version_reviewed})   {rec.path}:{rec.line_number}  [{rec.kind}]")
        if self.passed and versionadas:
            print("[sunset-audit] PASS — all exemptions tagged for current version.")
        elif self.passed:
            # Un PASS sobre cero sujetos no es la misma frase que un PASS sobre
            # 86 revisados, y escribirlas igual fue exactamente el defecto: el
            # reporte decia "all exemptions tagged for current version" sobre un
            # repo donde ninguna exencion estaba versionada.
            print("[sunset-audit] PASS (VACUO) — no habia ninguna exencion "
                  "versionada que comparar. El reporte esta completo; el sujeto "
                  "no esta revisado.")
        else:
            total_issues = len(self.stale) + len(self.untagged)
            print(f"[sunset-audit] FAIL — {total_issues} exemption(s) require review.")


# ---------------------------------------------------------------------------
# Scanners
# ---------------------------------------------------------------------------

def _minor_key(version: str) -> str:
    """'3.3.1' → '3.3'."""
    parts = version.split(".")
    return f"{parts[0]}.{parts[1]}" if len(parts) >= 2 else parts[0]


def _string_literal_spans(text: str) -> dict[int, list[tuple[int, int]]] | None:
    """Per 1-based line, the column ranges occupied by string literals.

    Returns None when the source cannot be tokenized -- the caller then scans
    every line, because refusing to look is worse than looking too hard.

    Exists because a test that exercises the noqa detector must CONTAIN the
    string `"# noqa"`, and that fixture is a mention, not an evasion. Measured
    2026-09-02 on this repo: scanning `tests/` naively surfaced 96 untagged
    exemptions across 33 files, and the great majority were fixtures. A gate
    that reports 96 findings of which most are noise is a gate people learn to
    ignore, which is the vice ADR-0013 exists to prevent.

    Matches in real CODE are deliberately NOT excluded -- a literal
    `--no-verify` passed to `subprocess.run` is an evasion wherever it lives.
    Only the inside of a string literal is exempt.
    """
    spans: dict[int, list[tuple[int, int]]] = {}
    try:
        for tok in tokenize.generate_tokens(io.StringIO(text).readline):
            if tok.type != tokenize.STRING:
                continue
            (srow, scol), (erow, ecol) = tok.start, tok.end
            for row in range(srow, erow + 1):
                start = scol if row == srow else 0
                end = ecol if row == erow else _END_OF_LINE
                spans.setdefault(row, []).append((start, end))
    except (tokenize.TokenError, IndentationError, SyntaxError, ValueError):
        return None
    return spans


def _python_comments_by_line(text: str) -> dict[int, str]:
    """Return actual Python comment tokens, even when later source is malformed."""
    comments: dict[int, str] = {}
    try:
        for tok in tokenize.generate_tokens(io.StringIO(text).readline):
            if tok.type == tokenize.COMMENT:
                comments[tok.start[0]] = tok.string
    except (tokenize.TokenError, IndentationError, SyntaxError, ValueError):
        return comments
    return comments


def _python_prose_spans(text: str, comments: dict[int, str]) -> dict[int, list[tuple[int, int]]]:
    """Locate comments and actual docstrings; executable string arguments stay visible.

    AST columns count UTF-8 bytes; regex and tokenizer columns count characters.
    Malformed Python retains the conservative full-text census.
    """
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError):
        return {}
    lines = text.splitlines()
    spans = {row: [(len(lines[row - 1]) - len(comment), len(lines[row - 1]))]
             for row, comment in comments.items()}
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if not node.body or not isinstance(node.body[0], ast.Expr):
            continue
        value = node.body[0].value
        if not isinstance(value, ast.Constant) or not isinstance(value.value, str):
            continue
        assert value.end_lineno is not None
        for row in range(value.lineno, value.end_lineno + 1):
            encoded = lines[row - 1].encode('utf-8')
            start = len(encoded[:value.col_offset].decode('utf-8')) if row == value.lineno else 0
            end = len(encoded[:value.end_col_offset].decode('utf-8')) if row == value.end_lineno else len(lines[row - 1])
            spans.setdefault(row, []).append((start, end))
    return spans


_END_OF_LINE = 1 << 30


# Only these are COMMENT-shaped: their pattern requires a leading `#`, so a
# match inside a string literal can only be a fixture. `hook-bypass` and
# `test-silencer` are CODE-shaped -- `run([..., "--no-verify"])` is a real
# bypass written as a string argument, and excusing it because it sits between
# quotes would be the opposite of the point. LIMIT, declared: a fixture of a
# code-shaped pattern is therefore still reported. That errs loud.
_COMMENT_SHAPED_KINDS = frozenset({
    "lint-suppress", "corpus-override",
    "blocking-sleep-override", "unmanaged-open-override", "destructive-input-override",
})


def _inside_a_string(
    spans: dict[int, list[tuple[int, int]]] | None, kind: str, lineno: int, start: int, end: int
) -> bool:
    if spans is None or kind not in _COMMENT_SHAPED_KINDS:
        return False
    return any(a <= start and end <= b for a, b in spans.get(lineno, ()))


def scan_python_file(path: Path) -> list[ExemptionRecord]:
    """Scan a single Python (or shell/text) file for exemption patterns.

    RAISES on a path that is not a readable file, rather than returning the
    empty list. Reported by aequitas_os 2026-09-02 with the failure it caused:
    a probe over a nonexistent path printed `stale 0 untagged 0 ok 0` and
    exited 0 -- a clean verdict indistinguishable from an absent subject. It
    bit an agent whose cwd was wrong, and the repo-wide form run from a
    subdirectory reported 185 records instead of 282 without a word. A
    verification that cannot come out negative is not a verification.
    """
    if not path.is_file():
        raise FileNotFoundError(
            f"sunset_audit: {path} is not a readable file. Returning zero "
            f"exemptions here would be a clean verdict over an absent subject."
        )
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        raise OSError(f"sunset_audit: {path} could not be read ({exc})") from exc
    spans = _string_literal_spans("\n".join(lines)) if path.suffix == ".py" else None
    comments = _python_comments_by_line("\n".join(lines)) if path.suffix == ".py" else {}
    prose = _python_prose_spans("\n".join(lines), comments) if path.suffix == ".py" else {}
    records: list[ExemptionRecord] = []
    for lineno, line in enumerate(lines, start=1):
        for kind, pattern in _PYTHON_PATTERNS:
            # Backticked corpus markers in comment prose are citations. Keep
            # unquoted directives, including a secondary directive after noqa.
            if kind == "corpus-override" and path.suffix == ".py" and spans is not None:
                comment = comments.get(lineno, "")
                if not pattern.search(re.sub(r"`[^`]*`", "", comment)):
                    continue
            hit = next((candidate for candidate in pattern.finditer(line)
                        if not _inside_a_string(
                            spans, kind, lineno, candidate.start(), candidate.end()
                        ) and not (kind not in _COMMENT_SHAPED_KINDS and any(
                            start <= candidate.start() and candidate.end() <= end
                            for start, end in prose.get(lineno, ())
                        ))), None)
            if hit:
                comment = comments.get(lineno, "") if path.suffix == ".py" else line
                tag_match = _SUNSET_TAG_RE.search(comment)
                records.append(ExemptionRecord(
                    path=path,
                    line_number=lineno,
                    line_content=line.rstrip(),
                    kind=kind,
                    version_reviewed=tag_match.group(1) if tag_match else None,
                ))
    return records


def scan_gitignore(path: Path) -> list[ExemptionRecord]:
    """Scan a .gitignore file.

    Each non-blank, non-comment entry must have a ``# sunset-reviewed: X.Y``
    comment on the immediately preceding line. RAISES on an absent or
    unreadable file, like :func:`scan_python_file` (SPEC-L239).
    """
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        # Same contract as `scan_python_file`: an unreadable .gitignore is not a
        # .gitignore with zero exemptions in it; `audit_repo` turns this into COULD_NOT_RUN.
        raise OSError(f"sunset_audit: {path} could not be read ({exc})") from exc
    records: list[ExemptionRecord] = []
    for lineno, line in enumerate(lines, start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        # Check preceding line for a sunset comment
        prev_line = lines[lineno - 2] if lineno >= 2 else ""
        tag_match = _GITIGNORE_COMMENT_RE.match(prev_line.strip())
        records.append(ExemptionRecord(
            path=path,
            line_number=lineno,
            line_content=line.rstrip(),
            kind="gitignore",
            version_reviewed=tag_match.group(1) if tag_match else None,
        ))
    return records


def _version_or_could_not_run(root: Path) -> tuple[str | None, str | None]:
    """``(version, could_not_run_reason)`` -- THREE outcomes, not two.

    - ``(version, None)``  -- read.
    - ``(None, None)``     -- the file is there, decodes and parses, and simply
      declares no ``[project].version``. Measured 2026-09-15 on
      blog_ciudadano_x and poe_normare: both carry a ``pyproject.toml`` that is
      nothing but ``[tool.ruff]`` config. Nothing was unreadable, so the caller
      may fall back to the mother's version -- the behaviour this module has
      always had for them. DECLARED LIMIT: judging their exemptions against the
      MOTHER's minor is a borrowed denominator, and whether that should become
      its own verdict is a decision with its own cost, not taken here.
    - ``(None, reason)``   -- COULD_NOT_RUN. The directory is absent, there is
      no ``pyproject.toml``, or the file cannot be decoded or parsed.

    The third branch is why this function exists. It used to be
    ``_project_version`` and it RAISED on an undecodable file -- a crash where a
    verdict belongs. Measured 2026-09-15: ``pyproject.toml`` holding
    ``b"\\xff\\xfe[project]\\n"`` took down the whole fleet audit with
    ``UnicodeDecodeError`` at ``pyproject.read_text``, and through
    ``version_bump``'s new MINOR wiring it took down the test suite with it.
    """
    if not root.is_dir():
        return None, f"directory absent ({root})"
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        # NO es un COULD_NOT_RUN: el arbol se lee entero, lo unico que falta es
        # la VERSION. Tratarlo como "no se pudo leer" costaba el informe entero
        # de 8 repos de la flota -- medido 2026-09-15: agente_inmobiliario,
        # blackbox, cuenza, migracion_atom, own_chats, poe_systems, red_python
        # y sistemas_estocasticos_ruleta suman **735 exenciones, 645 de ellas
        # SIN ETIQUETA**, y el gate no habia mirado ni una sola porque abortaba
        # antes de abrir un fichero. Una exencion sin etiqueta lo esta con
        # independencia de la version: esa mitad del veredicto no necesita
        # denominador y se puede dar siempre.
        return None, None
    try:
        text = pyproject.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        return None, f"{pyproject} could not be read ({type(exc).__name__}: {exc})"
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as exc:
        return None, f"{pyproject} is not valid TOML ({exc})"
    proyecto = data.get("project")
    version = proyecto.get("version") if isinstance(proyecto, dict) else None
    return (version if isinstance(version, str) else None), None


def _project_version(root: Path) -> str | None:
    """Read MAJOR.MINOR.PATCH from pyproject.toml, or None if it cannot be had.

    Kept as the narrow accessor for callers that only want a version and have
    their own fallback (`main`, `version_bump`). The REASON lives in
    :func:`_version_or_could_not_run`; collapsing both to None here is what
    makes this the wrong function for a fleet row.
    """
    return _version_or_could_not_run(root)[0]


@dataclass
class Census:
    """What a walk of a repository actually looked at.

    Three numbers instead of one, because a bare record count cannot tell the
    difference between "this repo is clean" and "this repo was barely read".
    `walked` is the denominator; `unreadable` counts entries the walk listed
    but could not read (a dangling symlink is the common one) -- they are NOT
    files with zero exemptions, and collapsing them into `walked` would say
    they were; `skipped_ignored` counts the ENTRIES git told
    us were not the repo's content -- a whole pruned tree counts once, because
    the walk never descends into it and so cannot know how many files it holds,
    and inventing that number would be the kind of unmeasured figure this
    module exists to refuse; `prune_unavailable` is the reason the pruning
    could not run, or None. A census with `prune_unavailable` set is NOT a pruned
    census, however small its record count. `skipped_vendored` is the same
    idea for a different reason: entries under a declared
    `vendored_path_prefixes` prefix that the repo is not the author of and,
    unlike `skipped_ignored`, is not merely absent from git's index -- it is
    tracked, present, and off-limits to edit (see `_load_vendored_path_prefixes`).
    """
    records: list[ExemptionRecord] = field(default_factory=list)
    walked: int = 0
    skipped_ignored: int = 0
    skipped_vendored: int = 0
    unreadable: int = 0
    prune_unavailable: str | None = None


def _load_vendored_path_prefixes(root: Path) -> tuple[str, ...]:
    """Project-local, opt-in directory PREFIXES this repo tracks but does not
    author and must not edit in place (same pattern as `foreign_corpus_prefixes`
    in `dangling_refs.py`, which this mirrors almost verbatim).

    Read from ``<root>/.simplecode/corpus_exempt.yaml``, key
    ``vendored_path_prefixes``. Absent file/key -> no exemptions, so a repo
    with no such declaration scans exactly as before this existed.

    PREFIX, and a relative-path string check rather than a resolved-directory
    frozenset like `_git_ignored_roots`'s `ignorados`: `vendored_path_prefixes`
    names conventions ("playbooks/"), not an enumerable list from git, and a
    prefix a repo declares today should cover a playbook added tomorrow
    without anyone regenerating a list -- the exact reasoning
    `corpus_exempt.yaml`'s own comment gives for using a prefix here instead
    of `vendored_paths` (file-exact).
    """
    config = root / ".simplecode" / "corpus_exempt.yaml"
    if not config.is_file():
        return ()
    try:
        data = yaml.safe_load(config.read_text(encoding="utf-8")) or {}
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return ()
    if not isinstance(data, dict):
        return ()
    prefixes = data.get("vendored_path_prefixes", [])
    if not isinstance(prefixes, list):
        return ()
    return tuple(str(p).replace("\\", "/") for p in prefixes if isinstance(p, str) and p.strip())


def _is_vendored(root: Path, path: Path, prefixes: tuple[str, ...]) -> bool:
    """True iff *path* (absolute, under *root*) falls under a declared
    `vendored_path_prefixes` entry."""
    if not prefixes:
        return False
    rel = path.relative_to(root).as_posix()
    return rel.startswith(prefixes)


def _git_ignored_roots(root: Path) -> tuple[frozenset[Path], str | None]:
    """The paths under *root* that git ignores, collapsed to whole directories.

    Returns `(paths, None)` on success and `(frozenset(), reason)` when the
    pruning could not run -- git absent, *root* not a work tree, the call
    failing. The caller must then scan everything and SAY so: silently
    scanning less is the failure mode this whole module exists to prevent,
    and silently scanning more is merely loud.

    Why this exists, measured on RePic 2026-09-05. Its 1.1 GB of harvested
    third-party source (digiKam, exiftool, ImageHash, VisiPics and five more)
    is git-ignored, and moving it inside the tree took this audit from
    `PASS -- 31 exemptions over 16 files` to `FAIL -- 330 require review over
    130 files`. All 330 were `.gitignore` entries belonging to OTHER PROJECTS,
    which the repo cannot tag because they are not its lines to edit. Adding
    the tree to the repo's own `.gitignore` changed nothing: measured, still
    330, because this walk read the disk and never asked the index. A gate
    whose verdict is set by material its own repo has already declared
    foreign is not measuring that repo.

    Why a subprocess, when the module docstring used to forbid one. The
    alternative is reimplementing gitignore semantics -- precedence, negation,
    `**`, per-directory files, `.git/info/exclude`, the global excludesfile --
    in Python, to agree with git in every corner. Git already does it, exactly,
    and one batched call per root is what it costs. Measured rather than
    argued: the whole fleet scan went from 4.6 s at HEAD to 3.5 s with this
    call in it, because the trees it lets the walk skip cost more than the 24
    subprocesses do. The timings are laid out in `scan_exemptions_census`.

    What this makes the gate STOP saying, declared rather than discovered
    later: an exemption written into a git-ignored file is no longer reported.
    That is intended -- it is not in the repo's content -- but it means a
    `# noqa` inside a gitignored generated file now goes unaudited here, and
    the `skipped_ignored` count printed by the report is what keeps that
    visible instead of silent.
    """
    try:
        proceso = subprocess.run(
            ["git", "-C", str(root), "ls-files", "--others", "--ignored",
             "--exclude-standard", "--directory", "-z"],
            capture_output=True,
            check=False,
            timeout=_GIT_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return frozenset(), f"git could not be run ({exc})"
    if proceso.returncode != 0:
        detalle = proceso.stderr.decode("utf-8", "replace").strip().splitlines()
        return frozenset(), f"git exited {proceso.returncode} ({detalle[0] if detalle else 'no message'})"
    salida = proceso.stdout.decode("utf-8", "replace")
    return frozenset(
        (root / entrada.rstrip("/")).resolve()
        for entrada in salida.split("\0")
        if entrada
    ), None


def scan_exemptions(root: Path) -> list[ExemptionRecord]:
    """Records only. Use :func:`scan_exemptions_census` to also get the counts."""
    return scan_exemptions_census(root).records


# Un worktree de agente de Claude Code: `.claude/worktrees/agent-<id>/` es una
# COPIA COMPLETA del repo que la sesión crea para aislar a un subagente, y git
# la excluye vía `.git/info/exclude`. Contarla no añade una sola exención real:
# cada registro que trae es un duplicado de uno que ya se contó en el árbol
# principal, y encima con una ruta que el autor del repo no puede editar.
#
# Medido en office2office el 2026-09-04, con cinco agentes trabajando:
# `sunset-audit` reportó **916 exenciones**, de las cuales **687 (el 75 %)**
# venían de `.claude/worktrees/agent-*`. El número real del árbol era 229. Un
# gate cuyo conteo se triplica según cuántos subagentes haya corriendo en ese
# momento no está midiendo el repo.
#
# Se comprueba la PAREJA de segmentos y no un `worktrees` suelto en `skip_dirs`:
# un repo puede tener legítimamente un directorio llamado `worktrees/`, y
# saltárselo entero sería esconder exenciones de verdad. Mismo criterio que
# `prek` y `.retired` -- árboles que el repo no escribe -- aplicado con la
# precisión que este caso necesita.
_AGENT_WORKTREE_SEGMENTS = (".claude", "worktrees")


def _under_any(path: Path, roots: frozenset[Path]) -> bool:
    """True when *path* is one of *roots* or lives underneath one of them.

    Two things this does NOT do, and only one of them paid off:

    - No `Path.resolve()` per entry. The caller walks down from an
      already-resolved root, so every path here is already absolute and
      normalized. Measured on the 24-repo fleet 2026-09-05: 91.6/94.3/96.8 s
      with it, 93.3/95.1/93.0 s without. **No measurable gain.** It stays
      because a syscall per entry that buys nothing is still a syscall per
      entry, but the honest record is that this was not the bottleneck.
    - No scan over *roots*. Testing `raiz in path.parents` for every root is
      O(len(roots)) per entry; asking whether any of the entry's own parents
      is IN the set is O(depth) against a hash lookup. THAT was the
      bottleneck: same fleet, same day, 93 s before and 3.5 s after, with
      nothing else changed.
    """
    if path in roots:
        return True
    return any(ancestro in roots for ancestro in path.parents)


def _is_agent_worktree(path: Path, root: Path) -> bool:
    """True si `path` cae dentro de un `.claude/worktrees/` POR DEBAJO de `root`.

    La pregunta es relativa al sujeto y no absoluta, y esa es toda la
    correccion: `.claude/worktrees` en los ancestros de `root` describe donde
    esta parado el auditor, no que haya un worktree DENTRO del arbol que se
    esta auditando.

    Medido 2026-09-15 con un par de control de bytes identicos (mismo md5),
    cambiando solo la ruta: fuera de un worktree `passed=False stale=1
    untagged=1`; con el mismo arbol colgado de `.claude/worktrees/fake`,
    `walked=0 passed=True`. El juicio absoluto podaba (a) el propio root y
    (b) TODOS sus hijos -- `src`, `tests`, `docs`, los tres daban True -- asi
    que un agente que corriera el gate desde su worktree obtenia un PASS sobre
    un repo que nunca abrio, con `could_not_run=None`. El hook de pre-push
    corre esta compuerta (`version_bump._version_checks`) y los agentes
    empujan desde worktrees, de modo que ese verde vacio era el caso normal,
    no el raro.

    Lo que sigue intacto es el motivo por el que el guard existe: una MADRE
    que se audita a si misma sigue podando los `.claude/worktrees/*` de sus
    agentes, porque para ella si cuelgan por debajo del root.
    """
    try:
        partes = path.relative_to(root).parts
    except ValueError:
        # No cuelga de `root`: no es asunto de esta pasada.
        return False
    return any(
        partes[i:i + 2] == _AGENT_WORKTREE_SEGMENTS
        for i in range(len(partes) - 1)
    )


@dataclass(frozen=True)
class _PruneContext:
    """The four facts about *root* that stay the same for every directory
    the walk visits, bundled so the per-directory pruning call takes the two
    things that actually change (which directory, its children) plus this
    one, instead of four more parameters that would all have the same value
    on every call.
    """
    root: Path
    skip_dirs: set[str]
    ignorados: frozenset[Path]
    vendored_prefixes: tuple[str, ...]


def _directorios_a_conservar(
    actual: Path,
    nombres: list[str],
    ctx: _PruneContext,
) -> tuple[list[str], int, int]:
    """The subdirectories of *actual* worth descending into, how many were
    pruned for being git-ignored, and how many for being vendored.

    The three travel together on purpose: a caller that got the list without
    the counts could not tell a directory it chose not to enter from one that
    was never there, nor tell "not the repo's content" (git-ignored) from
    "the repo's content, but not the repo's to edit" (vendored) -- two
    different facts that both mean "do not report an UNTAGGED here".
    """
    conservados: list[str] = []
    podados = 0
    podados_vendorizados = 0
    for nombre in nombres:
        hijo = actual / nombre
        if nombre in ctx.skip_dirs or _is_agent_worktree(hijo, ctx.root):
            continue
        if ctx.ignorados and _under_any(hijo, ctx.ignorados):
            podados += 1
            continue
        if _is_vendored(ctx.root, hijo, ctx.vendored_prefixes):
            podados_vendorizados += 1
            continue
        conservados.append(nombre)
    return conservados, podados, podados_vendorizados


def _registros_de(path: Path, code_shaped_in_tests: set[str]) -> list[ExemptionRecord]:
    """The exemption records in one file, with the tests/ carve-out applied."""
    if path.name == ".gitignore":
        return scan_gitignore(path)
    found = scan_python_file(path)
    if "tests" in path.parts:
        return [r for r in found if r.kind not in code_shaped_in_tests]
    return found


_HUNK = re.compile(r"^@@ -\S+ \+(\d+)(?:,(\d+))? @@", re.MULTILINE)
_TEXT_EXTENSIONS = {".py", ".sh", ".yaml", ".yml", ".toml", ".cfg", ".ini"}
# Kit files whose subject IS the vocabulary of exemptions (they quote `noqa`, `--no-verify`, corpus markers as
# data), so scanning them reports the detectors' own fixtures. Shared by the whole-repo census and the
# staged check: the staged check first ignored this list and blocked a commit on agent_threats.py's own
# corpus marker, a line the census has never counted (2026-09-25).
_SKIP_FILES = frozenset({
    "pattern_detectors.py", "detector_controls.py", "sunset_audit.py", "hook_receipts.py", "agent_threats.py",
    "corruption_guard.py", "injection_filter.py", "truncation_guard.py", "adversarial_judge.py",
    "success_evals.py", "transcript_acquire.py", "zero_debt.py",
})
_SKIP_PARTS = {".git", "__pycache__", ".venv", "venv", "env", ".tox", "build", "dist", "node_modules", "prek", ".retired"}


def _added_lines(root: Path, rel: str) -> set[int]:
    """Line numbers this commit ADDS to `rel` (the staged diff, zero context)."""
    proc = subprocess.run(["git", "-C", str(root), "diff", "--cached", "-U0", "--no-color", "--", rel],
                          capture_output=True, text=True, check=False)
    lines: set[int] = set()
    for m in _HUNK.finditer(proc.stdout):
        start, count = int(m.group(1)), int(m.group(2) if m.group(2) is not None else 1)
        lines.update(range(start, start + count))
    return lines


def staged_untagged(root: Path) -> list[ExemptionRecord]:
    """Exemptions the staged diff ADDS without a `sunset-reviewed:` tag.

    Atlas (2026-09-25): four exemptions entered untagged after the 1.8 review and no commit-time gate
    saw them; only `sunset_audit` at the next minor bump did. Judged on ADDED lines only, so editing a
    file that already carries an old untagged exemption is not this commit's finding. Same carve-outs
    as the whole-repo scan: vendored prefixes, the trees it never reads, and the code-shaped kinds
    inside tests/.
    """
    root = root.resolve()
    proc = subprocess.run(["git", "-C", str(root), "diff", "--no-relative", "--cached", "--name-only", "--diff-filter=ACM", "-z"],
                          capture_output=True, text=True, check=False)
    vendored = _load_vendored_path_prefixes(root)
    found: list[ExemptionRecord] = []
    for rel in sorted(p for p in proc.stdout.split("\0") if p):
        path = root / rel
        if (_SKIP_PARTS.intersection(path.relative_to(root).parts) or path.name in _SKIP_FILES
                or _is_vendored(root, path, vendored)):
            continue
        if path.name != ".gitignore" and path.suffix not in _TEXT_EXTENSIONS:
            continue
        if not path.is_file():
            continue
        added = _added_lines(root, rel)
        found.extend(r for r in _registros_de(path, {"hook-bypass", "test-silencer"})
                     if r.version_reviewed is None and r.line_number in added)
    return found


def scan_exemptions_census(root: Path) -> Census:
    """Enumerate all exemption records under *root* (recursively).

    Scans:
    - All ``*.py``, ``*.sh``, ``*.yaml``, ``*.yml``, ``*.toml`` files for
      inline exemption patterns.
    - All ``.gitignore`` files for unreviewed entries.

    Skips ``.git/`` and ``__pycache__/`` directories, every tree git ignores
    (see :func:`_git_ignored_roots`), and every tree declared
    `vendored_path_prefixes` in `.simplecode/corpus_exempt.yaml` (see
    :func:`_load_vendored_path_prefixes`) -- the repo's content, but not the
    repo's to edit, so an untagged evasion there is not this repo's finding.
    When the git-ignore pruning cannot run the walk covers everything and the
    census says so; the vendored-prefix pruning has no such failure mode
    (it is a local file read, not a subprocess) and so has no `unavailable` case.
    """
    records: list[ExemptionRecord] = []
    walked = 0
    # Resolved ONCE. Everything the walk yields is built from it, so no entry
    # below needs resolving again -- see `_under_any` for what that cost.
    root = root.resolve()
    ignorados, sin_poda = _git_ignored_roots(root)
    vendored_prefixes = _load_vendored_path_prefixes(root)
    saltados = 0
    saltados_vendorizados = 0
    unreadable = 0
    skip_dirs = {
        ".git",
        "__pycache__",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        ".venv",
        "venv",
        "env",
        ".tox",
        "build",
        "dist",
        "node_modules",
        # Reported by the session 020 (2026-09-04, office2office): `version-bump`
        # blocked on 21 UNTAGGED exemptions the repo cannot fix, because they
        # live in trees the repo does not author. `prek` (a pre-commit hook
        # vendored clone under `.simplecode/prek/repos/<hash>/`, confirmed a
        # gitleaks checkout) and `.retired` (code explicitly renamed-not-deleted
        # per the fleet's suspension convention -- dead by declaration, not a
        # live evasion) are both third-party or intentionally-dead by design.
        # `git check-ignore` was the other fix this session proposed, but this
        # module's docstring declares itself dependency-light on purpose (stdlib
        # only, no subprocess, <500ms fleet-wide) -- adding a subprocess call
        # would violate that constraint for every satellite, not just this one.
        "prek",
        ".retired",
    }
    # `tests` used to sit in that list. Removed 2026-09-02 at the request of the
    # aequitas_os session, which measured 28 noqa/type-ignore lines in 21 test
    # files that no version bump would ever re-examine: an evasion inside a test
    # is still an evasion.
    #
    # But a test suite about bypass detection necessarily CONTAINS bypasses as
    # its subject. String literals are already excluded for comment-shaped
    # patterns; the CODE-shaped ones (`--no-verify` as an argument, a
    # `pytest.mark.skip` decorator on a fixture function) cannot be told apart
    # from the real thing by shape, and reporting them here surfaced 20 findings
    # that were all subject-under-test. LIMIT, declared: a genuine
    # `pytest.mark.skip` silencing a real test inside `tests/` is therefore NOT
    # caught by this gate. It is caught by the suite failing to cover it, which
    # is a different instrument, and this sentence exists so nobody reads the
    # silence as coverage.
    code_shaped_in_tests = {"hook-bypass", "test-silencer"}
    skip_files = _SKIP_FILES
    text_extensions = {".py", ".sh", ".yaml", ".yml", ".toml", ".cfg", ".ini"}
    # `os.walk` and not `rglob`, since 2026-09-05: pruning has to happen
    # BEFORE the descent or it is only a filter, and a filter still pays to
    # walk the tree it is about to discard. Measured on the 24-repo fleet,
    # three runs each, `--fleet` wall clock:
    #
    #   HEAD (no pruning at all)                  4.71 / 4.59 s
    #   filter-only, resolve() per entry        262   / 182   s
    #   descent pruning, O(len(roots)) lookup    91.6 / 94.3 / 96.8 s
    #   descent pruning, ancestor set lookup      3.53 / 3.54 / 3.51 s
    #
    # The two middle rows are drafts of THIS change, kept in the record
    # because they are the honest shape of the work: pruning was worth 40x
    # less than nothing until the containment test stopped scanning the root
    # set once per entry. The last row is what ships, and it is faster than
    # HEAD rather than merely not slower.
    #
    # Recorded while measuring, since it will otherwise be repeated: this
    # module's docstring claims the fleet scan completes in `< 500 ms`. At
    # HEAD it takes 4.6 s -- nine times that. The claim was never run.
    # `_is_agent_worktree(root)` estaba aqui y se fue: con el juicio relativo
    # el root nunca es un worktree DE SI MISMO, y preguntarlo en absoluto era
    # lo que devolvia un censo vacio -- un PASS sobre un arbol jamas abierto.
    # El filtro por `skip_dirs` se queda: un root dentro de `.venv/` o `build/`
    # si es un arbol que este gate no audita.
    if any(part in skip_dirs for part in root.parts):
        return Census(prune_unavailable=sin_poda)
    ctx = _PruneContext(root=root, skip_dirs=skip_dirs, ignorados=ignorados,
                        vendored_prefixes=vendored_prefixes)
    for dirpath, dirnames, filenames in os.walk(root):
        actual = Path(dirpath)
        dirnames[:], podados, podados_vendorizados = _directorios_a_conservar(actual, dirnames, ctx)
        saltados += podados
        saltados_vendorizados += podados_vendorizados
        for nombre in filenames:
            path = actual / nombre
            if nombre in skip_files:
                continue
            if ignorados and _under_any(path, ignorados):
                saltados += 1
                continue
            if _is_vendored(root, path, vendored_prefixes):
                saltados_vendorizados += 1
                continue
            if nombre != ".gitignore" and path.suffix not in text_extensions:
                continue
            # `os.walk` lists a dangling symlink among `filenames`; the old
            # `rglob` walk filtered it out with `path.is_file()` and this one
            # has to do it explicitly. Found 2026-09-05 by the negative
            # control for the pruning, not by the positive case: digiKam ships
            # `snapcraft.yaml` as a symlink to a file it does not carry, and
            # `scan_python_file` -- which RAISES on an unreadable subject, on
            # purpose -- took the whole gate down with a traceback instead of
            # a verdict. Counted rather than dropped: a file the walk could
            # not read is not a file with no exemptions in it.
            if not path.is_file():
                unreadable += 1
                continue
            walked += 1
            records.extend(_registros_de(path, code_shaped_in_tests))
    # The file count travels with the records because "0 exemptions" over 282
    # files and "0 exemptions" over 0 files are the same number and opposite
    # facts. Measured by aequitas_os: the repo-wide scan run from a
    # subdirectory reported 185 records instead of 282 and said nothing.
    # `skipped_ignored` and `prune_unavailable` travel for the same reason:
    # a smaller number because git ignores those trees and a smaller number
    # because the walk never reached them are opposite facts too.
    # `skipped_vendored` travels for a THIRD reason, distinct from both:
    # tracked, present, reached by the walk, and still not this repo's
    # finding to report.
    return Census(
        records=records,
        walked=walked,
        skipped_ignored=saltados,
        skipped_vendored=saltados_vendorizados,
        unreadable=unreadable,
        prune_unavailable=sin_poda,
    )


def check_stale(
    records: Sequence[ExemptionRecord],
    current_version: str | None,
) -> AuditResult:
    """Classify *records* as ok / stale / untagged / undatable.

    `current_version` puede ser None: el repo se leyo entero pero no declara
    version. Entonces la mitad `untagged` SIGUE condenando --una exencion sin
    etiqueta lo esta sin importar la version-- y las etiquetadas caen en
    `undatable`, que es un COULD_NOT_RUN de la mitad de caducidad y no un OK.
    Juzgarlas contra la version de la MADRE seria un denominador prestado: las
    90 etiquetas `0.4` de poe_systems comparadas contra el 7.2 de simplecode
    darian "stale" por una aritmetica que no significa nada.
    """
    if current_version is None:
        result = AuditResult(version=None)
        for rec in records:
            if rec.version_reviewed is None:
                result.untagged.append(rec)
            else:
                result.undatable.append(rec)
        return result
    minor = _minor_key(current_version)
    result = AuditResult(version=current_version)
    for rec in records:
        if rec.version_reviewed is None:
            result.untagged.append(rec)
        elif rec.version_reviewed != minor:
            result.stale.append(rec)
        else:
            result.ok.append(rec)
    return result


# ---------------------------------------------------------------------------
# Fleet runner
# ---------------------------------------------------------------------------

def _names_from_manifest(manifest: Path) -> list[str]:
    """Declared names, best effort, for the ONE case `enrolled_satellites`
    cannot serve.

    `simplecode.satellite.satellite_sync.enrolled_satellites` is the kit's only
    `fleet.toml` reader and it owns the schema (`[[satellite]]` rows, a string
    `name` each, no duplicates). It is also ALL-OR-NOTHING about availability:
    one declared member that is not a git repo and it raises
    `FLEET_MEMBER_UNAVAILABLE` over the whole list. An audit cannot lose 17
    auditable repos because the 18th is absent -- and the absent one is exactly
    what has to be NAMED -- so when it refuses, the names are taken from the
    same file and every repo still gets a row. This reads names and nothing
    else; validation stays where it lives.
    """
    try:
        rows = tomllib.loads(manifest.read_text(encoding="utf-8")).get("satellite")
    except (OSError, UnicodeError, tomllib.TOMLDecodeError):
        return []
    if not isinstance(rows, list):
        return []
    return [r["name"] for r in rows if isinstance(r, dict) and isinstance(r.get("name"), str)]


def _fleet_root_de(mother_root: Path) -> Path:
    """El directorio donde viven los satelites, visto desde `mother_root`.

    Normalmente es `mother_root.parent`. La excepcion es el caso que mas corre:
    un AGENTE trabajando en `<repo>/.claude/worktrees/<nombre>`. Ahi el padre es
    `.claude/worktrees/`, asi que los 18 satelites declarados se buscaban dentro
    del directorio de worktrees y los 18 salian "directory absent" -- medido
    2026-09-15 al aplicar el bump 7.2.0 desde este mismo worktree:
    `fleet: 19 repo(s), 0 FAIL, 1 PASS, 18 COULD_NOT_RUN`, todos apuntando a
    `/home/lcasarin/projects/simplecode/.claude/worktrees/<nombre>`.

    Resolver la ruta (el arreglo anterior) arregla `--root .` pero NO este caso:
    son dos formas distintas de perder la flota y hacian falta las dos.

    Se sube por encima del par `.claude/worktrees/<nombre>` con la misma
    constante que ya usa la poda, sin un segundo subproceso de git: este modulo
    tiene UNA sola llamada a `git` y la mantiene. Supuesto declarado -- la
    convencion de esta casa es `<repo>/.claude/worktrees/<nombre>`; un worktree
    colocado a mano en otro sitio no se reconoce y cae en el caso normal.
    """
    partes = mother_root.parts
    for i in range(len(partes) - 1):
        if partes[i:i + 2] == _AGENT_WORKTREE_SEGMENTS:
            # `partes[:i]` es el checkout principal; su padre es la flota.
            return Path(*partes[:i]).parent
    return mother_root.parent


def declared_satellites(mother_root: Path) -> tuple[list[Path], str | None]:
    """The satellites ``fleet.toml`` DECLARES, and why there are none.

    Replaces discovery by adjacency, which was the defect. The old
    `_find_satellites` took every non-hidden child of `mother_root.parent` that
    carried a `pyproject.toml`, so the SUBJECT of the audit was "whatever sits
    next to the root" rather than the declared fleet. Two costs, both measured
    2026-09-15:

    - 8 of the 18 satellites `fleet.toml` declares (agente_inmobiliario,
      blackbox, cuenza, migracion_atom, own_chats, poe_systems, red_python,
      sistemas_estocasticos_ruleta) have no `pyproject.toml`, so adjacency
      skipped them silently. The report said "11 repos audited, 6 FAIL, 5 PASS"
      with zero COULD_NOT_RUN: a report that reads as complete over 55% of the
      fleet, which is what this house's reporting law forbids.
    - Run from a test's `tmp_path`, "the fleet" is the tmp_path of every OTHER
      test. That is how the suite went red:
      `tests/test_orphan_hunter.py` writes `b"\\xff\\xfe[project]\\n"` into its
      own `tmp_path/pyproject.toml`, and the fleet audit launched from
      `tests/test_version_bump.py` walked into that sibling directory.

    An absent `fleet.toml` yields ZERO satellites and says so. It deliberately
    does NOT fall back to adjacency: a freshly scaffolded repo, or a `tmp_path`,
    has no fleet, and inventing one from its neighbours is the defect itself.
    """
    # `.resolve()` ANTES de tomar `.parent`, y eso es el arreglo entero:
    # `Path(".").parent` es `Path(".")`, no el directorio de arriba, asi que
    # con la invocacion documentada (`sunset-audit --root .`) cada satelite se
    # buscaba en `./<nombre>` y los 18 salian "directory absent".
    # Par de control 2026-09-15 sobre este mismo repo:
    #   Path(".")            -> 18 declarados,  0 existen en disco
    #   Path(".").resolve()  -> 18 declarados, 18 existen en disco
    # Es decir: la mitad de FLOTA de ADR-0013 -- la que un bump MAYOR exige --
    # reportaba COULD_NOT_RUN sobre los 18 repos y nadie veia una sola exencion.
    mother_root = mother_root.resolve()
    manifest = mother_root / "fleet.toml"
    if not manifest.is_file():
        return [], f"no fleet.toml at {manifest} -- this root declares no fleet"
    fleet_root = _fleet_root_de(mother_root)
    try:
        # Function-local: this module is dependency-light on purpose and
        # `satellite_sync` pulls in cli_new, zipfile and yaml. Nothing that
        # imports `sunset_audit` pays for the fleet reader unless it asks for
        # the fleet.
        from simplecode.satellite.satellite_sync import enrolled_satellites

        return list(enrolled_satellites(fleet_root, manifest)), None
    except ValueError:
        return [fleet_root / name for name in _names_from_manifest(manifest)], None


def audit_repo(root: Path) -> AuditResult:
    """One repo's verdict: PASS, FAIL or COULD_NOT_RUN -- never a traceback.

    Both halves of the read are caught, because both can fail on a real repo:
    the version (`_version_or_could_not_run`) and the walk (`scan_exemptions`,
    whose contract is deliberately to RAISE on a file it cannot read rather
    than count it clean -- see `_scan_python_file`). Turning that raise into a
    verdict is this function's whole job; doing it inside the scanner would
    make "unreadable" indistinguishable from "no exemptions", which is the
    thing the scanner refuses to do.
    """
    version, reason = _version_or_could_not_run(root)
    if reason is not None:
        return AuditResult(version="unknown", could_not_run=reason)
    try:
        records = scan_exemptions(root)
    except (OSError, UnicodeError) as exc:
        return AuditResult(
            version=version or "unknown",
            could_not_run=f"{root} could not be scanned ({type(exc).__name__}: {exc})",
        )
    # `fallback_version` (la version de la MADRE) se fue a proposito: prestarle
    # un denominador a un repo que no declara version producia veredictos que
    # no significan nada -- las 90 etiquetas `0.4` de poe_systems comparadas
    # contra el 7.2 de simplecode. Sin version, las etiquetadas salen
    # `undatable` y las SIN etiqueta siguen condenando, que es lo que si se
    # puede decidir sin denominador.
    return check_stale(records, version)


def fleet_summary_lines(results: dict[Path, AuditResult]) -> list[str]:
    """The closing summary, with the denominator, the zeros, and the NAMES.

    Shared by `main --fleet` and `version_bump`'s ADR-0013 call so there is one
    definition of what a fleet verdict says. `COULD_NOT_RUN` is printed beside
    FAIL and PASS and never folded into either, and when it is non-zero the
    summary says in words that the report is NOT clean -- "COMPLETE" describes
    a report, never its subject.
    """
    cnr = sorted(r.name for r, res in results.items() if res.could_not_run is not None)
    sin_version = sorted(
        r.name for r, res in results.items()
        if res.could_not_run is None and res.version is None
    )
    fallando = sorted(
        r.name for r, res in results.items()
        if res.could_not_run is None and not res.passed
    )
    pasando = len(results) - len(cnr) - len(fallando)
    lineas = [
        f"[sunset-audit] fleet: {len(results)} repo(s) in the report, "
        f"{len(fallando)} FAIL, {pasando} PASS, {len(cnr)} COULD_NOT_RUN."
    ]
    if fallando:
        lineas.append(f"[sunset-audit] FAIL (exemptions need review): {', '.join(fallando)}")
    if sin_version:
        undatables = sum(
            len(res.undatable) for res in results.values()
            if res.could_not_run is None and res.version is None
        )
        lineas.append(
            f"[sunset-audit] SIN VERSION DECLARADA ({len(sin_version)} of {len(results)}): "
            f"{', '.join(sin_version)}. Sus exenciones SIN etiqueta si estan contadas "
            f"arriba y condenan; las {undatables} ETIQUETADAS no se pueden fechar "
            "porque el repo no declara version. Esa mitad es un COULD_NOT_RUN."
        )
    if cnr:
        lineas.append(
            f"[sunset-audit] COULD_NOT_RUN ({len(cnr)} of {len(results)}): {', '.join(cnr)}. "
            "This report is NOT clean: their exemption state is UNKNOWN, which is "
            "neither a PASS nor a finding. See each repo's row above for the reason."
        )
    return lineas


def run_fleet_audit(
    mother_root: Path,
    *,
    extra_satellites: list[Path] | None = None,
) -> dict[Path, AuditResult]:
    """Run sunset-audit on *mother_root* and every DECLARED satellite.

    Returns a mapping of {repo_root: AuditResult}. A declared satellite that
    could not be audited stays in the mapping with `could_not_run` set; it
    never silently drops out, which is what made the old report readable as
    complete over a fleet it had only half looked at.
    """
    results: dict[Path, AuditResult] = {}

    # Resuelta antes de usarla como clave: `Path(".").name` es la cadena vacia,
    # asi que la MADRE salia sin nombre en su propia fila del informe.
    mother_root = mother_root.resolve()
    mother = audit_repo(mother_root)
    results[mother_root] = mother

    satellites, sin_flota = declared_satellites(mother_root)
    if sin_flota is not None:
        print(f"[sunset-audit] 0 satellite(s): {sin_flota}. Only {mother_root.name} "
              "is in this report -- nothing was discovered from the neighbouring "
              "directories, by design.")
    if extra_satellites:
        satellites.extend(extra_satellites)

    for sat in satellites:
        results[sat] = audit_repo(sat)

    return results


# ---------------------------------------------------------------------------
# CLI entry point (called from cli.py dispatch)
# ---------------------------------------------------------------------------

def _staged_main(root: Path, gate: bool) -> int:
    """The `--staged` mode: report (and with `--gate` block on) exemptions this commit adds untagged."""
    import sys

    added = staged_untagged(root)
    for rec in added:
        print(f"  UNTAGGED  {rec.path.relative_to(root)}:{rec.line_number} [{rec.kind}] -- add "
              "`# sunset-reviewed: X.Y -- reason` (on the line ABOVE for .gitignore)")
    print(f"[sunset-audit] staged: {len(added)} exemption(s) added without a sunset tag")
    if added and gate:
        print("[sunset-audit] BLOCKED: tag the exemption(s) this commit adds.", file=sys.stderr)
        return 1
    return 0


def main(argv: list[str] | None = None) -> int:
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        prog="simplecode sunset-audit",
        description="Audit all legalized evasions for sunset-reviewed tags.",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--fleet", action="store_true", help="Scan mother + all satellite repos")
    parser.add_argument("--satellite", type=Path, metavar="PATH",
                        help="Scan a specific satellite repo (may be repeated)", action="append")
    parser.add_argument("--gate", action="store_true",
                        help="Exit 1 if any stale or untagged exemptions are found")
    parser.add_argument("--staged", action="store_true",
                        help="Commit-time check: only exemptions the STAGED diff adds without a tag")
    args = parser.parse_args(argv)
    root = args.root.resolve()

    if args.staged:
        return _staged_main(root, args.gate)

    if args.fleet:
        all_results = run_fleet_audit(root, extra_satellites=args.satellite)
    else:
        version = _project_version(root) or "0.0.0"
        censo = scan_exemptions_census(root)
        # Print the denominator. "0 exemptions" over 282 files and "0" over 0
        # files are the same number and opposite facts.
        print(f"[sunset-audit] scanned {censo.walked} file(s) under {root}")
        # And print what was NOT read, including the zero. A report that only
        # names what it looked at cannot be told apart from one that looked
        # at almost nothing.
        print(f"[sunset-audit] not scanned, git ignores them: "
              f"{censo.skipped_ignored} entry/entries (a pruned tree counts once)")
        print(f"[sunset-audit] not scanned, vendored per corpus_exempt.yaml: "
              f"{censo.skipped_vendored} entry/entries (tracked, but not this repo's to edit)")
        print(f"[sunset-audit] could not be read (dangling symlinks and the like): "
              f"{censo.unreadable} file(s)")
        if censo.prune_unavailable is not None:
            print("[sunset-audit] COULD_NOT_RUN: the git-ignored trees were NOT pruned "
                  f"({censo.prune_unavailable}); everything under {root} was scanned, "
                  "so findings may belong to material this repo does not author.")
        single = check_stale(censo.records, version)
        all_results = {root: single}
        for sat_path in args.satellite or []:
            sat_root = sat_path.resolve()
            all_results[sat_root] = audit_repo(sat_root)

    overall_pass = True
    for repo_root, result in all_results.items():
        print(f"\n=== {repo_root.name} ===")
        result.print_report()
        if not result.passed:
            overall_pass = False

    if len(all_results) > 1:
        print()
        for linea in fleet_summary_lines(all_results):
            print(linea)

    if not overall_pass and args.gate:
        print("\n[sunset-audit] BLOCKED — fix all stale/untagged exemptions before push.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
