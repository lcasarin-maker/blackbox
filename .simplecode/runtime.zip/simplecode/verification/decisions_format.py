#!/usr/bin/env python3
"""`DECISIONS.md` entries carry the decision, the reason, and what it rules out.

The three parts are not ceremony. "What this rules out" is the one that pays:
without it the rejected alternatives are invisible, and the next session
re-proposes them blind -- which is how the same option gets argued twice with
nobody able to say why it was dropped the first time. `DECISIONS.md` already had
this shape in practice (see the 2026-09-01 and 2026-09-02 entries); this module
is the first thing that CHECKS it.

Scope: process and product decisions about how this repo operates. Tool
architecture keeps its own, heavier mechanism in `docs/adr/` and is not governed
here.

Retroactivity follows the GS2-214 cut-off doctrine (`DECISIONS.md` 2026-09-01,
`backlog_verifier.load_contract_cutoff`): entries written before the contract
existed are a NAMED, COUNTED legacy cohort, never silently passed and never
retroactively convicted. Rewriting them would mean inventing reasons nobody held
at the time -- text shaped like a rationale, which is worse than an admitted gap.

Three cohorts, printed with their zeros on every run:
  governed   -- dated on or after the cut-off; the three markers are required.
  legacy     -- dated before it; counted, named, not evaluated for shape.
  undatable  -- a `## ` heading this parser cannot read a date out of; folded
                into neither side, because "no date = legacy" whitewashes and
                "no date = governed" convicts whoever wrote a section header.

Declared limit, not a gap discovered later: the date comes from the heading the
author wrote. Unlike a task file, a decision entry has no git add-date worth
trusting -- entries are appended to ONE file, so `git log --diff-filter=A` dates
every entry to the day `DECISIONS.md` was created. A backdated heading therefore
escapes the gate. The heading date is the entry's identity and is read by people;
nothing here verifies it against history.

Usage:
    python -m simplecode.verification.decisions_format --root . --gate
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from datetime import date
from pathlib import Path
from typing import NamedTuple

DECISIONS_RELPATH = Path("DECISIONS.md")
CUTOFF_CONFIG_RELPATH = Path(".simplecode") / "decisions_format_cutoff.json"

COHORT_GOVERNED = "governed"
COHORT_LEGACY = "legacy"
COHORT_UNDATABLE = "undatable"

# `## 2026-09-09 — Two task states and an explicitly updated kit`. All 24 entries
# present when this landed use the em dash; the en dash and the plain hyphen are
# accepted too, so that typing the wrong dash downgrades nothing -- an entry that
# fell into `undatable` for a dash would be an escape hatch, not a typo.
_DATED_HEADING_RE = re.compile(r"^##\s+(\d{4}-\d{2}-\d{2})\s*[—–-]\s*(.*?)\s*$")
_BOLD_LEAD_RE = re.compile(r"^\*\*(.+?)\*\*")

# Each required part, and the accent-folded lead-ins that count as writing it.
# Both halves come from entries already in the file, not from a style guess:
# English (`**Decision.**`, `**Why.**`, `**What this rules out.**`) and Spanish
# (`**Decisión.**`, `**Por qué.**`, `**Qué descarta.**`), the language the last
# five entries before this gate were written in. Accent folding also collapses
# `Que descarta` into `Qué descarta`, so a missing accent is not a violation.
#
# The match is a PREFIX of the bold lead-in, because real entries qualify it:
# `**Decision approved by the owner.**`, `**Why the bypass was the only path.**`,
# `**What this rules out, and the cost carried.**` are all the part they name.
_REQUIRED_PARTS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Decision.", ("decision",)),
    ("Why.", ("why", "por que")),
    ("What this rules out.", ("what this rules out", "que descarta")),
)


class EntryVerdict(NamedTuple):
    """One `## ` entry of `DECISIONS.md`, its cohort, and what it is missing.

    `missing` is only populated for governed entries: a legacy entry's shape is
    not evaluated, so an empty list there means "not looked at", never "clean".
    """

    label: str
    entry_date: date | None
    cohort: str
    missing: list[str]


class FormatAudit(NamedTuple):
    """The audit, with what it did NOT evaluate beside what it did.

    `could_not_run` exists so a report cannot come back clean over a subject the
    gate never read. A count of zero violations means nothing until the cohort
    counts and this list are read next to it.
    """

    entries: list[EntryVerdict]
    cohorts: dict[str, int]
    cutoff_note: str
    could_not_run: list[str]

    @property
    def breaches(self) -> list[EntryVerdict]:
        return [e for e in self.entries if e.cohort == COHORT_GOVERNED and e.missing]


def load_decisions_cutoff(root: Path) -> tuple[date | None, str]:
    """The declared cut-off date and a note describing it.

    ABSENT MEANS NO CUT-OFF: every entry is governed, which is the strictest
    reading and the same default `backlog_verifier.load_contract_cutoff` takes.
    A malformed declaration also falls back to no cut-off -- fail closed -- and
    says so with a COULD_NOT_RUN the caller must surface rather than absorb.
    """
    cfg = root / CUTOFF_CONFIG_RELPATH
    if not cfg.is_file():
        return None, f"no {CUTOFF_CONFIG_RELPATH.as_posix()} declared: every entry is governed"
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
        parsed = date.fromisoformat(str(data["cutoff"]))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return None, (
            f"COULD_NOT_RUN: {CUTOFF_CONFIG_RELPATH.as_posix()} is unreadable or malformed "
            f"({exc}); falling back to NO cut-off, every entry governed"
        )
    reason = str(data.get("reason", "")).strip() if isinstance(data, dict) else ""
    note = f"cut-off {parsed.isoformat()}"
    return parsed, f"{note} -- {reason}" if reason else note


def _fold(text: str) -> str:
    """Lowercase and strip accents, so `Qué descarta` and `Que descarta` match."""
    decomposed = unicodedata.normalize("NFKD", text.casefold())
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch))


def split_entries(text: str) -> list[tuple[str, list[str]]]:
    """Each `## ` heading and its body lines, fenced blocks excluded.

    A ```` ``` ```` block can legitimately contain a line starting with `## `
    (a shell comment, a quoted markdown sample). Counting one as an entry would
    invent a decision with no author.
    """
    entries: list[tuple[str, list[str]]] = []
    in_fence = False
    for raw in text.splitlines():
        if raw.lstrip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if raw.startswith("## ") and not raw.startswith("###"):
            entries.append((raw, []))
        elif entries:
            entries[-1][1].append(raw)
    return entries


def _missing_parts(body: list[str]) -> list[str]:
    """Which of the three required parts this body does not carry."""
    leads = []
    for line in body:
        match = _BOLD_LEAD_RE.match(line.strip())
        if match:
            leads.append(_fold(match.group(1)))
    return [
        canonical
        for canonical, accepted in _REQUIRED_PARTS
        if not any(lead.startswith(prefix) for lead in leads for prefix in accepted)
    ]


def _entry_cohort(entry_date: date | None, cutoff: date | None) -> str:
    if entry_date is None:
        return COHORT_UNDATABLE
    if cutoff is None:
        return COHORT_GOVERNED
    return COHORT_LEGACY if entry_date < cutoff else COHORT_GOVERNED


def audit_decisions(root: Path) -> FormatAudit:
    """Audit every `DECISIONS.md` entry against the three-part contract."""
    cutoff, cutoff_note = load_decisions_cutoff(root)
    could_not_run = [cutoff_note] if cutoff_note.startswith("COULD_NOT_RUN") else []

    path = root / DECISIONS_RELPATH
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        could_not_run.append(
            f"COULD_NOT_RUN: {DECISIONS_RELPATH.as_posix()} exists but could not be read ({exc})"
        )
        text = ""

    entries: list[EntryVerdict] = []
    for heading, body in split_entries(text):
        match = _DATED_HEADING_RE.match(heading)
        entry_date: date | None = None
        if match:
            try:
                entry_date = date.fromisoformat(match.group(1))
            except ValueError:
                entry_date = None
        title = match.group(2) if match else heading[3:].strip()
        label = f"{entry_date.isoformat()} — {title}" if entry_date else f"(undated) {title}"
        cohort = _entry_cohort(entry_date, cutoff)
        missing = _missing_parts(body) if cohort == COHORT_GOVERNED else []
        entries.append(EntryVerdict(label, entry_date, cohort, missing))

    cohorts = {
        COHORT_GOVERNED: sum(1 for e in entries if e.cohort == COHORT_GOVERNED),
        COHORT_LEGACY: sum(1 for e in entries if e.cohort == COHORT_LEGACY),
        COHORT_UNDATABLE: sum(1 for e in entries if e.cohort == COHORT_UNDATABLE),
    }
    return FormatAudit(entries, cohorts, cutoff_note, could_not_run)


def _report(audit: FormatAudit) -> None:
    print(f"[decisions-format] {audit.cutoff_note}")
    print(
        f"[decisions-format] entries={len(audit.entries)} "
        f"governed={audit.cohorts[COHORT_GOVERNED]} "
        f"legacy={audit.cohorts[COHORT_LEGACY]} "
        f"undatable={audit.cohorts[COHORT_UNDATABLE]} "
        f"violations={len(audit.breaches)} "
        f"could_not_run={len(audit.could_not_run)}"
    )
    for entry in audit.entries:
        if entry.cohort == COHORT_LEGACY:
            print(f"  LEGACY (shape NOT evaluated) {entry.label}")
    for entry in audit.entries:
        if entry.cohort == COHORT_UNDATABLE:
            print(f"  UNDATABLE (no date in the heading, shape NOT evaluated) {entry.label}")
    for entry in audit.breaches:
        print(f"  MISSING {', '.join(entry.missing)} -- {entry.label}")
    for note in audit.could_not_run:
        print(f"  {note}", file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="DECISIONS.md three-part entry contract")
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--gate", action="store_true", help="Exit 1 on any governed-entry violation")
    args = ap.parse_args(argv)
    root: Path = args.root

    if not (root / DECISIONS_RELPATH).is_file():
        print(f"[decisions-format] NO APLICA: this repo has no {DECISIONS_RELPATH.as_posix()}")
        return 0

    audit = audit_decisions(root)
    _report(audit)

    if not audit.entries and not audit.could_not_run:
        # A DECISIONS.md that exists and yields zero entries is the instrument
        # pointing at nothing, not a repo with nothing to check.
        print(
            f"[decisions-format] COULD_NOT_RUN: {DECISIONS_RELPATH.as_posix()} parsed to ZERO "
            f"entries; no `## <date> — <title>` heading was found, so nothing was audited",
            file=sys.stderr,
        )
        return 1 if args.gate else 0

    if not args.gate:
        return 0
    if audit.could_not_run:
        print(
            f"[decisions-format] COULD_NOT_RUN: {len(audit.could_not_run)} part(s) of this "
            f"check did not run; a report with could_not_run > 0 is not a clean report",
            file=sys.stderr,
        )
        return 1
    if audit.breaches:
        print(
            f"[decisions-format] FAIL: {len(audit.breaches)} governed entry/entries miss a "
            f"required part. An entry without `What this rules out.` lets the rejected "
            f"alternative come back as a fresh proposal.",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
