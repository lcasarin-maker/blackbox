#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""vendor_snapshot.py -- integrity gate for locally vendored (fork&own) source.

`upstream_watch` (ADR-0009) answers "has the upstream moved on since we last
reviewed it?" by comparing a manifest's recorded ref against upstream HEAD. It
never asks the narrower, more mechanical question this module answers: does
the vendored copy SITTING IN THIS REPO still match what its own manifest says
it should be? A snapshot can drift from its manifest with zero network
involved -- a hand-edit, a partial `cp`, a merge that silently dropped a file
-- and upstream_watch's "how far has upstream gone" measurement is blind to
that: it never re-hashes the local files.

Found live (fleet_deep_dive/vendor_snapshot_integrity_gap, 2026-09-10): a
satellite vendors a subset of another repo's source tree, declares a
hash+inventory manifest for it, keeps more than one copy of that subset in
different places, and had NOTHING checking that either copy still matched its
own declared manifest -- only that upstream had moved (which it had, on the
engine the vendored subset covers). Deliberately generic: no repo, product,
path, or organ name is written into this file. Every location, hash, and
upstream identity is manifest-driven; the manifest's SHAPE is documented below
and by `tests/test_vendor_snapshot.py`'s fixtures.

Manifest format (JSON), one file named `VENDOR_SNAPSHOT.json` per vendored
copy, normally sitting at the root of the copy it describes::

    {
      "root": "optional/path/relative/to/repo/root",
      "upstream": {"repo": "owner/name", "ref": "<sha the snapshot was cut at>"},
      "files": {"relative/path/inside/root.py": "<sha256 hex>", ...}
    }

`root` is optional; when absent the manifest's own parent directory is the
vendored root (the common case: the manifest lives inside the copy it
describes). `upstream` is optional; when present and `repo` is a GitHub
`owner/name` slug, freshness is checked via `gh api` the same way
`upstream_watch` does, but this check's PASS/FAIL never depends on it -- see
`check_freshness`. `files` is the hash+inventory contract: every path in it
must exist on disk at the declared hash, and no undeclared file may exist
under `root` (module noise directories excepted).

Three real outcomes, matching the kit's EXPECT-contract vocabulary
(`backlog_verifier`'s ADR-0005 M1 PASS/REPRODUCES/COULD_NOT_RUN, `gh`-facing
modules' COULD_NOT_RUN convention in `upstream_watch`/`prek_vendor`):

  PASS           -- every manifest's hash+inventory check is clean, and any
                    copy-parity comparison agrees.
  FAIL           -- a hash mismatch, a missing declared file, an extra
                    undeclared file, or a cross-copy divergence was found.
                    This NEVER downgrades to COULD_NOT_RUN just because the
                    network check also failed -- a corrupted local file is a
                    real defect whether or not upstream was reachable.
  COULD_NOT_RUN  -- hash+inventory is clean everywhere, but at least one
                    manifest declared an upstream to watch and it could not be
                    reached (no `gh`, unauthenticated, offline, rate-limited).
                    Reported as its own status, never silently folded into
                    PASS: an unreachable upstream means "unknown", not "current".

Uso:
    python -m simplecode.verification.vendor_snapshot --root .
    python -m simplecode.verification.vendor_snapshot --root . --gate
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import NamedTuple

from simplecode.utils.tool_limits import NETWORK_TIMEOUT

MANIFEST_FILENAME = "VENDOR_SNAPSHOT.json"

# Directories whose contents are never part of a vendored inventory, on either
# side of the comparison: build/runtime noise, never a file anyone declared or
# would want flagged as "extra".
_NOISE_DIRS = frozenset({".git", "__pycache__", "node_modules", ".venv", "venv", ".mypy_cache", ".pytest_cache"})

STATUS_SUCCESS = "PASS"
# Preserve the public verdict name for existing consumers.
STATUS_PASS = STATUS_SUCCESS
STATUS_FAIL = "FAIL"
STATUS_COULD_NOT_RUN = "COULD_NOT_RUN"

FRESH_NOT_CONFIGURED = "NOT_CONFIGURED"
FRESH_UP_TO_DATE = "UP_TO_DATE"
FRESH_MOVED = "MOVED"
FRESH_COULD_NOT_RUN = "COULD_NOT_RUN"


class Manifest(NamedTuple):
    """One parsed `VENDOR_SNAPSHOT.json`, resolved against the repo root."""

    manifest_path: Path
    root: Path  # absolute
    upstream: dict | None
    files: dict[str, str]  # relpath (posix, inside root) -> declared sha256


class InventoryResult(NamedTuple):
    manifest_path: Path
    mismatches: list[str]
    missing: list[str]
    extra: list[str]

    @property
    def ok(self) -> bool:
        return not (self.mismatches or self.missing or self.extra)


class ParityIssue(NamedTuple):
    group: str
    relpath: str
    detail: str


class FreshnessResult(NamedTuple):
    manifest_path: Path
    status: str
    detail: str


class VendorSnapshotReport(NamedTuple):
    manifests: list[Manifest]
    load_errors: list[str]
    inventories: list[InventoryResult]
    parity_issues: list[ParityIssue]
    freshness: list[FreshnessResult]
    status: str


def discover_manifests(root: Path) -> list[Path]:
    """Every `VENDOR_SNAPSHOT.json` under `root`, noise directories excluded."""
    found = []
    for path in root.rglob(MANIFEST_FILENAME):
        if any(part in _NOISE_DIRS for part in path.relative_to(root).parts):
            continue
        found.append(path)
    return sorted(found)


def _sha256_of(path: Path) -> str | None:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        return None


def load_manifest(root: Path, manifest_path: Path) -> tuple[Manifest | None, str | None]:
    """Parse one manifest file. Returns (manifest, None) or (None, error message)."""
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        return None, f"{manifest_path}: unreadable or invalid JSON ({exc})"
    if not isinstance(data, dict):
        return None, f"{manifest_path}: manifest is not a JSON object"
    files = data.get("files")
    if not isinstance(files, dict) or not files:
        return None, f"{manifest_path}: manifest declares no non-empty 'files' mapping"
    if not all(isinstance(k, str) and isinstance(v, str) and v for k, v in files.items()):
        return None, f"{manifest_path}: 'files' must map relative paths to non-empty hash strings"
    declared_root = data.get("root")
    if declared_root is not None and not isinstance(declared_root, str):
        return None, f"{manifest_path}: 'root' must be a string when present"
    vendor_root = (root / declared_root).resolve() if declared_root else manifest_path.parent
    upstream = data.get("upstream")
    if upstream is not None and not isinstance(upstream, dict):
        return None, f"{manifest_path}: 'upstream' must be an object when present"
    return Manifest(manifest_path, vendor_root, upstream, dict(files)), None


def check_inventory(manifest: Manifest) -> InventoryResult:
    """Hash+inventory check for one manifest: mismatches, missing, extra files."""
    mismatches: list[str] = []
    missing: list[str] = []
    for relpath, expected in sorted(manifest.files.items()):
        on_disk = manifest.root / relpath
        if not on_disk.is_file():
            missing.append(relpath)
            continue
        actual = _sha256_of(on_disk)
        if actual != expected:
            mismatches.append(relpath)

    declared = set(manifest.files)
    present: set[str] = set()
    if manifest.root.is_dir():
        for path in manifest.root.rglob("*"):
            if not path.is_file() or path == manifest.manifest_path:
                continue
            rel = path.relative_to(manifest.root)
            if any(part in _NOISE_DIRS for part in rel.parts):
                continue
            present.add(rel.as_posix())
    extra = sorted(present - declared)
    return InventoryResult(manifest.manifest_path, mismatches, missing, extra)


def _upstream_group_key(manifest: Manifest) -> str | None:
    """Identity used to group copies of the SAME upstream subset. None means
    the manifest declares no upstream identity, so it joins no parity group --
    a manifest with no way to name what it is a copy OF cannot be compared."""
    if not manifest.upstream:
        return None
    repo = str(manifest.upstream.get("repo") or "").strip()
    if not repo:
        return None
    subset = str(manifest.upstream.get("subset") or "").strip()
    return f"{repo}::{subset}" if subset else repo


def _parity_groups(manifests: list[Manifest]) -> dict[str, list[Manifest]]:
    """Manifests bucketed by upstream identity, keeping only the buckets that
    can actually be compared. A group of one has nothing to disagree with, and
    a manifest with no upstream identity joins no group at all -- both are
    dropped HERE rather than re-checked at every use, so a caller iterating
    the result never has to remember that `len(group) < 2` means "not a
    finding" instead of "a group with one problem"."""
    groups: dict[str, list[Manifest]] = {}
    for m in manifests:
        key = _upstream_group_key(m)
        if key is not None:
            groups.setdefault(key, []).append(m)
    return {key: group for key, group in groups.items() if len(group) > 1}


def _files_by_relpath(group: list[Manifest]) -> dict[str, list[tuple[Manifest, str]]]:
    """Every (manifest, sha) that declares each relpath anywhere in the group."""
    by_relpath: dict[str, list[tuple[Manifest, str]]] = {}
    for m in group:
        for relpath, sha in m.files.items():
            by_relpath.setdefault(relpath, []).append((m, sha))
    return by_relpath


def _undeclared_file_issues(
    key: str, group: list[Manifest], by_relpath: dict[str, list[tuple[Manifest, str]]],
) -> list[ParityIssue]:
    """One issue per (manifest, relpath) that a SIBLING copy declares and this
    one does not. A hole in an inventory, which is a different defect from two
    inventories that both list a file and disagree about its bytes -- see
    `_hash_conflict_issues` for that one. Kept apart because conflating them
    was how a missing file could read as "hashes agree"."""
    all_relpaths = set(by_relpath)
    return [
        ParityIssue(
            key, relpath,
            f"declared in {_shorten(by_relpath[relpath][0][0].manifest_path)} but "
            f"absent from {_shorten(m.manifest_path)}'s manifest",
        )
        for m in group
        for relpath in sorted(all_relpaths - set(m.files))
    ]


def _hash_conflict_issues(
    key: str, by_relpath: dict[str, list[tuple[Manifest, str]]],
) -> list[ParityIssue]:
    """One issue per relpath whose copies do not agree on a single sha."""
    issues: list[ParityIssue] = []
    for relpath, entries in sorted(by_relpath.items()):
        shas = {sha for _m, sha in entries}
        if len(shas) > 1:
            detail = ", ".join(f"{_shorten(m.manifest_path)}={sha[:12]}" for m, sha in entries)
            issues.append(ParityIssue(key, relpath, f"copies disagree on hash: {detail}"))
    return issues


def check_parity(manifests: list[Manifest]) -> list[ParityIssue]:
    """Cross-copy agreement for every group of >1 manifest sharing an upstream identity."""
    issues: list[ParityIssue] = []
    for key, group in _parity_groups(manifests).items():
        by_relpath = _files_by_relpath(group)
        issues.extend(_undeclared_file_issues(key, group, by_relpath))
        issues.extend(_hash_conflict_issues(key, by_relpath))
    return issues


def _shorten(path: Path) -> str:
    return path.as_posix()


def _run_gh(args: list[str]) -> subprocess.CompletedProcess[str] | None:
    """One `gh api` call; None means the instrument itself is unavailable.

    Deliberately not shared with `upstream_watch._run_gh`: that helper reads
    ITS OWN fork&own manifest shape (`{repo, ref, licencia}` rows in a
    fleet-wide registry); this one reads a single vendor snapshot's inline
    `upstream` object. Importing an underscore-prefixed helper across that
    boundary would couple two independently-shaped manifests for a handful of
    duplicated lines.
    """
    try:
        return subprocess.run(
            ["gh", "api", *args],
            capture_output=True, text=True, timeout=NETWORK_TIMEOUT, check=False,
        )
    except (subprocess.SubprocessError, OSError):
        return None


def check_freshness(manifest: Manifest) -> FreshnessResult:
    """Has upstream moved past this manifest's recorded ref? Never a proxy for
    the hash/inventory check -- see the module docstring's PASS/FAIL/COULD_NOT_RUN
    table. A manifest with no `upstream.repo`/`ref` is NOT_CONFIGURED, not a
    failure of any kind: freshness watching is optional per manifest."""
    upstream = manifest.upstream or {}
    repo = str(upstream.get("repo") or "").strip()
    ref = str(upstream.get("ref") or "").strip()
    if not repo or not ref:
        return FreshnessResult(manifest.manifest_path, FRESH_NOT_CONFIGURED,
                               "no upstream.repo/ref declared -- freshness not watched")
    if "/" not in repo:
        return FreshnessResult(manifest.manifest_path, FRESH_NOT_CONFIGURED,
                               f"upstream.repo {repo!r} is not an owner/name slug -- freshness not watched")
    head = _run_gh([f"repos/{repo}/commits/HEAD", "--jq", ".sha"])
    if head is None:
        return FreshnessResult(manifest.manifest_path, FRESH_COULD_NOT_RUN, "gh unavailable")
    if head.returncode != 0 or not head.stdout.strip():
        stderr = head.stderr.strip()[:160]
        return FreshnessResult(manifest.manifest_path, FRESH_COULD_NOT_RUN,
                               f"upstream not reached: {stderr or 'gh api failed'}")
    observed = head.stdout.strip()
    if observed == ref:
        return FreshnessResult(manifest.manifest_path, FRESH_UP_TO_DATE, f"upstream still at {ref[:12]}")
    return FreshnessResult(manifest.manifest_path, FRESH_MOVED,
                           f"upstream advanced from {ref[:12]} to {observed[:12]}")


def run(root: Path, *, check_upstream: bool = True) -> VendorSnapshotReport:
    """Run every check across every manifest found under `root`.

    `check_upstream=False` skips the network path entirely (used by tests that
    only exercise the local hash/inventory contract) -- a skipped check is
    NOT_CONFIGURED-shaped, never reported as if it had run and passed.
    """
    manifest_paths = discover_manifests(root)
    manifests: list[Manifest] = []
    load_errors: list[str] = []
    for path in manifest_paths:
        parsed, error = load_manifest(root, path)
        if parsed is None:
            load_errors.append(error or f"{path}: failed to load")
        else:
            manifests.append(parsed)

    inventories = [check_inventory(m) for m in manifests]
    parity_issues = check_parity(manifests)
    freshness = [check_freshness(m) for m in manifests] if check_upstream else []

    hash_clean = load_errors == [] and all(inv.ok for inv in inventories) and not parity_issues
    unreachable = any(f.status == FRESH_COULD_NOT_RUN for f in freshness)

    if not hash_clean:
        status = STATUS_FAIL
    elif unreachable:
        status = STATUS_COULD_NOT_RUN
    else:
        status = STATUS_SUCCESS

    return VendorSnapshotReport(manifests, load_errors, inventories, parity_issues, freshness, status)


def _report(report: VendorSnapshotReport) -> None:
    print(f"[vendor-snapshot] manifests={len(report.manifests)} load_errors={len(report.load_errors)} "
          f"parity_issues={len(report.parity_issues)}")
    for err in report.load_errors:
        print(f"  LOAD_ERROR {err}", file=sys.stderr)
    for inv in report.inventories:
        for relpath in inv.mismatches:
            print(f"  HASH_MISMATCH {relpath} ({_shorten(inv.manifest_path)})")
        for relpath in inv.missing:
            print(f"  MISSING_FILE {relpath} ({_shorten(inv.manifest_path)})")
        for relpath in inv.extra:
            print(f"  EXTRA_FILE {relpath} ({_shorten(inv.manifest_path)})")
    for issue in report.parity_issues:
        print(f"  PARITY_DIVERGENCE [{issue.group}] {issue.relpath}: {issue.detail}")
    for fr in report.freshness:
        line = f"  UPSTREAM[{_shorten(fr.manifest_path)}] {fr.status} -- {fr.detail}"
        if fr.status == FRESH_COULD_NOT_RUN:
            print(line, file=sys.stderr)
        else:
            print(line)
    print(f"[vendor-snapshot] {report.status}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--gate", action="store_true",
                    help="Exit with the real status (0 pass / 1 fail / 2 could_not_run) "
                         "instead of always exiting 0")
    ap.add_argument("--no-upstream", action="store_true",
                    help="Skip the network freshness check entirely (offline runs, tests)")
    args = ap.parse_args(argv)
    root: Path = args.root.resolve()

    if not discover_manifests(root):
        print(f"[vendor-snapshot] NO APLICA: no {MANIFEST_FILENAME} found under {root}")
        return 0

    report = run(root, check_upstream=not args.no_upstream)
    _report(report)

    if not args.gate:
        return 0
    return {STATUS_SUCCESS: 0, STATUS_FAIL: 1, STATUS_COULD_NOT_RUN: 2}[report.status]


if __name__ == "__main__":
    raise SystemExit(main())
