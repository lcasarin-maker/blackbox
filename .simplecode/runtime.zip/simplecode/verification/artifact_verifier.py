# -*- coding: utf-8 -*-
"""artifact_verifier.py -- Proves the SHIPPED artifact actually works.

Replaces two retired organs with one end-to-end check:

* hallucinated_check.py used a hand-maintained distribution-name -> import-name
  map and ran ``importlib.import_module`` on every declared dependency inside
  the DEV environment -- both a maintenance burden (six special cases and
  counting) and a side effect on the wrong environment.
* dist_verifier.py extracted and smoke-tested a raw ``.zip`` of the repo. The
  product abandoned that format on 2026-08-24 in favor of wheel/sdist (see the
  ``build-dist`` hook in .pre-commit-config.yaml, which already builds both
  and has verified neither since).

This module builds the real wheel and sdist, installs EACH into its own fresh
virtual environment with the normal resolver, runs ``pip check``, imports the
package, confirms its bundled ``catalog.yaml`` is present, and runs the public
CLI entry point. An undeclared or hallucinated dependency, a broken
distribution, or a wiring mistake in ``[project.scripts]`` fails HERE, on the
artifact that actually ships -- never via a manually maintained name map.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import tomllib
import venv
from pathlib import Path

from simplecode.utils.tool_limits import ARTIFACT_BUILD_TIMEOUT, ARTIFACT_INSTALL_TIMEOUT

# Measured live on this repo's own wheel (2026-08-31): venv.EnvBuilder + pip
# took 2.75s to create the venv and install; `uv venv` + `uv pip install`
# took 0.83s for the identical result -- 3.3x, same installed package, same
# pip-check/import/CLI smoke tests run after either path. Opportunistic, not
# required: a satellite without `uv` on PATH gets the same correctness via
# the slower stdlib path, never a COULD_NOT_RUN for lacking a tool this
# check doesn't strictly need.
_UV = shutil.which("uv")

_SMOKE_IMPORT_SNIPPET = (
    "import sys\n"
    "from pathlib import Path\n"
    "import simplecode\n"
    "from importlib.resources import files\n"
    "assert Path(simplecode.__file__).resolve().is_relative_to(Path(sys.prefix).resolve()), "
    "f'loaded outside artifact venv: {simplecode.__file__}'\n"
    "p = files('simplecode.rules').joinpath('catalog.yaml')\n"
    "assert p.is_file(), 'catalog.yaml missing from installed package'\n"
)

_NETWORK_FAILURE_MARKERS = (
    "dns error",
    "failed to lookup address information",
    "temporary failure in name resolution",
    "failed to connect",
    "connection refused",
    "connection reset",
    "network is unreachable",
    "connection timed out",
    "connect timeout",
    "connecttimeout",
    "read timeout",
    "readtimeout",
)


def _network_unavailable(detail: str) -> bool:
    """Whether an install-phase resolver failure means the artifact was unmeasured."""
    lowered = detail.lower()
    if "install failed" not in lowered:
        return False
    return any(marker in lowered for marker in _NETWORK_FAILURE_MARKERS)


ISOLATION = "built from a private copy of the build inputs, never inside the source folder"


def _copy_build_inputs(root: Path, dest: Path) -> None:
    """Copy only what `python -m build` reads: pyproject.toml, the files it names, the package
    dirs and the `tests/test*.py` setuptools adds to every sdist.

    Copying the whole checkout read a LIVE tree. Any `python -m build` whose cwd is
    that checkout makes setuptools create and then delete `simplecode-<version>/`
    there, and copytree died on it: "[Errno 2] No such file or directory:
    '<root>/simplecode-9.6.1'" (DEBT-REMEDIATION-ARTIFACT-VERDICT; under a concurrent
    sdist build loop in the same root, 8 of 88 runs failed before this change, 0 of 100 after).
    """
    # ponytail: copies only the setuptools layout this repo uses (a str readme,
    # license-files, [tool.setuptools.packages.find] where); any other layout fails
    # the copy and the verifier says COULD_NOT_RUN, never a verdict.
    # trigger: a satellite runs the verifier and gets "could not copy the build inputs".
    pyproject = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    project = pyproject["project"]
    dest.mkdir()
    for name in ["pyproject.toml", project["readme"], *project["license-files"]]:
        shutil.copy2(root / name, dest / name)
    for package_dir in pyproject["tool"]["setuptools"]["packages"]["find"]["where"]:
        shutil.copytree(
            root / package_dir,
            dest / package_dir,
            ignore=shutil.ignore_patterns("*.egg-info", "__pycache__"),
        )
    # setuptools' sdist also ships `tests/test*.py` by default; without them the sdist
    # built from the copy lost 216 test files (373 members in place, 156 from the copy,
    # measured 2026-10-07) while the wheel stayed identical.
    for test_file in sorted(root.glob("tests/test*.py")):
        (dest / "tests").mkdir(exist_ok=True)
        shutil.copy2(test_file, dest / "tests" / test_file.name)


def build_artifacts(root: Path, out_dir: Path) -> tuple[list[Path], str]:
    """Build wheel + sdist from a private copy of ``root``'s build inputs into ``out_dir``.

    setuptools creates and deletes ``<name>-<version>/`` (and writes ``build/`` and
    ``*.egg-info``) in the folder it builds in, so two builds sharing ``root`` killed
    each other with ``[Errno 2] No such file or directory``
    (DEBT-ARTIFACT-VERIFIER-CONCURRENT-BUILDS-20261006). Each build gets its own copy,
    which is removed when the build ends, and ``root`` is never written.

    Returns ``(artifact_paths, error)``; ``error`` is empty on success.
    """
    build_python = _venv_bin(root / ".venv", "python")
    if not build_python.is_file():
        build_python = _venv_bin(Path.cwd() / ".venv", "python")
    interpreter = build_python if build_python.is_file() else Path(sys.executable)
    with tempfile.TemporaryDirectory(prefix="simplecode_build_inputs_") as private:
        source = Path(private) / "project"
        try:
            _copy_build_inputs(root, source)
        except (OSError, KeyError, TypeError, tomllib.TOMLDecodeError) as exc:
            return [], f"build failed: could not copy the build inputs of {root}: {exc!r}"
        result = subprocess.run(
            # Build isolation downloads the declared backend even when this checked-in
            # environment already satisfies it. Artifact verification is a local gate;
            # it must remain runnable offline and fail only when its installed backend
            # cannot build the project.
            [str(interpreter), "-m", "build", "--no-isolation", "--outdir", str(out_dir)],
            cwd=source,
            capture_output=True,
            text=True,
            timeout=ARTIFACT_BUILD_TIMEOUT,
            check=False,
        )
    if result.returncode != 0:
        return [], f"build failed:\n{result.stdout}\n{result.stderr}"

    artifacts = sorted(out_dir.glob("*.whl")) + sorted(out_dir.glob("*.tar.gz"))
    if not artifacts:
        return [], "build produced no wheel or sdist"
    return artifacts, ""


def _venv_bin(venv_dir: Path, name: str) -> Path:
    bindir = "Scripts" if sys.platform == "win32" else "bin"
    suffix = ".exe" if sys.platform == "win32" else ""
    return venv_dir / bindir / f"{name}{suffix}"


def _create_and_install_with_uv(uv_path: str, venv_dir: Path, python: Path, artifact: Path) -> str | None:
    """`uv venv` + `uv pip install` + `uv pip check`. Returns an error
    message, or None on success."""
    cache_dir = venv_dir.parent / "uv-cache"
    cache_dir.mkdir()
    env = {**os.environ, "UV_CACHE_DIR": str(cache_dir)}
    create = subprocess.run(
        [uv_path, "venv", "--quiet", str(venv_dir)],
        capture_output=True, text=True, timeout=ARTIFACT_INSTALL_TIMEOUT, check=False, env=env,
    )
    if create.returncode != 0:
        return f"uv venv failed: {create.stdout}\n{create.stderr}"
    install = subprocess.run(
        [uv_path, "pip", "install", "--quiet", "--python", str(python), str(artifact)],
        capture_output=True, text=True, timeout=ARTIFACT_INSTALL_TIMEOUT, check=False, env=env,
    )
    if install.returncode != 0:
        return f"uv pip install failed for {artifact.name}:\n{install.stdout}\n{install.stderr}"
    check = subprocess.run(
        [uv_path, "pip", "check", "--python", str(python)],
        capture_output=True, text=True, timeout=ARTIFACT_INSTALL_TIMEOUT, check=False, env=env,
    )
    if check.returncode != 0:
        return f"uv pip check reported broken requirements for {artifact.name}:\n{check.stdout}\n{check.stderr}"
    return None


def _create_and_install_with_stdlib(venv_dir: Path, artifact: Path) -> str | None:
    """`venv.EnvBuilder` + `pip install` + `pip check`. Returns an error
    message, or None on success."""
    try:
        venv.EnvBuilder(with_pip=True).create(venv_dir)
    except OSError as exc:
        return f"Could not create isolated venv: {exc}"

    pip = _venv_bin(venv_dir, "pip")
    install = subprocess.run(
        [str(pip), "install", "--quiet", str(artifact)],
        capture_output=True, text=True, timeout=ARTIFACT_INSTALL_TIMEOUT, check=False,
    )
    if install.returncode != 0:
        return f"pip install failed for {artifact.name}:\n{install.stdout}\n{install.stderr}"

    check = subprocess.run(
        [str(pip), "check"],
        capture_output=True, text=True, timeout=ARTIFACT_INSTALL_TIMEOUT, check=False,
    )
    if check.returncode != 0:
        return f"pip check reported broken requirements for {artifact.name}:\n{check.stdout}\n{check.stderr}"
    return None


def verify_artifact(artifact: Path) -> tuple[bool, str]:
    """Install ``artifact`` into a fresh venv and prove it actually works."""
    if not artifact.is_file():
        return False, f"Artifact {artifact} not found."

    with tempfile.TemporaryDirectory(prefix="simplecode_artifact_venv_") as tmp:
        venv_dir = Path(tmp) / "venv"
        python = _venv_bin(venv_dir, "python")

        error = (
            _create_and_install_with_uv(_UV, venv_dir, python, artifact)
            if _UV
            else _create_and_install_with_stdlib(venv_dir, artifact)
        )
        if error is not None:
            return False, error

        smoke_cwd = Path(tmp) / "smoke-cwd"
        smoke_cwd.mkdir()
        smoke_env = {
            key: value for key, value in os.environ.items()
            if key not in {"PYTHONPATH", "PYTHONHOME"}
        }
        smoke = subprocess.run(
            [str(python), "-I", "-c", _SMOKE_IMPORT_SNIPPET],
            cwd=smoke_cwd,
            env=smoke_env,
            capture_output=True,
            text=True,
            timeout=ARTIFACT_INSTALL_TIMEOUT,
            check=False,
        )
        if smoke.returncode != 0:
            return False, f"import/catalog smoke test failed for {artifact.name}:\n{smoke.stdout}\n{smoke.stderr}"

        cli = subprocess.run(
            [str(_venv_bin(venv_dir, "simplecode")), "--help"],
            cwd=smoke_cwd,
            env=smoke_env,
            capture_output=True,
            text=True,
            timeout=ARTIFACT_INSTALL_TIMEOUT,
            check=False,
        )
        if cli.returncode != 0:
            return False, f"CLI smoke test failed for {artifact.name}:\n{cli.stdout}\n{cli.stderr}"

    return True, f"{artifact.name} installs cleanly, passes pip check, and its CLI runs."


def _report_build_error(error: str) -> int:
    if error.startswith("build failed:"):
        print(
            f"[build-dist] COULD_NOT_RUN: wheel/sdist build failed: {error.splitlines()[0]}",
            file=sys.stderr,
        )
        return 2
    print(f"[artifact-verifier] FAIL: {error}")
    return 1


def _missing_artifact_formats(artifacts: list[Path]) -> list[str]:
    missing = []
    if not any(artifact.name.endswith(".whl") for artifact in artifacts):
        missing.append("wheel")
    if not any(artifact.name.endswith(".tar.gz") for artifact in artifacts):
        missing.append("sdist")
    return missing


def main(root: str = ".") -> int:
    """Exit 0 when every built artifact installs and passes its smoke test."""
    root_path = Path(root).resolve()
    print(f"[artifact-verifier] isolation: {ISOLATION} ({root_path})")
    with tempfile.TemporaryDirectory(prefix="simplecode_dist_") as build_dir:
        artifacts, err = build_artifacts(root_path, Path(build_dir))
        if err:
            # Build infrastructure failure means no artifact verdict exists;
            # a successful build with incomplete output is a product failure.
            return _report_build_error(err)

        missing_formats = _missing_artifact_formats(artifacts)
        if missing_formats:
            print(
                "[artifact-verifier] FAIL: build output missing required artifact format(s): "
                + ", ".join(missing_formats)
            )
            return 1

        failures = []
        could_not_run = []
        for artifact in artifacts:
            ok, msg = verify_artifact(artifact)
            if ok:
                print(f"[artifact-verifier] OK: {msg}")
            elif _network_unavailable(msg):
                print(f"[artifact-verifier] COULD_NOT_RUN: {msg}")
                could_not_run.append(artifact.name)
            else:
                print(f"[artifact-verifier] FAIL: {msg}")
                failures.append(artifact.name)

    if could_not_run:
        print(
            f"[artifact-verifier] COULD_NOT_RUN: {len(could_not_run)} artifact(s) were not verified; "
            f"first {could_not_run[0]}"
        )

    if failures:
        print(f"[artifact-verifier] FAIL: {len(failures)} artifact(s) failed verification")
        print(
            f"[build-dist] FAIL: {len(failures)} of {len(artifacts)} artifact(s) failed verification; "
            f"first {failures[0]}"
        )
        return 1

    if could_not_run:
        return 2

    print(f"[artifact-verifier] OK: {len(artifacts)} artifact(s) verified (wheel + sdist)")
    return 0


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Build wheel + sdist and verify each installs cleanly")
    parser.add_argument("--root", default=".", help="Project root containing pyproject.toml")
    args = parser.parse_args()
    sys.exit(main(root=args.root))
