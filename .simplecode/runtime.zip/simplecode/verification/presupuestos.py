"""Lector validado de los presupuestos firmados `tasks/presupuesto_*.json`.

Un presupuesto firmado es deuda diferida por escrito: una persona autoriza un
exceso que ningun mecanismo acota, con su nombre y una caducidad. La forma la
fijo blackbox (`tasks/presupuesto_gpu.json`, leida por su
`tools/presupuesto_memoria.py`); este es el lector del kit, no una copia:

  * `owner`   texto no vacio -- una firma sin firmante no la revisa nadie;
  * `expires` fecha ISO -- una sin caducidad se vuelve permanente en silencio;
  * `reason`  texto no vacio -- una firma sin motivo no se puede re-discutir;
  * `excursion_gib`, cuando esta: numero > 0 -- es lo que se autoriza.

Una caducidad pasada NO invalida aqui: el informe la nombra como `EXPIRED`.
Un fichero que no cumple es `PresupuestoInvalido` nombrando el fichero, para que
el llamador lo trate como COULD_NOT_RUN y nunca como 0.
"""
from __future__ import annotations

import json
import math
from datetime import date
from pathlib import Path
from typing import NamedTuple

PATRON = "presupuesto_*.json"


class PresupuestoInvalido(ValueError):
    """Uno o mas presupuestos ilegibles o incompletos; el mensaje los nombra."""


class Presupuesto(NamedTuple):
    fichero: str
    owner: str
    expires: date
    reason: str
    excursion_gib: float | None


def _texto(data: dict, campo: str) -> str:
    valor = data.get(campo)
    if not isinstance(valor, str) or not valor.strip():
        raise PresupuestoInvalido(f"`{campo}` missing or empty")
    return valor


def _fecha(data: dict) -> date:
    texto = _texto(data, "expires")
    try:
        return date.fromisoformat(texto)
    except ValueError as exc:
        raise PresupuestoInvalido(f"`expires` is not an ISO date: {texto!r}") from exc


def _monto(data: dict) -> float | None:
    if "excursion_gib" not in data:
        return None
    valor = data["excursion_gib"]
    if isinstance(valor, bool) or not isinstance(valor, int | float) \
            or not math.isfinite(valor) or valor <= 0:
        raise PresupuestoInvalido(f"`excursion_gib` is not a positive number: {valor!r}")
    return float(valor)


def leer(ruta: Path) -> Presupuesto:
    """Lee y valida un presupuesto. `PresupuestoInvalido` nombra el fichero."""
    try:
        data = json.loads(ruta.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as exc:
        raise PresupuestoInvalido(f"{ruta.name}: unreadable or not valid JSON ({exc})") from exc
    if not isinstance(data, dict):
        raise PresupuestoInvalido(f"{ruta.name}: not a JSON object")
    try:
        return Presupuesto(ruta.name, _texto(data, "owner"), _fecha(data),
                           _texto(data, "reason"), _monto(data))
    except PresupuestoInvalido as exc:
        raise PresupuestoInvalido(f"{ruta.name}: {exc}") from exc


def leer_todos(root: Path) -> list[Presupuesto]:
    """Todos los presupuestos de `root/tasks/`, en orden de nombre. Si alguno no
    valida, `PresupuestoInvalido` con TODOS los rotos nombrados: uno roto no
    esconde a otro, y los validos no se cuentan como si la clase fuera legible."""
    leidos: list[Presupuesto] = []
    errores: list[str] = []
    for ruta in sorted((root / "tasks").glob(PATRON)):
        try:
            leidos.append(leer(ruta))
        except PresupuestoInvalido as exc:
            errores.append(str(exc))
    if errores:
        raise PresupuestoInvalido("; ".join(errores))
    return leidos
