"""Close-check for DEBT-TELEMETRY-DISPOSITION-CASCADE-ROWS-UNDISPOSABLE.

Exits 0 once the 5 named event_ids are all recorded as disposed in the
closed task file itself (`tasks/done/DEBT-TELEMETRY-DISPOSITION-CASCADE-
ROWS-UNDISPOSABLE.md`), which is committed to git.

This used to read `.simplecode/evidence/telemetry_dispositions.jsonl`,
which `.gitignore` declares machine-local state and never tracks -- so the
check could never pass in a fresh clone or worktree, only in the exact
session that produced the ledger (found 2026-09-15 via backlog_verifier
FRAUD DETECTED in a fresh worktree that never had that file at all).
"""
from __future__ import annotations

from pathlib import Path

EVENT_IDS = frozenset({
    "085368f675a8a8c7",
    "6465de300f8ce038",
    "5411b963cdeb80df",
    "df05d84363884738",
    "2ca8ce94be034768",
})

TASK_FILE = Path("tasks/done/DEBT-TELEMETRY-DISPOSITION-CASCADE-ROWS-UNDISPOSABLE.md")


def main() -> int:
    if not TASK_FILE.is_file():
        return 1
    text = TASK_FILE.read_text(encoding="utf-8")
    return 0 if all(event_id in text for event_id in EVENT_IDS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
