#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dangling_refs.py -- unresolved-reference detector.

A named file, ID, documented rule, or doc/code symbol that resolves to
nothing is the mechanical shadow of a hallucinated claim: something in the
tree asserts a link to a thing that isn't there. This module folds four
independent checks for that one failure mode into a single detector:

  1. file_refs    -- a file staged as deleted/renamed is still mentioned by
                      name somewhere else in the tracked tree.
  2. id_refs       -- an ID (PREFIX-NNN, e.g. "CC-32") is cited in source
                      code but no registry document defines it.
  3. rule_drift    -- a "RULE #N" is documented as enforced but no
                      implementing code (or git hook) actually contains it.
  4. doc_parity    -- a code/docs dependency graph shows a critical code
                      symbol with no documentation pointing at it, or a doc
                      node with no outgoing links at all.
  5. citation_lines -- a `file.py:10-20`-style citation (backtick, markdown
                      link, or bare) names a real file but a line range that
                      doesn't exist in it. Folded in from the retired
                      source_verifier.py (PI-011): that module's markdown-LINK
                      existence check (`file.py` exists?) overlapped with
                      check_broken_evidence_pins here, but its LINE-RANGE
                      validation was a distinct capability, preserved. Its
                      inherited regex initially measured 656 false positives
                      on this repo's own docs; tightened (known-extension
                      whitelist, path-separator-or-line-spec requirement,
                      organ-relative path fallback, harvested-history
                      exemption) down to 0 before joining the sweep.

Each detector is independently callable and returns a list of finding
dicts (see `_finding`). `run_all` runs whichever detectors have the inputs
they need and merges the findings; the CLI reports them and exits nonzero
on any FAIL.

Exit 0: OK -- no unresolved references found (or only WARN-level ones).
Exit 1: BLOCKED -- at least one FAIL-severity finding, or a detector could
        not complete its scan safely.

Un rc=0 no dice "el árbol está limpio", dice "los detectores que revisaron su
sujeto no encontraron nada". No es lo mismo, y la diferencia se imprime: cada
detector que no llegó a mirar sale nombrado con su motivo (`NO REVISADO`) antes
del veredicto. Ver `run_all`.
"""

from __future__ import annotations

import ast
import json
import logging
import re
import subprocess
import sys
from pathlib import Path
from typing import NamedTuple

import yaml

from simplecode.utils.tool_limits import GIT_O1_TIMEOUT, GIT_SCAN_TIMEOUT

logger = logging.getLogger("dangling_refs")
logging.basicConfig(level=logging.INFO, format="%(message)s")


def _finding(kind: str, ref: str, origin: str, message: str, severity: str = "FAIL") -> dict:
    """One unresolved-reference finding, in the shape all four detectors emit.

    Args:
        kind: Which detector produced this ("file_refs", "id_refs",
            "rule_drift", "doc_parity").
        ref: The dangling thing itself -- a filename, an id, a rule number,
            a code/doc symbol id.
        origin: Where the reference was found (a file path, or a symbol id
            for graph-based findings).
        message: Human-readable explanation.
        severity: "FAIL" (blocks) or "WARN" (advisory only).
    """
    return {"kind": kind, "ref": ref, "origin": origin, "severity": severity, "message": message}


# ---------------------------------------------------------------------------
# Shared git plumbing (used by file_refs and id_refs)
# ---------------------------------------------------------------------------

def git_root(cwd: Path | None = None) -> Path | None:
    """Repo root, or None when `cwd` isn't inside a git repo."""
    result = _run_git(["rev-parse", "--show-toplevel"], cwd=cwd, timeout=GIT_O1_TIMEOUT)
    if result is None or result.returncode != 0:
        return None
    out = result.stdout.strip()
    return Path(out) if out else None


def _run_git(args: list[str], cwd: Path | None, timeout: float) -> subprocess.CompletedProcess | None:
    """Run a git subcommand, text mode. Returns None on any I/O failure."""
    try:
        return subprocess.run(
            ["git", *args], capture_output=True, text=True, cwd=cwd, timeout=timeout,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.error("[dangling_refs] git %s failed: %s", " ".join(args), exc)
        return None


def tracked_files(root: Path, globs: tuple[str, ...] = ()) -> list[Path]:
    """Git-tracked files under root (optionally filtered by glob), so
    untracked scratch work never feeds a detector.

    Uses `-z` (NUL-separated) so a filename with non-ASCII bytes or a quote
    character comes back raw. Without it, `git ls-files` C-quotes any path
    outside plain ASCII -- `documentación.md` prints as the literal 9-byte
    string `"documentaci\303\263n.md"` (quotes and backslash-escapes
    included), and every caller that opens that string as a path fails with
    ENOENT on a file that exists under its real name. Measured on
    migracion_atom: `documentación Arquitectónica.md`, cited from
    EXORCISMO-2026-08-17.md, reproduced this exactly.
    """
    # Repo-wide enumeration: cost tracks tracked-file count, unmeasurable
    # before the call without making the call itself. GIT_SCAN_TIMEOUT.
    result = _run_git(["ls-files", "-z", *globs], cwd=root, timeout=GIT_SCAN_TIMEOUT)
    if result is None or result.returncode != 0:
        return []
    return [root / p for p in result.stdout.split("\0") if p]


# ---------------------------------------------------------------------------
# Detector 1: file_refs -- deleted/renamed filenames still referenced
# ---------------------------------------------------------------------------

# Append-only history files mention filenames that no longer exist by
# design (that's the point of a log). That's not a real dangling reference.
# `docs/RETIROS.md` entra por la MISMA razón que `tasks/` está en
# `_EXEMPT_PREFIXES`: es un registro, no un inventario vivo. Un acta de retiro
# que no puede nombrar la ruta que el órgano tenía no es un acta. Medido el
# 2026-08-17 al retirar `regression_corpus`: el gate detuvo el commit del acta
# que lo retiraba.
_EXEMPT_FILES = {
    "audit/AUDIT_TRAIL.md", "HANDOFF.md", "docs/RETIROS.md",
    "docs/EVALUACION_INCREMENTAL_FLOTA_2026-09-09.md",
}

# Same idea as _EXEMPT_FILES, but by prefix: each dated backup under
# deprecated/historial_backups/ is an immutable snapshot of a past
# HANDOFF/STATE file.
# `deprecated/` y `archive/` enteros, no sólo historial_backups: un acta de
# purga NOMBRA lo que purgó, y ésa es su función. Medido el 2026-08-17 con
# check_inventory_drift: sus 4 únicos falsos positivos de flota salían de
# red_python/deprecated/audits_legacy/.../phase_0_purge_result.md, un informe de
# junio que lista los archivos que ese mismo informe elimina.
# `tasks/` entra por la MISMA razón que ya lo sacó de `check_rule_drift` el
# 2026-08-17: un archivo de tarea REGISTRA un hallazgo, no DECLARA un inventario
# vivo. El caso que lo obligó: al retirar el aparato de evidencia, sus tres actas
# —DEBT-06, DEBT-07, DEBT-17— citan la ruta que el órgano tenía bajo
# `verification/` cuando corría. Un acta de retiro que no puede nombrar lo que
# retira no es un acta.
#
# Lo que NO se pierde con esto: el caso que dio valor al detector era
# `cuenza/SPEC.md`, un inventario declarado, no una tarea. Barrido de flota tras
# el cambio: NEW 0, LOST 5, y los cinco eran actas citando su propio sujeto.
#
# `docs/decisions/` y `docs/domain_knowledge/` son las dos carpetas de salida
# canónicas de `universal_harvester.py` (ADR-HARVESTED-*.md y LORE-*.md,
# ver universal_harvester.py:7-8): actas de cosecha de OTRO proyecto, muchas
# veces ya archivado y retirado del disco, citando rutas que nunca existieron
# en ESTE repo por diseño. `docs/gate_audit_2026-09-26/` conserva auditorías
# ejecutadas sobre repos/fixtures externos; sus rutas locales son parte de la
# evidencia histórica y no dependencias del Simplecode actual. Esas tres
# superficies quedan fuera del chequeo físico, mientras los documentos activos
# siguen sujetos al control. La exclusión del informe de flota es exacta porque
# evalúa varios repositorios y sus paths pertenecen a esos árboles.
_EXEMPT_PREFIXES = (
    "deprecated/", "archive/", "tasks/", "docs/decisions/",
    "docs/domain_knowledge/", "docs/gate_audit_2026-09-26/",
)

# Tercera vía, y hace falta una tercera porque `_EXEMPT_FILES` es coincidencia
# EXACTA y `_EXEMPT_PREFIXES` es por RUTA: un manifiesto de checksums no se deja
# nombrar por ninguna de las dos -- vive donde cayó el respaldo que lo produjo, y
# mañana cae en otro sitio. Es la misma clase de artefacto que el acta de purga de
# arriba: un manifiesto sha256 NOMBRA los archivos tal como estaban al sellarse, y
# ésa es su función. Editarlo para callar al detector no arregla una referencia:
# falsifica un registro de checksums.
#
# El caso que lo obligó, Atlas 2026-08-18 (DGX-135): al renombrar
# `tools/run_dedup_mutation_queue_gen.py` a `tools/run_dedup_queue_gen_mutation.py`
# el detector dio 2 FAIL. Uno legítimo -- BACKLOG.md citaba la ruta vieja, ya
# corregido -- y el otro sobre
# `logs/backup_to_nas/manifest_projects_delete_v2_20260818.sha256`, que cita la
# ruta vieja 2 veces (verificado con `grep -c`) porque es el sello de un respaldo
# hecho ANTES del renombrado.
#
# Por qué el SUFIJO y no el prefijo `logs/backup_to_nas/`, medido sobre Atlas el
# 2026-08-19: el sufijo exime 6 archivos y los 6 son manifiestos de checksums --
# incluido `logs/librechat_pre_atlas_feedback.sha256`, que vive FUERA de esa
# carpeta y el prefijo habría dejado fuera. Y por qué no `logs/` entero: Atlas
# tiene ahí 91 archivos vivos rastreados que no son manifiestos; un log vivo que
# cita una ruta muerta SÍ es hallazgo. Fuera de Atlas, la flota entera (simplecode,
# cuenza, aequitas_os, red_python, office2office) tiene 0 archivos `.sha256`
# rastreados, así que el radio de esta exención hoy es exactamente esos 6.
_EXEMPT_SUFFIXES = (".sha256",)

_GENERIC_BASENAMES = {
    "readme.md", "index.md", "changelog.md", "license", "__init__.py",
    "conftest.py", "config.py", "main.py", "utils.py",
}


def _is_exempt_history(path: str) -> bool:
    """Whether a file containing a dangling reference is append-only history.

    Example:
        >>> _is_exempt_history("deprecated/historial_backups/HIST_20260617.md")
        True
        >>> _is_exempt_history("logs/backup_to_nas/manifest_20260818.sha256")
        True
        >>> _is_exempt_history("SPEC.md")
        False
    """
    return (path in _EXEMPT_FILES or path.startswith(_EXEMPT_PREFIXES)
            or path.endswith(_EXEMPT_SUFFIXES))


def staged_deleted_files(root: Path) -> list[str] | None:
    """Files staged as deleted (D) or the 'source' side of a rename (R).

    Uses `--name-status -z` so paths with tabs/newlines are parsed safely.
    Returns None when the staged diff cannot be inspected safely.
    """
    # `--name-status` over an already-indexed diff: no file content crosses
    # the pipe, just path/status pairs -- O(1) plumbing, not payload-bound.
    result = _run_git(
        ["diff", "--no-relative", "--cached", "--name-status", "-z", "--diff-filter=DR"],
        cwd=root, timeout=GIT_O1_TIMEOUT,
    )
    if result is None:
        return None
    if result.returncode != 0:
        logger.error("[dangling_refs] git diff returned rc=%s inspecting staged deletions", result.returncode)
        return None

    deleted: list[str] = []
    records = [part for part in result.stdout.split("\0") if part]
    index = 0
    while index < len(records):
        status = records[index]
        if status.startswith("D") and index + 1 < len(records):
            deleted.append(records[index + 1])
            index += 2
            continue
        if status.startswith("R") and index + 2 < len(records):
            deleted.append(records[index + 1])  # rename source path
            index += 3
            continue
        index += 1
    return deleted


def staged_renamed_sources(root: Path) -> set[str]:
    """Rutas de ORIGEN de los renombrados en el índice.

    Un archivo renombrado NO está borrado: sigue existiendo, en otro sitio. La
    distinción no es académica -- `check_file_refs` busca por nombre de archivo,
    así que al mover `evidence_postdates.py` de `verification/` a
    `archive/organos-retirados/` con `git mv`, condenaba TODA mención del
    basename, incluida la de su ruta nueva y correcta. El detector pedía
    arreglar una referencia que ya apuntaba bien, y no había forma de
    satisfacerlo salvo dejar de nombrar el archivo.
    """
    # Same shape as staged_deleted_files above: name-status only, O(1).
    result = _run_git(
        ["diff", "--no-relative", "--cached", "--name-status", "-z", "--diff-filter=R"],
        cwd=root, timeout=GIT_O1_TIMEOUT,
    )
    if result is None or result.returncode != 0:
        return set()
    fuentes: set[str] = set()
    records = [part for part in result.stdout.split("\0") if part]
    i = 0
    while i < len(records):
        if records[i].startswith("R") and i + 2 < len(records):
            fuentes.add(records[i + 1])
            i += 3
            continue
        i += 1
    return fuentes


def _grep_remaining_references(root: Path, filename: str, exclude_paths: set[str]) -> list[str] | None:
    """Search for `filename` across the rest of the tracked tree, excluding exemptions."""
    # `git grep -F` reads every tracked file's CONTENT to search it -- the
    # true cost driver is total tracked-file bytes, which IS measurable
    # up front (sum of `git ls-files` sizes). But this runs once per
    # deleted/renamed path in the caller's loop, and measuring it honestly
    # means another `ls-files` + a stat() per tracked file each time --
    # metadata-only work, yet repeated per call it adds up to more
    # subprocess overhead than the grep itself is expected to cost on a
    # normal repo. Judgment, not fabrication: GIT_SCAN_TIMEOUT, the same
    # bound already used for repo-wide enumeration.
    # -z: same reason as tracked_files() -- a MATCHING file whose own name is
    # non-ASCII would otherwise come back C-quoted and fail every downstream
    # exemption/exclude-path comparison, which compare against real paths.
    result = _run_git(["grep", "-l", "-z", "-F", filename], cwd=root, timeout=GIT_SCAN_TIMEOUT)
    if result is None:
        return None
    if result.returncode > 1:
        logger.error("[dangling_refs] git grep returned rc=%s for %s", result.returncode, filename)
        return None
    return [
        line for line in result.stdout.split("\0")
        if line and not _is_exempt_history(line) and line not in exclude_paths
    ]


def check_file_refs(root: Path, deleted: list[str] | None = None) -> list[dict] | None:
    """Detector 1: staged-deleted/renamed files still mentioned by name elsewhere.

    Args:
        root: Repository root.
        deleted: Conjunto ya consultado de borrados/renombrados en el índice, si
            el llamador lo tiene. `run_all` lo pasa porque necesita ese mismo dato
            para saber si este detector tuvo material que mirar, y preguntárselo
            a git dos veces sería contestar dos veces la misma pregunta.

    Returns None (unable to scan safely -- caller should treat as blocked)
    or a list of findings, one per (deleted file, referencing file) pair.

    OJO al leer un `[]`: significa "revisé y está limpio" O "no había nada
    staged que revisar", y desde fuera no se distinguen. Quien informe el
    resultado a un humano tiene que separarlos -- ver `run_all`.
    """
    if deleted is None:
        deleted = staged_deleted_files(root)
    if deleted is None:
        return None
    if not deleted:
        return []

    renombrados = staged_renamed_sources(root)
    findings: list[dict] = []
    for path in deleted:
        filename = Path(path).name
        # Generic basenames (README.md, index.md, etc.) produce massive false
        # positives if searched by basename alone -- search the full
        # relative path instead, which is genuinely specific.
        #
        # Y un RENOMBRADO se busca siempre por ruta completa: el archivo existe,
        # sólo cambió de sitio, así que la mención obsoleta es la de la ruta
        # vieja -- nunca la del nombre, que puede ser la ruta nueva y correcta.
        needle = (path if (filename.lower() in _GENERIC_BASENAMES
                           or path in renombrados) else filename)
        hits = _grep_remaining_references(root, needle, exclude_paths={path})
        if hits is None:
            return None
        for hit in hits:
            findings.append(_finding(
                "file_refs", ref=path, origin=hit,
                message=f"deleted file {path!r} still referenced by name",
            ))
    return findings


# ---------------------------------------------------------------------------
# Detector 2: id_refs -- cited IDs undefined in the registry docs
# ---------------------------------------------------------------------------

_ID_SOURCE_GLOBS = ("*.py", "*.sh", "*.yaml", "*.yml")


def _id_pattern(prefix: str) -> re.Pattern:
    return re.compile(rf"\b{re.escape(prefix)}-0*([1-9]\d*)\b")


def known_ids(root: Path, registry_docs: tuple[str, ...], prefix: str) -> set[str]:
    """Every id the registry documents define (e.g. {"CC-32", "CC-40"})."""
    pattern = _id_pattern(prefix)
    found: set[str] = set()
    for rel in registry_docs:
        try:
            text = (root / rel).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            logger.debug("Failed reading registry doc %s: %s", rel, exc)
            continue
        found |= {f"{prefix}-{m}" for m in pattern.findall(text)}
    return found


def cite_map(root: Path, prefix: str) -> dict[str, list[str]]:
    """Map each cited id to the tracked source files citing it."""
    pattern = _id_pattern(prefix)
    hits: dict[str, list[str]] = {}
    for path in tracked_files(root, _ID_SOURCE_GLOBS):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:
            logger.debug("Failed reading source path %s: %s", path, exc)
            continue
        for match in set(pattern.findall(text)):
            ident = f"{prefix}-{match}"
            rel = str(path.relative_to(root)).replace("\\", "/")
            hits.setdefault(ident, []).append(rel)
    return {k: sorted(v) for k, v in sorted(hits.items())}


def check_id_refs(
    root: Path,
    registry_docs: tuple[str, ...],
    prefix: str,
    synthetic_ids: frozenset[str] = frozenset(),
) -> list[dict]:
    """Detector 2: ids cited in code that no registry document defines.

    `synthetic_ids` excludes fixture ids (e.g. used only in tests) even
    though undefined, so test data never gets reported as a real dangling
    reference.
    """
    defined = known_ids(root, registry_docs, prefix) | set(synthetic_ids)
    findings = []
    for ident, files in cite_map(root, prefix).items():
        if ident in defined:
            continue
        for f in files:
            findings.append(_finding(
                "id_refs", ref=ident, origin=f,
                message=f"id {ident!r} cited but not defined in any registry doc",
            ))
    return findings


# ---------------------------------------------------------------------------
# Detector 3: rule_drift -- documented "RULE #N" with no implementation
# ---------------------------------------------------------------------------

_RULE_PATTERN = re.compile(r"RULE #(\d+)")
_RULE_NUM_PATTERN = re.compile(r"#(\d+)")
_FUTURE_INLINE = re.compile(r"#(\d+)\s*\[FUTURE\]", re.IGNORECASE)
_FUTURE_FULL = re.compile(r"RULE\s+#(\d+).*\[FUTURE\]", re.IGNORECASE)


def _tracked_markdown(root: Path) -> list[tuple[Path, str]]:
    """(path, text) for every git-tracked *.md file under root."""
    out = []
    for md in tracked_files(root, ("*.md",)):
        try:
            out.append((md, md.read_text(encoding="utf-8")))
        except (OSError, UnicodeError, ValueError, TypeError) as e:
            logger.warning("[dangling_refs] cannot read %s: %s", md, e)
    return out


def _reglas_de_la_linea(line: str) -> set[int]:
    """Todo número de regla que aparece en una línea, en sus dos formas."""
    found: set[int] = set()
    for patron in (_RULE_PATTERN, _RULE_NUM_PATTERN):
        for match in patron.finditer(line):
            found.add(int(match.group(1)))
    return found


def _extract_prose_only_from_line(line: str) -> set[int]:
    """RULE numbers marked [PROSE-ONLY] on a single line."""
    return _reglas_de_la_linea(line) if "[PROSE-ONLY]" in line.upper() else set()


# Un archivo de tarea REGISTRA un hallazgo; no DECLARA una politica. La
# diferencia no es de estilo: `check_rule_drift` bloqueo el commit del propio
# kit el 2026-08-17 porque una tarea nueva citaba «RULE #22 de red_python» para
# describir un defecto del detector. simplecode no tiene reglas -- no tiene ni
# `scripts/` donde implementarlas -- asi que esa mencion no podia ser otra cosa
# que una cita, y el organo la leyo como una declaracion incumplida.
#
# Salir de ahi contorsionando la prosa para esquivar el regex habria sido
# silenciar el instrumento, que es justo lo que este kit existe para no hacer.
_CITA_NO_DECLARA = ("tasks/",)


def _declara_reglas(ruta: Path, root: Path) -> bool:
    """False si el documento registra hallazgos en vez de declarar politica."""
    try:
        rel = ruta.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return True
    return not rel.startswith(_CITA_NO_DECLARA)


def get_documented_rules(root: Path) -> set[int]:
    """Rule numbers documented in any tracked markdown file under root."""
    rules: set[int] = set()
    for ruta, content in _tracked_markdown(root):
        if not _declara_reglas(ruta, root):
            continue
        for match in _RULE_PATTERN.finditer(content):
            rules.add(int(match.group(1)))
    return rules


def get_future_rules(root: Path) -> set[int]:
    """Rules marked [FUTURE] -- backlog, no code expected yet."""
    rules: set[int] = set()
    for _, content in _tracked_markdown(root):
        for match in _FUTURE_INLINE.finditer(content):
            rules.add(int(match.group(1)))
        for match in _FUTURE_FULL.finditer(content):
            rules.add(int(match.group(1)))
    return rules


def _reglas_marcadas(root: Path, extractor) -> set[int]:
    """Reglas que `extractor` reconoce, recorriendo el markdown rastreado.

    Las tres exenciones —`[FUTURE]`, `[PROSE-ONLY]`, `[RETIRED: <razón>]`— sólo
    se diferencian en qué marca buscan; el recorrido es el mismo. Factorizado
    porque el propio gate del kit detuvo el commit que lo duplicaba, y tenía
    razón: dos cuerpos idénticos con otro nombre son copia sin criterio.
    """
    rules: set[int] = set()
    for _, content in _tracked_markdown(root):
        for line in content.split("\n"):
            rules.update(extractor(line))
    return rules


def get_prose_only_rules(root: Path) -> set[int]:
    """Rules marked [PROSE-ONLY] -- human-enforced, no code expected."""
    return _reglas_marcadas(root, _extract_prose_only_from_line)


_RETIRADA = re.compile(r"\[RETIRED:\s*(\S[^\]]*)\]", re.IGNORECASE)


def _extract_retired_from_line(line: str) -> set[int]:
    """Números de regla marcados `[RETIRED: <razón>]` en una línea.

    La razón es OBLIGATORIA: `[RETIRED:]` o `[RETIRED: ]` no exime nada. Un
    retiro sin motivo escrito es un silencio con corchetes, y el vocabulario
    entero existe para que un documento pueda decir la verdad -- no para dar una
    salida más cómoda.

    La primera versión de esto era una copia literal de
    `_extract_prose_only_from_line` con otro marcador, y el gate del propio kit
    la detuvo por `uncritical_copy_paste`. Tenía razón: lo compartido es
    `_reglas_de_la_linea`, y lo propio de cada marcador es una sola condición.
    """
    return _reglas_de_la_linea(line) if _RETIRADA.search(line) else set()


def get_retired_rules(root: Path) -> set[int]:
    """Reglas retiradas: su sujeto se borró a propósito y no vuelve.

    Faltaba la tercera clase del vocabulario. `[FUTURE]` dice «todavía no» y
    `[PROSE-ONLY]` dice «la aplica un humano»; ninguna de las dos sirve para una
    regla cuyo objeto ya no existe. Medido el 2026-08-17: la `RULE #22` de
    red_python apuntaba a `SOURCES_OF_TRUTH.md`, borrado ese mismo día por ser
    doctrina vendorizada. Sin marcador para eso quedó etiquetada `[PROSE-ONLY]`,
    que afirma un revisor humano **que no existe**.

    Es, en miniatura, el defecto que este kit existe para no tener: un gate que
    no admite la verdad obliga a escribir la mentira más cercana que sí acepta.
    """
    return _reglas_marcadas(root, _extract_retired_from_line)


_UNBUILT_MARKER = re.compile(
    r"\b(TODO|FIXME|XXX|HACK|not built|not implemented|no implementad|pendiente|"
    r"plan\w*|will implement|to be implemented|placeholder|stub|someday|"
    r"unimplemented|coming soon)\b", re.IGNORECASE
)


def _rules_claimed_by(content: str, is_python: bool) -> set[int]:
    """Rule numbers this file may claim to implement.

    Two references are NOT an implementation, and both were measured fooling
    this detector: a line that announces the rule as unbuilt ("TODO: implement
    RULE #13 -- tracked, not built yet" registered 13 as implemented), and a
    Python file with no def/class at all, which cannot enforce anything no
    matter what its prose says.
    """
    if is_python:
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return set()
        has_symbol = any(
            isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            for n in ast.walk(tree)
        )
        if not has_symbol:
            return set()
    found: set[int] = set()
    for line in content.split("\n"):
        if _UNBUILT_MARKER.search(line):
            continue
        for match in _RULE_PATTERN.finditer(line):
            found.add(int(match.group(1)))
    return found


def get_implemented_rules(root: Path, code_dirs: tuple[str, ...] = ("scripts",), hook_dir: str = ".git/hooks") -> set[int]:
    """Rule numbers with an implementation reference found in code_dirs or hook_dir."""
    rules: set[int] = set()
    hooks = root / hook_dir
    if hooks.is_dir():
        for hook in hooks.glob("*"):
            if hook.is_file() and not hook.name.endswith(".sample"):
                try:
                    content = hook.read_text(encoding="utf-8")
                    rules.update(_rules_claimed_by(content, is_python=False))
                except (OSError, UnicodeError, ValueError, TypeError) as e:
                    logger.warning("[dangling_refs] cannot read hook %s: %s", hook, e)
    for code_dir in code_dirs:
        d = root / code_dir
        if not d.is_dir():
            continue
        for script in d.glob("*.py"):
            try:
                content = script.read_text(encoding="utf-8")
                rules.update(_rules_claimed_by(content, is_python=True))
            except (OSError, UnicodeError, ValueError, TypeError) as e:
                logger.warning("[dangling_refs] cannot read script %s: %s", script, e)
    return rules


def check_rule_drift(root: Path, min_rule: int = 13, code_dirs: tuple[str, ...] = ("scripts",)) -> list[dict]:
    """Detector 3: documented rules >= min_rule with no implementation,
    [FUTURE], or [PROSE-ONLY] exemption."""
    documented = get_documented_rules(root)
    implemented = get_implemented_rules(root, code_dirs=code_dirs)
    future = get_future_rules(root)
    prose_only = get_prose_only_rules(root)
    retiradas = get_retired_rules(root)
    system_rules = {r for r in documented if r >= min_rule}
    drifted = (system_rules - implemented) - future - prose_only - retiradas
    if retiradas:
        logger.info("[dangling_refs] rule_drift: %s retirada(s) con razon escrita: %s",
                    len(retiradas), ", ".join(f"#{r}" for r in sorted(retiradas)))
    # La ley de la casa: una exencion que no aparece en la salida es una
    # exencion. Las citas que se dejaron fuera se imprimen con su numero.
    citadas = _reglas_solo_citadas(root) - documented
    if citadas:
        logger.info(
            "[dangling_refs] rule_drift: %s citada(s) solo en tasks/ y por tanto "
            "NO contadas como declaradas: %s",
            len(citadas), ", ".join(f"#{r}" for r in sorted(citadas)),
        )
    return [
        _finding(
            "rule_drift", ref=f"RULE #{r}", origin="(markdown)",
            message=f"RULE #{r} documented as enforced but no implementation found",
        )
        for r in sorted(drifted)
    ]


def _reglas_solo_citadas(root: Path) -> set[int]:
    """Numeros de regla que aparecen unicamente en documentos de registro."""
    rules: set[int] = set()
    for ruta, content in _tracked_markdown(root):
        if _declara_reglas(ruta, root):
            continue
        for match in _RULE_PATTERN.finditer(content):
            rules.add(int(match.group(1)))
    return rules


# ---------------------------------------------------------------------------
# Detector 4: doc_parity -- code/docs dependency-graph orphans
# ---------------------------------------------------------------------------

DEFAULT_CODE_NAMESPACES = ("scripts", "src", "app", "lib", "tests")

_ARCH_HINTS = (
    "architecture", "design", "overview", "readme", "index", "guide",
    "tutorial", "vision", "roadmap", "principles", "home", "about",
)

_ENTRYPOINT_SUFFIXES = ("_main",)


def extraction_is_trustworthy(layer1_ast: dict) -> bool:
    """True unless the code-graph extraction reported status "failed"."""
    return layer1_ast.get("extraction_status") != "failed"


def documented_code_ids(layer2: dict) -> set[str]:
    """Ids of code symbols with at least one "documents" edge pointing at them."""
    return {
        edge["target"] for edge in layer2.get("edges", [])
        if edge.get("relation") == "documents"
    }


def _is_documentable_symbol(sym: str, code_namespaces: tuple[str, ...]) -> bool:
    """Is `sym` an architectural symbol we expect to be documented?"""
    if sym.endswith("_py_path") or sym.endswith(_ENTRYPOINT_SUFFIXES):
        return False
    return any(sym == ns or sym.startswith(ns + "_") for ns in code_namespaces)


def critical_symbols(layer1: dict, code_namespaces: tuple[str, ...] | None = None) -> set[str]:
    """Critical symbols for alignment = documentable god-nodes, filtered to
    ones backed by a real path in the graph's path index (drops
    synthetic/aggregate node ids)."""
    namespaces = code_namespaces if code_namespaces is not None else DEFAULT_CODE_NAMESPACES
    path_backed = set(layer1.get("path_index", {}).values())
    documentable_namespaces = tuple(ns for ns in namespaces if ns != "tests")
    return {
        s for s in layer1.get("god_nodes", [])
        if s in path_backed and _is_documentable_symbol(s, documentable_namespaces)
    }


def _classify_doc(label: str) -> str:
    """"arch" (architecture/guide docs, allowed to have no outgoing edges)
    or "concept" (module-specific, held to the stricter standard)."""
    low = label.lower()
    return "arch" if any(hint in low for hint in _ARCH_HINTS) else "concept"


def check_doc_parity(layer1: dict, layer2: dict, code_namespaces: tuple[str, ...] | None = None) -> list[dict] | None:
    """Detector 4: critical code symbols with no documentation edge (FAIL),
    and doc nodes with no outgoing edges at all (WARN).

    Returns None when the input code graph is flagged untrustworthy --
    that's not "0 orphans", it's not-measurable, so callers must treat it
    as a failed scan rather than a clean result.
    """
    if not extraction_is_trustworthy(layer1):
        return None

    documented = documented_code_ids(layer2)
    findings = []
    for sym in sorted(critical_symbols(layer1, code_namespaces)):
        if sym in documented:
            continue
        findings.append(_finding(
            "doc_parity", ref=sym, origin=sym,
            message="critical symbol (god-node) has no documentation",
            severity="FAIL",
        ))

    sourcing = {edge["source"] for edge in layer2.get("edges", [])}
    for node in layer2.get("nodes", []):
        if node.get("skip_align") or node["id"] in sourcing:
            continue
        cls = _classify_doc(node.get("label", node["id"]))
        origin = node.get("path") or node.get("file") or node["id"]
        findings.append(_finding(
            "doc_parity", ref=node["id"], origin=origin,
            message=f"doc has no links to code or other docs ({cls})",
            severity="WARN",
        ))
    return findings


# ---------------------------------------------------------------------------
# Aggregation + CLI
# ---------------------------------------------------------------------------


# Una CITA dentro de prosa puede hablar del pasado: por eso se retiró
# `orphan_consumers.py` (620 candidatos, 96% ruido). Un INVENTARIO es otra cosa:
# una línea cuyo contenido completo es la ruta, en una lista que el documento
# declara como el conjunto de lo que existe. Un inventario que nombra archivos
# inexistentes afirma algo falso del PRESENTE.
#
# Caso medido, y lo produje yo: el 2026-08-17 borré 37 archivos de
# `cuenza/scripts/` y dejé 33 de las 62 entradas de la sección 3 de su SPEC.md
# apuntando a nada. El gate pasó en verde y este mismo órgano, corrido a mano,
# dijo "OK -- no unresolved references found".
_ENTRADA_INVENTARIO = re.compile(r"^- `([^`]+)`\s*$")


def check_inventory_drift(root: Path) -> list[dict]:
    """Entradas de inventario en un .md que nombran rutas que ya no existen.

    Sólo la forma pura: una línea cuyo contenido completo es la ruta entre
    comillas invertidas, y que contiene una barra, para no juzgar una lista de
    nombres sueltos. Nada dentro de prosa.
    """
    findings: list[dict] = []
    for md, text in _tracked_markdown(root):
        rel_md = md.relative_to(root).as_posix()
        if _is_exempt_history(rel_md):
            continue
        # EL DISCRIMINADOR, y es el que quedó tras medir: no la forma de la
        # ruta, sino si el documento es un inventario DE ESTE REPO. Una lista
        # donde NINGUNA entrada existe no es un inventario podrido -- es otra
        # cosa: un informe de respaldo que enumera lo que copió a otro sitio, o
        # una página web guardada. Una lista donde unas existen y otras no, sí.
        #
        # Medido sobre Atlas: 111 hits con el filtro de forma, de los que 68
        # salían de logs/backup_to_nas/*.md y 37 de una referencia web scrapeada.
        # Ninguno de esos documentos tenía UNA SOLA entrada que existiera.
        entradas = [m.group(1) for m in
                    (_ENTRADA_INVENTARIO.match(li.rstrip()) for li in text.splitlines())
                    if m]
        if not any((root / e).exists() for e in entradas):
            continue
        # Dentro de una valla de código la entrada es una CITA, no un
        # inventario. Medido al escribir esto: el primer hallazgo del detector
        # fue el ejemplo dentro de ``` de su propia tarea de deuda. Un detector
        # que condena la documentación que lo explica es el error que retiró a
        # orphan_consumers, una vuelta más.
        en_valla = False
        for numero, linea in enumerate(text.splitlines(), 1):
            if linea.lstrip().startswith("```"):
                en_valla = not en_valla
                continue
            if en_valla:
                continue
            m = _ENTRADA_INVENTARIO.match(linea.rstrip())
            if not m:
                continue
            ruta = m.group(1)
            # Medido el 2026-08-17 sobre la flota, primera versión: 421 hits en
            # Atlas, de los que 365 salían de logs/backup_to_nas/*.md -- informes
            # que LISTAN lo que copiaron, no inventarios de lo que hay -- y el
            # resto de páginas web guardadas citando órdenes de shell
            # (`git clone https://...`, `docker run aquasec/trivy`) y rutas de
            # otra máquina (`/mnt/skills/public`).
            #
            # Un inventario declara lo que hay EN ESTE REPO: ruta relativa, sin
            # espacios. Con eso, 421 -> ver la medición junto a los detectores.
            if ("/" not in ruta or " " in ruta
                    or ruta.startswith(("http", "#", "~", "/", "."))):
                continue
            if (root / ruta).exists():
                continue
            findings.append(_finding(
                "inventory_drift", ruta, f"{rel_md}:{numero}",
                "el inventario lo declara y no existe; una lista que dice qué "
                "hay y miente es peor que no tenerla"))
    return findings
 
 
_MD_LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)#\s]+)(?:#[^\)]*)?\)")
_INLINE_CODE_RE = re.compile(r"`[^`\n]+`")


def _inline_code_spans(line: str) -> list[tuple[int, int]]:
    """Character ranges covered by single-backtick inline code spans.

    `check_broken_evidence_pins` already skips fenced (``` ``` ```) blocks
    but scans every other line raw -- a markdown-syntax EXAMPLE inside inline
    code, e.g. `` `[Nombre](URL) - descripcion` `` describing a link format
    (not citing one), still matches `_MD_LINK_RE` and gets checked as if it
    were a real evidence pin. Reproduced 2026-08-28 on Atlas:
    `docs/agent_findings/2026-08-28_harvest_awesome_ai_tools.md:35` reads
    `` `* [Nombre](URL) - descripcion de una linea` `` -- prose illustrating a
    catalog's entry format, flagged FAIL for a literal target named "URL".
    """
    return [m.span() for m in _INLINE_CODE_RE.finditer(line)]


def _resolve_evidence_target(md_parent: Path, target: str) -> Path | None:
    if not target or target.startswith(("http://", "https://", "mailto:", "#", "data:")):
        return None
    if target.startswith("file:///"):
        return Path(target[7:])
    if target.startswith("/"):
        return Path(target)
    return (md_parent / target).resolve()


def _load_foreign_corpus_prefixes(root: Path) -> tuple[str, ...]:
    """Project-local, opt-in directory PREFIXES holding byte-for-byte copies
    of an external source (same pattern as corpus_exempt.yaml's
    vendored_paths / corruption_guard_prefixes keys, see zero_debt.py).

    Read from ``<root>/.simplecode/corpus_exempt.yaml``, key
    ``foreign_corpus_prefixes``. Absent file/key -> no exemptions.

    PREFIX, not exact path (unlike vendored_paths): a harvested corpus
    directory (e.g. `knowledge/references/`) holds many scraped documents,
    not one file, and each one legitimately cites the ORIGINAL repo's paths,
    not this one's. Measured on Atlas 2026-08-25: 4,683 of 4,720
    `Broken Evidence Pin` findings were relative links inside
    `knowledge/references/*.md` -- READMEs harvested whole alongside their
    evaluation, exactly the same false-positive class this module already
    special-cases for bare-absolute links (see `_is_bare_absolute`'s
    docstring), just not yet for relative ones.
    """
    config = root / ".simplecode" / "corpus_exempt.yaml"
    if not config.is_file():
        return ()
    try:
        data = yaml.safe_load(config.read_text(encoding="utf-8")) or {}
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return ()
    if not isinstance(data, dict):
        return ()
    prefixes = data.get("foreign_corpus_prefixes", [])
    if not isinstance(prefixes, list):
        return ()
    return tuple(str(p).replace("\\", "/") for p in prefixes if isinstance(p, str) and p.strip())


def is_foreign_corpus(root: Path, rel_path: str) -> bool:
    """True iff `rel_path` falls under a declared foreign_corpus_prefixes entry."""
    return rel_path.startswith(_load_foreign_corpus_prefixes(root))


def _is_bare_absolute(target: str) -> bool:
    """True for a `/`-prefixed link target with no scheme.

    This is the ambiguous class: a real absolute filesystem citation
    (`/var/log/some_file`) and a site-relative permalink scraped verbatim
    from an HTML page (`/u/username`, `/c/category/...`) are syntactically
    identical. `file:///...` targets carry an explicit scheme and are never
    in this class.
    """
    return target.startswith("/") and not target.startswith("file://")


def _check_line_pins(
    md_parent: Path, rel_md: str, line_no: int, line: str, skip_bare_absolute: bool = False
) -> list[dict]:
    findings = []
    code_spans = _inline_code_spans(line)
    for m in _MD_LINK_RE.finditer(line):
        if any(start <= m.start() < end for start, end in code_spans):
            continue
        target = m.group(2).strip()
        if skip_bare_absolute and _is_bare_absolute(target):
            continue
        target_path = _resolve_evidence_target(md_parent, target)
        if target_path is not None and not target_path.exists():
            findings.append(_finding(
                "broken_pin", target, f"{rel_md}:{line_no}",
                f"Evidence link points to non-existent file '{target}'",
                severity="FAIL",
            ))
    return findings


def check_broken_evidence_pins(root: Path) -> list[dict]:
    """Check that explicit local file markdown links and file:// citations resolve on disk.

    Inherited Acta 84 invariant: a broken pin and no pin must not read the
    same -- so unlike ``check_inventory_drift``, there is no unscoped
    whole-document skip here. Two DECLARED exceptions, neither a blanket "no
    pins matter" escape:

      1. The bare-absolute-path class (see ``_is_bare_absolute``): measured
         on Atlas, a document where not one bare-absolute link resolves
         locally is a scraped page citing site-relative permalinks, not repo
         evidence citations (2,236 false positives from
         `knowledge/references/forum_*.md` before this scope existed). A
         `file://` or relative target is never in that ambiguous class and
         always got checked, so a lone broken pin of either kind still fired.
      2. ``foreign_corpus_prefixes`` (see ``is_foreign_corpus``): a document
         whose entire directory is declared, in `.simplecode/corpus_exempt.yaml`,
         a byte-for-byte harvest of an external source -- its RELATIVE links
         also point at the original repo's tree, not this one's, and #1
         above never covered relative targets. Declarative and auditable
         (same reasoning as ``vendored_paths``): the exemption is visible in
         config, not inferred from "nothing here resolves."
    """
    findings: list[dict] = []
    for md, text in _tracked_markdown(root):
        rel_md = md.relative_to(root).as_posix()
        if _is_exempt_history(rel_md) or is_foreign_corpus(root, rel_md):
            continue
        bare_targets = [
            m.group(2).strip() for m in _MD_LINK_RE.finditer(text)
            if _is_bare_absolute(m.group(2).strip())
        ]
        skip_bare_absolute = bool(bare_targets) and not any(
            Path(t).exists() for t in bare_targets
        )
        en_valla = False
        for line_no, line in enumerate(text.splitlines(), 1):
            if line.lstrip().startswith("```"):
                en_valla = not en_valla
                continue
            if not en_valla:
                findings.extend(
                    _check_line_pins(md.parent, rel_md, line_no, line, skip_bare_absolute)
                )
    return findings


# --- citation_lines (folded in from the retired source_verifier.py) --------
# check_broken_evidence_pins above only proves a markdown-linked FILE exists;
# it never looks at a cited LINE RANGE, and it never sees a backtick citation
# (`` `file.py:10-15` ``) or a bare one (`file.py:10-20`) at all -- those
# syntaxes carry no `[label](...)` wrapper for _MD_LINK_RE to match.
_CITATION_RE = re.compile(
    r"""(?:`([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)(?::([0-9,\s\-]+))?`|\[[^\]]+\]\((?:file://)?([^)#\s]+\.[a-zA-Z0-9]+)(?:#L(\d+)(?:-L?(\d+))?)?\)|\b([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+):(\d+)(?:-(\d+))?\b)"""
)

# A citation must resolve unambiguously to A LOCATION, not merely mention a
# name. Two independent filters, measured against this repo's real docs
# (2026-08-25, 656 raw matches -> 32 after the harvested-history exemption
# above -> 0 remaining false positives after these two filters):
#
#   1. A REAL extension. The bare-word grammar (`` `word.suffix` ``) matches
#      any dotted token, so `` `json.loads` ``, `` `time.sleep` ``,
#      `` `os.replace` `` (a stdlib call, not a file) all satisfied the old
#      regex. An unbounded suffix set can't tell a module attribute from a
#      file extension; a known, finite set can.
#   2. A path separator OR an explicit line spec. `` `tool_limits.py` `` in
#      prose (SPEC.md, README.md) names a component, it doesn't claim an
#      address -- the citations that DO claim one either carry a directory
#      (`utils/tool_limits.py`) or a line number (`tool_limits.py:42`).
_CITATION_KNOWN_EXTENSIONS = frozenset({
    "py", "md", "yaml", "yml", "json", "jsonl", "toml", "txt", "sh",
    "cfg", "ini", "rst", "js", "ts", "tsx", "jsx", "html", "css",
    "csv", "sha256", "zip",
})


def _looks_like_a_real_citation(file_path: str, has_line_spec: bool) -> bool:
    ext = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else ""
    if ext not in _CITATION_KNOWN_EXTENSIONS:
        return False
    return has_line_spec or "/" in file_path


class CitationMatch(NamedTuple):
    raw: str
    file_path: str
    start_line: int | None
    end_line: int | None


def parse_citations(text: str) -> list[CitationMatch]:
    """Extract file and line citations from markdown or text (3 syntaxes:
    backtick, markdown link with #L anchor, and bare `file.py:N-M`)."""
    matches: list[CitationMatch] = []
    for m in _CITATION_RE.finditer(text):
        raw = m.group(0)
        if m.group(1):  # `file.py:10-15` or `file.py`
            fpath = m.group(1)
            lines_spec = m.group(2)
            s_line, e_line = None, None
            if lines_spec:
                parts = re.split(r"[-,\s]+", lines_spec.strip())
                if parts and parts[0].isdigit():
                    s_line = int(parts[0])
                    e_line = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else s_line
            if not _looks_like_a_real_citation(fpath, s_line is not None):
                continue
            matches.append(CitationMatch(raw, fpath, s_line, e_line))
        elif m.group(3):  # [label](file:///path#L10-L20)
            fpath = m.group(3)
            s_line = int(m.group(4)) if m.group(4) else None
            e_line = int(m.group(5)) if m.group(5) else s_line
            if not _looks_like_a_real_citation(fpath, s_line is not None):
                continue
            matches.append(CitationMatch(raw, fpath, s_line, e_line))
        elif m.group(6):  # file.py:10-20
            fpath = m.group(6)
            s_line = int(m.group(7)) if m.group(7) else None
            e_line = int(m.group(8)) if m.group(8) else s_line
            if not _looks_like_a_real_citation(fpath, s_line is not None):
                continue
            matches.append(CitationMatch(raw, fpath, s_line, e_line))
    return matches


# The same organ groups doctor.py walks under src/simplecode/ (doctor.py:22).
# Docs in this repo routinely cite an organ's path relative to that root
# (`guards/signed_commit.py`) rather than the full repo-relative path
# (`src/simplecode/guards/signed_commit.py`) -- a documentation convention,
# not sloppiness, and the citation checker needs to know it to avoid flagging
# every such citation as a dangling reference.
_ORGAN_GROUPS = ("guards", "verification", "utils", "worktree")


def _resolve_citation_target(
    root: Path, file_path: str, *, source_dir: Path | None = None,
) -> tuple[Path | None, str | None]:
    raw_path = Path(file_path)
    if raw_path.is_absolute() and raw_path.exists():
        target_path = raw_path.resolve()
    elif source_dir is not None and not raw_path.is_absolute():
        target_path = (source_dir / raw_path).resolve()
    else:
        target_path = (root / file_path.lstrip("/")).resolve()
        if not target_path.is_file():
            first_component = file_path.lstrip("/").split("/", 1)[0]
            if first_component in _ORGAN_GROUPS:
                fallback = (root / "src" / "simplecode" / file_path.lstrip("/")).resolve()
                if fallback.is_file():
                    target_path = fallback

    try:
        target_path.relative_to(root.resolve())
    except ValueError:
        return None, f"path_escapes_root: {file_path}"

    if not target_path.is_file():
        return None, f"file_not_found: {file_path}"
    return target_path, None


def verify_citation(
    root: Path, citation: CitationMatch, *, source_dir: Path | None = None,
) -> tuple[bool, str]:
    """Verify a citation resolves to a real file AND a real line range in it."""
    # Markdown links have document-relative URL semantics. Backtick and bare
    # citations retain the repository-root convention used by the CLI.
    link_source_dir = (
        source_dir if citation.raw.startswith("[")
        and not citation.file_path.startswith(("http://", "https://", "ftp://", "mailto:", "file://"))
        else None
    )
    target_path, err = _resolve_citation_target(
        root, citation.file_path, source_dir=link_source_dir,
    )
    if err or target_path is None:
        return False, err or "path_resolution_error"

    try:
        total_lines = len(target_path.read_text(encoding="utf-8", errors="replace").splitlines())
    except OSError as exc:
        return False, f"file_read_error: {exc}"

    if citation.start_line is not None:
        if citation.start_line < 1 or citation.start_line > max(total_lines, 1):
            return False, f"start_line_out_of_bounds: line {citation.start_line} (total lines: {total_lines})"
        if citation.end_line is not None and citation.end_line > total_lines:
            return False, f"end_line_out_of_bounds: line {citation.end_line} (total lines: {total_lines})"

    return True, "valid_physical_citation"


def audit_document_citations(root: Path, doc_path: Path) -> list[tuple[str, str]]:
    """Audit citations in ONE document. Returns (raw_citation, reason) pairs."""
    try:
        text = doc_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return [("document_read", "file_not_found")]

    findings = []
    for cit in parse_citations(text):
        if cit.file_path.startswith(("http://", "https://", "ftp://", "mailto:")):
            continue
        ok, reason = verify_citation(root, cit, source_dir=doc_path.resolve().parent)
        if not ok:
            findings.append((cit.raw, reason))
    return findings


def _citation_lines_from_stdin(root: Path) -> int:
    """`simplecode verify` with no paths: read citations from piped content."""
    try:
        content = sys.stdin.read()
    except OSError:
        print("[source-verifier] COULD NOT RUN: could not read stdin")
        return 2
    citations = parse_citations(content)
    invalid = []
    for cit in citations:
        if cit.file_path.startswith(("http://", "https://", "ftp://")):
            continue
        ok, reason = verify_citation(root, cit)
        if not ok:
            invalid.append((cit.raw, reason))
    if invalid:
        print(f"[source-verifier] FAIL: {len(invalid)} invalid citation(s):")
        for raw, reason in invalid:
            print(f"  - {raw} -> {reason}")
        return 1
    print(f"[source-verifier] OK: {len(citations)} citation(s) verified.")
    return 0


def _citation_lines_from_paths(root: Path, paths: list[Path]) -> int:
    """`simplecode verify <paths...>`: audit each explicit document.

    Explicit paths that are all missing/unreadable is COULD_NOT_RUN (2), not
    a silent OK -- PI-011: the retired source_verifier.py printed "OK: 0
    citation(s) verified" whether it actually checked anything or was simply
    never given anything real to check, and those two situations must not
    read the same.
    """
    checked_files = 0
    total_failures = 0
    for p in paths:
        if not p.is_file():
            print(f"[source-verifier] SKIP: {p} is not a file")
            continue
        checked_files += 1
        findings = audit_document_citations(root, p)
        if findings:
            total_failures += len(findings)
            print(f"[source-verifier] FAIL: {p}")
            for raw, reason in findings:
                print(f"  - {raw} -> {reason}")
        else:
            print(f"[source-verifier] OK: {p}")

    if checked_files == 0:
        print(f"[source-verifier] COULD NOT RUN: none of {len(paths)} given path(s) exist")
        return 2

    return 1 if total_failures > 0 else 0


def citation_lines_main(argv: list[str] | None = None) -> int:
    """CLI for on-demand citation checking (`simplecode verify [paths...]`)."""
    import argparse

    parser = argparse.ArgumentParser(
        description="On-demand file:line citation verification against physical files."
    )
    parser.add_argument("paths", nargs="*", type=Path, help="Documents to verify")
    parser.add_argument("--root", type=Path, default=None, help="Repository root directory")
    args = parser.parse_args(argv)
    root = (args.root or Path.cwd()).resolve()

    if not args.paths:
        return _citation_lines_from_stdin(root)
    return _citation_lines_from_paths(root, args.paths)


def check_citation_lines(root: Path) -> list[dict]:
    """Sweep every tracked markdown doc for file:line citations whose file
    exists but whose cited line range does not (PI-011, folded from
    source_verifier.py). External-scheme targets (http/https/ftp/mailto) are
    never citations to local evidence and are skipped, same as
    check_broken_evidence_pins does for markdown links. Same
    foreign_corpus_prefixes exemption as check_broken_evidence_pins: a
    harvested document's citations point at the ORIGINAL repo's paths, not
    this one's."""
    findings: list[dict] = []
    for md, text in _tracked_markdown(root):
        rel_md = md.relative_to(root).as_posix()
        if _is_exempt_history(rel_md) or is_foreign_corpus(root, rel_md):
            continue
        for cit in parse_citations(text):
            if cit.file_path.startswith(("http://", "https://", "ftp://", "mailto:")):
                continue
            ok, reason = verify_citation(root, cit, source_dir=md.resolve().parent)
            if not ok:
                findings.append(_finding(
                    "invalid_citation", cit.raw, rel_md,
                    f"Citation '{cit.raw}' failed verification: {reason}",
                    severity="FAIL",
                ))
    return findings


_TICKET_REF_RE = re.compile(
    r"#\s*(?:noqa|nosec|nosemgrep|blocking-sleep|unmanaged-open|destructive-input)[^\n]*\b((?:ADR|DGX|SC|DEBT)-[0-9A-Za-z_-]+)\b",
    re.IGNORECASE,
)


def _ticket_exists(root: Path, ticket: str) -> bool:
    norm = ticket.upper()
    for doc in tracked_files(root, ("*.md",)):
        doc_name = doc.name.upper()
        if norm in doc_name:
            return True
        try:
            txt = doc.read_text(encoding="utf-8", errors="ignore")
            if f"# {ticket}" in txt or f"id: {ticket}" in txt or f"id: {norm}" in txt:
                return True
        except OSError as exc:
            logger.debug("Failed reading doc %s: %s", doc, exc)
    return False


def check_noqa_ticket_references(root: Path) -> list[dict]:
    """Check that any ticket/ADR cited in noqa/nosec/nosemgrep suppressions physically exists."""
    findings: list[dict] = []
    for py in tracked_files(root, ("*.py",)):
        rel_py = py.relative_to(root).as_posix()
        if rel_py.startswith("tests/"):
            continue
        try:
            code = py.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.debug("Failed reading py file %s: %s", py, exc)
            continue
        for line_no, line in enumerate(code.splitlines(), 1):
            if "#" not in line:
                continue
            for m in _TICKET_REF_RE.finditer(line):
                ticket = m.group(1).strip()
                if not _ticket_exists(root, ticket):
                    findings.append(_finding(
                        "dangling_ticket", ticket, f"{rel_py}:{line_no}",
                        f"Suppression references non-existent ticket/ADR '{ticket}'",
                        severity="FAIL",
                    ))
    return findings


def run_all(
    root: Path,
    id_refs_config: tuple[tuple[str, ...], str] | None = None,
    graph: dict | None = None,
    min_rule: int = 13,
) -> tuple[list[dict] | None, bool, list[str]]:
    """Run every detector whose inputs are available."""
    all_findings: list[dict] = []
    not_inspected: list[str] = []

    deleted = staged_deleted_files(root)
    if deleted is None:
        return None, False, not_inspected
    if not deleted:
        not_inspected.append(
            "file_refs: el índice no trae borrados ni renombrados, "
            "así que no había qué revisar (no es lo mismo que estar limpio)")
    file_findings = check_file_refs(root, deleted)
    if file_findings is None:
        return None, False, not_inspected
    all_findings.extend(file_findings)

    all_findings.extend(check_inventory_drift(root))
    all_findings.extend(check_broken_evidence_pins(root))
    all_findings.extend(check_noqa_ticket_references(root))
    # check_citation_lines: tightened 2026-08-25 (known-extension whitelist,
    # require a path separator or line spec, organ-relative path fallback,
    # exempt the two harvested-history directories) after the untightened
    # version measured 656 false positives on this repo's own docs -- 0
    # remain after tightening (verified). See the function's own docstring.
    all_findings.extend(check_citation_lines(root))

    if id_refs_config is not None:
        registry_docs, prefix = id_refs_config
        all_findings.extend(check_id_refs(root, registry_docs, prefix))
    else:
        not_inspected.append("id_refs: deshabilitado -- nadie pasó --id-prefix")

    all_findings.extend(check_rule_drift(root, min_rule=min_rule))

    if graph is not None:
        parity = check_doc_parity(graph.get("layer1_ast", {}), graph.get("layer2_docs", {}))
        if parity is None:
            return all_findings, False, not_inspected
        all_findings.extend(parity)
    else:
        not_inspected.append("doc_parity: deshabilitado -- nadie pasó --graph-path")

    ok = not any(f["severity"] == "FAIL" for f in all_findings)
    return all_findings, ok, not_inspected


def _print_findings(findings: list[dict]) -> None:
    for f in findings:
        print(f"  [{f['severity']}] ({f['kind']}) {f['ref']} -- {f['message']} (in {f['origin']})")


def main(argv: list[str] | None = None) -> int:
    import argparse

    desc = (__doc__ or "").splitlines()[0] if __doc__ else ""
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument("--repo-root", default=".", help="Repository root")
    parser.add_argument("--id-prefix", help="Enable id_refs with this id prefix, e.g. CC")
    parser.add_argument("--registry-doc", action="append", default=[], help="Registry doc (repeatable, used with --id-prefix)")
    parser.add_argument("--graph-path", help="Path to a JSON graph enabling doc_parity")
    parser.add_argument("--min-rule", type=int, default=13)
    args = parser.parse_args(argv)

    root = Path(args.repo_root).resolve()

    id_refs_config = (tuple(args.registry_doc), args.id_prefix) if args.id_prefix else None

    graph = None
    if args.graph_path:
        try:
            graph = json.loads(Path(args.graph_path).read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
            logger.error("[dangling_refs] could not read graph %s: %s", args.graph_path, exc)
            return 1

    findings, ok, not_inspected = run_all(
        root, id_refs_config=id_refs_config, graph=graph, min_rule=args.min_rule)
    if findings is None:
        logger.error("[dangling_refs] BLOCKED -- a detector could not complete its scan safely")
        return 1

    # Los ceros se imprimen: lo que no se miró va SIEMPRE, haya hallazgos o no.
    # Medido en Atlas el 2026-08-18: sobre un árbol ya commiteado (tras un
    # `git commit --amend`) este órgano imprimía
    # "0 findings -- no unresolved references found" mientras la referencia
    # colgada del manifiesto seguía presente, 2 apariciones verificadas con
    # `grep -c`. `check_file_refs` había salido por `if not deleted: return []`
    # sin abrir un solo archivo. Un verde vacuo es peor que un rojo: afirma
    # limpieza sobre un sujeto que nadie examinó.
    for nota in not_inspected:
        logger.info("[dangling_refs] NO REVISADO -- %s", nota)

    # El número va declarado, no sólo la palabra: la telemetría del hook extrae
    # "N findings" de la salida, y un órgano que dice "OK" sin cifra deja su
    # columna en `sin_senal` -- indistinguible de no haber corrido. Por eso las
    # notas de arriba no llevan nunca la forma "N findings": la telemetría se
    # queda con la PRIMERA coincidencia y le robarían la cifra al veredicto.
    #
    # El rc no cambia, y es a propósito: no haber tenido material NO es un
    # fallo, y devolver algo distinto de 0 convertiría en captura todo commit
    # que no borre archivos -- el gate quedaría en amarillo permanente, que es
    # la forma más rápida de que nadie lo lea. Lo que cambia es que deja de
    # decirse limpio sobre lo que no miró.
    if not findings:
        if not_inspected:
            logger.info(
                "[dangling_refs] 0 findings -- limpio SÓLO en los detectores que "
                "revisaron; %d no revisaron nada (ver arriba)", len(not_inspected))
        else:
            logger.info("[dangling_refs] 0 findings -- no unresolved references "
                        "found (todos los detectores revisaron su sujeto)")
        return 0

    fails = [f for f in findings if f["severity"] == "FAIL"]
    warns = [f for f in findings if f["severity"] == "WARN"]
    logger.info("[dangling_refs] %d findings (%d FAIL, %d WARN)",
                len(findings), len(fails), len(warns))
    _print_findings(findings)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
