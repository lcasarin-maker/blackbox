#!/usr/bin/env python3
"""Mide cuanto de la estructura canonica ha adoptado ESTE repo. Sale 0 solo si todo.

Existe porque «adoptado» no es binario y tratarlo como si lo fuera produjo un reporte falso: el
2026-09-01 se declaro el canon «aplicado en 14 repos» y la medicion por criterio dio
**SPEC_v2 0/18, index.jsonl 0/18, gates declarados 0/18**. Estaba aplicada la parte visible —las
carpetas y las fichas— y ausente la que hace que el canon CORRA.

Imprime los ceros y distingue lo ausente de lo que no se pudo comprobar, porque un reporte con
`could_not_run > 0` no es un reporte limpio por muchas filas que pasen.

Uso:
    python -m simplecode.verification.canon_adoption --root . [--json]

Migrado y REESCRITO el 2026-09-04. La version anterior (`gates/canon_adoption.py`, copiada sin
pasar por `cli_new`/`satellite_sync` a cada satelite) media "gates declarados" comprobando que
`ledger-schema` apareciera en `.simplecode/local_hooks.yaml` -- comprobando UN SOLO lado. La
sesion aequitas_os lo senalo: un repo podia declarar el gate ahi y nunca tenerlo cableado de
verdad en `.pre-commit-config.yaml` (o al reves), y pasar la revision igual. Con estos gates
distribuidos ahora como hooks del kit en `.pre-commit-config.yaml` (nunca mas copias sueltas en
`gates/`, que es solo para gates PROPIOS del repo -- ver `gates/README.md`), la comprobacion es
correlacionar: el hook existe Y dispara el modulo correcto de `simplecode.verification`.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
from pathlib import Path

from simplecode.satellite.satellite_sync import (
    _extra_hooks_shadowed_by_canonical,
    _load_local_hooks,
    _reindent_extra_hooks,
)
from simplecode.utils.git_utils import run_git

# El nombre de hook (kebab-case, tal como lo escribe `cli_new._pre_commit_config`) y el modulo
# completo que debe disparar. NO todos viven en `simplecode.verification` -- `ponytail-debt`
# vive en `simplecode.guards`, y ese desajuste de paquete es EXACTAMENTE por lo que este
# diccionario nombra la ruta completa por hook en vez de asumir un prefijo comun.
#
# `ponytail-debt` se sumo el 2026-09-04, reportado por la sesion RePic: el modulo viaja en
# runtime.zip desde que se escribio, pero `canon_adoption` solo vigilaba los 3 gates
# originales -- exactamente el estado ("existe, no dispara") que este criterio existe para
# cazar, con el propio criterio ciego a su cuarto caso. RePic midio 0 referencias en su
# `.pre-commit-config.yaml`/`local_hooks.yaml` antes de cablearlo (commit 5ada316 en su repo).
#
# REDEFINIDO el 2026-09-27 (DECISIONS.md, votado por Luis): la auditoria de gates del
# 2026-09-26 juzgo APARATO -- protegen el proceso del kit, no el producto -- a
# `ledger-schema`, `no-perder-lineas` y `ponytail-debt`, y se retiraron del pipeline de
# hooks. El canon pasa a medir los 6 gates que salieron INDISPENSABLES: defensa real de
# producto, no disciplina de fichas del kit.
# Limite declarado de `gitleaks`: es un hook de repo remoto, su `- id:` no lleva `entry:`,
# asi que la cadena que se exige es el propio id -- el criterio distingue presente de
# ausente, pero no un `- id: gitleaks` local que corra otra cosa.
HOOKS_CANON = {
    "angry-path": "simplecode.guards.angry_path",
    "corruption-guard": "simplecode.guards.corruption_guard",
    "coverage-floor": "simplecode.verification.coverage_target",
    "gitleaks": "gitleaks",
    "pii-scan": "simplecode.verification.pii_scan",
    "pyright": "simplecode.verification.pyright_gate",
}


def _sin_comentarios(texto: str) -> str:
    """El texto sin sus comentarios HTML: lo que el documento AFIRMA, no lo que se instruye."""
    return re.sub(r"<!--.*?-->", "", texto, flags=re.DOTALL)


def _lee(p: Path) -> str:
    """El texto de `p`, o "" si no hay archivo que leer (ausente, o un directorio como el
    gitlink de un submodulo). Cualquier OTRO OSError se propaga: un archivo que existe y no
    se deja leer no es un archivo vacio, y `main` lo reporta COULD_NOT_RUN (SPEC-L239)."""
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except (FileNotFoundError, IsADirectoryError):
        return ""


def _gate_del_kit_vacuo(root: Path) -> bool:
    """True si el gate de fichas del kit gobierna 0 mientras el repo tiene contenido en tasks/."""
    return root.joinpath("tasks").is_dir() and not any(
        (root / "tasks" / c).is_dir() for c in ("backlog", "done")
    )


# Modulos que la flota ha forkeado historicamente a `gates/<nombre>` en vez de
# importar del kit -- cada uno con su propia ficha de deuda midiendo una copia
# que quedo atras (DEBT-FLEET-NO-PERDER-LINEAS-FIX-UNPROPAGATED: no_perder_lineas.py).
# Root cause compartida, nombrada por la propia ficha: "no hay ninguna senal
# automatica de que tu copia de X quedo atras de la version canonica".
#
# `ledger_schema.py` NO esta en esta lista, y fue un error que lo estuviera:
# dogfooding de `fleet_audit` (DEBT-FLEET-GENERALIZATION-CANDIDATES-2026-09-07
# item 7) lo encontro marcando **17 de 17** satelites como "desactualizados" el
# mismo dia que 10 de ellos se migraron y verificaron limpios contra
# DEBT-QUINCE-COPIAS-DEL-ESQUEMA-DIVERGEN -- un acierto del 100% sobre un
# defecto que no existe es un defecto del instrumento, no evidencia del
# sujeto. La comparacion es bytes-contra-el-modulo-COMPLETO-de-701-lineas de
# la madre, pero el fork canonico post-migracion es un wrapper corto de
# `_expect_del_kit()` -- nunca fue, ni sera, byte-identico a la madre, este al
# dia o no. El chequeo semantico correcto para este modulo es si deriva del
# kit (`_expect_del_kit()`) en vez de escribir `EXPECT` a mano -- eso es lo
# que mide `fleet_audit._expect_escrito_a_mano`, no un diff de bytes.
MODULOS_FORKEABLES = ("pii_scan.py", "no_perder_lineas.py", "canon_adoption.py")


def _mother_reachable(root: Path) -> Path | None:
    """El paquete `simplecode` del kit, alcanzable desde `root` -- mismo orden
    de alcanzabilidad que `.simplecode/run.py` y `doctor._runtime_freshness`
    usan: primero ESTE repo si es la propia madre, luego `~/projects/simplecode`
    en la maquina local. None si ninguno de los dos existe."""
    candidato = root / "src" / "simplecode"
    if candidato.is_dir():
        return candidato
    candidato = Path.home() / "projects" / "simplecode" / "src" / "simplecode"
    if candidato.is_dir():
        return candidato
    return None


def _gates_forkeados_desactualizados(root: Path) -> list[str]:
    """Nombres de `gates/*.py` cuyo contenido difiere del modulo canonico
    equivalente, cuando una madre es alcanzable para comparar.

    Sin madre alcanzable, "desactualizado" es indistinguible de "no se pudo
    saber" -- se reporta como AL DIA en vez de arriesgar un falso positivo
    sobre algo que no se pudo medir (mismo criterio que
    `doctor._runtime_freshness`'s estado `mother_absent`).
    """
    gates_dir = root / "gates"
    if not gates_dir.is_dir():
        return []
    mother_pkg = _mother_reachable(root)
    if mother_pkg is None:
        return []
    stale = []
    for nombre in MODULOS_FORKEABLES:
        fork = gates_dir / nombre
        canonico = mother_pkg / "verification" / nombre
        if fork.is_file() and canonico.is_file():
            if fork.read_bytes() != canonico.read_bytes():
                stale.append(nombre)
    return stale


# --- estados retirados reintroducidos por un auditor local ------------------
# DEBT-STRUCTURAL-AUDIT-REINTRODUCES-RETIRED-STATES (fleet_deep_dive, 2026-09-10):
# Agente Inmobiliario y Ruleta mantienen cada uno su propio auditor estructural
# LOCAL que exige `tasks/active`, `tasks/blocked` y `tasks/review` -- el layout
# de tres estados que DECISIONS.md retiro en favor de `tasks/backlog/` +
# `tasks/done/` (entrada 2026-09-09, "Two task states and an explicitly
# updated kit"). El criterio `una_sola_casa` de arriba solo mira que CARPETAS
# existen hoy en el arbol de trabajo -- nada le dice si hay un SCRIPT
# versionado que seguira reclamando esas carpetas para siempre. Un satelite
# puede borrar `tasks/active/` (pasando `una_sola_casa` en verde) mientras
# conserva el auditor que fallara en cada corrida futura exigiendola de vuelta.
#
# Alcance: solo archivos TRACKEADOS por git (`git ls-files`), nunca un paseo
# del filesystem -- un archivo de scratch sin comitear no es "este satelite
# envia un auditor", es ruido. Reads content, no solo el nombre del archivo:
# la extension de un "auditor estructural" varia (`.py`, `.sh`, un Makefile
# target, un config sin extension), y una lista fija de extensiones quedaria
# atras en la primera flota que use una distinta.
_LEGACY_TASK_STATES = ("active", "blocked", "review")

# El match exige que el token `tasks/<estado>` sea COMPLETO -- ni precedido ni
# seguido por otro caracter de palabra o `/`. Esto es lo que separa una
# referencia EJECUTABLE (`Path("tasks/active").mkdir()`, `tasks_dir:
# tasks/blocked` en un YAML sin comillas) de una que solo LUCE parecida:
# `"tasks/review/CONV-DEBT-x.md"` (dato de fixture citando un archivo bajo esa
# carpeta, no una orden de crearla -- medido real en
# tests/test_pii_scan.py, que qeudaria falsamente convicto sin este limite) y
# comentarios de prosa que narran la carpeta como parte de una ruta mas larga
# ("...tasks/review/ P1 backlog...", medido real en
# src/simplecode/verification/universal_harvester.py). Las comillas quedan
# fuera del propio patron a proposito: el mismo texto aparece sin comillas en
# YAML/Makefile y con comillas en Python/JS, y exigirlas dejaria ciego al
# primer caso.
_LEGACY_TASK_STATE_RE = re.compile(
    r"(?<![\w/])tasks/(?:" + "|".join(_LEGACY_TASK_STATES) + r")(?![\w/])"
)

# Documentacion/historia explicitamente exenta -- mismo patron de tres partes
# (archivo exacto / prefijo / sufijo) que `dangling_refs._is_exempt_history`,
# porque la pregunta es identica en naturaleza: ¿esta ocurrencia es un
# instrumento vivo, o el registro de un pasado que TIENE que poder nombrar lo
# que retiro? Un acta de retiro que no puede decir `tasks/active` no es un
# acta -- DECISIONS.md, CANON.md y un CHANGELOG existen precisamente para
# nombrar los estados que ya no rigen.
#
# `src/simplecode/verification/canon_adoption.py` es su propia excepcion: es
# el modulo canonico que ESCRIBE la lista de estados retirados (ve
# `legacy_task_paths` en `criterios()`, unas lineas mas abajo) para detectar
# si siguen presentes -- comprobar su ausencia no es lo mismo que un auditor
# local que exige su presencia, aunque el texto literal coincida byte a byte.
_LEGACY_AUDITOR_EXEMPT_FILES = {
    "DECISIONS.md", "CANON.md", "HANDOFF.md",
    "src/simplecode/verification/canon_adoption.py",
    # Its own regression suite necessarily constructs fixtures containing the
    # banned pattern to prove the detector convicts it -- that is testing the
    # retirement, not a live auditor demanding it back.
    "tests/test_canon_adoption.py",
}
# `audit/` y `tasks/evidence/` (anadidos 2026-10-05, medido en aequitas_os): son
# evidencia ENTREGADA -- CSV/JSON de un swarm de auditoria, el script que un
# worker uso una vez para levantar un censo --, no codigo que el repo ejecute en
# cada corrida. aequitas_os tenia 6 archivos ahi convictos por citar
# «tasks/active|blocked|review siguen retirados» o por listar esas carpetas en el
# recorrido de un censo; ninguno ordena crearlas ni exigirlas. Un script con el
# mismo contenido FUERA de estos prefijos sigue contando.
_LEGACY_AUDITOR_EXEMPT_PREFIXES = (
    "docs/", "deprecated/", "archive/", "CHANGELOG", "audit/", "tasks/evidence/",
)
_LEGACY_AUDITOR_EXEMPT_SUFFIXES = (".md", ".rst", ".txt")

# Datos tabulares/estructurados: el token solo cuenta si una celda (CSV) o un
# string/clave (JSON) ES la ruta retirada -- lo que un auditor leeria como
# configuracion (`{"dirs": ["tasks/active"]}`). Si solo aparece dentro de una
# frase mas larga (`"motivo": "2 fichas movidas de tasks/active a ..."`) es
# texto citado. Medido en aequitas_os 2026-10-05: 4 CSV y 1 JSON de auditoria y
# `.protocol/metadata/coverage_graph_gap_baseline.json`, todos prosa citada.
_LEGACY_AUDITOR_DATA_SUFFIXES = (".csv", ".json")
_LEGACY_TASK_STATE_PATHS = frozenset(f"tasks/{s}" for s in _LEGACY_TASK_STATES)


def _valores_de_dato(rel: str, contenido: str) -> list[str] | None:
    """Celdas de un CSV, o strings y claves de un JSON; None si `rel` no es dato
    estructurado o no parsea -- en ese caso el llamador cae al regex sobre el
    texto completo y lo cuenta, como antes: no saber parsearlo no lo absuelve."""
    if rel.endswith(".csv"):
        try:
            return [celda for fila in csv.reader(io.StringIO(contenido)) for celda in fila]
        except csv.Error:
            return None
    if rel.endswith(".json"):
        try:
            pendientes = [json.loads(contenido)]
        except ValueError:
            return None
        valores: list[str] = []
        while pendientes:
            x = pendientes.pop()
            if isinstance(x, str):
                valores.append(x)
            elif isinstance(x, dict):
                pendientes.extend(x.keys())
                pendientes.extend(x.values())
            elif isinstance(x, list):
                pendientes.extend(x)
        return valores
    return None


def _es_ruta_retirada(valor: str) -> bool:
    """True si `valor` es, entero, una ruta de estado retirado. Mismo token que
    `_LEGACY_TASK_STATE_RE`: `./tasks/active/` tampoco lo es alla.

    Example:
        >>> _es_ruta_retirada(" tasks/active ")
        True
        >>> _es_ruta_retirada("2 fichas movidas de tasks/active a tasks/backlog")
        False
    """
    return valor.strip() in _LEGACY_TASK_STATE_PATHS


def _is_exempt_legacy_auditor_doc(path: str) -> bool:
    """Whether `path` is historical/doc prose exempt from the legacy-states scan.

    Example:
        >>> _is_exempt_legacy_auditor_doc("DECISIONS.md")
        True
        >>> _is_exempt_legacy_auditor_doc("docs/CHANGELOG.md")
        True
        >>> _is_exempt_legacy_auditor_doc("scripts/structural_audit.py")
        False
    """
    return (path in _LEGACY_AUDITOR_EXEMPT_FILES
            or path.startswith(_LEGACY_AUDITOR_EXEMPT_PREFIXES)
            or path.endswith(_LEGACY_AUDITOR_EXEMPT_SUFFIXES))


def _legacy_task_state_scripts(root: Path) -> list[str]:
    """Tracked, non-exempt files that reference a retired task-state path in
    an executable way (see `_LEGACY_TASK_STATE_RE` for what counts).

    Sin repo git (o sin nada trackeado), `git ls-files` falla o sale vacio --
    en ambos casos no hay nada que un auditor local pudiera haber comitido, asi
    que esta funcion devuelve `[]` en vez de arriesgar un falso positivo sobre
    algo que no pudo comprobar.

    En CSV/JSON que parsean, cuenta solo si una celda/string/clave ES la ruta
    retirada (ver `_LEGACY_AUDITOR_DATA_SUFFIXES`); la mencion dentro de prosa
    citada no cuenta.
    """
    rc, out, _ = run_git(["ls-files"], root)
    if rc != 0:
        return []
    offenders: list[str] = []
    for rel in out.decode("utf-8", "surrogateescape").splitlines():
        rel = rel.strip()
        if not rel or _is_exempt_legacy_auditor_doc(rel):
            continue
        contenido = _lee(root / rel)
        if not contenido or not _LEGACY_TASK_STATE_RE.search(contenido):
            continue
        if rel.endswith(_LEGACY_AUDITOR_DATA_SUFFIXES):
            valores = _valores_de_dato(rel, contenido)
            if valores is not None and not any(map(_es_ruta_retirada, valores)):
                continue
        offenders.append(rel)
    return offenders


def _local_hooks_sin_versionar(root: Path) -> bool:
    """True si `.simplecode/local_hooks.yaml` existe pero NO esta trackeado por git.

    DEBT-FLEET-LOCAL-HOOKS-GITIGNORED-VANISH-ON-CLONE (office2office,
    `gates/hooks_versionados.py`): el archivo que hace que `satellite_sync --fix`
    no borre los hooks propios de un repo esta gitignorado en TODA la flota
    muestreada -- un clone fresco (CI, otra maquina, otro agente) pierde los
    hooks extra en silencio, y `canon_adoption` no lo veia porque solo
    correlacionaba id-de-hook con modulo, nunca la fuente de esos ids extra.
    Ausente el archivo no es un defecto (un repo sin hooks propios no tiene
    nada que versionar); presente pero sin trackear si lo es.
    """
    local_hooks = root / ".simplecode" / "local_hooks.yaml"
    if not local_hooks.is_file():
        return False
    rc, _, _ = run_git(["ls-files", "--error-unmatch", "--", ".simplecode/local_hooks.yaml"], root)
    return rc != 0


_EXTRA_HOOK_BLOCK_RE = re.compile(r"^\s*- id:\s*(\S+)\b.*?(?=^\s*- id:|\Z)", re.MULTILINE | re.DOTALL)


def _extra_hooks_bypassing_gate_runner(root: Path) -> list[str]:
    """Ids from `.simplecode/local_hooks.yaml`'s `extra_hooks:` whose `entry:`
    does not route through `simplecode.verification.gate_runner`.

    DEBT-FLEET-EXTRA-HOOKS-BYPASS-GATE-RUNNER-TELEMETRY (declutter diagnosed
    and fixed this for itself 2026-09-02/05; blog_ciudadano_x and cuenza were
    found with the same defect live, 2026-09-07 fleet audit): a hook that
    calls its script bare (`entry: python gates/X.py --check`) runs and can
    still block a commit, but writes NO row to
    `.simplecode/evidence/telemetry.jsonl` -- `gate_effectiveness` cannot
    distinguish "this gate never caught anything" from "this gate's rows
    never existed". Reuses `satellite_sync`'s own reindent/parse of
    `extra_hooks` rather than re-implementing it, so the two never drift on
    what counts as one hook's block.
    """
    raw = _load_local_hooks(root)
    if not raw.strip():
        return []
    reindented = _reindent_extra_hooks(raw)
    # A hook id already covered by HOOKS_CANON is SHADOWED: `satellite_sync`
    # drops it from the composed config in favor of the canonical (correctly
    # gate_runner-wrapped) entry, so its own `entry:` here never actually
    # runs -- flagging it would convict dead text, not a live bypass.
    shadowed = set(_extra_hooks_shadowed_by_canonical(root))
    offenders = []
    for m in _EXTRA_HOOK_BLOCK_RE.finditer(reindented):
        hook_id, block = m.group(1), m.group(0)
        if hook_id in shadowed:
            continue
        if "gate_runner" not in block:
            offenders.append(hook_id)
    return offenders


def _hook_cableado(pre_commit: str, hook_id: str, modulo: str) -> bool:
    """`hook_id` presente en `.pre-commit-config.yaml` Y disparando `modulo`.

    Un `- id: pii-scan` que exista pero dispare un script viejo (`gates/pii_scan.py`, o nada)
    no cuenta: existir en el archivo no basta si lo que corre no es el organo real. Se recorta
    el bloque del hook hasta el siguiente `- id:` (o fin de archivo) para no confundir el
    modulo de un hook con el de otro que lo mencione en un comentario cercano.
    """
    patron = re.compile(rf"^\s*- id:\s*{re.escape(hook_id)}\b.*?(?=^\s*- id:|\Z)",
                        re.MULTILINE | re.DOTALL)
    m = patron.search(pre_commit)
    return bool(m and modulo in m.group(0))


def _hooks_cableados(pre_commit: str) -> set[str]:
    """ids del canon (`HOOKS_CANON`) presentes en `.pre-commit-config.yaml` Y apuntando al
    modulo correcto -- ver `_hook_cableado`, que hace la comprobacion por hook."""
    return {hook_id for hook_id, modulo in HOOKS_CANON.items()
            if _hook_cableado(pre_commit, hook_id, modulo)}


def _closed_fichas_citing_canon_adoption(root: Path) -> list[str]:
    """Fichas in `tasks/done/` whose `close_check.cmd` invokes
    `canon_adoption` -- a criterion this module gains later (raising the
    canon's bar is legitimate and expected) can silently turn one of these
    already-closed fichas' own close_check red, with nothing to say so until
    someone happens to re-run it. DEBT-FLEET-CANON-ADOPTION-SILENT-ESCALATION
    (RePic, 2026-09-08): `CANON-ADOPT.md`, closed 2026-09-03, went red this
    way when `extra_hooks_via_gate_runner` was added, discovered only because
    RePic re-ran the gate on its own initiative.

    Reuses `ledger_schema.parse` (the kit's one frontmatter reader) rather
    than a second YAML-ish parser that could read a ficha's `close_check`
    differently from the schema gate that actually judges it.
    """
    from simplecode.verification import ledger_schema

    tasks_done = root / "tasks" / "done"
    if not tasks_done.is_dir():
        return []
    citing = []
    for path in sorted(tasks_done.glob("*.md")):
        fm, _err = ledger_schema.parse(path)
        if not fm:
            continue
        close_check = fm.get("close_check")
        cmd = str(close_check.get("cmd", "")) if isinstance(close_check, dict) else ""
        if "canon_adoption" in cmd:
            citing.append(path.name)
    return citing


def criterios(root: Path) -> dict[str, tuple[bool, str]]:
    """{nombre: (cumple, que falta)}. Cada uno comprobable sin juicio humano."""
    spec = _lee(root / "SPEC.md")
    pre_commit = _lee(root / ".pre-commit-config.yaml")
    cableados = _hooks_cableados(pre_commit)
    faltan_hooks = sorted(set(HOOKS_CANON) - cableados)
    tiene_src = (root / "src").is_dir()
    legacy_task_paths = [
        rel for rel in ("ledger", "backlog", "tasks/active", "tasks/blocked", "tasks/review")
        if (root / rel).exists()
    ]
    resultado: dict[str, tuple[bool, str]] = {
        "readme": ((root / "README.md").is_file(),
                   "falta README.md: la unica puerta para quien no sabe nada del repo"),
        "spec_tipado": (spec.lstrip().startswith("---") and "spec_version: 2" in spec[:600],
                        "SPEC.md sin front-matter tipado (`spec_version: 2`): sigue el esqueleto viejo"),
        # Busca un bloque `### REQ-NNNN` FUERA de comentarios HTML. La version anterior casaba
        # `verify:` y `SHALL` en cualquier parte, y el ejemplo dentro del comentario de la
        # seccion vacia los contenia: el criterio pasaba con la seccion sin llenar. Un criterio
        # que no puede fallar no mide, decora -- y daba 11/11 sobre 17 SPEC sin un solo requisito.
        "spec_requisitos": (bool(re.search(r"^### REQ-\d+", _sin_comentarios(spec), re.MULTILINE)),
                            "SPEC.md sin requisitos EARS con su `verify:`: un requisito sin comando es prosa"),
        # UNA sola casa: `tasks/`, con las carpetas que YA marcaban el estado. El `ledger/` se
        # colapso aqui el 2026-09-02: duplicaba fichas sin anadir la separacion que `tasks/`
        # ya daba, y esa duplicacion costo mas de una pisada de trabajo ajeno en un dia.
        "una_sola_casa": (not legacy_task_paths and (root / "tasks").is_dir(),
                          "el trabajo vive en tasks/backlog/ y tasks/done/; "
                          f"rutas antiguas por reconciliar: {legacy_task_paths}; "
                          f"tasks/ existe: {(root / 'tasks').is_dir()}"),
        "separa_abierto_de_cerrado": ((root / "tasks" / "backlog").is_dir()
                                      and (root / "tasks" / "done").is_dir(),
                                      "faltan las carpetas que separan abierto de cerrado: "
                                      "`tasks/backlog/` y `tasks/done/`. Sin ellas, pedir la "
                                      "deuda abierta obliga a filtrar por un campo en vez de "
                                      "mirar un directorio"),
        # Los gates del canon (`HOOKS_CANON`, los 6 indispensables desde el 2026-09-27)
        # viven en el kit (runtime.zip): no hay `gates/*.py` que copiar, asi que
        # "adoptado" significa que el
        # hook del kit este cableado y dispare el modulo real -- comprobado en LOS DOS
        # extremos (existe el id, Y apunta al modulo), no solo en uno.
        "gates_del_kit_cableados": (not faltan_hooks,
                                    "hooks del canon sin cablear de verdad en "
                                    ".pre-commit-config.yaml (existir no basta si no disparan "
                                    f"el modulo real): faltan {faltan_hooks or list(HOOKS_CANON)}"),
        # Criterio anadido el 2026-09-01 tras el aviso de la sesion atlas-48, medido y confirmado:
        # retirar `tasks/` dejo al `backlog_verifier` del kit reportando `governed: 0` y `rc=0` en
        # varios repos migrados. Es la doctrina de la casa al pie de la letra --«un gate con cero
        # capturas tras muchas corridas es un defecto del instrumento, nunca evidencia de que el
        # sujeto este limpio»-- y lo produjo mover el sujeto sin re-apuntar el instrumento.
        "gate_no_vacuo": (not _gate_del_kit_vacuo(root),
                          "el `backlog_verifier` del kit gobierna 0 fichas mientras el repo "
                          "tiene contenido en tasks/: aprueba en verde sobre un conjunto vacio "
                          "por construccion. Un instrumento que solo sabe aprobar es peor que "
                          "ninguno"),
        # Criterio anadido el 2026-09-02 tras un incidente real que reporto aequitas_os: un
        # agente pego 20 RFC y razones sociales de clientes en una ficha. El repo se publica en
        # GitHub. Seguridad no se recorta -- y "el gate existe en algun lado" no basta, tiene
        # que estar disparando: mismo criterio de cableado que arriba, con su propio nombre
        # porque la razon de que importe es otra.
        # Renombrado 2026-09-04 (hallazgo de Atlas, verificado aqui sobre el sujeto).
        # Se llamaba `sin_pii` -- "sin PII" -- y prometia una ausencia que NO mide: con un
        # RFC vivo plantado en `tasks/backlog/` este criterio sigue en OK, medido. Lo que
        # comprueba es que el hook este CABLEADO al organo correcto, que es la pregunta que
        # le toca a un medidor de adopcion. La respuesta sobre exposicion la da `pii_scan`
        # corriendo (rc=1 con el RFC plantado, rc=0 sin el; medido el mismo dia).
        # NO se cambio para que invoque `pii_scan`: son dos preguntas distintas, y atarlas
        # haria que un repo PIERDA adopcion por tener un hallazgo, que es leer el sujeto
        # como si fuera el cableado -- el error inverso al que este arreglo corrige.
        "pii_scan_cableado": ("pii-scan" in cableados,
                    "el hook `pii-scan` no dispara de verdad: no esta cableado al modulo "
                    "`simplecode.verification.pii_scan`, asi que nada corre para impedir que "
                    "un RFC, una CURP o una razon social de un tercero entre a `tasks/`"),
        "tests_si_src": ((not tiene_src) or (root / "tests").is_dir(),
                         "hay src/ sin tests/: la suite es una implicacion del codigo, no un opcional"),
        "local_hooks_versionado": (not _local_hooks_sin_versionar(root),
                    ".simplecode/local_hooks.yaml existe pero no esta trackeado por git: un "
                    "clone fresco (CI, otra maquina, otro agente) pierde los hooks propios de "
                    "este repo en silencio -- `satellite_sync --fix` no tiene nada que "
                    "preservar si el archivo nunca llega al clone"),
    }
    bypass = _extra_hooks_bypassing_gate_runner(root)
    resultado["extra_hooks_via_gate_runner"] = (
        not bypass,
        "hook(s) propios en .simplecode/local_hooks.yaml no pasan por "
        "gate_runner, asi que corren y pueden bloquear un commit sin escribir "
        f"telemetria (gate_effectiveness nunca los vera): {bypass}",
    )
    stale_forks = _gates_forkeados_desactualizados(root)
    resultado["gates_forkeados_al_dia"] = (
        not stale_forks,
        "copia(s) en gates/ cuyo contenido difiere del modulo canonico equivalente "
        "del kit -- una mejora real (ej. un chequeo nuevo) puede haber llegado al kit "
        f"sin llegar aqui, en silencio: {stale_forks}",
    )
    # DEBT-STRUCTURAL-AUDIT-REINTRODUCES-RETIRED-STATES: `una_sola_casa` (arriba)
    # solo mide la ESTRUCTURA presente en el arbol de trabajo. Este criterio mide
    # el CONTENIDO de lo trackeado: un auditor local comitido que sigue exigiendo
    # `tasks/active`, `tasks/blocked` o `tasks/review` de forma ejecutable, pese a
    # que esas carpetas ya no existen y `una_sola_casa` esta en verde.
    auditores_legacy = _legacy_task_state_scripts(root)
    resultado["sin_auditor_de_estados_retirados"] = (
        not auditores_legacy,
        "archivo(s) trackeado(s) referencian tasks/active, tasks/blocked o "
        "tasks/review de forma ejecutable (no en prosa historica) -- un auditor "
        "local seguira exigiendo el layout de tres estados que DECISIONS.md "
        f"retiro (2026-09-09, 'Two task states and an explicitly updated kit'): {auditores_legacy}",
    )
    # Criterio 14, anadido 2026-09-22 (Pista 3): la unica convencion de esta lista que
    # ningun gate exige, medida por adopcion organica -- 14/18 repos de la flota ya lo
    # tienen sin que nada los obligue. Solo presencia, mismo costo que `readme`: el
    # CONTENIDO de las decisiones (fecha, motivo, que descarta) lo audita `/vote`, no un
    # criterio ejecutable de este modulo.
    resultado["decisions_md"] = (
        (root / "DECISIONS.md").is_file(),
        "falta DECISIONS.md: donde vive el 'por que' de una decision durable, para que no "
        "se pierda con la sesion que la tomo",
    )
    # El criterio 15 (`close_check_discrimina_bloqueante`, exigia el hook
    # `close-check-discrimina` cableado) se retiro el 2026-09-27 junto con ese hook: la
    # auditoria de gates lo juzgo APARATO (DECISIONS.md). El modulo sigue corrible a mano.
    return resultado


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    root = args.root

    try:
        c = criterios(root)
    except OSError as exc:
        # Ni NO ni OK: un criterio calculado sobre un archivo que no se pudo leer seria un
        # veredicto sobre un sujeto que nadie leyo. rc=2, el de COULD_NOT_RUN del kit.
        print(f"[canon-adoption] COULD_NOT_RUN: no se pudo leer {getattr(exc, 'filename', '')} "
              f"({type(exc).__name__}: {exc}) -- ningun criterio se juzgo")
        return 2
    faltan = [(k, m) for k, (ok, m) in c.items() if not ok]
    citando = _closed_fichas_citing_canon_adoption(root) if faltan else []
    if args.json:
        print(json.dumps({"repo": root.resolve().name, "total": len(c),
                          "cumple": len(c) - len(faltan),
                          "faltan": [k for k, _ in faltan],
                          "fichas_cerradas_afectadas": citando}, ensure_ascii=False))
        return 1 if faltan else 0
    print(f"adopcion del canon en {root.resolve().name}: {len(c) - len(faltan)}/{len(c)} criterios")
    for k, (ok, _) in c.items():
        print(f"  {'OK' if ok else 'NO'}  {k}")
    if faltan:
        print("\nlo que falta, y por que importa:")
        for k, m in faltan:
            print(f"  - {k}: {m}")
    if citando:
        print(
            f"\nAVISO: {len(citando)} ficha(s) en tasks/done/ verificaron canon_adoption al "
            "cerrarse y hoy corren contra un criterio mas estricto que el que tenian entonces -- "
            "su close_check podria ya no pasar si se re-corre: " + ", ".join(citando)
        )
    # Lo que este medidor NO mira, dicho en el mismo aliento que el veredicto.
    # `10/10 criterios` describe el CABLEADO del canon, nunca el estado del
    # sujeto: los gates cableados aqui pueden estar todos rojos y este numero
    # no se mueve. Sin esta linea, un OK se lee como salud (Atlas, 2026-09-04).
    print("\nalcance: esto mide CABLEADO, no veredictos. Un repo con los "
          "hooks cableados y todos sus gates en rojo puntua igual. Para el estado "
          "del sujeto hay que correr los gates: `pii_scan`, `zero_debt`, "
          "`adversarial_judge` y el resto responden cada uno por lo suyo.")
    return 1 if faltan else 0


if __name__ == "__main__":
    raise SystemExit(main())
