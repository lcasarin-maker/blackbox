#!/usr/bin/env python3
"""Bounded telemetry: measure the horizon SPEC declares, archive past it, and
report growth anomalies instead of waiting to notice a slow report.

SPEC section 8 carried "telemetry automated pruning/anomaly detection" as a
bounded horizon -- 2.8 MiB measured 2026-09-01, elevate at 10 MiB per repo or at
a measurable report slowdown. Nothing checked either threshold, so the horizon
was a number in prose and the first notice of crossing it would have been a slow
report nobody attributed to this. Built 2026-09-04 (DEBT-SPEC8-TELEMETRY-PRUNING).

PRUNE MEANS ARCHIVE, NEVER DELETE
---------------------------------
`telemetry_dispositions.derive_event_id` is CONTENT-ADDRESSED: a row's identity
is a sha256 of the row itself. Deleting a row therefore does not free space, it
orphans every disposition that cites it -- the ledger keeps a verdict about an
event nobody can produce any more. So old rows move to a gzip archive beside the
live file and stay resolvable. This is the same contract the standing suspension
rule states for hooks (rename, never delete) applied to rows.

WHAT THIS DOES NOT DO
---------------------
It does not run on a hook. Nothing prunes automatically, on purpose: an
unattended process that rewrites an evidence ledger is a worse failure than a
large file. `--gate` REPORTS over the threshold; a human runs `--apply`.
"""
from __future__ import annotations

import argparse
import gzip
import json
import shutil
import statistics
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos

EVIDENCE = Path(".simplecode") / "evidence"

# SPEC section 8's declared ceiling, per repo, across every telemetry ledger.
THRESHOLD_BYTES = 10 * 1024 * 1024

# The live ledgers reached the 10 MiB ceiling in 15 days on 2026-09-10. Keeping
# 90 live days would make the bound permanently red; seven live days preserve a
# useful recent operational window while older, content-addressed rows remain in
# the append-only gzip archive for longer forensic queries.
DEFAULT_KEEP_DAYS = 7

LEDGERS = (
    "telemetry.jsonl",
    "gate_failures.jsonl",
    "hook_receipts.jsonl",
    "telemetry_dispositions.jsonl",
    "telemetry_legacy_migration.jsonl",
)

# A day whose volume exceeds `median * _ANOMALY_FACTOR` AND clears this floor is
# reported. The floor exists because a median of 2 makes every ordinary day a
# 10x "anomaly"; the factor exists because a busy day is not news on its own.
_ANOMALY_FACTOR = 10
_ANOMALY_FLOOR = 100


def _rows(path: Path) -> list[dict]:
    """Parse a JSONL ledger, skipping unparseable lines rather than raising.

    A malformed line is COUNTED by `measure` as `unparseable`, never silently
    dropped: a ledger this tool cannot fully read is a fact the report states.
    """
    out: list[dict] = []
    if not path.is_file():
        return out
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict):
            out.append(obj)
    return out


def _unparseable(path: Path) -> int:
    if not path.is_file():
        return 0
    bad = 0
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            json.loads(line)
        except json.JSONDecodeError:
            bad += 1
    return bad


def _invalid_rows(path: Path) -> int:
    """Rows the archive writer cannot preserve as JSON objects."""
    if not path.is_file():
        return 0
    invalid = 0
    for line in path.read_bytes().decode("utf-8").splitlines():
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            invalid += 1
        else:
            invalid += int(not isinstance(obj, dict))
    return invalid


def _invalid_rows_or_error(path: Path) -> tuple[int | None, str | None]:
    try:
        return _invalid_rows(path), None
    except (OSError, UnicodeError) as exc:
        return None, f"cannot decode/read ledger safely: {exc}"


def _prune_input_problem(path: Path, name: str, apply: bool) -> dict | None:
    if not apply:
        return None
    invalid_rows, read_error = _invalid_rows_or_error(path)
    if read_error:
        return {
            "ledger": name, "present": True, "archived": 0,
            "kept": 0, "undated_kept": 0, "archive": None,
            "applied": False, "could_not_run": read_error,
        }
    if invalid_rows:
        return {
            "ledger": name, "present": True, "archived": 0,
            "kept": len(_rows(path)), "undated_kept": 0,
            "archive": None, "applied": False,
            "could_not_run": (
                f"{invalid_rows} non-empty line(s) are not JSON objects; "
                "refusing to rewrite and lose unparsed ledger content"
            ),
        }
    return None


def _ts(row: dict) -> datetime | None:
    raw = row.get("ts") or row.get("timestamp")
    if not isinstance(raw, str):
        return None
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def measure(root: Path) -> dict:
    """Sizes and row counts per ledger, plus the totals the threshold is about.

    Every ledger in `LEDGERS` appears in the result, including the ones that do
    not exist here -- a ledger that is absent is reported as absent, never
    folded into a total that reads as "nothing to prune".
    """
    ledgers = []
    for name in LEDGERS:
        path = root / EVIDENCE / name
        if not path.is_file():
            ledgers.append({"name": name, "present": False, "bytes": 0, "rows": 0,
                            "unparseable": 0, "oldest": None, "newest": None,
                            "unreadable": None})
            continue
        try:
            rows = _rows(path)
            stamps = sorted(t for t in (_ts(r) for r in rows) if t is not None)
            size = path.stat().st_size
            unparseable = _unparseable(path)
        except OSError as exc:
            # Present on disk but the OS refused to read it (permissions, a
            # race with a concurrent unlink): this ledger's bytes are NOT
            # measured, so it must not silently vanish into the total as 0.
            ledgers.append({"name": name, "present": True, "bytes": 0, "rows": 0,
                            "unparseable": 0, "oldest": None, "newest": None,
                            "unreadable": str(exc)})
            continue
        ledgers.append({
            "name": name,
            "present": True,
            "bytes": size,
            "rows": len(rows),
            "unparseable": unparseable,
            "oldest": stamps[0].isoformat() if stamps else None,
            "newest": stamps[-1].isoformat() if stamps else None,
            "unreadable": None,
        })
    total = sum(l["bytes"] for l in ledgers)
    return {
        "ledgers": ledgers,
        "total_bytes": total,
        "threshold_bytes": THRESHOLD_BYTES,
        "over_threshold": total > THRESHOLD_BYTES,
        "pct_of_threshold": round(100.0 * total / THRESHOLD_BYTES, 1),
        "unreadable_ledgers": [l for l in ledgers if l["unreadable"]],
    }


def detect_anomalies(root: Path, name: str = "telemetry.jsonl") -> list[dict]:
    """Days whose row volume is a large multiple of the median day.

    Reported, never blocking. A spike is a question ("what ran 40x that day?"),
    and a gate that answers questions by refusing the push is a gate people
    disable.
    """
    rows = _rows(root / EVIDENCE / name)
    per_day = Counter()
    for row in rows:
        stamp = _ts(row)
        if stamp is not None:
            per_day[stamp.date().isoformat()] += 1
    if len(per_day) < 3:
        return []
    median = statistics.median(per_day.values())
    return sorted(
        (
            {"day": day, "rows": count, "median_day": median,
             "factor": round(count / median, 1) if median else None}
            for day, count in per_day.items()
            if count >= _ANOMALY_FLOOR and median and count > median * _ANOMALY_FACTOR
        ),
        key=lambda a: a["rows"],
        reverse=True,
    )


def prune(root: Path, keep_days: int = DEFAULT_KEEP_DAYS, name: str = "telemetry.jsonl",
          apply: bool = False) -> dict:
    """Move rows older than `keep_days` into a gzip archive beside the ledger.

    With `apply=False` (the default) nothing is written and the result says what
    WOULD move -- a dry run is the only mode a gate ever invokes.

    Rows with no readable timestamp are KEPT, never archived: this function
    cannot tell an undated row's age, and archiving what it cannot date would be
    deciding by assumption exactly where the cost of being wrong is highest.
    """
    path = root / EVIDENCE / name
    if not path.is_file():
        return {"ledger": name, "present": False, "archived": 0, "kept": 0,
                "undated_kept": 0, "archive": None, "applied": False}

    input_problem = _prune_input_problem(path, name, apply)
    if input_problem:
        return input_problem

    cutoff = datetime.now(timezone.utc) - timedelta(days=keep_days)
    rows = _rows(path)
    old, keep, undated = [], [], 0
    for row in rows:
        stamp = _ts(row)
        if stamp is None:
            undated += 1
            keep.append(row)
        elif stamp < cutoff:
            old.append(row)
        else:
            keep.append(row)

    archive = path.with_suffix(f".jsonl.until-{cutoff.date().isoformat()}.gz")
    result = {
        "ledger": name, "present": True, "archived": len(old), "kept": len(keep),
        "undated_kept": undated, "archive": str(archive.relative_to(root)),
        "applied": False, "cutoff": cutoff.isoformat(),
    }
    if not apply or not old:
        return result

    # Append to the archive (a second prune on the same day must not clobber the
    # first), then rewrite the live ledger only once the archive is on disk.
    with gzip.open(archive, "at", encoding="utf-8") as fh:
        for row in old:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    tmp = path.with_suffix(".jsonl.tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        for row in keep:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    shutil.move(str(tmp), str(path))
    result["applied"] = True
    return result


def _mib(n: int) -> str:
    return f"{n / (1024 * 1024):.2f} MiB"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Bounded telemetry: measure, archive, flag spikes.")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--gate", action="store_true",
                    help="Exit 1 when the total is over the declared threshold.")
    ap.add_argument("--apply", action="store_true",
                    help="Actually archive (default is a dry run).")
    ap.add_argument("--keep-days", type=int, default=DEFAULT_KEEP_DAYS)
    ap.add_argument("--ledger", default="telemetry.jsonl")
    args = ap.parse_args(argv)
    root = args.root.resolve()

    m = measure(root)
    print(f"[telemetry] threshold: {_mib(m['threshold_bytes'])} per repo (SPEC section 8)")
    print(f"[telemetry] total: {_mib(m['total_bytes'])}  ({m['pct_of_threshold']}% of threshold)")
    for l in m["ledgers"]:
        if not l["present"]:
            print(f"  ABSENT   {l['name']}")
            continue
        if l["unreadable"]:
            print(f"  UNREADABLE   {l['name']}  ({l['unreadable']})")
            continue
        window = f"{(l['oldest'] or '?')[:10]} -> {(l['newest'] or '?')[:10]}"
        print(f"  {_mib(l['bytes']):>10}  {l['rows']:>6} rows  {window}  {l['name']}"
              + (f"  [unparseable: {l['unparseable']}]" if l["unparseable"] else ""))

    if m["unreadable_ledgers"]:
        first = m["unreadable_ledgers"][0]
        print(
            f"[telemetry-bound] COULD_NOT_RUN: {len(m['unreadable_ledgers'])} ledger(s) "
            f"could not be read, so their size is NOT in the total above; "
            f"first {first['name']} ({first['unreadable']})",
            file=sys.stderr,
        )

    anomalies = detect_anomalies(root, args.ledger)
    emit_hallazgos("[telemetry]", len(anomalies))
    print(f"[telemetry] volume anomalies in {args.ledger}: {len(anomalies)}"
          f" (a day is flagged over {_ANOMALY_FACTOR}x the median day and >= {_ANOMALY_FLOOR} rows)")
    for a in anomalies[:5]:
        print(f"  SPIKE {a['day']}: {a['rows']} rows ({a['factor']}x the median day of {a['median_day']})")

    p = prune(root, keep_days=args.keep_days, name=args.ledger, apply=args.apply)
    if p.get("could_not_run"):
        print(f"[telemetry-bound] COULD_NOT_RUN: {p['could_not_run']}", file=sys.stderr)
        return 2
    verb = "archived" if p["applied"] else "would archive"
    print(f"[telemetry] {verb} {p['archived']} row(s) older than {args.keep_days}d "
          f"from {args.ledger}; keeping {p['kept']}"
          + (f" ({p['undated_kept']} undated, kept because their age is unknown)"
             if p["undated_kept"] else ""))
    if p["archived"] and not p["applied"]:
        print(f"[telemetry] dry run. `--apply` writes {p['archive']} (gzip, append-only). "
              "Rows are ARCHIVED, never deleted: event_ids are content-addressed, so a "
              "deleted row orphans every disposition citing it.")

    if m["over_threshold"]:
        print(f"[telemetry] OVER THRESHOLD: {_mib(m['total_bytes'])} > {_mib(m['threshold_bytes'])}")
        largest = max((l for l in m["ledgers"] if l["present"] and not l["unreadable"]),
                      key=lambda l: l["bytes"], default=None)
        detail = (f"; largest ledger {largest['name']} {_mib(largest['bytes'])} "
                  f"({largest['rows']} rows)") if largest else ""
        # Name the fix, not only the culprit: `--apply` rotates ONE ledger (`--ledger`,
        # default telemetry.jsonl), so the ledger that is actually over is not the
        # one the bare command would touch (aequitas_os, 2026-09-26: gate_failures.jsonl
        # weighed 4.12 MiB in 7 days, the default ledger was not the problem).
        fix = (f"; fix: python .simplecode/run.py simplecode.verification.telemetry_prune "
               f"--root . --ledger {largest['name']} --keep-days 3 --apply") if largest else ""
        print(
            f"[telemetry-bound] FAIL: {_mib(m['total_bytes'])} total over the "
            f"{_mib(m['threshold_bytes'])} ceiling{detail}{fix}",
            file=sys.stderr,
        )
        return 1 if args.gate else 0
    print("[telemetry] OK: under the declared threshold.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
