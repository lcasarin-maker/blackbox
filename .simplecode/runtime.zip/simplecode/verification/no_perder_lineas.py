#!/usr/bin/env python3
"""Ninguna entrada trackeada del ledger pierde lineas respecto a HEAD. Sale 1 si alguna lo hace.

Lo propuso la sesion 020 tras perder DOS VECES la misma seccion de 54 lineas en
`office2office`, y su argumento es por que este control gana a los que yo tenia:

    «tu control dice `respetadas=101` sobre entradas que ya existian. Ese numero no distingue
    "no sobreescribi" de "no llegue a correr sobre ese repo". El control que habria cazado esto
    es mas barato: comparar la entrada en disco contra la que hay en HEAD y exigir que ninguna
    PIERDA lineas. Un diff de solo borrados sobre una entrada trackeada es la firma exacta de
    este defecto, y no depende de que la entrada sea open, done, ni de que tenga evidence.»

Los tres controles que tuve antes miraban una PROPIEDAD de la entrada —`status`, `evidence`, su
existencia— y por eso cada uno se lo salto una forma distinta del mismo defecto. Este mira el
EFECTO, que es lo unico comun a las tres.

Uso:
    python -m simplecode.verification.no_perder_lineas --root .

Migrado el 2026-09-04 de `gates/no_perder_lineas.py`, copiado sin pasar por
`cli_new`/`satellite_sync` a cada satelite. Como modulo de `simplecode.verification`, viaja en
runtime.zip y ningun satelite vuelve a tener su propia copia que pueda divergir; `--root`
reemplaza el `ROOT` resuelto por `__file__` que asumia vivir siempre en `<repo>/gates/`.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.verification import ledger_schema

# Las MISMAS carpetas y las MISMAS omisiones que `ledger_schema.py`. Que los dos organos lean
# el mismo sujeto no es estetica: dos gates que miden lo mismo sobre conjuntos distintos es el
# molde (c) de Atlas, el caro, y aqui se materializo en su forma pura -- durante semanas esto
# hizo `ENTRIES.glob("*.md")`, no recursivo, sobre una carpeta cuyas fichas viven todas en
# `tasks/backlog/` y `tasks/done/`. El gate imprimia `revisadas=0 pierden=0` y salia verde.
# El 2026-09-02 borre 30 fichas y reescribi 86 punteros bajo `tasks/` y no dijo una palabra:
# no podia, su conjunto estaba vacio por construccion.
# DERIVADAS de `ledger_schema`, no copiadas. Las tres listas eran literales identicos en los
# dos modulos, y un literal duplicado entre dos organos que miden el MISMO sujeto es el molde
# (c) esperando su turno: el dia que alguien anada una carpeta a uno y no al otro, los dos
# siguen verdes y discrepan sobre que fichas existen. Ya paso una vez aqui en su forma pura
# (ver el parrafo de arriba), y la copia no habria dicho nada.
#
# `ledger_schema` es la fuente porque es quien DEFINE los estados: `ANULADAS` es lo anulado
# y `NO_FICHAS` lo que nunca fue ficha. Este modulo no tiene opinion propia sobre eso.
GOBERNADAS = ledger_schema.GOBERNADAS
OMITIR = ledger_schema.OMITIR
NO_GOBERNADAS_EXENTAS = (*ledger_schema.ANULADAS, *ledger_schema.NO_FICHAS)


def _fichas_en_juego(entries: Path) -> tuple[list[Path], list[Path]]:
    """Las fichas que ESTE gate compara, y las que quedan fuera de su conjunto.

    Separado de `main` porque es la pregunta que ya se contesto mal una vez, y
    se contesto mal en silencio: durante semanas el conjunto era vacio por
    construccion (un `glob` no recursivo sobre una carpeta cuyas fichas viven
    en subcarpetas) y el gate salia verde. La medicion y el conjunto sobre el
    que se mide son dos cosas distintas, y ahora fallan por separado.
    """
    candidatas = sorted(f for c in GOBERNADAS for f in (entries / c).glob("*.md")
                        if f.name not in OMITIR)
    sin_gobernar = sorted(
        f for f in entries.rglob("*.md")
        if f.name not in OMITIR
        and (f.parent == entries or f.parent.name not in (*GOBERNADAS, *NO_GOBERNADAS_EXENTAS))
    )
    return candidatas, sin_gobernar


def _medir_perdidas(root: Path, candidatas: list[Path]) -> tuple[int, int, list[str]]:
    """Compara cada ficha contra HEAD. Devuelve (revisadas, perdidas, detalle).

    `revisadas` NO es `len(candidatas)`: una ficha sin trackear no tiene con
    que comparar y no se cuenta. Esa diferencia es lo que `main` publica como
    AVISO, y es la razon de devolver las dos cifras en vez de un veredicto:
    quien mide no decide, y quien decide ve el hueco.
    """
    revisadas = perdidas = 0
    detalle: list[str] = []
    for f in candidatas:
        rel = f.relative_to(root)
        # check=False, explicit: a nonzero rc here means "not tracked at HEAD",
        # which the next line reads as "nothing to compare", not as an error.
        r = subprocess.run(["git", "show", f"HEAD:{rel}"], cwd=root,
                           capture_output=True, text=True, check=False)
        if r.returncode != 0:
            continue                      # sin trackear: no hay con que comparar, no es perdida
        revisadas += 1
        # check=False, explicit: an empty/failed numstat falls through to the
        # `len(d) < 2` guard below rather than raising.
        d = subprocess.run(["git", "diff", "--numstat", "HEAD", "--", str(rel)],
                           cwd=root, capture_output=True, text=True,
                           check=False).stdout.split()
        if len(d) < 2 or not d[0].isdigit():
            continue
        anadidas, borradas = int(d[0]), int(d[1])
        # La firma es **borrados con CERO inserciones**, tal como la formulo 020. Una linea
        # SUSTITUIDA da 1 y 1 y no es perdida: la reparacion de fechas del 2026-09-02 cambio
        # `created` en 747 entradas y una version anterior de este gate la marco a las 747 como
        # perdida. Un control que no distingue sustituir de borrar convierte cada correccion
        # legitima en una alarma, y una alarma que suena siempre se apaga.
        if borradas > 0 and anadidas == 0:
            perdidas += 1
            detalle.append(f"PIERDE {rel}: {borradas} linea(s) borradas y 0 anadidas")
    return revisadas, perdidas, detalle


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    args = ap.parse_args(argv)
    root = args.root
    entries = root / "tasks"
    if not entries.is_dir():
        print(f"could_not_run: {entries} no existe")
        print(f"[no-perder-lineas] COULD_NOT_RUN: {entries} no existe", file=sys.stderr)
        return 1
    could_not_run = 0
    candidatas, sin_gobernar = _fichas_en_juego(entries)
    revisadas, perdidas, detalle = _medir_perdidas(root, candidatas)

    # Un instrumento sin sujeto NO esta verde: esta sin correr. Sin esta rama, la version
    # anterior de este gate era indistinguible de una que hubiera revisado todo y no hallado
    # nada -- y durante semanas fue exactamente lo segundo lo que aparento ser.
    if not candidatas:
        could_not_run = 1
        detalle.append(f"SIN SUJETO: 0 fichas bajo {'/, '.join(GOBERNADAS)}/ en {entries}")
    # `revisadas < candidatas` NO bloquea (a proposito): la causa mas comun es una ficha nueva,
    # todavia sin comitear -- legitima, y sin historia contra la que comparar, asi que "no se
    # perdio nada" es cierto y no un hueco. Pero declutter midio (2026-09-04) un caso distinto:
    # justo despues de un `git mv` sin commitear, 17 candidatas SIN revisar dieron
    # `could_not_run=0` y veredicto limpio -- la MISMA firma que un renombrado en curso Y una
    # ficha nueva, sin forma barata de distinguirlas aqui. La respuesta no es bloquear (eso
    # convertiria cada ficha nueva sin comitear en un falso rojo) sino DECIRLO: un lector que
    # solo mira `pierden=0` no debe leer "verde" donde el propio numero ya dice que faltan.
    if candidatas and revisadas < len(candidatas):
        faltan = len(candidatas) - revisadas
        detalle.append(f"AVISO: {faltan} candidata(s) sin comparar contra HEAD (sin comitear "
                       "todavia, o recien renombradas) -- este veredicto no las cubre")
    if sin_gobernar:
        could_not_run = 1
        detalle.append(f"SIN GOBERNAR: {len(sin_gobernar)} ficha(s) fuera de "
                       f"{'/, '.join(GOBERNADAS)}/ no revisadas: "
                       + ", ".join(str(f.relative_to(entries)) for f in sin_gobernar[:10]))

    print(f"candidatas={len(candidatas)} revisadas={revisadas} pierden={perdidas} "
          f"could_not_run={could_not_run}")
    emit_hallazgos("[no-perder-lineas]", perdidas)
    for d in detalle[:60]:
        print(f"  {d}")

    if perdidas:
        # detalle[0] is guaranteed to be the first PIERDE entry whenever
        # perdidas > 0: PIERDE lines are appended inside the per-candidata
        # loop above, before any SIN SUJETO/AVISO/SIN GOBERNAR line is ever
        # appended -- so it is always the earliest, concrete offending path.
        print(f"[no-perder-lineas] FAIL: {perdidas} ficha(s) pierden lineas respecto a HEAD; "
              f"primero {detalle[0]}")
    if could_not_run:
        motivo = next((d for d in detalle if d.startswith("SIN SUJETO") or d.startswith("SIN GOBERNAR")),
                      "instrumento no pudo cubrir su conjunto de fichas")
        print(f"[no-perder-lineas] COULD_NOT_RUN: {motivo}", file=sys.stderr)

    return 1 if (perdidas or could_not_run) else 0


if __name__ == "__main__":
    raise SystemExit(main())
