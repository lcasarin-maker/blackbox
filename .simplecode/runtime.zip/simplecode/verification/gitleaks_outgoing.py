"""Run the pinned gitleaks hook against commits a pre-push will publish."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml

_ZERO_OIDS = {"0" * 40, "0" * 64}
_GITLEAKS_REPO = "https://github.com/gitleaks/gitleaks"


def _git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args], cwd=root, capture_output=True, text=True, check=False,
    )


def _commit_exists(root: Path, oid: str) -> bool:
    return bool(oid) and _git(root, "cat-file", "-e", f"{oid}^{{commit}}").returncode == 0


def _scan_specs(root: Path, refs_text: str) -> list[str]:
    """Return safe per-ref log options; uncertainty falls back to all history."""
    refs: list[tuple[str, str]] = []
    if not refs_text:
        return ["--all"]
    for line in refs_text.rstrip(",").split(","):
        fields = line.split(":")
        if len(fields) != 2:
            return ["--all"]
        local_oid, remote_oid = fields
        if (len(local_oid) not in {40, 64} or len(remote_oid) not in {40, 64}
                or any(ch not in "0123456789abcdefABCDEF" for ch in local_oid + remote_oid)):
            return ["--all"]
        if local_oid not in _ZERO_OIDS:
            refs.append((local_oid, remote_oid))
    if not refs:
        return []

    specs: list[str] = []
    for local_oid, remote_oid in refs:
        if not _commit_exists(root, local_oid) or remote_oid in _ZERO_OIDS:
            return ["--all"]
        if not _commit_exists(root, remote_oid):
            return ["--all"]
        specs.append(f"{local_oid} ^{remote_oid}")
    return specs


def _gitleaks_config(root: Path, log_opts: str) -> str:
    canonical = yaml.safe_load(
        (root / ".pre-commit-config.yaml").read_text(encoding="utf-8")
    )
    repo = next(
        (entry for entry in canonical.get("repos", [])
         if entry.get("repo") == _GITLEAKS_REPO),
        None,
    )
    if not repo or not repo.get("rev"):
        raise ValueError("canonical config has no pinned gitleaks repository")
    hook = {
        "id": "gitleaks",
        "name": "gitleaks (outgoing commits)",
        "args": ["--no-banner", "--redact", "--pre-commit=false", "--staged=false",
                 f"--log-opts={log_opts}"],
        "stages": ["pre-push"],
        "pass_filenames": False,
    }
    return yaml.safe_dump(
        {"fail_fast": False, "repos": [{"repo": _GITLEAKS_REPO,
          "rev": repo["rev"], "hooks": [hook]}]},
        sort_keys=False,
    )


def scan_outgoing(root: Path, runner: str, refs_text: str) -> int:
    specs = _scan_specs(root, refs_text)
    if not specs:
        print("[gitleaks-outgoing] no commits in pushed refs")
        return 0
    for spec in specs:
        with tempfile.TemporaryDirectory(prefix="simplecode-gitleaks-") as tmp:
            config = Path(tmp) / ".pre-commit-config.yaml"
            config.write_text(_gitleaks_config(root, spec), encoding="utf-8")
            result = subprocess.run(
                [runner, "run", "--config", str(config), "--hook-stage", "pre-push",
                 "--all-files"],
                cwd=root,
                check=False,
            )
        if result.returncode:
            return result.returncode
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--runner", required=True, help="prek or pre-commit executable")
    args = parser.parse_args(argv)
    refs_text = os.environ.get("SIMPLECODE_PUSH_REFS", "")
    try:
        return scan_outgoing(args.root.resolve(), args.runner, refs_text)
    except (OSError, UnicodeError, ValueError, yaml.YAMLError) as exc:
        print(f"[gitleaks-outgoing] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
