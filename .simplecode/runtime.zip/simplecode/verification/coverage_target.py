# -*- coding: utf-8 -*-
"""coverage_target.py -- resolve `pytest --cov=<target>` for the coverage-floor gate.

The canonical .pre-commit-config.yaml is one byte-identical string synced to
every satellite (satellite_sync._sync_config_file compares it verbatim), so
the `coverage-floor` hook entry cannot hardcode a per-repo `--cov=` path --
`--cov=src` measured 0% forever on any satellite without a `src/` layout
(office2office, blog_ciudadano_x, red_python, sistemas_estocasticos_ruleta,
cuenza all hit this, 2026-08-24/25 fleet dogfooding). This module resolves
the real target at RUN time instead, so the config text stays universal.
"""
from __future__ import annotations

import ast
import functools
import json
import os
import re
import subprocess
import sys
import warnings
from pathlib import Path
from typing import NamedTuple

import yaml

from simplecode.utils.tool_limits import VERSION_PROBE_TIMEOUT
from simplecode.utils.tool_limits import WORKERS_ENV as WORKERS_ENV
from simplecode.utils.tool_limits import xdist_workers as _xdist_workers
from simplecode.utils.unified_memory_slots import unified_memory_slots

# Measured live on this repo's own suite (2026-08-31): serial 156.4s ->
# parallel 58.1s/58.9s/27.7s across several worker counts. The REAL hazard
# isn't CPU/IO contention (that theory didn't survive contact with a second
# real push failure) -- it's that a handful of tests, marked
# `mutates_real_source`, temporarily write to a REAL file under
# src/simplecode/ (not tmp_path) to prove a real patch/restore cycle. Any
# xdist worker reading the whole source tree at that exact instant (this
# module's own `--cov` collection; satellite_sync._runtime_bundle scanning
# every source file) can catch a momentarily-modified file and produce a
# genuinely different result -- non-deterministic by construction, not
# something a lower worker count reliably avoids (confirmed: a SEPARATE
# test than the first one found still flaked at -n 4 on a later real push).
# Fixed by running those tests in their own SERIAL phase -- see main().
#
# The `min(4, ...)` cap that used to sit here was never re-measured after
# that fix landed: the non-determinism it guarded against is now handled by
# the phase split above, not by a low worker count, so the cap was pure
# unmeasured caution. Re-measured 2026-09-08 on a 20-core machine, full
# suite (`pytest -q -n <N> -m "not mutates_real_source"`, all passing at
# every count): -n 4 -> 54.0s, -n 10 -> 45.6s, -n 20 -> 31.8s. Uncapped
# `os.cpu_count()` -- the same value `-n auto` would pick -- cut the
# dominant cost of the pre-push suite by ~41% over the old cap, with no
# correctness change on a smaller machine (a 4-core box still gets 4).
#
# WORKERS_ENV/_xdist_workers moved to simplecode.utils.tool_limits (2026-09-21):
# backlog_verifier.audit_closed_tasks needs the identical knob for the identical reason, and
# tool_limits.py is the shared home both modules already import from. Re-exported here by
# name so every existing caller/test of this module keeps working unchanged.

_XDIST_WORKERS = _xdist_workers()
_MUTATES_REAL_SOURCE_MARKER = "mutates_real_source"

_EXCLUDED_TOP_LEVEL = {
    ".git", ".venv", "venv", "env", "node_modules", ".simplecode", "tasks",
    "docs", "dist", "build", "htmlcov", "tests", "test",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox",
}


@functools.lru_cache(maxsize=8)
def _load_configured_targets(root: Path) -> tuple[str, ...]:
    """Project-local, opt-in `--cov=` targets (same pattern as corpus_exempt.yaml).

    Read from ``<root>/.simplecode/corpus_exempt.yaml``, key
    ``coverage_targets``. Absent file/key -> fall through to auto-detection,
    so a repo only needs this when auto-detection would guess wrong (e.g. a
    src/ directory that isn't the package, or a package that must be excluded
    from coverage on purpose).
    """
    config = root / ".simplecode" / "corpus_exempt.yaml"
    if not config.is_file():
        return ()
    try:
        data = yaml.safe_load(config.read_text(encoding="utf-8")) or {}
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return ()
    if not isinstance(data, dict) or "coverage_targets" not in data:
        return ()
    targets = data["coverage_targets"]
    # DEBT-SURVEY-LIMITS-DISCOVERED-BY-COLLISION (Descargasat): a wrong shape
    # here (a dict instead of a list, non-string entries) used to fall through
    # to auto-detection in total silence -- the author's `coverage_targets`
    # was simply never read, and nothing said so or named the shape expected.
    valid = isinstance(targets, list) and all(
        isinstance(t, str) and t.strip() for t in targets
    )
    if not valid:
        print(
            f"[coverage-target] {config}: coverage_targets tiene forma invalida "
            f"({targets!r}) -- se esperaba una lista de strings no vacios, ej. "
            '["src"]. Se ignora y se cae a auto-deteccion.',
            file=sys.stderr,
        )
        return ()
    # DEBT-GATE-ENGANABLE-COVERAGE-FLOOR (auditoria 2026-09-26): nada validaba
    # que el objetivo declarado fuera PRODUCTO. `coverage_targets: [tests]`
    # medía los propios tests (100% por construccion) y el gate pasaba con el
    # producto al 41.67%. Un objetivo que no es producto se descarta en voz
    # alta; si no queda ninguno, se cae a auto-deteccion como con la forma
    # invalida de arriba -- el sujeto vuelve a ser el codigo, no el atajo.
    kept = []
    for target in (str(t) for t in targets):
        reason = _non_product_reason(root, target)
        if reason is None:
            kept.append(target)
            continue
        print(
            f"[coverage-target] {config}: coverage_targets descarta {target!r} -- "
            f"{reason}. El piso de cobertura mide producto, no eso.",
            file=sys.stderr,
        )
    return tuple(kept)


_TEST_DIR_NAMES = {"tests", "test"}


def _is_test_file(path: Path) -> bool:
    name = path.name
    return name == "conftest.py" or name.startswith("test_") or name.endswith("_test.py")


def _non_product_reason(root: Path, target: str) -> str | None:
    """Why `target` is not product code to measure, or None if it may be.

    Three shapes, each one a way to change the SUBJECT instead of covering it:
    a test directory by name (`tests`, `pkg/tests`, `pkg.tests`), the repo
    root or anything outside it (`.` dilutes the product with the tests'
    own ~100%), and a directory whose Python files are all tests under
    another name (`checks/test_x.py`). A target that exists neither as a path
    nor as `<target>.py` -- e.g. a dotted module name -- is left alone.

    Cuarta forma: producto por nombre y por forma que NINGUN archivo de test
    importa (un stub al 100% declarado en lugar del paquete real). Se resuelve
    el nombre importable del objetivo (`src/pkg` -> `pkg`; un directorio sin
    `__init__.py` como `src` aporta su nombre y los de sus hijos) y se busca,
    con `ast`, en los `import`/`from ... import` y en las cadenas con forma de
    modulo (`importlib.import_module("pkg")`, `-m pkg`) de cada `.py` de test.
    Un repo sin ningun archivo de test no se juzga aqui: no hay importador a
    quien preguntar, y el propio piso ya bloquea sin suite que lo cubra.
    Lo que esto NO cubre: un stub que algun test importa (aunque no ejercite
    nada) sigue pasando, y un subpaquete alcanzado solo transitivamente por el
    import de su padre se descarta en voz alta aunque este cubierto.
    """
    if _TEST_DIR_NAMES.intersection(re.split(r"[/\\.]", target)):
        return "es un directorio de tests"
    # Lexico (normpath), no `resolve()`: un `vendor/` enlazado fuera del repo
    # es producto vendorizado legitimo y no debe leerse como "fuera".
    relative = os.path.normpath(target)
    if relative == "." or relative.startswith("..") or os.path.isabs(relative):
        return "es la raiz del repo o queda fuera de el"
    candidate = root / relative
    if not candidate.exists():
        candidate = candidate.with_name(candidate.name + ".py")
    if candidate.is_dir():
        py_files = list(candidate.rglob("*.py"))
        if not py_files:
            return None
        if all(_is_test_file(p) for p in py_files):
            return "todos sus .py son archivos de test"
    elif not (candidate.is_file() and candidate.suffix == ".py"):
        return None
    referenced = _test_referenced_modules(root)
    if referenced is None:
        return None
    names = _importable_names(candidate)
    if not any(m == n or m.startswith(n + ".") for n in names for m in referenced):
        return "ningun archivo de test lo importa"
    return None


_WALK_PRUNE = _EXCLUDED_TOP_LEVEL - _TEST_DIR_NAMES
_DOTTED = re.compile(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*")


def _dotted_name(path: Path) -> str:
    """Nombre importable de un paquete o modulo: sube mientras el padre sea paquete."""
    parts = [path.stem if path.suffix == ".py" else path.name]
    parent = path.parent
    while (parent / "__init__.py").is_file():
        parts.insert(0, parent.name)
        parent = parent.parent
    return ".".join(parts)


def _importable_names(candidate: Path) -> set[str]:
    """Nombres con los que un test importaria `candidate`. Un directorio sin
    `__init__.py` (`src/`, un namespace) tambien aporta los de sus hijos."""
    names = {_dotted_name(candidate)}
    if candidate.is_dir() and not (candidate / "__init__.py").is_file():
        for child in candidate.iterdir():
            if child.is_dir() and child.name not in _EXCLUDED_TOP_LEVEL:
                names.add(child.name)
            elif child.suffix == ".py" and not _is_test_file(child):
                names.add(child.stem)
    return names


def _test_referenced_modules(root: Path) -> set[str] | None:
    """Modulos que los archivos de test de `root` nombran, o None si no hay
    ningun archivo de test. Cuenta como test todo `.py` con nombre de test y
    todo `.py` bajo un directorio `tests`/`test` (sus helpers importan producto)."""
    found: set[str] | None = None
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _WALK_PRUNE and not d.startswith(".")]
        in_test_dir = bool(_TEST_DIR_NAMES.intersection(Path(dirpath).relative_to(root).parts))
        for name in filenames:
            path = Path(dirpath, name)
            if name.endswith(".py") and (in_test_dir or _is_test_file(path)):
                found = (found or set()) | _referenced_modules(path)
    return found


def _referenced_modules(path: Path) -> set[str]:
    try:
        # Solo leemos imports: los SyntaxWarning del archivo ajeno (escapes
        # invalidos en sus cadenas) son ruido en la salida del gate.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", SyntaxWarning)
            tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, SyntaxError, ValueError):
        return set()
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            found.add(node.module)
            found.update(f"{node.module}.{alias.name}" for alias in node.names)
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and _DOTTED.fullmatch(node.value):
            found.add(node.value)
    return found


def _auto_detect_targets(root: Path) -> tuple[str, ...]:
    """`src/` if present AND it actually holds Python source (the common
    case, and this repo's own layout); otherwise every top-level directory
    that is a real Python package (contains an `__init__.py`), excluding
    well-known non-source dirs.

    A bare `is_dir()` check previously accepted any `src/` directory, even
    one holding only non-Python assets (reported live against a consuming
    repo whose `src/` contained a single PNG and no code) -- `--cov=src`
    against such a target silently measures 0% forever, the same failure
    mode several satellites already had to work around by hand-declaring
    `coverage_targets` in `.simplecode/corpus_exempt.yaml`.
    """
    src_dir = root / "src"
    if src_dir.is_dir() and next(src_dir.rglob("*.py"), None) is not None:
        return ("src",)
    detected = []
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name in _EXCLUDED_TOP_LEVEL or child.name.startswith("."):
            continue
        if (child / "__init__.py").is_file():
            detected.append(child.name)
    return tuple(detected)


def resolve_targets(root: Path) -> tuple[str, ...]:
    configured = _load_configured_targets(root)
    return configured if configured else _auto_detect_targets(root)


def _clear_stale_coverage_data(root: Path) -> None:
    """Reported live (2026-08-31): a `.coverage` (or xdist-parallel
    `.coverage.<host>.<pid>.<rand>`) file orphaned by an earlier interrupted
    run silently corrupted this run's `--cov-append` combine -- coverage.py
    merged stale partial data alongside phase 1's fresh data, undercounting
    lines that phase 1 covers now but the stale file never saw. Two-phase
    accumulation depends on starting from a genuinely clean slate; a single
    non-appending run never had this exposure (it always starts fresh)."""
    for stale in [root / ".coverage", *root.glob(".coverage.*")]:
        stale.unlink(missing_ok=True)


_PYTEST_NO_TESTS_COLLECTED = 5

# One probe answers everything this module needs to know about the interpreter
# that will RUN the suite: its version (for the banner), whether it can even
# import pytest (a candidate that cannot is not a candidate), whether it has
# xdist (which decides the two-phase split), and the marker expression the
# REPOSITORY itself declares. Asking the PARENT process any of these -- as
# this module did until 2026-09-05 -- measures the wrong process; see
# `_resolve_suite_interpreter`.
#
# `markexpr` is obtained by ASKING pytest, never by parsing ini files. pytest
# already resolves pytest.ini / pyproject.toml / tox.ini / setup.cfg, their
# precedence, rootdir discovery, and the PYTEST_ADDOPTS environment variable
# (measured 2026-09-05 in own_chats: `PYTEST_ADDOPTS='-m "not integration"'`
# comes back as exactly `not integration`, and a directory with no ini at all
# comes back as `""`). A hand-rolled reader would have to reproduce all of
# that and would get it wrong SILENTLY -- the same wrong-subject family this
# module already carries two fixes for. `pytest_cmdline_main` returning 0
# short-circuits before collection, so the probe imports no test module and
# costs one interpreter start (measured 0.126 s in own_chats).
_PROBE = """
import json, sys, importlib.util as u
info = {
    'version': sys.version.split()[0],
    'pytest': u.find_spec('pytest') is not None,
    'xdist': u.find_spec('xdist') is not None,
}
if info['pytest']:
    import contextlib, io, pytest

    seen = {}

    class _Ask:
        def pytest_cmdline_main(self, config):
            seen['m'] = config.option.markexpr
            return 0

    try:
        noise = io.StringIO()
        with contextlib.redirect_stdout(noise), contextlib.redirect_stderr(noise):
            pytest.main([], plugins=[_Ask()])
    except BaseException:
        pass
    if 'm' in seen:
        info['markexpr'] = seen['m']
print(json.dumps(info))
"""


def _probe_interpreter(executable: str, cwd: Path | None = None) -> dict | None:
    """What `executable` is, what it can import, and what marker filter the
    repository at `cwd` declares -- or None if it cannot run.

    `cwd` is load-bearing: the marker expression is a property of the
    REPOSITORY, and pytest resolves it from the directory it starts in.
    """
    try:
        probe = subprocess.run(
            [executable, "-c", _PROBE], capture_output=True, text=True, check=False,
            timeout=VERSION_PROBE_TIMEOUT, cwd=None if cwd is None else str(cwd),
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if probe.returncode != 0:
        return None
    # The LAST line, not the whole stream: building a pytest config imports the
    # repository's root conftest.py, and one that prints on import would
    # otherwise turn a perfectly healthy interpreter into a COULD_NOT_RUN.
    lines = probe.stdout.strip().splitlines()
    if not lines:
        return None
    try:
        info = json.loads(lines[-1])
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None
    return info if isinstance(info, dict) else None


def _compose_markexpr(repo_markexpr: str | None, own: str) -> str:
    """`own`, INTERSECTED with whatever filter the repository declares.

    pytest's `-m` is a *store* option: a `-m` on the command line REPLACES the
    `-m` inside `addopts`, it does not intersect with it. This gate therefore
    used to silently widen the suite it measured. Measured 2026-09-05 in the
    own_chats satellite, whose `addopts` carries `-m "not slow and not e2e"`:

        $ pytest -q --collect-only                              -> 235/237 (2 deselected)
        $ pytest -q --collect-only -m "not mutates_real_source"  -> 237 tests collected

    The two extra tests each hold a lock for 62 s on purpose. Worse than the
    clock: with pytest-xdist installed the gate measured 237 tests and without
    it 235, so `.coverage_watermark` was comparing numbers from two different
    subjects across machines without knowing it.
    """
    if not repo_markexpr:
        return own
    return f"({repo_markexpr}) and ({own})"


def _resolve_suite_interpreter(root: Path) -> tuple[str, dict | None]:
    """The interpreter that will actually run the suite, plus what it holds.

    This module used to launch the suite as the BARE NAME `pytest`, which
    resolves through PATH and therefore names no interpreter at all. Measured
    2026-09-05 in the `own_chats` satellite, whose package is installed
    editable only in its own `.venv`, from a shell whose PATH does not carry
    that `.venv`:

        $ which -a pytest        -> /home/lcasarin/.local/bin/pytest
        $ head -1 <that file>    -> #!/opt/miniforge3/bin/python3.12
        $ pytest --collect-only -q
          27 tests collected, 17 errors in 0.21s
        $ .venv/bin/python -m pytest --collect-only -q
          225/227 tests collected (2 deselected) in 0.44s

    Run end to end on a copy of that satellite, the pre-fix gate reported
    `27 passed, 17 errors`, wrote percent_covered 0.0 and exited 1; the same
    gate with this resolution reports `228 passed, 2 deselected` and 43.46%
    against the 43.46 watermark, exit 0. It did block -- but on seventeen
    import errors in a subject nobody chose to measure, not on coverage, and
    the number it published was measured against that wrong subject.

    `sys.executable` alone does not close it either: this module runs under
    whatever python launched `.simplecode/run.py`, which under a PATH without
    the repo's `.venv` is that same system interpreter. So the repo's own
    `.venv` is tried FIRST, and only kept if it can import pytest -- a repo
    with a stale or partial `.venv` falls back to `sys.executable` and behaves
    exactly as it did before this existed, rather than breaking its push.
    """
    candidates: list[str] = []
    venv_python = root / ".venv" / "bin" / "python"
    if venv_python.is_file() or venv_python.is_symlink():
        candidates.append(str(venv_python))
    if sys.executable and sys.executable not in candidates:
        candidates.append(sys.executable)
    fallback: dict | None = None
    for candidate in candidates:
        info = _probe_interpreter(candidate, cwd=root)
        if info is not None and info.get("pytest"):
            return candidate, info
        if candidate == sys.executable:
            fallback = info
    return sys.executable, fallback


class _Suite(NamedTuple):
    """How the suite is launched, and what the repository itself already filters.

    One value rather than two parameters: `_run_two_phase` is called
    positionally as `(root, cov_args, coverage_json, argv)` by three tests in
    `tests/test_coverage_ratchet.py`, and a sixth parameter also trips this
    project's own PLR0913 gate -- which this repo answers by restructuring, not
    by a `noqa` (there is not one in the tree).
    """

    cmd: list[str]
    markexpr: str | None = None


def _run_two_phase(root: Path, cov_args: list[str], coverage_json: Path, argv: list[str],
                   suite: _Suite | None = None) -> subprocess.CompletedProcess:
    """Phase 1: the bulk suite in parallel, EXCLUDING anything marked
    `mutates_real_source`. Phase 2: just those tests, fully serial (no `-n`
    at all -- xdist_group only keeps a marked group together on one worker,
    it does nothing to stop an UNRELATED worker from reading the source
    tree at the same moment). `--cov-append` on phase 2 combines with
    phase 1's coverage data before the final JSON report is written.
    Phase 1's own failure short-circuits -- phase 2 not worth running
    against a suite that's already red.

    Reported live (2026-08-31): phase 1 is INCOMPLETE by design (it
    excludes the mutates_real_source tests), so it always measures under
    100% -- and `pyproject.toml`'s `[tool.coverage.report] fail_under = 100`
    applies to EVERY coverage report coverage.py generates regardless of
    whether `--cov-fail-under` was passed on the command line, so simply
    not forwarding the caller's own flag wasn't enough: the ini/toml default
    still failed phase 1 on its own necessarily-partial view, short-
    circuiting before phase 2 ever got to add the missing coverage. An
    explicit `--cov-fail-under=0` is what actually overrides the config
    default (CLI flags win over ini/toml in coverage.py) -- only the
    COMBINED result (after phase 2's --cov-append) is meaningful against a
    real threshold; phase 1 must be judged on real test failures only.

    `suite.cmd` is the interpreter-anchored launch prefix built by `main`
    (`[<interpreter>, "-m", "pytest"]`). `suite` is last and optional so the
    existing positional call shape keeps working; the fallback is still an
    explicit interpreter, never the bare name `pytest`.

    `suite.markexpr` is the repository's OWN `-m`, read off the same probe. Both
    phases intersect with it instead of replacing it (see `_compose_markexpr`),
    so phase 1 + phase 2 add up to exactly the set of tests the repository
    declares -- the same set the serial path measures. Without that, the two
    paths measured different subjects and the watermark compared them anyway.

    Phase 2 pins `-n 0` rather than merely omitting `-n`. `-n` is a *store*
    option too: a satellite carrying `-n auto` in its own `addopts` had that
    value apply to phase 2, parallelising the very lane whose whole purpose is
    to be serial. Measured 2026-09-05 in own_chats on a 3-test file, with
    `-o addopts='-n 2'`: no `-n` on the command line -> 0.37 s and two worker
    processes; `-n 0` -> 0.01 s in-process. Where a repo declares no `-n`, the
    flag changes nothing.
    """
    suite = suite or _Suite([sys.executable, "-m", "pytest"])
    pytest_cmd, repo_markexpr = suite.cmd, suite.markexpr
    _clear_stale_coverage_data(root)
    phase1_argv = [a for a in argv if not a.startswith("--cov-fail-under")]
    # _XDIST_WORKERS es lo que este proceso PIDE; lo que corre es lo que el
    # contador global concede, porque el pool de memoria unificada lo comparten
    # todos los procesos de la maquina y no solo este. Ver
    # simplecode.utils.unified_memory_slots: sin esto, N coders suman 6N hijos
    # con CUDA inicializado y cada tope por proceso aplicado correctamente.
    # La fase 2 no pide slot: corre con `-n 0`, un solo hijo.
    with unified_memory_slots(_XDIST_WORKERS) as granted:
        phase1 = subprocess.run(
            [
                *pytest_cmd, *cov_args, f"--cov-report=json:{coverage_json}", "--cov-fail-under=0",
                "-n", str(granted),
                "-m", _compose_markexpr(repo_markexpr, f"not {_MUTATES_REAL_SOURCE_MARKER}"),
                *phase1_argv,
            ],
            cwd=root, check=False,
        )
    if phase1.returncode != 0:
        return phase1
    phase2 = subprocess.run(
        [
            *pytest_cmd, *cov_args, f"--cov-report=json:{coverage_json}", "--cov-append",
            "-n", "0",
            "-m", _compose_markexpr(repo_markexpr, _MUTATES_REAL_SOURCE_MARKER), *argv,
        ],
        cwd=root, check=False,
    )
    # pytest exits 5 for "no tests collected". In phase 2 that means the lane is
    # EMPTY -- this repository marks no test `mutates_real_source` -- which is a
    # fact about the suite, not a failure of it. Propagating it turned the
    # coverage floor red in every satellite without a marked test, with coverage
    # comfortably above the watermark. Measured by the aequitas_os session
    # 2026-09-02 on the resynced kit: phase 1 '2867 passed, 17 skipped, 1
    # xfailed', percent_covered 81.3 against a 79.26 watermark, and the gate
    # still rc=5 because phase 2 reported '2885 deselected'.
    #
    # Excused ONLY here. Phase 1 collecting nothing is the opposite situation --
    # a repository with no tests at all reporting coverage as a pass -- and it
    # keeps short-circuiting above, because a zero that nobody looks at is the
    # failure this kit spends its life chasing.
    if phase2.returncode == _PYTEST_NO_TESTS_COLLECTED:
        print(f"[coverage] phase 2: no test carries the `{_MUTATES_REAL_SOURCE_MARKER}` "
              f"marker here; the serial lane is empty, not failing. "
              f"Phase 1's coverage stands on its own.")
        return phase1
    return phase2


class _OwnFlags(NamedTuple):
    """The argv partition: what THIS module consumes vs. what pytest gets.

    A NamedTuple and not four returns because the partition is one decision
    with one failure mode, and that failure mode has a specific exit code.
    `could_not_run` carries the MESSAGE and not the code: the code (2, never 1)
    stays in `main`, so a future caller of this function cannot accidentally
    turn "could not measure" into "measured and found a defect".
    """

    advance: bool
    root: Path
    forwarded: list[str]
    could_not_run: str | None = None


def _parse_own_flags(argv: list[str]) -> _OwnFlags:
    """Split `argv` into this module's own flags and pytest's.

    Extracted from `main` because it is the FRAGILE half and it had no way to
    be exercised on its own. `--advance` and `--root` are consumed; every other
    token is forwarded verbatim AND IN ORDER. Both directions of that partition
    break a satellite: consume too little and pytest exits on `error:
    unrecognized arguments` naming pytest for a flag pytest never saw before
    (reported by repic, 2026-09-05); consume too much and pytest silently never
    receives a flag the caller asked for -- including `--rootdir=`, a real
    pytest flag whose name starts with this module's own, which is why the test
    is `startswith("--root=")` and not `startswith("--root")`.

    Worse than either where it does not error: run from a subdirectory with no
    `--root`, `Path.cwd()` silently makes the SUBJECT that subdirectory, so the
    watermark read and the coverage measured belong to a tree nobody asked
    about, and the verdict prints like a real one.
    """
    advance = "--advance" in argv
    root = Path.cwd()
    forwarded: list[str] = []
    it = iter(a for a in argv if a != "--advance")
    for a in it:
        if a == "--root":
            siguiente = next(it, None)
            if siguiente is None:
                return _OwnFlags(advance, root, forwarded,
                                 "--root given with no path")
            root = Path(siguiente)
        elif a.startswith("--root="):
            root = Path(a.split("=", 1)[1])
        else:
            forwarded.append(a)
    if not root.is_dir():
        # Refusing beats falling back to cwd. A silent fallback measures a
        # tree the caller did not name and prints the verdict as if it had.
        return _OwnFlags(advance, root, forwarded,
                         f"--root {root} is not a directory")
    return _OwnFlags(advance, root.resolve(), forwarded)


def _resolve_parallel_lane(info: dict, argv: list[str]) -> bool:
    """Whether to run the two-phase xdist split -- and SAY OUT LOUD whatever
    this run silently is not doing.

    Decision and announcement are one responsibility on purpose: every one of
    these three prints exists because the degradation it names had already been
    misread as something else (a serial run misread as "the fix didn't help", a
    dropped `addopts` marker filter, a caller `-m` undoing the split). A future
    edit that changes the decision without changing what gets announced would
    recreate exactly that, and here it cannot be done in two separate places.
    """
    has_xdist = bool(info.get("xdist"))
    explicit_n = any(a == "-n" or a.startswith("-n=") for a in argv)
    if not has_xdist and not explicit_n:
        print(
            "[coverage-target] pytest-xdist not installed -- running serial "
            "(pip install pytest-xdist for a measured 2.6-5.6x speedup)",
            file=sys.stderr,
        )
    use_xdist = has_xdist and not explicit_n
    if not use_xdist:
        return False
    # The repository's own `-m`, so the two phases INTERSECT with it instead
    # of replacing it. `markexpr` absent means the probe could not build a
    # pytest config here at all (a conftest that raises on import is the
    # realistic cause). Say so: the run still goes ahead with the old,
    # replacing filter, and a reader who is told can check whether this
    # repository declares an `addopts` filter that just got dropped.
    # A repository that simply declares no filter reports `''`, not absent.
    if "markexpr" not in info:
        print(
            "[coverage-target] could not read this repository's own `-m` filter -- "
            "phase 1 falls back to REPLACING it, so an `addopts` marker filter "
            "declared here is not being honoured",
            file=sys.stderr,
        )
    # A caller-supplied `-m` lands AFTER this module's own on the command
    # line and, being a store option, wins outright -- which silently undoes
    # the two-phase split. No fleet hook passes one (the canonical entry is
    # `coverage_target --cov-fail-under=100 -q`); this says so out loud
    # rather than composing it, and stays a declared limit.
    if any(a == "-m" or a.startswith("-m=") for a in argv):
        print(
            "[coverage-target] a caller-supplied `-m` overrides the two-phase "
            "marker split (pytest's `-m` is a store option): the "
            f"`{_MUTATES_REAL_SOURCE_MARKER}` lanes are no longer separated",
            file=sys.stderr,
        )
    return True


def main(argv: list[str] | None = None) -> int:
    """Run the test suite, then gate on the coverage RATCHET rather than a
    hardcoded ``--cov-fail-under``.

    The canonical hook used to bake ``--cov-fail-under=100`` straight into
    ``.pre-commit-config.yaml``, which `satellite_sync` overwrites verbatim
    on every sync -- so a satellite genuinely below 100% (Atlas, measured
    2026-08-26) had no declarative way to say so, and hand-editing that one
    hook's args got silently reverted by the next `--fix` run. The fleet
    already has a purpose-built mechanism for exactly this --
    `simplecode.worktree.coverage_ratchet`'s ``.coverage_watermark`` (never
    regresses, advances only on measured improvement) -- it was simply never
    wired into a gate. This is that wiring: the canonical config text stays
    universal (still just ``coverage_target -q``), and the actual floor
    lives in each repo's own watermark file instead of in the shared config.
    """
    own = _parse_own_flags(sys.argv[1:] if argv is None else argv)
    if own.could_not_run is not None:
        print(f"[coverage-target] COULD_NOT_RUN: {own.could_not_run}", file=sys.stderr)
        return 2
    advance, root, argv = own.advance, own.root, own.forwarded
    # First line of the run, before anything can fail: which interpreter is
    # measuring. `language: system` hooks inherit git's PATH, so this is not
    # always the one the repository is developed with, and a coverage figure
    # from an unnamed interpreter is a number nobody can place.
    #
    # It used to print `sys.executable` -- the interpreter of THIS process,
    # which is not the one that ran the suite: the suite went out as the bare
    # name `pytest` through PATH. The banner named one interpreter and the
    # measurement came from another, so a reader trusting the line was reading
    # a fact about the wrong process. It now names the interpreter the suite
    # is actually launched with, and reports ITS version, not this process's.
    interpreter, info = _resolve_suite_interpreter(root)
    version = (info or {}).get("version", "unknown")
    print(f"[coverage] interpreter: {interpreter} (python {version})")
    if info is None or not info.get("pytest"):
        print(
            f"[coverage-target] COULD_NOT_RUN: {interpreter} cannot import pytest -- "
            "no interpreter available to run the suite",
            file=sys.stderr,
        )
        return 2
    pytest_cmd = [interpreter, "-m", "pytest"]
    targets = resolve_targets(root)
    if not targets:
        print(
            "[coverage-target] COULD_NOT_RUN: no src/ directory and no top-level Python "
            "package (dir with __init__.py) found -- set coverage_targets in "
            ".simplecode/corpus_exempt.yaml to override",
            file=sys.stderr,
        )
        return 2

    # DEBT-SURVEY-GATES-MEASURE-THE-SCAFFOLD: `--cov-fail-under=100` describes
    # `targets` (this repo's Python packages) alone. A satellite whose product
    # is C#/Rust/TypeScript gets a "coverage: 100%" banner that is true and
    # says nothing about the actual building -- same shape `zero_debt` already
    # confesses for its own scan. Reusing that scan here rather than
    # reimplementing it: this gate is Python-only by construction (there is no
    # branch that could read a foreign extension), so what it left outside is
    # exactly what `zero_debt.unexamined_source` already counts.
    from simplecode.worktree.zero_debt import unexamined_source

    _unexamined = unexamined_source(root)
    if _unexamined:
        _total = sum(_unexamined.values())
        _breakdown = ", ".join(f"{n} {ext}" for ext, n in sorted(_unexamined.items()))
        print(
            f"[coverage-target] NOT EXAMINED -- this floor measures Python coverage "
            f"only: {_total} tracked source file(s) ({_breakdown}) are outside any "
            f"coverage measurement. A clean verdict below says NOTHING about them."
        )

    # Written under .simplecode/ (universally gitignored, `.simplecode/*` in
    # every scaffolded and existing repo this session touched) rather than
    # the default `coverage.json` at repo root. Reported live (Atlas,
    # 2026-08-26): a root-level coverage.json is untracked and un-ignored by
    # default, so `git status --porcelain` sees it as a new file after every
    # run -- which trips pre-commit's own dirty-tree check ("files were
    # modified by this hook") on the coverage-floor hook itself, failing the
    # push regardless of the semantic coverage verdict. Gitignoring it repo
    # by repo (the first fix, in simplecode's own .gitignore) only closes the
    # gap for repos someone remembers to edit; writing it somewhere already
    # ignored closes it for every satellite that runs this exact code.
    coverage_json = root / ".simplecode" / "coverage.json"
    cov_args = [f"--cov={t}" for t in targets]
    # Opportunistic: a satellite without pytest-xdist installed yet gets the
    # same correctness at the old serial speed, never a COULD_NOT_RUN for
    # lacking a plugin this check doesn't strictly need. Skipped entirely
    # when the caller already passed its own `-n` -- an explicit override
    # always wins, and this module doesn't try to layer the two-phase split
    # on top of a worker count it didn't choose.
    #
    # Reported live (2026-08-31): this degrades to serial SILENTLY when
    # xdist is missing -- confirmed neither Atlas nor aequitas_os had it
    # installed despite having synced the version that opportunistically
    # uses it, so a measured 199.27s coverage-100 run was misread as "the
    # fix didn't help" when it had simply never been exercised. The warning
    # below is the fix for THAT confusion, not for the missing dependency
    # itself (which stays a per-satellite `pip install`, not this module's
    # job to force).
    #
    # `importlib.util.find_spec("xdist")` answered for THIS process, which is
    # not the one that imports the plugin -- the same wrong-subject bug as the
    # banner above. It is read off the probe of the suite interpreter instead.
    use_xdist = _resolve_parallel_lane(info, argv)
    if use_xdist:
        result = _run_two_phase(
            root, cov_args, coverage_json, argv,
            _Suite(pytest_cmd, info.get("markexpr")),
        )
    else:
        result = subprocess.run(
            [*pytest_cmd, *cov_args, f"--cov-report=json:{coverage_json}", *argv], cwd=root, check=False
        )
    if result.returncode != 0:
        return result.returncode

    from simplecode.worktree import coverage_ratchet

    current_cov = coverage_ratchet.extract_coverage_from_json(coverage_json)
    if current_cov is None:
        print(
            "[coverage-target] COULD_NOT_RUN: coverage.json missing or unparseable "
            "after a passing test run",
            file=sys.stderr,
        )
        return 2
    # advance=False on purpose. The gate JUDGES; recording is a separate step,
    # the same separation that makes `hook_receipts` work. A gate that writes a
    # git-TRACKED file while pre-commit is watching the tree reports its own
    # write as a failure -- see `coverage_ratchet.evaluate_coverage` for the
    # descargaSAT reproduction. `--advance` is the explicit lock-in.
    ok, msg = coverage_ratchet.evaluate_coverage(
        current_cov, root, advance=advance, gate=True)
    print(msg)
    if ok:
        return 0
    # Veredicto de condena TAGUEADO. Sin esta linea el modulo solo imprimia
    # `[coverage-target] COULD_NOT_RUN` en sus caminos de instrumento caido, y
    # `gate_runner.gate_could_not_run` -- que decide leyendo la salida -- no tenia
    # como distinguir "no pude medir la cobertura" de "la medi y no llega". Un
    # fallo real se habria grabado como instrumento caido, que es peor que el
    # defecto original: borraria una captura verdadera.
    print("[coverage-target] FAIL: coverage below the recorded floor")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
