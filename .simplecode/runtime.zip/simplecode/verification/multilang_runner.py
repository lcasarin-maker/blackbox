#!/usr/bin/env python3
"""Repo-wide runner for `guards/multilang_detectors.py`.

DEBT-MULTILANG-DETECTORS-NO-RUNNER: the detectors in `multilang_detectors.py`
existed (one real, narrow, regex-based check per non-Python language --
C#, JavaScript, Rust, TypeScript) but nothing in the canon walked a repo's
tracked files and dispatched them. A satellite (Aequitas) wrote its own local
copy of exactly this walk-and-dispatch loop to scan 154 TypeScript files
(59,708 lines) because the kit did not provide one -- the same shape of gap
`subject_survey.py` names for whole languages, one level down: the ORGAN
existed, the RUNNER that reaches it did not.

WHAT THIS DOES
--------------
1. Enumerate git-tracked files (`dangling_refs.tracked_files` -- reused, not
   reimplemented, so untracked scratch work never feeds a detector and a
   non-ASCII filename is never mis-split; see that function's own docstring).
2. Determine each file's language by extension, reusing
   `subject_survey.LANGUAGES` rather than a second copy of that table.
3. Dispatch to the language's detector(s) in `multilang_detectors.py`, when
   one exists.
4. Report, per language: files scanned, lines scanned, findings -- and for a
   language present in the tree with NO registered detector, report it
   explicitly as `COULD_NOT_RUN`, never silently absent.

WHAT THIS DOES NOT DO
----------------------
Python is out of scope by design, not by oversight: it already has an
AST-level detector suite (`pattern_detectors.py`, `agent_threats.py`) that
this module does not duplicate or shadow, so `.py` files are excluded from
enumeration entirely and never appear as `COULD_NOT_RUN` -- that verdict is
reserved for a language this runner claims to survey but genuinely cannot
read. It does not teach any detector a new vice, and it is not wired into
`.pre-commit-config.yaml` or `zero_debt`'s pipeline -- that is a separate,
fleet-wide wiring decision (see `multilang_detectors.py`'s own docstring for
the same distinction on the detectors themselves).
"""
from __future__ import annotations

import argparse
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from simplecode.guards import multilang_detectors as md
from simplecode.verification.dangling_refs import tracked_files
from simplecode.verification.subject_survey import LANGUAGES

logger = logging.getLogger(__name__)

# Language -> the detector(s) `multilang_detectors.py` actually registers for
# it. Kept as a table (not a dispatch-by-name lookup into the module) so a
# language with NO entry here is unambiguous: `LANGUAGE_DETECTORS.get(lang)`
# returns None, and `scan()` reports that as COULD_NOT_RUN rather than
# silently finding zero.
DetectorFn = Callable[[str], bool]
LANGUAGE_DETECTORS: dict[str, tuple[tuple[str, DetectorFn], ...]] = {
    "C#": (("csharp_empty_catch", md.csharp_empty_catch),),
    "JavaScript": (("javascript_empty_catch", md.javascript_empty_catch),),
    "TypeScript": (("typescript_empty_catch", md.typescript_empty_catch),),
    "Rust": (("rust_unwrap_call", md.rust_unwrap_call),),
}

# Python has its own AST-level tooling elsewhere in the kit; this runner's
# whole point is the languages that tooling cannot read, so Python is
# excluded from enumeration rather than reported as covered or uncovered.
_OUT_OF_SCOPE = frozenset({"Python"})


@dataclass
class LanguageStats:
    files: int = 0
    lines: int = 0
    findings: int = 0
    finding_paths: list[str] = field(default_factory=list)
    unreadable: int = 0
    has_detector: bool = True


@dataclass
class ScanResult:
    languages: dict[str, LanguageStats] = field(default_factory=dict)

    @property
    def uncovered(self) -> list[str]:
        """Languages present in the tree with no registered detector."""
        return sorted(lang for lang, s in self.languages.items() if not s.has_detector)

    @property
    def total_files(self) -> int:
        return sum(s.files for s in self.languages.values())

    @property
    def total_lines(self) -> int:
        return sum(s.lines for s in self.languages.values())

    @property
    def total_findings(self) -> int:
        return sum(s.findings for s in self.languages.values())


def _language_for(path: Path) -> str | None:
    return LANGUAGES.get(path.suffix.lower())


def _is_excluded(rel_posix: str, excludes: tuple[str, ...]) -> bool:
    """Whether `rel_posix` falls under any of `excludes`.

    Each exclusion is matched as an exact path or a directory prefix
    (`"vendor"` excludes `vendor/x.ts` but not `vendor_extra/x.ts`), so a
    short exclusion name never accidentally swallows an unrelated sibling.
    """
    for ex in excludes:
        ex_norm = ex.strip("/")
        if not ex_norm:
            continue
        if rel_posix == ex_norm or rel_posix.startswith(ex_norm + "/"):
            return True
    return False


def scan(root: Path, excludes: tuple[str, ...] = ()) -> ScanResult:
    """Walk git-tracked non-Python files under `root`, dispatch to detectors.

    `excludes` are repo-relative paths or path-prefixes (POSIX-style, as
    `git ls-files` itself reports them) skipped entirely -- neither counted
    nor scanned, so an excluded finding truly does not appear anywhere in the
    result, not just in the printed report.
    """
    result = ScanResult()
    for f in tracked_files(root):
        lang = _language_for(f)
        if lang is None or lang in _OUT_OF_SCOPE:
            continue
        rel = f.relative_to(root).as_posix()
        if _is_excluded(rel, excludes):
            continue

        stats = result.languages.setdefault(lang, LanguageStats())
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("multilang runner could not read %s: %s", f, exc)
            stats.unreadable += 1
            continue

        stats.files += 1
        stats.lines += text.count("\n") + (1 if text and not text.endswith("\n") else 0)

        detectors = LANGUAGE_DETECTORS.get(lang)
        if detectors is None:
            stats.has_detector = False
            continue
        for _name, fn in detectors:
            if fn(text):
                stats.findings += 1
                stats.finding_paths.append(rel)
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Walk git-tracked non-Python files and dispatch each to the "
                     "matching guards/multilang_detectors.py detector; report "
                     "files/lines/findings per language and COULD_NOT_RUN for any "
                     "language with no detector."
    )
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--gate", action="store_true",
                     help="exit 1 when any detector found something, or a "
                          "present language has no detector")
    ap.add_argument("--exclude", action="append", default=[], metavar="PATH",
                     help="repo-relative path or path-prefix to exclude "
                          "(repeatable)")
    args = ap.parse_args(argv)
    root = args.root.resolve()
    excludes = tuple(args.exclude)

    result = scan(root, excludes)
    if not result.languages:
        print(f"[multilang] COULD_NOT_RUN: no non-Python tracked source in a "
              f"known language under {root}", file=sys.stderr)
        return 2

    print(f"[multilang] {result.total_files} file(s), {result.total_lines:,} "
          f"line(s) scanned across {len(result.languages)} language(s)")
    for lang, stats in sorted(result.languages.items(), key=lambda kv: -kv[1].lines):
        if stats.has_detector:
            print(f"    {lang:<12} files={stats.files:<5} lines={stats.lines:<8,} "
                  f"findings={stats.findings}")
            for p in stats.finding_paths:
                print(f"        FINDING  {lang}: {p}")
        else:
            print(f"    {lang:<12} files={stats.files:<5} lines={stats.lines:<8,} "
                  f"COULD_NOT_RUN: no detector registered for {lang} in "
                  f"guards/multilang_detectors.py")
        if stats.unreadable:
            print(f"        {stats.unreadable} file(s) of {lang} could not be read "
                  f"(counted, not skipped in silence)")

    uncovered = result.uncovered
    if uncovered:
        print(f"[multilang] COULD_NOT_RUN for {len(uncovered)} language(s) with "
              f"no detector: {', '.join(uncovered)}")

    if not args.gate:
        return 0
    return 1 if (result.total_findings or uncovered) else 0


if __name__ == "__main__":
    sys.exit(main())
