#!/usr/bin/env python3
"""El lockfile es la verdad de referencia, y este gate lo mantiene honesto.

Mecanismo cosechado de `earendil.works/pi` (Atlas, 2026-09-06), una de las pocas
citas de esa cosecha que resuelve contra la captura CRUDA del upstream y no contra
la prosa del propio modelo: *"`package-lock.json` is the dependency ground truth.
Pre-commit blocks accidental lockfile commits"*. Traido a nuestra escala -- de
npm a pip, de "bloquea cambios accidentales" a "el lock no puede quedarse atras".

Lo que lo justifica no es la idea, es lo que encontro al aplicarlo: `pytest-xdist`
llevaba fijado en `pyproject.toml` desde la fase de paralelismo y NO existia en
`requirements-lock.txt` (ni su transitiva `execnet`). El lock era del 22 de agosto;
la dependencia se anadio despues y nadie regenero nada. Quien clonara e instalara
desde el lock no obtenia xdist, la paralelizacion no aplicaba, y ningun gate lo
decia. Es la misma clase que `pii_scan.permitidos` documenta para el allowlist: una
declaracion que no sobrevive al clone.

El gate NO comprueba hashes ni resuelve el arbol transitivo -- eso lo hace `pip`
con `--require-hashes`, que ya es el instrumento correcto y no hay que duplicarlo
(escalera: la plataforma ya lo hace). Comprueba la unica cosa que nadie mira: que
cada version FIJADA a mano en `pyproject.toml` este en el lock, con la misma
version. Es texto contra texto, sin red y sin resolver nada.

Uso:
    python -m simplecode.verification.lockfile_parity --root .
"""
from __future__ import annotations

import argparse
import re
import sys
import tomllib
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos

_LOCK_RELPATH = Path("requirements-lock.txt")
_PIN = re.compile(r"^([A-Za-z0-9_.\-]+)==([^\s;\\]+)")


def _normalizar(nombre: str) -> str:
    """PEP 503: `pytest_xdist`, `Pytest-XDist` y `pytest-xdist` son el mismo paquete."""
    return re.sub(r"[-_.]+", "-", nombre).lower()


def pins_declarados(root: Path) -> dict[str, str]:
    """Las versiones fijadas A MANO en pyproject.toml, obligatorias y opcionales."""
    datos = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    proyecto = datos.get("project", {})
    grupos = [proyecto.get("dependencies", [])]
    grupos += list(proyecto.get("optional-dependencies", {}).values())
    pins: dict[str, str] = {}
    for grupo in grupos:
        for req in grupo:
            m = _PIN.match(str(req))
            if m:
                pins[_normalizar(m.group(1))] = m.group(2)
    return pins


def pins_del_lock(root: Path) -> dict[str, str]:
    texto = (root / _LOCK_RELPATH).read_text(encoding="utf-8")
    pins: dict[str, str] = {}
    for linea in texto.splitlines():
        m = _PIN.match(linea.strip())
        if m:
            pins[_normalizar(m.group(1))] = m.group(2)
    return pins


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    args = ap.parse_args(argv)
    root = args.root

    if not (root / "pyproject.toml").is_file():
        print("[lockfile-parity] NO APLICA: este repo no tiene pyproject.toml")
        return 0
    if not (root / _LOCK_RELPATH).is_file():
        # Un repo sin lock no tiene nada que divergir. Se dice, no se silencia:
        # el dia que alguien anada uno, el gate empieza a hablar solo.
        print(f"[lockfile-parity] NO APLICA: no hay {_LOCK_RELPATH.as_posix()}")
        return 0

    try:
        declarados = pins_declarados(root)
        bloqueados = pins_del_lock(root)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        print(f"[lockfile-parity] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 1

    if not declarados:
        # Cero pins leidos de un pyproject que SI existe es el instrumento
        # apuntando a nada, no un repo limpio -- la misma politica que pii_scan
        # aplica a sus ambitos vacios.
        print("[lockfile-parity] COULD_NOT_RUN: pyproject.toml no declara ninguna "
              "version fijada con `==`; no se comparo nada", file=sys.stderr)
        return 1

    ausentes = sorted(p for p in declarados if p not in bloqueados)
    divergentes = sorted(
        (p, declarados[p], bloqueados[p])
        for p in declarados
        if p in bloqueados and declarados[p] != bloqueados[p]
    )

    print(f"[lockfile-parity] pins declarados={len(declarados)} "
          f"paquetes en el lock={len(bloqueados)} "
          f"ausentes={len(ausentes)} divergentes={len(divergentes)}")
    # Same sum the FAIL line below prints, unconditional here so it covers
    # the clean run (0) too -- both NO APLICA returns and the two
    # COULD_NOT_RUN bails above (nothing measured yet) never reach this line.
    emit_hallazgos("[lockfile-parity]", len(ausentes) + len(divergentes))
    for p in ausentes:
        print(f"  AUSENTE {p}=={declarados[p]} fijado en pyproject.toml y no esta "
              f"en {_LOCK_RELPATH.as_posix()}")
    for p, decl, bloq in divergentes:
        print(f"  DIVERGE {p}: pyproject.toml=={decl} pero el lock=={bloq}")

    if ausentes or divergentes:
        print(f"[lockfile-parity] FAIL: {len(ausentes) + len(divergentes)} pin(s) que "
              f"un clone instalando desde el lock no obtendria como dice pyproject.toml")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
