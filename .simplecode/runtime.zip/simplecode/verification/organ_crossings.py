#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""organ_crossings -- the home of mould (c): two organs asserting the same thing.

Atlas catalogued (DGX-402, 2026-09-01) four moulds of instrument that cannot
come out negative. Three of them a per-organ counter can see: an organ that
points at a subject that no longer exists, one that cannot reach its subject,
one that truncates itself -- all of them accumulate runs without ever
convicting, which is what `gate_effectiveness --gate` measures.

The fourth, mould (c), is invisible to that counter BY CONSTRUCTION: two organs
measure the same thing, disagree, and both are green apart. A counter per organ
cannot see a disagreement BETWEEN organs. Three instances surfaced in one day,
and every one of them was found by a person crossing two reports by hand.

This module is the place a crossing gets declared, so the species has a home
and adding a specimen costs ten lines instead of a test file. Every crossing
names the two organs, the ONE claim they both make, and how each side is read;
the gate runs them together and prints AGREE / DIVERGE / CANNOT_CROSS with the
zeros.

WHAT THIS DOES NOT DO, stated here rather than left for a reader to assume: it
does not assert completeness. There is no enumeration of "claims", so nothing
here can tell you that a new organ arrived and nobody crossed it. A crossing
exists because someone wrote it. Chosen deliberately over a completeness
assertion keyed on hook ids, which would have needed ~33 hand-written "no
counterpart" rows on day one and would have decayed into a formality -- the
exact vice this gate exists to catch.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import sys
import zipfile
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import yaml

from simplecode import cli_new
from simplecode.verification import gate_effectiveness, ledger

AGREE = "AGREE"
DIVERGE = "DIVERGE"
CANNOT_CROSS = "CANNOT_CROSS"


@dataclass(frozen=True)
class CrossingResult:
    verdict: str
    detail: str


@dataclass(frozen=True)
class Crossing:
    """Two organs, one shared claim, and the reading that compares them."""

    name: str
    claim: str
    organs: tuple[str, str]
    run: Callable[[Path], CrossingResult]


# ---------------------------------------------------------------------------
# Crossing 1 -- the canonical gate list vs the hooks actually wired
# ---------------------------------------------------------------------------

def _wired_organs(config_text: str) -> set[str]:
    """Canonical organs reachable from the hook ids declared in a config."""
    try:
        data = yaml.safe_load(config_text) or {}
    except yaml.YAMLError:
        return set()
    if not isinstance(data, dict):
        return set()
    wired: set[str] = set()
    for repo in data.get("repos", []) or []:
        if not isinstance(repo, dict):
            continue
        for hook in repo.get("hooks", []) or []:
            if not isinstance(hook, dict) or "id" not in hook:
                continue
            hook_id = str(hook["id"])
            wired.update(gate_effectiveness.ALIAS.get(hook_id, (hook_id.replace("-", "_"),)))
    return wired & gate_effectiveness.COMPUERTAS_CANONICAS


def cross_canonical_organs_are_wired(root: Path) -> CrossingResult:
    """`COMPUERTAS_CANONICAS` and `.pre-commit-config.yaml` both say which gates run.

    They disagree silently in the direction that matters most: an organ listed
    as canonical and present in the kit, but wired to no hook, produces zero
    telemetry rows -- so `gate_effectiveness`'s zero-catch rule never fires for
    it either. Nothing is measuring nothing, and both organs are green. That is
    the shape that shipped `growth-ratchet --subdir src/simplecode` to four
    satellites where the directory does not exist.
    """
    config = root / ".pre-commit-config.yaml"
    if not config.is_file():
        return CrossingResult(CANNOT_CROSS, f"{config} is absent; nothing to read on one side")
    en_kit = gate_effectiveness.organos_del_kit()
    if not en_kit:
        return CrossingResult(CANNOT_CROSS, "no canonical organ found in the kit; the comparison would be vacuous")
    cableados = _wired_organs(config.read_text(encoding="utf-8"))
    sin_cablear = sorted(en_kit - cableados)
    if sin_cablear:
        return CrossingResult(
            DIVERGE,
            f"canonical and present in the kit but wired to no hook: {sin_cablear}. "
            f"They will report zero runs forever, and a zero-catch counter cannot "
            f"tell that apart from a quiet gate",
        )
    return CrossingResult(AGREE, f"{len(en_kit)} canonical organ(s) in the kit, all wired: {sorted(en_kit)}")


# ---------------------------------------------------------------------------
# Crossing 2 -- this repo's live config vs the template the fleet receives
# ---------------------------------------------------------------------------

_ENTRY_MODULE = re.compile(r"simplecode\.(?:guards|verification|worktree|satellite)\.\w+")

# Divergences that are DELIBERATE. Each needs a reason, because the whole point
# is that an undeclared one -- the `--staged` omission, the hook-receipts one
# before it -- fails loudly instead of shipping a gate the fleet never runs.
# Divergences that are DELIBERATE. Each needs a reason, because the whole point
# is that an undeclared one -- the `--staged` omission, the hook-receipts one
# before it -- fails loudly instead of shipping a gate the fleet never runs.
#
# One of these was REMOVED and RESTORED within the hour on 2026-09-02, and the
# episode is worth the lines. The crossing reported that `coverage-floor` no
# longer diverged, so the entry was dropped as a stale exemption. It was not
# stale: a peer session had just run `satellite_sync` against THIS repository,
# composing its config from the scaffold template and stripping the
# `--cov-fail-under=100` pin along with nine other gates. The two sides agreed
# only because one of them had been overwritten. The crossing's observation was
# correct and the conclusion drawn from it was not -- an instrument can only
# report that two organs agree, never why.
DECLARED_DIVERGENCES = {
    "coverage-floor": (
        "simplecode pins --cov-fail-under=100 on itself; a satellite scaffolded "
        "today would fail its first commit at that floor, so the template ships "
        "the gate without the pin and each satellite ratchets its own"
    ),
}

# Gates simplecode runs on itself and does NOT ship. Same rule: declared, with
# a reason, so a gate meant for the fleet cannot go missing by accident.
#
# EMPTY since 2026-09-27 (DECISIONS.md): the gate audit retired all twelve gates this
# repo used to run only on itself (build-dist, commit-msg-claims, consumer-shapes,
# deadcode-gate, decisions-format, findings-detail-ratchet, gate-controls, observe,
# ratchet-audit, red-team, signed-commit, vices-semgrep). Their reasons for staying
# out of the template are in git history; a stale entry here would pre-excuse any of
# them coming back to this config without reaching the fleet -- the same reason
# DECLARED_DIVERGENCES refuses an entry whose two sides agree.
#
# version-bump returned the same day, kit only (DECISIONS.md, "H1 no puede quedar
# stale"): it gates the release on the H1 ledger, and no satellite carries one.
SIMPLECODE_ONLY: set[str] = {"version-bump"}


def gate_invocations(config_text: str) -> dict[str, set[str]]:
    """Hook id -> the simplecode modules its entry runs, plus their flags.

    Compared at the level of "which organ runs with which flags", not raw text:
    the two configs legitimately differ in HOW they reach the interpreter
    (`python -m simplecode...` here, `python .simplecode/run.py simplecode...`
    on a satellite), and a raw diff would be noise that nobody could keep green.
    """
    data = yaml.safe_load(config_text)
    out: dict[str, set[str]] = {}
    for repo in data.get("repos", []):
        for hook in repo.get("hooks", []):
            entry = " ".join((hook.get("entry") or "").split())
            if not _ENTRY_MODULE.search(entry):
                continue
            tokens = entry.split()
            invocations = set()
            for i, tok in enumerate(tokens):
                if _ENTRY_MODULE.fullmatch(tok):
                    # Flags up to the next module reference belong to this one.
                    stop = next((j for j, t in enumerate(tokens[i + 1:])
                                 if _ENTRY_MODULE.fullmatch(t)), len(tokens))
                    flags = [t for t in tokens[i + 1:i + 1 + stop] if t.startswith("--")]
                    invocations.add(f"{tok} {' '.join(sorted(flags))}".strip())
            out.setdefault(hook["id"], set()).update(invocations)
    return out


def template_parity_breaches(root: Path) -> list[str]:
    """Every undeclared disagreement between the live config and the template.

    `satellite_sync._sync_config_file` composes each satellite's config from
    `cli_new._pre_commit_config()` -- a template in code -- and NOT from this
    repo's config file. So a gate can be fixed, tested and verified green here
    and still never reach the 12 satellites, and verifying it here cannot
    detect that.

    Measured twice. Commit cb4dd77 (`fix(scaffold): wire hook-receipts-gate into
    simplecode new's template`) was the first. On 2026-09-01 it happened again:
    `corruption-guard` was switched to `--staged` in this repo's config to
    unfreeze Atlas, the template kept the repo-wide invocation, and a satellite
    adopting the "fixed" kit would have stayed frozen. Two occurrences of one
    shape is a reincidence, and the instrument that catches it is worth more
    than either fix -- proposed by the Atlas session that was blocked by it.
    """
    config = root / ".pre-commit-config.yaml"
    if not config.is_file():
        return []
    aqui = gate_invocations(config.read_text(encoding="utf-8"))
    plantilla = gate_invocations(cli_new._pre_commit_config())
    if not aqui or not plantilla:
        return ["COULD_NOT_RUN: one side parsed to no gate invocations at all"]

    breaches: list[str] = []
    compartidos = sorted(set(aqui) & set(plantilla))
    if not compartidos:
        breaches.append(
            "this repo's config and the scaffold template share no hook id at all; "
            "either the template stopped shipping gates or the parser broke"
        )
    for hook_id in sorted(set(aqui) - set(plantilla) - SIMPLECODE_ONLY):
        breaches.append(
            f"{hook_id}: runs here, absent from the scaffold template the fleet "
            f"receives, and not declared in SIMPLECODE_ONLY"
        )
    for hook_id in compartidos:
        if hook_id in DECLARED_DIVERGENCES:
            if aqui[hook_id] == plantilla[hook_id]:
                breaches.append(
                    f"{hook_id}: listed in DECLARED_DIVERGENCES but the two configs "
                    f"now agree; drop the entry so a future real divergence is not "
                    f"pre-excused by a stale exemption"
                )
            continue
        if aqui[hook_id] != plantilla[hook_id]:
            breaches.append(
                f"{hook_id}: runs {sorted(aqui[hook_id])} here but "
                f"{sorted(plantilla[hook_id])} in the template shipped to the fleet"
            )
    return breaches


def cross_template_matches_live_config(root: Path) -> CrossingResult:
    breaches = template_parity_breaches(root)
    if not (root / ".pre-commit-config.yaml").is_file():
        return CrossingResult(CANNOT_CROSS, "no .pre-commit-config.yaml in this root")
    if breaches:
        return CrossingResult(DIVERGE, "; ".join(breaches))
    return CrossingResult(AGREE, "every shared hook runs the same organ with the same flags")


# ---------------------------------------------------------------------------
# Crossing 3 -- declared impossible, with its reason
# ---------------------------------------------------------------------------

def cross_h2_controls_vs_disposition_ledger(root: Path) -> CrossingResult:
    """H2 and the disposition ledger both speak about planted controls, and cannot be crossed.

    `detector_controls` proves every detector convicts a planted fixture;
    `telemetry_dispositions` records whether a production block was a confirmed
    defect, a false positive, or a controlled canary. Measured 2026-09-01 in two
    repos: 357 blocks between them, `controlled_canary: 0` in both, while H2
    reported every detector proven. The fleet had blocked 357 times with
    evidence that exactly one was correct.

    They cannot be reconciled by a counter, and SPEC already concedes why: H2's
    canary runs IN-PROCESS and never emits a telemetry row, so the ledger has
    nothing to record. The two numbers are not in disagreement -- they are not
    about the same runs. Declared here so the pair is visible and counted rather
    than looking green in two places; closing it means making H2 emit a
    disposable row, which is a change to how we measure and is not free.
    """
    return CrossingResult(
        CANNOT_CROSS,
        "H2's positive controls run in-process and emit no telemetry row, so the "
        "disposition ledger has nothing to record; the two counts are not about "
        "the same runs. Closing it requires H2 to emit a disposable event.",
    )


# ---------------------------------------------------------------------------
# Crossing 4 -- the runner's freshness digest vs the manifest's
# ---------------------------------------------------------------------------

def _runner_style_digest(package_root: Path) -> str:
    """The digest exactly as `.simplecode/run.py` computes it on every hook run.

    Deliberately a SECOND implementation of the same claim rather than a call
    into the first: the runner is a source string shipped to 17 repos and
    cannot import anything from the kit before it has decided whether to pull
    the kit. Two implementations of one rule is the mould (c) shape, so it is
    declared and crossed here instead of being left to agree by hope.
    """
    digest = hashlib.sha256()
    for source in sorted(package_root.rglob("*")):
        if source.is_file() and source.suffix in (".py", ".yaml"):
            digest.update(source.relative_to(package_root.parent).as_posix().encode("utf-8"))
            digest.update(source.read_bytes())
    return digest.hexdigest()


def cross_runner_digest_matches_manifest(root: Path) -> CrossingResult:
    """`run.py`'s freshness test and `RUNTIME_MANIFEST.json` must hash the same thing.

    The runner resyncs a satellite when its digest of the mother's package
    differs from the bundle's recorded `content_sha256`. If the two ever stop
    hashing the same input, the failure is silent in the worse direction: the
    digests never match, every satellite resyncs on every hook run, and nothing
    reports it. Replaced the version-number trigger on 2026-09-02, after four
    satellites were measured declaring the mother's exact version while
    carrying none of its code.
    """
    package_root = root / "src" / "simplecode"
    if not package_root.is_dir():
        return CrossingResult(CANNOT_CROSS, f"{package_root} is absent; this is not the mother repo")
    if "content_sha256" not in cli_new._portable_runner():
        return CrossingResult(
            DIVERGE,
            "the shipped runner no longer reads `content_sha256`, so its freshness "
            "test and the manifest are not about the same thing at all",
        )
    manifest = json.loads(
        zipfile.ZipFile(io.BytesIO(cli_new._runtime_bundle())).read("RUNTIME_MANIFEST.json")
    )
    recorded = str(manifest.get("content_sha256", ""))
    computed = _runner_style_digest(package_root)
    if computed != recorded:
        return CrossingResult(
            DIVERGE,
            f"runner digest {computed[:16]} != manifest content_sha256 {recorded[:16]}; "
            f"every satellite would resync on every hook run and nothing would say why",
        )
    return CrossingResult(AGREE, f"both hash the same package tree ({recorded[:16]})")


# ---------------------------------------------------------------------------
# Crossing 5 -- every reading of `.git` must handle a worktree pointer file
# ---------------------------------------------------------------------------

_BARE_GIT_ISDIR_RE = re.compile(r'/\s*"\.git"\s*\)\s*\.is_dir\(\)')

# The one place allowed to test `.git` as a directory, because it is the fast
# path INSIDE the function that resolves the pointer file when it is not one.
_GIT_READING_HOME = "verification/hook_receipts.py"

# Declared exceptions, each with the reason it is not the bug.
_GIT_READING_EXEMPT = {
    # This module QUOTES the offending pattern in its own docstring to explain
    # it. The line-based scan cannot tell a docstring from code, and this file
    # makes no repository test of its own, so exempting it costs nothing that
    # could hide a real one.
    "verification/organ_crossings.py": "quotes the pattern in prose; tests no repository itself",
    "verification/universal_harvester.py": (
        "tests is_dir() OR is_file() explicitly on the same line, so the pointer "
        "file is already handled"
    ),
}


def cross_git_readings_handle_worktrees(root: Path) -> CrossingResult:
    """Every "is this a git repo?" in the kit must give the same answer.

    In a `git worktree` -- and in a submodule -- `.git` is a FILE holding
    `gitdir: <path>`, never a directory, so `(root / ".git").is_dir()` answers
    False for a real repository. `hook_receipts.get_git_dir` has handled that
    since it cost a commit, with a docstring describing the failure exactly;
    `satellite_sync`, `fleet_inventory` and `debt_materializer` did not, and
    nothing crossed the two readings.

    Measured by the fleet-canon pilot 2026-09-02: all agent work in Atlas
    happens in worktrees, so `sync-satellites --target <worktree> --fix` refused
    every one of them, and the launchers it did install went to a `.git/hooks`
    path that does not exist there. Two organs, one claim, one fixed and one
    blind, both green apart -- the definition of this mould.
    """
    package = root / "src" / "simplecode"
    if not package.is_dir():
        return CrossingResult(CANNOT_CROSS, f"{package} is absent; this is not the mother repo")
    offenders: list[str] = []
    scanned = 0
    for source in sorted(package.rglob("*.py")):
        rel = source.relative_to(package).as_posix()
        if rel == _GIT_READING_HOME or rel in _GIT_READING_EXEMPT:
            continue
        scanned += 1
        for number, line in enumerate(source.read_text(encoding="utf-8").splitlines(), start=1):
            if line.lstrip().startswith("#"):
                continue
            if _BARE_GIT_ISDIR_RE.search(line):
                offenders.append(f"{rel}:{number}")
    if not scanned:
        return CrossingResult(CANNOT_CROSS, "no source files scanned; the comparison would be vacuous")
    if offenders:
        return CrossingResult(
            DIVERGE,
            f"these read `.git` as a directory and so answer False for every "
            f"worktree and submodule, while hook_receipts.is_git_repo answers "
            f"True: {offenders}",
        )
    return CrossingResult(
        AGREE,
        f"{scanned} module(s) scanned; every repo test goes through "
        f"hook_receipts, or is declared in _GIT_READING_EXEMPT",
    )


# ---------------------------------------------------------------------------
# Crossing 6 -- the kit's evidence reader vs the canon's evidence validator
# ---------------------------------------------------------------------------

def cross_evidence_readers_agree(root: Path) -> CrossingResult:
    r"""`finding_backlog` and `simplecode.verification.ledger_schema` both decide
    whether a done entry has its `evidence.fail`, and they must not disagree about one.

    They did. The canon's validator parses the frontmatter and asks
    `fm["evidence"].get("fail")`; the kit's reader used a regex over raw text,
    `^\s*fail:\s*\S+`. Both forms of the field parse to the same mapping, so
    the data never differed -- only one reader grepped where the other parsed.
    Measured by the aequitas_os session 2026-09-02: 23 entries with all three
    artifacts on disk were reported "done with no evidence.fail artifact",
    blocking ship-freeze in every repo that adopts the canon.

    Crossed on both SHAPES the field is written in, because the disagreement was
    invisible to any repo that only ever used one of them -- which is why it
    took a satellite to find it.

    The presence check used to be `(root / "gates" / "ledger_schema.py").is_file()`,
    back when the validator was a file copied into each satellite's own `gates/`.
    Migrated 2026-09-04 to `simplecode.verification.ledger_schema`, shipped in
    runtime.zip for every satellite alike -- the marker for "has this repo adopted
    the canon" is now `tasks/`, the structure the validator actually governs.
    """
    tasks_dir = root / "tasks"
    if not tasks_dir.is_dir():
        return CrossingResult(CANNOT_CROSS, f"{tasks_dir} is absent; the canon's validator "
                              "has nothing to govern here")
    forms = {
        "nested": '---\nid: X\nstatus: done\nevidence:\n  pass: p\n  fail: f\n  e2e: e\n---\n\n# x\n',
        "inline": '---\nid: X\nstatus: done\nevidence: {"pass": "p", "fail": "f", "e2e": "e"}\n---\n\n# x\n',
        "absent-fail": '---\nid: X\nstatus: done\nevidence: {"pass": "p", "e2e": "e"}\n---\n\n# x\n',
    }
    expected = {"nested": True, "inline": True, "absent-fail": False}
    disagree = []
    for name, body in forms.items():
        kit = bool(ledger.evidence_fail_path(body))
        if kit is not expected[name]:
            disagree.append(f"{name}: kit says {kit}, the canon's contract says {expected[name]}")
    if disagree:
        return CrossingResult(
            DIVERGE,
            "the kit's evidence reader and the canon's validator disagree about the "
            f"same entry: {disagree}",
        )
    return CrossingResult(
        AGREE,
        "both readers accept the nested and inline forms of `evidence.fail` and both "
        "reject its absence",
    )


def cross_semantic_gap_readers_agree(root: Path) -> CrossingResult:
    """`pattern_detectors.unanalysed_semantic_source` and `zero_debt._semantic_gap`
    both claim "these tracked Rust/TypeScript files have no AST-semantic
    detector reaching them" -- for the SAME tracked files, they must agree.

    DEBT-SPEC8-RUST-TS-PARSERS: before `multilang_ast` existed, both were a
    plain filter over `unexamined_source(root)` and could not disagree by
    construction (one imported the other). Once `multilang_ast`'s optional
    binding made the claim conditional, each side gated on
    `MULTILANG_AST_AVAILABLE` independently -- exactly the shape that let
    `evidence_readers_agree`'s own two-vocabulary defect happen once
    already. Crossed here on both states of the flag, via monkeypatch on
    a real tracked fixture, rather than trusted from two docstrings that
    promise to stay matched by hand.
    """
    import subprocess
    import tempfile

    from simplecode.guards import multilang_ast, pattern_detectors
    from simplecode.worktree import zero_debt

    with tempfile.TemporaryDirectory(prefix="cross_semantic_gap_") as tmp:
        repo = Path(tmp)
        try:
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            subprocess.run(["git", "config", "user.email", "t@t"], cwd=repo, check=True)
            subprocess.run(["git", "config", "user.name", "t"], cwd=repo, check=True)
            (repo / "lib.rs").write_text("fn main() {}\n", encoding="utf-8")
            (repo / "app.tsx").write_text("export const x = 1;\n", encoding="utf-8")
            subprocess.run(["git", "add", "-A"], cwd=repo, check=True)
        except (OSError, subprocess.CalledProcessError) as exc:
            return CrossingResult(CANNOT_CROSS, f"could not build the fixture repo: {exc}")

        disagree = []
        original = multilang_ast.MULTILANG_AST_AVAILABLE
        try:
            for available in (True, False):
                multilang_ast.MULTILANG_AST_AVAILABLE = available
                kit_gap = pattern_detectors.unanalysed_semantic_source(repo)
                own_gap = zero_debt._semantic_gap(zero_debt.unexamined_source(repo))
                if kit_gap != own_gap:
                    disagree.append(
                        f"available={available}: unanalysed_semantic_source={kit_gap}, "
                        f"zero_debt._semantic_gap={own_gap}"
                    )
        finally:
            multilang_ast.MULTILANG_AST_AVAILABLE = original

    if disagree:
        return CrossingResult(
            DIVERGE,
            "the two semantic-gap readers disagree on the same tracked files: "
            f"{disagree}",
        )
    return CrossingResult(
        AGREE,
        "both readers report the same Rust/TypeScript gap whether or not "
        "the optional AST binding is available",
    )


CROSSINGS: tuple[Crossing, ...] = (
    Crossing(
        name="canonical_organs_are_wired",
        claim="which gates actually run in this repo",
        organs=("gate_effectiveness.COMPUERTAS_CANONICAS", ".pre-commit-config.yaml"),
        run=cross_canonical_organs_are_wired,
    ),
    Crossing(
        name="template_matches_live_config",
        claim="which organ each hook runs, and with which flags",
        organs=(".pre-commit-config.yaml", "cli_new._pre_commit_config"),
        run=cross_template_matches_live_config,
    ),
    Crossing(
        name="runner_digest_matches_manifest",
        claim="whether a satellite's bundled runtime is stale",
        organs=("cli_new._portable_runner", "RUNTIME_MANIFEST.json"),
        run=cross_runner_digest_matches_manifest,
    ),
    Crossing(
        name="git_readings_handle_worktrees",
        claim="whether a path is a git repository",
        organs=("hook_receipts.is_git_repo", "every other `.git` test in the kit"),
        run=cross_git_readings_handle_worktrees,
    ),
    Crossing(
        name="evidence_readers_agree",
        claim="whether a done entry has shown its evidence.fail",
        organs=("finding_backlog via ledger.evidence_fail_path",
                "simplecode.verification.ledger_schema"),
        run=cross_evidence_readers_agree,
    ),
    Crossing(
        name="h2_controls_vs_disposition_ledger",
        claim="whether any planted control has ever been observed as a block",
        organs=("detector_controls", "telemetry_dispositions"),
        run=cross_h2_controls_vs_disposition_ledger,
    ),
    Crossing(
        name="semantic_gap_readers_agree",
        claim="which tracked Rust/TypeScript files have no AST-semantic detector",
        organs=("pattern_detectors.unanalysed_semantic_source", "zero_debt._semantic_gap"),
        run=cross_semantic_gap_readers_agree,
    ),
)


def run_crossings(root: Path) -> list[tuple[Crossing, CrossingResult]]:
    return [(c, c.run(root)) for c in CROSSINGS]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Cross organs that assert the same thing (mould c)")
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--gate", action="store_true", help="Exit 1 on any DIVERGE")
    args = parser.parse_args(argv)

    results = run_crossings(args.root.resolve())
    counts = {AGREE: 0, DIVERGE: 0, CANNOT_CROSS: 0}
    for crossing, result in results:
        counts[result.verdict] += 1
        mark = {AGREE: "🟢", DIVERGE: "🔴", CANNOT_CROSS: "🟡"}[result.verdict]
        print(f"{mark} {result.verdict:<13} {crossing.name}")
        print(f"      claim : {crossing.claim}")
        print(f"      organs: {crossing.organs[0]}  ⇄  {crossing.organs[1]}")
        print(f"      {result.detail}")

    # The zeros print. A CANNOT_CROSS is a declared impossibility carried in a
    # reviewed commit, so it does NOT block -- blocking on it would make the
    # declaration pointless and the honest reason unwritable. It is counted and
    # named instead, which is the whole difference between this and silence.
    print(
        f"[organ-crossings] declared crossings: {len(results)} -> "
        f"agree: {counts[AGREE]} · diverge: {counts[DIVERGE]} · "
        f"cannot_cross (declared, does NOT block): {counts[CANNOT_CROSS]}"
    )
    print("[organ-crossings] completeness is NOT asserted: a crossing exists because someone wrote it.")
    if counts[DIVERGE]:
        return 1 if args.gate else 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
