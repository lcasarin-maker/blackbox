# -*- coding: utf-8 -*-
"""coverage_blind_modules.py -- flag Python modules with real size and 0% coverage.

DEBT-COVERAGE-BLIND-MODULES-NO-GENERIC-GATE: Aequitas and DescargaSAT each
independently wrote the same check -- any Python module with more than 20
statements and 0% test coverage is a red flag -- both reading this repo's own
coverage artifact, `.simplecode/coverage.json` (produced by
`simplecode.verification.coverage_target`, see that module's `main` for how
it is written). The canon only offered a global 100%-coverage gate, nothing
that names WHICH modules are entirely untested. The duplication across two
satellites is the evidence this is a real cross-fleet need, not a one-off.

This module is the canonical, satellite-configurable version: it reads the
same artifact, reports the threshold it actually applied (so a caller cannot
misread which cutoff was used), and returns COULD_NOT_RUN when the artifact
is missing -- never a silent pass or fail as if the check had run.

Standalone by design: not wired into `.pre-commit-config.yaml`. The ficha's
own `close_check` only requires the regression test to pass, and this repo's
own coverage gate (`coverage_target.py`) already owns the pre-push coverage
hook -- adding a second coverage-shaped hook without a satellite asking for
it would be exactly the kind of unmeasured addition `ponytail` exists to
flag. Left as a runnable module a satellite (or a future canon hook) can
invoke explicitly.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import NamedTuple

# The artifact `coverage_target.main` writes -- see that module's `main`,
# "Written under .simplecode/ ... rather than the default `coverage.json` at
# repo root." Read from the SAME path here rather than duplicating a second
# convention for where coverage lives.
COVERAGE_JSON_RELPATH = Path(".simplecode") / "coverage.json"

# Per-satellite tuning, same pattern as `backlog_verifier.CUTOFF_CONFIG_RELPATH`:
# a small JSON file under `.simplecode/`, absent by default, never required.
CONFIG_RELPATH = Path(".simplecode") / "coverage_blind_modules.json"

# What both satellites (Aequitas, DescargaSAT) used before this existed.
DEFAULT_THRESHOLD = 20


class BlindModule(NamedTuple):
    """One module whose statement count clears the threshold with zero coverage."""

    path: str
    num_statements: int


def load_threshold(root: Path) -> tuple[int, str]:
    """The statement-count threshold, from `.simplecode/coverage_blind_modules.json`.

    Absent config falls back to `DEFAULT_THRESHOLD`; so does a malformed one,
    with a warning naming exactly what was wrong. This file is optional
    per-satellite tuning, not a required artifact -- only `.simplecode/coverage.json`
    (checked in `main`) can produce a COULD_NOT_RUN. Same fail-toward-a-safe-default
    shape as `backlog_verifier.task_contract_cutoff` reading its own cutoff config.

    Returns `(threshold, note)`: `note` is the human-readable line `main` prints so a
    reader always sees which cutoff was actually applied, never has to guess.
    """
    cfg = root / CONFIG_RELPATH
    if not cfg.is_file():
        return DEFAULT_THRESHOLD, (
            f"no {CONFIG_RELPATH.as_posix()} declared: default threshold {DEFAULT_THRESHOLD}"
        )
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
        threshold = int(data["threshold"])
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(
            f"[coverage-blind-modules] {CONFIG_RELPATH.as_posix()} is unreadable or "
            f"malformed ({exc!r}); falling back to default threshold {DEFAULT_THRESHOLD}",
            file=sys.stderr,
        )
        return DEFAULT_THRESHOLD, (
            f"{CONFIG_RELPATH.as_posix()} malformed -- default threshold {DEFAULT_THRESHOLD}"
        )
    if threshold < 0:
        print(
            f"[coverage-blind-modules] {CONFIG_RELPATH.as_posix()} declares a negative "
            f"threshold ({threshold}); falling back to default threshold {DEFAULT_THRESHOLD}",
            file=sys.stderr,
        )
        return DEFAULT_THRESHOLD, (
            f"{CONFIG_RELPATH.as_posix()} declares negative threshold -- "
            f"default threshold {DEFAULT_THRESHOLD} applied instead"
        )
    return threshold, f"threshold {threshold} (from {CONFIG_RELPATH.as_posix()})"


def find_blind_modules(coverage_json: Path, threshold: int) -> list[BlindModule] | None:
    """Modules whose `num_statements` exceeds `threshold` AND whose `covered_lines`
    is exactly zero, read from a pytest-cov JSON report.

    Real shape of that report (verified by running `coverage_target.main` on this
    repo and reading its own `.simplecode/coverage.json`):

        {"meta": {...},
         "files": {"<relpath>": {"summary": {"num_statements": int,
                                              "covered_lines": int,
                                              "percent_covered": float, ...},
                                  ...}, ...},
         "totals": {...}}

    `covered_lines == 0` is used rather than `percent_covered == 0.0` -- both are
    equivalent whenever `num_statements > 0` (which the threshold already implies
    for any positive threshold), but the integer comparison never carries a
    float-equality hazard for a threshold of 0.

    Returns None when the artifact is missing, unparseable, or missing the `files`
    mapping this check depends on -- the caller turns that into COULD_NOT_RUN,
    never a silent pass or fail.
    """
    if not coverage_json.is_file():
        return None
    try:
        data = json.loads(coverage_json.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    files = data.get("files")
    if not isinstance(files, dict):
        return None

    blind: list[BlindModule] = []
    for path, entry in files.items():
        if not isinstance(entry, dict):
            continue
        summary = entry.get("summary")
        if not isinstance(summary, dict):
            continue
        try:
            num_statements = int(summary.get("num_statements", 0))
            covered_lines = int(summary.get("covered_lines", 0))
        except (TypeError, ValueError):
            continue
        if num_statements > threshold and covered_lines == 0:
            blind.append(BlindModule(path=str(path), num_statements=num_statements))
    blind.sort(key=lambda m: (-m.num_statements, m.path))
    return blind


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Flag Python modules with real size and 0% test coverage, "
                    "read from .simplecode/coverage.json (DEBT-COVERAGE-BLIND-MODULES-NO-GENERIC-GATE)."
    )
    parser.add_argument("--root", type=Path, default=Path("."), help="Repository root directory")
    parser.add_argument(
        "--gate", action="store_true",
        help="Exit 1 when blind modules are found. Without this flag the run is "
             "consultative: it reports and exits 0 (a missing coverage.json still "
             "exits 2, COULD_NOT_RUN, regardless of --gate).",
    )
    args = parser.parse_args(argv)
    root = args.root.resolve()

    coverage_json = root / COVERAGE_JSON_RELPATH
    threshold, threshold_note = load_threshold(root)
    blind = find_blind_modules(coverage_json, threshold)
    if blind is None:
        print(
            f"[coverage-blind-modules] COULD_NOT_RUN: {COVERAGE_JSON_RELPATH.as_posix()} "
            "is missing or unparseable -- run the coverage gate first "
            "(python -m simplecode.verification.coverage_target) to produce it",
            file=sys.stderr,
        )
        return 2

    print(f"[coverage-blind-modules] {threshold_note}")
    if not blind:
        print(f"[coverage-blind-modules] OK: no module exceeds {threshold} statement(s) at 0% coverage")
        return 0

    print(f"[coverage-blind-modules] {len(blind)} module(s) exceed {threshold} statement(s) at 0% coverage:")
    for module in blind:
        print(f"  - {module.path}: {module.num_statements} statements, 0% covered")
    if args.gate:
        print("[coverage-blind-modules] FAIL: blind modules found")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
