#!/usr/bin/env python3
"""Install fail-closed Git launchers around the canonical pre-commit stages."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.utils.git_utils import hooks_dir as _resolve_hooks_dir


def _uses_bundled_runtime(root: Path) -> bool:
    return (root / ".simplecode" / "run.py").is_file()


def _preamble(root: Path) -> str:
    """Shell prologue shared by every launcher: enter the checkout, find the runtime.

    Git installs ONE set of hooks per repository (`$GIT_COMMON_DIR/hooks`), but
    `.simplecode/` is gitignored local runtime that `git worktree add` never
    copies. Every commit from every linked worktree therefore died with
    `can't open file .../.simplecode/run.py`, exit 2, before a single check ran.

    Pointing only this launcher at the main checkout is NOT enough: the canonical
    `.pre-commit-config.yaml` addresses `.simplecode/run.py` by that literal path
    in 25 hook entries, so `staged-parity`, `truncation-guard` and the rest keep
    failing inside the worktree. Rewriting all 25 in every satellite would drag
    project-local config edits along with a runtime fix, so instead link the two
    runtime files into the worktree's own `.simplecode/` (which exists, and is
    tracked, because `corpus_exempt.yaml` lives there). Symlinks rather than
    copies: one runtime per repository, so a worktree can never drift from its
    main checkout, and the link is re-made on every run if it goes missing.

    With no runtime found we exit 2 rather than commit unverified -- the gate is
    fail-closed by design.

    Two more worktree defects, reported live (Atlas, 2026-08-27), fixed here:

      * `GIT_DIR`/`GIT_WORK_TREE` leak. Git sets these when invoking a hook
        from a linked worktree so the hook's OWN git commands resolve the
        right worktree; but this launcher execs a whole test suite
        (`pytest` via the coverage-floor hook), and any
        test that shells out to its own `git init`/`git add` in a scratch
        directory silently inherits that context instead of creating an
        independent repo -- `git add -A` failing with exit 128 in a brand
        new `/tmp` repo, reproduced identically across two independent runs
        (ruling out a flaky/concurrent cause), only inside the real hook
        chain, never invoking the same commands directly. Unset right after
        `cd "$ROOT"`: our own subsequent git calls resolve fine from cwd
        without them, and nothing downstream (including any subprocess a
        test spawns) can inherit what is no longer exported.
      * `.venv` resolution used `$ROOT` (the worktree's own directory, which
        `git worktree add` never provisions a venv into) instead of the
        MAIN checkout that actually has one -- so pyright and
        backlog-verifier silently fell back to unpinned system tools with
        no warning (a stale pyright version re-reporting two files a prior
        commit had already fixed to 0 errors). `MAIN` was already computed
        for the `.simplecode/run.py` worktree-link case below; hoisted here
        so the venv check uses it too, for BOTH runtime shapes -- a
        bundled-runtime satellite AND a `pip install -e .` checkout like
        this repo's own dev venv can both be linked worktrees.
      * `.venv` resolution only ever checked `$ROOT/.venv` and `$MAIN/.venv`
        -- a repo whose venv lives one level down (e.g. `backend/.venv` in a
        monorepo split between a backend and a frontend) never matched
        either, so the hook silently ran with the system interpreter.
        Reported live (aequitas_os, 2026-08-28): `coverage-100` failed with
        `ModuleNotFoundError: No module named 'pypdf'` even though `pypdf`
        was installed in `backend/.venv` -- `pip show` confirmed it present,
        the hook just never looked there. Added a one-level-deep scan of
        `$ROOT`'s and `$MAIN`'s immediate subdirectories for a `.venv/bin`,
        tried only after the existing root/main checks both miss, so the
        common case (venv at the repo root) pays no extra cost.
    """
    head = (
        "#!/bin/sh\n"
        "# simplecode-managed-hook:v1\n"
        "ROOT=$(git rev-parse --show-toplevel) || exit 2\n"
        'cd "$ROOT" || exit 2\n'
        "unset GIT_DIR GIT_WORK_TREE\n"
        "COMMON=$(git rev-parse --path-format=absolute --git-common-dir) || exit 2\n"
        'MAIN=$(cd "$COMMON/.." && pwd) || exit 2\n'
        'VENV_ROOT="$ROOT"\n'
        '[ -d "$ROOT/.venv/bin" ] || VENV_ROOT="$MAIN"\n'
        'if [ ! -d "$VENV_ROOT/.venv/bin" ]; then\n'
        '  for _vd in "$ROOT"/*/ "$MAIN"/*/; do\n'
        '    if [ -d "${_vd}.venv/bin" ]; then VENV_ROOT="${_vd%/}"; break; fi\n'
        "  done\n"
        "fi\n"
        '[ ! -d "$VENV_ROOT/.venv/bin" ] || PATH="$VENV_ROOT/.venv/bin:$PATH"\n'
        "export PATH\n"
    )
    if not _uses_bundled_runtime(root):
        return head + "RUNNER='python -m'\n"
    # The guard tests EITHER file, and the check afterwards tests BOTH.
    #
    # It used to enter this block only when `run.py` was missing, while linking
    # two files inside it -- so a worktree that had the runner and not the
    # bundle skipped the linking entirely and then died inside python with an
    # unrelated message. Measured in Atlas 2026-09-02 (DGX-434) with a paired
    # control: 9 kit tests fail in a fresh worktree and pass with `runtime.zip`
    # copied in by hand, same tree, and coders had been copying it manually
    # before every suite.
    #
    # The explicit COULD_NOT_RUN now names WHICH file is missing. A gate that
    # cannot run must say so and stop; the failure this replaces was a gate
    # that could not run and let python explain it three layers down.
    # PER FILE, and never over a path this repo TRACKS (DEBT-PUSH-LOOP-11,
    # diagnosed by the determined-haslett session 2026-09-15 and measured on
    # both halves of the fleet before this shape was chosen).
    #
    # The shape this replaces was one OR-guard over two files and then an
    # UNCONDITIONAL link of both. The two files have opposite git status, and
    # that is the whole defect: `.simplecode/run.py` is gitignored (pure cache,
    # absent in a fresh worktree), while `.simplecode/runtime.zip` is TRACKED in
    # the kit and in most satellites, so git materialises it in every worktree.
    # The guard was therefore satisfied by the absence of run.py, and the next
    # line overwrote a tracked, present, correct bundle with a symlink carrying
    # an absolute machine path -- a 100644 -> 120000 typechange nobody asked for.
    # Measured: it happened in two worktrees of this repo in one day.
    #
    # And "never link the bundle" is NOT the fix either, measured on the fleet
    # the same day: `git ls-files .simplecode/runtime.zip` returns it in
    # simplecode, declutter and RePic, but in Atlas the path is gitignored, so
    # there the link is the ONLY way a worktree ever gets a runtime -- removing
    # it would turn every Atlas worktree's first hook into a COULD_NOT_RUN.
    # Tracking is what separates the two cases, so tracking is what the
    # condition reads. A tracked file that is missing is a broken checkout: that
    # is the verify loop's business below, not something a hook repairs behind
    # the repo's back.
    return head + (
        'for f in run.py runtime.zip; do\n'
        '  [ -e "$ROOT/.simplecode/$f" ] && continue\n'
        '  git ls-files --error-unmatch ".simplecode/$f" >/dev/null 2>&1 && continue\n'
        '  [ "$MAIN" != "$ROOT" ] || continue\n'
        '  [ -f "$MAIN/.simplecode/$f" ] || continue\n'
        '  mkdir -p "$ROOT/.simplecode" || exit 2\n'
        '  ln -sfn "$MAIN/.simplecode/$f" "$ROOT/.simplecode/$f" || exit 2\n'
        'done\n'
        'for f in run.py runtime.zip; do\n'
        '  [ -f "$ROOT/.simplecode/$f" ] || { echo "[hook] COULD_NOT_RUN: .simplecode/$f not found" >&2; exit 2; }\n'
        'done\n'
        "RUNNER='python .simplecode/run.py'\n"
    )


_SKIP_ON_ALL_DELETE = (
    "# A ref-deletion push (e.g. `git push origin --delete <branch>`) touches\n"
    "# zero files -- git still invokes pre-push and feeds it the ref update\n"
    "# lines on stdin (`<local ref> <local oid> <remote ref> <remote oid>`),\n"
    "# a delete's local oid is all-zero. Running the full --all-files suite\n"
    "# (coverage-100, a fresh-venv dist build, pyright, red-team, ...) against\n"
    "# a push with nothing to verify was measured taking the same 2-4 minutes\n"
    "# as a real content push, for every branch deletion.\n"
    "#\n"
    "# ZERO lines on stdin is NOT a deletion push (DEBT-PUSH-LOOP-04, decision\n"
    "# by Luis 2026-09-15). This block used to start ALL_DELETE=1 and lower it\n"
    "# only on a non-delete line, so an EMPTY stdin -- nobody said anything --\n"
    "# fell straight through to `exit 0` and the hook verified nothing at all.\n"
    "# That is precisely how a non-git caller invokes this script: `make check`\n"
    "# runs it `< /dev/null`, because make would otherwise leave the terminal\n"
    "# on stdin and this `read` would hang forever. So the rehearsal would have\n"
    "# skipped the entire suite and reported green in seconds.\n"
    "# REFS_SEEN separates the two cases: silence means VERIFY, and only lines\n"
    "# that were actually read and were ALL deletions skip. The saving the\n"
    "# skip bought is unchanged -- it is pinned by its own negative-control\n"
    "# test (test_a_real_ref_deletion_push_still_skips_the_whole_suite).\n"
    "REFS_SEEN=0\n"
    "ALL_DELETE=1\n"
    "SIMPLECODE_PUSH_REFS=''\n"
    'while read -r _lref _loid _rref _roid; do\n'
    "  REFS_SEEN=1\n"
    '  SIMPLECODE_PUSH_REFS="${SIMPLECODE_PUSH_REFS}${_loid}:${_roid},"\n'
    '  case "$_loid" in\n'
    "    0000000000000000000000000000000000000000|"
    "0000000000000000000000000000000000000000000000000000000000000000) ;;\n"
    "    *) ALL_DELETE=0 ;;\n"
    "  esac\n"
    "done\n"
    "export SIMPLECODE_PUSH_REFS\n"
    'if [ "$REFS_SEEN" = "1" ] && [ "$ALL_DELETE" = "1" ]; then\n'
    '  echo "[gate-runner] pre-push: all refs are deletions, nothing to verify -- skipped" >&2\n'
    "  exit 0\n"
    "fi\n"
)


# Decision by Luis, 2026-09-15. The rationale is emitted INTO the generated
# script rather than kept here, because the reader who needs it is the operator
# staring at `.git/hooks/pre-push` after a failed push, not a reader of this
# module. Local-skip settings and runner preference are built by `_PREFER_PREK`
# and `_launcher`.
_DISPOSITION_WHY = (
    "# telemetry-disposition is no longer a configured hook. The launcher runs\n"
    "# its bookkeeping command once after a green pre-push suite, so it can use\n"
    "# the current run's verdicts. A red suite exits before that final step.\n"
    "# Measured in Atlas: of 184 blocked attempts, 97 had a cheap gate AND an\n"
    "# expensive one red at once, so stopping at the cheap one would have hidden\n"
    "# the expensive one and cost a second full round trip to find it. The only\n"
    "# conditional is the `rc` check, and it guards ONLY the disposition step --\n"
    "# a suite that failed has no greens to dispose against.\n"
    "# ONE run_id for the whole attempt: the suite and the disposition step are\n"
    "# separate processes, so without this export the final step mints its own\n"
    "# and one push's rows carry two ids (measured 2026-09-15: 27 + 1). Empty\n"
    "# counts as unset (`:-`), same rule as gate_runner.\n"
    'export SIMPLECODE_RUN_ID="${SIMPLECODE_RUN_ID:-$(date +%s)-$$}"\n'
)


_DISPOSITION_STEP = (
    "exec $RUNNER simplecode.verification.gate_runner --root . "
    "--name telemetry-disposition --hook pre-push -- "
    "$RUNNER simplecode.verification.telemetry_dispositions --root . --gate\n"
)


# Printed when the pre-push SUITE blocks (not when gitleaks-outgoing does: that step stops the
# push before any gate row of an attempt exists, so there is nothing to recheck). Attempt 1 is
# unchanged, it still runs every gate; this is the cheap step before attempt 2.
_BLOCKED_HINT = (
    '[ "$rc" = 0 ] || echo "[pre-push] blocked. Before paying a full retry, re-run what was '
    "red plus the cheap gates: $RUNNER simplecode.verification.push_recheck --repo . "
    '(add --only-red for the red ones alone)" >&2\n'
)


_PREFER_PREK = (
    "# prek (ADR-0009 fork&own, src/simplecode/verification/prek_vendor.py) is\n"
    "# a drop-in for pre-commit that reads THIS SAME .pre-commit-config.yaml\n"
    "# unchanged. On that file alone it runs the hooks one after another: measured\n"
    "# 2026-10-06 over the fleet, gate-seconds per wall-second 0.94-1.00 in all 17\n"
    "# repos. It runs them concurrently only for hooks that share a `priority:`\n"
    "# key, which plain pre-commit does not know (it warns once per hook) and which\n"
    "# the fleet-synced file therefore must not carry. So prek reads a schedule\n"
    "# generated from that file just before the run (prek_schedule.py) and the\n"
    "# shared file never changes. If the schedule cannot be generated the suite\n"
    "# still runs, serially, on the shared file -- said out loud, never skipped.\n"
    "# Opportunistic: a satellite where prek can't be fetched/verified (offline,\n"
    "# unsupported platform) silently falls through to plain pre-commit below --\n"
    "# same correctness, just the old serial dispatch, never a COULD_NOT_RUN for\n"
    "# lacking a tool this hook doesn't strictly need.\n"
    'PREK_BIN=$($RUNNER simplecode.verification.prek_vendor --root . --print-path 2>/dev/null)\n'
    'if [ -n "$PREK_BIN" ] && [ -x "$PREK_BIN" ]; then\n'
    "  $RUNNER simplecode.verification.gate_runner --root . "
    "--name gitleaks-outgoing --hook pre-push -- $RUNNER "
    'simplecode.verification.gitleaks_outgoing --root . --runner "$PREK_BIN"\n'
    '  rc=$?\n'
    '  [ "$rc" = 0 ] || exit "$rc"\n'
    # Same shape guard as LOCAL_SKIP below: `$(...)` captures the runner's whole
    # stdout, so only the one path the module prints is accepted as the config.
    '  PREK_CONFIG=$($RUNNER simplecode.verification.prek_schedule --root .)\n'
    '  case "$PREK_CONFIG" in\n'
    '    .simplecode/prek-schedule.yaml) ;;\n'
    '    *) echo "[prek-schedule] no schedule generated; running the suite serially" >&2\n'
    '       PREK_CONFIG=.pre-commit-config.yaml ;;\n'
    '  esac\n'
    "  $RUNNER simplecode.verification.gate_runner --root . "
    "--name pre-push --hook pre-push -- "
    '"$PREK_BIN" run --config "$PREK_CONFIG" --stage pre-push --all-files'
    # ponytail: no-op on the current canon (its only gitleaks hook is commit-stage),
    # needed by a satellite still composing the old two-entry config; delete when
    # `sync-satellites --plan` shows no satellite with a pre-push gitleaks.
    " --skip gitleaks\n"
    "  rc=$?\n"
    "  " + _BLOCKED_HINT
    + '  [ "$rc" = 0 ] || exit "$rc"\n'
    "  " + _DISPOSITION_STEP
    + "fi\n"
)


_APPLY_LOCAL_SKIP_CONFIG = (
    "# Lefthook-inspired mechanism (2026-08-31): .simplecode/hooks-local.yaml,\n"
    "# gitignored, per-developer, never synced fleet-wide -- lets one\n"
    "# developer skip a hook blocking them locally without touching the\n"
    "# shared .pre-commit-config.yaml, which satellite_sync would overwrite\n"
    "# on the next fleet sync anyway. Both pre-commit and prek already\n"
    "# honor the standard SKIP env var (a comma-joined hook id list,\n"
    "# verified live), so this only needs to read the local file and\n"
    "# export it. DEBT-AEQUITAS-07 (2026-09-08): gate_runner ALSO reads this\n"
    "# same SKIP env var, but keyed to its own --name (a telemetry label),\n"
    "# not to the id: above -- a value matching neither leaves the wrapped\n"
    "# command running in full, so double check which id: a hook actually\n"
    "# declares before setting SKIP to silence it.\n"
    'LOCAL_SKIP=$($RUNNER simplecode.verification.hook_local_config --root .)\n'  # sunset-reviewed: 9.7 -- local skip is accepted only from a successful reader; stderr remains visible
    'LOCAL_SKIP_RC=$?\n'
    'if [ "$LOCAL_SKIP_RC" -ne 0 ]; then\n'
    '  echo "[hook-install] local hook configuration could not be read (exit $LOCAL_SKIP_RC)" >&2\n'
    '  exit "$LOCAL_SKIP_RC"\n'
    'fi\n'
    # Shape guard (2026-09-06, D4 transferida desde aequitas_os). `$(...)` above
    # captures the RUNNER's whole stdout, not just the module's answer -- and the
    # runner resyncs the satellite before delegating, so anything printed on that
    # path lands here. A real hook id is `[A-Za-z0-9_,.-]+` (measured: 40 of 40
    # ids in .pre-commit-config.yaml), so prose never survives this case. That
    # closes the CHANNEL, not only today's banner: a future message carrying a
    # real gate name would still be rejected, because it would carry a space too.
    'case "$LOCAL_SKIP" in "" | *[!A-Za-z0-9_,.-]*) ;; *) export SKIP="$LOCAL_SKIP" ;; esac\n'  # sunset-reviewed: 9.7 -- the reviewed SKIP export, now shape-guarded; mechanism unchanged since 4.5 (fdc9384), the guard added 5.8 (D4) after a real false BYPASS in aequitas_os
    # D5 (2026-09-06, transferida desde aequitas_os): este script se REESCRIBE
    # entero desde la plantilla en cada sync, asi que un ajuste hecho a mano aqui
    # se pierde. Medido alli: el kit cambio 4 veces en una sesion y su linea
    # `. "$HOME/.aequitas_hook_env"` desaparecio 2 veces; sin ese entorno su
    # conftest salia con exit 4 y backlog_verifier lo leyo como reproduccion --
    # 8 acusaciones de fraude contra fichas sanas. La cura es que el ajuste deje de
    # vivir en el script generado: `.simplecode/hooks-local.yaml` (gitignored, nunca
    # sincronizado) gana un campo `env_file:` y el launcher lo sourcea aqui, DESPUES
    # de `export PATH` para que el fichero pueda usarlo, y ANTES del despacho.
    #
    # Invocacion separada de la de SKIP a proposito: mezclar dos respuestas en el
    # stdout que `$(...)` captura es la causa exacta de D4. Y el mismo guardian de
    # forma, adaptado a una ruta: debe empezar por `/` y no llevar espacios ni
    # comillas, asi que ninguna prosa impresa por el resync puede convertirse en un
    # `.` de un fichero arbitrario. `hook_local_config` ya rechazo antes lo que
    # estuviera dentro del repo o fuera escribible por otros, y dijo por que.
    'LOCAL_ENV=$($RUNNER simplecode.verification.hook_local_config --root . --env-file 2>/dev/null)\n'
    'case "$LOCAL_ENV" in /*[!\\ \\"\\\']*|/) [ -f "$LOCAL_ENV" ] && . "$LOCAL_ENV" ;; esac\n'
)


def _launcher(root: Path, stage: str) -> str:
    all_files = " --all-files" if stage == "pre-push" else ""
    receipt = " --receipt" if stage == "pre-commit" else ""
    skip_check = _SKIP_ON_ALL_DELETE if stage == "pre-push" else ""
    prefer_prek = _PREFER_PREK if stage == "pre-push" else ""
    real_command = (
        "$RUNNER simplecode.verification.gate_runner --root . "
        f"--name {stage} --hook {stage}{receipt} -- pre-commit run "
        f"--config .pre-commit-config.yaml --hook-stage {stage}{all_files}"
    )
    # Lefthook-inspired mechanism (2026-08-31): re-stage files a hook
    # modified in place (e.g. an auto-fixer) so the commit about to happen
    # actually includes them -- see stage_fixed.py. Pre-commit-stage only:
    # pre-push has no notion of "about to commit", so re-staging there
    # would be meaningless. Wraps rather than replaces the real command.
    if stage == "pre-commit":
        dispatch = (
            f"exec $RUNNER simplecode.verification.stage_fixed --root . -- {real_command}\n"
        )
    else:
        # No-prek fallback. `pre-commit` has no `--skip` flag; it honors the
        # `SKIP` env var (a comma-joined id list) that `_APPLY_LOCAL_SKIP_CONFIG`
        # above may already have exported. Merge the outgoing-range scan's
        # `gitleaks` selector instead of overwriting a developer's local list.
        # The disposition hook was removed from the config; its separate
        # bookkeeping command runs after the suite only when the suite is green.
        dispatch = (
            "$RUNNER simplecode.verification.gate_runner --root . "
            "--name gitleaks-outgoing --hook pre-push -- $RUNNER "
            "simplecode.verification.gitleaks_outgoing --root . --runner pre-commit\n"
            "rc=$?\n"
            '[ "$rc" = 0 ] || exit "$rc"\n'
            f'SKIP="${{SKIP:+$SKIP,}}gitleaks" {real_command}\n'  # sunset-reviewed: 9.7 -- gitleaks-outgoing se ejecuta antes de la suite y el hook configurado se omite dentro de ella; telemetry-disposition ya no es un hook de la configuración
            "rc=$?\n"
            + _BLOCKED_HINT
            + '[ "$rc" = 0 ] || exit "$rc"\n'
            + _DISPOSITION_STEP
        )
    why = _DISPOSITION_WHY if stage == "pre-push" else ""
    return (_preamble(root) + _APPLY_LOCAL_SKIP_CONFIG + skip_check
            + why + prefer_prek + dispatch)


def _post_commit(root: Path) -> str:
    return _preamble(root) + (
        "exec $RUNNER simplecode.verification.hook_receipts --root . --stamp-head\n"
    )


def install_hooks(root: Path) -> bool:
    """Install pre-commit, pre-merge-commit, pre-push, post-commit, and
    post-merge launchers."""
    root = root.resolve()
    hooks = _resolve_hooks_dir(root)
    if hooks is None:
        print(f"[hook-install] FAIL: {root} is not a Git worktree", file=sys.stderr)
        return False
    # `pre-merge-commit` is NOT optional company for `pre-commit`: git does not
    # run pre-commit for a merge commit, it runs this hook instead, and it does
    # not exist unless something writes it. Without it every staged gate is
    # skipped on a merge, and `hook-receipts-gate` then refuses the push because
    # those commits carry no receipt -- so a repo that merges cannot push at all.
    # Reported by declutter 2026-09-01 after mother-sync erased their local fix
    # twice in one session; the same hole is in this repo (0 hooks declared that
    # stage before this change). Same shape as the revert/cherry-pick bypass
    # already closed in 8aea888, with the merge path left open.
    #
    # `post-merge` closes the twin hole (DEBT-AEQUITAS-08, reported by
    # declutter 2026-09-14): `pre-merge-commit` WRITES the receipt nonce (via
    # `--receipt`), but the nonce is CONSUMED by `hook_receipts --stamp-head`,
    # which only `post-commit` ran -- and git does not run `post-commit` after
    # a merge either, it runs `post-merge`. So the nonce got written and never
    # read: every clean, automatic merge left HEAD unstamped, and
    # `hook-receipts-gate` reported it as a bypass at push time when none
    # occurred. `_post_commit`'s launcher is reused verbatim: `--stamp-head`
    # reads `git rev-parse HEAD` and the receipt record fresh each call, with
    # no assumption about what kind of commit produced that HEAD.
    scripts = {
        "pre-commit": _launcher(root, "pre-commit"),
        "pre-merge-commit": _launcher(root, "pre-commit"),
        "pre-push": _launcher(root, "pre-push"),
        "post-commit": _post_commit(root),
        "post-merge": _post_commit(root),
    }
    try:
        for name, content in scripts.items():
            target = hooks / name
            atomic_io.write_text_durable(target, content)
            target.chmod(0o755)
    except OSError as exc:
        print(f"[hook-install] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return False
    # stderr, not stdout, for all three verdicts above and below: `install_hooks`
    # runs from inside run.py's lazy resync, which happens BEFORE run.py delegates
    # to the requested module -- and the launcher captures that stdout into
    # LOCAL_SKIP. Measured in aequitas_os 2026-09-06: this banner became
    # the banner began with a local-skip environment assignment followed by
    # hook names; gate_runner._skipped_gates() parsed them into 4 "skipped gates"
    # and reported as BYPASS after every fleet sync. run.py's own messages already
    # went to stderr for exactly this reason; this module never got the memo.
    print("[hook-install] OK: pre-commit, pre-merge-commit, pre-push, "
          "post-commit, and post-merge installed", file=sys.stderr)
    return True


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    args = parser.parse_args(argv)
    return 0 if install_hooks(args.root) else 1


if __name__ == "__main__":
    raise SystemExit(main())
