# -*- coding: utf-8 -*-
"""mutation_verify.py -- Targeted mutation testing (Fase 1, ADR-0012 remediation).

The 5 static test-quality detectors (covert_test_skip, opaque_boolean_assertion,
test_without_assert, test_atrophy_detector, blind_mock_injection) all ask the same
Goodhart-gameable question: "does this test's SYNTAX look weak?" A motivated agent
can satisfy any syntactic pattern-matcher without doing real verification work --
`assert result is not None`, `assert True`, a beautifully-shaped `pytest.raises`
with nothing checked inside it, all read as "fine" to a shape detector.

This module asks the question that can't be gamed the same way: "if the source
this test exercises actually broke, would the test notice?" A syntactically
perfect assertion an agent can fabricate; a test that fails when its subject's
real behavior changes cannot be faked without the agent doing the verification
it was trying to skip.

Deliberately NOT wired as a fast pre-commit gate: mutating source and re-running
pytest per mutant is not O(1) the way the rest of simplecode's detectors are.
This is a slower, pre-push-only or manually-triggered confirmatory check over a
SMALL, bounded set of mutations per test -- not exhaustive mutation testing.
"""
from __future__ import annotations

import argparse
import ast
import copy
import logging
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator, NamedTuple

from simplecode.utils import atomic_io
from simplecode.utils.tool_limits import SMOKE_SUITE_TIMEOUT

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Mutation generation
# ---------------------------------------------------------------------------

_COMPARE_FLIPS: dict[type, type] = {
    ast.Eq: ast.NotEq,
    ast.NotEq: ast.Eq,
    ast.Lt: ast.GtE,
    ast.LtE: ast.Gt,
    ast.Gt: ast.LtE,
    ast.GtE: ast.Lt,
    ast.Is: ast.IsNot,
    ast.IsNot: ast.Is,
}

_BOOLOP_FLIPS: dict[type, type] = {
    ast.And: ast.Or,
    ast.Or: ast.And,
}


@dataclass(frozen=True)
class Mutant:
    """One candidate mutation: the full mutated module source, plus a human
    description of what changed and where, for reporting a surviving mutant."""
    source: str
    description: str
    lineno: int


class _SingleNodeMutator(ast.NodeTransformer):
    """Applies exactly ONE mutation (the `target_id`-th mutable node found in
    a left-to-right walk) and leaves everything else untouched. Rerun once per
    candidate index to get one mutant at a time -- keeps each mutant a minimal,
    single-fault change, the mutation-testing convention (a multi-fault mutant
    can mask survivors behind an unrelated crash)."""

    def __init__(self, target_id: int):
        self.target_id = target_id
        self.seen = -1
        self.description: str | None = None
        self.lineno = 0

    def _claim(self, node: ast.AST, description: str) -> bool:
        self.seen += 1
        if self.seen == self.target_id:
            self.description = description
            self.lineno = getattr(node, "lineno", 0)
            return True
        return False

    def visit_Compare(self, node: ast.Compare) -> ast.AST:
        self.generic_visit(node)
        new_ops = list(node.ops)
        for i, op in enumerate(node.ops):
            flip = _COMPARE_FLIPS.get(type(op))
            if flip is not None and self._claim(node, f"flip {type(op).__name__} -> {flip.__name__}"):
                new_ops[i] = flip()
                node.ops = new_ops
                return node
        return node

    def visit_BoolOp(self, node: ast.BoolOp) -> ast.AST:
        self.generic_visit(node)
        flip = _BOOLOP_FLIPS.get(type(node.op))
        if flip is not None and self._claim(node, f"flip {type(node.op).__name__} -> {flip.__name__}"):
            node.op = flip()
        return node

    def visit_UnaryOp(self, node: ast.UnaryOp) -> ast.AST:
        self.generic_visit(node)
        if isinstance(node.op, ast.Not) and self._claim(node, "drop `not`"):
            return node.operand
        return node

    def visit_Constant(self, node: ast.Constant) -> ast.AST:
        if isinstance(node.value, bool):
            if self._claim(node, f"flip {node.value} -> {not node.value}"):
                return ast.copy_location(ast.Constant(value=not node.value), node)
        elif isinstance(node.value, int) and not isinstance(node.value, bool):
            if self._claim(node, f"off-by-one {node.value} -> {node.value + 1}"):
                return ast.copy_location(ast.Constant(value=node.value + 1), node)
        return node


def _count_mutable_nodes(tree: ast.AST) -> int:
    """Dry-run the mutator past every candidate index to find how many exist."""
    count = 0
    while True:
        probe = _SingleNodeMutator(target_id=count)
        probe.visit(copy.deepcopy(tree))
        if probe.description is None:
            return count
        count += 1


def count_mutable_nodes(source: str) -> int:
    """How many single-fault mutations `generate_mutants` COULD produce from
    `source`, ignoring `max_mutants`. Callers use this to report truncation
    honestly instead of letting a capped run read as an exhaustive one."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0
    return _count_mutable_nodes(tree)


def generate_mutants(source: str, max_mutants: int = 5) -> list[Mutant]:
    """Up to `max_mutants` single-fault mutations of `source`'s AST.

    Bounded and deterministic (same source -> same mutants, in the same
    left-to-right AST-walk order) so a re-run reproduces the same verdict.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    total = min(_count_mutable_nodes(tree), max_mutants)
    mutants: list[Mutant] = []
    for i in range(total):
        # `total` is bounded by `_count_mutable_nodes`, which runs the SAME
        # probe/mutate logic against a fresh deepcopy of the same tree -- for
        # every i < total a description is guaranteed, never None here.
        mutator = _SingleNodeMutator(target_id=i)
        mutated_tree = mutator.visit(copy.deepcopy(tree))
        assert mutator.description is not None, (
            f"target_id={i} < total={total} (bounded by _count_mutable_nodes) but no candidate "
            "was claimed -- the two walks have diverged, a real bug, not a type-checker false alarm"
        )
        ast.fix_missing_locations(mutated_tree)
        try:
            mutated_source = ast.unparse(mutated_tree)
        except (ValueError, TypeError):
            continue
        mutants.append(Mutant(source=mutated_source, description=mutator.description, lineno=mutator.lineno))
    return mutants


# ---------------------------------------------------------------------------
# Test-to-source resolution
# ---------------------------------------------------------------------------

def _imported_local_modules(tree: ast.AST, local_top_names: set[str]) -> Iterator[str]:
    """Every dotted module name this file imports whose TOP-LEVEL package is
    one of `local_top_names`, in source order.

    Reading imports and resolving them to files are two jobs, and they failed
    differently: this one only has to know what the file SAYS, and is wrong
    only if it misreads the AST. `_module_source_path` only has to know where
    a dotted name lives on disk, and is wrong only if the layout differs.
    Neither can now be broken by a change to the other.
    """
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.module and node.module.split(".")[0] in local_top_names:
                # MOST SPECIFIC FIRST. `from tools import calibra_psi` names a
                # MODULE, not a symbol, in the flat layout every satellite
                # uses -- yielding only `tools` resolved it to a two-line
                # `tools/__init__.py`, which is non-None and therefore looks
                # like success while carrying no mutable behaviour at all.
                # Measured 2026-09-25: 5 of blackbox's 7 resolutions landed on
                # `__init__.py`. The caller keeps the first candidate that
                # exists on disk, so a symbol import (`from tools.x import f`)
                # simply fails to resolve `tools.x.f` and falls through to
                # `tools.x`, which is right.
                for alias in node.names:
                    yield f"{node.module}.{alias.name}"
                yield node.module
        elif isinstance(node, ast.Import):
            # ONE module per `import a, b` statement, the first local one --
            # the pre-split code said this with a `break` after assigning,
            # which as a generator would be unreachable: a consumer that
            # stops at the first yield never resumes the loop to run it. An
            # unreachable line is a line no mutant can be caught on, so it is
            # expressed as a `next(...)` that has no dead branch instead.
            local = next(
                (a.name for a in node.names if a.name.split(".")[0] in local_top_names), None,
            )
            if local is not None:
                yield local


def _module_source_path(src_dir: Path, module_name: str) -> Path | None:
    """Where a dotted module name lives under `src_dir`: the `.py` file, or the
    package's `__init__.py`. None when neither exists -- an import naming a
    local top-level package that has no file behind it (a namespace package, a
    stale import) is NOT mutable source, and saying None here is what makes
    the caller keep looking instead of mutating the wrong file."""
    rel = Path(*module_name.split("."))
    candidate = src_dir / rel.with_suffix(".py")
    if candidate.is_file():
        return candidate
    candidate_pkg = src_dir / rel / "__init__.py"
    if candidate_pkg.is_file():
        return candidate_pkg
    return None


def _importable_top_names(directory: Path, excluding: str | None = None) -> set[str]:
    """Top-level names importable from `directory`.

    A directory counts when it holds at least one `.py`, with or without
    `__init__.py`: namespace packages are importable and two of the three
    repos measured on 2026-09-25 rely on that (Atlas imports `tools` with no
    `__init__.py`). Requiring `__init__.py` would have kept this resolver
    blind to exactly the layout it was failing on.

    `excluding` drops one name -- the directory the test file itself lives in.
    Without it, a project whose tests import sibling test helpers would get
    its TEST file mutated instead of its source, and the verdict would be
    about the wrong file entirely.
    """
    try:
        entries = list(directory.iterdir())
    except OSError:
        return set()
    names = set()
    for entry in entries:
        if entry.name == excluding:
            continue
        if entry.suffix == ".py":
            names.add(entry.stem)
        elif entry.is_dir():
            try:
                if any(entry.glob("*.py")):
                    names.add(entry.name)
            except OSError:
                continue
    return names


def _pythonpath_from_pyproject(root: Path) -> list[str]:
    """`[tool.pytest.ini_options] pythonpath` from `pyproject.toml`, or `[]`.

    Malformed TOML, an unreadable file, or a shape that isn't `pythonpath`
    yields `[]` rather than raising -- see `_declared_pythonpath`.
    """
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        return []
    try:
        import tomllib

        datos = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        valor = (datos.get("tool", {}).get("pytest", {})
                 .get("ini_options", {}).get("pythonpath"))
    except (OSError, ValueError, ImportError, AttributeError):
        return []
    if isinstance(valor, str):
        return valor.split()
    if isinstance(valor, list):
        return [str(v) for v in valor]
    return []


def _pythonpath_from_ini_style(root: Path, nombre: str, seccion: str) -> list[str]:
    """`pythonpath = ...` under `seccion` in an ini-style config file, or `[]`.

    Covers `pytest.ini`/`tox.ini` (`[pytest]`) and `setup.cfg`
    (`[tool:pytest]`) -- all three are the same line-oriented grammar, so one
    tiny parser serves the three instead of three near-duplicates.
    """
    archivo = root / nombre
    if not archivo.is_file():
        return []
    try:
        texto = archivo.read_text(encoding="utf-8")
    except OSError as exc:
        logger.debug("_pythonpath_from_ini_style: no se pudo leer %s: %s", archivo, exc)
        return []
    entradas: list[str] = []
    dentro = False
    for linea in texto.splitlines():
        despojada = linea.strip()
        if despojada.startswith("["):
            dentro = despojada == seccion
            continue
        if dentro and despojada.startswith("pythonpath"):
            _, _, valor = despojada.partition("=")
            entradas.extend(valor.replace(",", " ").strip(" []").replace('"', "").split())
    return entradas


def _declared_pythonpath(root: Path) -> list[Path]:
    """The import roots the PROJECT ITSELF declares, in its own pytest config.

    A project that tells pytest where its code is has already answered the
    question this module was guessing at. Measured 2026-09-25 across the
    fleet: `aequitas_os` declares `pythonpath = [".", "backend"]` and keeps
    1086 of its imports under `app.*`, which lives in `backend/`. Guessing
    `src/` then the repo root resolved 5 of its 492 test files; reading what
    it declares resolves 459 of 486.

    Read, never executed: a config file is data. An unreadable or malformed
    one yields nothing rather than raising -- the caller still has `src/` and
    the root to fall back on, and a crash here would take down a gate over a
    stray character in a `setup.cfg`.
    """
    entradas = _pythonpath_from_pyproject(root)
    for nombre, seccion in (("pytest.ini", "[pytest]"), ("tox.ini", "[pytest]"),
                            ("setup.cfg", "[tool:pytest]")):
        entradas.extend(_pythonpath_from_ini_style(root, nombre, seccion))

    vistos: list[Path] = []
    for entrada in entradas:
        ruta = (root / entrada).resolve()
        if ruta.is_dir() and ruta not in vistos:
            vistos.append(ruta)
    return vistos


def source_roots(root: Path) -> list[Path]:
    """The directories this project's own importable code lives in, in the
    order they should be tried.

    What the project DECLARES first (its pytest `pythonpath`), because a
    project that has answered this question should not be second-guessed.
    Then `src/`, which is the layout this module was born in. Then `root`
    itself, which is the layout of every SATELLITE: measured 2026-09-25,
    blackbox keeps its code in `tools/` and `bin/` with no `src/` at all, and
    Atlas has a `src/` holding nothing but `images/`.

    Hardcoding `src/` made this resolver return None for **0 of 374** test
    files across those two repos while working fine in simplecode itself --
    the kit shipped a gate into two satellites where it could not fire even
    once. A gate with no possible catch is a defect in the instrument, never
    evidence that the subject is clean, so the layout assumption is the bug.
    """
    roots: list[Path] = []
    for declarado in _declared_pythonpath(root):
        if _importable_top_names(declarado):
            roots.append(declarado)
    src = root / "src"
    if src.is_dir() and _importable_top_names(src) and src not in roots:
        roots.append(src)
    if root.resolve() not in roots:
        roots.append(root)
    return roots


def resolve_source_for_test(test_file: Path, root: Path) -> Path | None:
    """The first module a test file imports that resolves to this project's
    own source, or None.

    Package-name-agnostic AND layout-agnostic: it asks where the project's
    importable code actually is (`source_roots`) instead of assuming `src/`.
    A test importing several internal modules is only mutation-checked
    against the first -- a real limitation, not a silent one: callers surface
    COULD_NOT_RUN when this returns None, never a false PASS.
    """
    try:
        text = test_file.read_text(encoding="utf-8")
        tree = ast.parse(text)
    except (OSError, SyntaxError, UnicodeDecodeError):
        return None

    own_dir = test_file.parent.name
    for src_dir in source_roots(root):
        excluding = own_dir if src_dir == test_file.parent.parent else None
        local_top_names = _importable_top_names(src_dir, excluding=excluding)
        if not local_top_names:
            continue
        for module_name in _imported_local_modules(tree, local_top_names):
            source = _module_source_path(src_dir, module_name)
            if source is not None:
                return source
    return None


# ---------------------------------------------------------------------------
# Safe mutate-run-restore execution
# ---------------------------------------------------------------------------

class _TestNode(NamedTuple):
    """WHICH test to run, and how long to wait for it -- the four values that
    travelled together through every function in this module's run path and
    never varied within one call chain. Grouping them is not a count-reduction
    trick: `_mutate_run_restore(root, source_file, mutant, test_file, test_name,
    timeout)` let a caller transpose `test_file` and `source_file` (both `Path`,
    adjacent, no type would object), and mutating the wrong file is exactly the
    failure this module exists to avoid committing."""

    root: Path
    test_file: Path
    test_name: str
    timeout: float


def _run_pytest_node(node: _TestNode) -> bool:
    """True iff the targeted test FAILS (the mutant is killed)."""
    root, test_file, test_name, timeout = node
    node_id = f"{test_file.relative_to(root)}::{test_name}"
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", node_id, "-q", "-p", "no:cacheprovider"],
            cwd=root, capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        # A mutant that hangs the test (e.g. an infinite loop from a flipped
        # comparison) is a killed mutant too -- the test caught the fault, it
        # just didn't finish cleanly. Treat as killed, not COULD_NOT_RUN: the
        # ORIGINAL source (checked separately) proves the harness itself works.
        return True
    return result.returncode != 0


def _mutate_run_restore(node: _TestNode, source_file: Path, mutant: Mutant) -> bool:
    """Apply `mutant` to `source_file`, run the test, ALWAYS restore -- even on
    crash. Mirrors the manual cp-backup / mutate / test / restore / diff
    discipline used throughout this session's negative controls, made durable
    (fsync'd write+restore) instead of ad hoc.
    """
    original = source_file.read_bytes()
    try:
        atomic_io.write_text_durable(source_file, mutant.source)
        return _run_pytest_node(node)
    finally:
        atomic_io.write_bytes_durable(source_file, original)


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MutationVerdict:
    test_file: Path
    test_name: str
    source_file: Path | None
    status: str  # "RESISTANT" | "WEAK" | "COULD_NOT_RUN"
    total_mutants: int = 0
    total_mutable: int = 0
    survived: list[str] = field(default_factory=list)

    @property
    def truncated(self) -> bool:
        """True when more mutations existed than `max_mutants` allowed --
        RESISTANT here means "survived every mutant WE TRIED", not "every
        mutant that exists". Never fold this into `status`: a caller that
        wants a strict verdict must check it explicitly, same as this
        project's own could_not_run-is-not-zero reporting discipline."""
        return self.total_mutable > self.total_mutants


def verify_test_mutation_resistant(
    root: Path, test_file: Path, test_name: str, max_mutants: int = 5, timeout: float = SMOKE_SUITE_TIMEOUT,
) -> MutationVerdict:
    """The real question, in one call: if `test_name` in `test_file`'s subject
    broke, would the test notice? Runs the ORIGINAL test first (must pass --
    a test that's already red proves nothing about mutation resistance and is
    reported COULD_NOT_RUN, not a false verdict either way).
    """
    node = _TestNode(root, test_file, test_name, timeout)
    source_file = resolve_source_for_test(test_file, root)
    if source_file is None:
        return MutationVerdict(test_file, test_name, None, "COULD_NOT_RUN")

    if _run_pytest_node(node):
        # returncode != 0 against the UNCHANGED source: the test is already failing.
        return MutationVerdict(test_file, test_name, source_file, "COULD_NOT_RUN")

    try:
        source = source_file.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return MutationVerdict(test_file, test_name, source_file, "COULD_NOT_RUN")

    total_mutable = count_mutable_nodes(source)
    mutants = generate_mutants(source, max_mutants=max_mutants)
    if not mutants:
        return MutationVerdict(test_file, test_name, source_file, "COULD_NOT_RUN", total_mutable=total_mutable)

    survived = []
    for mutant in mutants:
        killed = _mutate_run_restore(node, source_file, mutant)
        if not killed:
            survived.append(f"{source_file.name}:{mutant.lineno}: {mutant.description}")

    status = "WEAK" if survived else "RESISTANT"
    return MutationVerdict(test_file, test_name, source_file, status, len(mutants), total_mutable, survived)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Targeted mutation testing for a single test.")
    parser.add_argument("test_file", type=Path)
    parser.add_argument("test_name")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-mutants", type=int, default=5)
    parser.add_argument("--gate", action="store_true", help="Exit 1 on WEAK or COULD_NOT_RUN")
    args = parser.parse_args(argv)

    # Absolutas antes de nada. `_run_pytest_node` construye el node-id con
    # `test_file.relative_to(root)`, que revienta con un ValueError si una de
    # las dos es relativa -- y la forma natural de invocar esto desde la raiz
    # del repo es justamente `tests/test_x.py`. Ese fallo estuvo TAPADO
    # mientras el resolutor devolvia None antes de llegar aqui: al arreglar el
    # resolutor (2026-09-25) salio a la primera corrida en un satelite. Un
    # defecto que solo aparece cuando el anterior se arregla es la firma de un
    # camino que nunca se habia recorrido entero.
    root = args.root.resolve()
    test_file = args.test_file if args.test_file.is_absolute() else (root / args.test_file)

    verdict = verify_test_mutation_resistant(root, test_file.resolve(), args.test_name, args.max_mutants)
    print(f"[mutation-verify] {verdict.test_file}::{verdict.test_name} -> {verdict.status} "
          f"({len(verdict.survived)}/{verdict.total_mutants} mutants survived)")
    for s in verdict.survived:
        print(f"  SURVIVED: {s}")
    if verdict.truncated:
        print(f"  NOTE: {verdict.total_mutable - verdict.total_mutants} candidate mutation(s) were "
              f"NOT tried (--max-mutants={args.max_mutants}); a RESISTANT verdict here is not exhaustive.")

    if args.gate and verdict.status != "RESISTANT":
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
