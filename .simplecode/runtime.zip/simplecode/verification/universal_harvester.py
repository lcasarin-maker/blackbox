# -*- coding: utf-8 -*-
"""universal_harvester.py -- Universal Polyglot Harvester across Claude, Gemini, Codex, OpenCode, Aider & Git History.

Enforces DGX-40 (Mechanisms before Verdict) and DGX-169 (Speech is not Record).
Extracts the 6 Core Knowledge Assets from historical transcripts, archive dumps and git commit logs:
  1. DEBT: Candidate bugs and commitments -> tasks/backlog/CONV-DEBT-*.md
  2. DECISIONS: Abandoned paths, rejected libraries, architectural rationales -> docs/decisions/
  3. LORE: Fiscal, legal and business domain rules -> docs/domain_knowledge/
  4. FIXTURES: Real sample XMLs, JSON payloads, test data -> tests/fixtures/harvested/
  5. PLAYBOOKS: Diagnostic commands, recovery recipes -> docs/runbooks/
  6. DIRECTIVES: User non-negotiable principles & mental models -> docs/user_directives/

A candidate only materializes for real into a repo's tracked tree when it is
routed with high confidence (an explicit cwd) AND the gate finds no noise
markers in it (see _gate_confident_noise). Anything routed only by a
coincidental mentioned-file match, or that the gate cannot confidently
clear, is written under QUARANTINE_DIRNAME next to the fleet instead of
into a repo's tracked tree, for human triage -- a real 112-thread run
materializing straight into 6 repos measured 96% false positives, worst
case a 65-file wrong-repo misfile (own-chats-universal-harvester-contract
memory, 2026-08-31). The printed HARVEST SUMMARY only counts a category
when something was actually written to disk (materialized or quarantined),
never a candidate that was declined, gate-rejected, or unrouted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import re
import sqlite3
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Generator

from simplecode.utils import atomic_io
from simplecode.utils.tool_limits import HARVEST_SOURCE_FILE_MAX_BYTES
from simplecode.verification import ledger_schema

logger = logging.getLogger(__name__)

# SPEC-L057: one-shot harvest collapses the DEBT backlog to at most this many
# reviewable tasks/backlog/CONV-DEBT-*.md decisions per run. Overflow is
# counted (stats["DEBT_OVERFLOW"]) and logged, never silently dropped.
MAX_REVIEW_DECISIONS = 30

# Knowledge extractors
PATTERNS = {
    "DEBT": [
        re.compile(r"(?:falta\s+(?:implementar|agregar|validar|considerar|soporte|corregir)|tenemos\s+pendiente|queda\s+pendiente)[^.\n]*", re.I),
        re.compile(r"(?:hay\s+un\s+bug|error\s+de\s+diseño|falla\s+cuando|no\s+contempla|no\s+soporta|deuda\s+técnica)[^.\n]*", re.I),
        re.compile(r"(?:bug\s+in|missing\s+implementation|not\s+supported|needs\s+to\s+be\s+fixed|pending\s+task)[^.\n]*", re.I),
        re.compile(r"(?:deficiencia|incidente|discrepancia\s+en|falso\s+positivo\s+en|brecha\s+en)[^.\n]*", re.I),
    ],
    "DECISION": [
        re.compile(r"(?:se\s+descart[oó]|descartamos|optamos\s+por|decidimos\s+(?:usar|no\s+usar|migrar)|en\s+lugar\s+de\s+\w+\s+usaremos)[^.\n]*", re.I),
        re.compile(r"(?:decided\s+against|rejected\s+because|abandoned\s+approach|alternative\s+considered)[^.\n]*", re.I),
    ],
    "LORE": [
        re.compile(r"(?:regla\s+del\s+SAT|art[ií]culo\s+\d+|c[oó]digo\s+fiscal|CFDI\s+(?:3\.3|4\.0)|r[eé]gimen\s+fiscal|TFJA|juzgado)[^.\n]*", re.I),
        re.compile(r"(?:retenci[oó]n\s+de\s+IVA|RESICO|SIPRED|carta\s+porte|n[oó]mina\s+1\.2)[^.\n]*", re.I),
    ],
    "PLAYBOOK": [
        re.compile(r"(?:para\s+recuperar|comando\s+para|receta\s+de\s+despliegue|en\s+caso\s+de\s+desastre|script\s+de\s+rescate)[^.\n]*", re.I),
    ],
    "DIRECTIVE": [
        re.compile(r"(?:regla\s+inviolable|no\s+vibecoding|nunca\s+traduzcas|recordar\s+no\s+es\s+registrar|cero\s+deuda)[^.\n]*", re.I),
    ]
}


def classify_dgx40_tag(snippet: str, category: str) -> str:
    """Classify knowledge item per DGX-40 taxonomy (COS, BUG, DOM, MAD, TOS, DUP)."""
    s = snippet.lower()
    if category == "DEBT" or "bug" in s or "fallo" in s or "error" in s:
        return "BUG"
    if category == "LORE" or "sat" in s or "fiscal" in s or "ley" in s:
        return "DOM"
    if "descart" in s or "inmadur" in s or "inestable" in s:
        return "MAD"
    if "seguridad" in s or "licencia" in s:
        return "TOS"
    return "COS"


def _extract_text_from_line(obj: dict[str, Any]) -> tuple[str, str, str]:
    """Return (role, text, cwd_or_project) from arbitrary agent line format."""
    if not isinstance(obj, dict):
        if isinstance(obj, list):
            return "UNKNOWN", "\n".join(str(x) for x in obj), ""
        return "UNKNOWN", str(obj), ""

    # Gemini / Antigravity format
    if "step_index" in obj and "content" in obj:
        role = obj.get("source", obj.get("type", "UNKNOWN"))
        return str(role), str(obj.get("content", "")), ""

    # Claude project session format
    if "message" in obj and isinstance(obj["message"], dict):
        msg = obj["message"]
        role = msg.get("role", obj.get("type", "UNKNOWN"))
        content = msg.get("content", "")
        if isinstance(content, list):
            texts = [b.get("text", "") for b in content if isinstance(b, dict)]
            content = "\n".join(texts)
        cwd = obj.get("cwd", "")
        return str(role), str(content), str(cwd)

    # Claude history.jsonl
    if "display" in obj:
        return "USER", str(obj.get("display", "")) + "\n" + str(obj.get("pastedContents", "")), str(obj.get("project", ""))

    # Fallback
    content = str(obj.get("content", obj.get("text", "")))
    return "UNKNOWN", content, ""


PROJECT_LINEAGE_MAP = {
    # Cuenza family (quenza, quenza_modern, cuenza_app, etc.)
    "quenza": "cuenza",
    "quenza_modern": "cuenza",
    "quenza-modern": "cuenza",
    "cuenza_app": "cuenza",
    "cuenza_restos": "cuenza",
    "cuenza_web": "cuenza",
    # Aequitas family
    "aequitas": "aequitas_os",
    "aequitaslegal": "aequitas_os",
    "aequitas-legal": "aequitas_os",
    "aequitas_rag": "aequitas_os",
    "aequitas_os": "aequitas_os",
    # Cerberus & Governance family
    "cerberus": "simplecode",
    "cerberus2": "simplecode",
    "cerberus-v2": "simplecode",
    "goodcode": "simplecode",
    # Poe family
    "normare": "poe_normare",
    "poe_normare": "poe_normare",
    "poe": "poe_systems",
    "poe_sat": "poe_systems",
    "poe_systems": "poe_systems",
    # Atlas family
    "spark": "Atlas",
    "dgx_spark": "Atlas",
    "atlas": "Atlas",
}


CLOSURE_POLARITY_NEGATIONS = re.compile(
    r"(?:queda\s+cerrad[oa]|qued[oó]\s+(?:resuelto|cerrad[oa]|arreglad[oa]|corregid[oa]|eliminad[oa])|"
    r"se\s+(?:resolvi[oó]|cerr[oó]|arregl[oó]|corrigi[oó]|elimin[oó]|subsan[oó])|"
    r"fue\s+(?:resuelto|cerrad[oa]|arreglad[oa]|corregid[oa]|eliminad[oa]|subsanad[oa])|"
    r"no\s+queda\s+ning[uú]n\s+pendiente|resuelto\s+al\s+100%|ya\s+(?:est[aá]|qued[oó]|resuelto|se\s+implement[oó]|se\s+corrigi[oó])|"
    r"resumen\s+del\s+incidente|post-?mortem|audit\s+trail|historial\s+completo|"
    r"fixed\s+in|resolved\s+by|closed\s+issue|already\s+implemented|no\s+action\s+needed|revertido\s+a\s+tiempo|"
    # SPEC-CONV-DEBT-NOISE (Atlas, 2026-08-28): bare past-participle closure
    # signals and null-result statements measured slipping through on a
    # systematic 37/289 sample of Atlas's tasks/review/ P1 backlog -- 0 of 37
    # were real debt, several were explicit closure ("Ambos verificados con
    # una prueba real tras el incidente", "corregido en el mismo turno,
    # verificado", "Found and fixed along the way") that the phrase-anchored
    # patterns above (requiring "fue"/"quedó"/"se" immediately before the
    # participle) do not cover.
    r"\bverificad[oa]s?\s+con\s+(?:una\s+)?prueba\s+real\b|\bcorregid[oa]\s+en\s+el\s+mismo\s+turno|"
    r"found\s+and\s+fixed|"
    # "benigno" and "no tengo mecanismos/..." are each ambiguous in
    # isolation: "el bug es benigno EN MODO DEBUG pero falta agregar el fix
    # para producción" is real open debt that happens to call one aspect
    # benign, and "no tengo mecanismos DE ROLLBACK, hay que agregar uno" is
    # real open debt describing a missing capability, not a null result.
    # Measured live (2026-08-28) reviewing this same diff: both loose forms
    # convict genuine debt sentences that merely co-occur with the word.
    # Anchoring "benigno" to "hallazgo" (the null-finding framing from the
    # source audit's own positive example) and requiring "no tengo
    # mecanismos/..." to close on "ningún"/"que reportar"/"sobre los/las
    # cuales" (the actual null-result idiom) keeps the two real positives
    # from the 37-sample audit while dropping the false ones.
    r"\bhallazgo\b[^.\n]{0,40}\bbenign[oa]\b|\bbenign[oa]\b[^.\n]{0,40}\bhallazgo\b|"
    r"no\s+tengo\s+(?:mecanismos|hallazgos|incidentes|correcciones)\b"
    r"(?:[^.\n]{0,40}\b(?:ning[uú]n[ao]?|que\s+reportar|sobre\s+los?\s+cuales|sobre\s+las?\s+cuales)))",
    re.I,
)

# Same 37-sample audit: a harvested "issue" that is itself a question ("¿Qué
# deficiencia de `simplecode` pone esto en evidencia?") is the agent asking,
# not reporting a defect -- a question has no polarity to negate, so it can't
# be caught by CLOSURE_POLARITY_NEGATIONS above. Checked for every category:
# an interrogative sentence is never a coherent mechanism statement, DEBT or
# otherwise.
QUESTION_MARKER = re.compile(r"[?¿]")

# A transcript can contain a tool_result that IS a prior gate/hook run's raw
# diagnostic output (e.g. a failed corruption-guard or gate-runner invocation
# pasted verbatim). That text often matches a DEBT/BUG trigger phrase ("no
# soporta", "restore from git", ...) on its own words, so without this guard
# the harvester re-materializes the tool's own report as a fresh "conversational
# debt" finding -- and when the diagnosed file itself contains corrupted text,
# the finding's snippet embeds that corrupted quote, which the NEXT harvest run
# can match again, snowballing near-duplicate CONV-DEBT files (observed:
# aequitas_os, DGX-169 dogfooding, 2026-08-24). This is tool self-output, not a
# human/agent statement about a defect, so it is never a valid harvest source.
TOOL_DIAGNOSTIC_ARTIFACT = re.compile(
    r"\[gate-runner\]|hook id:|redacted output sha256=|"
    r"restore from git(?:\s+or\s+(?:normalize|strip)\b)?|"
    r"(?:mojibake|CRLF line endings|byte-order mark \(BOM\))\s+detected\b",
    re.I,
)

# Materialization-time gate (own-chats-universal-harvester-contract memory,
# real 112-thread run 2026-08-31): materializing straight into any of the
# fleet's tracked repo trees hit 96% false positives (99/103 files). Three
# noise sources survive TOOL_DIAGNOSTIC_ARTIFACT and CLOSURE_POLARITY_NEGATIONS
# above because those only screen the matched snippet at extraction time --
# they never see the item's full context, and never see a materialized
# doc's own generated headers/frontmatter (which contain trigger vocabulary
# like "Deficiencia Identificada" and get re-matched when a rendered doc is
# quoted in a later conversation).
SELF_HARVEST_ARTIFACT = re.compile(
    r"CONV-DEBT-[0-9A-F]{12}|ADR-HARVESTED-[0-9A-F]{12}|ADR-[0-9A-F]{12}|LORE-[0-9A-F]{12}|"
    r"^status:\s*(?:review|accepted|done)\s*$|^risk_score:|^blast_radius:|^satd_family:|"
    r"##\s*[IRAC]\s*\xb7|##\s*HOWEVER\s*\xb7|"
    r"##\s*\d\.\s*(?:Context and Problem Statement|Decision Drivers|Considered Options|Decision Outcome)",
    re.I | re.M,
)
TOOL_INVOCATION_ARTIFACT = re.compile(
    r"\[Tool:\s*\w+\]|\[external_agent_tool_call\]|\[external_agent_tool_result\]",
    re.I,
)
VERIFICATION_SCAFFOLDING_ARTIFACT = re.compile(
    r"control\s+negativo|bug\s+inyectado|sabe\s+decir\s+que\s+no|negative[\s-]control\b|"
    r"positive[\s-]control\b|deliberately\s+inject",
    re.I,
)

# Written next to the fleet's repos, never inside one of their tracked
# trees. An item routed only by coincidental file-mention (not an explicit
# cwd) lands here instead of the target repo for human triage -- the
# routing signal that misfiled 65/65 items into Twiner from an unrelated
# conversation (own-chats-universal-harvester-contract memory, 2026-08-31).
QUARANTINE_DIRNAME = "_harvest_quarantine"


def _gate_confident_noise(item: dict[str, Any]) -> bool:
    """True only when the item is certainly noise: a self-quoted harvester
    artifact, a tool/log trace, or verification-methodology scaffolding --
    never a real DEBT/DECISION/LORE/PLAYBOOK/DIRECTIVE candidate. Anything
    this doesn't reject is NOT thereby confirmed real; routing confidence
    still gates whether it materializes for real or sits in quarantine (see
    _materialize_single_item)."""
    text = item["snippet"] + "\n" + item["context"]
    return bool(
        SELF_HARVEST_ARTIFACT.search(text)
        or TOOL_INVOCATION_ARTIFACT.search(text)
        or VERIFICATION_SCAFFOLDING_ARTIFACT.search(text)
    )


def compute_root_cause_key(item: dict[str, Any], fleet_dir: Path) -> str:
    """Compute normalized deduplication key based on target repo, target component/symbol, and defect category."""
    resolved = _determine_target_repo(item.get("cwd_hint", ""), item["context"], fleet_dir)
    target_repo = resolved.name if resolved is not None else "unrouted"
    cat = item["category"]
    tag = item.get("tag", "COS")

    # Extract target file or symbol
    files = re.findall(r"([\w./\-]+\.(?:py|js|ts|html|sh|json|toml))", item["snippet"] + " " + item["context"][:300])
    symbols = re.findall(r"`([a-zA-Z_][a-zA-Z0-9_]+)`", item["snippet"])
    main_target = files[0] if files else (symbols[0] if symbols else "general")

    # Core normalized token signature
    norm_tokens = sorted(set(re.findall(r"\b[a-zA-Z0-9_]{4,}\b", item["snippet"].lower())))
    core_sig = "-".join(norm_tokens[:6])

    raw_key = f"{target_repo}:{cat}:{tag}:{main_target}:{core_sig}"
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()[:12]


# Un punto de FIN DE FRASE va seguido de espacio o de fin de texto. El punto de
# `mod.py`, de `3.11` o de `simplecode.verification` no lo es.
#
# Encontrado el 2026-09-06 cableando el guardia de sujeto de `_materialize_debt`: la
# frase «falta implementar validacion funcion alpha en mod.py de forma completa» salia
# del extractor como `'falta implementar validacion funcion alpha en mod'` -- cortada
# EN el punto del nombre de fichero. El extractor le amputaba el sujeto al hallazgo y
# luego el resto del organo se preguntaba por que tantas fichas no nombran nada.
#
# Es media causa raiz del volumen que midio o2o, y estaba escrita aqui: un `.` tratado
# como final de oracion sin mirar que viene detras. La otra media (el guardia que medía
# el contexto y no la afirmacion) vive en `snippet_names_a_subject`.
_FIN_DE_FRASE_RE = re.compile(r"\.(?=\s|$)")


def _extract_coherent_mechanism(match: re.Match, text: str, category: str) -> str | None:
    """Extract a complete, coherent grammatical mechanism sentence, filtering out closure statements."""
    m_start, m_end = match.start(), match.end()
    # Sentence boundaries. El `.` cuenta solo si de verdad cierra una frase (ver
    # `_FIN_DE_FRASE_RE`); el orden de preferencia --salto de linea antes que punto-- es
    # el que este extractor ya tenia y no se toca.
    ultimo_punto = -1
    for previo in _FIN_DE_FRASE_RE.finditer(text, 0, m_start):
        ultimo_punto = previo.end()
    start = max(0, text.rfind("\n", 0, m_start) + 1, ultimo_punto)
    end = text.find("\n", m_end)
    if end == -1:
        siguiente = _FIN_DE_FRASE_RE.search(text, m_end)
        end = siguiente.start() if siguiente else -1
    if end == -1:
        end = len(text)

    sentence = text[start:end].strip(" .-\t\r\n`*#>")
    if len(sentence) < 25 or len(sentence.split()) < 5:
        return None

    # A question ("¿Qué deficiencia...?") is the agent asking, not reporting
    # a defect -- it has no closure polarity for CLOSURE_POLARITY_NEGATIONS
    # to catch, so it needs its own filter. Applies to every category.
    if QUESTION_MARKER.search(sentence):
        return None

    # Reject tool/gate diagnostic output regardless of category -- it is the
    # instrument talking about itself, never a human or agent statement.
    if TOOL_DIAGNOSTIC_ARTIFACT.search(sentence):
        return None

    # Filter out false-positive closure statements if extracting DEBT
    if category == "DEBT" and CLOSURE_POLARITY_NEGATIONS.search(sentence):
        return None

    return sentence


def _find_repo_by_mentioned_files(text: str, default_fleet: Path) -> Path | None:
    """Find repo if text mentions files that physically exist in a satellite."""
    for child in sorted(default_fleet.iterdir()):
        if child.is_dir() and not child.name.startswith("."):
            for word in text.split():
                clean_word = word.strip("`'\"(),;:")
                if "/" in clean_word and len(clean_word) > 4:
                    if (child / clean_word).exists():
                        return child
    return None


def _determine_target_repo(cwd_or_proj: str, text: str, default_fleet: Path) -> Path | None:
    """Resolve a repository only from an explicit cwd or an existing mentioned file."""
    if cwd_or_proj:
        cwd_name = Path(cwd_or_proj).name.lower()
        canonical = PROJECT_LINEAGE_MAP.get(cwd_name, cwd_name)
        candidate = default_fleet / canonical
        if candidate.is_dir():
            return candidate

    match_file = _find_repo_by_mentioned_files(text, default_fleet)
    if match_file:
        return match_file
    return None


def _determine_target_repo_with_confidence(cwd_or_proj: str, text: str, default_fleet: Path) -> tuple[Path | None, bool]:
    """Same resolution as _determine_target_repo, plus whether it came from
    an explicit cwd (high confidence) or only a coincidental mentioned-file
    match (low confidence -- a single filename that happens to also exist in
    an unrelated repo, the routing signal behind the Twiner misfile)."""
    if cwd_or_proj:
        cwd_name = Path(cwd_or_proj).name.lower()
        canonical = PROJECT_LINEAGE_MAP.get(cwd_name, cwd_name)
        candidate = default_fleet / canonical
        if candidate.is_dir():
            return candidate, True

    match_file = _find_repo_by_mentioned_files(text, default_fleet)
    return match_file, False


def _is_actionable_candidate(item: dict[str, Any], fleet_dir: Path) -> bool:
    """Reject unscoped transcript phrases before they can create repository state."""
    target = _determine_target_repo(item.get("cwd_hint", ""), item.get("context", ""), fleet_dir)
    if target is None:
        return False
    if item.get("category") != "DEBT":
        return True
    role = str(item.get("role", "")).upper()
    return role not in {"UNKNOWN", "MARKDOWN_ARCHIVE", "GIT"}


def _within_size_cap(path: Path, skip_stats: dict[str, Any] | None) -> bool:
    """Return True if `path` is within HARVEST_SOURCE_FILE_MAX_BYTES (Axiom 10).

    Oversize files are reported loudly (logger.warning, visible by default)
    and counted in `skip_stats["oversize_skipped"]` when a stats dict is
    supplied -- never silently truncated or dropped."""
    try:
        size = path.stat().st_size
    except OSError as exc:
        logger.warning("Could not stat %s to enforce size cap: %s", path, exc, exc_info=True)
        if skip_stats is not None:
            skip_stats["oversize_skipped"] = skip_stats.get("oversize_skipped", 0) + 1
            skip_stats.setdefault("oversize_skipped_files", []).append(str(path))
        return False
    if size > HARVEST_SOURCE_FILE_MAX_BYTES:
        logger.warning(
            "Skipping oversize source file %s (%d bytes > %d byte cap)",
            path, size, HARVEST_SOURCE_FILE_MAX_BYTES,
        )
        if skip_stats is not None:
            skip_stats["oversize_skipped"] = skip_stats.get("oversize_skipped", 0) + 1
            skip_stats.setdefault("oversize_skipped_files", []).append(str(path))
        return False
    return True


def _yield_pattern_matches(text: str, common_fields: dict[str, Any]) -> Generator[dict[str, Any], None, None]:
    """Shared regex-match-to-knowledge-item expansion used by every scanner."""
    for category, regex_list in PATTERNS.items():
        for rgx in regex_list:
            for match in rgx.finditer(text):
                snippet = _extract_coherent_mechanism(match, text, category)
                if snippet:
                    yield {
                        **common_fields,
                        "category": category,
                        "tag": classify_dgx40_tag(snippet, category),
                        "snippet": snippet,
                        "context": text[:600],
                    }


def _scan_transcript_line(path: Path, idx: int, line: str) -> Generator[dict[str, Any], None, None]:
    """Parse and extract knowledge items from a single transcript JSONL line."""
    if not line.strip():
        return
    try:
        obj = json.loads(line)
    except json.JSONDecodeError as exc:
        logger.debug("Skipping unparseable JSON in %s: %s", path, exc)
        return

    role, text, cwd_or_proj = _extract_text_from_line(obj)
    if not text or len(text) < 20:
        return

    yield from _yield_pattern_matches(
        text, {"file": str(path), "line": idx, "role": role, "cwd_hint": cwd_or_proj}
    )


def scan_transcript_file(
    path: Path, skip_stats: dict[str, Any] | None = None
) -> Generator[dict[str, Any], None, None]:
    """Yield extracted candidate knowledge items from a single transcript file."""
    if not _within_size_cap(path, skip_stats):
        return
    try:
        with path.open(encoding="utf-8", errors="ignore") as fh:
            for idx, line in enumerate(fh, start=1):
                yield from _scan_transcript_line(path, idx, line)
    except OSError as exc:
        logger.debug("Could not read transcript %s: %s", path, exc)
        return


def _scan_opencode_parts(conn: sqlite3.Connection, path: Path) -> Generator[dict[str, Any], None, None]:
    rows = conn.execute("SELECT id, data FROM part WHERE data IS NOT NULL;").fetchall()
    for r_id, raw_data in rows:
        try:
            data = json.loads(raw_data)
            text = data.get("text", "")
            if text and len(text) >= 20:
                for category, regex_list in PATTERNS.items():
                    for rgx in regex_list:
                        for match in rgx.finditer(text):
                            snippet = _extract_coherent_mechanism(match, text, category)
                            if snippet:
                                yield {
                                    "file": str(path),
                                    "line": r_id,
                                    "role": "OPENCODE",
                                    "category": category,
                                    "tag": classify_dgx40_tag(snippet, category),
                                    "snippet": snippet,
                                    "context": text[:600],
                                    "cwd_hint": "",
                                }
        except (json.JSONDecodeError, KeyError) as exc:
            logger.debug("Skipping invalid part record %s in %s: %s", r_id, path, exc)
            continue


def _scan_codex_threads(conn: sqlite3.Connection, path: Path) -> Generator[dict[str, Any], None, None]:
    rows = conn.execute("SELECT thread_id, display_title, cwd, source_detail FROM local_thread_catalog;").fetchall()
    for t_id, title, cwd, detail in rows:
        full_text = f"{title or ''}\n{detail or ''}"
        if len(full_text) >= 20:
            for category, regex_list in PATTERNS.items():
                for rgx in regex_list:
                    for match in rgx.finditer(full_text):
                        snippet = _extract_coherent_mechanism(match, full_text, category)
                        if snippet:
                            yield {
                                "file": str(path),
                                "line": t_id,
                                "role": "CODEX",
                                "category": category,
                                "tag": classify_dgx40_tag(snippet, category),
                                "snippet": snippet,
                                "context": full_text[:600],
                                "cwd_hint": cwd or "",
                            }


def scan_sqlite_database(path: Path) -> Generator[dict[str, Any], None, None]:
    """Extract conversation text from OpenCode (opencode.db) or Codex SQLite databases."""
    try:
        conn = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
        tables = [t[0] for t in conn.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()]
        if "part" in tables:
            yield from _scan_opencode_parts(conn, path)
        if "local_thread_catalog" in tables:
            yield from _scan_codex_threads(conn, path)
        conn.close()
    except (sqlite3.Error, OSError) as exc:
        logger.debug("Database read error for %s: %s", path, exc)
        return


def scan_markdown_chat(
    path: Path, skip_stats: dict[str, Any] | None = None
) -> Generator[dict[str, Any], None, None]:
    """Extract conversation snippets from Aider or archive markdown logs."""
    if not _within_size_cap(path, skip_stats):
        return
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
        for category, regex_list in PATTERNS.items():
            for rgx in regex_list:
                for match in rgx.finditer(content):
                    snippet = _extract_coherent_mechanism(match, content, category)
                    if snippet:
                        yield {
                            "file": str(path),
                            "line": 1,
                            "role": "MARKDOWN_ARCHIVE",
                            "category": category,
                            "tag": classify_dgx40_tag(snippet, category),
                            "snippet": snippet,
                            "context": content[:600],
                            "cwd_hint": path.parent.as_posix(),
                        }
    except OSError as exc:
        logger.debug("Markdown read error for %s: %s", path, exc)
        return


def _parse_commit_record(rec: str, repo_dir: Path) -> Generator[dict[str, Any], None, None]:
    if not rec.strip().startswith("COMMIT_REC:"):
        return
    lines = rec.strip().splitlines()
    header = lines[0].replace("COMMIT_REC:", "")
    parts = header.split("|", 2)
    if len(parts) < 3:
        return
    c_hash, author, subject = parts
    body = "\n".join(lines[1:])
    full_msg = f"{subject}\n{body}"

    for category, regex_list in PATTERNS.items():
        for rgx in regex_list:
            for match in rgx.finditer(full_msg):
                snippet = _extract_coherent_mechanism(match, full_msg, category)
                if snippet:
                    yield {
                        "file": f"git://{repo_dir.name}/{c_hash[:8]}",
                        "line": c_hash[:8],
                        "role": f"GIT_COMMIT({author})",
                        "category": category,
                        "tag": classify_dgx40_tag(snippet, category),
                        "snippet": snippet,
                        "context": full_msg[:600],
                        "cwd_hint": repo_dir.as_posix(),
                    }


def scan_git_history(repo_dir: Path, max_commits: int = 500) -> Generator[dict[str, Any], None, None]:
    """Extract decisions, debt and post-mortems from git commit history."""
    if not (repo_dir / ".git").is_dir() and not (repo_dir / ".git").is_file():
        return
    try:
        cmd = [
            "git", "-C", str(repo_dir), "log", "--no-merges",
            f"-n{max_commits}", "--format=COMMIT_REC:%H|%an|%s%n%b%n---END_REC---"
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, errors="ignore", check=False)
        if res.returncode != 0:
            return

        for rec in res.stdout.split("---END_REC---"):
            yield from _parse_commit_record(rec, repo_dir)
    except (subprocess.SubprocessError, OSError) as exc:
        logger.debug("Git history scan error for %s: %s", repo_dir, exc)
        return


def _load_checkpoint_cache(cache_file: Path) -> dict[str, float]:
    """Load previously scanned file mtimes to support sub-second incremental re-scans."""
    if not cache_file.is_file():
        return {}
    try:
        data = json.loads(cache_file.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError) as exc:
        logger.debug("Checkpoint cache read error for %s: %s", cache_file, exc)
        return {}


def _save_checkpoint_cache(cache_file: Path, cache_data: dict[str, float]) -> bool:
    """Persist scanned file mtimes. Returns True on success; a write failure is
    logged loudly with the path and exception context (never silently dropped)
    -- the run's results are still valid, but the next run loses incremental
    re-scan and will re-scan every source from scratch."""
    try:
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        atomic_io.write_text_durable(cache_file, json.dumps(cache_data), encoding="utf-8")
        return True
    except OSError:
        logger.warning(
            "Checkpoint cache write failed for %s; incremental re-scan disabled for next run",
            cache_file, exc_info=True,
        )
        return False


def _collect_files_from_source(src: Path) -> list[Path]:
    """Collect all transcript, sqlite, and markdown files from source."""
    if not src.exists():
        return []
    if src.is_file():
        return [src]
    files = list(src.glob("**/*.jsonl"))
    files.extend(src.glob("**/*.db"))
    files.extend(src.glob("**/*.aider.chat.history.md"))
    # Include archive markdown files
    if "archive" in src.as_posix():
        files.extend(src.glob("**/*.md"))
    # Axiom 9: enumeration order must be deterministic across filesystems/runs.
    return sorted(set(files), key=lambda p: p.as_posix())


def _scan_single_file(
    f: Path, skip_stats: dict[str, Any] | None = None
) -> Generator[dict[str, Any], None, None]:
    """Dispatch scanner based on file extension."""
    if f.suffix == ".db":
        yield from scan_sqlite_database(f)
    elif f.name.endswith(".md"):
        yield from scan_markdown_chat(f, skip_stats)
    else:
        yield from scan_transcript_file(f, skip_stats)


def _scan_source_git_repos(src: Path) -> Generator[dict[str, Any], None, None]:
    """Scan git history for a directory or its immediate child repositories."""
    if (src / ".git").exists():
        yield from scan_git_history(src)
    elif src.is_dir():
        for sub in sorted(src.iterdir()):
            if sub.is_dir() and (sub / ".git").exists():
                yield from scan_git_history(sub)


def _merge_candidate(
    discovered: dict[str, dict[str, Any]], item: dict[str, Any], fleet_dir: Path
) -> None:
    if not _is_actionable_candidate(item, fleet_dir):
        return
    sig = compute_root_cause_key(item, fleet_dir)
    existing = discovered.get(sig)
    if existing is None:
        discovered[sig] = item
    elif item["snippet"] not in existing["context"]:
        existing["context"] += (
            f"\n\n---\n**Evidencia Adicional ({item['file']}):**\n{item['context'][:300]}"
        )


def _changed_file_items(
    file_path: Path,
    old_cache: dict[str, float],
    new_cache: dict[str, float],
    skip_stats: dict[str, Any] | None = None,
) -> Generator[dict[str, Any], None, None]:
    try:
        mtime = file_path.stat().st_mtime
    except OSError:
        return
    new_cache[str(file_path)] = mtime
    if old_cache.get(str(file_path)) != mtime:
        yield from _scan_single_file(file_path, skip_stats)


def _collect_all_candidate_items(
    sources: list[Path], fleet_dir: Path, cache_file: Path | None = None
) -> tuple[dict[str, dict[str, Any]], dict[str, float], dict[str, Any]]:
    discovered: dict[str, dict[str, Any]] = {}
    new_cache: dict[str, float] = {}
    skip_stats: dict[str, Any] = {}
    old_cache = _load_checkpoint_cache(cache_file) if cache_file else {}

    # Normalize caller-provided source order before merging duplicate root
    # causes; the first representative otherwise depends on argument order.
    for src in sorted(sources, key=lambda path: path.as_posix()):
        for item in _scan_source_git_repos(src):
            _merge_candidate(discovered, item, fleet_dir)

        for file_path in _collect_files_from_source(src):
            for item in _changed_file_items(file_path, old_cache, new_cache, skip_stats):
                _merge_candidate(discovered, item, fleet_dir)

    # A file skipped for being oversize contributed zero items this run --
    # do not let the checkpoint remember it as "scanned" (same mtime), or a
    # future run under a raised cap / fixed file would never look at it
    # again and OVERSIZE_SKIPPED would silently read 0 forever instead of
    # being re-reported every run until the file shrinks or the cap moves.
    for skipped_file in skip_stats.get("oversize_skipped_files", []):
        new_cache.pop(skipped_file, None)

    return discovered, new_cache, skip_stats


CAPABILITY_TAXONOMY = {
    "DOCUMENT_PARSING": (
        re.compile(r"(?:pdf|tabla|ocr|docx|xlsx|mammoth|pdfjs|mineru|unstructured)", re.I),
        ["aequitas_os", "office2office", "poe_normare"],
    ),
    "CONCURRENCY_PERSISTENCE": (
        re.compile(r"(?:sqlite|wal|postgres|lock|pool|transacci[oó]n|concurrencia)", re.I),
        ["cuenza", "aequitas_os", "simplecode", "Atlas"],
    ),
    "LEGAL_FISCAL_RULES": (
        re.compile(r"(?:sat|cfdi|retenci[oó]n|resico|scjn|tesis|jurisprudencia|d[ií]as\s+h[aá]biles|tfja)", re.I),
        ["aequitas_os", "poe_systems", "cuenza", "poe_normare"],
    ),
    "HYBRID_RETRIEVAL_RAG": (
        re.compile(r"(?:retrieval|bm25|embedding|qdrant|rerank|tokeniz|hybrid|bge-m3)", re.I),
        ["Atlas", "aequitas_os", "agente_inmobiliario"],
    ),
    "RESILIENCE_HARNESS": (
        re.compile(r"(?:chaos|mutaci[oó]n|fault\s+injection|resiliencia|robustez|superviviente)", re.I),
        ["simplecode", "Atlas", "red_python"],
    ),
    "DATA_CLEANING": (
        re.compile(r"(?:mojibake|nul\s+byte|soft-hyphen|crlf|encoding|utf-8|corrupci[oó]n)", re.I),
        ["poe_normare", "office2office", "aequitas_os"],
    ),
    "AUTH_SESSION_RETRY": (
        re.compile(r"(?:token|oauth|jwt|refresh|retry|backoff|expiraci[oó]n)", re.I),
        ["cuenza", "poe_systems", "agente_inmobiliario"],
    ),
    "AGENTIC_GOVERNANCE": (
        re.compile(r"(?:linter|ast|pre-commit|gate|evasi[oó]n|anti-fraud|zero-debt|dgx-169)", re.I),
        ["simplecode", "Atlas", "aequitas_os"],
    ),
}


def _classify_capability(text: str) -> tuple[str, list[str]] | None:
    """Identify if a knowledge item belongs to a reusable ecosystem capability."""
    for cap_name, (pattern, beneficiaries) in CAPABILITY_TAXONOMY.items():
        if pattern.search(text):
            return cap_name, beneficiaries
    return None


def _materialize_atlas_use_case(sig: str, item: dict[str, Any], cap_name: str, beneficiaries: list[str], fleet_dir: Path) -> None:
    """Register reusable technical mechanisms in Atlas central use case library."""
    atlas_uc_dir = fleet_dir / "Atlas" / "docs" / "use_cases"
    atlas_uc_dir.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-zA-Z0-9_\-]+", "_", item["snippet"][:40]).strip("_")
    fname = atlas_uc_dir / f"UC-{cap_name}-{sig.upper()}.md"

    if not fname.is_file():
        content = (
            f"# Ecosystem Use Case: [{cap_name}] {slug}\n\n"
            f"**ID:** `UC-{cap_name}-{sig.upper()}`\n"
            f"**Proveniencia Original:** `{item.get('file', 'unknown')}` (Rol: `{item.get('role', 'agent')}`)\n"
            f"**Beneficiarios Potenciales:** `{', '.join(beneficiaries)}`\n\n"
            f"## 1. Mecanismo Probado\n> \"{item['snippet']}\"\n\n"
            f"## 2. Contexto de Implementación & Excepción\n```text\n{item['context'].strip()}\n```\n\n"
            f"## 3. Guía de Adopción para Proyectos Vivos\n"
            f"- Cualquier proyecto dentro de la lista de beneficiarios con necesidad de `{cap_name}` puede adaptar este patrón directamente.\n"
        )
        atomic_io.write_text_durable(fname, content, encoding="utf-8")


# Un SUJETO TECNICO: un fichero, un simbolo entrecomillado, o un comando. Es la misma
# forma que ya usan `_find_repo_by_mentioned_files` (fichero) y `compute_root_cause_key`
# (fichero o simbolo entre backticks); aqui se juntan las tres en un patron para poder
# preguntarle a UNA cadena --el snippet-- si afirma algo sobre algo.
_SUJETO_TECNICO_RE = re.compile(
    r"[\w./-]+\.(?:py|js|jsx|ts|tsx|rs|go|java|cs|rb|html|sh|toml|json|ya?ml|md|txt)\b"
    r"|`[A-Za-z_][A-Za-z0-9_.]*`"
    r"|(?<![\w./-])(?:pytest|ruff|mypy|pyright|python3?|make|git|cargo|npm|node|"
    r"pip|docker|pre-commit|simplecode)(?![\w./-])",
    re.I,
)


def snippet_names_a_subject(snippet: str) -> bool:
    """El HALLAZGO nombra un fichero, un simbolo o un comando.

    Se mira el SNIPPET --la afirmacion-- y no el `context`, y ahi esta el arreglo. El
    guardia que ya existia en `_materialize_debt` busca ficheros en
    `snippet + context[:300]`, asi que una narracion de sesion sin sujeto pasaba en
    cuanto la conversacion de alrededor citaba de pasada un fichero que existe en el
    repo. El contexto es la conversacion; el snippet es lo que la ficha va a AFIRMAR.

    Lo midio `o2o` leyendo sus 103 fichas `CONV-DEBT-*` una por una: **71 de 103 ni
    siquiera son una afirmacion tecnica** -- narracion de estado de sesion, fragmentos de
    log historico, transcripciones de OTRO proyecto coladas por error. *"El problema no
    esta en como se cuentan, esta en que se crearon."* Una ficha sin sujeto no es deuda:
    es un recorte de conversacion.

    LIMITE DECLARADO (DEBT-HARVESTER-SUBJECT-CHECK-BLIND-TO-NOISY-CITATION): esto caza
    «no nombra nada». NO caza un hallazgo que cita un simbolo real y sigue siendo ruido
    -- para eso haria falta poder correr su verificacion en tiempo de cosecha, que aqui
    no se puede.
    """
    return bool(_SUJETO_TECNICO_RE.search(snippet))


def _extract_however_clause(context: str) -> str | None:
    match = re.search(r"(?:sin embargo|a menos que|excepto\s+(?:si|cuando)|siempre\s+y\s+cuando|however|unless)[^.\n]*", context, re.I)
    return match.group(0).strip() if match else None


def _compute_risk_score(item: dict[str, Any]) -> tuple[str, int, str]:
    """Compute multi-signal risk priority per debtmap heuristics (Complexity x Severity x BlastRadius)."""
    text = (item["snippet"] + " " + item["context"]).lower()
    tag = item.get("tag", "COS")

    if re.search(r"producci[oó]n|cr[ií]tico|seguridad", text):
        return "P0", 10, "HIGH"
    if tag == "BUG" or "fallo" in text or "error" in text or "bloquea" in text:
        return "P1", 8, "HIGH"
    if "falta" in text or "pendiente" in text:
        return "P2", 5, "MEDIUM"
    return "P3", 3, "LOW"


def classify_satd_family(snippet: str, context: str) -> str:
    """Classify technical debt into empirical 4-family taxonomy (Li et al. / SATDBailiff)."""
    text = (snippet + " " + context).lower()
    if any(k in text for k in ["test", "mock", "assert", "skip", "xfail", "cobertura", "mutaci"]):
        return "TEST_DEBT"
    if any(k in text for k in ["docstring", "comentario", "firma", "tipo", "documentaci"]):
        return "DOCUMENTATION_DEBT"
    if any(k in text for k in ["falta validar", "falta implementar", "soporte", "pendiente", "edge case"]):
        return "REQUIREMENT_DEBT"
    return "CODE_DESIGN_DEBT"


def _materialize_debt(
    sig: str,
    item: dict[str, Any],
    target_repo: Path,
    cap_info: tuple[str, list[str]] | None,
    write_root: Path | None = None,
) -> bool:
    # QUALITY GATE between harvesting and DECLARING debt (owner's instruction,
    # 2026-09-02: "universal_harvester tiene que mejorar para generar tasks
    # reales antes de subirlas a open").
    #
    # The check below already refused a finding that named files, none of which
    # exist here. What it did NOT refuse is a finding that names NO file at all
    # -- `if mentioned_files:` skipped the whole gate -- and that is the exact
    # signature of the noise this cost the fleet. Measured in Atlas: 1,947
    # harvested entries, 58 audited by hand, ZERO were real debt; only 1 of the
    # 1,947 had a trivial body, so they were indistinguishable from real
    # findings by reading. They were 92% of that repo's tasks, forced the canon
    # to invent a `void` state that existed only for them, and contributed
    # could_not_run=1385 to its schema gate.
    #
    # A finding that names no file of this repository is not a finding ABOUT
    # this repository. It may still be a true observation; it is not debt, and
    # the gap between those two is what this gate exists to hold.
    #
    # DECLARED LIMIT: this catches "names no file" and "names only files that do
    # not exist". It does NOT catch a finding that cites a real file and is
    # still noise -- for that the ticket suggests a second condition, that the
    # verification_command be able to come out red, and that one needs the
    # command to be runnable at harvest time, which it is not here.
    #
    # SEGUNDA MITAD, 2026-09-06. La de arriba pregunta si el CONTEXTO cita un fichero que
    # existe aqui; esta pregunta si el HALLAZGO afirma algo sobre algo. Son distintas, y
    # la diferencia es justo el hueco por el que entraron las 71 de 103 de o2o: una
    # narracion de sesion sin sujeto pasaba en cuanto la conversacion de alrededor
    # mencionaba de pasada un fichero real. Ver `snippet_names_a_subject`.
    if not snippet_names_a_subject(item["snippet"]):
        return False
    mentioned_files = re.findall(r"([\w./\-]+\.(?:py|js|ts|html|sh|toml|json))", item["snippet"] + " " + item["context"][:300])
    has_existing_target = any(
        (target_repo / f).is_file() or (target_repo / "src" / f).is_file() or (target_repo / "tests" / f).is_file()
        for f in mentioned_files
    )
    if not has_existing_target:
        return False

    dest_dir = (write_root or target_repo) / "tasks" / "backlog"
    dest_dir.mkdir(parents=True, exist_ok=True)
    fname = dest_dir / f"CONV-DEBT-{sig.upper()}.md"
    if fname.is_file():
        return True

    tag = item.get("tag", "COS")
    slug = re.sub(r"[^a-zA-Z0-9_\-]+", "_", item["snippet"][:40]).strip("_")
    however = _extract_however_clause(item["context"])
    sev, risk_score, blast_radius = _compute_risk_score(item)
    satd_fam = classify_satd_family(item["snippet"], item["context"])

    cross_ref = ""
    if cap_info:
        cap_name, _ = cap_info
        cross_ref = f"\n## CROSS-POLLINATION · Solución en Atlas\n- Ver Caso de Uso: `Atlas/docs/use_cases/UC-{cap_name}-{sig.upper()}.md`\n"

    content = (
        ledger_schema.render_frontmatter(
            id=f"CONV-DEBT-{sig.upper()}",
            title=f"Validate conversational finding: {slug}",
            status="open", severity=sev, satd_family=satd_fam,
            # This is an open work item.  The command is deliberately only a
            # closure plan, never executed as evidence until the owner replaces
            # it with the concrete regression check for this repository.
            close_check={"cmd": "triage-required", "expect": "exit_zero"},
            risk_score=risk_score, blast_radius=blast_radius, tag=tag,
        )
        + "\n"
        f"# Conversational Debt [{tag} | {satd_fam}]: {slug}\n\n"
        f"**Source:** `{item.get('file', 'unknown')}` (Line/ID #{item.get('line', 1)})\n"
        f"**Multi-Signal Priority:** `{sev}` (Risk Score: `{risk_score}/10`, Blast Radius: `{blast_radius}`, SATD Family: `{satd_fam}`)\n\n"
        f"## I · Issue (Deficiencia Identificada)\n> \"{item['snippet']}\"\n\n"
        f"## R · Rule / Mecanismo Implicado (DGX-40)\n- Componente afectado: `{slug}`\n- Clasificación: `{tag}`\n\n"
        f"## A · Application (Evidencia y Contexto Verbatim)\n```text\n{item['context'].strip()}\n```\n\n"
        + (f"## HOWEVER · Condición Derrotable / Excepción (SIRAC)\n- `{however}`\n\n" if however else "")
        + cross_ref
        + f"## C · Conclusion & Resolution\n1. Diseñar prueba de regresión específica.\n2. Corregir defecto y validar con suite de pruebas.\n\n"
        + f"```json queue-job\n"
        + f"{{\n"
        + f'  "name": "remediate_conv_debt_{sig.lower()}",\n'
        + f'  "command": "triage-required",\n'
        + f'  "artifact": "tasks/backlog/CONV-DEBT-{sig.upper()}.md"\n'
        + f"}}\n"
        + f"```\n"
    )
    atomic_io.write_text_durable(fname, content, encoding="utf-8")
    return True


def _materialize_decision(sig: str, item: dict[str, Any], target_repo: Path, write_root: Path | None = None) -> bool:
    dest_dir = (write_root or target_repo) / "docs" / "decisions"
    dest_dir.mkdir(parents=True, exist_ok=True)
    fname = dest_dir / f"ADR-HARVESTED-{sig.upper()}.md"
    if fname.is_file():
        return True

    tag = item.get("tag", "COS")
    slug = re.sub(r"[^a-zA-Z0-9_\-]+", "_", item["snippet"][:40]).strip("_")
    however = _extract_however_clause(item["context"])

    content = (
        f"---\n"
        f"id: ADR-{sig.upper()}\n"
        f"status: accepted\n"
        f"tag: {tag}\n"
        f"---\n\n"
        f"# ADR-{sig.upper()}: {slug} (MADR 3.0)\n\n"
        f"## 1. Context and Problem Statement\n> \"{item['snippet']}\"\n\n"
        f"## 2. Decision Drivers (Fuerzas y Limitaciones)\n- Proveniencia: `{item.get('file', 'unknown')}`\n- Clasificación técnica: `{tag}`\n\n"
        f"## 3. Considered Options & Rationale\n```text\n{item['context'].strip()}\n```\n\n"
        + (f"## HOWEVER · Excepción Operativa (SIRAC)\n- `{however}`\n\n" if however else "")
        + f"## 4. Decision Outcome & Validation\n- Opción elegida clasificada como `{tag}`.\n- Obligatoria para futuros refactors en `{target_repo.name}`.\n"
    )
    atomic_io.write_text_durable(fname, content, encoding="utf-8")
    return True


@dataclass(frozen=True)
class _IRUWording:
    """Destination and section wording for one single-file knowledge-asset
    type (LORE, PLAYBOOK, DIRECTIVE) -- these differ only in this, never in
    shape, so one parameterized writer (_materialize_iru_asset) replaces
    three near-identical function bodies. Bundled into one param instead of
    six keyword args to stay under the project's PLR0913 max-args limit."""
    subdir: str
    file_prefix: str
    asset_label: str
    declaration_label: str
    rule_label: str
    however_label: str
    conclusion_label: str
    conclusion_text: str


_LORE_WORDING = _IRUWording(
    subdir="domain_knowledge", file_prefix="LORE",
    asset_label="Domain Rule", declaration_label="Declaración de Dominio",
    rule_label="Especificación y Normativa Aplicable",
    however_label="Excepción Legal / Fiscal",
    conclusion_label="Criterio Operativo",
    conclusion_text="Observancia obligatoria en lógica de negocio.",
)
_PLAYBOOK_WORDING = _IRUWording(
    subdir="runbooks", file_prefix="RUNBOOK",
    asset_label="Runbook", declaration_label="Procedimiento Identificado",
    rule_label="Comandos y Contexto Verbatim",
    however_label="Excepción / Condición Derrotable",
    conclusion_label="Uso Operativo",
    conclusion_text="Ejecutar sólo tras validar que el contexto coincide con el incidente actual.",
)
_DIRECTIVE_WORDING = _IRUWording(
    subdir="user_directives", file_prefix="DIRECTIVE",
    asset_label="User Directive", declaration_label="Principio Declarado",
    rule_label="Contexto Verbatim",
    however_label="Excepción / Condición Derrotable",
    conclusion_label="Carácter",
    conclusion_text="No negociable: observancia obligatoria en toda decisión futura.",
)


def _materialize_iru_asset(
    sig: str,
    item: dict[str, Any],
    target_repo: Path,
    wording: _IRUWording,
    write_root: Path | None = None,
) -> bool:
    """Shared I/R/(HOWEVER)/C materializer for the single-file knowledge
    assets (LORE, PLAYBOOK, DIRECTIVE)."""
    dest_dir = (write_root or target_repo) / "docs" / wording.subdir
    dest_dir.mkdir(parents=True, exist_ok=True)
    fname = dest_dir / f"{wording.file_prefix}-{sig.upper()}.md"
    if fname.is_file():
        return True

    tag = item.get("tag", "COS")
    slug = re.sub(r"[^a-zA-Z0-9_\-]+", "_", item["snippet"][:40]).strip("_")
    however = _extract_however_clause(item["context"])

    content = (
        f"# {wording.asset_label} [{tag}]: {slug}\n\n"
        f"## I · {wording.declaration_label}\n> \"{item['snippet']}\"\n\n"
        f"## R · {wording.rule_label}\n```text\n{item['context'].strip()}\n```\n\n"
        + (f"## HOWEVER · {wording.however_label} (SIRAC)\n- `{however}`\n\n" if however else "")
        + f"## C · {wording.conclusion_label}\n- {wording.conclusion_text}\n"
    )
    atomic_io.write_text_durable(fname, content, encoding="utf-8")
    return True


def _materialize_lore(sig: str, item: dict[str, Any], target_repo: Path, write_root: Path | None = None) -> bool:
    return _materialize_iru_asset(sig, item, target_repo, _LORE_WORDING, write_root)


def _materialize_playbook(sig: str, item: dict[str, Any], target_repo: Path, write_root: Path | None = None) -> bool:
    return _materialize_iru_asset(sig, item, target_repo, _PLAYBOOK_WORDING, write_root)


def _materialize_directive(sig: str, item: dict[str, Any], target_repo: Path, write_root: Path | None = None) -> bool:
    return _materialize_iru_asset(sig, item, target_repo, _DIRECTIVE_WORDING, write_root)


def _materialize_single_item(sig: str, item: dict[str, Any], fleet_dir: Path) -> str:
    """Route one item to real materialization, quarantine staging, gate
    rejection, or outright non-routing, and report which. A cwd-routed item
    that the gate finds no noise markers in writes for real into its target
    repo's tracked tree; everything else that isn't confident noise --
    weakly routed by mentioned-file coincidence alone -- lands in
    QUARANTINE_DIRNAME next to the fleet instead, for human triage. A
    materializer's own dedup/guard logic (e.g. _materialize_debt's
    mentioned-file guard) can still decline to write even after routing and
    the gate both clear an item -- that's "declined", not a routing/gate
    failure."""
    cat = item["category"]
    target_repo, high_confidence_route = _determine_target_repo_with_confidence(
        item["cwd_hint"], item["context"], fleet_dir
    )
    if target_repo is None:
        return "unrouted"
    if _gate_confident_noise(item):
        return "gate_rejected"

    cap_info = _classify_capability(item["context"])
    write_root = target_repo if high_confidence_route else (fleet_dir / QUARANTINE_DIRNAME / target_repo.name)

    if cat == "DEBT":
        written = _materialize_debt(sig, item, target_repo, cap_info, write_root)
    elif cat == "DECISION":
        written = _materialize_decision(sig, item, target_repo, write_root)
    elif cat == "LORE":
        written = _materialize_lore(sig, item, target_repo, write_root)
    elif cat == "PLAYBOOK":
        written = _materialize_playbook(sig, item, target_repo, write_root)
    else:
        written = _materialize_directive(sig, item, target_repo, write_root)

    if not written:
        return "declined"
    return "materialized" if high_confidence_route else "quarantined"


def harvest_all_transcripts(
    sources: list[Path],
    fleet_dir: Path,
    dry_run: bool = False,
    cache_file: Path | None = None,
) -> dict[str, int]:
    """Scan all transcript files across sources and materialize knowledge into the fleet."""
    discovered, new_cache, skip_stats = _collect_all_candidate_items(sources, fleet_dir, cache_file)
    stats: dict[str, int] = {k: 0 for k in PATTERNS}
    stats["DEBT_OVERFLOW"] = 0
    stats["OVERSIZE_SKIPPED"] = skip_stats.get("oversize_skipped", 0)
    stats["MATERIALIZED"] = 0
    stats["QUARANTINED"] = 0
    stats["GATE_REJECTED"] = 0
    stats["DECLINED"] = 0
    stats["UNROUTED"] = 0

    # SPEC-L057: cap materialized DEBT to MAX_REVIEW_DECISIONS reviewable
    # tasks/review/CONV-DEBT-*.md decisions per run, highest risk first
    # (Axiom 9: deterministic tie-break on sig). Overflow is counted and
    # logged -- never silently dropped from the run.
    debt_sigs = sorted(
        (sig for sig, item in discovered.items() if item["category"] == "DEBT"),
        key=lambda s: (-_compute_risk_score(discovered[s])[1], s),
    )
    materializable_debt = set(debt_sigs[:MAX_REVIEW_DECISIONS])
    overflow_debt = debt_sigs[MAX_REVIEW_DECISIONS:]
    if overflow_debt:
        logger.warning(
            "Harvest backlog cap reached: %d DEBT item(s) exceed MAX_REVIEW_DECISIONS=%d "
            "and were not materialized this run: %s",
            len(overflow_debt), MAX_REVIEW_DECISIONS, overflow_debt,
        )
        # The mtime checkpoint must not remember a source file as "scanned"
        # if an item it contributed overflowed the cap -- otherwise the next
        # run sees an unchanged mtime, never re-yields the item, and it is
        # unrecoverable (DEBT_OVERFLOW lived only in this return value,
        # persisted nowhere). Evicting the file's checkpoint entry forces a
        # full re-scan next run so the overflow item is re-discovered and
        # re-attempted against the cap, honestly, instead of vanishing.
        overflow_files = {discovered[sig]["file"] for sig in overflow_debt}
        for f in overflow_files:
            new_cache.pop(f, None)
    stats["DEBT_OVERFLOW"] = len(overflow_debt)

    for sig, item in sorted(discovered.items(), key=lambda kv: kv[0]):
        cat = item["category"]
        if cat == "DEBT" and sig not in materializable_debt:
            continue  # counted in DEBT_OVERFLOW above, not silently dropped
        if dry_run:
            # Nothing is written in a dry run, so report candidates found
            # rather than claiming writes that never happen.
            stats[cat] = stats.get(cat, 0) + 1
            continue
        verdict = _materialize_single_item(sig, item, fleet_dir)
        # Only count what actually landed on disk (materialized into a
        # repo's tracked tree, or staged in quarantine for triage) -- a
        # gate rejection, a routing miss, or a materializer's own dedup
        # guard means nothing was written, and the summary must not claim
        # a capture that didn't happen.
        if verdict in ("materialized", "quarantined"):
            stats[cat] = stats.get(cat, 0) + 1
        stats[verdict.upper()] = stats.get(verdict.upper(), 0) + 1

    if not dry_run and cache_file:
        _save_checkpoint_cache(cache_file, new_cache)

    return stats


def harvest_chat_transcript(transcript: Path, fleet: Path, dry_run: bool = False) -> int:
    """Production entry point for the `harvest-chat` CLI command (DGX-169:
    conversational debt from a single session transcript).

    Wires transcript_acquire.read_transcript in as a loud fail-fast
    acquisition step: it reports turn/output-token accounting and
    pre-compaction-discard diagnostics that scan_transcript_file does not
    compute (scan_transcript_file only regex-extracts knowledge snippets; it
    has no notion of assistant output tokens or the last compact marker).
    On an unreadable/corrupt/oversize transcript this returns COULD_NOT_RUN
    (30) without touching the fleet. Otherwise it reuses the shared
    knowledge-asset pipeline (harvest_all_transcripts) against the same file
    so DEBT/DECISION/LORE/PLAYBOOK/DIRECTIVE extraction stays a single
    implementation, not a second parallel path.
    """
    from simplecode.verification import transcript_acquire

    turns, diagnostics = transcript_acquire.read_transcript(str(transcript))
    print(f"=== TRANSCRIPT ACQUISITION DIAGNOSTICS (DGX-169): {transcript} ===")
    print(f"  turns_acquired={len(turns)} {diagnostics}")
    if diagnostics["files_unreadable"] or diagnostics["lines_unparseable"]:
        print(f"COULD_NOT_RUN: transcript acquisition failed: {diagnostics['error']}")
        return 30

    stats = harvest_all_transcripts([transcript], fleet, dry_run=dry_run)
    print("\n=== HARVEST-CHAT SUMMARY BY KNOWLEDGE ASSET ===")
    for cat, count in sorted(stats.items()):
        print(f"  {cat:15s}: {count:5d} unique asset(s) captured")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Universal Polyglot Knowledge Harvester across Claude, Gemini & Codex")
    ap.add_argument("--fleet", type=Path, default=Path.home() / "projects", help="Fleet root directory")
    ap.add_argument("--source", type=Path, nargs="*", default=None, help="Specific directories/files to scan")
    ap.add_argument("--dry-run", action="store_true", help="Report counts without writing files")
    args = ap.parse_args(argv)

    fleet = args.fleet.resolve()
    if not args.source:
        print("COULD_NOT_RUN: --source is required; unbounded historical mining is prohibited")
        return 2
    sources = [p.resolve() for p in args.source]
    cache_file = fleet / "simplecode" / ".simplecode" / "cache" / "harvest_checkpoint.json"

    print("=== UNIVERSAL TRANSCRIPT & GIT HARVESTER (Claude, Gemini, Codex, Git) ===")
    print(f"Sources: {[str(s) for s in sources]}")
    print(f"Target Fleet: {fleet}")

    stats = harvest_all_transcripts(sources, fleet, dry_run=args.dry_run, cache_file=cache_file)
    print("\n=== HARVEST SUMMARY BY KNOWLEDGE ASSET ===")
    for cat, count in sorted(stats.items()):
        print(f"  {cat:15s}: {count:5d} unique asset(s) captured")
    return 0


if __name__ == "__main__":
    sys.exit(main())
