# -*- coding: utf-8 -*-
"""adversarial_probes.py -- Dynamic blackbox adversarial probes for Simplecode satellites (Tier 3).

Executes active behavioral verification against real filesystems in isolated tmpfs
sandboxes, validating security invariants (path containment, atomic rollback, zero-mock
execution) without trusting mocked test suites.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class ProbeFinding:
    """A defect or vulnerability discovered by a dynamic probe."""

    probe_id: str
    severity: str  # "CRITICAL" | "HIGH" | "MEDIUM"
    title: str
    evidence: str
    location: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ProbeResult:
    """Summary of a probe execution against a project."""

    probe_id: str
    name: str
    # "PASSED" | "FAILED" | "SKIPPED" | "COULD_NOT_RUN".
    # COULD_NOT_RUN exists because two of these probes never executed the
    # SUBJECT: they grepped src/ for a keyword and returned PASSED if it
    # appeared anywhere. Measured 2026-09-01 with a deliberately vulnerable
    # repo -- `shutil.move`/`os.rename` with no journal, archive entries joined
    # into a destination with no containment -- which passed all three probes,
    # rc=0, because the words `startswith` and `rollback` occurred once in an
    # unrelated comment in another file. An instrument that cannot fail is not
    # an instrument, and a probe that cannot reach its subject must say so
    # instead of reporting the subject clean.
    status: str
    duration_ms: int
    findings: list[ProbeFinding] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def probe_path_containment(root: Path) -> ProbeResult:
    """Probe 1: run THIS project's own evidence-path resolver against traversal.

    Rewritten 2026-09-05. The previous body grepped `src/` for the words
    `is_relative_to`, `commonpath` or `startswith` and could never say PASSED,
    because a keyword appearing somewhere in a tree is not evidence that the
    path handling in question is guarded. It reported COULD_NOT_RUN forever,
    which was honest and useless.

    The subject it should always have had is
    `ledger_schema._es_ruta_existente`: it takes the raw `evidence:` value out
    of a ficha's frontmatter and answers whether that names a real file, which
    is what lets a ficha be closed. Executing it with traversal vectors found
    a real defect the same minute -- `/etc/hostname` and
    `../../../../etc/hostname` both returned True, so the evidence contract
    could be satisfied three times over by a file that is not in the repo and
    that a reviewer cannot read in a diff.
    """
    from simplecode.verification import ledger_schema

    findings: list[ProbeFinding] = []
    root = root.resolve()

    escapes = [
        ("/etc/hostname", "Absolute path outside the repository"),
        ("../../../../etc/hostname", "Multi-level relative traversal"),
        ("../" * 12 + "etc/passwd", "Deep relative traversal"),
    ]
    for payload, desc in escapes:
        if ledger_schema._es_ruta_existente(root, payload):
            findings.append(
                ProbeFinding(
                    probe_id="PROBE-PATH-CONTAINMENT",
                    severity="CRITICAL",
                    title=f"Evidence path escapes the repository: {desc}",
                    evidence=(
                        f"ledger_schema._es_ruta_existente(root, {payload!r}) returned True, "
                        f"so a ficha citing it satisfies the `evidence` contract with a file "
                        f"outside {root}."
                    ),
                    location="src/simplecode/verification/ledger_schema.py",
                )
            )

    # The probe's OWN negative control, run every time rather than argued: a
    # guard that refuses everything would make the three vectors above pass
    # while silently breaking every honest ficha. If a real in-repo file is
    # also refused, this probe is measuring a broken guard, not a safe one, and
    # it must say so instead of reporting the subject clean.
    # The control needs a path that really exists under `root`, and it must NOT
    # be one this probe creates: writing a fixture into the repo being measured
    # is `self_polluting_tooling`, and zero-debt convicted the first version of
    # this probe for exactly that. So an existing file is BORROWED, never made.
    testigo = next(
        (f for f in sorted(root.rglob("*.md"))
         if f.is_file() and ".git" not in f.parts and ".venv" not in f.parts),
        None,
    )
    if testigo is None:
        # No file to borrow means this half was not measured. Saying so beats
        # reporting the guard sound on a control that never ran.
        return ProbeResult(
            probe_id="PROBE-PATH-CONTAINMENT",
            name="Path Containment & Traversal Resistance Probe",
            status="FAILED" if findings else "COULD_NOT_RUN",
            duration_ms=10,
            findings=findings,
        )
    rel = testigo.relative_to(root).as_posix()
    if not ledger_schema._es_ruta_existente(root, rel):
        findings.append(
            ProbeFinding(
                probe_id="PROBE-PATH-CONTAINMENT",
                severity="CRITICAL",
                title="Containment guard refuses a legitimate in-repo evidence path",
                evidence=(
                    f"ledger_schema._es_ruta_existente(root, {rel!r}) returned False for a "
                    f"file that exists inside the repo. The guard is over-broad: every "
                    f"honest ficha would fail to close."
                ),
                location="src/simplecode/verification/ledger_schema.py",
            )
        )

    # PASSED is now reachable, and it means the subject's own function was
    # CALLED and behaved in both directions -- not that a word was found.
    return ProbeResult(
        probe_id="PROBE-PATH-CONTAINMENT",
        name="Path Containment & Traversal Resistance Probe",
        status="FAILED" if findings else "PASSED",
        duration_ms=10,
        findings=findings,
    )


# patch()/MagicMock() per test. See probe_zero_mock_density for the fleet
# measurement this was calibrated against: the worst real repo sits at 0.09, so
# 0.5 is five times the observed worst and still convicts a mock-choked suite.
MOCK_DENSITY_CEILING = 0.5


def probe_zero_mock_density(root: Path) -> ProbeResult:
    """Probe 2: Detect test suites with excessive mock density masking real filesystem defects."""
    findings: list[ProbeFinding] = []
    root = root.resolve()
    tests_dir = root / "tests"

    # An absent or empty tests/ is the ABSENCE of a subject, never a clean one:
    # this probe measures mock density in real test files, and with no test
    # files to read it has measured nothing. Returning PASSED here made a repo
    # with zero tests indistinguishable from one with a healthy suite.
    if not tests_dir.is_dir():
        return ProbeResult(
            probe_id="PROBE-ZERO-MOCK-DENSITY",
            name="Zero-Mock Filesystem Integration Probe",
            status="COULD_NOT_RUN",
            duration_ms=0,
            findings=[],
        )

    # RECALIBRATED 2026-09-05. The probe is named DENSITY and measured an
    # absolute repo-wide COUNT against a fixed threshold of 30, counting
    # `monkeypatch` -- pytest's own sanctioned fixture -- as a mock. Two ordinary
    # test files cleared it, so on any mature suite this probe could return
    # exactly one verdict, forever. A gate that can only say FAIL is as
    # uninformative as one that can only say PASS: neither reading tells you
    # anything about the subject.
    #
    # Measured across the 17-repo fleet before choosing the new shape:
    #
    #     repo          tests   patch(/MagicMock(   monkeypatch
    #     Atlas          3529                  12          2650
    #     simplecode     1942                 137          1332
    #     office2office  1174                   2           117
    #     declutter       396                  22            62
    #     cuenza          301                  28            53
    #
    # `monkeypatch` dominates by two orders of magnitude and is NOT what this
    # probe is about: it is the recommended pytest way to isolate, and it does
    # not fabricate filesystem behaviour the way a MagicMock stands in for a real
    # file. Real mock usage is low everywhere -- the worst repo in the fleet sits
    # at 0.09 per test.
    #
    # So: count only the constructs that actually substitute for real I/O, and
    # measure them PER TEST. The ceiling is 0.5 -- more than five times the
    # fleet's worst observed density, so it convicts a genuinely mock-choked
    # suite and stays silent on every real one measured. Both directions are
    # tested; `monkeypatch` is reported alongside, as information, never as a
    # verdict.
    mock_count = 0
    monkeypatch_count = 0
    test_count = 0
    test_files_with_heavy_mocks: list[str] = []
    test_files_read = 0

    for test_file in sorted(tests_dir.rglob("test_*.py")):
        test_files_read += 1
        code = test_file.read_text(encoding="utf-8", errors="replace")
        tests_here = code.count("def test_")
        mocks_here = code.count("patch(") + code.count("MagicMock(")
        test_count += tests_here
        mock_count += mocks_here
        monkeypatch_count += code.count("monkeypatch")
        if tests_here and mocks_here / tests_here > MOCK_DENSITY_CEILING:
            test_files_with_heavy_mocks.append(
                f"{test_file.name} ({mocks_here} mocks / {tests_here} tests)"
            )

    density = mock_count / test_count if test_count else 0.0
    if density > MOCK_DENSITY_CEILING and test_files_with_heavy_mocks:
        findings.append(
            ProbeFinding(
                probe_id="PROBE-ZERO-MOCK-DENSITY",
                severity="HIGH",
                title="Excessive Mock Density Masking Real Filesystem Behavior",
                evidence=(
                    f"{mock_count} patch()/MagicMock() across {test_count} tests "
                    f"= {density:.2f} per test, over the {MOCK_DENSITY_CEILING} ceiling. "
                    f"Worst files: {', '.join(test_files_with_heavy_mocks[:3])}. "
                    f"(monkeypatch used {monkeypatch_count} times and NOT counted: it is "
                    f"pytest's own fixture, not a stand-in for real I/O.) "
                    f"Critical I/O must be tested against real tmp_path fixtures."
                ),
                location=str(tests_dir),
            )
        )

    # The per-file case, REPORTED and not blocking. Two legitimate questions
    # live here and the `and` above answered only one of them.
    #
    # Reported by the agente_inmobiliario session 2026-09-05, found by looking
    # for the negative control rather than by reading the code, and measured in
    # both directions in a 250-test suite:
    #
    #   3 MagicMock planted in ONE file -> that file's density 3.0, six times
    #     the ceiling                    -> PASSED, rc=0
    #   130 MagicMock planted            -> repo density 0.52 -> FAILED, rc=1
    #
    # `density` is the whole repo's, so with 250 tests it takes >125 mocks
    # before the gate says anything -- and the case this probe exists to catch,
    # ONE file substituting the disk instead of exercising it, is exactly the
    # one the average dilutes. The more mature the suite, the more invisible.
    # Their reading of my own comment is right: the old version could only say
    # FAIL, and this one, in any repo with a decent suite, can only say PASS.
    #
    # NOT armed to block today, and the reason is measured rather than cautious.
    # Across the fleet -- 18 repos, 646 test files -- exactly 10 files exceed
    # the per-test ceiling, and they sit in 4 repos INCLUDING THIS ONE
    # (test_prek_vendor.py 25/25, test_final_100_perfection.py 21/18,
    # test_worktree_collision.py 11/5). Arming it would turn 4 repos red the day
    # it ships, which is the "blocking gate on an unmeasured assumption" mistake
    # this session already made once today with the telemetry hook. The arming
    # is a decision with the fleet numbers in hand, not a calculation.
    #
    # So it is emitted at severity INFO and excluded from the FAILED verdict:
    # visible and named, which is the actual complaint -- the file was
    # invisible, not unblocked.
    if test_files_with_heavy_mocks and not findings:
        findings.append(
            ProbeFinding(
                probe_id="PROBE-ZERO-MOCK-DENSITY",
                severity="INFO",
                title="Individual test files over the per-test mock ceiling",
                evidence=(
                    f"{len(test_files_with_heavy_mocks)} file(s) exceed "
                    f"{MOCK_DENSITY_CEILING} mocks per test while the repo-wide "
                    f"density is {density:.2f}, under the same ceiling: "
                    f"{', '.join(test_files_with_heavy_mocks[:3])}. "
                    f"REPORTED, not blocking -- the repo average measures "
                    f"aggregate health and this measures one file substituting "
                    f"the disk; answering the first does not answer the second."
                ),
                location=str(tests_dir),
            )
        )

    if any(f.severity != "INFO" for f in findings):
        status = "FAILED"
    elif test_files_read == 0:
        status = "COULD_NOT_RUN"  # tests/ exists but holds no test_*.py
    elif test_count == 0:
        # Files exist but hold no `def test_`. A density needs a denominator;
        # with none, this probe measured NOTHING. Reporting PASSED here would
        # make "no tests to divide by" indistinguishable from "a healthy ratio"
        # -- the same conflation the absent-tests branch above already refuses.
        status = "COULD_NOT_RUN"
    else:
        status = "PASSED"
    return ProbeResult(
        probe_id="PROBE-ZERO-MOCK-DENSITY",
        name="Zero-Mock Filesystem Integration Probe",
        status=status,
        duration_ms=15,
        findings=findings,
    )


def probe_atomic_journal_integrity(root: Path) -> ProbeResult:
    """Probe 3: run THIS project's own backup/rollback path and check it rolls back.

    Rewritten 2026-09-05. The previous body scanned `src/` for `shutil.move`
    beside the words `journal`, `undo` or `rollback` and reported COULD_NOT_RUN
    when it found both -- the presence of a word in a tree says nothing about
    whether the destructive path is recoverable. Measured 2026-09-01 against a
    deliberately vulnerable repo, that shape passed all three probes at rc=0
    because `rollback` appeared once in an unrelated comment.

    The subject is `atomic_io.write_text_durable(backup=True)` +
    `restore_from_backup`, which is what this repo actually uses to make a
    rejected write recoverable.
    """
    from simplecode.utils import atomic_io

    findings: list[ProbeFinding] = []
    root = root.resolve()

    with tempfile.TemporaryDirectory() as sandbox:
        target = Path(sandbox) / "ledger.txt"
        original = "the row that must survive a rejected write\n"
        atomic_io.write_text_durable(target, original)

        atomic_io.write_text_durable(target, "corrupted replacement\n", backup=True)
        restored = atomic_io.restore_from_backup(target)
        content = target.read_text(encoding="utf-8")
        if not restored or content != original:
            findings.append(
                ProbeFinding(
                    probe_id="PROBE-ATOMIC-JOURNAL",
                    severity="HIGH",
                    title="A rejected write cannot be rolled back",
                    evidence=(
                        f"restore_from_backup returned {restored!r} and the file holds "
                        f"{content!r}, expected {original!r}. A write rejected after the "
                        f"replace would be unrecoverable."
                    ),
                    location="src/simplecode/utils/atomic_io.py",
                )
            )

        # The probe's own negative control: restore must REFUSE when there is no
        # backup, rather than reporting success over an unknown. A restore that
        # always returns True would make the check above pass while proving
        # nothing -- the same shape the suspension contract refuses.
        virgin = Path(sandbox) / "no-backup.txt"
        atomic_io.write_text_durable(virgin, "never backed up\n")
        if atomic_io.restore_from_backup(virgin):
            findings.append(
                ProbeFinding(
                    probe_id="PROBE-ATOMIC-JOURNAL",
                    severity="HIGH",
                    title="restore_from_backup reports success with no backup on disk",
                    evidence=(
                        "restore_from_backup returned True for a file that has no .bak "
                        "sidecar, so its True carries no information and the rollback "
                        "check above cannot fail."
                    ),
                    location="src/simplecode/utils/atomic_io.py",
                )
            )

    return ProbeResult(
        probe_id="PROBE-ATOMIC-JOURNAL",
        name="Atomic Journal & Rollback Integrity Probe",
        status="FAILED" if findings else "PASSED",
        duration_ms=10,
        findings=findings,
    )


ALL_PROBES: list[Callable[[Path], ProbeResult]] = [
    probe_path_containment,
    probe_zero_mock_density,
    probe_atomic_journal_integrity,
]


def run_all_probes(root: Path) -> list[ProbeResult]:
    """Execute all Tier 3 dynamic behavioral probes against the target project root."""
    results: list[ProbeResult] = []
    for probe_fn in ALL_PROBES:
        try:
            res = probe_fn(root)
            results.append(res)
        except Exception as exc:
            logger.error("Probe %s crashed: %s", probe_fn.__name__, exc)
            results.append(
                ProbeResult(
                    probe_id=probe_fn.__name__.upper(),
                    name=probe_fn.__name__,
                    status="FAILED",
                    duration_ms=0,
                    findings=[
                        ProbeFinding(
                            probe_id=probe_fn.__name__.upper(),
                            severity="CRITICAL",
                            title="Probe Execution Crash",
                            evidence=str(exc),
                        )
                    ],
                )
            )
    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run Tier 3 dynamic adversarial probes against project invariants."
    )
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Target repository root")
    parser.add_argument("--gate", action="store_true", help="Exit nonzero if any probe fails")
    parser.add_argument("--json", action="store_true", help="Output results as JSON")
    args = parser.parse_args(argv)

    results = run_all_probes(args.root)

    could_not_run = [r for r in results if r.status == "COULD_NOT_RUN"]
    failed = [r for r in results if r.status == "FAILED"]

    if args.json:
        print(json.dumps([r.to_dict() for r in results], indent=2, ensure_ascii=False))
        return 1 if ((failed or could_not_run) and args.gate) else 0

    print(f"\n=== SONDAS ADVERSARIALES DINÁMICAS (Tier 3) — {args.root.name} ===")
    badges = {
        "PASSED": ("✓ PASSED", "\033[32m"),
        "SKIPPED": ("⊘ SKIPPED", "\033[33m"),
        "COULD_NOT_RUN": ("? COULD_NOT_RUN", "\033[33m"),
        "FAILED": ("✗ FAILED", "\033[31m"),
    }
    total_findings = 0
    for r in results:
        badge, color = badges.get(r.status, ("✗ FAILED", "\033[31m"))
        print(f"  {color}[{badge}]\033[0m {r.name} ({r.duration_ms}ms)")
        total_findings += len(r.findings)
        for f in r.findings:
            print(f"      • [{f.severity}] {f.title}")
            print(f"        Evidencia: {f.evidence[:120]}...")

    # Reporting politics: print the zeros, and print what could not run BESIDE
    # what passed. A report with could_not_run > 0 is not a clean report,
    # however many rows pass -- and these probes' own history is why: two of
    # them reported PASSED for years while never executing the subject at all.
    print(f"\n[probe] passed={len(results) - len(failed) - len(could_not_run)} "
          f"failed={len(failed)} could_not_run={len(could_not_run)} "
          f"findings={total_findings}")
    for r in could_not_run:
        print(f"  [COULD_NOT_RUN] {r.name}: the probe never executed this "
              f"project's own code for the invariant it names")

    if not failed and not could_not_run:
        # "found nothing" only when it found nothing. The INFO channel exists so
        # a non-blocking finding is still a finding, and printing OK beside
        # `findings=1` would be the report contradicting its own count -- the
        # same defect this kit spent the day fixing in three other organs.
        informativos = sum(
            1 for r in results for f in r.findings if f.severity == "INFO")
        if informativos:
            print(f"\n\033[32m[probe] OK: every probe reached its subject and "
                  f"nothing blocks -- with {informativos} reported finding(s) "
                  f"above, which block nothing and are not nothing.\033[0m\n")
        else:
            print("\n\033[32m[probe] OK: every probe reached its subject and found nothing.\033[0m\n")
        return 0

    print(f"\n\033[31m[probe] NOT CLEAN: {len(failed)} failed, "
          f"{len(could_not_run)} could not run.\033[0m\n")
    return 1 if args.gate else 0


if __name__ == "__main__":
    sys.exit(main())
