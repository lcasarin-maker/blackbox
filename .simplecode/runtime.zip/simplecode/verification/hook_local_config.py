# -*- coding: utf-8 -*-
"""hook_local_config.py -- per-machine hook overrides, never version-controlled.

Rescued as a standalone mechanism from the Lefthook/prek comparison
(2026-08-31): Lefthook ships `lefthook-local.yml`, a gitignored config that
lets one developer skip specific hooks locally without touching the shared
config everyone else uses. Neither pre-commit nor prek has an equivalent --
but both already honor the standard `SKIP` environment variable (a
comma-joined hook id list; verified live: setting it to `ruff` genuinely
omitted the ruff hook from a real run),  # sunset-reviewed: 4.0 -- same: documents the reviewed local-skip mechanism
so this doesn't need to reimplement hook dispatch -- it only needs to read
one small local file and hand its contents to that existing mechanism.

Orthogonal to the pipeline speed work this session did (xdist, prek) --
this doesn't make anything faster, it lets a developer deliberately skip a
hook that's blocking them locally (a broken local tool install, a hook
under active repair) without editing .pre-commit-config.yaml, which
satellite_sync would overwrite on the next fleet sync anyway.
"""
from __future__ import annotations

import sys
from pathlib import Path

import yaml

# `.simplecode/*` is gitignored fleet-wide already (see .gitignore) -- no
# negation entry needed, this file was never meant to be shared or synced.
_LOCAL_CONFIG_RELPATH = Path(".simplecode") / "hooks-local.yaml"


# ---------------------------------------------------------------------------
# The twin-filename guard
# ---------------------------------------------------------------------------
#
#     .simplecode/local_hooks.yaml   ADDS a satellite's own hooks  (satellite_sync)
#     .simplecode/hooks-local.yaml   SKIPs gates per developer     (this module)
#
# Same directory, one letter and one hyphen apart, opposite purposes. Measured
# cost 2026-09-01: Atlas looked for the second, concluded no extension mechanism
# existed, and re-applied a deleted gate by hand expecting to repeat it after
# every sync. Renaming either one now would break what Atlas adopted hours
# earlier, so instead each file refuses to stay silent about content shaped like
# its twin's and names the file the author probably wanted.

_EXTRA_HOOKS_FILE = "local_hooks.yaml"
_SKIP_FILE = "hooks-local.yaml"

_TWINS: dict[str, tuple[str, str, str]] = {
    # this file -> (its twin, the key IT reads, the key the TWIN reads)
    _SKIP_FILE: (_EXTRA_HOOKS_FILE, "skip", "extra_hooks"),
    _EXTRA_HOOKS_FILE: (_SKIP_FILE, "extra_hooks", "skip"),
}

_PURPOSE = {
    _EXTRA_HOOKS_FILE: "adds this repo's own hooks on top of the canonical set (satellite_sync)",
    _SKIP_FILE: "skips gates for one developer on one machine, via the SKIP environment variable",
}


def _top_level_keys(path: Path) -> set[str]:
    """The mapping keys of a YAML file, empty for anything unreadable."""
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return set()
    return set(data) if isinstance(data, dict) else set()


def misfiled_key_warning(root: Path, filename: str) -> str | None:
    """Warn when a key landed in the wrong one of the two near-identical files.

    Returns the message, or None when nothing looks misfiled. Two shapes are
    detected, both of which read as "the mechanism does not exist" to whoever
    wrote the file:

    - this file carries the TWIN's key and not its own (the author wrote the
      right content into the wrong filename);
    - this file's own key sits in the TWIN instead (same mistake, other way).
    """
    twin_name, own_key, twin_key = _TWINS[filename]
    directory = root / ".simplecode"
    here = _top_level_keys(directory / filename)
    there = _top_level_keys(directory / twin_name)

    if twin_key in here and own_key not in here:
        return (
            f"{directory / filename} declares `{twin_key}:`, which this file does not "
            f"read -- it only reads `{own_key}:`. `{twin_key}:` belongs in "
            f"`.simplecode/{twin_name}`, which {_PURPOSE[twin_name]}. The two "
            f"filenames differ by one letter and one hyphen and do opposite things."
        )
    if own_key in there and own_key not in here:
        return (
            f"{directory / twin_name} declares `{own_key}:`, which nothing reads there. "
            f"`{own_key}:` is read from `.simplecode/{filename}`, which "
            f"{_PURPOSE[filename]}. The two filenames differ by one letter and one "
            f"hyphen and do opposite things."
        )
    return None


def local_skip_hook_ids(root: Path) -> tuple[str, ...]:
    """Hook ids to skip, read from `.simplecode/hooks-local.yaml`'s `skip:`
    key. Absent file, malformed YAML, wrong shape, or a non-dict `skip:`
    value all fall through to an empty tuple -- fail-safe means "skip
    nothing extra", never a COULD_NOT_RUN for a config nobody has to
    create."""
    config_path = root / _LOCAL_CONFIG_RELPATH
    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return ()
    if not isinstance(data, dict):
        return ()
    skip = data.get("skip", [])
    if not isinstance(skip, list):
        return ()
    ids = tuple(str(item) for item in skip if isinstance(item, str) and item.strip())
    if not ids:
        _warn_if_misfiled(root, _SKIP_FILE)
    return ids


def _warn_if_misfiled(root: Path, filename: str) -> None:
    """Print the twin-filename warning to stderr, if there is one.

    Only reached when this file yielded nothing -- which is exactly the moment
    the author is about to conclude the mechanism does not exist.
    """
    message = misfiled_key_warning(root, filename)
    if message:
        print(f"[hook-config] {message}", file=sys.stderr)


def local_env_file(root: Path) -> Path | None:
    """La ruta del fichero de ENTORNO local que el launcher debe sourcear, o None.

    D5, transferida desde aequitas_os el 2026-09-06. `hook_install.install_hooks`
    reescribe los cuatro scripts desde la plantilla canonica en cada sync, asi que
    cualquier ajuste hecho a mano en `.git/hooks/pre-commit` se pierde. Medido en
    aequitas_os: el kit cambio cuatro veces en una sesion y la linea
    `. "$HOME/.aequitas_hook_env"` desaparecio al menos dos veces
    (`grep -c` paso de 1 a 0 sin que nadie tocara los hooks). No es cosmetico: sin
    ese entorno su conftest se niega a correr y `backlog_verifier` leyo el exit 4
    como que el hallazgo reproduce -- **ocho acusaciones de fraude contra fichas
    sanas**, que con el entorno cargado dan cero.

    El precedente estaba en el propio `hook_install.py`: "Reported by declutter
    2026-09-01 after mother-sync erased their local fix twice in one session". Ahi
    se cerro el sintoma (faltaba el hook de merge) y la causa siguio abierta cinco
    dias -- el sync borra arreglos locales y no ofrecia donde ponerlos.

    Reusa el canal que YA existe (mismo fichero gitignored, ya excluido del sync, ya
    leido en cada corrida) con un segundo campo, en vez de inventar un mecanismo.

    Se valida, y cada rechazo DICE cual fue: sourcear un fichero es ejecutar codigo
    en cada commit, asi que un fichero dentro del repo queda prohibido -- seria un
    vector para ejecutar codigo en la maquina de cualquiera que clone, en los 17
    satelites. Todo rechazo devuelve None y deja correr las compuertas: fail-safe
    aqui es "sin entorno local", nunca "sin compuertas".
    """
    config_path = root / _LOCAL_CONFIG_RELPATH
    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return None
    if not isinstance(data, dict):
        return None
    crudo = data.get("env_file")
    if crudo is None:
        return None
    if not isinstance(crudo, str) or not crudo.strip():
        print(f"[hook-local-config] env_file en {_LOCAL_CONFIG_RELPATH.as_posix()} "
              f"no es una ruta: {crudo!r}", file=sys.stderr)
        return None

    ruta = Path(crudo.strip()).expanduser()
    if not ruta.is_absolute():
        print(f"[hook-local-config] env_file debe ser una ruta absoluta (o con ~); "
              f"recibido {crudo!r}", file=sys.stderr)
        return None
    # `is_file()` dentro del try, no fuera: cuando el directorio padre no es
    # atravesable, PROPAGA el error en vez de devolver False, y una excepcion aqui
    # tumba el hook entero en vez de rechazar la config con un mensaje. Lo destapo
    # su propio test.
    try:
        if not ruta.is_file():
            print(f"[hook-local-config] env_file no existe: {ruta}", file=sys.stderr)
            return None
        if ruta.resolve().is_relative_to(root.resolve()):
            print(f"[hook-local-config] env_file RECHAZADO por estar dentro del repo: "
                  f"{ruta} -- se sourcea en cada commit, y un fichero versionable ahi "
                  f"ejecuta codigo en la maquina de todo el que clone",
                  file=sys.stderr)
            return None
        modo = ruta.stat().st_mode
    except OSError as exc:
        print(f"[hook-local-config] env_file ilegible: {ruta}: {exc}", file=sys.stderr)
        return None
    if modo & 0o022:
        print(f"[hook-local-config] env_file RECHAZADO por ser escribible por grupo u "
              f"otros (modo {modo & 0o777:o}): {ruta} -- cualquiera con esa cuenta "
              f"ejecutaria codigo en cada commit. Arreglalo con: chmod 600 {ruta}",
              file=sys.stderr)
        return None
    return ruta


def main(argv: list[str] | None = None) -> int:
    """Print a comma-joined SKIP value for the shell launcher to export, or
    nothing if there's nothing to skip. Always exits 0 -- this is advisory
    config, never a gate of its own."""
    argv = sys.argv[1:] if argv is None else argv
    root = Path(".").resolve()
    if "--root" in argv:
        root = Path(argv[argv.index("--root") + 1]).resolve()
    # Una invocacion, un significado. `--env-file` NO se mezcla con la lista de
    # SKIP en el mismo stdout: mezclar dos cosas en un stream que el launcher
    # captura con `$(...)` es exactamente la causa de D4 (un banner de otro modulo
    # se exporto como SKIP y produjo cuatro compuertas fantasma). Cuesta ~30 ms de
    # arranque de Python extra, medido, sobre un pre-commit de 722 ms.
    if "--env-file" in argv:
        ruta = local_env_file(root)
        if ruta is not None:
            print(ruta)
        return 0
    skip_ids = local_skip_hook_ids(root)
    if skip_ids:
        print(",".join(skip_ids))
    return 0


if __name__ == "__main__":
    sys.exit(main())
