#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""H4 findings-detail ratchet: new detectors must ship WHERE and WHY, not just THAT.

Policy (2026-08-28, user directive): every test/detector failure must name its
exact cause -- line, literal, whatever applies -- never collapse to a bare
pass/fail. `zero_debt`'s findings used to be `line: 0` plus a generic
"<detector> fired" for every one of the ~56 entries in `PATTERN_DETECTORS` /
`AGENT_THREAT_DETECTORS`; the fix (this same day) was a `<detector_id>_findings
(code, path=None) -> list[tuple[int, str]]` sibling convention, picked up
automatically by `zero_debt._detail_providers`. 12 detectors have one so far.

This gate makes that convention STICK going forward without demanding the
other 44 be converted today: a RATCHET, same algebra as `worktree/ratchet.py`
(`compare_debt_to_baseline`) and the H3 findings ratchet -- the recorded
baseline is frozen at today's count of detectors missing a `_findings`
sibling, and the gate fails only if that count ever GROWS. Existing debt is
never retroactively blocking; a NEW detector shipped without detail is.

HONEST LIMIT: this only enforces the sibling's EXISTENCE and callability, not
its quality -- a `_findings` function that always returns `[]` or a single
fake `(1, "trust me")` hit passes this gate. Catching a hollow sibling is H2's
job (a detector's positive control already exercises the bool wrapper; a
`_findings` sibling that never actually fires would need its own dedicated
control, not yet built -- left honest, not silently claimed here).
"""
from __future__ import annotations

import argparse
import sys
from types import ModuleType

from simplecode.guards import agent_threats, pattern_detectors

# Measured 2026-08-28, the day this gate was written: 12 of 56 live detectors
# have a `_findings` sibling. Frozen as the ratchet floor -- see module
# docstring. Raise (never silently lower) only in the same commit that
# converts a detector, mirroring `worktree/ratchet.py`'s own re-baseline
# discipline.
BASELINE_MISSING_COUNT = 44


def _live_registry() -> list[tuple[object, str, ModuleType]]:
    reg: list[tuple[object, str, ModuleType]] = [
        (fn, key, pattern_detectors) for fn, key, _msg in pattern_detectors.PATTERN_DETECTORS
    ]
    reg += [(fn, key, agent_threats) for fn, key, _msg in agent_threats.AGENT_THREAT_DETECTORS]
    return reg


def detectors_missing_findings_detail() -> list[str]:
    """Detector ids with no `<id>_findings` sibling in their own module,
    sorted for deterministic output."""
    missing = [
        key
        for _fn, key, module in _live_registry()
        if not callable(getattr(module, f"{key}_findings", None))
    ]
    return sorted(missing)


def _print_report(missing: list[str]) -> None:
    total = len(_live_registry())
    print(f"[findings-detail-ratchet] detectors in live registry: {total}")
    print(f"[findings-detail-ratchet] with a _findings sibling:   {total - len(missing)}")
    print(f"[findings-detail-ratchet] without one (baseline={BASELINE_MISSING_COUNT}): {len(missing)}")
    if missing:
        shown = ", ".join(missing[:10])
        more = f" ... and {len(missing) - 10} more" if len(missing) > 10 else ""
        print(f"[findings-detail-ratchet]   {shown}{more}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="H4 findings-detail ratchet: no NEW detector may ship without a _findings sibling."
    )
    ap.add_argument("--gate", action="store_true", help="Exit 1 if the missing count grew past the frozen baseline.")
    args = ap.parse_args(argv)

    missing = detectors_missing_findings_detail()
    total = len(_live_registry())
    _print_report(missing)

    # Zero detectors examined is not "nothing to report" -- it means the
    # registries (pattern_detectors.PATTERN_DETECTORS / agent_threats.
    # AGENT_THREAT_DETECTORS) came back empty, i.e. this gate never looked at
    # its subject at all. That is instrument-down, not a clean verdict.
    if total == 0:
        print(
            "[findings-detail-ratchet] COULD_NOT_RUN: 0 detectors in live registry "
            "(pattern_detectors.PATTERN_DETECTORS + agent_threats.AGENT_THREAT_DETECTORS "
            "returned nothing)",
            file=sys.stderr,
        )
        return 1

    if args.gate:
        if len(missing) > BASELINE_MISSING_COUNT:
            print(
                f"BLOCKED [findings-detail-ratchet] - {len(missing)} detectors lack a _findings "
                f"sibling, above the frozen baseline of {BASELINE_MISSING_COUNT}: a new detector "
                "shipped without one. Add a <id>_findings(code, path=None) -> list[tuple[int, str]] "
                "sibling, or lower this only alongside converting an existing one."
            )
            print(
                f"[findings-detail-ratchet] FAIL: {len(missing)} detectors without a _findings "
                f"sibling, above baseline {BASELINE_MISSING_COUNT}; primero {missing[0]}"
            )
            return 1
        print(f"[findings-detail-ratchet] OK - missing count ({len(missing)}) at or below baseline.")
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
