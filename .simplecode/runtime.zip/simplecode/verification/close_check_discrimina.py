#!/usr/bin/env python3
"""El `close_check` de una ficha `done` no puede cerrar tambien la de al lado.

Generalizado desde `gates/close_check_discrimina.py` en aequitas_os (auditoria de flota
2026-09-07, ver DEBT-FLEET-GENERALIZATION-CANDIDATES-2026-09-07 item 1). Medido alli el
2026-09-05: 560 de 614 fichas declaraban el MISMO `close_check` -- el gate generico
`zero_debt --gate` -- que ese dia daba `rc=0`. Un criterio identico en 560 sitios no mide
el sujeto, mide el repo: no puede distinguir una ficha de otra, y se pone verde con el
defecto de cualquiera de ellas dentro.

De esas 560, 530 estaban en `done_unverified` -- declaradas cerradas SIN verificar, que es
el estado diciendo la verdad, no el defecto. El defecto son las 22 que decian `status:
done` (verificada) con un criterio que nunca pudo verificar nada. Ese es el caso que este
gate ataca: `done`, nunca `done_unverified` ni `open`.

LA REGLA, y por que esta y no otra. No se codifica el comando generico concreto: eso solo
cazaria ESE comando, y el siguiente que alguien invente pasaria limpio. Se exige que el
`cmd` de una ficha `done` sea UNICO entre las fichas `done`. Un criterio que cierra dos
fichas distintas no puede discriminar ninguna de las dos, sea cual sea el comando.

UMBRAL MEDIDO en aequitas_os, no elegido a ojo: las 35 fichas `done` que ya tenian
criterio propio ese dia usaban 35 comandos DISTINTOS -- cero solapamiento. Un umbral de 2
no produce ni un falso positivo sobre ese conjunto real, y por eso se pone en 2 y no en 3.

LO QUE ESTE GATE NO MIRA: si el comando SIRVE. Un `close_check` unico puede seguir siendo
uno que no prueba nada de la ficha, o que se pone verde antes de tiempo. Eso lo caza leer
la ficha, no un gate. Tampoco juzga `done_unverified` (declara que no se verifico, honesto
por construccion) ni `open` (una ficha abierta no afirma nada sobre su propio cierre --
ahi un criterio compartido se avisa, no bloquea).

Uso: python -m simplecode.verification.close_check_discrimina --root . [--json]
"""
from __future__ import annotations

import argparse
import collections
import json
import re
from dataclasses import dataclass
from pathlib import Path

FRONTMATTER = re.compile(r"^---\n(.*?)\n---\n", re.S)
CAMPO = re.compile(r"^(status|close_check):\s*(.+)$", re.M)

# Medido en aequitas_os 2026-09-05: 35 fichas `done` con criterio propio usaban 35
# comandos distintos, cero solapamiento. Un umbral de 2 no produce falsos positivos
# sobre ese conjunto real.
UMBRAL_COMPARTIDO = 2


def _campos(texto: str) -> dict[str, str]:
    m = FRONTMATTER.match(texto)
    return dict(CAMPO.findall(m.group(1))) if m else {}


def _cmd(crudo: str) -> str | None:
    """El `cmd` del close_check, o None si el campo no es JSON legible.

    Un close_check ilegible no se cuenta como violacion aqui: otro organo
    (`ledger_schema`/`backlog_verifier`) ya lo reporta como `could_not_run`, y dos
    gates dando veredictos distintos sobre el mismo defecto es peor que uno callado.
    """
    try:
        valor = json.loads(crudo)
    except (ValueError, TypeError):
        return None
    if not isinstance(valor, dict):
        return None
    return str(valor.get("cmd", "")).strip() or None


@dataclass(frozen=True)
class _Bloque:
    """La forma de un grupo del informe. Existe para no pasar parametros sueltos de
    los que varios son `str` intercambiables -- que es como se imprime un hallazgo
    bajo la etiqueta equivocada sin que nada avise."""

    titulo: str
    etiqueta: str
    frase: str
    tope: int
    remedio: str = ""


def _reporta(bloque: _Bloque, grupos: dict[str, list[str]]) -> None:
    print(f"[close-check-discrimina] {bloque.titulo}: {len(grupos)}")
    for cmd, fichas in sorted(grupos.items()):
        print(f"  {bloque.etiqueta}   {len(fichas)} fichas {bloque.frase}: {cmd[:88]}")
        for n in fichas[: bloque.tope]:
            print(f"           {n}")
        if len(fichas) > bloque.tope:
            print(f"           ... y {len(fichas) - bloque.tope} mas")
        if bloque.remedio:
            print(f"         {bloque.remedio}")


def agrupar_por_estado(root: Path) -> tuple[dict[str, list[tuple[str, str]]], int]:
    """(fichas por estado, cuenta de close_check ilegibles). No escribe nada."""
    por_estado: dict[str, list[tuple[str, str]]] = collections.defaultdict(list)
    ilegibles = 0
    tasks_dir = root / "tasks"
    if not tasks_dir.is_dir():
        return por_estado, ilegibles
    for f in sorted(tasks_dir.rglob("*.md")):
        campos = _campos(f.read_text(encoding="utf-8", errors="ignore"))
        estado, crudo = campos.get("status"), campos.get("close_check")
        if not estado or not crudo:
            continue
        cmd = _cmd(crudo)
        if cmd is None:
            ilegibles += 1
            continue
        por_estado[estado].append((f.relative_to(root).as_posix(), cmd))
    return por_estado, ilegibles


def _compartidos(filas: list[tuple[str, str]]) -> dict[str, list[str]]:
    cuenta = collections.Counter(cmd for _, cmd in filas)
    return {
        cmd: sorted(n for n, c in filas if c == cmd)
        for cmd, veces in cuenta.items()
        if veces >= UMBRAL_COMPARTIDO
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    root = args.root

    por_estado, ilegibles = agrupar_por_estado(root)
    malas = _compartidos(por_estado.get("done", []))
    avisos = _compartidos(por_estado.get("open", []))

    if args.json:
        print(json.dumps({
            "done": len(por_estado.get("done", [])),
            "open": len(por_estado.get("open", [])),
            "done_unverified": len(por_estado.get("done_unverified", [])),
            "ilegibles": ilegibles,
            "violations": malas,
            "avisos": avisos,
        }, ensure_ascii=False))
        return 1 if malas else 0

    print(
        f"[close-check-discrimina] done={len(por_estado.get('done', []))} "
        f"open={len(por_estado.get('open', []))} "
        f"done_unverified={len(por_estado.get('done_unverified', []))} "
        f"(no juzgado: declara que no se verifico)"
    )
    print(f"[close-check-discrimina] close_check ilegible (lo reporta otro organo): {ilegibles}")
    _reporta(_Bloque("avisos en `open`", "AVISO", "abiertas comparten", 6), avisos)
    _reporta(
        _Bloque(
            "violations",
            "FAIL",
            "`done` comparten el MISMO criterio",
            12,
            "Un criterio que cierra varias fichas no discrimina ninguna. Dale a cada "
            "una un criterio propio, o pasala a `done_unverified` con su "
            "`unverified_reason` -- que es lo honesto si nunca se verifico.",
        ),
        malas,
    )
    return 1 if malas else 0


if __name__ == "__main__":
    raise SystemExit(main())
