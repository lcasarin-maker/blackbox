"""Ponytail owned by Simplecode: reuse existing evidence-producing organs.

This module deliberately does not reimplement dead-code, marker, or dependency
analysis.  ``ponytail_debt`` owns declared shortcuts and ``orphan_hunter`` owns
the structural survey.  The coordinator gives every harness one neutral entry
point and a Git-derived change measurement; it never reports external benchmark
claims as if they were measurements of the current repository.
"""
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from simplecode.guards import orphan_hunter, ponytail_debt
from simplecode.utils.tool_limits import GIT_O1_TIMEOUT


def _git_numstat(root: Path, base: str) -> tuple[int, int] | None:
    """Return literal added/removed lines against ``base`` or None if unreadable."""
    try:
        result = subprocess.run(
            ["git", "diff", "--numstat", base, "--"], cwd=root, text=True,
            capture_output=True, check=True, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    added = removed = 0
    for row in result.stdout.splitlines():
        fields = row.split("\t", 2)
        if len(fields) < 2 or not fields[0].isdigit() or not fields[1].isdigit():
            continue  # Binary rows have '-' and carry no meaningful line count.
        added += int(fields[0])
        removed += int(fields[1])
    return added, removed


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Simplecode-owned Ponytail survey: declared shortcuts and structural slop."
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--gate", action="store_true",
                        help="Block on unmanaged shortcuts or structural findings.")
    parser.add_argument("--include-tests", action="store_true")
    parser.add_argument("--tombstones", action="store_true")
    parser.add_argument("--gain", metavar="BASE",
                        help="Print literal Git line changes from BASE; never estimates savings.")
    args = parser.parse_args(argv)
    root = args.root.resolve()
    if args.gain:
        stats = _git_numstat(root, args.gain)
        if stats is None:
            print(f"[ponytail] COULD_NOT_RUN: git diff --numstat {args.gain}")
            return 2
        print(f"[ponytail] measured git diff {args.gain}..HEAD: added={stats[0]} removed={stats[1]}")
    debt_argv = ["--root", str(root)] + (["--gate"] if args.gate else [])
    debt_rc = ponytail_debt.main(debt_argv)
    hunt_argv = ["--root", str(root)]
    if args.gate:
        hunt_argv.append("--gate")
    if args.include_tests:
        hunt_argv.append("--include-tests")
    if args.tombstones:
        hunt_argv.append("--tombstones")
    hunt_rc = orphan_hunter.main(hunt_argv)
    return 0 if debt_rc == 0 and hunt_rc == 0 else 1
