"""Route a staged change to harness-neutral engineering checks.

The router records what the repository can prove from the staged diff.  It does
not pretend that a prose review happened: a receipt names required flows and
the evidence source that selected them, so every harness receives the same
instruction before a commit is created.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from simplecode.utils.tool_limits import GIT_O1_TIMEOUT
from simplecode.utils import atomic_io
from simplecode import profiles

RECEIPT = Path(".simplecode/evidence/workflow_receipt.json")
SENSITIVE_PARTS = ("auth", "security", "secret", "credential", "mcp", "network", "payment", "persist", "infra", "deploy")
CONTEXT_NAMES = {"AGENTS.md", "CLAUDE.md", "CONTEXT.md", "README.md", "SPEC.md"}


def staged_paths(root: Path) -> list[str] | None:
    try:
        result = subprocess.run(["git", "diff", "--no-relative", "--cached", "--name-only"], cwd=root,
                                text=True, capture_output=True, check=True,
                                timeout=GIT_O1_TIMEOUT)
    except (OSError, subprocess.SubprocessError):
        return None
    return [line for line in result.stdout.splitlines() if line]


def classify(paths: list[str], message: str = "") -> list[str]:
    """Return the minimum applicable flows; `review` covers every code change."""
    lower = [path.lower() for path in paths]
    flows: set[str] = set()
    if any(path.endswith((".py", ".js", ".ts", ".go", ".rs")) for path in lower):
        flows.update({"review", "ponytail", "debt"})
    if any("test" in path for path in lower) or message.lower().startswith(("fix", "feat")):
        flows.add("tdd")
    if message.lower().startswith(("fix", "revert")):
        flows.add("diagnose")
    if any(Path(path).name in CONTEXT_NAMES for path in paths):
        flows.add("context")
    if any(part in path for path in lower for part in SENSITIVE_PARTS):
        flows.add("security")
    return sorted(flows)


def write_receipt(root: Path, paths: list[str], message: str) -> Path:
    raw = "\n".join(paths).encode("utf-8")
    payload = {
        "schema": 1,
        "staged_paths_sha256": hashlib.sha256(raw).hexdigest(),
        "staged_paths": paths,
        "flows": classify(paths, message),
        "selection_evidence": "git diff --cached --name-only",
        "commands": [{
            "command": "git diff --cached --name-only",
            "result": "passed",
            "evidence": "staged_paths",
        }],
        "could_not_run": [],
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    destination = root / RECEIPT
    destination.parent.mkdir(parents=True, exist_ok=True)
    atomic_io.write_text_durable(
        destination,
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return destination


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--message-file", type=Path)
    args = parser.parse_args(argv)
    root = args.root.resolve()
    active, error = profiles.enabled(root, "workflow")
    if error:
        print(f"[workflow-router] COULD_NOT_RUN: {error}")
        return 2
    if not active:
        print("[workflow-router] workflow profile disabled")
        return 0
    message = ""
    if args.message_file:
        try:
            message = args.message_file.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            print(f"[workflow-router] COULD_NOT_RUN: {exc}")
            return 2
    paths = staged_paths(root)
    if paths is None:
        print("[workflow-router] COULD_NOT_RUN: git diff --cached --name-only")
        return 2
    destination = write_receipt(root, paths, message)
    flows = classify(paths, message)
    print(f"[workflow-router] flows={','.join(flows) if flows else 'none'} receipt={destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
