"""close_check_trace.py -- what a closed ficha's close_check actually READ, observed, not guessed.

DEBT-BACKLOG-VERIFIER-INCREMENTAL-MODE-20261006. `backlog_verifier` may reuse a close_check's
last PASS only while every input of that PASS is unchanged. A ficha's prose cannot list those
inputs (audit B1, 2026-09-29: a test importing an UNCITED helper module stayed cached after the
helper broke), and hashing every `.py` in the repo invalidated every entry on any commit
(measured 2026-10-06 in office2office: a one-line comment edit to one test file, then a version
bump of `pyproject.toml`, each dropped all 393 recorded PASSes).

So the inputs are OBSERVED. A Python close_check runs with this file installed as its
`sitecustomize` (via PYTHONPATH, inherited by every Python child it spawns). A CPython audit hook
records each file the process opens and each directory it lists, a wrapper on `os.stat`/
`os.lstat` records each existence probe, and at exit every module in `sys.modules` is added (an
import served from `__pycache__` never opens its `.py`). Each input is recorded with the value
the process SAW (content digest, listing digest, existence) at its first use, so a file rewritten
while the command ran is sealed as what the command read, not as what it became. The next run
reuses the PASS only if every input still has that value.

Inputs inside the repo are kept repo-relative; inputs outside it (another repo, an editable
install's source) are kept absolute and sealed the same way. The interpreter, its installed
packages, scratch space and the OS are the ENVIRONMENT: not recorded file by file; the parent
seals their identity instead (launcher, executables, installed-distribution names).

A non-Python child that the repo's own code starts INSIDE the repo (`git log` reads history, `tar`
reads the tree) is invisible too; such a PASS is REPO-BOUND: `backlog_verifier` reuses it only
while the whole repo is the same snapshot (HEAD, a clean tree, every ref).

What CANNOT be observed makes the PASS UNSEALABLE -- it re-executes on every run, which is what
a ficha that "reads files it does not name" must do:
  * a non-Python command (ruff, make, bash): an audit hook cannot see its reads;
  * network access; `os.system`/`os.exec*`/`os.spawn*`/`posix_spawn`;
  * a child Python stripped of the tracer (`-I`/`-E`/`-S`, or an `env=` without it);
  * two processes that saw different contents of the same input;
  * a command that read no repo file at all (DEBT-AEQUITAS-09: an external-state check has
    nothing that could ever invalidate it).
Declared limit, not handled here: the CLOCK. A verdict that depends on today's date with no file
changing can go stale; `backlog_verifier` bounds that with a maximum entry age.

Everything above `# --- parent side ---` runs INSIDE the close_check's interpreter: stdlib only,
importable without side effects, and this module's own source is what `write_site` writes out
as `sitecustomize.py`.
"""
from __future__ import annotations

import atexit
import hashlib
import json
import os
import sys
from collections.abc import Callable, Mapping

TRACE_DIR_ENV = "SIMPLECODE_CLOSE_CHECK_TRACE_DIR"
TRACE_ROOT_ENV = "SIMPLECODE_CLOSE_CHECK_TRACE_ROOT"
MISSING = "<missing>"
# Present in every copy of this module's source (`write_site` writes the source out whole), so a
# stale copy left on PYTHONPATH is recognised by what it IS, not by being in the current stack.
_TRACER_MARKER = "simplecode-close-check-tracer"

# Paths inside the repo that are not inputs of a verdict: git's own store, the interpreter
# (its identity is sealed separately) and tool caches.
_EXCLUDED_TOP = (".git", ".venv", ".pytest_cache", ".ruff_cache", ".mypy_cache")
_DIST_SUFFIXES = (".dist-info", ".egg-info", ".egg-link", ".pth")
_NETWORK_EVENTS = ("socket.connect", "socket.getaddrinfo", "socket.sendto", "urllib.Request")
_SPAWN_EVENTS = ("os.system", "os.exec", "os.posix_spawn", "os.spawn", "os.startfile")
# Interpreter flags that skip sitecustomize or PYTHONPATH: a child run with them is not traced.
_UNTRACED_FLAGS = frozenset({"-I", "-E", "-S"})


def file_digest(path: str) -> str:
    """sha256 of a file's bytes, `MISSING` when it cannot be read (absent is a value too)."""
    try:
        with open(path, "rb") as handle:
            return hashlib.sha256(handle.read()).hexdigest()
    except OSError:
        return MISSING


def names_digest(path: str, suffixes: tuple[str, ...] = ()) -> str:
    """sha256 of a directory's sorted entry names (only those ending in `suffixes`, if given)."""
    try:
        names = os.listdir(path)
    except OSError:
        return MISSING
    kept = sorted(n for n in names if not suffixes or n.endswith(suffixes))
    return hashlib.sha256("\n".join(kept).encode("utf-8", "surrogateescape")).hexdigest()


class Recorder:
    """The in-process half: turns audit events into the inputs of one process, each with the
    value this process saw at its first use."""

    def __init__(self, root: str, cwd: str, allowed_outside: tuple[str, ...]) -> None:
        self.root = root.rstrip(os.sep) or os.sep
        self.cwd = cwd
        self.allowed_outside = tuple(os.path.realpath(p) for p in allowed_outside)
        self.reads: dict[str, str] = {}
        self.listings: dict[str, str] = {}
        self.dist_listings: dict[str, str] = {}
        self.stats: dict[str, bool] = {}
        self.pyproject_config = False
        # True when pytest was handed only explicit test FILES: its collector then walks the
        # directories on the way to them but collects nothing else, so a new sibling test file
        # is not an input (`explicit_files_only`).
        self.pytest_files_only = False
        self.unsealable: set[str] = set()
        # Non-Python children the repo's own code ran INSIDE the repo (a VCS log, a tar of the
        # tree): their reads are invisible, so the PASS holds only while the repo snapshot holds.
        self.repo_bound: set[str] = set()
        self.busy = False
        # Set by `install`: every first observation is written to this process's log at once, so
        # a process killed or ended by os._exit has already recorded all it read.
        self.sink: Callable[[dict], None] | None = None

    def _emit(self, line: dict) -> None:
        if self.sink is not None:
            self.sink(line)

    def _observe(self, kind: str, key: str, value: object) -> None:
        getattr(self, kind)[key] = value
        self._emit({"k": kind, "p": key, "v": value})

    def _flag(self, kind: str, message: str) -> None:
        if message not in getattr(self, kind):
            getattr(self, kind).add(message)
            self._emit({"k": kind, "m": message})

    def _abs(self, path: object) -> str | None:
        if isinstance(path, int) or path is None:
            return None  # a file descriptor: the file was recorded when it was opened
        return os.path.normpath(os.path.join(self.cwd, os.fsdecode(path)))  # type: ignore[arg-type]  # sunset-reviewed: 9.7 -- path arrives from an audit hook typed object; int and None return above and os.fsdecode raises on any other non-path type

    def rel(self, path: object) -> str | None:
        """Repo-relative path; '' when outside the repo; None when excluded or not a path."""
        absolute = self._abs(path)
        if absolute is None:
            return None
        if absolute != self.root and not absolute.startswith(self.root + os.sep):
            return ""
        relative = os.path.relpath(absolute, self.root)
        return None if relative.split(os.sep)[0] in _EXCLUDED_TOP else relative

    def key(self, path: object, *, map_cache: bool = True) -> str | None:
        """How an input is sealed: repo-relative, absolute when outside, None when not an input.

        `pkg/__pycache__/mod.cpython-311.pyc` is `pkg/mod.py` served from cache (`map_cache`);
        a cache path is never an input of its own.
        """
        absolute = self._abs(path)
        if absolute is None:
            return None
        head, name = os.path.split(absolute)
        if os.path.basename(head) == "__pycache__":
            if not map_cache:
                return None
            absolute = os.path.join(os.path.dirname(head), name.split(".")[0] + ".py")
        elif name == "__pycache__":
            return None
        relative = self.rel(absolute)
        if relative != "":
            return relative
        real = os.path.realpath(absolute)
        if any(real == p or real.startswith(p.rstrip(os.sep) + os.sep) for p in self.allowed_outside):
            return None
        return absolute

    def path_of(self, key: str) -> str:
        return os.path.join(self.root, key)  # an absolute key stays absolute

    def on_open(self, path: object, mode: object, flags: object, reader: str) -> None:
        if isinstance(mode, str):
            is_read = "r" in mode or "+" in mode
        else:
            is_read = isinstance(flags, int) and (flags & os.O_ACCMODE) != os.O_WRONLY
        key = self.key(path)
        if key is None or not is_read:
            return
        if key == "pyproject.toml" and f"{os.sep}_pytest{os.sep}" in reader:
            # pytest's own config loader consumes only [tool.pytest.ini_options]; sealing the
            # whole file would let every version bump drop every pytest PASS.
            if not self.pyproject_config:
                self.pyproject_config = True
                self._emit({"k": "pyproject_config"})
        elif key not in self.reads:
            self._observe("reads", key, file_digest(self.path_of(key)))

    def on_listing(self, path: object, frames: list[str]) -> None:
        reader = _reader(frames)
        if reader.startswith("<frozen importlib"):
            return  # the import system probing sys.path: imports are recorded as reads
        if f"{os.sep}_pytest{os.sep}" in reader and self.pytest_files_only:
            return
        key = self.key("." if path is None else path, map_cache=False)
        if key is None:
            return
        if any(f"importlib{os.sep}metadata" in f for f in frames):
            # distribution discovery reads only the *.dist-info / *.egg-info names
            if key not in self.dist_listings:
                self._observe("dist_listings", key, names_digest(self.path_of(key), _DIST_SUFFIXES))
        elif key not in self.listings:
            self._observe("listings", key, names_digest(self.path_of(key)))

    def on_stat(self, path: object) -> None:
        if self.busy:
            return
        relative = self.rel(path)
        if not relative or relative in self.stats or "__pycache__" in relative.split(os.sep):
            return
        self.busy = True  # os.path.exists goes through the very wrapper that called us
        try:
            self._observe("stats", relative, os.path.exists(self.path_of(relative)))
        finally:
            self.busy = False

    def on_spawn(self, executable: str | bytes | None, args: object, cwd: object, env: object, by_repo: bool) -> None:
        """A Python child traces itself unless stripped of the tracer. A non-Python child cannot
        be traced: refused when the repo's own code starts it inside the repo. One started by an
        installed library alone (pytest-benchmark asks the VCS for a label at every startup) is
        part of the environment -- declared, not sealed."""
        argv = [args] if isinstance(args, (str, bytes)) else list(args or [])  # type: ignore[call-overload]  # sunset-reviewed: 9.7 -- args arrives from the audit hook typed object; the str/bytes case is the first branch of this expression
        argv = [os.fsdecode(a) for a in argv]
        program = os.path.basename(os.fsdecode(executable) if executable else (argv[0] if argv else ""))
        if program.startswith("python"):
            if env is not None and TRACE_DIR_ENV not in env:  # type: ignore[operator]  # sunset-reviewed: 9.7 -- env arrives from the subprocess.Popen audit event typed object; CPython documents it as a mapping or None
                self._flag("unsealable", f"child Python started with an env= that drops the tracer: {program}")
            elif _UNTRACED_FLAGS.intersection(argv[1:]):
                self._flag("unsealable", f"child Python runs with a flag that skips the tracer: {argv}")
            return
        if not by_repo:
            return
        workdir = self._abs(cwd) or self.cwd
        if program == "git":
            workdir = _git_workdir(argv[1:], workdir)
        if self.inside(workdir):
            self._flag("repo_bound", f"non-Python child runs inside the repo, its reads are invisible: {program}")
        elif any(self.inside(v) for a in argv[1:] for v in (a, a.partition("=")[2]) if os.path.isabs(v)):
            self._flag("repo_bound", f"non-Python child is handed a path inside the repo: {program}")

    def inside(self, path: str) -> bool:
        """Under the repo root, `.git` and `.venv` included: a child reading those reads repo state."""
        absolute = os.path.normpath(os.path.join(self.cwd, path))
        return absolute == self.root or absolute.startswith(self.root + os.sep)

    def on_event(self, event: str, args: tuple) -> None:
        if event == "open":
            self.on_open(args[0], args[1], args[2], _reader(list(_frames())))
        elif event in ("os.listdir", "os.scandir"):
            self.on_listing(args[0], list(_frames()))
        elif event == "os.chdir":
            self.cwd = self._abs(args[0]) or self.cwd
        elif event == "subprocess.Popen":
            self.on_spawn(*args[:4], by_repo=any(self.rel(f) for f in _frames() if os.path.isabs(f)))
        elif event == "sqlite3.connect":
            self.on_open(args[0], "r", None, "")
        elif event in _NETWORK_EVENTS:
            self._flag("unsealable", f"network access: {event}")
        elif event.startswith(_SPAWN_EVENTS):
            self._flag("unsealable", f"process replaced or spawned outside subprocess: {event}")

    def add_loaded_modules(self, modules: dict) -> None:
        for module in list(modules.values()):
            key = self.key(getattr(module, "__file__", None))
            if key and key not in self.reads:
                self._observe("reads", key, file_digest(self.path_of(key)))

    def header(self) -> dict:
        """First line of every process log: who it is and which interpreter it ran."""
        return {
            "k": "start",
            "ppid": os.getppid(),
            "executable": sys.executable,
            "site": sorted({p for p in sys.path if p.endswith(("site-packages", "dist-packages"))}),
        }


def _git_workdir(args: list[str], cwd: str) -> str:
    """Where `git <global options> <command>` works: each `-C <dir>` BEFORE the command moves it.

    169 in-repo spawns of one test file were `git -C <tmp fixture> ...` started from the repo's
    cwd (measured 2026-10-06); they read the fixture, not the repo. A `-C` after the command is
    that command's own flag (`git commit -C <rev>`), never a directory.
    """
    workdir, index = cwd, 0
    while index < len(args) and args[index].startswith("-"):
        if args[index] == "-C" and index + 1 < len(args):
            workdir = os.path.normpath(os.path.join(workdir, args[index + 1]))
            index += 1
        elif args[index] in ("-c", "--git-dir", "--work-tree", "--namespace") and index + 1 < len(args):
            index += 1
        index += 1
    return workdir


def _frames():
    """Code file of every frame above the audited call, innermost first."""
    frame = sys._getframe(1)
    while frame is not None:
        yield frame.f_code.co_filename
        frame = frame.f_back


def _reader(frames: list[str]) -> str:
    """File of the first frame above the audited call that is neither the tracer nor the stdlib.

    Tells pytest's config loader reading `pyproject.toml` apart from a test reading it, and the
    import system listing `sys.path` apart from code enumerating a directory.
    """
    stdlib = os.path.dirname(os.__file__)
    for filename in frames:
        if filename.startswith("<frozen importlib") or not (
            filename == __file__ or filename.startswith((stdlib, "<frozen"))
        ):
            return filename
    return ""


def _log_sink(path: str):
    """Append-only line writer for one process's log, or None when it cannot be opened (a
    detached grandchild outliving the trace directory: it must stay silent, since an exception
    here would print 'Error in sitecustomize' into the close_check's own output). One os.write
    per line on an O_APPEND descriptor: a kill lands between lines, never inside one."""
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    except OSError:
        return None

    def sink(line: dict) -> None:
        try:
            os.write(fd, (json.dumps(line) + "\n").encode("utf-8", "surrogateescape"))
        except OSError:
            pass

    return sink


def install(recorder: Recorder, trace_dir: str, *, add_audit_hook=sys.addaudithook,
            register_atexit=atexit.register, register_at_fork=os.register_at_fork) -> None:
    """Start recording this process into `<trace_dir>/<pid>.log`: its header now, each input at
    its first use, the modules still loaded at exit (an import served from cache)."""
    state = {"recorder": recorder}

    def start(current: Recorder) -> None:
        current.sink = _log_sink(os.path.join(trace_dir, f"{os.getpid()}.log"))
        current._emit(current.header())

    def hook(event: str, args: tuple) -> None:
        current = state["recorder"]
        if current.busy:
            return
        current.busy = True
        try:
            current.on_event(event, args)
        finally:
            current.busy = False

    def wrap(real):
        def traced(path, *args, **kwargs):
            state["recorder"].on_stat(path)
            return real(path, *args, **kwargs)
        return traced

    def finish() -> None:
        current = state["recorder"]
        current.busy = True
        current.add_loaded_modules(sys.modules)

    def forked() -> None:
        state["recorder"] = Recorder(recorder.root, recorder.cwd, recorder.allowed_outside)
        start(state["recorder"])

    start(recorder)
    os.stat, os.lstat = wrap(os.stat), wrap(os.lstat)
    add_audit_hook(hook)
    register_atexit(finish)
    register_at_fork(after_in_child=forked)


def _allowed_outside() -> tuple[str, ...]:
    """Reads outside the repo that are the interpreter, its installed packages (their set is
    sealed by `header()["site"]`), scratch space or the OS -- not repo inputs."""
    import site
    import tempfile

    prefixes = {sys.prefix, sys.base_prefix, sys.exec_prefix, tempfile.gettempdir(),
                "/dev", "/proc", "/sys", "/etc", "/usr", site.getusersitepackages(),
                *site.getsitepackages(), *(p for p in sys.path if p.endswith(("site-packages", "dist-packages")))}
    return tuple(sorted(prefixes))


def explicit_files_only(args: list[str], cwd: str) -> bool:
    """True when the positional arguments that exist on disk are all files (pytest `a.py::t`)."""
    existing = [path for path in (os.path.join(cwd, a.split("::")[0]) for a in args if not a.startswith("-"))
                if os.path.exists(path)]
    return bool(existing) and all(os.path.isfile(path) for path in existing)


def _stack(environ: Mapping[str, str]) -> list[tuple[str, str]]:
    """Every (trace dir, root) asking for this process: one per backlog_verifier above it.

    A traced close_check may itself run backlog_verifier (its own test suite does), whose
    close_checks are then traced for BOTH verifiers -- each one records into its own directory.
    """
    dirs = [d for d in environ.get(TRACE_DIR_ENV, "").split(os.pathsep) if d]
    roots = [r for r in environ.get(TRACE_ROOT_ENV, "").split(os.pathsep) if r]
    return list(zip(dirs, roots))


def main(environ: Mapping[str, str] | None = None, argv: list[str] | None = None) -> bool:
    """sitecustomize entry: trace only when a parent asked for it, once per asking parent."""
    environ = os.environ if environ is None else environ
    stack = _stack(environ)
    for trace_dir, root in stack:
        recorder = Recorder(root, os.getcwd(), _allowed_outside())
        recorder.pytest_files_only = explicit_files_only((sys.argv if argv is None else argv)[1:], recorder.cwd)
        install(recorder, trace_dir)
    return bool(stack)


def _is_tracer_copy(directory: str) -> bool:
    """True when `<directory>/sitecustomize.py` is a copy of this tracer, even one whose trace
    dir is no longer listed: chained into, it would run `main()` again and install a second
    Recorder for the same trace dir, writing a second header into the same log."""
    try:
        with open(os.path.join(directory or ".", "sitecustomize.py"), encoding="utf-8", errors="replace") as handle:
            return _TRACER_MARKER in handle.read()
    except OSError:
        return False


def chain_real_sitecustomize(path: list, here: str, environ: Mapping[str, str] | None = None) -> bool:
    """Run the interpreter's own sitecustomize that this one shadows (Debian ships one).

    Executed as a fresh module object, never through `sys.modules`: removing this module from
    `sys.modules` while its own import is in progress makes the import system raise
    KeyError('sitecustomize'), which `site` prints to stderr in every traced process -- five
    close_checks comparing stderr went red that way on 2026-10-06.
    """
    import importlib.machinery
    import importlib.util

    environ = os.environ if environ is None else environ
    ours = {here, *(os.path.join(d, "site") for d, _root in _stack(environ))}
    rest = [p for p in path if os.path.abspath(p or ".") not in ours and not _is_tracer_copy(p)]
    spec = importlib.machinery.PathFinder.find_spec("sitecustomize", rest)
    if spec is None or spec.loader is None:
        return False
    spec.loader.exec_module(importlib.util.module_from_spec(spec))
    return True


if __name__ == "sitecustomize":
    main()
    chain_real_sitecustomize(sys.path, os.path.dirname(os.path.abspath(__file__)))


# --- parent side: everything below runs in backlog_verifier, never in the close_check ---

# Variables that change what a Python close_check imports or how pytest runs, read from the
# environment the child inherits. PATH is NOT here: what it resolves to is sealed instead (the
# executable's identity), so two callers with different PATHs that launch the same interpreter
# share one entry instead of overwriting each other's (measured 2026-10-06: three callers, three
# contexts, on the same commit).
_SEALED_ENV = ("PYTHONPATH", "PYTHONHOME", "PYTEST_ADDOPTS", "PYTEST_PLUGINS",
               "PYTEST_DISABLE_PLUGIN_AUTOLOAD")
_OBSERVED = ("reads", "listings", "dist_listings", "stats")


def write_site(trace_dir) -> str:
    """Write this module as `<trace_dir>/site/sitecustomize.py`; returns that directory."""
    import inspect
    from pathlib import Path

    # Imported here, not at the top: this file is copied verbatim as a child's sitecustomize,
    # where `simplecode` need not be importable; only the verifier's own process calls this.
    from simplecode.utils.atomic_io import write_text_durable

    site = os.path.join(os.fspath(trace_dir), "site")
    os.makedirs(site, exist_ok=True)
    write_text_durable(Path(site) / "sitecustomize.py", inspect.getsource(sys.modules[__name__]))
    return site


def traced_env(base_env: Mapping[str, str], trace_dir, root) -> dict:
    """`base_env` plus what the child needs to trace itself into `trace_dir`, stacked on any
    tracer already asking (`_stack`): one sitecustomize on PYTHONPATH, every directory listed."""
    env = dict(base_env)
    stack = [*_stack(base_env), (os.fspath(trace_dir), os.fspath(root))]
    earlier = {os.path.join(d, "site") for d, _root in stack[:-1]}
    kept = [p for p in base_env.get("PYTHONPATH", "").split(os.pathsep) if p and p not in earlier]
    env["PYTHONPATH"] = os.pathsep.join([write_site(trace_dir), *kept])
    env[TRACE_DIR_ENV] = os.pathsep.join(d for d, _root in stack)
    env[TRACE_ROOT_ENV] = os.pathsep.join(r for _dir, r in stack)
    return env


def collect(trace_dir, parent_pid: int) -> tuple[dict | None, str | None]:
    """Every traced process's observed inputs, merged, or `(None, reason)` when they cannot be
    sealed. Observed values stay attached (`seal` digests them); `keys_only` is what is stored."""
    import glob

    logs = sorted(glob.glob(os.path.join(os.fspath(trace_dir), "*.log")))
    if not logs:
        return None, "not a traced Python process: its reads cannot be observed"
    inputs: dict = {**{name: {} for name in _OBSERVED}, "pyproject_config": False,
                    "executables": set(), "site": set(), "repo_bound": set()}
    top_seen = False
    for log in logs:
        lines = _read_log(log)
        if isinstance(lines, str):
            return None, lines
        top_seen = top_seen or lines[0]["ppid"] == parent_pid
        inputs["executables"].add(lines[0]["executable"])
        inputs["site"].update(lines[0]["site"])
        for line in lines[1:]:
            refusal = _merge_line(inputs, line)
            if refusal is not None:
                return None, refusal
    if not top_seen:
        return None, "the command's own process was not traced: only its children were"
    if not inputs["repo_bound"] and all(os.path.isabs(path) for path in [*inputs["reads"], *inputs["listings"]]):
        return None, "read no file of this repo: nothing could ever invalidate its PASS"
    for name in ("executables", "site", "repo_bound"):
        inputs[name] = sorted(inputs[name])
    return inputs, None


def _read_log(path: str) -> list[dict] | str:
    """A process log's lines, header first, or the reason it cannot be trusted."""
    try:
        with open(path, encoding="utf-8", errors="surrogateescape") as handle:
            lines = [json.loads(text) for text in handle.read().splitlines()]
    except (OSError, ValueError):
        return f"a trace log could not be read: {os.path.basename(path)}"
    if not lines or lines[0].get("k") != "start":
        return f"a traced process left no header: {os.path.basename(path)}"
    return lines


def _merge_line(inputs: dict, line: dict) -> str | None:
    """Fold one observation into `inputs`; the refusal it carries, if any."""
    kind = line["k"]
    if kind == "unsealable":
        return line["m"]
    if kind == "repo_bound":
        inputs["repo_bound"].add(line["m"])
    elif kind == "pyproject_config":
        inputs["pyproject_config"] = True
    elif kind not in _OBSERVED:  # a second `start` header, or a kind from another version
        return f"a trace log holds a line of an unknown kind: {kind}"
    elif inputs[kind].setdefault(line["p"], line["v"]) != line["v"]:
        return f"an input changed while the command ran: {line['p']}"
    return None


def drop_transient_stats(root, inputs: dict) -> dict:
    """Existence probes whose answer flipped while the command ran are the run's own scratch.

    pytest creates `pytest-cache-files-XXXX` in the repo, probes it and renames it away; sealing
    that probe made every pytest PASS unverifiable (measured 2026-10-06). A probe whose path
    exists after the run exactly as it did when probed is kept, absence included -- the case that
    matters (a test asserting a retired file stays gone).
    """
    root = os.fspath(root)
    inputs["stats"] = {key: seen for key, seen in inputs["stats"].items()
                       if os.path.exists(os.path.join(root, key)) == seen}
    return inputs


def keys_only(inputs: dict) -> dict:
    """The stored form: which inputs, not their values (the seal already holds those)."""
    return {name: sorted(value) if name in _OBSERVED else value for name, value in inputs.items()}


def _pytest_table(root: str) -> object:
    import tomllib

    try:
        with open(os.path.join(root, "pyproject.toml"), "rb") as handle:
            return tomllib.load(handle).get("tool", {}).get("pytest", {})
    except (OSError, ValueError):
        return MISSING


def _executable_identity(path: str) -> list:
    real = os.path.realpath(path)
    try:
        status = os.stat(real)
    except OSError:
        return [real, MISSING]
    return [real, status.st_size, status.st_mtime_ns]


def seal(root, inputs: dict, launcher: str | None, environ: Mapping[str, str], memo: dict) -> str:
    """One digest over every input `inputs` names.

    An input given with its OBSERVED value (`collect`'s dicts) is digested as observed; one given
    by name only (`keys_only`'s lists, the stored form) is read from disk NOW. Recording uses the
    first, validating the next run uses the second: equal digests mean every input still has the
    value the PASS saw. `launcher` is what argv[0] resolves to; `environ` is what the command
    would inherit. `memo` spares re-reading a file many fichas share within one run.
    """
    root = os.fspath(root)

    def current(name: str, key: str) -> object:
        path = os.path.join(root, key)
        if name == "reads":
            if path not in memo:
                memo[path] = file_digest(path)
            return memo[path]
        if name == "stats":
            return os.path.exists(path)
        return names_digest(path, _DIST_SUFFIXES if name == "dist_listings" else ())

    payload: dict[str, object] = {
        name: [[key, inputs[name][key] if isinstance(inputs[name], dict) else current(name, key)]
               for key in sorted(inputs[name])]
        for name in _OBSERVED
    }
    payload.update({
        "pytest_config": _pytest_table(root) if inputs["pyproject_config"] else None,
        "executables": [_executable_identity(p) for p in [launcher or MISSING, *inputs["executables"]]],
        "site": [[p, names_digest(p, _DIST_SUFFIXES)] for p in inputs["site"]],
        "env": [[name, environ.get(name)] for name in _SEALED_ENV],
    })
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
