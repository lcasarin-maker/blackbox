# -*- coding: utf-8 -*-
"""stage_fixed.py -- auto-`git add` files a pre-commit hook modified in place.

Rescued as a standalone mechanism from the Lefthook/prek comparison
(2026-08-31): Lefthook's `stage_fixed: true` re-stages a hook's own
auto-fixes so the commit that's about to happen actually includes them,
instead of leaving the developer to notice "files were modified by this
hook" and re-stage by hand. Neither pre-commit nor prek does this
natively.

Scoped to the pre-commit stage only -- pre-push has no notion of "about to
commit", so re-staging there would be meaningless. Wraps the REAL command
(gate_runner -> pre-commit/prek) as a subprocess rather than replacing it,
so this adds one thin layer, not a reimplementation of hook dispatch.

Also the only point in the whole pre-commit chain that runs BEFORE
`pre-commit run`'s own stash (`pre_commit.staged_files_only`): that stash
unconditionally does `git checkout -- .` before any hook sees the tree,
which resets disk to match the INDEX for every staged path -- silently
erasing any divergence between what's staged and what's on disk, then
restoring disk afterward so the working tree looks untouched. `git mv
<path> <newpath>` on a file already edited-but-not-restaged is the classic
trigger: `git mv` stages the rename with the OLD (pre-edit) blob, `git
status` shows it plainly (`RM`), but every hook -- including
`staged-parity`, whose entire job is to catch exactly this -- runs after
the checkout has already hidden it, sees a self-consistent tree, and
passes. The commit then carries the stale blob while the working tree
(restored by the same stash) still shows the edit, so nothing on screen
says anything is wrong. Reproduced 2026-09-30 on aequitas_os: two ficha
closures (`git mv tasks/backlog/*.md tasks/done/*.md` after editing the
file at its old path) landed with `status: open` and no Cierre section,
git's own summary line reading "rename ... (100%)" because the committed
blob really was byte-identical to the pre-edit one -- reproducible with
zero hooks involved, purely from `git mv` + `git commit`. `staged_parity`
already computes the right comparison; it is simply asked too late. This
module is the one seam that runs early enough to ask it in time.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from simplecode.worktree.staged_parity import GitUnavailable, get_divergent_staged_files


def snapshot_staged(root: Path) -> dict[str, str]:
    """relpath -> git blob sha of the CURRENTLY STAGED content, for every
    file with a staged change. Empty dict on any git failure -- fail-safe
    means "nothing to compare, so nothing gets auto-restaged", never a
    COULD_NOT_RUN for a step this thin."""
    result = subprocess.run(
        ["git", "diff", "--no-relative", "--cached", "--name-only", "-z"], cwd=root, capture_output=True, text=True, check=False
    )
    if result.returncode != 0:
        return {}
    snapshot: dict[str, str] = {}
    for relpath in (p for p in result.stdout.split("\0") if p):
        hashed = subprocess.run(["git", "hash-object", relpath], cwd=root, capture_output=True, text=True, check=False)
        if hashed.returncode == 0:
            snapshot[relpath] = hashed.stdout.strip()
    return snapshot


def restage_changed(root: Path, snapshot: dict[str, str]) -> list[str]:
    """`git add` every path in `snapshot` whose WORKING-TREE content hash no
    longer matches what was staged when the snapshot was taken -- a hook
    modified it in place. Returns the paths actually restaged, in
    snapshot order."""
    restaged: list[str] = []
    for relpath, staged_hash in snapshot.items():
        full_path = root / relpath
        if not full_path.is_file():
            continue
        current = subprocess.run(["git", "hash-object", relpath], cwd=root, capture_output=True, text=True, check=False)
        if current.returncode != 0 or current.stdout.strip() == staged_hash:
            continue
        added = subprocess.run(["git", "add", "--", relpath], cwd=root, capture_output=True, text=True, check=False)
        if added.returncode == 0:
            restaged.append(relpath)
    return restaged


def main(argv: list[str] | None = None) -> int:
    """Usage: stage_fixed [--root R] -- <command...>

    Checks, BEFORE the wrapped command runs, that no staged path already
    diverges from disk -- the wrapped command is `pre-commit run` (or
    `prek`), and its own stash will silently reset disk to the stale staged
    content, run every hook against that, then restore the edit afterward,
    so the commit carries the stale blob while nothing on screen looks
    wrong (see module docstring). This is the one point early enough to
    catch it: refuse before the wrapped command ever starts.

    Otherwise: snapshots staged files, runs `<command...>` as a real
    subprocess (inheriting stdio so its own output streams live), re-stages
    anything it changed, and propagates its exit code unchanged."""
    argv = sys.argv[1:] if argv is None else argv
    if "--" not in argv:
        print("[stage-fixed] COULD_NOT_RUN: usage: stage_fixed [--root R] -- <command...>", file=sys.stderr)
        return 2
    sep = argv.index("--")
    pre, command = argv[:sep], argv[sep + 1 :]
    if not command:
        print("[stage-fixed] COULD_NOT_RUN: no command given after --", file=sys.stderr)
        return 2

    root = Path(".").resolve()
    if "--root" in pre:
        root = Path(pre[pre.index("--root") + 1]).resolve()

    try:
        divergent = get_divergent_staged_files(root)
    except GitUnavailable as exc:
        print(f"[stage-fixed] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 1
    if divergent:
        print(
            f"[stage-fixed] FAIL: {len(divergent)} staged file(s) already differ from disk "
            f"before any hook ran; primero {divergent[0]}",
            file=sys.stderr,
        )
        for f in divergent:
            print(f"  - {f}", file=sys.stderr)
        print(
            "  The commit would NOT carry your working-tree content: pre-commit's own stash "
            "resets disk to this stale staged blob before any hook runs, then restores your "
            "edit to disk afterward, so the working tree looks fine while HEAD gets the stale "
            "content. Usual cause: `git mv <old> <new>` on a file you had already edited but "
            "not yet re-added. `git add <file>` to take the new content, or `git restore "
            "<file>` to keep what's staged -- then re-commit.",
            file=sys.stderr,
        )
        return 1

    snapshot = snapshot_staged(root)
    result = subprocess.run(command, cwd=root, check=False)
    restaged = restage_changed(root, snapshot)
    if restaged:
        print(f"[stage-fixed] re-staged {len(restaged)} file(s) a hook modified: {', '.join(restaged)}")
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
