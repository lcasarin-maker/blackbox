"""Bounded deterministic repair loop for the local Python tree.

The loop only runs Ruff's existing fixers, then runs their read-only checks.
It stops when a round makes no change and fails when the fixer keeps changing
the tree past a small bound.  This gives ``simplecode fix`` a critic pass
without allowing an agent or an unbounded formatter loop to rewrite a repo.
"""

from __future__ import annotations

import argparse
import logging
import subprocess
from collections.abc import Callable
from pathlib import Path

from simplecode.utils.tool_limits import GIT_SCAN_TIMEOUT

FIX_SELECT = "E9,F401,F632,F811"
CommandRunner = Callable[[list[str], Path], int]
logger = logging.getLogger(__name__)


def _snapshot(root: Path) -> dict[Path, bytes]:
    """Return Python source bytes, excluding generated and dependency trees."""
    ignored = {".git", ".venv", ".simplecode", "__pycache__"}
    result: dict[Path, bytes] = {}
    for path in (*root.rglob("*.py"), *root.rglob("*.pyi")):
        if ignored.intersection(path.parts):
            continue
        try:
            result[path.relative_to(root)] = path.read_bytes()
        except OSError as exc:
            logger.warning("[autofix] could not snapshot %s: %s", path, exc)
            continue
    return result


def _run(command: list[str], root: Path) -> int:
    return subprocess.run(command, cwd=root, check=False).returncode


def _changed_python_paths(root: Path) -> tuple[str, ...]:
    """Return changed Python paths; never widen a fix to the whole repository."""
    commands = [
        ["git", "diff", "--no-relative", "--name-only", "--diff-filter=ACM"],
        ["git", "diff", "--no-relative", "--cached", "--name-only", "--diff-filter=ACM"],
        ["git", "ls-files", "--others", "--exclude-standard"],
    ]
    names: set[str] = set()
    for command in commands:
        try:
            result = subprocess.run(
                command, cwd=root, capture_output=True, text=True, check=False,
                timeout=GIT_SCAN_TIMEOUT,
            )
        except (OSError, subprocess.SubprocessError):
            return ()
        if result.returncode != 0:
            return ()
        names.update(line.strip() for line in result.stdout.splitlines() if line.strip())
    return tuple(sorted(name for name in names if name.endswith((".py", ".pyi"))))


def _targets(root: Path, paths: tuple[str, ...] | None) -> tuple[str, ...]:
    selected = paths if paths is not None else _changed_python_paths(root)
    result: list[str] = []
    for raw in selected:
        path = Path(raw)
        try:
            candidate = path if path.is_absolute() else root / path
            relative = candidate.resolve().relative_to(root.resolve())
        except ValueError:
            raise ValueError(f"path outside repository: {raw}") from None
        if relative.suffix in (".py", ".pyi") and (root / relative).is_file():
            result.append(relative.as_posix())
    return tuple(dict.fromkeys(result))


def run_fix_loop(
    root: Path,
    max_rounds: int = 3,
    paths: tuple[str, ...] | None = None,
    runner: CommandRunner = _run,
) -> int:
    """Apply Ruff fixes until stable, then require clean read-only checks."""
    if max_rounds < 1:
        print("[autofix] FAIL: --max-rounds must be at least 1")
        return 1
    try:
        targets = _targets(root, paths)
    except ValueError as exc:
        print(f"[autofix] FAIL: {exc}")
        return 1
    if not targets:
        print("[autofix] OK: no changed Python files")
        return 0

    fixer_commands = [["ruff", "check", "--fix", "--select", FIX_SELECT, *targets]]
    check_commands = [["ruff", "check", "--select", FIX_SELECT, *targets]]

    for round_number in range(1, max_rounds + 1):
        before = _snapshot(root)
        for command in fixer_commands:
            if runner(command, root) != 0:
                print(f"[autofix] FAIL: {' '.join(command)}")
                return 1
        changed = before != _snapshot(root)
        print(f"[autofix] round={round_number} changed={'yes' if changed else 'no'}")
        if not changed:
            break
    else:
        print(f"[autofix] FAIL: fixer did not converge in {max_rounds} rounds")
        return 1

    for command in check_commands:
        if runner(command, root) != 0:
            print(f"[autofix] FAIL: critic {' '.join(command)}")
            return 1
    print("[autofix] OK: tree stable and critic checks passed")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-rounds", type=int, default=3)
    parser.add_argument("paths", nargs="*", help="Python files; default: changed files only")
    args = parser.parse_args(argv)
    paths = tuple(args.paths) if args.paths else None
    return run_fix_loop(args.root.resolve(), args.max_rounds, paths=paths)


if __name__ == "__main__":
    raise SystemExit(main())
