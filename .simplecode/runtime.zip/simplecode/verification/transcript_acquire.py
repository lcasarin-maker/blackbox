#!/usr/bin/env python3
"""transcript_acquire.py - Turns a session transcript .jsonl file into (turns, diagnostics).

Job clause: fails loud — corrupt, empty, missing, or directory input is
distinguishable from a genuinely quiet session; nothing is silently treated
as success.

# simplecode:corpus vocabulary for transcript acquisition - JSONL session parsing
"""

import json
import logging
import os
import sys

from simplecode.utils.tool_limits import HARVEST_SOURCE_FILE_MAX_BYTES

logger = logging.getLogger("transcript_acquire")
PATH_ARGUMENT_INDEX = 1


def _assistant_text_blocks(obj: dict) -> list:
    """Text of the 'text' blocks in an assistant message; [] if not an assistant message."""
    if obj.get("type") != "assistant":
        return []
    content = obj.get("message", {}).get("content")
    if not isinstance(content, list):
        return []
    return [
        b.get("text", "")
        for b in content
        if isinstance(b, dict) and b.get("type") == "text"
    ]


def _parse_jsonl_line(line: str):
    """Parses one transcript line; None if blank or not valid JSON (logged, not raised)."""
    line = line.strip()
    if not line:
        return None
    try:
        return json.loads(line)
    except json.JSONDecodeError as exc:
        logger.debug("non-JSON transcript line, skipped: %r", exc)
        return None


def _validate_content_block(block: dict, line_number: int) -> str | None:
    kind = block.get("type")
    if not isinstance(kind, str) or not kind:
        return f"assistant record has invalid content block type on line {line_number}"
    if kind == "text":
        valid = isinstance(block.get("text"), str)
    elif kind == "thinking":
        valid = isinstance(block.get("thinking"), str) and (
            "signature" not in block or isinstance(block["signature"], str)
        )
    elif kind == "redacted_thinking":
        valid = isinstance(block.get("data"), str)
    elif kind in {"tool_use", "server_tool_use"}:
        valid = all(isinstance(block.get(key), str) and block[key] for key in ("id", "name"))
        valid = valid and isinstance(block.get("input"), dict)
    else:
        return f"assistant record has unsupported content block {kind!r} on line {line_number}"
    return None if valid else f"assistant record has malformed {kind} block on line {line_number}"


def _valid_output_tokens(usage: dict, line_number: int) -> tuple[int | None, str | None]:
    output_tokens = usage.get("output_tokens", 0)
    if isinstance(output_tokens, bool) or not isinstance(output_tokens, int) or output_tokens < 0:
        return None, f"assistant record has invalid output token count on line {line_number}"
    return output_tokens, None


def _assistant_turn(obj: dict, line_number: int) -> tuple[tuple[int, str, int] | None, str | None]:
    """Validate and extract one assistant row; return its reason when malformed."""
    if obj.get("type") != "assistant":
        return None, None
    message = obj.get("message")
    if not isinstance(message, dict):
        return None, f"assistant record has invalid message on line {line_number}"
    content = message.get("content")
    usage = message.get("usage", {})
    if not isinstance(content, list) or not isinstance(usage, dict):
        return None, f"assistant record has invalid content/usage on line {line_number}"
    for block in content:
        if not isinstance(block, dict):
            return None, f"assistant record has invalid content block on line {line_number}"
        error = _validate_content_block(block, line_number)
        if error:
            return None, error
    output_tokens, error = _valid_output_tokens(usage, line_number)
    if error or output_tokens is None:
        return None, error or f"assistant record has invalid output token count on line {line_number}"
    return (line_number - 1, "\n".join(_assistant_text_blocks(obj)), output_tokens), None


def _transcript_row(obj, line_number: int):
    """Return (turn, error, compact-marker, is-object) for one decoded JSON value."""
    if not isinstance(obj, dict):
        return None, f"non-object JSONL record on line {line_number}", False, False
    turn, error = _assistant_turn(obj, line_number)
    return turn, error, bool(obj.get("isCompactSummary")), True


def _parse_transcript_line(line: str, line_number: int):
    """Return the validated row, error, compact marker, and malformed flag."""
    obj = _parse_jsonl_line(line)
    if obj is None:
        return None, None, False, bool(line.strip())
    turn, error, compact, is_object = _transcript_row(obj, line_number)
    return turn, error, compact, bool(error) or not is_object


def read_transcript(path: str) -> tuple[list[tuple[int, str, int]], dict[str, int | str]]:
    """(turns, diagnostics): turns = [(line_no, text, output_tokens)] over the WHOLE file; the
    leading diagnostics['turns_discarded_pre_compact'] of them precede the last compact marker."""
    lines_total = 0
    lines_unparseable = 0
    turns: list[tuple[int, str, int]] = []
    compact_at = -1

    # Axiom 10: refuse to read an arbitrarily large transcript whole into
    # memory. Loud skip-and-report, shaped like the existing files_unreadable
    # disposition so callers need no new branch to handle it.
    try:
        size = os.path.getsize(path)
    except OSError as exc:
        logger.warning("Could not stat transcript %s: %s", path, exc, exc_info=True)
        size = None
    if size is not None and size > HARVEST_SOURCE_FILE_MAX_BYTES:
        msg = f"oversize transcript: {size} bytes > {HARVEST_SOURCE_FILE_MAX_BYTES} byte cap"
        logger.warning("Skipping %s: %s", path, msg)
        return [], {
            "lines_total": 0,
            "lines_unparseable": 0,
            "files_unreadable": 1,
            "turns_discarded_pre_compact": 0,
            "error": msg,
        }

    try:  # the WHOLE acquisition is guarded — not just a stdin parse
        with open(path, encoding="utf-8") as fh:
            for idx, line in enumerate(fh):
                lines_total += 1
                turn, error, is_compact, malformed = _parse_transcript_line(line, idx + 1)
                if is_compact:
                    compact_at = idx
                if error:
                    logger.warning(error)
                if malformed:
                    lines_unparseable += 1
                if turn is not None:
                    turns.append(turn)
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        return [], {
            "lines_total": lines_total,
            "lines_unparseable": lines_unparseable,
            "files_unreadable": 1,
            "turns_discarded_pre_compact": 0,
            "error": f"{type(exc).__name__}: {exc}",
        }
    discarded = sum(1 for t in turns if t[0] < compact_at)
    return turns, {
        "lines_total": lines_total,
        "lines_unparseable": lines_unparseable,
        "files_unreadable": 0,
        "turns_discarded_pre_compact": discarded,
        "error": f"{lines_unparseable} unparseable JSONL line(s)" if lines_unparseable else "",
    }


def main() -> int:
    """0 = turns acquired cleanly · 20 = zero turns AND zero diagnostics · 30 = could_not_run."""
    if len(sys.argv) <= PATH_ARGUMENT_INDEX:
        print("[acquire] COULD NOT RUN: no telemetry path provided", file=sys.stderr)
        return 30
    path = sys.argv[PATH_ARGUMENT_INDEX]
    if not os.path.exists(path):
        print(f"[acquire] COULD NOT RUN: telemetry file not found at {path}", file=sys.stderr)
        return 30
    turns, diag = read_transcript(path)
    print(f"[acquire] turns={len(turns)} {diag}", file=sys.stderr)
    return 30 if diag["files_unreadable"] or diag["lines_unparseable"] else (0 if turns else 20)


if __name__ == "__main__":
    sys.exit(main())
