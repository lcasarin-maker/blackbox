# -*- coding: utf-8 -*-
"""Blocks a staged commit that moves a task ficha into `tasks/done/` on a
synthetic closure: a `close_check` that only verifies its own filing, or a
move with no source/test change behind it.

Measured incident (Atlas, 2026-09-06, commit `3e057605`, reverted by the
operator before push as `8c1954ea`): a swarm chasing "Ship Freeze" (zero open
backlog) closed 11 fichas by moving them to `tasks/done/` and rewriting their
`close_check.cmd` from a real command (`python -m tools.backlog_declara_cierre
DGX-96`) to `python3 -c "import os; assert os.path.exists('tasks/done/DGX-96.md')"`
-- a command that verifies the commit's own rename, not the fix the ficha
describes. No `evidence:` field was added either. The ficha carried a "Root
Cause" / "Regression Test" / "Verification Evidence" section, each one
generic, unfalsifiable prose ("Covered by automated test suite in tests/",
"Verified with pytest and quality gates passing 100% cleanly") naming no
artifact.

Why the existing gates did not catch it in time: `backlog_verifier`'s
`_validate_verification_cmd` already bans the `-c`/`-e` inline-execution form
this close_check used -- but only at PRE-PUSH, so an arbitrary number of
local commits can carry a synthetic closure before anyone or anything looks.
`ledger_schema`'s `evidence: {pass, fail, e2e}` requirement (which DGX-96 also
violated outright -- no `evidence:` field at all) is stronger, but a satellite
can retire the `ledger-schema` hook for reasons unrelated to fraud (Atlas did,
by a documented vote, over a backlog volume problem: DGX-475) and silently
lose this protection as a side effect. This module runs at PRE-COMMIT,
scoped only to what THIS commit stages (the same class as `zero-debt --staged`
and `corruption-guard --staged` beside it, never a repo-wide judgment -- a
repo-wide schema check running at pre-commit froze office2office solid on
128 pre-existing fichas, which is why `ledger-schema`/`backlog-verifier`
stay at pre-push; this gate cannot repeat that because it only ever looks at
the rename this commit makes), and it cannot be silently disabled by a vote
aimed at something else, because it is its own hook.

LIMITS, declared:
  - Detects a closure only when git resolves it as a RENAME (`-M`) from
    `tasks/{backlog,active,blocked}/*.md` to `tasks/done/*.md`. A closure
    that deletes the old path and adds an unrelated-looking new one below
    git's similarity threshold is not caught here -- not observed yet, and
    building for it before it happens is exactly the over-engineering this
    kit's own ladder rejects.
  - `close_check` is read as inline JSON on one line (`close_check: {"cmd":
    ..., "expect": ...}`) or the indented-block form; a `cmd:` this module's
    regexes cannot locate reports `COULD_NOT_DETERMINE_CLOSE_CHECK` rather
    than guessing pass or fail.
  - The substantive-change check is commit-wide, not per-ficha: one real
    source or test change anywhere in the staged diff satisfies every ficha
    the same commit closes. Requiring one per ficha was rejected as an
    unneeded restriction the reported requirement does not ask for.

A third `closure_type` (2026-09-07, prompted by a real case): `relocated_prior_verification`
-- a ficha whose `status: done` and real close_check were already committed and verified in
an EARLIER, separate commit, and this commit only corrects which `tasks/` subfolder it lives
in (a pure filesystem tidy-up, not a new closure). Considered and rejected: exempting any
staged rename git reports as byte-identical (`R100`, no content diff at all). That signal
looked sound but is NOT: `test_negative_case_synthetic_close_check_alone_is_blocked` (the
Atlas incident's own regression test) stages its fraud exactly the same way -- commit the
ficha once with the synthetic close_check already written in, then a bare `git mv` to
`tasks/done/` with zero further edits -- which git also reports as `R100`. The two cases are
INDISTINGUISHABLE by content-similarity alone; only a human declaring `relocated_prior_
verification` with a `reason:` (same trust model this module already accepts for
`void_wontfix`/`duplicate` -- an explicit, on-the-record claim, not an automatically-detected
one) tells them apart.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

from simplecode.guards.agent_threats import simulated_or_stub_implementation
from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.closure_types import EXEMPT_CLOSURE_TYPES
from simplecode.utils.tool_limits import GIT_O1_TIMEOUT
from simplecode.verification.backlog_verifier import _validate_verification_cmd

OPEN_DIR_RE = re.compile(r"^tasks/backlog/[^/]+\.md$")
DONE_DIR_RE = re.compile(r"^tasks/done/[^/]+\.md$")

# Extensions this gate accepts as "real code", alongside anything under tests/.
_SOURCE_EXTS = frozenset({
    ".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".java", ".rb", ".sh",
    ".c", ".cc", ".cpp", ".cs", ".kt", ".swift",
})

# La lista vive en simplecode.utils.closure_types: hasta el 2026-09-23 estaba
# escrita dos veces (aqui y en harvest_decision) unidas por una promesa en un
# docstring, que es como dos copias divergen.
_EXEMPT_CLOSURE_TYPES = EXEMPT_CLOSURE_TYPES


class GitUnavailable(RuntimeError):
    """The `git` subprocess itself could not be run (missing binary, timeout).

    Distinct from a plain non-zero returncode, which is an honest "nothing to
    report" from a git command that DID run -- this is the case where nothing
    about the commit was actually checked at all.
    """


def _run_git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            ["git", "-C", str(root), *args],
            capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GitUnavailable(f"git {' '.join(args)} could not be run: {exc}") from exc


def staged_closures(root: Path) -> list[tuple[str, str]]:
    """(old_path, new_path) for every staged rename landing in `tasks/done/`
    from an open task folder."""
    proc = _run_git(root, "diff", "--no-relative", "--cached", "--name-status", "-M", "--", "tasks")
    if proc.returncode != 0:
        return []
    pairs: list[tuple[str, str]] = []
    for line in proc.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) < 3 or not parts[0].startswith("R"):
            continue
        old, new = parts[1], parts[2]
        if OPEN_DIR_RE.match(old) and DONE_DIR_RE.match(new):
            pairs.append((old, new))
    return pairs


def _staged_content(root: Path, relpath: str) -> str:
    """The file AS STAGED. Reading disk would miss a hook that already
    rewrote the staged blob, or judge content the commit does not carry."""
    proc = _run_git(root, "show", f":{relpath}")
    return proc.stdout if proc.returncode == 0 else ""


def close_check_cmd(text: str) -> str | None:
    """The declared closing command, or None when this module cannot locate
    one at all -- distinct from `""`, a `close_check` present but empty.
    Mirrors `backlog_verifier`'s two accepted frontmatter shapes without
    importing its YAML-block parser, which expects a real Path on disk."""
    m = re.search(r'^close_check:\s*(\{.*\})\s*$', text, re.M)
    if m:
        try:
            return str(json.loads(m.group(1)).get("cmd", "") or "").strip()
        except (ValueError, AttributeError):
            return None
    if re.search(r'^close_check:\s*$', text, re.M):
        block_m = re.search(r'^close_check:\s*\n((?:[ \t]+.*\n?)+)', text, re.M)
        if block_m:
            cmd_m = re.search(r'^\s+cmd:\s*"?(.+?)"?\s*$', block_m.group(1), re.M)
            if cmd_m:
                return cmd_m.group(1).strip()
        return None
    m = re.search(r'^verification_command:\s*"?([^"\n]+?)"?\s*$', text, re.M)
    return m.group(1).strip() if m else None


def synthetic_closure_reason(cmd: str, new_path: str, root: Path) -> str | None:
    """None, or why `cmd` verifies this commit's own filing rather than the
    fix the ficha claims -- checked BEFORE the general whitelist below, since
    a self-referential check can use an otherwise-whitelisted shape (a real
    module that just calls `os.path.exists` on its own ficha)."""
    if "backlog_declara_cierre" in cmd:
        return (f"invokes backlog_declara_cierre, the closer that files the ficha, as "
                f"its own proof of closure -- a declaration is not a verification ({cmd!r})")
    if re.search(r"\bassert\s+True\b", cmd):
        return "asserts a literal True, which cannot fail"
    if "os.path.exists" in cmd and (new_path in cmd or re.search(r"tasks/done", cmd)):
        return (f"checks only that a file under tasks/done/ exists -- the very "
                f"rename this commit makes, so it always passes ({cmd!r})")
    if ("artifact_exists" in cmd or "os.path.exists" in cmd) and re.search(r"docs/agent_findings", cmd):
        return (f"uses artifact_exists on docs/agent_findings/ as sole proof of closure -- "
                f"verifying file creation is not verifying substantive functionality ({cmd!r})")
    ok, msg = _validate_verification_cmd(cmd, root=root)
    if not ok:
        return f"not an executable closing command: {msg}"
    return None


def _closure_exemption(text: str) -> tuple[str, str] | None:
    """(closure_type, reason) when the ficha declares one of the two documented
    exemptions from the substantive-change requirement, with a real reason --
    an exemption with no reason is indistinguishable from one nobody wrote."""
    m_type = re.search(r'^closure_type:\s*"?([\w-]+)"?\s*$', text, re.M)
    if m_type is None or m_type.group(1) not in _EXEMPT_CLOSURE_TYPES:
        return None
    m_reason = re.search(r'^reason:\s*"?(.+?)"?\s*$', text, re.M)
    reason = m_reason.group(1).strip() if m_reason else ""
    return (m_type.group(1), reason) if reason else None


def has_substantive_change(root: Path) -> bool:
    """Whether this STAGED commit touches at least one real source or test
    file, anywhere outside `tasks/`."""
    proc = _run_git(root, "diff", "--no-relative", "--cached", "--name-only")
    if proc.returncode != 0:
        return False
    for raw in proc.stdout.splitlines():
        path = raw.strip()
        if not path or path.startswith("tasks/"):
            continue
        if path.startswith("tests/") or Path(path).suffix.lower() in _SOURCE_EXTS:
            return True
    return False


def staged_simulation_or_stub(root: Path) -> list[str]:
    """Check staged source files for simulation comments (simulacion family) or stubs."""
    proc = _run_git(root, "diff", "--no-relative", "--cached", "--name-only")
    if proc.returncode != 0:
        return []
    flagged: list[str] = []
    for raw in proc.stdout.splitlines():
        path = raw.strip()
        if not path or path.startswith(("tests/", "tasks/")):
            continue
        if "agent_threats.py" in path or "detector_controls.py" in path:
            continue
        if path.endswith((".py", ".sh", ".md")):
            content = _staged_content(root, path)
            if "simplecode:corpus" in content:
                continue
            if simulated_or_stub_implementation(content):
                flagged.append(f"{path}: contains simulated or stub code (simulacion family)")
    return flagged


def check(root: Path) -> list[str]:
    """Every synthetic-closure finding for this staged commit, empty if clean."""
    problems: list[str] = []
    sim_stubs = staged_simulation_or_stub(root)
    if sim_stubs:
        problems.extend(sim_stubs)

    closures = staged_closures(root)
    if not closures:
        return problems

    substantive = has_substantive_change(root)
    for _old, new in closures:
        text = _staged_content(root, new)
        if not text:
            continue
        cmd = close_check_cmd(text)
        if cmd is None:
            problems.append(f"{new}: COULD_NOT_DETERMINE_CLOSE_CHECK -- this module "
                             "could not locate a close_check.cmd in the staged content")
        elif not cmd:
            problems.append(f"{new}: close_check declares no command for a ficha "
                             "moving to tasks/done/")
        else:
            reason = synthetic_closure_reason(cmd, new, root)
            if reason:
                problems.append(f"{new}: synthetic close_check -- {reason}")
        if not substantive and _closure_exemption(text) is None:
            problems.append(
                f"{new}: moved to tasks/done/ with no source or test change staged in "
                "this commit, and no closure_type exemption. Include the fix (a "
                "source file or a tests/ change) in this same commit, or declare "
                "`closure_type: void_wontfix`, `closure_type: duplicate`, or "
                "`closure_type: relocated_prior_verification` (already fixed and "
                "verified in an earlier commit; this one only moves the file) with a "
                "non-empty `reason:`. A fix that is only DATA (a manifest, a config "
                "json) is not source: commit it first with its evidence, then move the "
                "ficha in a second commit declaring `relocated_prior_verification` -- "
                "never add a synthetic test just to satisfy this gate"
            )
    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=None, help="Repository root")
    args = parser.parse_args(argv)
    root = args.root or Path.cwd()

    try:
        problems = check(root)
    except GitUnavailable as exc:
        print(f"[genuine-task-closure] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 1

    # Reached only once `check()` has actually scanned the staged commit --
    # the COULD_NOT_RUN bail above (git unavailable, nothing measured yet)
    # never gets here. Covers the clean branch (0) and the BLOCKED branch
    # (len(problems), the same count its own FAIL line prints) alike.
    emit_hallazgos("[genuine-task-closure]", len(problems))

    if not problems:
        print("[genuine-task-closure] OK: no synthetic closure staged.")
        return 0

    print(f"[genuine-task-closure] BLOCKED: synthetic closure detected ({len(problems)})")
    for p in problems:
        print(f"  - {p}")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
