#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mutation-effectiveness probe: does the suite catch anything?

Plants a behavior-changing mutant into a source file's AST (comparison-
operator flip, boolean-literal flip, or off-by-one integer-literal), reruns
the project's real pytest suite, and reports whether the mutant's failing
node-ids differ from the pre-mutation baseline. A green suite that survives
every mutant is theater, not coverage.

Job clause: `probe_mutation_effectiveness` is the single entry point --
walk one source file for mutation candidates, mutate each in turn against
the file on disk (always restored), and classify it killed / survived /
unmeasurable by diffing pytest's short-summary node-ids before and after.
Near-standalone: the only project dependency is
`simplecode.utils.tool_limits.VERSION_PROBE_TIMEOUT`, the declared fixed
bound for the `pytest --version` interpreter probe (GS2-210: fixed
timeouts are only honest when declared in that one place, not scattered
as anonymous magic numbers here too). `tool_limits` itself is stdlib-only.
"""

from __future__ import annotations

import ast
import logging
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from simplecode.utils.tool_limits import VERSION_PROBE_TIMEOUT

logger = logging.getLogger("test_effectiveness")

DEFAULT_TIMEOUT_SECONDS = 1800

# ---------------------------------------------------------------------------
# a) AST mutation engine -- pure, no I/O, no subprocess.
# ---------------------------------------------------------------------------

_CMP_FLIP: dict[type, type] = {
    ast.Eq: ast.NotEq,
    ast.NotEq: ast.Eq,
    ast.Lt: ast.GtE,
    ast.GtE: ast.Lt,
    ast.Gt: ast.LtE,
    ast.LtE: ast.Gt,
}
_CMP_SYMBOL: dict[type, str] = {
    ast.Eq: "==",
    ast.NotEq: "!=",
    ast.Lt: "<",
    ast.GtE: ">=",
    ast.Gt: ">",
    ast.LtE: "<=",
}


@dataclass(frozen=True)
class MutationSite:
    """One candidate mutation: an exact source span plus its replacement text."""

    lineno: int
    col_offset: int
    end_lineno: int
    end_col_offset: int
    original: str
    mutated: str
    operator: str
    description: str


def _span_text(node: ast.AST, lines: list[str]) -> str | None:
    """Return the exact source text a node spans, or None for multi-line spans."""
    lineno = getattr(node, "lineno", None)
    end_lineno = getattr(node, "end_lineno", None)
    col_offset = getattr(node, "col_offset", None)
    end_col_offset = getattr(node, "end_col_offset", None)
    if lineno is None or end_lineno is None or col_offset is None or end_col_offset is None:
        return None
    if lineno != end_lineno or lineno < 1 or lineno > len(lines):
        return None
    line = lines[lineno - 1]
    return line[col_offset:end_col_offset]


def find_mutation_sites(source: str) -> list[MutationSite]:
    """Walk a source file's AST and collect every supported mutation candidate.

    Returns one MutationSite per comparison-operator flip, boolean-literal
    flip, or off-by-one integer-literal mutation found.

    Raises:
        SyntaxError: `source` does not parse. This is deliberately loud --
            an unparseable target file means the probe COULD NOT RUN, which
            is not the same thing as "nothing to mutate", and must not be
            reported as a clean zero-findings pass. Callers that need a
            could-not-run disposition instead of a crash must catch this
            explicitly and record it, not swallow it.
    """
    tree = ast.parse(source)

    lines = source.splitlines()
    sites: list[MutationSite] = []

    parents = {child: parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}
    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            if _is_module_entrypoint_guard(node, parents.get(node)):
                continue
            sites.extend(_compare_sites(node, lines))
        elif isinstance(node, ast.Constant):
            parent = parents.get(node)
            # Changing a zero-argument cache from one slot to two is behaviorally
            # equivalent, so it cannot produce a killable mutant.
            if isinstance(parent, ast.keyword) and parent.arg == "maxsize":
                continue
            if isinstance(node.value, bool):
                sites.extend(_bool_sites(node, lines))
            elif isinstance(node.value, int):
                sites.extend(_int_sites(node, lines))

    return sites


def _is_module_entrypoint_guard(node: ast.Compare, parent: ast.AST | None) -> bool:
    """Exclude import-time entrypoint guards that turn mutation into collection failure."""
    return (
        isinstance(parent, ast.If)
        and parent.test is node
        and isinstance(node.left, ast.Name)
        and node.left.id == "__name__"
        and any(
            isinstance(comparator, ast.Constant) and comparator.value == "__main__"
            for comparator in node.comparators
        )
    )


def _compare_sites(node: ast.Compare, lines: list[str]) -> list[MutationSite]:
    """Build the cmp_flip MutationSite for a single-operator Compare node."""
    if len(node.ops) != 1:
        return []
    op_type = type(node.ops[0])
    flip = _CMP_FLIP.get(op_type)
    if flip is None:
        return []
    orig_sym = _CMP_SYMBOL[op_type]
    new_sym = _CMP_SYMBOL[flip]
    text = _span_text(node, lines)
    if text is None or orig_sym not in text:
        return []
    end_lineno = getattr(node, "end_lineno", node.lineno) or node.lineno
    end_col_offset = getattr(node, "end_col_offset", node.col_offset + len(text)) or (node.col_offset + len(text))
    return [
        MutationSite(
            node.lineno,
            node.col_offset,
            end_lineno,
            end_col_offset,
            text,
            text.replace(orig_sym, new_sym, 1),
            "cmp_flip",
            f"{orig_sym} -> {new_sym}",
        )
    ]


_cmp_sites = _compare_sites


def _bool_sites(node: ast.Constant, lines: list[str]) -> list[MutationSite]:
    """Build the bool_flip MutationSite for a `True`/`False` literal node."""
    text = _span_text(node, lines)
    if text is None:
        return []
    end_lineno = getattr(node, "end_lineno", node.lineno) or node.lineno
    end_col_offset = getattr(node, "end_col_offset", node.col_offset + len(text)) or (node.col_offset + len(text))
    return [
        MutationSite(
            node.lineno,
            node.col_offset,
            end_lineno,
            end_col_offset,
            text,
            "False" if node.value else "True",
            "bool_flip",
            f"{node.value} -> {not node.value}",
        )
    ]


def _int_sites(node: ast.Constant, lines: list[str]) -> list[MutationSite]:
    """Build the two off_by_one MutationSites (+1 and -1) for an int literal."""
    text = _span_text(node, lines)
    if text is None or not isinstance(node.value, int) or isinstance(node.value, bool):
        return []
    val = int(node.value)
    end_lineno = getattr(node, "end_lineno", node.lineno) or node.lineno
    end_col_offset = getattr(node, "end_col_offset", node.col_offset + len(text)) or (node.col_offset + len(text))
    return [
        MutationSite(
            node.lineno,
            node.col_offset,
            end_lineno,
            end_col_offset,
            text,
            str(val + delta),
            "off_by_one",
            f"{val} -> {val + delta}",
        )
        for delta in (1, -1)
    ]


def _read_source_exact(path: Path) -> str:
    """Read a source file byte-faithfully: fixed UTF-8, no newline translation.

    `Path.read_text()` decodes with the locale's default encoding and
    universal-newlines-translates every line ending to "\\n". Both are
    wrong for a production source file this module rewrites in place: the
    locale can silently pick something other than UTF-8, and a CRLF file
    would get rewritten as LF even when only the mutation itself changed.
    ``newline=""`` disables the translation so `apply_mutation`'s
    `splitlines(keepends=True)` round-trip reproduces the original
    terminators exactly.
    """
    with path.open("r", encoding="utf-8", newline="") as fh:
        return fh.read()


def _write_source_exact(path: Path, source: str) -> None:
    """Write `source` back byte-faithfully: fixed UTF-8, no newline translation."""
    with path.open("w", encoding="utf-8", newline="") as fh:
        fh.write(source)


def apply_mutation(source: str, site: MutationSite) -> str:
    """Return `source` with exactly one mutation site's span replaced."""
    lines = source.splitlines(keepends=True)
    line = lines[site.lineno - 1]
    lines[site.lineno - 1] = (
        line[: site.col_offset] + site.mutated + line[site.end_col_offset :]
    )
    return "".join(lines)


# ---------------------------------------------------------------------------
# b) Suite runner -- resolves an interpreter, runs pytest, parses real
#    failing/erroring node-ids from its short summary only (captured log
#    lines can also start with FAILED/ERROR, so the full output is not
#    trustworthy).
# ---------------------------------------------------------------------------

_SUMMARY_HEADER = "short test summary info"
_SUMMARY_LINE = re.compile(r"^(?:FAILED|ERROR)\s+(\S+)")


def normalize_entries(entries: Iterable[str] | None) -> tuple[str, ...]:
    """Canonical form of a set of identifiers: sorted, de-duplicated, no blanks.

    Example:
        >>> normalize_entries(["b", " a ", "b", ""])
        ('a', 'b')
    """
    if entries is None:
        return ()
    cleaned = {str(entry).strip() for entry in entries}
    return tuple(sorted(entry for entry in cleaned if entry))


def _summary_region(output: str) -> list[str]:
    """The lines of pytest's short-summary section, or [] when it never printed."""
    lines = output.splitlines()
    starts = [i for i, line in enumerate(lines) if _SUMMARY_HEADER in line]
    if not starts:
        return []
    return lines[starts[-1] + 1 :]


def parse_failing_node_ids(output: str) -> tuple[str, ...]:
    """Every failing/erroring node-id pytest reported, from its short summary.

    Example:
        >>> parse_failing_node_ids("== short test summary info ==\\nFAILED t.py::a - x")
        ('t.py::a',)
    """
    found = []
    for line in _summary_region(output):
        match = _SUMMARY_LINE.match(line.strip())
        if not match:
            continue
        node_id = match.group(1)
        if ".py" in node_id:
            found.append(node_id)
    return normalize_entries(found)


def resolve_python(root: Path, declared: str | None = None) -> str:
    """The interpreter that can actually run this project's suite.

    Every candidate is PROVEN able to run pytest before it is chosen. The
    project's own venv comes first, because the suite needs the PROJECT's
    dependencies, never the caller's.
    """
    candidates = [
        candidate
        for candidate in (
            declared,
            str(root / ".venv" / "bin" / "python"),
            "/usr/bin/python3",
            sys.executable,
        )
        if candidate
    ]
    for candidate in candidates:
        try:
            probe = subprocess.run(
                [candidate, "-m", "pytest", "--version"],
                capture_output=True,
                text=True,
                timeout=VERSION_PROBE_TIMEOUT,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            logger.info("Candidate interpreter %s cannot run pytest: %s", candidate, exc, exc_info=True)
            continue
        if probe.returncode == 0:
            return candidate
        logger.info("Candidate interpreter %s has no usable pytest (exit %s).", candidate, probe.returncode)
    return candidates[0]


def run_suite(
    root: Path, tests_dir: Path, python: str, timeout: int = DEFAULT_TIMEOUT_SECONDS
) -> tuple[int, str] | None:
    """Run the project's suite and return its exit code and output, or None
    when the run could not be performed at all."""
    env = dict(
        os.environ,
        PYTHONPATH=str(root),
        PYTHONUTF8="1",
        PYTHONIOENCODING="utf-8",
        # Reproduced under load (DEBT-SPEC8-MUTATION-CI's CI-wiring tests): the
        # baseline run and the first mutant can land inside the same mtime tick
        # on a coarse filesystem clock, and CPython's (mtime, size) pyc cache
        # check then reuses the PRE-MUTATION bytecode for a same-size mutation
        # (a flipped operator or a single-digit literal never changes the file
        # size) -- the mutant silently never executes and reads as "survived"
        # for a reason that has nothing to do with the test's real quality.
        # Disabling bytecode writes for this subprocess removes the cache this
        # race depends on; every run recompiles from the source actually on
        # disk. Scoped to this one subprocess's env, not the caller's process.
        PYTHONDONTWRITEBYTECODE="1",
    )
    command = [python, "-m", "pytest", str(tests_dir)]
    command += ["-q", "-rfE", "--color=no", "-p", "no:cacheprovider"]
    # rootdir is pinned so reported node-ids are repo-relative and stable
    # regardless of whether the project happens to have a pytest.ini.
    command += ["--rootdir", str(root)]
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            cwd=str(root),
            env=env,
            timeout=timeout,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.warning("The suite could not be run: %s", exc, exc_info=True)
        return None
    return completed.returncode, (completed.stdout or "") + (completed.stderr or "")


def measure_failures(
    root: Path, tests_dir: Path, python: str, timeout: int = DEFAULT_TIMEOUT_SECONDS
) -> tuple[str, ...] | None:
    """The project's current failing set, or None when it cannot be measured.

    Fail-closed on ambiguity: pytest exit codes other than 0 (all passed) and 1
    (tests failed) mean the run was interrupted, misconfigured or collected
    nothing, and a failing run with no parseable node-id is not evidence of a
    green suite either. Both cases return None so the caller blocks.
    """
    run = run_suite(root, tests_dir, python, timeout)
    if run is None:
        return None
    returncode, output = run
    if returncode == 0:
        return ()
    if returncode != 1:
        return None
    return parse_failing_node_ids(output) or None


# ---------------------------------------------------------------------------
# c) The organ itself: plant each mutant against the real file on disk,
#    rerun the real suite, and classify against the pre-mutation baseline.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MutantResult:
    """One mutant's verdict: what changed, and whether the suite noticed."""

    site: MutationSite
    verdict: str  # "killed" | "survived" | "unmeasurable"
    failing_node_ids: tuple[str, ...] | None


@dataclass(frozen=True)
class MutationReport:
    """The full probe result for one source file against one suite."""

    baseline: tuple[str, ...] | None
    results: list[MutantResult] = field(default_factory=list)
    sites_error: str | None = None
    """Set when the target file could not even be parsed for mutation sites.

    A populated `sites_error` means the probe COULD NOT RUN against this
    file at all -- distinct from `results == []`, which means the file
    parsed cleanly but had nothing mutable in it. Callers must report this
    explicitly rather than treat an empty `results` as a passing probe.
    """

    @property
    def killed(self) -> list[MutantResult]:
        return [r for r in self.results if r.verdict == "killed"]

    @property
    def survived(self) -> list[MutantResult]:
        return [r for r in self.results if r.verdict == "survived"]

    @property
    def unmeasurable(self) -> list[MutantResult]:
        return [r for r in self.results if r.verdict == "unmeasurable"]

    @property
    def is_theater(self) -> bool:
        """True when there was at least one mutant to plant and none died."""
        return bool(self.results) and not self.killed

    @property
    def is_effective(self) -> bool:
        """True only when every planted mutant was measured and killed."""
        return (
            self.baseline == ()
            and bool(self.results)
            and not self.survived
            and not self.unmeasurable
        )


@dataclass(frozen=True)
class MutationOptions:
    python: str | None = None
    timeout: int = DEFAULT_TIMEOUT_SECONDS
    max_mutants: int | None = None


def probe_mutation_effectiveness(
    target_file: Path,
    root: Path,
    tests_dir: Path,
    options: MutationOptions | None = None,
) -> MutationReport:
    """Plant mutants into `target_file` one at a time and see if the suite dies.

    For each supported mutation site: mutate the file on disk, rerun the
    suite, and compare its failing node-ids to the pre-mutation baseline.
    The file is always restored to its original text, even on error. A
    mutant is "killed" only when it produces failures the baseline did not
    already have -- an already-red baseline proves nothing about a mutant,
    so no new failure beyond the baseline means "survived", not "killed".

    Args:
        target_file: Source file to mutate, must live under `root`.
        root: Project repository root (cwd and PYTHONPATH for the suite).
        tests_dir: Directory of tests to run.
        options: Interpreter, timeout and mutant limit overrides.

    Returns:
        MutationReport: baseline failing set plus one MutantResult per site.
    """
    options = options or MutationOptions()
    python = options.python or resolve_python(root)
    baseline = measure_failures(root, tests_dir, python, options.timeout)

    original_source = _read_source_exact(target_file)
    try:
        sites = find_mutation_sites(original_source)
    except SyntaxError as exc:
        logger.error(
            "Cannot parse %s for mutation sites -- probe COULD NOT RUN: %s",
            target_file,
            exc,
            exc_info=True,
        )
        return MutationReport(baseline=baseline, results=[], sites_error=f"{target_file}: {exc}")
    if options.max_mutants is not None:
        sites = sites[: options.max_mutants]

    results: list[MutantResult] = []
    try:
        for site in sites:
            _write_source_exact(target_file, apply_mutation(original_source, site))
            try:
                mutated_failures = measure_failures(root, tests_dir, python, options.timeout)
            finally:
                _write_source_exact(target_file, original_source)

            if mutated_failures is None:
                verdict = "unmeasurable"
            elif baseline is not None and set(mutated_failures) > set(baseline):
                verdict = "killed"
            else:
                verdict = "survived"
            results.append(MutantResult(site, verdict, mutated_failures))
    finally:
        _write_source_exact(target_file, original_source)

    return MutationReport(baseline=baseline, results=results)


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for mutation effectiveness testing."""
    import argparse

    parser = argparse.ArgumentParser(description="Mutation effectiveness probe")
    parser.add_argument("target_file", nargs="?", type=Path, default=None, help="Source file to mutate")
    parser.add_argument("--target-file", dest="flag_target_file", type=Path, default=None, help="Source file to mutate")
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Project root")
    parser.add_argument("--tests-dir", type=Path, default=Path("tests"), help="Tests directory")
    parser.add_argument("--python", help="Python interpreter override")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="Timeout per suite run")
    parser.add_argument("--max-mutants", type=int, help="Max mutants to test")
    args = parser.parse_args(argv)

    target = args.target_file or args.flag_target_file
    if target is None:
        print("Error: target_file is required")
        return 1

    try:
        report = probe_mutation_effectiveness(
            target_file=target,
            root=args.root,
            tests_dir=args.tests_dir,
            options=MutationOptions(args.python, args.timeout, args.max_mutants),
        )
        if report.sites_error:
            print(f"COULD NOT RUN: {report.sites_error}")
            return 2
        print(f"Baseline failures: {len(report.baseline) if report.baseline is not None else 'unmeasurable'}")
        print(f"Mutants tested: {len(report.results)}")
        print(f"Killed: {len(report.killed)}")
        print(f"Survived: {len(report.survived)}")
        print(f"Unmeasurable: {len(report.unmeasurable)}")
        for result in report.results:
            print(
                f"  {result.verdict.upper()}: line {result.site.lineno} "
                f"{result.site.description}"
            )
        if not report.is_effective:
            print("MUTATION GATE FAILED: every mutant must be measured and killed")
            return 2
        return 0
    except Exception as e:
        logger.error("Mutation analysis failed: %s", e, exc_info=True)
        print(f"Error: {e}")
        return 1


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))
