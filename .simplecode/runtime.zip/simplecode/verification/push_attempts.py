#!/usr/bin/env python3
"""push_attempts.py -- how many `git push` attempts does a green push cost?

Reads `.simplecode/evidence/telemetry.jsonl` (rows written by
`simplecode.verification.gate_runner`) and groups the `hook=pre-push` rows
into push ATTEMPTS: every child gate row up to and including the aggregate
`check=pre-push` row the generated hook writes for the whole run.

Prints, per repo and window:
  * attempts, blocked, green;
  * attempts needed per green push: mean (the price actually paid), median,
    median among pushes that needed a retry, max -- the 2026-09-15
    push-pipeline reform is judged by the MEAN (target: <= 2 = discover, then
    confirm) and `--max-mean` gates on it for that reason;
  * gates red in attempt N+1 that were green in attempt N ("fresh": the fix
    of one attempt created the failure of the next -- the self-reference
    signature);
  * attempts blocked by exactly ONE gate.

Exit codes (so a ficha's close_check can cite it):
  0  measured, and `--max-mean` (if given) is satisfied;
  1  measured, and the mean attempts per green push EXCEEDS `--max-mean`;
  2  COULD_NOT_RUN: fewer than `--min-green` green pushes in the window --
     a verdict over no data is not a verdict.

This is the literal query behind the numbers in DECISIONS.md (2026-09-15,
push-pipeline reform) and the fichas DEBT-PUSH-LOOP-*; re-run it instead of
quoting them:

    python -m simplecode.verification.push_attempts --repo . --since 2026-09-16 --max-mean 2

Declared limits: attempts are delimited by the aggregate `check=pre-push` row,
so a run killed before writing it merges into the next attempt; rows are
grouped by file position after a stable sort on `ts`, so two hooks running
concurrently in the same tree interleave (measured to happen: worktree pushes
overlapping main's).
"""
from __future__ import annotations

import argparse
import collections
import gzip
import json
import statistics
import sys
from pathlib import Path
from collections.abc import Iterator

TELEMETRY = Path(".simplecode/evidence/telemetry.jsonl")


def telemetry_sources(path: Path) -> tuple[list[Path], list[Path]]:
    """(fuentes legibles, fuentes ilegibles) para la ventana: el ledger vivo y sus archivos.

    `telemetry_prune` mueve toda fila de mas de `DEFAULT_KEEP_DAYS = 7` dias a un
    `telemetry.jsonl.until-<fecha>.gz` al lado del ledger. Leer solo el ledger vivo
    convierte a este instrumento en uno que se vacia solo: el cron semanal que juzga
    la reforma pide `--since 2026-09-16` y a partir del 2026-09-30 esa ventana ya no
    estaria entera en el fichero vivo, asi que la media se calcularia sobre una muestra
    que se encoge sin que nada avise. Medido el 2026-09-15: con el archivo incluido la
    ventana desde 2026-09-03 da 212 intentos; sin el, 90.

    La lista de ilegibles existe para que el reporte pueda decir su denominador. Un
    archivo que no se puede abrir no se salta en silencio: hace el veredicto INCOMPLETO.
    """
    fuentes = [path] if path.is_file() else []
    ilegibles: list[Path] = []
    for arch in sorted(path.parent.glob(path.name + ".until-*.gz")):
        try:
            with gzip.open(arch, "rt", encoding="utf-8") as fh:
                fh.readline()
        except OSError:
            ilegibles.append(arch)
            continue
        fuentes.append(arch)
    return fuentes, ilegibles


def _iter_lines(source: Path) -> Iterator[str]:
    """Las lineas de un ledger, este comprimido o no.

    Se ramifica en vez de asignar `gzip.open` u `open` a una variable: esa forma
    obligaba a un `# type: ignore[operator]`, y una supresion que se puede hacer
    innecesaria escribiendo el codigo de otra manera no se justifica, se elimina.
    """
    if source.suffix == ".gz":
        with gzip.open(source, "rt", encoding="utf-8") as fh:
            yield from fh
    else:
        with source.open(encoding="utf-8") as fh:
            yield from fh


def load_attempts(path: Path, since: str, until: str | None = None) -> list[list[dict]]:
    rows: list[dict] = []
    vistas: set[str] = set()
    fuentes, _ = telemetry_sources(path)
    for source in fuentes:
        for line in _iter_lines(source):
            line = line.strip()
            if not line:
                continue
            if line in vistas:
                continue  # una poda MUEVE filas, no las copia; esto es seguro barato
            vistas.add(line)
            try:
                row = json.loads(line)
            except ValueError:
                continue  # a torn line is not an attempt; counted nowhere on purpose
            ts = str(row.get("ts", ""))
            if row.get("hook") == "pre-push" and ts >= since and (until is None or ts < until):
                rows.append(row)
    rows.sort(key=lambda r: r["ts"])
    attempts: list[list[dict]] = []
    current: list[dict] = []
    for row in rows:
        current.append(row)
        if row.get("check") == "pre-push":
            attempts.append(current)
            current = []
    return attempts


def summarize(attempts: list[list[dict]]) -> dict:
    blocked = [a for a in attempts if a[-1].get("status") != "ok"]
    green = [a for a in attempts if a[-1].get("status") == "ok"]
    runs: list[int] = []
    streak = 0
    fresh: collections.Counter[str] = collections.Counter()
    single: collections.Counter[str] = collections.Counter()
    for i, attempt in enumerate(attempts):
        if attempt[-1].get("status") == "ok":
            runs.append(streak + 1)
            streak = 0
            continue
        streak += 1
        red = {c["check"] for c in attempt[:-1] if c.get("status") != "ok"}
        if len(red) == 1:
            single[next(iter(red))] += 1
        if i:
            prev_red = {c["check"] for c in attempts[i - 1][:-1] if c.get("status") != "ok"}
            fresh.update(red - prev_red)
    return {
        "attempts": len(attempts),
        "blocked": len(blocked),
        "green": len(green),
        # Three views of the same cost, because each alone misleads: the mean
        # is the honest per-push price (every attempt paid / every push that
        # landed); the overall median hides retries when most pushes land
        # first try; the retried-only median says how deep a loop goes once
        # it starts.
        "attempts_per_green_mean": round(len(attempts) / len(green), 2) if green else None,
        "attempts_per_green_median": statistics.median(runs) if runs else None,
        "attempts_per_green_median_when_retried": (
            statistics.median([r for r in runs if r > 1]) if any(r > 1 for r in runs) else None),
        "attempts_per_green_max": max(runs) if runs else None,
        "first_ts": attempts[0][0].get("ts") if attempts else None,
        "fresh_in_next_attempt": fresh.most_common(),
        "blocked_by_single_gate": single.most_common(),
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", default=".", help="repository root (default: .)")
    ap.add_argument("--since", default="0000", help="ISO timestamp lower bound, e.g. 2026-09-16")
    ap.add_argument("--until", default=None,
                    help="ISO timestamp EXCLUSIVE upper bound. A closure that measured a window must "
                         "pin it: with only --since the ratio keeps moving with every later push")
    ap.add_argument("--max-mean", type=float, default=None,
                    help="exit 1 if the MEAN attempts per green push exceeds this")
    ap.add_argument("--min-green", type=int, default=5,
                    help="fewer green pushes than this in the window is COULD_NOT_RUN (exit 2)")
    args = ap.parse_args(argv)

    path = Path(args.repo) / TELEMETRY
    # La guarda pregunta por FUENTES, no por el ledger vivo: `telemetry_prune` puede
    # haberselo llevado entero a un archivo, y negarse a medir datos que si estan es
    # el mismo defecto que leer el instrumento en vez del sujeto.
    fuentes, ilegibles = telemetry_sources(path)
    if not fuentes:
        print(f"[push-attempts] COULD_NOT_RUN: neither {path} nor any "
              f"{path.name}.until-*.gz archive beside it", file=sys.stderr)
        return 2
    summary = summarize(load_attempts(path, args.since, args.until))
    print(f"[push-attempts] repo={Path(args.repo).resolve().name} since={args.since}"
          + (f" until={args.until}" if args.until else ""))
    print(f"  telemetry read: {len(fuentes)} source(s) "
          f"({', '.join(s.name for s in fuentes)})")
    if ilegibles:
        # El denominador va junto al numero, no en su lugar: si un archivo no se pudo
        # abrir, la media de abajo se calculo sobre MENOS filas de las que la ventana
        # abarca, y eso hay que poder leerlo sin ir al codigo.
        print(f"  COULD NOT READ {len(ilegibles)} archive(s): "
              f"{', '.join(s.name for s in ilegibles)} -- this verdict is INCOMPLETE",
              file=sys.stderr)
    print(f"  attempts={summary['attempts']} blocked={summary['blocked']} green={summary['green']}")
    print(f"  first attempt in window: {summary['first_ts']}")
    print(f"  attempts per green push: mean={summary['attempts_per_green_mean']} "
          f"median={summary['attempts_per_green_median']} "
          f"median-when-retried={summary['attempts_per_green_median_when_retried']} "
          f"max={summary['attempts_per_green_max']}")
    print("  red in N+1, green in N (fresh):", summary["fresh_in_next_attempt"] or 0)
    print("  blocked by a single gate:", summary["blocked_by_single_gate"] or 0)

    if summary["green"] < args.min_green:
        print(f"[push-attempts] COULD_NOT_RUN: {summary['green']} green push(es) < --min-green "
              f"{args.min_green}; no verdict over this little data", file=sys.stderr)
        return 2
    mean = summary["attempts_per_green_mean"]
    if args.max_mean is not None and mean is not None and mean > args.max_mean:
        print(f"[push-attempts] NOT CLEAN: mean {mean} attempts per green push > "
              f"--max-mean {args.max_mean}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
