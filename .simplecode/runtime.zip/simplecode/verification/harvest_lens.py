# -*- coding: utf-8 -*-
"""Verification tool enforcing the Harvest Lens evaluation protocol for third-party libraries and code."""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

VALID_VERDICTS = {"MAD", "ABD", "INF", "LIC", "DOM", "EVI", "TOS", "COS"}
VERDICT_RE = re.compile(rf"\b({'|'.join(VALID_VERDICTS)})\b")
MECHANISM_ITEM_RE = re.compile(r"^\s*(?:[-*]|\d+\.)\s+(?:M\d+|mecanismo|mechanism|\*\*M\d+\*\*|`M\d+`)", re.IGNORECASE | re.MULTILINE)
TRIGGER_RE = re.compile(r"(?i)\b(?:disparador|trigger|caducidad|reevaluaci[oó]n|re-evaluation)\b")

# Step 2 (interrogar cada mecanismo contra NUESTRO sistema). The doctrine's three
# questions: does it attack a known failure of ours? is there a version at our
# scale? does it formally name something we did implicitly? An evaluation that
# lists mechanisms but never interrogates them is the "juzgar al nivel del
# producto" failure -- exactly how an arrogant "INF, we're superior" slips in.
INTERROGATION_RE = re.compile(
    r"(?i)("
    r"ataca|attack|falla (?:conocida|nuestra)|known failure|nuestr[oa]|our system|our\b|"
    r"a nuestra escala|at our scale|escala\b|scale\b|"
    r"implíc|implicit|nombra formalmente|formally names?|hac[ií]amos|we (?:did|do) implicitly|"
    r"deuda|debt|resuelve|resolves|atiende"
    r")"
)

# Section 3 of the doctrine: reasonings that may be CONTEXT but are PROHIBITED as
# a rejection conclusion. Judging the product ("ya tenemos algo superior") instead
# of mining the mechanism is the named arrogance. Meta-references to the
# prohibition itself are excluded so the doctrine can be quoted.
PROHIBITED_REASONING = (
    (re.compile(r"(?i)ya tenemos (?:algo )?(?:superior|mejor)|we already have (?:something )?(?:superior|better)|we'?re (?:superior|better)"),
     "product_level_superiority"),
    (re.compile(r"(?i)pocas estrellas|few (?:github )?stars"),
     "github_stars"),
    (re.compile(r"(?i)(?:muy|too) (?:nuevo|viejo|new|old)"),
     "project_age"),
    (re.compile(r"(?i)no aplica a nuestro dominio|does(?:n'?t| not) apply to our domain"),
     "domain_mismatch_without_mechanisms"),
    (re.compile(r"(?i)no encontré nada|found nothing|nada que (?:cosechar|extraer|aprovechar)"),
     "found_nothing_without_component_list"),
)
_PROHIBITION_META_RE = re.compile(r"(?i)prohib|nunca conclus|never (?:a )?conclusi|§ ?3|secci[oó]n 3|as a rejection|como motivo de rechazo|razonamientos? prohibid")


def audit_harvest_evaluation(text: str) -> list[str]:
    """Audit an evaluation note against the Harvest Lens protocol.

    Enforces all three mandatory steps AND the Section-3 anti-arrogance rules:
    Step 1 (>= 3 mechanisms), Step 2 (each mechanism interrogated against our
    system -- not merely listed), Step 3 (typed verdict + re-evaluation trigger),
    and Section 3 (no product-level dismissal standing as a conclusion).
    """
    step1, mechanism_count = _check_mechanisms(text)
    return (
        step1
        + _check_verdict(text)
        + _check_interrogation(text, mechanism_count)
        + _check_trigger(text)
        + _check_prohibited_reasoning(text)
        + _check_per_mechanism_dismissals(text)
    )


def _check_mechanisms(text: str) -> tuple[list[str], int]:
    """Step 1: enumerate >= 3 concrete mechanisms before any verdict."""
    mechanisms = MECHANISM_ITEM_RE.findall(text)
    mechanism_count = len(mechanisms)
    if mechanism_count >= 3:
        return [], mechanism_count
    generic_items = re.findall(r"^\s*(?:[-*]|\d+\.)\s+.{15,}", text, re.MULTILINE)
    mechanism_count = max(mechanism_count, len(generic_items))
    if len(generic_items) >= 3:
        return [], mechanism_count
    return [
        f"insufficient_mechanisms_enumerated: found {len(mechanisms)} mechanisms "
        f"(must enumerate >= 3 before verdict)"
    ], mechanism_count


def _check_verdict(text: str) -> list[str]:
    """Step 3a: a classified verdict code must be present."""
    if VERDICT_RE.search(text):
        return []
    return [
        f"missing_standard_verdict: evaluation must declare a classified verdict "
        f"({', '.join(sorted(VALID_VERDICTS))})"
    ]


def _check_interrogation(text: str, mechanism_count: int) -> list[str]:
    """Step 2: mechanisms must be interrogated against our system, not just listed."""
    interrogations = len(INTERROGATION_RE.findall(text))
    required = min(mechanism_count, 3) if mechanism_count else 3
    if interrogations >= required:
        return []
    return [
        f"mechanisms_not_interrogated: {mechanism_count} mechanism(s) listed but only {interrogations} "
        f"interrogation(s) of our system found (Step 2 requires interrogating each -- does it attack a "
        f"known failure of ours? a version at our scale? name something we did implicitly?)"
    ]


def _check_trigger(text: str) -> list[str]:
    """Step 3b: a re-evaluation / expiration trigger must be stated."""
    if TRIGGER_RE.search(text):
        return []
    return ["missing_reevaluation_trigger: evaluation must state an expiration trigger or re-evaluation condition"]


def _check_prohibited_reasoning(text: str) -> list[str]:
    """Section 3: a prohibited reasoning standing as a conclusion (anti-arrogance)."""
    findings: list[str] = []
    for pattern, label in PROHIBITED_REASONING:
        for match in pattern.finditer(text):
            if _PROHIBITION_META_RE.search(_line_of(text, match.start())):
                continue  # quoting the prohibition itself is allowed
            findings.append(
                f"prohibited_reasoning_as_conclusion ({label}): {match.group(0)!r} -- Section 3 forbids this as a "
                f"rejection motive; it may be context, never a conclusion. Interrogate the mechanism instead."
            )
    return findings


def _check_per_mechanism_dismissals(text: str) -> list[str]:
    """A mechanism carrying a DISMISSAL must interrogate >= 2 Step-2 questions in
    its OWN block -- catching product-level arrogance hiding in one mechanism
    while the document as a whole looks well-interrogated."""
    findings: list[str] = []
    for label, block in _mechanism_blocks(text):
        if not DISMISSAL_RE.search(block):
            continue
        themes = sum(1 for theme in STEP2_THEMES if theme.search(block))
        if themes < 2:
            findings.append(
                f"mechanism_dismissed_without_interrogation ({label}): a dismissive verdict appears but only "
                f"{themes}/3 Step-2 questions are interrogated in its block -- dismissing at the product level "
                f"('we're superior') before interrogating the mechanism is the named Section-3 arrogance."
            )
    return findings


# A sub-verdict that rejects/downgrades a mechanism. Legitimate only when the
# mechanism was actually interrogated (see per-block check).
DISMISSAL_RE = re.compile(
    r"(?i)\bINF\b|inferior|(?:supera|superamos|iguala|equals?|exceeds?|surpass)|"
    r"a la par|por encima|already (?:exceed|have|surpass|beat)|nothing to (?:harvest|extract)|"
    r"nada que (?:cosechar|extraer|aprovechar)|no-op|not harvested|ya lo superamos"
)
# The three Step-2 questions, as detectable themes.
STEP2_THEMES = (
    re.compile(r"(?i)ataca|falla (?:conocida|nuestra)|known failure|deuda|debt|attacks?\b"),
    re.compile(r"(?i)a nuestra escala|at our scale|\bescala\b|\bscale\b"),
    re.compile(r"(?i)implíc|implicit|nombra formalmente|formally names?|hac[ií]amos|we (?:did|do) implicitly"),
)
_MECH_HEADER_RE = re.compile(r"^\s*(?:[-*]\s*)?(?:\*\*)?\s*(M\d+)\b", re.MULTILINE)


def _mechanism_blocks(text: str) -> list[tuple[str, str]]:
    """Split the evaluation into (mechanism-label, block-text) chunks.

    A block runs from one ``Mn`` header to the next (or end of text), so each
    mechanism's own reasoning can be interrogated in isolation.
    """
    headers = list(_MECH_HEADER_RE.finditer(text))
    blocks: list[tuple[str, str]] = []
    for i, header in enumerate(headers):
        start = header.start()
        end = headers[i + 1].start() if i + 1 < len(headers) else len(text)
        blocks.append((header.group(1), text[start:end]))
    return blocks


def _line_of(text: str, index: int) -> str:
    """The full line of ``text`` containing the character at ``index``."""
    start = text.rfind("\n", 0, index) + 1
    end = text.find("\n", index)
    return text[start:] if end == -1 else text[start:end]


def audit_harvest_file(file_path: Path) -> list[str]:
    """Read and audit a harvest evaluation document."""
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ["file_not_found"]
    return audit_harvest_evaluation(content)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Enforce Harvest Lens protocol (3+ mechanisms, standard verdict, expiration trigger)."
    )
    parser.add_argument("paths", nargs="*", type=Path, help="Evaluation documents or registries to audit")
    args = parser.parse_args(argv)

    if not args.paths:
        try:
            content = sys.stdin.read()
            findings = audit_harvest_evaluation(content)
            if findings:
                print(f"[harvest-lens] FAIL: {len(findings)} protocol violation(s):")
                for f in findings:
                    print(f"  - {f}")
                return 1
            print("[harvest-lens] OK: evaluation conforms to Harvest Lens protocol.")
            return 0
        except OSError:
            return 1

    total_failures = 0
    for p in args.paths:
        if not p.is_file():
            continue
        findings = audit_harvest_file(p)
        if findings:
            total_failures += len(findings)
            print(f"[harvest-lens] FAIL: {p}")
            for f in findings:
                print(f"  - {f}")
        else:
            print(f"[harvest-lens] OK: {p}")

    return 1 if total_failures > 0 else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
