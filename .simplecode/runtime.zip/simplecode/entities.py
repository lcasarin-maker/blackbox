# -*- coding: utf-8 -*-
"""entities -- the real dataclasses SPEC.md's §4 gestures at, wired to what
production actually carries.

The prior `entities.py` never existed as a module; its test file compared
dict literals against themselves (mock theater -- nothing under test). These
dataclasses are wired to their actual producers/consumers:

  Finding          The contract for detector/gate findings. Defined here with
                    (de)serialization helpers. zero_debt.py and gate_runner.py
                    still emit ad hoc dicts/strings as of this module's
                    introduction -- routing them through Finding is a later
                    wave's wiring, not this one's. Not a dataclass nobody
                    calls forever, just not called yet.

  RatchetSnapshot   Wired to worktree/ratchet.py's tooling baseline (the
                    {scripts, loc, code} triple written/read by
                    run_tooling_check). Enriched with `timestamp` and
                    `head_sha` for provenance; both are optional so a legacy
                    baseline file (no provenance fields) still loads.

  DriftGap /
  DriftReport       Wired to worktree/drift.py's `build_drift_report`, which
                    classifies the same deviation strings `find_deviations`
                    has always produced (kept as list[str] -- see drift.py's
                    module docstring for why) into typed entries.

Standalone module: no repo-specific imports, no fleet-walking, no network.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any, Optional

VALID_SEVERITIES = ("FAIL", "WARN")


@dataclass(frozen=True)
class Finding:
    """One detector/gate finding: what fired, where, and whether it blocks.

    SPEC §4's field list for Finding (file_path, line, detector_id, message,
    severity, would_block) matches what detectors already produce as loose
    dicts/strings today, so no diff to report here -- this dataclass is the
    field list made real, not a redesign of it.
    """

    file_path: str
    line: int
    detector_id: str
    message: str
    severity: str
    would_block: bool

    def __post_init__(self) -> None:
        if self.severity not in VALID_SEVERITIES:
            raise ValueError(
                f"severity must be one of {VALID_SEVERITIES}, got {self.severity!r}"
            )
        if not isinstance(self.line, int) or isinstance(self.line, bool):
            raise TypeError(f"line must be an int, got {type(self.line).__name__}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Finding":
        return cls(
            file_path=str(data["file_path"]),
            line=int(data["line"]),
            detector_id=str(data["detector_id"]),
            message=str(data["message"]),
            severity=str(data["severity"]),
            would_block=bool(data["would_block"]),
        )

    @classmethod
    def from_json(cls, text: str) -> "Finding":
        return cls.from_dict(json.loads(text))


@dataclass(frozen=True)
class RatchetSnapshot:
    """The tooling ratchet's baseline, wired to `worktree.ratchet.measure_tooling_tree`.

    The real baseline on disk is `{scripts, loc, code}` with no provenance --
    SPEC's field list (timestamp, head_sha, code_lines, prose_lines,
    total_lines, version_floor) does not match what the tooling ratchet
    actually measures or what the debt ratchet keys its baseline by (a
    per-file line-count map, a different shape entirely; RatchetSnapshot
    models the tooling baseline only). This is the measured reality:
    `scripts`, `loc`, `code` are the counts `measure_tooling_tree` produces;
    `timestamp` and `head_sha` are injected provenance, both optional so a
    legacy baseline file (written before this module existed) still loads.
    """

    scripts: int
    loc: int
    code: int
    timestamp: Optional[str] = None
    head_sha: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "scripts": self.scripts,
            "loc": self.loc,
            "code": self.code,
            "timestamp": self.timestamp,
            "head_sha": self.head_sha,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RatchetSnapshot":
        timestamp = data.get("timestamp")
        head_sha = data.get("head_sha")
        return cls(
            scripts=int(data.get("scripts", 0)),
            loc=int(data.get("loc", 0)),
            code=int(data.get("code", 0)),
            timestamp=timestamp if isinstance(timestamp, str) else None,
            head_sha=head_sha if isinstance(head_sha, str) else None,
        )

    @classmethod
    def from_json(cls, text: str) -> "RatchetSnapshot":
        return cls.from_dict(json.loads(text))

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n"


@dataclass(frozen=True)
class DriftGap:
    """One deviation drift.py's checks found, typed instead of a magic-prefixed string."""

    category: str
    detail: str

    def render(self) -> str:
        """Reconstruct the exact string drift.py has always printed: `CATEGORY: detail`."""
        return f"{self.category}: {self.detail}"

    @classmethod
    def parse(cls, deviation: str) -> "DriftGap":
        """Parse one of drift.py's existing `"CATEGORY: detail"` strings.

        Categories drift.py has ever emitted: MISSING, INCOMPLETE, BOUNDARY,
        ALIGNMENT, COULD NOT RUN. A string with no recognized `: ` split
        still parses -- it becomes category "UNKNOWN" rather than raising,
        because a drift report must never itself become the thing that
        crashes the drift check.
        """
        if ": " in deviation:
            category, detail = deviation.split(": ", 1)
            return cls(category=category, detail=detail)
        return cls(category="UNKNOWN", detail=deviation)


_HIGH_CATEGORIES = frozenset({"MISSING", "COULD NOT RUN"})
_MEDIUM_CATEGORIES = frozenset({"BOUNDARY"})


@dataclass(frozen=True)
class DriftReport:
    """Structured result of `worktree.drift.find_deviations`, adapted from SPEC §4.

    SPEC's field list (spec_objective, actual_state, gaps[], severity) assumes
    ONE objective being checked; drift.py actually checks three independent
    things (SPEC.md's structured objective, an explicit non-UI/real-time
    boundary against actual imports, and ADR-to-mission alignment) and
    concatenates their findings. `spec_objective`/`actual_state` here
    describe that combined invariant rather than a single field, and
    `severity` is derived from the worst category present rather than
    hand-assigned -- reality's shape differs from SPEC's single-objective
    assumption, so this is the adaptation, not a redesign.
    """

    spec_objective: str
    actual_state: str
    gaps: list[DriftGap] = field(default_factory=list)
    severity: str = "none"

    def is_clean(self) -> bool:
        return not self.gaps

    def render_lines(self) -> list[str]:
        """The exact strings `find_deviations` would have produced, in order."""
        return [gap.render() for gap in self.gaps]

    @staticmethod
    def severity_for(gaps: list[DriftGap]) -> str:
        if not gaps:
            return "none"
        categories = {gap.category for gap in gaps}
        if categories & _HIGH_CATEGORIES:
            return "high"
        if categories & _MEDIUM_CATEGORIES:
            return "medium"
        return "low"

    @classmethod
    def from_deviations(cls, deviations: list[str]) -> "DriftReport":
        """Build a report from `find_deviations`'s existing list[str] output."""
        gaps = [DriftGap.parse(d) for d in deviations]
        return cls(
            spec_objective=(
                "SPEC.md's objective is filled in, any declared non-UI/real-time "
                "boundary holds against actual imports, and accepted ADRs "
                "reference the mission"
            ),
            actual_state="aligned" if not gaps else f"{len(gaps)} deviation(s) found",
            gaps=gaps,
            severity=cls.severity_for(gaps),
        )
