"""Command-line entry point for the preventive toolkit."""

from __future__ import annotations

import argparse
import subprocess
from pathlib import Path



def _run_make(target: str, *variables: str) -> int:
    """Run one documented Make target from the current project directory."""
    command = ["make", target, *(item for item in variables if item)]
    return subprocess.run(command, check=False).returncode


def _run_new(args: argparse.Namespace) -> int:
    from simplecode import cli_new
    return cli_new.main(args)


def _run_spec(args: argparse.Namespace) -> int:
    from simplecode import cli_spec
    return cli_spec.main(args)


def _run_push(args: argparse.Namespace) -> int:
    from simplecode import cli_push
    return cli_push.main(args)


def _run_adr(args: argparse.Namespace) -> int:
    from simplecode import cli_adr
    return cli_adr.main(args)


def _run_doctor(args: argparse.Namespace) -> int:
    from simplecode import doctor
    return doctor.main(["--json"] if args.json else [])


def _run_telemetry(args: argparse.Namespace) -> int:
    from simplecode.verification import gate_effectiveness
    argv = ["--html", ".simplecode/gate-effectiveness.html"] if args.html else []
    return gate_effectiveness.main(argv)


def _run_parity(_args: argparse.Namespace) -> int:
    from simplecode.worktree import staged_parity
    return staged_parity.main([])


def _run_claim(args: argparse.Namespace) -> int:
    from simplecode.worktree import claims
    argv = [str(args.path), "--ttl", str(args.ttl), "--root", str(args.root)]
    if args.owner:
        argv.extend(["--owner", args.owner])
    if args.claim_command:
        argv.extend(["--command", args.claim_command])
    return claims.main(argv)


def _run_debt(args: argparse.Namespace) -> int:
    from simplecode.guards import ponytail_debt
    argv = [str(p) for p in args.paths] if args.paths else []
    argv.extend(["--root", str(args.root)])
    if args.gate:
        argv.append("--gate")
    return ponytail_debt.main(argv)


def _run_ponytail(args: argparse.Namespace) -> int:
    from simplecode.verification import ponytail
    argv = ["--root", str(args.root)]
    for flag in ("gate", "include_tests", "tombstones"):
        if getattr(args, flag):
            argv.append(f"--{flag.replace('_', '-')}")
    if args.gain:
        argv.extend(["--gain", args.gain])
    return ponytail.main(argv)


def _run_route(args: argparse.Namespace) -> int:
    from simplecode.verification import workflow_router
    argv = ["--root", str(args.root)]
    if args.message_file:
        argv.extend(["--message-file", str(args.message_file)])
    return workflow_router.main(argv)


def _run_context_audit(args: argparse.Namespace) -> int:
    from simplecode.verification import context_audit
    return context_audit.main(["--root", str(args.root), *( ["--gate"] if args.gate else [])])


def _run_sanitize(args: argparse.Namespace) -> int:
    from simplecode.guards import injection_filter
    argv = [str(p) for p in args.paths] if args.paths else []
    return injection_filter.main(argv)


def _run_verify(args: argparse.Namespace) -> int:
    from simplecode.verification import dangling_refs
    argv = [str(p) for p in args.paths] if args.paths else []
    return dangling_refs.citation_lines_main(argv)


def _run_harvest(args: argparse.Namespace) -> int:
    from simplecode.verification import harvest_lens
    argv = [str(p) for p in args.paths] if args.paths else []
    return harvest_lens.main(argv)


def _run_fix(args: argparse.Namespace) -> int:
    from simplecode.verification import autofix
    argv = [
        "--root", str(args.root), "--max-rounds", str(args.max_rounds),
        *map(str, args.paths),
    ]
    return autofix.main(argv)


def _run_success_eval(args: argparse.Namespace) -> int:
    from simplecode.verification import success_evals
    try:
        response = args.report.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        print(f"[SUCCESS-EVAL] COULD_NOT_RUN: {exc}")
        return 1
    result = success_evals.evaluate_case(
        success_evals.EvalCase(
            name=args.report.name,
            response=response,
            trajectory=tuple(args.step),
            expected_valid=True,
        )
    )
    print(f"[SUCCESS-EVAL] {'PASS' if result.valid else 'BLOCKED'}: {args.report}")
    print(f"[SUCCESS-EVAL] reasons: {', '.join(result.reasons) if result.reasons else 'none'}")
    return 0 if result.valid else 1


def _run_sync_satellites(args: argparse.Namespace) -> int:
    from simplecode.satellite import satellite_sync
    argv = []
    if args.projects_dir:
        argv.extend(["--projects-dir", str(args.projects_dir)])
    if args.target:
        argv.extend(["--target", str(args.target)])
    if getattr(args, "apply", False) or getattr(args, "fix", False):
        argv.append("--apply")
    if getattr(args, "plan", False):
        argv.append("--plan")
    if getattr(args, "runtime_only", False):
        argv.append("--runtime-only")
    return satellite_sync.main(argv)


def _run_task_migration(args: argparse.Namespace) -> int:
    from simplecode.verification import task_migration
    argv = ["--root", str(args.root)]
    if args.apply:
        argv.append("--apply")
    return task_migration.main(argv)


def _run_chaos(args: argparse.Namespace) -> int:
    from simplecode.verification import chaos_monkey
    return chaos_monkey.main([])


def _run_gate_controls(args: argparse.Namespace) -> int:
    from simplecode.verification import detector_controls
    return detector_controls.main(["--gate"] if args.gate else [])


def _run_ratchet_audit(args: argparse.Namespace) -> int:
    from simplecode.verification import findings_ratchet
    argv = ["--root", str(args.root)]
    if args.gate:
        argv.append("--gate")
    if args.record:
        argv.extend(["--record", args.record[0], args.record[1]])
        argv.extend(["--description", args.description, "--source", args.source])
    if args.report:
        argv.append("--report")
    return findings_ratchet.main(argv)


def _run_telemetry_disposition(args: argparse.Namespace) -> int:
    from simplecode.verification import telemetry_dispositions
    argv = ["--root", str(args.root)]
    if args.migrate_legacy:
        argv.append("--migrate-legacy")
    if args.record:
        argv.extend(["--record", args.record[0], args.record[1]])
        argv.extend(["--evidence", args.evidence, "--source", args.source])
    if args.report:
        argv.append("--report")
    if args.gate:
        argv.append("--gate")
    if args.no_auto_dispose:
        argv.append("--no-auto-dispose")
    if args.declare_cutoff:
        argv.append("--declare-cutoff")
    return telemetry_dispositions.main(argv)


def _run_audit(args: argparse.Namespace) -> int:
    from simplecode.verification import audit_ledger
    argv = ["--root", str(args.root)]
    if args.extract_claims:
        argv.append("--extract-claims")
    if args.record:
        argv.append("--record")
    if args.panel:
        argv.extend(["--panel", args.panel])
    if args.results:
        argv.extend(["--results", str(args.results)])
    if args.profile:
        argv.extend(["--profile", args.profile])
    if args.gate:
        argv.append("--gate")
    if args.stale:
        argv.append("--stale")
    if args.merge:
        argv.append("--merge")
    return audit_ledger.main(argv)


def _run_angry_path(args: argparse.Namespace) -> int:
    from simplecode.guards import angry_path
    argv = ["--gate"] if args.gate else []
    if args.paths:
        argv.extend([str(p) for p in args.paths])
    return angry_path.main(argv)


def _run_hunt(args: argparse.Namespace) -> int:
    from simplecode.guards import orphan_hunter
    argv = ["--root", str(args.root)]
    for flag in ("gate", "json", "tombstones", "materialize"):
        if getattr(args, flag):
            argv.append(f"--{flag}")
    if args.include_tests:
        argv.append("--include-tests")
    return orphan_hunter.main(argv)


def _run_upstream_check(args: argparse.Namespace) -> int:
    from simplecode.guards import upstream_watch
    argv = []
    if args.root:
        argv.extend(["--root", str(args.root)])
    if args.fleet:
        argv.extend(["--fleet", str(args.fleet)])
    for flag in ("json", "materialize", "quarantine"):
        if getattr(args, flag):
            argv.append(f"--{flag}")
    if args.verify_reviewed:
        argv.extend(["--verify-reviewed", args.verify_reviewed])
    return upstream_watch.main(argv)


def _add_upstream_check_parser(subcommands) -> None:
    upstream = subcommands.add_parser(
        "upstream-check",
        help="Fork&own upstream watch (ADR-0009): report upstream movement; never auto-absorbs",
    )
    upstream.add_argument("--root", type=Path, default=None, help="Project root (default: cwd)")
    upstream.add_argument("--fleet", type=Path, default=None, help="Check every project under DIR")
    upstream.add_argument("--json", action="store_true", help="Machine-readable results")
    upstream.add_argument("--materialize", action="store_true",
                          help="File one backlog review task per moved upstream repo")
    upstream.add_argument("--quarantine", action="store_true",
                          help="Stage moved upstreams' compare + digest for review (ADR-0010)")
    upstream.add_argument("--verify-reviewed", metavar="OWNER/NAME", default=None,
                          help="Offline: exit 1 while OWNER/NAME's review is pending")


def _run_kit_drift_check(args: argparse.Namespace) -> int:
    from simplecode.guards import kit_drift_watch
    argv = ["--fleet", str(args.fleet)]
    if args.mother_root:
        argv.extend(["--mother-root", str(args.mother_root)])
    for flag in ("json", "materialize"):
        if getattr(args, flag):
            argv.append(f"--{flag}")
    return kit_drift_watch.main(argv)


def _add_kit_drift_check_parser(subcommands) -> None:
    drift = subcommands.add_parser(
        "kit-drift-check",
        help="Espejo de ADR-0009 para el kit propio: avisa cuando un satelite se atrasa "
             "de la madre, en vez de esperar a la proxima auditoria manual",
    )
    drift.add_argument("--fleet", type=Path, required=True, help="Check every satellite under DIR")
    drift.add_argument("--mother-root", type=Path, default=None,
                       help="Where the dead-man switch state is recorded (default: this kit's own repo)")
    drift.add_argument("--json", action="store_true", help="Machine-readable results")
    drift.add_argument("--materialize", action="store_true",
                       help="File one backlog task per drifted satellite, in ITS OWN tasks/backlog/")


def _add_hunt_parser(subcommands) -> None:
    # upstream-check and kit-drift-check ride here so cli.main() stays additive
    # without growing past its statement ceiling (same pattern as ratchet-audit
    # under _add_gate_controls_parser).
    _add_upstream_check_parser(subcommands)
    _add_kit_drift_check_parser(subcommands)
    hunt = subcommands.add_parser(
        "hunt",
        help="Dead-code & slop forensics (ADR-0004): orphans, zombies, ghost tasks, tombstones, ODS",
    )
    hunt.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    hunt.add_argument("--gate", action="store_true", help="Exit 1 on any orphan, ghost task, or could-not-run")
    hunt.add_argument("--json", action="store_true", help="Emit a structured JSON report")
    hunt.add_argument("--tombstones", action="store_true", help="Run the tombstone catalog engine")
    hunt.add_argument("--include-tests", action="store_true", help="Run the zombie fixture/helper sweeper")
    hunt.add_argument("--materialize", action="store_true", help="Write gating findings to tasks/backlog/")


def _add_chaos_and_audit_parsers(subcommands) -> None:
    subcommands.add_parser("chaos", help="Run Chaos Monkey fault injection and resilience harness")
    audit = subcommands.add_parser(
        "audit",
        help="Adversarial audit ledger (ADR-0006): extract claims, record ledger, freshness+green gate",
    )
    audit.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    audit.add_argument("--extract-claims", action="store_true", help="Emit SPEC claims as JSON")
    audit.add_argument("--record", action="store_true", help="Write a ledger from an audit results file")
    audit.add_argument("--panel", default=None, help="Who/what ran the panel (with --record)")
    audit.add_argument("--results", type=Path, default=None, help="Audit results JSON (with --record)")
    audit.add_argument("--profile", choices=("general", "security"), default=None,
                       help="Evidence profile to record or require")
    audit.add_argument("--gate", action="store_true", help="Verify a fresh, complete, green ledger; exit 1 if not")
    audit.add_argument("--stale", action="store_true",
                       help="Emit, as JSON, every claim that needs an audit now (unaudited, stale, failing)")
    audit.add_argument("--merge", action="store_true",
                       help="With --record: keep prior results whose per-claim seal still matches")


def _add_telemetry_parser(subcommands) -> None:
    telemetry = subcommands.add_parser("telemetry", help="Show gate effectiveness")
    telemetry.add_argument("--html", action="store_true", help="Write the HTML dashboard")


def _add_ratchet_audit_parser(subcommands) -> None:
    ratchet_audit = subcommands.add_parser(
        "ratchet-audit",
        help="H3 findings ratchet (ADR-0008): recorded defect classes stay gated forever",
    )
    ratchet_audit.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    ratchet_audit.add_argument(
        "--gate", action="store_true",
        help="Exit 1 if any recorded class's detector is missing or blind (broken ratchet)",
    )
    ratchet_audit.add_argument(
        "--record", nargs=2, metavar=("CLASS_ID", "DETECTOR_KEY"), default=None,
        help="Record a crystallization (refused unless the detector is live and convicting)",
    )
    ratchet_audit.add_argument("--description", default="", help="Human description of the defect class")
    ratchet_audit.add_argument("--source", default="audit", help="Origin of the finding: audit/ADR/session")
    ratchet_audit.add_argument("--report", action="store_true", help="Print the recorded-class table")


def _add_telemetry_disposition_parser(subcommands) -> None:
    td = subcommands.add_parser(
        "telemetry-disposition",
        help="DECL-GOV-080: durable disposition ledger for blocked telemetry rows",
    )
    td.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    td.add_argument(
        "--migrate-legacy", action="store_true",
        help="Give every legacy (no event_id) blocked row a durable content-addressed id",
    )
    td.add_argument(
        "--record", nargs=2, metavar=("EVENT_ID", "STATE"), default=None,
        help="Record a disposition (confirmed_defect/false_positive/controlled_canary), refused without --evidence",
    )
    td.add_argument("--evidence", default="", help="Evidence text (required with --record)")
    td.add_argument("--source", default="manual", help="Origin of the disposition (with --record)")
    td.add_argument("--report", action="store_true", help="Print the classification report")
    td.add_argument("--gate", action="store_true", help="Exit 1 if could_not_dispose > 0")
    td.add_argument(
        "--no-auto-dispose", action="store_true",
        help="Skip the evidence-based auto-disposition pass (diagnosis: see what a human still owes)",
    )
    td.add_argument(
        "--declare-cutoff", action="store_true",
        help=(
            "Declare this repo's disposition cutoff, writing the TRACKED "
            ".simplecode/telemetry_disposition_cutoff.json (DEBT-PUSH-LOOP-03: the gate READS it "
            "and reports COULD_NOT_RUN when absent -- it never writes it)"
        ),
    )


def _add_gate_controls_parser(subcommands) -> None:
    gate_controls = subcommands.add_parser(
        "gate-controls",
        help="H2 detector positive-control gate (ADR-0007): prove every detector convicts its own defect",
    )
    gate_controls.add_argument(
        "--gate", action="store_true",
        help="Exit 1 if any control is missing, blind, or false-positive",
    )
    # H3 (ADR-0008) rides in the same gate family; registered here so cli.main()
    # stays additive without growing past its statement ceiling.
    _add_ratchet_audit_parser(subcommands)
    _add_telemetry_disposition_parser(subcommands)


def _run_check_close_check(args: argparse.Namespace) -> int:
    from simplecode.verification import backlog_verifier
    timeout = [] if args.timeout is None else ["--timeout", args.timeout]
    return backlog_verifier.check_close_check_main(
        [args.cmd, "--expect", args.expect, "--root", str(args.root), *timeout]
    )


def _add_check_close_check_parser(subcommands) -> None:
    ccc = subcommands.add_parser(
        "check-close-check",
        help="Valida un close_check ANTES de escribir la ficha (mismo validador que el push)",
    )
    ccc.add_argument("cmd", help="El comando del close_check, entre comillas")
    ccc.add_argument("--expect", default="exit_zero", help="Criterio de exito (por defecto exit_zero)")
    ccc.add_argument("--root", type=Path, default=Path.cwd(), help="Raiz del repo")
    ccc.add_argument("--timeout", default=None,
                     help="close_check.timeout que declararia la ficha, en segundos")


def _add_success_eval_parser(subcommands) -> None:
    success_eval = subcommands.add_parser(
        "success-eval", help="Reject success reports that lack executed evidence"
    )
    success_eval.add_argument("report", type=Path, help="Report text or Markdown file")
    success_eval.add_argument(
        "--step", action="append", default=[], help="Ordered action step; repeat as needed"
    )


def _add_project_parsers(subcommands) -> None:
    from simplecode.worktree import claims

    new = subcommands.add_parser("new", help="Create a project with the preventive baseline")
    new.add_argument("name")
    new.add_argument("--package")
    new.add_argument("--type", choices=["library", "cli", "api"], default="library")

    spec = subcommands.add_parser("spec", help="Create or validate SPEC.md")
    spec.add_argument("spec_command", choices=["init", "check", "validate", "drift", "verify"])
    spec.add_argument("--timeout", type=float, default=900.0, help="Seconds per verify: command (spec verify)")
    spec.add_argument("--force", action="store_true")

    push = subcommands.add_parser("push", help="Apply the due version bump, commit it, then git push")
    push.add_argument("push_args", nargs=argparse.REMAINDER, help="Passed through to git push")

    adr = subcommands.add_parser("adr", help="Create or list architecture decisions")
    adr.add_argument("adr_command", choices=["new", "list"])
    adr.add_argument("title", nargs="?")

    _add_telemetry_parser(subcommands)

    doctor_cmd = subcommands.add_parser("doctor", help="Diagnose local setup")
    doctor_cmd.add_argument("--json", action="store_true", help="Emit machine-readable diagnostics")

    subcommands.add_parser("parity", help="Check staged files match working tree (staged parity)")

    claim_cmd = subcommands.add_parser(
        "claim",
        help="Record an ownership claim on a path (DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP)",
    )
    claim_cmd.add_argument("path", help="Repo-relative (or absolute) path being claimed")
    claim_cmd.add_argument(
        "--ttl", type=int, default=claims.DEFAULT_TTL_SECONDS, help="Seconds until the claim expires"
    )
    claim_cmd.add_argument(
        "--owner", default=None,
        help="Session/agent/generator identifier (default: SIMPLECODE_CLAIM_OWNER env var, then git user.name)",
    )
    claim_cmd.add_argument(
        "--command", dest="claim_command", default=None,
        # Explicit `dest`: the parent subparsers already own `dest="command"`
        # (which subcommand ran) on this same flat argparse Namespace. Naming
        # this flag's dest "command" too silently overwrote that with
        # whatever --command was (None, absent the flag) and every `simplecode
        # claim ...` invocation fell through to `_run_make(None)` instead of
        # `_run_claim` -- caught by test_cli_main_claim.
        help="Command that produced/will produce the write -- for generator claims, e.g. a broadcast job",
    )
    claim_cmd.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")


def _add_ponytail_parser(subcommands) -> None:
    ponytail = subcommands.add_parser("ponytail", help="Survey shortcuts and structural slop using Simplecode organs")
    ponytail.add_argument("--root", type=Path, default=Path.cwd())
    ponytail.add_argument("--gate", action="store_true")
    ponytail.add_argument("--include-tests", action="store_true")
    ponytail.add_argument("--tombstones", action="store_true")
    ponytail.add_argument("--gain", default=None, metavar="BASE")


def _add_route_parser(subcommands) -> None:
    route = subcommands.add_parser("route", help="Record harness-neutral flows selected from the staged diff")
    route.add_argument("--root", type=Path, default=Path.cwd())
    route.add_argument("--message-file", type=Path)


def _add_debt_parser(subcommands) -> None:
    debt = subcommands.add_parser("debt", help="Audit technical debt declarations for ceiling and trigger")
    debt.add_argument("paths", nargs="*", type=Path, help="Files to audit")
    debt.add_argument("--root", type=Path, default=Path.cwd())
    debt.add_argument("--gate", action="store_true")


def _add_context_audit_parser(subcommands) -> None:
    audit = subcommands.add_parser("context-audit", help="Validate harness-neutral context links and commands")
    audit.add_argument("--root", type=Path, default=Path.cwd())
    audit.add_argument("--gate", action="store_true")


def _add_sanitize_parser(subcommands) -> None:
    sanitize = subcommands.add_parser("sanitize", help="Sanitize prompt injection payloads from text files")
    sanitize.add_argument("paths", nargs="*", type=Path, help="Files to sanitize")


def _add_sync_parser(subcommands) -> None:
    sync_sat = subcommands.add_parser("sync-satellites", help="Plan, apply, or verify an explicit satellite kit revision")
    sync_sat.add_argument("--projects-dir", type=Path, default=None, help="Fleet directory")
    sync_sat.add_argument("--target", type=Path, default=None, help="Target specific satellite")
    sync_sat.add_argument("--plan", action="store_true", help="Report managed-file drift without writing")
    sync_sat.add_argument("--apply", action="store_true", help="Apply the selected kit revision explicitly")
    sync_sat.add_argument("--fix", action="store_true", help="Deprecated alias for --apply")
    sync_sat.add_argument("--runtime-only", action="store_true", help="Refresh runtime without changing tracked configuration")


def _add_fleet_audit_parsers(subcommands) -> None:
    fleet_cmd = subcommands.add_parser("fleet", help="Dynamic fleet inventory, census, and cross-project awareness")
    fleet_cmd.add_argument("--projects-dir", type=Path, default=Path.home() / "projects", help="Fleet root directory")
    fleet_cmd.add_argument("--json", action="store_true", help="Emit machine-readable JSON inventory")
    fleet_cmd.add_argument("--matrix", action="store_true", help="Emit Markdown fleet registry matrix")
    fleet_cmd.add_argument("--broadcast", "--sync", action="store_true", dest="broadcast", help="Broadcast fleet catalog to all satellites & Atlas")

    probe_cmd = subcommands.add_parser("probe", help="Run Tier 3 dynamic adversarial probes against project invariants")
    probe_cmd.add_argument("--root", type=Path, default=Path.cwd(), help="Target repository root")
    probe_cmd.add_argument("--gate", action="store_true", help="Exit nonzero if any probe fails")
    probe_cmd.add_argument("--json", action="store_true", help="Output results as JSON")

    redteam_cmd = subcommands.add_parser("redteam", help="Autonomous red-team adversarial evasion fuzzer (ADR-0012)")
    redteam_cmd.add_argument("--gate", action="store_true", help="Exit 1 if any synthesized evasion bypasses detection")

    sunset_cmd = subcommands.add_parser("sunset-audit", help="Audit legalized evasions for sunset-reviewed tags (ADR-0013)")
    sunset_cmd.add_argument("--root", type=Path, default=Path.cwd(), help="Repo root to audit")
    sunset_cmd.add_argument("--fleet", action="store_true", help="Audit mother + all satellite repos")
    sunset_cmd.add_argument("--satellite", type=Path, metavar="PATH", action="append",
                            help="Also audit this satellite path (repeatable)")
    sunset_cmd.add_argument("--gate", action="store_true", help="Exit 1 if any stale/untagged exemptions")


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="simplecode", description="Preventive toolkit for Python projects"
    )
    subcommands = parser.add_subparsers(dest="command", required=True)

    _add_project_parsers(subcommands)

    _add_debt_parser(subcommands)

    _add_ponytail_parser(subcommands)
    _add_route_parser(subcommands)
    _add_context_audit_parser(subcommands)

    _add_sanitize_parser(subcommands)

    verify = subcommands.add_parser("verify", help="Verify physical code and document citations")
    verify.add_argument("paths", nargs="*", type=Path, help="Markdown files to verify")

    harvest = subcommands.add_parser("harvest", help="Audit third-party library evaluations against Harvest Lens protocol")
    harvest.add_argument("paths", nargs="*", type=Path, help="Evaluation markdown files to audit")

    _add_success_eval_parser(subcommands)
    _add_check_close_check_parser(subcommands)

    _add_sync_parser(subcommands)

    task_migrate = subcommands.add_parser(
        "migrate-tasks", help="Plan or apply the canonical two-queue task migration"
    )
    task_migrate.add_argument("--root", type=Path, default=Path.cwd())
    task_migrate.add_argument("--apply", action="store_true", help="Move unambiguous legacy task files")

    _add_chaos_and_audit_parsers(subcommands)

    angry = subcommands.add_parser("angry-path", help="Audit codebase for silent error swallowing (Rule B3)")
    angry.add_argument("--gate", action="store_true", help="Exit 1 if findings exist")
    angry.add_argument("paths", nargs="*", type=Path, help="Files to audit")

    _add_gate_controls_parser(subcommands)

    _add_hunt_parser(subcommands)

    mat = subcommands.add_parser("materialize", help="Materialize untracked debt findings into physical tasks/backlog/ (DGX-169)")
    mat.add_argument("--fleet", type=Path, default=None, help="Fleet directory")
    mat.add_argument("--root", type=Path, default=Path.cwd(), help="Target repository")

    hchat = subcommands.add_parser("harvest-chat", help="Harvest conversational debt from session transcript (DGX-169)")
    hchat.add_argument("--transcript", type=Path, required=True, help="Path to transcript.jsonl")
    hchat.add_argument("--root", type=Path, default=Path.cwd(), help="Target repository")

    huni = subcommands.add_parser("harvest-universal", help="Universal transcript harvester across Claude, Gemini & Codex logs")
    huni.add_argument("--fleet", type=Path, default=Path.home() / "projects", help="Fleet root directory")
    huni.add_argument("--source", type=Path, nargs="*", default=None, help="Specific directories/files to scan")
    huni.add_argument("--dry-run", action="store_true", help="Report counts without writing files")

    _add_fleet_audit_parsers(subcommands)

    fix = subcommands.add_parser(
        "fix", help="Apply bounded Ruff fixes and re-run read-only critic checks"
    )
    fix.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    fix.add_argument("--max-rounds", type=int, default=3, help="Maximum fixer rounds")
    fix.add_argument(
        "paths", nargs="*", type=Path, help="Python files; default: changed files only"
    )

    for name in ("check", "mutate", "ratchet", "drift"):
        subcommands.add_parser(name)


    args = parser.parse_args()
    handlers = {
        "new": _run_new,
        "spec": _run_spec,
        "push": _run_push,
        "adr": _run_adr,
        "doctor": _run_doctor,
        "telemetry": _run_telemetry,
        "parity": _run_parity,
        "claim": _run_claim,
        "debt": _run_debt,
        "ponytail": _run_ponytail,
        "route": _run_route,
        "context-audit": _run_context_audit,
        "sanitize": _run_sanitize,
        "verify": _run_verify,
        "harvest": _run_harvest,
        "fix": _run_fix,
        "success-eval": _run_success_eval,
        "check-close-check": _run_check_close_check,
        "sync-satellites": _run_sync_satellites,
        "migrate-tasks": _run_task_migration,
        "chaos": _run_chaos,
        "gate-controls": _run_gate_controls,
        "ratchet-audit": _run_ratchet_audit,
        "telemetry-disposition": _run_telemetry_disposition,
        "audit": _run_audit,
        "angry-path": _run_angry_path,
        "hunt": _run_hunt,
        "upstream-check": _run_upstream_check,
        "kit-drift-check": _run_kit_drift_check,
        "fleet": lambda a: __import__("simplecode.satellite.fleet_inventory", fromlist=["main"]).main(
            ["--projects-dir", str(a.projects_dir)] + (["--json"] if a.json else []) + (["--matrix"] if a.matrix else []) + (["--broadcast"] if a.broadcast else [])
        ),
        "probe": lambda a: __import__("simplecode.verification.adversarial_probes", fromlist=["main"]).main(
            ["--root", str(a.root)] + (["--gate"] if a.gate else []) + (["--json"] if a.json else [])
        ),
        "redteam": lambda a: __import__("simplecode.verification.red_team", fromlist=["main"]).main(
            ["--gate"] if a.gate else []
        ),
        "sunset-audit": lambda a: __import__("simplecode.verification.sunset_audit", fromlist=["main"]).main(
            ["--root", str(a.root)]
            + (["--fleet"] if a.fleet else [])
            + (["--gate"] if a.gate else [])
            + ([item for sat in a.satellite for item in ("--satellite", str(sat))] if a.satellite else [])
        ),
        "materialize": lambda a: __import__("simplecode.worktree.debt_materializer", fromlist=["main"]).main(
            ["--fleet", str(a.fleet)] if a.fleet else ["--root", str(a.root)]
        ),
        "harvest-chat": lambda a: __import__(
            "simplecode.verification.universal_harvester", fromlist=["harvest_chat_transcript"]
        ).harvest_chat_transcript(a.transcript, a.root.parent),
        "harvest-universal": lambda a: __import__("simplecode.verification.universal_harvester", fromlist=["main"]).main(
            ["--fleet", str(a.fleet)] + (["--dry-run"] if a.dry_run else []) + (["--source"] + [str(s) for s in a.source] if a.source else [])
        ),
    }
    if args.command in handlers:
        return handlers[args.command](args)
    if args.command == "drift":
        from simplecode.worktree.drift import main as drift_main
        return drift_main()
    return _run_make(args.command)


if __name__ == "__main__":
    raise SystemExit(main())
