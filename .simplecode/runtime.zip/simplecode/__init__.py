"""simplecode package."""
from __future__ import annotations


def _warn_if_stale_zip_import() -> None:
    """Compatibility no-op after retiring lazy mother hot-pull.

    A runtime is now selected by ``.simplecode/kit.lock`` and verified by the
    portable runner before importing the bundle. Import-time comparison against
    a reachable mother checkout made the executed revision depend on a machine
    local working tree, so it has deliberately been removed.
    """
    return


_warn_if_stale_zip_import()
