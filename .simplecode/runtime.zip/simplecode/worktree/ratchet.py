#!/usr/bin/env python3
"""Monotonic-invariant ratchet: baseline debt, inverse tooling size, audit-log
growth anomaly, and a version floor, unified as one gated organ.

Four checks, one shared arming model:

  debt            A per-file metric baseline (default: line count) that new
                   debt cannot cross. Existing over-threshold files are
                   grandfathered at their recorded value; a file is a
                   violation only if it EXCEEDS threshold AND grew past (or
                   is new since) its baseline entry. Shrinking, staying
                   flat, or staying under threshold never blocks.

  tooling         Inverse ratchet over a script tree: total script count and
                   total LOC may only shrink or stay flat versus baseline,
                   never grow.

  test-ratio      Early-warning guard on test:product growth (2026-08-31,
                   prompted by "estamos gordos y lentos como Cerberus"):
                   flags when the test-code-lines-to-product-code-lines
                   ratio climbs past baseline by more than a tolerance in
                   one measurement AND product test code actually grew by a
                   real amount -- catches a pile of near-duplicate tests
                   landing at once without punishing ordinary incremental
                   growth, or a ratio spike from deleting product code with
                   no new test added.

  audit-growth    Early-warning guard: flags a tracked log/audit file whose
                   git-staged size jumps far past its HEAD size in a single
                   commit (self-duplicating writer, redoubled output) --
                   only when growth crosses BOTH an absolute and a relative
                   threshold, so a legitimate one-time import doesn't trip it.

  version-floor   Blocks when a separately pinned installation's semantic
                   version is older than the floor recorded in this
                   project's config. Comparison is semantic (1.10.0 > 1.9.0).

THE ARMING-MARKER LESSON (baked in, not bolted on):
A ratchet that silently passes while disarmed is indistinguishable, from its
own green output, from one that is actually enforcing anything -- that gap is
the measured defect this organ exists to close. So every check, on every run
(pass or fail), prints its own gate state explicitly: "armed" (a gate-marker
file is present -> violations exit non-zero) or "advisory" (marker absent ->
violations are reported but exit 0, "would block if armed"). Nothing here can
print a bare "OK" without also saying which state it was OK *as*.

Baselines are only ever written on an explicit --write-baseline; a check run
never mutates its own baseline as a side effect.

Standalone module: no repo-specific imports, no fleet-walking, no network.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from simplecode.entities import RatchetSnapshot
from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos

DEFAULT_LINE_THRESHOLD = 400
DEFAULT_TOOLING_SUBDIR = "scripts"
DEFAULT_TEST_SUBDIR = "tests"
DEFAULT_AUDIT_PATH = "audit/AUDIT_TRAIL.md"
MIN_ABSOLUTE_GROWTH_BYTES = 50_000
MIN_RELATIVE_GROWTH_FACTOR = 3.0

# How far the test:product code-line ratio may climb past its last recorded
# baseline before this check speaks up. NOT a measured constant like
# coverage_ratchet's NOISE_TOLERANCE (that one cites a specific observed
# noise band) -- this is a starting judgment call: simplecode's own ratio
# climbed 0.61 -> 0.85 over 12 days of legitimate growth (a
# verification/detection tool structurally needs a positive case AND a
# negative control per check), so the tolerance has to be loose enough to
# not fire on ordinary work between two `make ratchet` runs, tight enough
# to still catch a single push dumping a pile of near-duplicate tests.
# Adjust it (and re-baseline with --write-baseline) if it proves too loud
# or too quiet -- it is not load-bearing the way a coverage or zero-debt
# floor is.
TEST_RATIO_GROWTH_TOLERANCE = 0.03
# A ratio jump is only reported alongside REAL test growth -- otherwise a
# push that only deletes product code (which mechanically raises the ratio
# without a single test being added) would false-positive as "test bloat".
MIN_TEST_CODE_GROWTH_FOR_RATIO_CHECK = 100


# --------------------------------------------------------------------------
# Shared plumbing: gate state, JSON baseline load/write (used by debt and
# tooling -- both sources carried near-identical fail-closed loaders and
# mkdir-then-write savers; folded into one pair here).
# --------------------------------------------------------------------------

def gate_state(gate_marker: Optional[Path]) -> str:
    """"armed" if `gate_marker` is a path to a file that exists, else "advisory"."""
    return "armed" if (gate_marker and gate_marker.is_file()) else "advisory"


def load_json_baseline(path: Path) -> Optional[Dict[str, int]]:
    """Load a {str: int} baseline JSON, failing closed on any invalid input.

    Returns None if the file is missing, not valid JSON, not a JSON object,
    or any value can't be coerced to int -- callers must treat None as
    "cannot verify" and block, never as "no baseline recorded yet".
    """
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    try:
        return {str(k): int(v) for k, v in data.items()}
    except (TypeError, ValueError):
        return None


def write_json_baseline(path: Path, data: Dict[str, int]) -> None:
    """Write a baseline JSON durably (Axiom 13): this is the floor the whole
    gate suite is measured against, so a torn write must never silently
    lower it. Atomic replace + post-write hash verification, not a raw
    `write_text` that can leave a half-written file on crash.
    """
    atomic_io.write_text_durable(path, json.dumps(data, indent=2, sort_keys=True) + "\n")


def _head_sha(root: Path) -> Optional[str]:
    """`git rev-parse HEAD` for `root`, or None outside a repo / on any git failure."""
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "HEAD"],
            capture_output=True, text=True,
        )
    except OSError:
        return None
    if result.returncode != 0:
        return None
    sha = result.stdout.strip()
    return sha or None


def _now_iso() -> str:
    """Current UTC time, ISO 8601. Injected at the call site, not a hidden
    clock read deep in comparison logic -- this is repo-local provenance on
    a baseline file, not a ban this project places on itself elsewhere.
    """
    return datetime.now(timezone.utc).isoformat()


def load_tooling_snapshot(path: Path) -> Optional[RatchetSnapshot]:
    """Load the tooling ratchet's baseline as a RatchetSnapshot.

    Tolerates a legacy baseline file -- one written before RatchetSnapshot
    existed, carrying only `{scripts, loc, code}` with no provenance --
    by defaulting the missing `timestamp`/`head_sha` fields to None.
    Returns None (fail closed) if the file is missing, not valid JSON, or
    not a JSON object, exactly like `load_json_baseline`.
    """
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    try:
        return RatchetSnapshot.from_dict(data)
    except (TypeError, ValueError):
        return None


def write_tooling_snapshot(path: Path, snapshot: RatchetSnapshot) -> None:
    """Write the tooling ratchet's baseline durably, always in the enriched
    (provenance-carrying) shape -- a legacy file read via
    `load_tooling_snapshot` is upgraded to this shape the next time it is
    written, never re-written in the old shape.
    """
    atomic_io.write_text_durable(path, snapshot.to_json())


# --------------------------------------------------------------------------
# 1) debt: per-file metric baseline ratchet
# --------------------------------------------------------------------------

def scan_line_counts(root: Path, paths: List[str]) -> Optional[Dict[str, int]]:
    """Line count for every listed path that exists under `root`.

    Returns None if any listed path can't be read safely (I/O or decode
    error), so callers fail closed instead of gating on a partial scan.
    """
    counts: Dict[str, int] = {}
    for rel in paths:
        fpath = root / rel
        if not fpath.is_file():
            continue
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                counts[rel] = sum(1 for _ in f)
        except (OSError, UnicodeError):
            return None
    return counts


def discover_source_paths(root: Path) -> List[str]:
    """Every .py/.js file under `root`, as paths relative to `root`."""
    return sorted(
        str(p.relative_to(root))
        for p in root.rglob("*")
        if p.is_file() and p.suffix in (".py", ".js")
    )


def compare_debt_to_baseline(
    current: Dict[str, int],
    baseline: Dict[str, int],
    threshold: int = DEFAULT_LINE_THRESHOLD,
) -> List[str]:
    """Pure. Sorted list of files that count as NEW debt.

    A file is new debt if it exceeds `threshold` AND (it wasn't in the
    baseline, OR it grew past its recorded baseline value).
    """
    violations = [
        rel
        for rel, count in current.items()
        if count > threshold
        and (baseline.get(rel) is None or count > baseline[rel])
    ]
    return sorted(violations)


def debt_baseline_for_write(counts: Dict[str, int], threshold: int) -> Dict[str, int]:
    """Only the over-threshold files get grandfathered into a written baseline."""
    return {rel: n for rel, n in counts.items() if n > threshold}


def run_debt_check(
    root: Path,
    baseline_path: Path,
    threshold: int,
    write_baseline: bool,
    gate_marker: Optional[Path],
) -> int:
    state = gate_state(gate_marker)
    paths = discover_source_paths(root)
    counts = scan_line_counts(root, paths)
    if counts is None:
        # An I/O error scanning the source tree -- the check never got to look
        # at the subject at all, so this is an instrument failure, not a
        # verdict on any file. "debt BLOCKED" here would have made a downed
        # scanner indistinguishable from a real over-threshold file.
        print(
            "[growth-ratchet] COULD_NOT_RUN: debt check could not safely read "
            "the source tree (I/O or decode error while counting lines); "
            "nothing was compared.",
            file=sys.stderr,
        )
        return 1

    if write_baseline:
        write_json_baseline(baseline_path, debt_baseline_for_write(counts, threshold))
        over = sum(1 for n in counts.values() if n > threshold)
        print(f"debt baseline written (gate: {state}): {over} file(s) grandfathered into {baseline_path}")
        return 0

    baseline = load_json_baseline(baseline_path)
    if baseline is None:
        print(
            f"[growth-ratchet] COULD_NOT_RUN: debt baseline unreadable or missing: "
            f"{baseline_path}; nothing was compared (run with --write-baseline once "
            "to seed it).",
            file=sys.stderr,
        )
        return 1

    violations = compare_debt_to_baseline(counts, baseline, threshold)
    emit_hallazgos("[growth-ratchet]", len(violations))
    if not violations:
        print(f"debt passed (gate: {state}): no new debt")
        return 0

    armed = state == "armed"
    label = "debt BLOCKED" if armed else "debt ADVISORY (would block if armed)"
    print(f"{label} (gate: {state}):", file=sys.stderr)
    for rel in violations:
        print(f"  {rel}: {counts[rel]} lines (baseline: {baseline.get(rel, 'unrecorded')})", file=sys.stderr)
    print("  If growth is intentional, re-run with --write-baseline to update it.", file=sys.stderr)
    if armed:
        worst = max(violations, key=lambda rel: counts[rel])
        print(
            f"[growth-ratchet] FAIL: {len(violations)} fichero(s) crecieron sobre "
            f"el techo; el mayor {worst} {baseline.get(worst, 'unrecorded')} -> "
            f"{counts[worst]} lineas (techo {threshold})"
        )
    return 1 if armed else 0


# --------------------------------------------------------------------------
# 2) tooling: inverse ratchet -- tracked tree only shrinks
# --------------------------------------------------------------------------

def _code_lines(text: str) -> int:
    """Lines that are neither blank, nor a comment, nor a docstring body.

    Exists because a ceiling on TOTAL lines punishes the two things that made
    this kit trustworthy: the near-miss corpus and the in-code record of what
    each fix measured. Measured 2026-08-17 on simplecode -- 10,266 total lines in
    the product directories, 5,659 of them executable, 44% prose. A ratchet over
    the 10,266 would block the next measured comment; over the 5,659 it blocks
    exactly what the owner meant by "no quiero otro elefante blanco".
    """
    import io
    import tokenize
    prose = 0
    try:
        for tok in tokenize.generate_tokens(io.StringIO(text).readline):
            if tok.type == tokenize.COMMENT:
                prose += 1
            elif tok.type == tokenize.STRING and tok.line.strip().startswith(('"""', "'''")):
                prose += tok.string.count("\n") + 1
    except (tokenize.TokenError, IndentationError, SyntaxError):
        return len(text.splitlines())          # unreadable: count it all, never less
    blank = sum(1 for line in text.splitlines() if not line.strip())
    return max(0, len(text.splitlines()) - prose - blank)


def measure_tooling_tree(root: Path, subdir: str = DEFAULT_TOOLING_SUBDIR) -> Dict[str, int]:
    """Script count, total Python LOC, and executable code lines under root/subdir.

    `subdir` accepts several paths separated by commas, because a kit's product
    surface is not one directory: simplecode's is guards + verification + worktree
    + utils, and its tests are deliberately NOT on the ceiling.
    """
    files: List[Path] = []
    for part in (p.strip() for p in subdir.split(",") if p.strip()):
        files.extend(sorted((root / part).rglob("*.py")))
    files = sorted(set(files))
    total_loc = 0
    code = 0
    for path in files:
        text = path.read_text(encoding="utf-8")
        total_loc += len(text.splitlines())
        code += _code_lines(text)
    return {"scripts": len(files), "loc": total_loc, "code": code}


def compare_tooling_to_baseline(current: Dict[str, int], baseline: Dict[str, int]) -> List[str]:
    """Violations where a baselined metric increased.

    Iterates the BASELINE's keys, not a fixed tuple: a baseline recorded before
    `code` existed keeps ratcheting on scripts+loc exactly as before, and one
    recorded after ratchets on code too. Adding a metric must not silently
    re-arm an old baseline against a number it never measured.
    """
    return [
        f"{key}: {current.get(key, 0)} > {baseline[key]}"
        for key in ("scripts", "loc", "code")
        if key in baseline and current.get(key, 0) > baseline[key]
    ]


# --------------------------------------------------------------------------
# 2b) test-ratio: early-warning guard on test:product LOC growth
# --------------------------------------------------------------------------

def measure_test_ratio(root: Path, test_subdir: str, product_subdir: str) -> Dict[str, float]:
    """Executable-code-line counts for the test tree and the product tree,
    and their ratio -- `code` (comments/docstrings stripped, see
    `_code_lines`) rather than raw `loc`, so a heavily-documented detector
    doesn't skew the ratio by its prose alone."""
    test_metrics = measure_tooling_tree(root, test_subdir)
    product_metrics = measure_tooling_tree(root, product_subdir)
    test_code = test_metrics["code"]
    product_code = product_metrics["code"]
    ratio = (test_code / product_code) if product_code else 0.0
    return {"test_code": test_code, "product_code": product_code, "ratio": ratio}


def compare_test_ratio_to_baseline(current: Dict[str, float], baseline: Dict[str, float]) -> Optional[str]:
    """A violation message when the test:product ratio climbed past
    tolerance alongside real test growth, or None. Mirrors audit-growth's
    dual-threshold shape (see module docstring) for the same reason: one
    signal alone is too noisy, both together is a real anomaly."""
    test_code_growth = current["test_code"] - baseline.get("test_code", current["test_code"])
    if test_code_growth < MIN_TEST_CODE_GROWTH_FOR_RATIO_CHECK:
        return None
    baseline_ratio = baseline.get("ratio", current["ratio"])
    ratio_growth = current["ratio"] - baseline_ratio
    if ratio_growth <= TEST_RATIO_GROWTH_TOLERANCE:
        return None
    return (
        f"test:product code-line ratio jumped {baseline_ratio:.3f} -> {current['ratio']:.3f} "
        f"(+{ratio_growth:.3f}) alongside +{test_code_growth} test code lines since the last "
        f"baseline -- tests are growing faster than product code by more than this ratchet's "
        f"tolerance ({TEST_RATIO_GROWTH_TOLERANCE}). If the growth is deliberate (e.g. a new "
        "detector needing a real positive case and negative control), re-run with "
        "--write-baseline to accept the new ratio; otherwise look for near-duplicate coverage."
    )


def run_test_ratio_check(
    root: Path,
    subdirs: Tuple[str, str],
    baseline_path: Path,
    write_baseline: bool,
    gate_marker: Optional[Path],
) -> int:
    """`subdirs` is `(test_subdir, product_subdir)`, bundled into one
    parameter to keep this at 5 args like every other `run_*_check` here
    (PLR0913) rather than carrying the two subdir strings separately."""
    test_subdir, product_subdir = subdirs
    state = gate_state(gate_marker)
    try:
        current = measure_test_ratio(root, test_subdir, product_subdir)
    except (OSError, UnicodeError) as exc:
        print(
            f"[growth-ratchet] COULD_NOT_RUN: test-ratio check could not read "
            f"test/product trees: {exc}",
            file=sys.stderr,
        )
        return 1

    if write_baseline:
        payload = {**current, "timestamp": _now_iso(), "head_sha": _head_sha(root)}
        try:
            atomic_io.write_text_durable(baseline_path, json.dumps(payload, indent=2, sort_keys=True) + "\n")
        except (OSError, UnicodeError, atomic_io.WriteVerificationError) as exc:
            print(
                f"[growth-ratchet] COULD_NOT_RUN: could not write test-ratio baseline "
                f"{baseline_path}: {exc}",
                file=sys.stderr,
            )
            return 1
        print(f"test-ratio baseline written (gate: {state}): ratio={current['ratio']:.3f} "
              f"(test_code={current['test_code']}, product_code={current['product_code']})")
        return 0

    if not baseline_path.is_file():
        print(f"[growth-ratchet] COULD_NOT_RUN: test-ratio baseline missing: {baseline_path} "
              "(run with --write-baseline once to seed it). Nothing was "
              f"compared; the `{state}` mode governs the ratio check, not "
              f"this path.", file=sys.stderr)
        return 1
    try:
        baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(f"[growth-ratchet] COULD_NOT_RUN: test-ratio baseline unreadable or corrupt: "
              f"{baseline_path}: {exc}. Nothing was compared; the `{state}` "
              f"mode governs the ratio check, not this path.", file=sys.stderr)
        return 1
    if not isinstance(baseline, dict):
        print(
            f"[growth-ratchet] COULD_NOT_RUN: test-ratio baseline is not a JSON "
            f"object: {baseline_path}; nothing was compared.",
            file=sys.stderr,
        )
        return 1

    violation = compare_test_ratio_to_baseline(current, baseline)
    if violation:
        armed = state == "armed"
        label = "test-ratio BLOCKED" if armed else "test-ratio ADVISORY (would block if armed)"
        print(f"{label} (gate: {state}): {violation}", file=sys.stderr)
        if armed:
            print(f"[growth-ratchet] FAIL: test:product code-line ratio ratchet tripped: {violation}")
        return 1 if armed else 0

    print(f"test-ratio passed (gate: {state}): ratio={current['ratio']:.3f} "
          f"(test_code={current['test_code']}, product_code={current['product_code']})")
    return 0


def run_tooling_check(
    root: Path,
    subdir: str,
    baseline_path: Path,
    write_baseline: bool,
    gate_marker: Optional[Path],
) -> int:
    state = gate_state(gate_marker)
    try:
        current = measure_tooling_tree(root, subdir)
    except (OSError, UnicodeError) as exc:
        print(
            f"[growth-ratchet] COULD_NOT_RUN: tooling check could not read tree "
            f"{subdir!r}: {exc}",
            file=sys.stderr,
        )
        return 1

    if write_baseline:
        snapshot = RatchetSnapshot(
            scripts=current["scripts"], loc=current["loc"], code=current["code"],
            timestamp=_now_iso(), head_sha=_head_sha(root),
        )
        try:
            write_tooling_snapshot(baseline_path, snapshot)
        except (OSError, UnicodeError, atomic_io.WriteVerificationError) as exc:
            print(
                f"[growth-ratchet] COULD_NOT_RUN: could not write tooling baseline "
                f"{baseline_path}: {exc}",
                file=sys.stderr,
            )
            return 1
        print(f"tooling baseline written (gate: {state}): {current} (head {snapshot.head_sha}, at {snapshot.timestamp})")
        return 0

    # Absent and corrupt are different verdicts and were reported as one.
    # Measured in office2office 2026-09-01: the baseline simply did not exist
    # there and the gate said "unreadable or corrupt", sending the reader to look
    # for damage in a file that was never written. The `test-ratio` branch of
    # this same module already distinguished them and this branch did not -- two
    # halves of one file answering the same question differently.
    if not baseline_path.is_file():
        # COULD_NOT_RUN, not BLOCKED, and the mode is not printed as if it
        # governed. An absent baseline is an INSTRUMENT failure: nothing was
        # compared, so there is no verdict about the subject to report. Saying
        # BLOCKED made a downed instrument indistinguishable from a growing
        # tree -- the house rule, broken by the house, for the second time
        # today after `gate_runner` recorded rc=127 the same way.
        #
        # Reported by own_chats 2026-09-05, and it refuted a model of MINE:
        # I had been reasoning that an advisory organ exits 0 by construction.
        # It does not. `advisory` governs the GROWTH path only; the
        # instrument-down paths exit 1 whatever the mode, which is right --
        # failing toward blocking is the only honest direction when nothing
        # could be measured -- and the word was the part that lied.
        print(f"[growth-ratchet] COULD_NOT_RUN: tooling baseline missing: {baseline_path} "
              "(run with --write-baseline once to seed it). Nothing was "
              f"compared, so this is not a verdict about the tree. The "
              f"`{state}` mode governs the growth check, not this path.",
              file=sys.stderr)
        return 1
    snapshot = load_tooling_snapshot(baseline_path)
    if snapshot is None:
        print(f"[growth-ratchet] COULD_NOT_RUN: tooling baseline unreadable or corrupt: "
              f"{baseline_path}. Nothing was compared; the `{state}` mode "
              f"governs the growth check, not this path.", file=sys.stderr)
        return 1
    baseline = snapshot.to_dict()

    violations = compare_tooling_to_baseline(current, baseline)
    emit_hallazgos("[growth-ratchet]", len(violations))
    if violations:
        armed = state == "armed"
        label = "tooling BLOCKED" if armed else "tooling ADVISORY (would block if armed)"
        print(f"{label} (gate: {state}): " + "; ".join(violations), file=sys.stderr)
        if armed:
            print(f"[growth-ratchet] FAIL: {len(violations)} tooling metric(s) grew past baseline; first {violations[0]}")
        return 1 if armed else 0

    print(f"tooling passed (gate: {state}): {current}")
    return 0


# --------------------------------------------------------------------------
# 3) audit-growth: growth-anomaly guard on a tracked log file
# --------------------------------------------------------------------------

def _git_show_size(ref_and_path: str, cwd: Optional[Path] = None) -> Optional[int]:
    """Byte size of a path at a given git ref, or None if absent there."""
    result = subprocess.run(
        ["git", "cat-file", "-s", ref_and_path],
        capture_output=True, text=True, cwd=str(cwd) if cwd else None,
    )
    if result.returncode != 0:
        return None
    try:
        return int(result.stdout.strip())
    except ValueError:
        return None


def check_audit_growth(
    head_size: Optional[int],
    staged_size: Optional[int],
    min_absolute: int = MIN_ABSOLUTE_GROWTH_BYTES,
    min_relative: float = MIN_RELATIVE_GROWTH_FACTOR,
    tracked_path: str = DEFAULT_AUDIT_PATH,
) -> Optional[str]:
    """Pure decision: a violation message, or None if growth is unremarkable.

    Flags growth only when it crosses BOTH an absolute and a relative
    threshold, so a large one-time import doesn't false-positive alone.
    """
    if head_size is None or staged_size is None:
        return None  # new file or deleted -- not what this check is for
    growth = staged_size - head_size
    if growth <= 0 or growth < min_absolute:
        return None
    if head_size > 0 and (staged_size / head_size) < min_relative:
        return None
    return (
        f"{tracked_path} growth this commit is anomalous: "
        f"{head_size:,} -> {staged_size:,} bytes (+{growth:,}, "
        f"{(staged_size / head_size) if head_size else float('inf'):.1f}x) -- crosses the threshold "
        f"({min_absolute:,} bytes absolute AND {min_relative}x relative)."
    )


def run_audit_growth_check(
    repo_root: Path,
    tracked_path: str,
    gate_marker: Optional[Path],
) -> int:
    state = gate_state(gate_marker)
    exists_worktree = (repo_root / tracked_path).exists()
    head_size = _git_show_size(f"HEAD:{tracked_path}", cwd=repo_root)
    if not exists_worktree and head_size is None:
        print(f"audit-growth SKIPPED (gate: {state}): {tracked_path} does not exist in this repo.")
        return 0

    staged_size = _git_show_size(f":{tracked_path}", cwd=repo_root)
    violation = check_audit_growth(head_size, staged_size, tracked_path=tracked_path)
    if violation:
        armed = state == "armed"
        label = "audit-growth BLOCKED" if armed else "audit-growth ADVISORY (would block if armed)"
        print(f"{label} (gate: {state}): {violation}", file=sys.stderr)
        if armed:
            print(f"[growth-ratchet] FAIL: anomalous audit-log growth: {violation}")
        return 1 if armed else 0
    print(f"audit-growth passed (gate: {state}): {tracked_path} normal growth.")
    return 0


# --------------------------------------------------------------------------
# 4) version-floor: semantic version floor + a safe "raise the floor" op
#
# Differential folded in from the marginal bump_version.py: it bumps a
# semver string (major/minor/patch, preserving 2-part vs 3-part shape) and
# then propagates + git-tags across a whole file fleet. Only the semver
# bump arithmetic is the ~5% this ratchet needs -- adapted here into
# `raise_version_floor`, which bumps ONLY this project's own recorded floor
# (version_floor.json), never a pinned install's VERSION.txt, never other
# fleet files, and never runs `git tag`/`git push`. The fleet-propagation
# and git-tag-and-push mechanics are dropped: an inverse-shrink-only,
# read-mostly ratchet organ has no business rewriting a fleet of unrelated
# docs or pushing tags to origin as a side effect of a floor check.
# --------------------------------------------------------------------------

def parse_version(text: str) -> Tuple[int, int, int]:
    """Parse an "X.Y" or "X.Y.Z" string into a 3-tuple of ints.

    Non-digit suffixes are dropped rather than rejected ("0.6-dev" reads as
    (0, 6, 0)), and a missing component pads with zero.

    >>> parse_version("1.10.2")
    (1, 10, 2)
    >>> parse_version("0.6")
    (0, 6, 0)
    """
    parts: List[int] = []
    for chunk in text.strip().split("."):
        digits = ""
        for char in chunk:
            if char.isdigit():
                digits += char
            else:
                break
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return (parts[0], parts[1], parts[2])


def version_below(current: str, floor: str) -> bool:
    """True when `current` is strictly older than `floor`, compared semantically.

    >>> version_below("0.9", "0.10")
    True
    >>> version_below("0.6", "0.6")
    False
    """
    return parse_version(current) < parse_version(floor)


def pinned_requirements(requirements_path: Path) -> dict[str, str]:
    """Read exact package pins from a requirements file, ignoring directives."""
    try:
        lines = requirements_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError):
        return {}
    pins = {}
    for raw_line in lines:
        match = re.match(r"^\s*([A-Za-z0-9_.-]+)\s*==\s*([^\s;#]+)", raw_line)
        if match:
            pins[match.group(1).lower().replace("_", "-")] = match.group(2)
    return pins


def bump_version_string(version: str, part: str) -> str:
    """Increment one semver component, resetting components to its right.

    Accepts two-part (`X.Y`) or three-part (`X.Y.Z`) input and preserves
    that shape on output (bumping "1.4" minor returns "1.5", not "1.5.0").

    ADR-0013 rollover rule, extended to PATCH (2026-09-14, user request: "que
    siempre tenga números de 1 cifra"): a component reaching 10 rolls into the
    one to its left and resets to 0, cascading. The original rule only
    covered MINOR->MAJOR (3.9.x -> 4.0.0); PATCH now rolls into MINOR the
    same way (6.6.9 -> 6.7.0, not 6.6.10), and that MINOR increment cascades
    into MAJOR in turn if it also reaches 10 (6.9.9 -> 7.0.0, not 6.10.0).
    Keeps every digit single-decimal end to end, not just the first two.
    """
    if part not in ("major", "minor", "patch"):
        raise ValueError(f"Invalid part '{part}'. Must be 'major', 'minor', or 'patch'.")
    parts = version.split(".")
    while len(parts) < 3:
        parts.append("0")
    major, minor, patch = (int(p) for p in parts[:3])
    if part == "major":
        major, minor, patch = major + 1, 0, 0
    elif part == "minor":
        minor, patch = minor + 1, 0
    else:
        patch += 1
        if patch >= 10:  # ADR-0013 extended: PATCH rolls into MINOR
            minor, patch = minor + 1, 0
    if part in ("minor", "patch") and minor >= 10:  # ADR-0013: cascades into MAJOR
        major, minor = major + 1, 0
    bumped = f"{major}.{minor}.{patch}"
    return bumped if len(version.split(".")) == 3 else f"{major}.{minor}"



def _check_dependency_floors(dependency_floors: dict, project_root: Path) -> Optional[str]:
    pins = pinned_requirements(project_root / "requirements.txt")
    violations = []
    for name, floor in sorted(dependency_floors.items()):
        if not isinstance(name, str) or not isinstance(floor, str):
            continue
        current = pins.get(name.lower().replace("_", "-"))
        if current is not None and version_below(current, floor):
            violations.append(f"{name}=={current} is below required floor {floor}")
    if violations:
        return "Pinned dependency downgrade detected:\n  " + "\n  ".join(violations)
    return None


def check_version_floor(pinned_root: Path, project_root: Path) -> Optional[str]:
    """The blocking message for `project_root`, or None when nothing blocks."""
    config_file = project_root / "version_floor.json"
    if not config_file.is_file():
        return None
    try:
        config = json.loads(config_file.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(config, dict):
        return None

    dependency_floors = config.get("dependencies")
    if isinstance(dependency_floors, dict):
        return _check_dependency_floors(dependency_floors, project_root)

    floor = config.get("min_version")
    if not isinstance(floor, str) or not floor.strip():
        return None

    version_file = pinned_root / "VERSION.txt"
    if not version_file.is_file():
        return None
    try:
        current = version_file.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeError):
        return None
    if not current or not version_below(current, floor):
        return None

    return (
        f"Pinned installation at {pinned_root} is version {current}, older "
        f"than the required floor {floor} recorded in {config_file.name}.\n"
        "  Update the pinned installation, then retry."
    )


def raise_version_floor(config_path: Path, part: str) -> str:
    """Bump this project's OWN recorded floor (version_floor.json) by one
    semver part and write it back. Returns the new floor string.

    Scope is deliberately narrow versus bump_version.py's fleet-wide bump:
    touches only `config_path`, never a pinned install's VERSION.txt, never
    other fleet files, and never shells out to git.

    Written durably (Axiom 13): this is the state `run_version_floor_check`
    gates on, so a torn write must never silently lower or corrupt the
    floor. Atomic replace + post-write hash verification, not a raw
    `write_text` that can leave a half-written file on crash.
    """
    if config_path.is_file():
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            config = {}
    else:
        config = {}
    if not isinstance(config, dict):
        config = {}
    min_ver = config.get("min_version")
    current_floor: str = min_ver if isinstance(min_ver, str) else "0.0.0"
    new_floor = bump_version_string(current_floor, part)
    config["min_version"] = new_floor
    atomic_io.write_text_durable(config_path, json.dumps(config, indent=2, sort_keys=True) + "\n")
    return new_floor


def run_version_floor_check(
    pinned_root: Path,
    project_root: Path,
    gate_marker: Optional[Path],
    raise_floor_part: Optional[str],
) -> int:
    state = gate_state(gate_marker)
    config_path = project_root / "version_floor.json"

    if raise_floor_part:
        new_floor = raise_version_floor(config_path, raise_floor_part)
        print(f"version-floor raised (gate: {state}): {config_path} min_version -> {new_floor}")
        return 0

    message = check_version_floor(pinned_root, project_root)
    if message:
        armed = state == "armed"
        label = "version-floor BLOCKED" if armed else "version-floor ADVISORY (would block if armed)"
        print(f"{label} (gate: {state}): {message}", file=sys.stderr)
        if armed:
            print(f"[growth-ratchet] FAIL: version floor violated: {message}")
        return 1 if armed else 0
    print(f"version-floor passed (gate: {state})")
    return 0


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def _add_gate_arg(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--gate-marker", type=Path, default=None,
        help="Marker file whose presence arms this check (violations exit 1). "
             "Absent marker -> advisory (violations reported, exit 0).",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="check", required=True)

    p_debt = sub.add_parser("debt", help="Per-file metric baseline ratchet.")
    p_debt.add_argument("--root", type=Path, default=Path("."))
    p_debt.add_argument("--baseline", type=Path, default=Path("debt_baseline.json"))
    p_debt.add_argument("--threshold", type=int, default=DEFAULT_LINE_THRESHOLD)
    p_debt.add_argument("--write-baseline", action="store_true")
    _add_gate_arg(p_debt)

    p_tooling = sub.add_parser("tooling", help="Inverse ratchet: script count/LOC only shrinks.")
    p_tooling.add_argument("--root", type=Path, default=Path("."))
    p_tooling.add_argument("--subdir", default=DEFAULT_TOOLING_SUBDIR)
    p_tooling.add_argument("--baseline", type=Path, default=Path(".tooling_ratchet_baseline.json"))
    p_tooling.add_argument("--write-baseline", action="store_true")
    _add_gate_arg(p_tooling)

    p_test_ratio = sub.add_parser("test-ratio", help="Early-warning: test:product code-line ratio growth.")
    p_test_ratio.add_argument("--root", type=Path, default=Path("."))
    p_test_ratio.add_argument("--test-subdir", default=DEFAULT_TEST_SUBDIR)
    p_test_ratio.add_argument("--product-subdir", default=DEFAULT_TOOLING_SUBDIR)
    p_test_ratio.add_argument("--baseline", type=Path, default=Path(".test_ratio_baseline.json"))
    p_test_ratio.add_argument("--write-baseline", action="store_true")
    _add_gate_arg(p_test_ratio)

    p_audit = sub.add_parser("audit-growth", help="Flag anomalous growth of a tracked audit/log file.")
    p_audit.add_argument("--repo-root", type=Path, default=Path("."))
    p_audit.add_argument("--tracked-path", default=DEFAULT_AUDIT_PATH)
    _add_gate_arg(p_audit)

    p_version = sub.add_parser("version-floor", help="Block a pinned install older than the recorded floor.")
    p_version.add_argument("--pinned-root", type=Path, required=False, default=Path("."))
    p_version.add_argument("--root", type=Path, default=Path("."))
    p_version.add_argument("--raise-floor", choices=["major", "minor", "patch"], default=None,
                            help="Instead of checking, bump this project's own recorded floor and write it.")
    _add_gate_arg(p_version)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.check == "debt":
        return run_debt_check(
            args.root.resolve(), args.baseline, args.threshold, args.write_baseline, args.gate_marker,
        )
    if args.check == "tooling":
        return run_tooling_check(
            args.root.resolve(), args.subdir, args.baseline, args.write_baseline, args.gate_marker,
        )
    if args.check == "test-ratio":
        return run_test_ratio_check(
            args.root.resolve(), (args.test_subdir, args.product_subdir),
            args.baseline, args.write_baseline, args.gate_marker,
        )
    if args.check == "audit-growth":
        return run_audit_growth_check(args.repo_root.resolve(), args.tracked_path, args.gate_marker)
    if args.check == "version-floor":
        return run_version_floor_check(
            args.pinned_root.resolve(), args.root.resolve(), args.gate_marker, args.raise_floor,
        )
    return 1  # pragma: no cover -- argparse `required=True` makes this unreachable


if __name__ == "__main__":
    sys.exit(main())
