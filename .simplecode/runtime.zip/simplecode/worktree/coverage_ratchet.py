# -*- coding: utf-8 -*-
"""coverage_ratchet.py -- Strict monotonic coverage ratchet guard.

Enforces that test coverage never regresses below the recorded watermark.
When coverage improves, it advances the watermark, establishing a new floor.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from simplecode.utils import atomic_io

WATERMARK_FILE = ".coverage_watermark"
DEFAULT_FLOOR = 100.0

# Percentage points of ordinary run-to-run coverage measurement noise the
# gate absorbs before treating a drop as a real regression. Reported live
# by Atlas (2026-08-26), one push blocked after the 2-decimal-rounding fix
# above still shipped: watermark read 53.89, a full clean run measured
# 53.870174% -- a genuine ~0.02-point swing between two runs over the SAME
# unchanged code, wider than sub-hundredth rounding noise but still not a
# real regression (no test was removed, no line went uncovered on purpose).
# This is a deliberate, auditable BUDGET for that noise, not a loosened
# floor: a drop bigger than this still fails, and the watermark itself
# never moves down on its own -- only --reset (an explicit, human action)
# can lower it. The tradeoff this accepts: a genuine regression smaller
# than the tolerance does not fail on its own single push; it has to
# accumulate past the band, or be caught by the coverage number itself
# being watched over time, not by this one gate.
NOISE_TOLERANCE = 0.5


def read_watermark(root: Path) -> float:
    """Read the current coverage watermark percentage."""
    wm_path = root / WATERMARK_FILE
    if not wm_path.is_file():
        return DEFAULT_FLOOR
    try:
        return float(wm_path.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return DEFAULT_FLOOR


def write_watermark(root: Path, value: float) -> None:
    """Persist the new coverage watermark durably (Axiom 13): this is the
    floor the whole gate suite is measured against, so a torn write must
    never silently lower it. Atomic replace + post-write hash verification.
    """
    wm_path = root / WATERMARK_FILE
    atomic_io.write_text_durable(wm_path, f"{value:.2f}\n")


def evaluate_coverage(current_cov: float, root: Path, advance: bool = False, gate: bool = False) -> tuple[bool, str]:
    """Evaluate current coverage against watermark.

    Compares at the SAME precision the watermark is actually persisted at
    (`write_watermark` stores `f"{value:.2f}"`) instead of raw floats against
    a fixed 0.001 epsilon. Reported live by Atlas (2026-08-26), 3 consecutive
    runs over the SAME unchanged code: run 1 measured 53.87 -> 53.88 (a real
    hundredth-point improvement, correctly advances); run 2 then reported
    "dropped from watermark 53.88% to 53.88%" -- FAIL, with both numbers
    printing identical, because the raw unrounded floats differed by less
    than a hundredth (ordinary test-run measurement noise, not a real
    regression) and the old 0.001 epsilon was too tight to absorb it. Worse,
    `.coverage_watermark` is a git-TRACKED file: every spurious "advance"
    this noise triggered rewrote it, and pre-commit's own dirty-tree check
    (which only looks at tracked paths -- the same mechanism behind the
    DGX-228 incident in `gate_runner._log_gate_failure`) then reported the
    NEXT hook as "files were modified", rejecting the push outright even
    though every semantic gate was green. Rounding both sides before
    comparing means two runs that measure the same coverage at the
    precision that's actually persisted never write the file at all -- only
    a genuine >= 0.01-point change ever touches disk. A drop bigger than
    that but still within `NOISE_TOLERANCE` is reported as OK (measurement
    noise) and never written -- only a drop beyond the tolerance band, or a
    genuine improvement, ever changes anything.
    """
    watermark = round(read_watermark(root), 2)
    current = round(current_cov, 2)

    if current < watermark - NOISE_TOLERANCE:
        msg = (
            f"[coverage-ratchet] FAIL: Coverage dropped from watermark {watermark:.2f}% "
            f"to {current:.2f}% (beyond the {NOISE_TOLERANCE:.2f}-point noise tolerance)!"
        )
        return False, msg

    if current > watermark:
        if advance:
            write_watermark(root, current)
            msg = f"[coverage-ratchet] ADVANCED: Watermark raised from {watermark:.2f}% to {current:.2f}%."
        else:
            # ADVANCE PENDING, not a quiet OK. Reported by the descargaSAT
            # session 2026-09-05 with the reproduction and its negative control
            # in one experiment: the gate printed `Failed` and
            # `ADVANCED: Watermark raised from 26.26% to 26.29%` in the SAME
            # run. The semantic verdict was green -- coverage rose and the
            # ratchet recorded it -- and what made it red was pre-commit's
            # dirty-tree check, because `.coverage_watermark` is git-TRACKED
            # and the hook rewrote it mid-run. Retrying passed, because the
            # watermark was already advanced.
            #
            # That is the worst shape a red can have: it teaches "a failing
            # gate is fixed by running it again", which is exactly the
            # anti-loop rule's forbidden lesson, and it fires ONLY when
            # somebody IMPROVES coverage -- punishing the one behaviour the
            # ratchet exists to reward. In a repo with CI, a red that vanishes
            # on retry is never investigated.
            #
            # They ruled out measurement noise by measuring, not by reading:
            # six direct runs gave 26.2860 to four decimals with zero variance,
            # and NOISE_TOLERANCE puts the failure band at < 25.76.
            msg = (f"[coverage-ratchet] ADVANCE PENDING: {watermark:.2f}% -> {current:.2f}%. "
                   f"Not written -- this gate judges, it does not record. Run "
                   f"`python -m simplecode.verification.coverage_target --advance` to lock it in.")
    elif current == watermark:
        msg = f"[coverage-ratchet] OK: Current coverage {current:.2f}% meets watermark {watermark:.2f}%."
    else:
        msg = (
            f"[coverage-ratchet] OK: Current coverage {current:.2f}% is within the "
            f"{NOISE_TOLERANCE:.2f}-point noise tolerance of watermark {watermark:.2f}% "
            "(not a regression, not written)."
        )

    return True, msg


def extract_coverage_from_json(json_path: Path) -> float | None:
    """Extract total coverage percentage from coverage.json report."""
    if not json_path.is_file():
        return None
    try:
        data = json.loads(json_path.read_text(encoding="utf-8"))
        return float(data.get("totals", {}).get("percent_covered", 0.0))
    except (json.JSONDecodeError, KeyError, ValueError, OSError):
        return None


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Enforce monotonic coverage ratchet.")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--coverage-json", type=Path, default=Path("coverage.json"))
    ap.add_argument("--current", type=float, default=None, help="Explicit current coverage percentage.")
    ap.add_argument("--advance", action="store_true", help="Advance watermark if current coverage is higher.")
    ap.add_argument("--gate", action="store_true", help="Exit 1 if coverage dropped below watermark.")
    ap.add_argument(
        "--reset",
        type=float,
        default=None,
        metavar="PERCENT",
        help=(
            "Overwrite the watermark to PERCENT regardless of direction, then exit. "
            "For correcting a watermark seeded before this gate ever actually ran "
            "(satellite_sync only ever wrote it once, at first sync, to whatever "
            "coverage.json happened to exist then -- a value nothing enforced or "
            "corrected until this gate existed), not for lowering a floor that was "
            "genuinely earned."
        ),
    )
    args = ap.parse_args(argv)

    root = args.root.resolve()

    if args.reset is not None:
        write_watermark(root, args.reset)
        print(f"[coverage-ratchet] RESET: watermark forced to {args.reset:.2f}% (was not derived from a measured run)")
        return 0

    current_cov = args.current
    if current_cov is None:
        json_path = args.coverage_json if args.coverage_json.is_absolute() else root / args.coverage_json
        current_cov = extract_coverage_from_json(json_path)

    if current_cov is None:
        print("[coverage-ratchet] ERROR: Could not determine current coverage (coverage.json missing or unparseable).", file=sys.stderr)
        return 1 if args.gate else 0

    ok, msg = evaluate_coverage(current_cov, root, advance=args.advance, gate=args.gate)
    print(msg)
    if not ok and args.gate:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
