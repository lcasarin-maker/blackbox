# -*- coding: utf-8 -*-
"""claim_guard.py -- pre-commit check: staged paths vs foreign active claims
(DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP).

`own_chats`/Twiner's ask for the first half of the OWNS law (CLAUDE.md
"Staging"): compare rutas STAGEADAS contra claims AJENOS and print the ones
that collide -- the `git diff --cached` a human reads by hand today, done by
a hook instead. This is a printer by design, not a blocker: `claims.claim()`
is advisory ("ni siquiera un lock" -- see claims.py), so colliding with a
foreign claim means another owner said they were mid-work on this exact path,
which is worth surfacing before the commit lands, not proof the write itself
is wrong. `--gate` turns that into a block for a caller who wants one; wired
into `.pre-commit-config.yaml` without `--gate`, matching the `observe` /
`growth-ratchet` informational-gate shape.

The SECOND half of the OWNS law ("si ya lo cometiste, NO reviertas, avisa al
dueno") has no AUTOMATED cross-session channel here -- `SendMessage`-style
routing exists only inside an agent session's own tools, not as something a
`language: system` git-hook subprocess can reach, and that gap is real and
stays undocumented-as-solved. What `--post-commit` below DOES provide is the
honest degraded version: the human at the keyboard IS a channel, just not an
automated one. Printing "you just committed over X's claim, tell them" to
the terminal the instant it happens is a real instrument -- worse than
automation, better than silence, and it is what "avisa al dueno" reduces to
when the automated half cannot exist yet.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.git_utils import git_committed_files, git_diff_name_only, git_status_paths
from simplecode.worktree import claims


def foreign_collisions(
    *,
    owner: str,
    root: Path,
    claims_path: Path | None = None,
    now: datetime | None = None,
) -> list[dict]:
    """Staged paths that carry an ACTIVE claim from an owner other than `owner`.

    Reads ONLY the staged set (`git diff --cached --name-only`), the same
    "judges what the commit introduces" scoping `corruption-guard --staged`
    already uses -- a repo-wide sweep would flag paths this commit never
    touches, which is exactly the freeze `corruption-guard`'s own docstring
    describes hitting once already.
    """
    now = now or datetime.now(timezone.utc)
    staged = git_diff_name_only(root, cached=True)
    if not staged:
        return []
    collisions = []
    for path in staged:
        entry = claims.find_claim(path, root=root, claims_path=claims_path, now=now)
        if entry is not None and entry.get("owner") != owner:
            collisions.append(entry)
    return collisions


def foreign_modified_files(
    *,
    owner: str,
    root: Path,
    claims_path: Path | None = None,
    now: datetime | None = None,
) -> list[dict]:
    """Every path in the WORKING TREE (staged, unstaged, or untracked) that
    carries an active claim from an owner other than `owner`.

    DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP (Twiner, item d): a SessionStart
    summary needs the full tree, not just what a commit would introduce --
    a session just starting has usually staged nothing yet. Deliberately a
    SEPARATE function from `foreign_collisions` rather than a parameter on
    it: that one's staged-only scope is the correct, permanent contract for
    its pre-commit purpose, not an accident of not having asked broader yet.
    """
    now = now or datetime.now(timezone.utc)
    changed = git_status_paths(root)
    if not changed:
        return []
    collisions = []
    for path in changed:
        entry = claims.find_claim(path, root=root, claims_path=claims_path, now=now)
        if entry is not None and entry.get("owner") != owner:
            collisions.append(entry)
    return collisions


def foreign_claims_in_commit(
    *,
    owner: str,
    root: Path,
    ref: str = "HEAD",
    claims_path: Path | None = None,
    now: datetime | None = None,
) -> list[dict]:
    """Paths a SPECIFIC commit changed that carry an active claim from an
    owner other than `owner`.

    DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP, second half of the OWNS law ("si ya
    lo cometiste, avisa al dueno"): `foreign_collisions` looks at the
    STAGED set, which is gone by the time a `post-commit` hook runs -- this
    looks at what `ref` (the commit that JUST landed) actually changed, via
    `git_committed_files`, so a post-commit hook can still say what happened
    even though the index has already moved on.
    """
    now = now or datetime.now(timezone.utc)
    changed = git_committed_files(ref, root)
    if not changed:
        return []
    collisions = []
    for path in changed:
        entry = claims.find_claim(path, root=root, claims_path=claims_path, now=now)
        if entry is not None and entry.get("owner") != owner:
            collisions.append(entry)
    return collisions


def _format_collision(entry: dict, *, now: datetime) -> str:
    claimed_at = datetime.fromisoformat(str(entry["claimed_at"]))
    if claimed_at.tzinfo is None:
        claimed_at = claimed_at.replace(tzinfo=timezone.utc)
    age = now - claimed_at
    minutes = max(int(age.total_seconds() // 60), 0)
    command = entry.get("command")
    suffix = f", cmd: {command}" if command else ""
    return f"{entry['path']}: claimed by {entry['owner']} ({minutes} min ago{suffix})"


def _run_summary(*, owner: str, root: Path, now: datetime) -> int:
    """`--summary` mode: foreign claims over the FULL working tree, one line.

    ALWAYS returns 0, COULD_NOT_RUN included -- see the `--summary` help text:
    this is a SessionStart banner, and a banner that can fail a session start
    is worse than no banner. The exit code is the contract, not an accident;
    `test_claim_guard.py` pins each mode's code separately for that reason.
    """
    try:
        found = foreign_modified_files(owner=owner, root=root, now=now)
    except claims.ClaimsError as exc:
        print(f"[claim-guard] COULD_NOT_RUN: {exc}")
        return 0
    if not found:
        return 0
    detail = "; ".join(_format_collision(entry, now=now) for entry in found)
    print(f"[claim-guard] arbol de {root}: {len(found)} archivo(s) modificado(s) ajeno(s): {detail}")
    return 0


def _run_post_commit(*, owner: str, root: Path, ref: str, now: datetime) -> int:
    """`--post-commit` mode: foreign claims in the commit that JUST landed.

    ALWAYS returns 0, COULD_NOT_RUN included: the commit already happened, so
    there is nothing left to block -- only a human to notify.
    """
    try:
        found = foreign_claims_in_commit(owner=owner, root=root, ref=ref, now=now)
    except claims.ClaimsError as exc:
        print(f"[claim-guard] COULD_NOT_RUN: {exc}")
        return 0
    if not found:
        return 0
    print(f"[claim-guard] AVISO: este commit ({ref}) escribio sobre "
          f"{len(found)} ruta(s) con claim ajeno activo -- avisa al dueno:")
    for entry in found:
        print(f"  - {_format_collision(entry, now=now)}")
    return 0


def _run_staged_check(*, owner: str, root: Path, now: datetime, gate: bool) -> int:
    """Default pre-commit mode: STAGED paths against foreign active claims.

    The only mode with three DISTINCT exit codes, and they must stay distinct:
    2 = COULD_NOT_RUN (the claims file could not be read, so nothing was
    judged), 1 = a real collision under `--gate`, 0 = judged clean (or judged
    colliding without `--gate`, the informational-gate shape). Collapsing 2
    into 1 would report "there is a collision" when the truth is "nothing was
    measured"; collapsing 1 into 0 would hide a real one.
    """
    try:
        collisions = foreign_collisions(owner=owner, root=root, now=now)
    except claims.ClaimsError as exc:
        print(f"[claim-guard] COULD_NOT_RUN: {exc}")
        return 2

    if not collisions:
        print(f"[claim-guard] OK: no staged path collides with a foreign active claim (as {owner}).")
        emit_hallazgos("[claim-guard]", 0)
        return 0

    print(f"[claim-guard] {len(collisions)} staged path(s) collide with a foreign claim (as {owner}):")
    for entry in collisions:
        print(f"  - {_format_collision(entry, now=now)}")
    emit_hallazgos("[claim-guard]", len(collisions))
    return 1 if gate else 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Compare staged paths against foreign active claims (OWNS, CLAUDE.md)"
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--owner", default=None,
        help="This commit's identifier (default: SIMPLECODE_CLAIM_OWNER env var, then git user.name)",
    )
    parser.add_argument("--gate", action="store_true", help="Exit 1 on any foreign collision")
    parser.add_argument(
        "--summary", action="store_true",
        help=(
            "Report foreign claims over the FULL working tree (staged, unstaged, "
            "untracked), one line, for a SessionStart-style banner -- not the "
            "staged-only pre-commit check. Never exits nonzero: informational only."
        ),
    )
    parser.add_argument(
        "--post-commit", action="store_true",
        help=(
            "OWNS law, second half ('avisa al dueno'): report foreign claims in the "
            "commit that JUST landed (--ref, default HEAD), so a human can relay the "
            "notice -- the only channel that exists for this today. Never exits "
            "nonzero: the commit already happened, there is nothing left to block."
        ),
    )
    parser.add_argument("--ref", default="HEAD", help="Commit to inspect with --post-commit")
    args = parser.parse_args(argv)

    owner = claims.resolve_owner(args.owner, args.root)
    now = datetime.now(timezone.utc)

    if args.summary:
        return _run_summary(owner=owner, root=args.root, now=now)
    if args.post_commit:
        return _run_post_commit(owner=owner, root=args.root, ref=args.ref, now=now)
    return _run_staged_check(owner=owner, root=args.root, now=now, gate=args.gate)


if __name__ == "__main__":
    raise SystemExit(main())
