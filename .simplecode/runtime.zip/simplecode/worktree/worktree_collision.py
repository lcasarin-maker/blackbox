# -*- coding: utf-8 -*-
"""worktree_collision.py -- Detect overlapping modifications and collisions across active git worktrees (DGX-232).

Prevents concurrent agents and parallel worktrees from modifying the same files
or working on identical branches, avoiding race conditions and silent code loss.
"""
from __future__ import annotations

import argparse
import json
import logging
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class WorktreeInfo:
    """Metadata for one active git worktree."""

    path: str
    head: str
    branch: str = ""
    is_bare: bool = False
    is_locked: bool = False
    is_detached: bool = False
    modified_files: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class WorktreeCollision:
    """A collision detected between two active worktrees."""

    collision_type: str  # "FILE_OVERLAP" | "DUPLICATE_BRANCH"
    worktree_a: str
    branch_a: str
    worktree_b: str
    branch_b: str
    details: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# `git worktree list --porcelain` is a flat key/value stream: one `worktree <path>`
# line opens a record, later keys add to it, a BLANK line closes it, and the last
# record is closed by end-of-input with no blank line at all. That last detail is
# why this was written twice inline -- the closing block appeared once for the
# blank-line case and once again after the loop, and a field added to one copy and
# not the other would have silently produced two different shapes of WorktreeInfo
# from the same stream. It is one function now, called from both places.
_PORCELAIN_FLAGS = ("bare", "locked", "detached")


def _parse_porcelain_entries(stdout: str) -> list[dict[str, Any]]:
    """Every record in a `git worktree list --porcelain` stream, as raw dicts.

    Kept separate from `_worktree_info` because this half knows only git's
    grammar -- no filesystem is touched here, which is what makes it testable
    without a repo on disk.
    """
    entries: list[dict[str, Any]] = []
    current: dict[str, Any] = {}
    for raw in stdout.splitlines():
        line = raw.strip()
        if not line:
            if current.get("worktree"):
                entries.append(current)
            current = {}
            continue
        key, _, val = line.partition(" ")
        if key == "worktree":
            current["worktree"] = val
        elif key == "HEAD":
            current["HEAD"] = val
        elif key == "branch":
            current["branch"] = val.replace("refs/heads/", "")
        elif key in _PORCELAIN_FLAGS:
            current[key] = True
    # End of input closes the final record: git emits no trailing blank line.
    if current.get("worktree"):
        entries.append(current)
    return entries


def _worktree_info(entry: dict[str, Any]) -> WorktreeInfo:
    """One parsed porcelain record as a `WorktreeInfo`.

    The modified-file read is attempted only for a path that is a directory on
    THIS machine: a worktree git still lists but whose directory is gone would
    otherwise make `git status` fail once per record.
    """
    wt_path = Path(entry["worktree"])
    return WorktreeInfo(
        path=str(wt_path.resolve()),
        head=entry.get("HEAD", ""),
        branch=entry.get("branch", ""),
        is_bare=entry.get("bare", False),
        is_locked=entry.get("locked", False),
        is_detached=entry.get("detached", False),
        modified_files=get_worktree_modified_files(wt_path) if wt_path.is_dir() else [],
    )


def list_active_worktrees(repo_root: Path) -> list[WorktreeInfo]:
    """Parse active git worktrees using `git worktree list --porcelain`."""
    repo_root = repo_root.resolve()
    try:
        res = subprocess.run(
            ["git", "worktree", "list", "--porcelain"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        logger.warning("Could not execute git worktree: %s", exc)
        return []

    if res.returncode != 0:
        return []

    return [_worktree_info(e) for e in _parse_porcelain_entries(res.stdout)]


def get_worktree_modified_files(worktree_path: Path) -> list[str]:
    """Retrieve list of modified/staged files in a worktree."""
    if not (worktree_path / ".git").exists() and not (worktree_path / ".git").is_file():
        return []
    try:
        res = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=worktree_path,
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return []

    if res.returncode != 0:
        return []

    modified: list[str] = []
    for line in res.stdout.splitlines():
        if len(line) > 3:
            # line is 'XY path' or 'XY orig -> path'
            file_path = line[3:].strip().split(" -> ")[-1]
            modified.append(file_path)
    return sorted(set(modified))


def detect_collisions(repo_root: Path) -> list[WorktreeCollision]:
    """Detect overlapping files or duplicate active branches among active worktrees."""
    worktrees = list_active_worktrees(repo_root)
    if len(worktrees) < 2:
        return []

    collisions: list[WorktreeCollision] = []
    n = len(worktrees)

    for i in range(n):
        for j in range(i + 1, n):
            wt_a = worktrees[i]
            wt_b = worktrees[j]

            # 1. Duplicate active branch check
            if wt_a.branch and wt_b.branch and wt_a.branch == wt_b.branch:
                collisions.append(
                    WorktreeCollision(
                        collision_type="DUPLICATE_BRANCH",
                        worktree_a=wt_a.path,
                        branch_a=wt_a.branch,
                        worktree_b=wt_b.path,
                        branch_b=wt_b.branch,
                        details=[f"Both worktrees checkout the same branch '{wt_a.branch}'"],
                    )
                )

            # 2. Overlapping modified files check
            overlap = sorted(set(wt_a.modified_files) & set(wt_b.modified_files))
            if overlap:
                collisions.append(
                    WorktreeCollision(
                        collision_type="FILE_OVERLAP",
                        worktree_a=wt_a.path,
                        branch_a=wt_a.branch,
                        worktree_b=wt_b.path,
                        branch_b=wt_b.branch,
                        details=overlap,
                    )
                )

    return collisions


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Detect file overlap and collisions across active git worktrees (DGX-232)."
    )
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Git repository root")
    parser.add_argument("--gate", action="store_true", help="Exit nonzero if collisions are detected")
    parser.add_argument("--json", action="store_true", help="Emit findings as JSON")
    args = parser.parse_args(argv)

    collisions = detect_collisions(args.root)

    if args.json:
        print(json.dumps([c.to_dict() for c in collisions], indent=2, ensure_ascii=False))
        return 1 if (collisions and args.gate) else 0

    if not collisions:
        print("[worktree-collision] OK: No worktree overlaps or collisions detected.")
        return 0

    print(f"\033[31m[worktree-collision] FOUND {len(collisions)} WORKTREE COLLISION(S):\033[0m")
    for c in collisions:
        print(f"  - [{c.collision_type}] Between {Path(c.worktree_a).name} ({c.branch_a}) and {Path(c.worktree_b).name} ({c.branch_b})")
        for d in c.details:
            print(f"      • {d}")

    return 1 if args.gate else 0


if __name__ == "__main__":
    sys.exit(main())
