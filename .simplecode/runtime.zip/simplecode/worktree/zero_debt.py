#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""zero_debt -- the ratchet with no grandfathering: not one finding may stand.

The owner's policy (2026-08-16): zero debt, small, medium or large, and nothing
gets grandfathered. This is that policy made mechanical, and it is the SAME
ratchet algebra `ratchet.py` already ships -- `compare_debt_to_baseline` is pure
and metric-agnostic, taking file -> count. Point it at findings-per-file with an
EMPTY baseline and a threshold of zero and "existing debt is frozen" becomes
"no debt exists", with no second implementation to drift.

Why an explicit baseline argument survives at all under a zero policy: the same
function, given today's counts as the baseline, answers a different and still
useful question -- "did THIS change add anything?" -- which is what a pre-commit
lane needs while the standing debt is being paid down. The policy is zero; the
path to zero is not instantaneous, and a gate that cannot express the path gets
turned off. That is how the ancestor died.

  --mode zero      (default) any finding at all is a violation
  --mode no-growth compares against a baseline file; only NEW findings violate

Usage:
    python3 zero_debt.py --root REPO [--mode zero|no-growth] [--baseline F]
                         [--write-baseline] [--gate]
Exit 0: policy satisfied.  Exit 1 (with --gate): violated.
"""
from __future__ import annotations

import argparse
import functools
import importlib
import inspect
import json
import re
import subprocess
import sys
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from typing import Any, NamedTuple

import yaml

from simplecode.entities import Finding
from simplecode.utils.atomic_io import write_text_durable
from simplecode.utils.gate_signal import emit_detectores, emit_hallazgos
from simplecode.utils.tool_limits import GIT_O1_TIMEOUT

HERE = Path(__file__).resolve().parent
# Kit root: the directory containing guards/, verification/, worktree/
# In this repo it's src/simplecode/; when installed it may differ.
_KIT_CANDIDATES = [
    HERE.parent,                    # src/simplecode/ (this repo)
    HERE.parent.parent,             # project root (if run from there)
    HERE.parent / "simplecode",     # alternative layout
]
KIT = next((p for p in _KIT_CANDIDATES if (p / "guards").is_dir()), HERE.parent)

# EMPTY, and that is the result of work rather than an oversight. Three
# detectors were excluded here by name because they fired on 59.6%, 24.8% and
# 20.9% of the fleet, and feeding one into a debt policy reproduces the
# 2,523-ticket burial that killed the ancestor of this lane. On 2026-08-16 all
# three were taken apart instead of carried:
#
#   incomprehensible_code    RETIRED -- it was the docstring nag itself.
#   hallucinated_dependency  RETIRED -- guards/dependency_guard.py already does
#                            this correctly, with the scanned repo's own
#                            requirements instead of this interpreter's.
#   ambiguous_handoff        FIXED -- 97.6% of its hits came from the bare word
#                            `status`; now 0.1% of the fleet, battery 5/5.
#
# An exclusion list is a debt, not a feature: every name on it is a vice the
# policy silently forgives. Keep it empty; if a name has to go back, it goes
# back loudly and with its measurement, the way these three left.
HIGH_VOLUME_EXCLUDED: tuple[str, ...] = ()

# The detectors this gate judges: real-behaviour defects plus two precise
# test-truth checks. Voted by Luis 2026-09-27 on the product verdict
# `docs/gate_audit_2026-09-26/veredicto_producto/zero-debt-repo.md` (RECORTAR);
# test-truth checks were restored after the 2026-09-29 audit proved tests were
# excluded from the gate entirely.
# Remaining detectors -- process labels (`untracked_prototype`, `invisible_debt`, ...)
# and style (`frozen_nomenclature`, `premature_abstraction`, ...) -- stay in the
# registries because red_team, detector_controls, finding_backlog,
# backlog_verifier, hardening_proposal and findings_detail_ratchet read them;
# they no longer block a push. Shared by `--staged` and the repo-wide lane: it
# is one gate at two moments, and two selections would let one lane condemn
# what the other forgives. An id that disappears from the registry is reported
# as COULD_NOT_RUN by `scan_all_detectors`, never dropped in silence.
GATE_DETECTORS: frozenset[str] = frozenset({
    "hardcoded_secret", "unsafe_eval", "insecure_defaults", "optimistic_config",
    "blind_except", "silent_io_loop_swallow", "poisonous_empty_fallback",
    "unhandled_error_continuation", "mutable_default_argument",
    "unmanaged_resource_open", "non_atomic_file_overwrite", "blocking_sleep",
    "deadlock_without_heartbeat", "destructive_without_dryrun",
    "destructive_action_without_confirmation", "io_without_validation",
    "blind_trust_in_llm_output", "unencoded_file_io", "hardcoded_path",
    "data_exfiltration", "excessive_agency", "unhandled_tool_call_failure",
    "test_without_assert", "assert_true",
})

# Paths whose whole purpose is to CONTAIN the vice. A labeled fixture that no
# longer trips its detector has stopped being a fixture, so holding it to a
# zero-debt policy would delete the corpus that proves the detectors work.
# Scoped by path, and narrow: this exempts test fixtures, never source.
#
# ANCHORED at the repo root. The old markers matched ANYWHERE in the path
# (`"tests/fixtures/" in rel`, `"/fixtures/near_miss/" in rel`), so moving a
# production module to `src/tests/fixtures/app.py` or
# `src/fixtures/near_miss/app.py` turned CONVICTED into EXEMPT_FIXTURE with
# rc=0 -- the atajo of DEBT-GATE-ENGANABLE-ZERO-DEBT-REPO (audit 2026-09-26).
# Measured 2026-09-27 over every checkout under ~/projects: the only `.py`
# under either marker are simplecode's 10 `tests/fixtures/near_miss/`, all at
# the root, so the anchor exempts the same files it exempted before.
# NAMED LIMIT: a module placed in the root `tests/fixtures/` and imported from
# product code would still pass; nothing checks who imports a fixture.
FIXTURE_ROOT = "tests/fixtures/"


def is_fixture(rel: str) -> bool:
    return rel.replace("\\", "/").startswith(FIXTURE_ROOT)


def _load_corpus_exempt_list(root: Path, key: str) -> tuple[str, ...]:
    """A list-of-strings value under one `.simplecode/corpus_exempt.yaml`
    key, normalized to forward slashes. Absent file/key/malformed value ->
    empty, never an error -- shared by every corpus_exempt.yaml list key in
    this module (`vendored_paths`, `vendored_path_prefixes`)."""
    config = root / ".simplecode" / "corpus_exempt.yaml"
    if not config.is_file():
        return ()
    try:
        data = yaml.safe_load(config.read_text(encoding="utf-8")) or {}
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return ()
    if not isinstance(data, dict):
        return ()
    values = data.get(key, [])
    if not isinstance(values, list):
        return ()
    return tuple(str(v).replace("\\", "/") for v in values if isinstance(v, str) and v.strip())


@functools.lru_cache(maxsize=8)
def _load_vendored_paths(root: Path) -> tuple[str, ...]:
    """Project-local, opt-in EXACT paths of third-party code a satellite
    vendors and must not edit (same pattern as corpus_exempt.yaml's
    corruption_guard_prefixes / coverage_targets keys).

    Read from ``<root>/.simplecode/corpus_exempt.yaml``, key
    ``vendored_paths``. Absent file/key -> no exemptions, so every project
    (including this one) keeps zero_debt's strict default untouched.

    EXACT path was the original default over a directory prefix (measured
    on Atlas, 2026-08-25: `playbooks/` findings moved 3->1 and 29->11 on two
    files under that directory the same day). Re-measured 2026-08-26, on
    Atlas's own request, with the actual claim under test: not "does this
    directory hold real Atlas code" but "were those two files THEMSELVES
    authored by Atlas or vendored". They were not -- both are upstream
    NVIDIA `.py` files that Atlas had EDITED in place to pass this gate (0
    of 118 `.py` under `playbooks/` are Atlas-authored; the incident's "real
    code" was Atlas's own patches layered onto vendored files, which forked
    50 of the 118 from upstream). Once editing vendored files is the thing
    being stopped, per-file exactness no longer buys anything a directory
    prefix doesn't -- see `vendored_path_prefixes` below for the declared,
    measured-safe alternative for a directory that is ENTIRELY vendored.
    """
    return _load_corpus_exempt_list(root, "vendored_paths")


@functools.lru_cache(maxsize=8)
def _load_vendored_path_prefixes(root: Path) -> tuple[str, ...]:
    """Project-local, opt-in directory PREFIXES that are ENTIRELY vendored
    (every file under them is a byte-for-byte-editable-only third-party
    copy, none Atlas/project-authored) -- same shape as `dangling_refs`'s
    `foreign_corpus_prefixes`.

    Read from ``<root>/.simplecode/corpus_exempt.yaml``, key
    ``vendored_path_prefixes``. Absent file/key -> no exemptions.

    Declaring a prefix here is a claim the caller must have MEASURED, not
    assumed: `vendored_paths` (exact-path) stays the default precisely
    because a mixed directory silently loses real findings under a prefix.
    A prefix entry is safe only once someone has confirmed, file by file
    (e.g. diffing against the vendor's own upstream tree), that nothing
    under it is project-authored.
    """
    return _load_corpus_exempt_list(root, "vendored_path_prefixes")


# DEBT-FLEET-VENDORED-RUNPY-HARDCODED-TIMEOUT-FALSE-POSITIVE (RePic,
# 2026-09-08): `.simplecode/run.py` is generated by THIS kit's own
# `_portable_runner()` and shipped byte-identical to every satellite that
# hot-pulls it -- a hardcoded `timeout=5` in it is a value reviewed once, in
# the mother, not a per-satellite invariant to re-litigate. Every one of the
# 17 satellites had to discover this and declare it in their OWN
# corpus_exempt.yaml independently (RePic measured it live) -- exactly the
# duplicated work a kit-wide default should absorb once, here, rather than
# 17 times downstream. `runtime.zip` is not listed: it is a zip archive, never
# matched by a `.py`-scoped detector in the first place.
_KIT_VENDORED_PATHS = frozenset({".simplecode/run.py"})


def is_vendored(root: Path, rel: str) -> bool:
    """True iff `rel` is declared, by exact path or by declared prefix, in
    .simplecode/corpus_exempt.yaml, or is one of this kit's own always-vendored
    generated files (see `_KIT_VENDORED_PATHS`)."""
    rel = rel.replace("\\", "/")
    return (
        rel in _KIT_VENDORED_PATHS
        or rel in _load_vendored_paths(root)
        or rel.startswith(_load_vendored_path_prefixes(root))
    )


# The scanner's own source IS the vocabulary of the vice: the line that defines
# the eval pattern matches the eval pattern. Measured 2026-08-17, the first
# commit that touched `guards/pattern_detectors.py` after this gate went
# blocking: 17 findings across 2 files, 17 of them the corpus convicting itself
# (`danger/hardcoded_credentials` on `_SECRET_HINTS`, `threat/prompt_injection`
# on the fixture that proves prompt_injection fires). Every commit to the
# scanner was entering with --no-verify, and a bypass nobody decided is how a
# gate switches itself off.
#
# NOT a path list -- that is the mechanism that killed the predecessor. Three
# conditions, all checked: the file DECLARES itself corpus with a written
# reason, the repo being scanned IS the kit, and the count is PRINTED on every
# run. In any other repo the marker does nothing at all.
CORPUS_MARK = re.compile(r"#\s*simplecode:corpus\s+(\S.*)")

# Los marcadores de bloque se arman por concatenación para que el fuente de ESTE
# archivo nunca contenga el marcador que busca: al escanearse a sí mismo, un
# literal completo hacía que mask_corpus_code enmascarara sus propias líneas de
# código y produjera fuente imparseable (medido 2026-08-23: IndentationError en
# la línea 191, que el parseo ruidoso convirtió en COULD_NOT_RUN — antes salía
# PASSED en silencio).
_CORPUS_TAG = "# simplecode:" + "corpus"
_CORPUS_START = _CORPUS_TAG + ":start"
_CORPUS_END = _CORPUS_TAG + ":end"

# Authorized paths within Simplecode that legitimately declare detector/threat vocabulary.
# In any external satellite repository or unauthorized path, the marker is ignored
# and the file is held to strict zero-debt inspection.
AUTHORIZED_CORPUS_PREFIXES = (
    "src/simplecode/guards/pattern_detectors.py",
    "src/simplecode/guards/agent_threats.py",
    "src/simplecode/guards/injection_filter.py",
    "src/simplecode/verification/success_evals.py",
    "src/simplecode/verification/transcript_acquire.py",
    "guards/pattern_detectors.py",
    "guards/agent_threats.py",
    "guards/injection_filter.py",
    "verification/success_evals.py",
    "verification/transcript_acquire.py",
    "tests/",
    "fixtures/",
)


# Detectors whose PATTERN collides with the vice vocabulary these files carry as
# data. Measured 2026-09-01 by running every detector over the five authorised
# paths: exactly these twelve fire, and they do so because those files spell
# out the very strings the detectors hunt for.
#
# Twelve, not eight. The first cut of this list measured with
# `pd.PATTERN_DETECTORS` alone while the gate builds its registry from
# `PATTERN_DETECTORS` + `AGENT_THREAT_DETECTORS` minus `HIGH_VOLUME_EXCLUDED`
# (66 detectors). Four collisions in `agent_threats.py` and `injection_filter.py`
# were invisible to the smaller registry -- measuring the wrong instrument, one
# more time, inside the fix for a gate that could not measure.
#
# Everything NOT on this list still runs. That is the whole point, and the
# reason this list exists at all: whole-file exemption made these paths a zone
# of impunity. Reported as CONV-DEBT-015E1C7D798F and confirmed here with a
# planted control -- `time.sleep(5)` and `open(path, "w")` without encoding,
# appended to `pattern_detectors.py`, produced `violations: 0` and rc=0. Neither
# vice is vocabulary; neither detector is on this list; both are now convicted.
CORPUS_COLLIDING_DETECTORS = frozenset({
    "blanket_filterwarnings",
    "gate_relaxation_tamper",
    "invisible_debt",
    "prompt_injection",
    "simulated_or_stub_implementation",
    "tool_poisoning_homoglyph",
    "tool_poisoning_invisible",
    "tool_poisoning_mixed_script",
    "untracked_prototype",
})


def _is_authorized_corpus_path(rel: str) -> bool:
    norm = rel.replace("\\", "/")
    return any(norm == auth or norm.startswith(auth) or norm.endswith(auth)
               for auth in AUTHORIZED_CORPUS_PREFIXES)


def _authoritative_kit_repo() -> Path | None:
    """The kit's own repo root, robust to zipimport.

    `KIT`/`HERE` come from `Path(__file__).resolve()`. When this module loads
    from source that already IS a real, on-disk `src/simplecode/` (the
    ordinary editable-install case), `KIT` needs nothing further. But when it
    loads via the portable `.simplecode/run.py` launcher -- `zipimport` out of
    a bundled `runtime.zip` -- `__file__` resolves to a path INSIDE the
    archive (e.g. `.../runtime.zip/simplecode/worktree`), which has no
    `guards/` sibling on any real filesystem, so `_KIT_CANDIDATES` never
    matches. That silently killed corpus self-exemption everywhere the kit
    runs portably: every satellite, AND every worktree of the mother doing
    kit development in that mode -- measured directly (2026-09-07):
    `zero_debt.KIT` inside such a worktree resolved to
    `.../runtime.zip/simplecode`, an unopenable path, so a legitimately
    corpus-marked `pattern_detectors.py` convicted itself on its own
    vocabulary and blocked a real commit.

    Falls back to the same on-workstation "mother repo" convention
    `.simplecode/run.py`'s own hot-pull and `doctor._runtime_freshness`
    already use, rather than inventing a second one.
    """
    if (KIT / "guards").is_dir():
        return KIT.parent if KIT.parent.name != "src" else KIT.parent.parent
    candidate = Path.home() / "projects" / "simplecode"
    if (candidate / "src" / "simplecode" / "guards").is_dir():
        return candidate
    return None


def _git_common_dir(path: Path) -> Path | None:
    """The `.git` directory `path` shares with every OTHER worktree of the
    same physical repository, or None if `path` is not a git repo / git is
    unavailable. Unlike `.git` itself (a private pointer file inside a
    worktree), `--git-common-dir` is the one thing that is identical across
    the main checkout and all its worktrees, which is exactly the equality
    a worktree-aware "is this repo the kit" check needs."""
    try:
        proc = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "--path-format=absolute", "--git-common-dir"],
            capture_output=True, text=True, timeout=GIT_O1_TIMEOUT, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if proc.returncode != 0 or not proc.stdout.strip():
        return None
    try:
        return Path(proc.stdout.strip()).resolve()
    except OSError:
        return None


def _root_is_the_kit(root: Path) -> bool:
    """Whether `root` is the kit's own repository -- the primary checkout,
    OR one of its own git worktrees (same physical repo, different working
    directory). The worktree case matters here specifically: every
    `.claude/worktrees/agent-*` checkout used to develop simplecode's own
    kit code IS such a worktree, and its commits deserve the exact same
    corpus self-exemption the primary checkout gets.

    Three tiers, cheapest first:
      1. Plain path equality (`root` IS `KIT`/its repo) -- the original,
         zero-cost check, unchanged for the common case.
      2. Git-repo identity against `kit_repo` itself, via `--git-common-dir`
         -- correct whenever `KIT` resolves to a real, if arbitrary, git
         checkout and `root` is one of ITS worktrees (the ordinary case:
         `python -m simplecode...` importing the main checkout while `--root`
         names a `.claude/worktrees/<name>` sibling).
      3. Git-repo identity against `_authoritative_kit_repo()` -- the tier
         that matters when `KIT` itself is not a usable filesystem path at
         all (zipimport from `.simplecode/run.py`'s bundled `runtime.zip`),
         so tier 2's own comparison point is meaningless.
    """
    try:
        kit_root = KIT.resolve()
        kit_repo = kit_root.parent.parent if kit_root.parent.name == "src" else kit_root
        resolved_root = root.resolve()
    except OSError:
        return False
    if resolved_root in (kit_root, kit_repo):
        return True
    common_root = _git_common_dir(root)
    if common_root is not None and common_root == _git_common_dir(kit_repo):
        return True
    authoritative = _authoritative_kit_repo()
    if authoritative is None:
        return False
    if resolved_root == authoritative.resolve():
        return True
    return common_root is not None and common_root == _git_common_dir(authoritative)


def declares_corpus(root: Path, rel: str) -> str:
    """The reason this file declares for being the vice's own vocabulary, or ""."""
    if not _is_authorized_corpus_path(rel):
        return ""
    if not _root_is_the_kit(root):
        return ""
    try:
        # Read from `root`, never from `KIT`: by this point `root` IS the kit
        # (or one of its own worktrees), so its own copy of the file is the
        # correct -- and only ever real, filesystem-openable -- one to read,
        # whether `KIT` itself resolved to a source tree or to a zip-internal
        # path this process could never open directly.
        with (root / rel).open(encoding="utf-8", errors="replace") as fh:
            head = [next(fh, "") for _ in range(40)]
    except (OSError, ValueError):
        return ""
    for line in head:
        m = CORPUS_MARK.search(line)
        if m:
            return (m.group(1) or "corpus").strip()
    return ""


def _load(path: Path):
    try:
        package_module = {
            "pattern_detectors.py": "simplecode.guards.pattern_detectors",
            "agent_threats.py": "simplecode.guards.agent_threats",
            "ratchet.py": "simplecode.worktree.ratchet",
        }[path.name]
    except KeyError as exc:
        raise ImportError(f"Unknown Simplecode organ: {path}") from exc
    return importlib.import_module(package_module)


def _drop_merge_inherited(root: Path, staged: list[str]) -> list[str]:
    """En un merge, deja sólo los archivos que difieren de AMBOS padres.

    `git diff --cached` compara el índice contra `HEAD`, o sea contra el padre
    al que se está mergeando. En un commit normal eso es exactamente el cambio
    del autor; en un commit de MERGE no lo es: todo archivo que cambió del lado
    del OTRO padre y no dio conflicto entra al índice tal cual, sin que quien
    corrió `git commit --no-edit` lo tocara. Comparado contra `HEAD` sale como
    "staged", y el carril de commit acaba juzgando a quien mergea por deuda que
    escribió alguien más.

    Medido en Atlas el 2026-08-31 (worktree `agent-a28f814fbe584386d`, merge de
    `master` sobre una rama de trabajo): `git commit --no-edit` salió BLOCKED con
    7 violaciones, y `git diff --cached master` sobre esos mismos 7 archivos daba
    0 líneas de diff -- byte a byte idénticos al padre que entraba. Los 6
    archivos que quien mergeaba SÍ tocó en ese commit traían cero violaciones
    entre todos.

    El criterio de responsabilidad es diferir de los dos padres: un blob
    idéntico a `HEAD` o idéntico a `MERGE_HEAD` no lo produjo este merge, ni
    auto-mergeado ni resuelto a mano. Intersección de los dos diffs, dos
    llamadas de plumbing, sin estructura nueva.

    Si el segundo diff no se puede correr, se devuelve el conjunto ENTERO sin
    recortar: la ausencia de la medición nunca absuelve, y un gate que se
    achica solo cuando su instrumento falla es peor que uno que sobra-reporta.
    """
    merge = subprocess.run(["git", "rev-parse", "-q", "--verify", "MERGE_HEAD"],
                           cwd=root, capture_output=True, text=True)
    if merge.returncode != 0:
        return staged
    otro = subprocess.run(
        ["git", "diff", "--no-relative", "--cached", "--name-only", "--diff-filter=ACM",
         "MERGE_HEAD", "--", "*.py"],
        cwd=root, capture_output=True, text=True,
    )
    if otro.returncode != 0:
        print("[zero-debt] merge commit: no se pudo diffear contra MERGE_HEAD "
              f"({otro.stderr.strip() or 'sin stderr'}); no se recorta el carril.")
        return staged
    difieren_del_otro = {p for p in otro.stdout.splitlines() if p.strip()}
    propios = [p for p in staged if p in difieren_del_otro]
    # Reporting politics: un gate no achica su propio alcance en silencio.
    if excluidos := len(staged) - len(propios):
        print(f"[zero-debt] merge commit: {excluidos} staged file(s) excluded "
              "(inherited from the other parent, untouched by this merge)")
    return propios


def _git_paths(root: Path, args: list[str]) -> list[str]:
    """`git` output as a path list; an unusable git is an empty list, never a raise."""
    out = subprocess.run(["git", *args], cwd=root, capture_output=True, text=True, check=False)
    if out.returncode != 0:
        return []
    return [p for p in out.stdout.splitlines() if p.strip()]


def scan_scope(root: Path, staged: bool = False,
               explicit: list[Path] | None = None) -> tuple[list[str], int, str]:
    """The .py files this scan reads, plus how many it leaves outside and why.

    Returns ``(files, outside_count, outside_reason)``.

    Until 2026-09-04 the repo-wide lane enumerated `git ls-files` alone, which
    lists the INDEX. A file nobody had `git add`-ed yet was not in it, so a
    planted `time.sleep(5)` in a NEW file produced `violations: 0` and rc=0 --
    the scanner did not miss the vice, it reported the repository clean over a
    file it never opened. Measured independently by four agents on aequitas_os
    (2026-09-02) and reproduced here before this fix.

    Two things changed, and the second is the one that survives the next
    directory nobody has thought of yet:

    1. `--others --exclude-standard` is enumerated too, so untracked files are
       scanned.
    2. The count left OUTSIDE the scan is returned and printed. A zero that is
       declared is not the same object as a zero that is assumed, and nothing in
       the old output told the two apart -- which is why four separate agents
       each had to measure it by hand. aequitas_os's words: "un cero que se
       declara".

    Adding one more directory to a list was explicitly ruled out by the ficha,
    and by `DEBT-KIT-ASSUMES-PYTHON` for the same reason: it breaks again at the
    next directory. What is enumerated here is whatever git can see, and what
    git deliberately hides (ignored paths) is COUNTED and NAMED rather than
    silently dropped.

    Cost note, unchanged from the original contract: repo-wide takes ~9s on a
    320-file tree, so the commit lane still sees only what the commit adds and
    the repo-wide sweep belongs in pre-push or CI.
    """
    if explicit is not None:
        # Reported by the aequitas_os session 2026-09-05, with the measurement
        # that makes it worth having: on 1,160 tracked Python files a repo-wide
        # sweep costs 30-45s, and checking whether ONE edit cleared ONE finding
        # cost a full sweep every time. A gate that expensive to interrogate gets
        # interrogated less, and then it is read less.
        #
        # The outside-count is exact here rather than approximate: everything the
        # repo-wide lane WOULD have read, minus what was asked for. A scoped scan
        # that did not say what it skipped would be the same defect this lane
        # already fixed for untracked files.
        pedidos = [str(f) for f in explicit]
        todos = _git_paths(root, ["ls-files", "--", "*.py"])
        todos += _git_paths(root, ["ls-files", "--others", "--exclude-standard", "--", "*.py"])
        vivos = [p for p in pedidos if (root / p).is_file()]
        return (
            vivos,
            max(len(set(todos)) - len(vivos), 0),
            "not named on the command line (--file was given, so this scan is scoped)",
        )
    if staged:
        files = _drop_merge_inherited(
            root,
            _git_paths(root, ["diff", "--no-relative", "--cached", "--name-only",
                              "--diff-filter=ACM", "--", "*.py"]),
        )
        outside = len(_git_paths(root, ["ls-files", "--", "*.py"])) - len(files)
        return (
            [p for p in files if (root / p).is_file()],
            max(outside, 0),
            "tracked but not staged for this commit",
        )

    tracked = _git_paths(root, ["ls-files", "--", "*.py"])
    untracked = _git_paths(root, ["ls-files", "--others", "--exclude-standard", "--", "*.py"])
    # dict.fromkeys: dedupe while keeping a deterministic order (Axiom 9).
    files = list(dict.fromkeys([*tracked, *untracked]))
    ignored = _git_paths(
        root, ["ls-files", "--others", "--ignored", "--exclude-standard", "--", "*.py"]
    )
    return (
        [p for p in files if (root / p).is_file()],
        len(ignored),
        "git-ignored (.gitignore); not part of the product",
    )


# Source extensions this scanner CANNOT read. Not a capability list to grow --
# a list of what to CONFESS. See `unexamined_source`.
_FOREIGN_SOURCE_GLOBS = (
    "*.rs", "*.ts", "*.tsx", "*.js", "*.jsx", "*.go", "*.java", "*.kt",
    "*.rb", "*.php", "*.cs", "*.c", "*.h", "*.cpp", "*.hpp", "*.swift", "*.scala",
)


def unexamined_source(root: Path) -> dict[str, int]:
    """Tracked source files this Python-only scanner did not read, by extension.

    DEBT-KIT-ASSUMES-PYTHON, second site. RePic measured `zero_debt --mode zero`
    reporting `files scanned: 4` on a repo holding 5,759 lines of Rust: the four
    were `.simplecode/run.py`, `tools/__init__.py`, `tools/verify_finding.py` and
    `tests/test_verify_finding.py` -- tooling, none of it product. Their wording,
    kept because it is exact: *"lo que no es cierto es que 'nueve compuertas en
    verde' describa el producto: cinco de las nueve describen cuatro ficheros de
    utillaje"*.

    This does NOT make the scanner understand Rust -- that is
    DEBT-SPEC8-RUST-TS-PARSERS. It makes the scanner say what it did not read, so
    "0 violations" stops being indistinguishable from "0 files of the product
    were opened". A confession is not coverage, and the report says which it is.
    """
    counts: dict[str, int] = {}
    for glob in _FOREIGN_SOURCE_GLOBS:
        found = _git_paths(root, ["ls-files", "--", glob])
        if found:
            counts[glob.lstrip("*")] = len(found)
    return counts


def tracked_python(root: Path, staged: bool = False,
                   explicit: list[Path] | None = None) -> list[str]:
    """The files `scan_scope` selects. Kept as the name callers already use."""
    files, _, _ = scan_scope(root, staged=staged, explicit=explicit)
    return files


def mask_corpus_code(code: str) -> str:
    """Mask out declared corpus blocks (start/end markers, see _CORPUS_TAG)."""
    if _CORPUS_TAG not in code:
        return code
    lines = code.splitlines(keepends=True)
    clean_lines = []
    in_block = False
    for line in lines:
        if _CORPUS_START in line:
            in_block = True
            clean_lines.append("# [corpus masked]\n")
            continue
        if _CORPUS_END in line:
            in_block = False
            clean_lines.append("# [corpus masked]\n")
            continue
        if in_block:
            clean_lines.append("# [corpus masked]\n")
        else:
            clean_lines.append(line)
    return "".join(clean_lines)


@functools.lru_cache(maxsize=None)
def _accepts_path(fn) -> bool:
    """True si el detector acepta un parámetro `path` (p. ej. GS2-210).

    El registro es uniforme `fn(code)`; unos pocos detectores exigen la RUTA
    para su exención (el basename `tool_limits.py`), y la reciben por kwarg sin
    romper la API pura de los demás. Se cachea por función.
    """
    try:
        return "path" in inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False


def _detail_providers(*modules) -> dict[str, Callable[..., Any]]:
    """Opt-in {detector_id: detail_fn} map, built from the `<id>_findings`
    naming convention -- a detector named `foo` may define a sibling
    `foo_findings(code, path=None) -> list[tuple[int, str]]` returning every
    match's (line, reason) instead of one collapsed bool. Detectors that
    don't define the sibling are simply absent from this map; `_run_registry`
    falls back to the old line=0 generic message for those, so adding detail
    to one detector never requires touching any other.
    """
    providers: dict[str, Callable[..., Any]] = {}
    for module in modules:
        for fn, key, _msg in getattr(module, "PATTERN_DETECTORS", ()):
            detail_fn = getattr(module, f"{key}_findings", None)
            if callable(detail_fn):
                providers[key] = detail_fn
        for fn, key, _msg in getattr(module, "AGENT_THREAT_DETECTORS", ()):
            detail_fn = getattr(module, f"{key}_findings", None)
            if callable(detail_fn):
                providers[key] = detail_fn
    return providers


class FindingSink(NamedTuple):
    """A DONDE van los `Finding` de un detector que dispara, y con cuanto detalle.

    Los dos campos viajan como UN parametro porque `detail_providers` SOLO no
    hace nada: se lee unicamente dentro de la rama `findings is not None`, asi
    que `_run_registry(..., findings=None, detail_providers=providers)` era un
    no-op silencioso que la firma dejaba escribir. Medido sobre el codigo, no
    deducido: `grep -n detail_providers` da la unica lectura (`sink.
    detail_providers.get(key)`) dentro de ese `if`.

    Atarlos hace que esa combinacion invalida sea INEXPRESABLE, y de paso baja
    `_run_registry` de seis parametros a cinco (`ruff` PLR0913, 6 > 5) sin tocar
    los tres puntos de llamada que pasan solo cuatro argumentos.

    Sin valor por defecto en `detail_providers` a proposito: un `{}` de defecto
    volveria a permitir el sumidero a medias que este tipo existe para impedir,
    y quien no tiene proveedores de detalle lo dice escribiendo `{}`.
    """

    findings: list[Finding]
    detail_providers: dict[str, Callable[..., Any]]


def _run_registry(
    registry: list[tuple],
    rel: str,
    code: str,
    could_not_run: list[str],
    sink: FindingSink | None = None,
) -> tuple[int, bool]:
    """Findings for one file, plus whether anything stopped a detector.

    `sink`, when given, collects one `entities.Finding` per detector that
    fired -- the same events the returned count summarizes, with the detector
    that fired kept instead of thrown away.

    `sink.detail_providers` (see `_detail_providers`) lets a detector report WHERE
    and WHY instead of just THAT: when the detector that fired has a sibling
    `<id>_findings` function, one `Finding` is emitted per (line, reason) hit
    it returns -- so a file with 3 hardcoded timeouts gets 3 lines naming
    each one, not 1 generic "fired" with no location. Detectors with no such
    sibling keep the original behavior: `line` is 0, "no line was measured,
    never a guess at line 1", exactly as before this parameter existed.

    Un archivo que no se pudo PARSEAR no está limpio, está NO LEÍDO, y desde que
    pattern_detectors levanta UnparseableSource eso llega aquí como excepción en
    vez de disfrazarse de `False`. Un solo renglón por archivo: los 25 detectores
    tropiezan con el mismo árbol ausente, y 25 renglones idénticos entierran el
    hecho en lugar de contarlo.

    CINCO PARÁMETROS desde 2026-09-15, y por qué la exclusión razonada que
    ocupaba este hueco estaba MAL MEDIDA. Decía: *"los seis son tres parejas de
    naturaleza distinta -- QUÉ correr (`registry`, `detail_providers`), SOBRE QUÉ
    ARCHIVO (`rel`, `code`), y DÓNDE ACUMULAR (`could_not_run`, `findings`) -- y
    ninguna de las tres viaja junta en ningún otro sitio del kit"*. El reparto es
    el que no describía este código: `detail_providers` no es "qué correr", es
    parte del SUMIDERO, y está MUERTO sin `findings` -- su única lectura vive
    dentro de la rama `if sink is not None`. Así que la pareja que sí viaja junta
    era precisamente una de las que el párrafo declaraba disjuntas, y el hueco
    se cerró atándolas en `FindingSink` (ver su docstring).

    Lo que la corrección conserva, medido y no argumentado:
      - los TRES puntos de llamada simples siguen pasando los MISMOS cuatro
        argumentos, carácter por carácter: agrupar la pareja del sumidero no
        toca la llamada que no lo usa, que era la objeción entera del párrafo
        viejo;
      - una combinación que antes se podía escribir y no hacía nada
        (`findings=None` con `detail_providers` puesto) ya no se puede escribir;
      - `ruff check` sobre este fichero pasa de 1 error a 0.

    Y sigue sin llevar supresión `noqa`, que ahora es moot pero conviene dejar
    escrito por qué nunca fue la salida: `unjustified_noqa_complexity` exige que
    el noqa cite un ticket y `dangling_refs.check_noqa_ticket_references` exige
    que ese ticket sea un `.md` YA RASTREADO por git; el ticket vigente
    (DEBT-ACCEPTED-COMPLEXITY-CORE-DETECTORS) está acotado a cuatro detectores
    AST NOMBRADOS de pattern_detectors.py bajo C901, no a esta función ni a esta
    regla, así que citarlo aquí habría sido una cita falsa.

    LO QUE SIGUE SIN HACERSE, con su costo: doblar `could_not_run` a valor de
    retorno bajaría a cuatro. No se hizo, y la razón es la clase de defecto que
    este repo teme más -- un `could_not_run` que se pierde en silencio. Como
    parámetro, el llamador no puede olvidarse de él; como valor de retorno, un
    llamador futuro que omita el `.extend(...)` tira las filas al suelo sin que
    nada falle. Ese cambio es de Luis, no de este hilo.
    """
    from simplecode.guards.pattern_detectors import UnparseableSource

    n = 0
    file_err = False
    for fn, key in registry:
        try:
            if (fn(code, path=rel) if _accepts_path(fn) else fn(code)):
                n += 1
                if sink is not None:
                    detail_fn = sink.detail_providers.get(key)
                    hits = detail_fn(code, path=rel) if detail_fn else None
                    if hits:
                        for line, reason in hits:
                            sink.findings.append(
                                Finding(
                                    file_path=rel,
                                    line=line,
                                    detector_id=key,
                                    message=f"{rel}:{line}: {key}: {reason}",
                                    severity="FAIL",
                                    would_block=True,
                                )
                            )
                    else:
                        sink.findings.append(
                            Finding(
                                file_path=rel,
                                line=0,
                                detector_id=key,
                                message=f"{rel}: {key} fired",
                                severity="FAIL",
                                would_block=True,
                            )
                        )
        except UnparseableSource as exc:
            could_not_run.append(f"{rel}: unparseable ({exc})")
            return n, True
        except Exception as exc:
            could_not_run.append(f"{rel}: {key} raised {type(exc).__name__}: {exc}")
            file_err = True
    return n, file_err


def _gate_registry(pd, at) -> tuple[list[tuple], list[str]]:
    """The (fn, id) pairs this gate runs -- `GATE_DETECTORS` minus
    `HIGH_VOLUME_EXCLUDED` -- plus one COULD_NOT_RUN row per selected id the
    registries no longer carry: a renamed detector must not leave the gate
    judging 21 while it reports 22."""
    registry = [(fn, k) for fn, k, _ in (*pd.PATTERN_DETECTORS, *at.AGENT_THREAT_DETECTORS)
                if k in GATE_DETECTORS and k not in HIGH_VOLUME_EXCLUDED]
    ausentes = sorted(GATE_DETECTORS - {k for _, k in registry} - set(HIGH_VOLUME_EXCLUDED))
    return registry, [f"GATE_DETECTORS: {k} not in the detector registry" for k in ausentes]


def _corpus_detector_selection(registry: list[tuple], rel: str) -> tuple[frozenset[str] | None, list[tuple]]:
    """Keep fixture-vocabulary exemptions while judging real test truth."""
    norm = rel.replace("\\", "/")
    es_test = norm.startswith("tests/") or "fixtures/" in norm
    if es_test:
        test_truth = {"test_without_assert", "assert_true"}
        activo = [r for r in registry if r[1] in test_truth]
        return None, activo
    return CORPUS_COLLIDING_DETECTORS, [
        r for r in registry if r[1] not in CORPUS_COLLIDING_DETECTORS
    ]


def scan_all_detectors(
    root: Path, staged: bool = False, findings: list[Finding] | None = None,
    explicit: list[Path] | None = None,
) -> tuple[dict[str, int], list[str], dict[str, str], dict[str, str]]:
    """Runs the `GATE_DETECTORS` selection of the pattern and agent threat
    registries across tracked python files.

    Pass `findings` to also collect the typed `entities.Finding` for every
    detector that fired. The four-tuple return is unchanged: its callers
    (`backlog_verifier`, the tests) keep working untouched.
    """
    _load_vendored_paths.cache_clear()
    _load_vendored_path_prefixes.cache_clear()
    pd = _load(KIT / "guards" / "pattern_detectors.py")
    at = _load(KIT / "guards" / "agent_threats.py")
    registry, faltan = _gate_registry(pd, at)
    # El sumidero se construye UNA vez, fuera del bucle, y es `None` cuando el
    # llamador no pidio `findings`: `FindingSink` no admite una mitad, asi que la
    # ausencia se expresa como ausencia del objeto y no como un campo vacio.
    sink = FindingSink(findings, _detail_providers(pd, at)) if findings is not None else None

    counts: dict[str, int] = {}
    could_not_run = faltan + [f"{p}: missing or not a file" for p in explicit or []
                              if not (root / p).is_file()]
    corpus: dict[str, str] = {}
    dispositions: dict[str, str] = {}
    for rel in tracked_python(root, staged=staged, explicit=explicit):
        if is_fixture(rel):
            dispositions[rel] = "EXEMPT_FIXTURE"
            continue
        if is_vendored(root, rel):
            dispositions[rel] = "EXEMPT_VENDORED"
            continue
        reason = declares_corpus(root, rel)
        if reason:
            corpus[rel] = reason
            # NOT `continue`. A corpus declaration exempts the detectors whose
            # patterns collide with the vocabulary, never the file: skipping the
            # whole file let a real `time.sleep(5)` sit inside the module that
            # defines the sleep detector, with the gate reporting 0 violations.
            # Two classes, deliberately different, because the risk is
            # different. PRODUCTION corpus (the five source paths) gets the
            # narrow per-detector exemption above: a real vice hiding there is
            # the reported defect. TEST corpus keeps the whole-file exemption --
            # 17 detectors fire across `tests/`, including `hardcoded_secret`
            # and `destructive_without_dryrun`, because carrying vices verbatim
            # is what a detector's fixture IS, and narrowing it to those 17
            # would exempt more than the whole-file rule does today.
            #
            # NAMED LIMIT, not solved: `tests/` therefore remains a zone where a
            # genuine vice would pass. It is a smaller zone than the one this
            # change closes (production modules) and a different argument is
            # needed for it -- block markers per fixture, which the test files
            # already support and mostly do not use.
            corpus_detectors, activo = _corpus_detector_selection(registry, rel)
            dispositions[rel] = "EXEMPT_CORPUS"
        else:
            activo = registry
        path = root / rel
        try:
            raw = path.read_bytes()
        except OSError as exc:
            could_not_run.append(f"{rel}: unreadable ({exc})")
            dispositions[rel] = "COULD_NOT_RUN"
            continue
        # UTF-8 ESTRICTO. Medido el 2026-08-23 (auditoría V2-L076): con
        # `errors="replace"` un archivo latin-1 (`VALOR = "caf\xe9"`) decodificaba
        # a U+FFFD y salía PASSED en silencio -- una lectura que se inventa bytes
        # no es una lectura, es una absolución sobre texto que no existe. Bytes
        # indecodificables => COULD_NOT_RUN (fuerte), jamás PASSED. El byte NUL
        # SÍ decodifica en utf-8 (U+0000), así que sigue su camino hasta _parse,
        # que lo levanta como UnparseableSource -- ese contrato queda intacto.
        try:
            code = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            could_not_run.append(f"{rel}: undecodable ({exc})")
            dispositions[rel] = "COULD_NOT_RUN"
            continue
        code = mask_corpus_code(code)
        n, file_err = _run_registry(activo, rel, code, could_not_run, sink)
        counts[rel] = n
        if file_err:
            dispositions[rel] = "COULD_NOT_RUN"
        elif n > 0:
            dispositions[rel] = "CONVICTED"
        elif not reason:
            dispositions[rel] = "PASSED"
    return counts, could_not_run, corpus, dispositions


findings_per_file = scan_all_detectors


def _baseline_for(args: argparse.Namespace, dirty: dict[str, int], total: int) -> dict[str, int] | None:
    if args.write_baseline and args.staged:
        print(
            "[zero-debt] refusing --write-baseline with --staged: "
            "a baseline from a partial scan records absence as zero."
        )
        # INSTRUMENTO CAIDO: se rehusa a producir un veredicto sobre un baseline
        # que solo vio los archivos staged -- nunca miro el repo completo.
        print(
            "[zero-debt] COULD_NOT_RUN: refused --write-baseline combined with "
            "--staged (a baseline from a partial scan would freeze absence as zero)",
            file=sys.stderr,
        )
        return None
    if args.write_baseline:
        write_text_durable(
            args.baseline, json.dumps(dict(sorted(dirty.items())), indent=1)
        )
        print(f"[zero-debt] baseline written: {len(dirty)} files, {total} findings")
        print("            (this records the path to zero; it does not forgive it)")
    if args.mode == "zero":
        return {}
    try:
        return json.loads(args.baseline.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        print(
            f"[zero-debt] no readable baseline at {args.baseline} - "
            "treating every finding as new"
        )
        return {}


from dataclasses import dataclass, field


@dataclass
class ScanResults:
    counts: dict[str, int]
    could_not_run: list[str]
    corpus: dict[str, str]
    violations: list[str]
    dispositions: dict[str, str] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)
    # (count, reason) for .py files this scan did NOT read. Defaults to a
    # declared unknown, never to 0: a scan that never computed its own blind
    # spot must not print a zero it did not measure.
    outside: tuple[int, str] = (-1, "not computed by this caller")
    # {".rs": 120, ".ts": 40} -- tracked source this Python-only scanner cannot
    # read. Empty means "none found", which in a pure-Python repo is the truth.
    unexamined: dict[str, int] = field(default_factory=dict)


def _semantic_gap(unexamined: dict[str, int]) -> dict[str, int]:
    """The subset of `unexamined` with NO AST-semantic detector reaching it
    at all -- `{}` once the optional `multilang_ast` binding is installed,
    since at least one real (if narrow) AST detector then covers these
    extensions. Extracted as its own function, rather than inlined where it
    is printed, specifically so `organ_crossings.cross_semantic_gap_readers_agree`
    can call the EXACT same logic `pattern_detectors.unanalysed_semantic_source`
    is compared against, instead of a comment promising the two stay in sync.
    """
    from simplecode.guards.multilang_ast import MULTILANG_AST_AVAILABLE

    if MULTILANG_AST_AVAILABLE:
        return {}
    return {ext: n for ext, n in unexamined.items() if ext in (".rs", ".ts", ".tsx")}


def _print_unexamined_confession(unexamined: dict[str, int], gate: str = "zero-debt") -> None:
    """Print the `NOT EXAMINED` confession line, or nothing when there is
    nothing to confess.

    Factored out of `_print_report` (DEBT-SURVEY-GATES-MEASURE-THE-SCAFFOLD,
    zero-debt-repo half): the verdict-cache HIT path in `main` used to return
    0 straight after "CACHE HIT" WITHOUT ever calling `_print_report`, so a
    repo-wide pre-push run that hit cache -- the common case once a tree has
    gone green once -- printed a bare green with no confession at all, even
    though `unexamined_source(root)` is a cheap `git ls-files` sweep the cache
    hit was never trying to save. Same text both callers already agreed on;
    this just gives it one home instead of two copies that could drift.
    """
    if not unexamined:
        return
    total = sum(unexamined.values())
    breakdown = ", ".join(f"{n} {ext}" for ext, n in sorted(unexamined.items()))
    print(
        f"[{gate}] NOT EXAMINED -- this scanner reads Python only: "
        f"{total} tracked source file(s) ({breakdown}). A clean verdict above "
        f"says NOTHING about them."
    )
    # DEBT-SPEC8-RUST-TS-PARSERS: a sharper claim than the line above. Even a
    # gate that DID read a Rust/TypeScript file (this scanner doesn't, but the
    # regex-only checks in `guards/multilang_detectors.py` would) still has no
    # AST-semantic detector for it -- UNLESS the optional `multilang_ast`
    # binding is installed here, in which case at least one real AST-semantic
    # detector (silent-error-swallow) now reaches these extensions.
    # `_semantic_gap` is the source of truth `pattern_detectors.
    # unanalysed_semantic_source` must stay in sync with;
    # `organ_crossings.cross_semantic_gap_readers_agree` crosses the two for
    # real instead of trusting a comment to keep them matched by hand.
    semantic_gap = _semantic_gap(unexamined)
    if semantic_gap:
        total_gap = sum(semantic_gap.values())
        breakdown_gap = ", ".join(f"{n} {ext}" for ext, n in sorted(semantic_gap.items()))
        print(
            f"[{gate}] NO AST-SEMANTIC COVERAGE (DEBT-SPEC8-RUST-TS-PARSERS): "
            f"{total_gap} of the above ({breakdown_gap}) have no AST-level detector "
            f"at all, pattern-level or otherwise -- no tree-sitter binding (or any "
            f"other AST library for these languages) is installed."
        )


def _print_report(args: argparse.Namespace, res: ScanResults) -> None:
    dirty = {path: count for path, count in res.counts.items() if count}
    print(f"[zero-debt] mode: {args.mode}  lane: {'staged' if args.staged else 'repo-wide'}")
    print(
        f"[zero-debt] files scanned: {len(res.counts)}  findings: {sum(res.counts.values())}  "
        f"files with findings: {len(dirty)}"
    )
    emit_hallazgos("[zero-debt]", sum(res.counts.values()))
    # One count per (file, detector) that fired -- the unit `res.counts` sums --
    # so the values add up to the HALLAZGOS line above, whatever number of
    # per-line `Finding`s a detail provider emitted for each firing.
    disparos = {(f.file_path, f.detector_id) for f in res.findings}
    por_detector: dict[str, int] = {}
    for _, detector_id in disparos:
        por_detector[detector_id] = por_detector.get(detector_id, 0) + 1
    emit_detectores("[zero-debt]", por_detector)
    # Reporting politics: print the zeros, and print what was NOT looked at
    # beside what was. Before 2026-09-04 this line did not exist and the lane
    # enumerated the index alone, so "scanned and clean" and "never opened"
    # produced identical output -- see `scan_scope`.
    outside_count, outside_reason = res.outside
    print(f"[zero-debt] .py left OUTSIDE this scan: {outside_count} ({outside_reason})")
    _print_unexamined_confession(res.unexamined)
    if res.dispositions:
        from collections import Counter
        disp_counts = Counter(res.dispositions.values())
        print(
            f"[zero-debt] dispositions (Acta 83): "
            f"PASSED={disp_counts.get('PASSED', 0)} "
            f"CONVICTED={disp_counts.get('CONVICTED', 0)} "
            f"EXEMPT_CORPUS={disp_counts.get('EXEMPT_CORPUS', 0)} "
            f"EXEMPT_FIXTURE={disp_counts.get('EXEMPT_FIXTURE', 0)} "
            f"EXEMPT_VENDORED={disp_counts.get('EXEMPT_VENDORED', 0)} "
            f"COULD_NOT_RUN={disp_counts.get('COULD_NOT_RUN', 0)}"
        )
    print(f"[zero-debt] detectors judged (GATE_DETECTORS): {len(GATE_DETECTORS)}")
    print(
        f"[zero-debt] detectors excluded by volume: {len(HIGH_VOLUME_EXCLUDED)} "
        f"({', '.join(HIGH_VOLUME_EXCLUDED)})"
    )
    print(f"[zero-debt] could_not_run: {len(res.could_not_run)}")
    for row in res.could_not_run[:10]:
        print(f"  BROKE {row}")
    print(f"[zero-debt] corpus declarado (no juzgado): {len(res.corpus)}")
    for rel, reason in sorted(res.corpus.items()):
        print(f"  CORPUS {rel} - {reason}")
    print(f"[zero-debt] violations: {len(res.violations)}")
    por_archivo: dict[str, list[Finding]] = {}
    for finding in res.findings:
        por_archivo.setdefault(finding.file_path, []).append(finding)
    for rel in res.violations[:25]:
        detectores = ", ".join(f.detector_id for f in por_archivo.get(rel, ()))
        detalle = f": {detectores}" if detectores else ""
        print(f"  - {rel} ({res.counts[rel]} findings{detalle})")
    if len(violations := res.violations) > 25:
        print(f"  ... and {len(violations) - 25} more")
    if res.findings:
        print(f"[zero-debt] findings (JSONL): {len(res.findings)}")
        for finding in res.findings[:25]:
            print(f"  {finding.to_json()}")


def _stamp(root: Path, counts: dict[str, int]) -> None:
    from simplecode.verification.finding_backlog import open_tasks, prune_resolved, write_findings

    findings = [f"{rel}: {count} finding(s)" for rel, count in counts.items() if count]
    if findings:
        write_findings(root, findings)
    prune_resolved(root, findings, force=True)
    outstanding = open_tasks(root)
    if outstanding:
        print(f"[zero-debt] backlog: {len(outstanding)} open task(s) written to tasks/backlog/")


def _scan_cache_key(root: Path, args: argparse.Namespace) -> str | None:
    """Only a complete, read-only scan may reuse or publish a repository verdict."""
    from simplecode.worktree import verdict_cache

    if not args.gate or args.staged or args.file or args.write_baseline or args.stamp:
        return None
    # Hash the actual installed implementation, including transitive helpers and
    # rule data. Zip imports must hash the archive, never nonexistent inner paths.
    archive = next((p for p in HERE.parents if p.suffix == ".zip" and p.is_file()), None)
    sources = [archive] if archive else sorted(
        p for p in KIT.rglob("*") if p.is_file() and p.suffix in (".py", ".yaml")
    )
    if not sources:
        return None
    config = [root / ".simplecode" / "corpus_exempt.yaml"]
    if args.mode == "no-growth":
        config.append(args.baseline)
    return verdict_cache.compute_key(
        root, "zero-debt", registry_source_paths=sources, config_paths=config, extra=args.mode,
    )


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Zero-debt ratchet over detector findings.")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--mode", choices=("zero", "no-growth"), default="zero")
    ap.add_argument("--baseline", type=Path, default=Path(".zero_debt_baseline.json"))
    ap.add_argument("--write-baseline", action="store_true")
    ap.add_argument("--staged", action="store_true",
                    help="Only files staged for commit (the cheap pre-commit lane).")
    ap.add_argument("--file", type=Path, action="append", default=None, metavar="PATH",
                    help="Scan only these file(s). Repeatable. For the debugging loop: "
                         "checking whether one edit cleared one finding should not cost a "
                         "repo-wide sweep.")
    ap.add_argument("--gate", action="store_true")
    ap.add_argument("--stamp", action="store_true",
                    help="Write findings to finding_backlog (one per line format).")
    args = ap.parse_args(argv)
    root = args.root.resolve()
    if not args.baseline.is_absolute():
        args.baseline = root / args.baseline

    from simplecode.worktree import verdict_cache

    cache_key = _scan_cache_key(root, args)
    if cache_key is not None:
        cached = verdict_cache.lookup(root, "zero-debt", cache_key)
        if cached is not None:
            print(
                f"[zero-debt] CACHE HIT: verdict unchanged since last GREEN run "
                f"({cached['summary']}) -- skipping full scan"
            )
            # The scan is skipped, not the confession: `unexamined_source` is a
            # handful of `git ls-files` calls, not the expensive AST sweep the
            # cache exists to avoid, and skipping it here was the actual gap
            # (see `_print_unexamined_confession`'s docstring).
            _print_unexamined_confession(unexamined_source(root))
            return 0

    ratchet = _load(HERE / "ratchet.py")
    findings: list[Finding] = []
    counts, could_not_run, corpus, dispositions = findings_per_file(
        root, staged=args.staged, findings=findings, explicit=args.file
    )
    dirty = {k: v for k, v in counts.items() if v}
    total = sum(counts.values())
    baseline = _baseline_for(args, dirty, total)
    if baseline is None:
        return 1
    violations = ratchet.compare_debt_to_baseline(counts, baseline, threshold=0)
    # `_run_registry` marks every finding blocking because the standing policy
    # is zero. Under --mode no-growth a finding already in the baseline does
    # not block this commit, and the record has to say so rather than inherit
    # the default.
    bloqueantes = set(violations)
    findings = [
        f if f.file_path in bloqueantes else replace(f, would_block=False)
        for f in findings
    ]
    _, outside_count, outside_reason = scan_scope(root, staged=args.staged, explicit=args.file)
    results = ScanResults(counts, could_not_run, corpus, violations, dispositions,
                          findings, outside=(outside_count, outside_reason),
                          unexamined=unexamined_source(root))
    _print_report(args, results)
    if could_not_run and args.gate:
        print("BLOCKED [zero-debt] - a detector could not run; absence never approves.")
        # INSTRUMENTO CAIDO: al menos un archivo no se pudo leer/parsear/correr.
        print(
            f"[zero-debt] COULD_NOT_RUN: {len(could_not_run)} file(s) unreadable or "
            f"unparseable; first {could_not_run[0]}",
            file=sys.stderr,
        )
        return 1
    if violations and args.gate:
        print("BLOCKED [zero-debt] - policy is zero debt, with no grandfathering.")
        # CONDENA: el sujeto se leyo completo y al menos un archivo tiene
        # findings vivos bajo la politica cero. `violations` conserva el orden
        # de `counts`, y `findings` ya trae el detector+linea de cada hallazgo.
        primer_file = violations[0]
        primer_finding = next((f for f in findings if f.file_path == primer_file), None)
        if primer_finding is not None:
            primero = f"{primer_finding.file_path}:{primer_finding.line} ({primer_finding.detector_id})"
        else:
            primero = f"{primer_file} (no detail provider)"
        print(f"[zero-debt] FAIL: {len(violations)} violation(es); primera {primero}")
        return 1

    if args.stamp:
        _stamp(root, counts)
    if cache_key is not None:
        verdict_cache.record(
            root, "zero-debt", cache_key,
            summary=f"{len(counts)} files, 0 violations, 0 could_not_run",
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
