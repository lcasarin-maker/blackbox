# -*- coding: utf-8 -*-
"""Staged parity: the commit must contain what the gates reviewed and what its code imports.

Two revisions: (1) a staged file whose working-tree version differs from the
index; (2) a module the staged code imports that is on disk but not in the
index, in whatever package the repo has. The third one (reopening a `done`
ledger entry) was removed 2026-09-27 by Luis's vote on the product audit
(docs/gate_audit_2026-09-26/veredicto_producto/staged-parity.md): it guarded
the ticket apparatus, not the product.
"""
from __future__ import annotations

import argparse
import ast
import subprocess
import sys
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.git_utils import git_divergent_staged_files
from simplecode.utils.tool_limits import GIT_O1_TIMEOUT


class GitUnavailable(RuntimeError):
    """The `git` subprocess itself could not be run (missing binary, timeout).

    Distinct from a plain non-zero returncode: `returncode != 0` from a git
    command that DID run (e.g. "not a git repository") is an honest "nothing
    to report" -- tested and documented below. This exception is for the
    case the module previously let crash uncontrolled: the process never
    ran at all, so nothing about the commit was actually checked.
    """


def get_divergent_staged_files(root: Path | None = None) -> list[str]:
    """Staged files whose working-tree version differs from the index.

    Two readings, united: git's own `diff` (which also sees mode changes), and
    a content hash of disk against the index blob. The second exists because
    `git diff` obeys `update-index --assume-unchanged` / `--skip-worktree`:
    with either bit set, git is told not to look at the tree, the diff is
    empty, and the commit carries v1 while every gate reviewed v2 on disk
    (audit 2026-09-26, atajo 1, rc=0). Hashing the file cannot be told not to
    look.
    """
    return sorted(set(git_divergent_staged_files(root)) | set(_hidden_divergence(root or Path.cwd())))


# Regular-file modes only: a symlink's blob is its target string and a gitlink
# has no blob in this repo, so hashing what sits on disk would compare apples
# with the wrong fruit and convict every staged symlink.
_REGULAR_MODES = frozenset({"100644", "100755"})


def _hidden_divergence(root: Path) -> list[str]:
    """Staged regular files whose disk content hashes differently from the index."""
    staged = _run_git(root, "diff", "--no-relative", "--cached", "--name-only", "-z", "--diff-filter=ACMR")
    if staged.returncode != 0:
        return []
    wanted = {p for p in staged.stdout.split("\0") if p}
    blobs: dict[str, str] = {}
    for entry in _run_git(root, "ls-files", "-s", "-z").stdout.split("\0"):
        meta, _, path = entry.partition("\t")   # "<mode> <sha> <stage>\t<path>"
        if path in wanted:
            mode, sha, _stage = meta.split()
            if mode in _REGULAR_MODES:
                blobs[path] = sha
    gone = sorted(p for p in blobs if not (root / p).is_file())
    present = sorted(p for p in blobs if p not in gone)
    if not present:
        return gone
    # With a path, hash-object applies the same clean filters and eol
    # conversion `git add` would, so an honest file hashes to its index blob.
    hashed = _run_git(root, "hash-object", "--", *present)
    if hashed.returncode != 0:
        raise GitUnavailable(f"git hash-object failed: {hashed.stderr.strip()}")
    disk = hashed.stdout.split()
    return gone + [p for p, h in zip(present, disk, strict=True) if h != blobs[p]]


def _run_git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """Every git invocation in this module funnels through here so a missing
    binary or a hung process surfaces as `GitUnavailable`, not an uncaught
    traceback with no tagged verdict at all (the previous behavior)."""
    try:
        return subprocess.run(
            ["git", "-C", str(root), *args],
            capture_output=True, text=True, check=False, timeout=GIT_O1_TIMEOUT,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GitUnavailable(f"git {' '.join(args)} could not be run: {exc}") from exc


def _index_paths(root: Path) -> set[str]:
    """Every path git has IN THE INDEX -- what the commit will actually contain."""
    proc = _run_git(root, "ls-files")
    if proc.returncode != 0:
        return set()
    return {line.strip() for line in proc.stdout.splitlines() if line.strip()}


def _staged_python(root: Path) -> list[str]:
    proc = _run_git(root, "diff", "--no-relative", "--cached", "--name-only", "--diff-filter=ACMR")
    if proc.returncode != 0:
        return []
    return [ln.strip() for ln in proc.stdout.splitlines() if ln.strip().endswith(".py")]


def _staged_content(root: Path, relpath: str) -> str:
    """The file AS STAGED, never as it sits on disk.

    Reading the disk here would repeat the very defect this check exists to
    catch: the working tree had the module, the index did not, and every test
    passed because it ran against the tree.
    """
    proc = _run_git(root, "show", f":{relpath}")
    return proc.stdout if proc.returncode == 0 else ""


def _module_candidates(dotted: str) -> tuple[str, ...]:
    """Where `dotted` would live in the two layouts Python packaging knows:
    `src/<pkg>/...` and the flat `<pkg>/...` at the repo root."""
    stem = "/".join(dotted.split("."))
    return (f"src/{stem}.py", f"src/{stem}/__init__.py", f"{stem}.py", f"{stem}/__init__.py")


def _relative_candidates(relpath: str, level: int, dotted: str) -> tuple[str, ...]:
    """Where `from <level dots><dotted>` inside `relpath` resolves: relative to
    the file's own directory, never to a guessed package root."""
    parts = relpath.split("/")[:-1]
    keep = len(parts) - (level - 1)
    stem = "/".join(parts[:keep] + [p for p in dotted.split(".") if p]) if keep >= 0 else ""
    # Too many dots, or `from . import x` at the repo root: nothing in the repo.
    return (f"{stem}.py", f"{stem}/__init__.py") if stem else ()


def _literal_import_module(node: ast.Call) -> str | None:
    """`import_module("a.b")` / `importlib.import_module(...)` / `__import__(...)`
    with a literal absolute name: the dynamic import that is still decidable."""
    func = node.func
    name = func.attr if isinstance(func, ast.Attribute) else getattr(func, "id", "")
    if name not in {"import_module", "__import__"} or not node.args:
        return None
    arg = node.args[0]
    if isinstance(arg, ast.Constant) and isinstance(arg.value, str) and arg.value[:1] not in ("", "."):
        return arg.value
    return None


def _imported_modules(content: str, relpath: str) -> dict[str, tuple[str, ...]]:
    """Every name the source could be importing as a MODULE -> where it would live.

    ANY package, not only `simplecode`: a name only becomes a finding when it
    resolves to a file that is on disk and missing from the index (see
    `unstaged_imports`), so stdlib and third-party names drop out by themselves.
    `from pkg import a, b` contributes `pkg.a` and `pkg.b`; whether each is a
    module or a symbol is decided by the disk, the only place that knows.

    Parsed with `ast`, not regex: the regex saw only absolute one-line imports,
    so `from . import newmod`, a parenthesised `from pkg import (newmod)` and
    `import_module("pkg.newmod")` all walked past it (audit 2026-09-26, atajo 2:
    gate OK, clean clone ImportError). A file that does not parse is left to
    the `ruff` hook: Python cannot import it either, for a reason not this one.
    """
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return {}
    found: dict[str, tuple[str, ...]] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                found[alias.name] = _module_candidates(alias.name)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            label = "." * node.level + module
            names = [a.name for a in node.names if a.name != "*"]
            if node.level == 0:
                found[module] = _module_candidates(module)
                for name in names:
                    found[f"{module}.{name}"] = _module_candidates(f"{module}.{name}")
            else:
                found[label] = _relative_candidates(relpath, node.level, module)
                for name in names:
                    found[f"{label}.{name}" if module else f"{label}{name}"] = (
                        _relative_candidates(relpath, node.level, f"{module}.{name}")
                    )
        elif isinstance(node, ast.Call) and (dotted := _literal_import_module(node)):
            found[dotted] = _module_candidates(dotted)
    return found


def unstaged_imports(root: Path) -> list[str]:
    """Modules the STAGED code imports that exist on disk but not in the index.

    The rule is deliberately "on disk AND not in the index", never "not in the
    index" alone: `from pkg import census` may name a function, and demanding a
    `census.py` for it would block every honest commit. Comparing the two places
    removes the guess entirely -- if the file is sitting there untracked, the
    working tree can import it and the commit cannot, and that gap is the whole
    finding.

    Measured on this repo 2026-09-02, by causing it: a `git add` whose pathspec
    named an already-moved file was rejected wholesale, so
    `verification/ledger.py` was never staged. The next commit staged a
    `finding_backlog.py` that imports it. HEAD would not import, and the full
    suite passed throughout -- because it ran against the working tree, where
    the file was.

    No gate in this repo could see that: `staged-parity` compared tracked files
    against disk, `clean worktree` looked for partial staging, and the tests are
    run by a person against a checkout. Nothing asked whether the COMMIT is
    internally consistent.
    """
    index = _index_paths(root)
    missing: list[str] = []
    for relpath in _staged_python(root):
        content = _staged_content(root, relpath)
        for module, candidates in sorted(_imported_modules(content, relpath).items()):
            if any(c in index for c in candidates):
                continue
            on_disk = [c for c in candidates if (root / c).is_file()]
            if on_disk:
                missing.append(
                    f"{relpath} imports {module}: {on_disk[0]} exists on disk "
                    f"but is not in the index"
                )
    return sorted(set(missing))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Verify staged parity: ensure files being committed match working tree content."
    )
    parser.add_argument("--root", type=Path, default=None, help="Repository root")
    args = parser.parse_args(argv)

    root = args.root or Path.cwd()
    try:
        divergent = get_divergent_staged_files(root)
        huerfanos = unstaged_imports(root)
        emit_hallazgos("[staged-parity]", len(divergent) + len(huerfanos))
    except GitUnavailable as exc:
        # The subprocess itself never ran (missing binary, timed out): nothing
        # about the commit was checked, which is an instrument failure, not a
        # verdict that the commit is clean or broken. Previously this crashed
        # uncontrolled with a bare traceback and no tagged line at all.
        print(f"[staged-parity] COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 1

    if not divergent and not huerfanos:
        print("[staged-parity] OK: staged files match the working tree, and the "
              "commit imports nothing the index lacks.")
        return 0

    if divergent:
        print(
            f"[staged-parity] FAIL: {len(divergent)} fichero(s) difieren entre "
            f"indice y arbol; primero {divergent[0]}"
        )
        for f in divergent:
            print(f"  - {f}: staged content differs from disk")
        # WHICH cause, because under pre-commit only one of the two is even
        # reachable and the old message named the other one.
        #
        # Planted by the descargaSAT session 2026-09-05, after their own model
        # said this organ could never fire and simplecode's telemetry said it
        # had fired 5 times. Their experiment settled it: a temporary hook
        # placed BEFORE this one, rewriting a staged file, with `git diff`
        # empty beforehand so the stash had nothing to take -- this gate then
        # convicted. Both readings were half right.
        #
        # pre-commit stashes the divergence that exists BEFORE the chain starts,
        # so the developer who half-staged a file is invisible here -- git
        # status tells them anyway. The divergence a PREVIOUS HOOK creates is
        # born after the stash and survives, and nobody else reports it. So
        # this organ is not watching the subject its name suggests; it is
        # watching the rarer and more dangerous one: a hook rewrote a staged
        # file, and the commit no longer contains what the gates reviewed.
        print(
            "  If a hook above printed `files were modified by this hook`, THAT "
            "is the cause: it rewrote a staged file, so the commit would not "
            "contain what the gates just reviewed. Re-stage what it wrote "
            "(`git add`) and re-run, having read the change."
        )
        print(
            "  If no hook modified anything, you staged a file and then edited "
            "it: `git add <file>` to take the new content, `git restore <file>` "
            "to keep what you staged."
        )

    if huerfanos:
        print(
            f"[staged-parity] FAIL: {len(huerfanos)} staged import(s) the commit "
            f"would not contain; primero {huerfanos[0]}"
        )
        for f in huerfanos:
            print(f"  - {f}")
        print("  The working tree has it and the commit does not, so every test "
              "passes and HEAD does not import. `git add` the module.")

    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
