# -*- coding: utf-8 -*-
"""claims.py -- lightweight session/process ownership claims for concurrent-write
coordination (DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP).

`own_chats` ran six of its own agents plus two foreign sessions writing this
same repo at once and coordinated it by prompt + human message: "funciono,
pero es artesania y no escala". Its proposal was `simplecode claim <ruta>`
writing owner+timestamp, with a hook printing it on collision -- "ni siquiera
un lock". `Twiner` refined it with failure modes that basic form does not
cover; two of those are folded in here:

- (b) a claim with no expiry is a candado por olvido -- the same shape as the
  Suspension contract in CLAUDE.md (suspend without expiry stayed "temporary"
  forever). Every claim carries a mandatory `ttl_seconds`; a claim read after
  its TTL is treated as ABSENT, never as a collision (see `is_expired`).
- (d) the owner is a free-form string, not a session id specifically -- a
  broadcast/generator process can claim under its own name plus the command
  that produced the write (`command=`), so a file stamped by a cron/broadcast
  reads as e.g. "generator:fleet-broadcast (cmd: simplecode fleet
  --broadcast)" instead of looking like an abandoned interactive session.

What this is NOT: a lock. `claim()` never refuses, whatever is already on
record for the path -- the most recent call wins. It is a readable trace, not
a mutex; enforcement (printing a collision before a commit lands) is
`claim_guard.py`'s job, not this module's.

Stored at `.simplecode/claims.json`. `.simplecode/*` is gitignored repo-wide
(see `.gitignore`) on purpose: a claim is coordination WITHIN one active work
session/worktree, not a durable record that should survive a clone. Contrast
`tasks/red_team_corpus.json`, which IS tracked because it is an append-only
ledger meant to survive exactly that (see `red_team_corpus.py`'s own
docstring) -- a claim is the opposite kind of state, and belongs in
`.simplecode/` by the same reasoning, not despite it.
"""
from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io
from simplecode.utils.git_utils import run_git

# Short, renewable -- (b)'s "TTL obligatorio, corto, renovable". A default long
# enough to cover one focused editing stretch, short enough that a forgotten
# claim stops mattering within the hour rather than becoming a permanent lock.
DEFAULT_TTL_SECONDS = 3600

_REQUIRED_FIELDS = {"path", "owner", "claimed_at", "ttl_seconds"}


class ClaimsError(RuntimeError):
    """The claims ledger cannot be trusted or interpreted."""


def default_claims_path(root: Path | None = None) -> Path:
    return (root or Path.cwd()) / ".simplecode" / "claims.json"


def _normalize_path(path: str | Path, root: Path) -> str:
    """Repo-relative POSIX path -- the key every claim is stored and looked up
    by, so an absolute path and its repo-relative spelling collide correctly."""
    candidate = Path(path)
    if candidate.is_absolute():
        try:
            candidate = candidate.resolve().relative_to(root.resolve())
        except ValueError:
            pass  # outside root: best-effort, keep the absolute form
    return candidate.as_posix()


def _load(claims_path: Path) -> dict[str, Any]:
    if not claims_path.is_file():
        return {"claims": []}
    try:
        data = json.loads(claims_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ClaimsError(f"cannot read valid JSON from {claims_path}: {exc}") from exc
    if not isinstance(data, dict) or not isinstance(data.get("claims"), list):
        raise ClaimsError(f"invalid claims shape in {claims_path}: expected a claims list")
    for entry in data["claims"]:
        if not isinstance(entry, dict) or (_REQUIRED_FIELDS - entry.keys()):
            raise ClaimsError(f"invalid claim entry in {claims_path}: missing required fields")
    return data


def _save(claims_path: Path, data: dict[str, Any]) -> None:
    claims_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_io.write_text_durable(
        claims_path, json.dumps(data, indent=2, sort_keys=True) + "\n", backup=True,
    )


def is_expired(entry: dict[str, Any], *, now: datetime | None = None) -> bool:
    """True once `claimed_at + ttl_seconds` has passed.

    (b): an expired claim is treated as ABSENT everywhere in this module --
    never as a block, exactly like the Suspension contract's expiry check.
    An entry whose timestamp/ttl cannot even be parsed is treated the same
    way: it cannot be vouched for, so it reads as gone rather than as a
    collision nobody can explain.
    """
    now = now or datetime.now(timezone.utc)
    try:
        claimed_at = datetime.fromisoformat(str(entry["claimed_at"]))
        ttl = float(entry["ttl_seconds"])
    except (KeyError, ValueError, TypeError):
        return True
    if claimed_at.tzinfo is None:
        claimed_at = claimed_at.replace(tzinfo=timezone.utc)
    return claimed_at + timedelta(seconds=ttl) < now


def resolve_owner(explicit: str | None, root: Path) -> str:
    """`explicit` if given, else `SIMPLECODE_CLAIM_OWNER`, else `git config
    user.name`, else "unknown" -- the same explicit-arg-then-native-fallback
    order the ponytail ladder asks for (native identity before inventing one).
    Used by both the `claim` CLI and `claim_guard` so a hook run with no
    `--owner` still resolves to something meaningful instead of a
    process-specific default that would collide with every other caller.
    """
    if explicit:
        return explicit
    env_owner = os.environ.get("SIMPLECODE_CLAIM_OWNER")
    if env_owner:
        return env_owner
    rc, out, _ = run_git(["config", "user.name"], root)
    name = out.decode("utf-8", "surrogateescape").strip()
    return name if rc == 0 and name else "unknown"


def claim(
    path: str | Path,
    owner: str,
    ttl_seconds: int = DEFAULT_TTL_SECONDS,
    *,
    command: str | None = None,
    root: Path | None = None,
) -> dict[str, Any]:
    """Record (or renew) that `owner` is actively working on `path`.

    Not a lock: this never refuses, whatever is already recorded for `path`.
    Replaces any prior entry for the same path -- the most recent `claim()`
    call is what a collision check sees. Returns the entry written.

    NO `claims_path=` HERE, AND THE ASYMMETRY IS DELIBERATE -- do not "restore"
    it for symmetry. Luis voted RESTRUCTURE over renewing the suppression that
    used to sit on this signature (2026-09-15); this is the restructuring, and
    it is a DELETION, not a regrouping.

    The parameter was DEAD. Measured, not asserted: an AST sweep of every
    `claim(...)` call site in the repo -- 26 of them, in `cli_new.py`,
    `satellite_sync.py` (twice), this module's own CLI, and 21 tests -- found
    ZERO passing `claims_path`. The negative control for that sweep was the
    same scanner pointed at `find_claim`, which reported 6 call sites that DO
    pass it, so the scanner was capable of the opposite verdict. Inside the
    body the parameter did one thing, `claims_path or default_claims_path(root)`,
    which is what the function now does unconditionally.

    What the asymmetry costs, stated rather than hidden: `find_claim` and
    `active_claims` -- the other two public functions of this module -- still
    take an optional keyword-only `claims_path`, and `claim_guard.py` forwards
    it at three sites, so `claim` is now the only one of those three without
    it. That is real, and it is justified on three measured grounds:

      1. `root=` already expresses the same thing for every real caller. All
         four non-test call sites pass `root=` and nothing else; the ledger
         they mean is always `root/.simplecode/claims.json`.
      2. `find_claim`/`active_claims` have a reason `claim` does not: they are
         READERS, and `claim_guard` genuinely points them at a ledger chosen by
         its own caller. A writer aimed at an arbitrary path is a capability
         nothing in this repo ever asked for.
      3. A parameter no caller passes cannot be covered by a caller's test. It
         was reachable only by a test written to exercise the parameter itself
         -- an instrument measuring itself, which is the shape CLAUDE.md's
         negative-control rule exists to reject.

    The honest limit: nothing MECHANICALLY prevents the parameter coming back.
    If a writer ever does need to aim at an explicit ledger, the change that
    earns it is the `ClaimStore` that owns the (`root`, `claims_path`) pair for
    the whole module -- which is a real design, unlike re-adding one dead
    keyword. That refactor spans `claim_guard.py`, `cli_new.py` and
    `satellite_sync.py`, and is what the parameter count would otherwise have
    been paid down with.
    """
    root = (root or Path.cwd()).resolve()
    claims_path = default_claims_path(root)
    data = _load(claims_path)
    rel = _normalize_path(path, root)
    entries = [e for e in data["claims"] if e.get("path") != rel]
    entry: dict[str, Any] = {
        "path": rel,
        "owner": owner,
        "claimed_at": datetime.now(timezone.utc).isoformat(),
        "ttl_seconds": int(ttl_seconds),
        "command": command,
    }
    entries.append(entry)
    data["claims"] = entries
    _save(claims_path, data)
    return entry


def find_claim(
    path: str | Path,
    *,
    root: Path | None = None,
    claims_path: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any] | None:
    """The active (non-expired) claim on `path`, or None.

    Expired and never-claimed both read as None (b): a caller cannot tell,
    and must not need to, whether a path was never claimed or was claimed
    and the claim lapsed -- both mean "nothing stands in the way".
    """
    root = (root or Path.cwd()).resolve()
    claims_path = claims_path or default_claims_path(root)
    data = _load(claims_path)
    rel = _normalize_path(path, root)
    for entry in data["claims"]:
        if entry.get("path") == rel and not is_expired(entry, now=now):
            return entry
    return None


def active_claims(
    *, root: Path | None = None, claims_path: Path | None = None, now: datetime | None = None,
) -> list[dict[str, Any]]:
    """Every non-expired claim currently on record."""
    root = (root or Path.cwd()).resolve()
    claims_path = claims_path or default_claims_path(root)
    data = _load(claims_path)
    return [e for e in data["claims"] if not is_expired(e, now=now)]


def _run_claim_action(args: argparse.Namespace) -> int:
    owner = resolve_owner(args.owner, args.root)
    entry = claim(args.path, owner, args.ttl, command=args.command, root=args.root)
    print(
        f"[claim] {entry['path']}: claimed by {entry['owner']} "
        f"(ttl={entry['ttl_seconds']}s, at {entry['claimed_at']})"
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Record an ownership claim on a path (DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP)"
    )
    parser.add_argument("path", help="Repo-relative (or absolute) path being claimed")
    parser.add_argument(
        "--owner", default=None,
        help="Session/agent/generator identifier (default: SIMPLECODE_CLAIM_OWNER env var, then git user.name)",
    )
    parser.add_argument("--ttl", type=int, default=DEFAULT_TTL_SECONDS, help="Seconds until the claim expires")
    parser.add_argument(
        "--command", default=None,
        help="Command that produced/will produce the write -- for generator claims (d), e.g. a broadcast job",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root")
    args = parser.parse_args(argv)
    try:
        return _run_claim_action(args)
    except ClaimsError as exc:
        print(f"[claim] COULD_NOT_RUN: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
