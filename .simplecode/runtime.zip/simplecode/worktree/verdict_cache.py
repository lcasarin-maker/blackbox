# -*- coding: utf-8 -*-
"""verdict_cache.py -- Bazel-style action cache for whole-repo scanners.

The insight (from the 2026-08-31 Atlas/aequitas_os deep-dive): a scanner like
`zero_debt --mode zero` is a PURE function of (its own detector source, its
config inputs, and the content of every tracked file it reads). When the
working tree exactly matches a commit that already produced a GREEN verdict
under the same inputs, re-running the scan produces the same verdict --
`git`'s own commit SHA already IS a content hash of the whole tree, so no
per-file hashing is needed to know the tree is unchanged.

Fail-closed by construction, the same discipline as `prek_vendor.ensure_prek`:
ANY uncertainty (git unavailable, dirty tree, unparseable cache, missing
entry) returns `None` from `compute_key`/`lookup`, and callers MUST treat
`None` as "run the real scan" -- never as permission to skip it. Only a
GREEN verdict is ever cached: a RED result always gets a fresh run with full
diagnostics, so a stale cache can never hide a real regression, only skip
work that would have re-confirmed something already proven.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import time
from collections.abc import Sequence
from pathlib import Path

_CACHE_RELPATH = Path(".simplecode") / "verdict_cache.json"

# `git rev-parse`/`status` against a local repo are near-instant -- this is
# generous headroom over what either could plausibly take, not a budget that
# scales with repo size (unlike the whole-repo scan this module exists to
# let a caller sometimes skip).
_GIT_TIMEOUT = 10.0


def _run_git(root: Path, *args: str) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args], cwd=root, capture_output=True, text=True, timeout=_GIT_TIMEOUT, check=False
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return result.stdout if result.returncode == 0 else None


def _head_sha(root: Path) -> str | None:
    out = _run_git(root, "rev-parse", "HEAD")
    return out.strip() if out else None


def _tree_is_clean(root: Path) -> bool:
    """False on any uncommitted change, any untracked file, or if git itself
    cannot be consulted -- `git status --porcelain` reports both in one call,
    respecting .gitignore, so a fresh untracked .py file is caught the same
    way a modified tracked one is.

    The cache file itself is excluded from this check by pathspec, not by
    relying on the caller's .gitignore -- a repo that hasn't gitignored
    `.simplecode/` would otherwise poison its OWN cache on the very first
    write: the just-written verdict_cache.json shows up as untracked, which
    would make every subsequent run see a "dirty" tree forever after."""
    out = _run_git(root, "status", "--porcelain", "--", ".", f":!{_CACHE_RELPATH.as_posix()}")
    return out is not None and out.strip() == ""


def _read_bytes_or_empty(path: Path) -> bytes:
    """A file that doesn't exist yet (e.g. no baseline written) hashes as an
    empty read -- absence is part of what changed, not ignored or a crash."""
    try:
        return path.read_bytes()
    except OSError:
        return b""


def _sha256_of_files(paths: list[Path]) -> str:
    """Hash of the CONCATENATED CONTENT of the given files, order-independent
    of caller sorting since callers pass an already-fixed order."""
    h = hashlib.sha256()
    for p in paths:
        h.update(_read_bytes_or_empty(p))
        h.update(b"\0")
    return h.hexdigest()


def compute_key(
    root: Path,
    scanner_id: str,
    *,
    registry_source_paths: Sequence[Path],
    config_paths: Sequence[Path] = (),
    extra: str = "",
) -> str | None:
    """A cache key valid ONLY when the working tree exactly matches a known
    commit -- `None` (never guess) when git can't confirm that.

    `registry_source_paths`: the scanner's own detector/logic source files --
    a changed detector must invalidate every cached verdict it could have
    produced differently, without hand-maintaining a version counter that
    silently drifts from the code it describes.
    `config_paths`: files outside the tracked-and-scanned set whose content
    the verdict also depends on (e.g. corpus_exempt.yaml, a baseline file).
    `extra`: any other input that changes the verdict for the same tree
    (mode string, --staged flag, ...).
    """
    if not _tree_is_clean(root):
        return None
    head = _head_sha(root)
    if head is None:
        return None
    registry_hash = _sha256_of_files(sorted(registry_source_paths))
    config_hash = _sha256_of_files(sorted(Path(p) for p in config_paths))
    payload = f"{scanner_id}|{head}|{registry_hash}|{config_hash}|{extra}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _load_cache(root: Path) -> dict:
    path = root / _CACHE_RELPATH
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def lookup(root: Path, scanner_id: str, key: str | None) -> dict | None:
    """The cached record for an exact key match, or `None` -- absence, a
    key mismatch, or a malformed cache file are indistinguishable to the
    caller on purpose: all three mean "run the real scan"."""
    if key is None:
        return None
    entry = _load_cache(root).get(scanner_id)
    if (not isinstance(entry, dict) or entry.get("key") != key
            or not isinstance(entry.get("summary"), str)):
        return None
    return entry


def record(root: Path, scanner_id: str, key: str, summary: str) -> None:
    """Only ever called by a caller that just observed a GREEN verdict --
    this module has no opinion on what counts as green, it only stores what
    it's told. A write failure here is not fatal to the caller's own verdict
    (the scan already ran and already reported); it only costs the NEXT
    run its cache hit, so failures are swallowed, not raised."""
    from simplecode.utils.atomic_io import write_text_durable

    path = root / _CACHE_RELPATH
    data = _load_cache(root)
    data[scanner_id] = {
        "key": key,
        "recorded_at": time.time(),
        "summary": summary,
    }
    try:
        write_text_durable(path, json.dumps(data, indent=1, sort_keys=True))
    except OSError:
        pass
