# -*- coding: utf-8 -*-
"""debt_materializer.py -- materializes THIS ORGAN'S findings into physical tasks/backlog/.

Enforces the DGX-169 Axiom: 'To state in chat is not to record. To record is to write on disk.'
Every detected corruption, linter omission, angry path or quality vice is converted
directly into a trackable markdown task under tasks/backlog/DEBT-<ID>.md.

IT READS FOUR SOURCES AND NAMES THEM. Until 2026-09-05 it printed
``OK: all findings are already registered in tasks/`` -- a sentence about ALL of
a repo's findings, emitted by an organ that looks at four things. Measured on
own_chats 2026-09-04: that OK, rc=0, printed the same minute that ``ruff check .``
gave 12 errors, ``simplecode hunt`` 1 ghost_task, ``simplecode sunset-audit`` 57
exemptions, ``backlog_verifier --gate`` 1 contract breach and ``simplecode
telemetry`` 3 blind instruments -- none of them with a task file. The OK was
honest about its own four sources (all four measured 0 that day) and mute about
the other five, and nothing in its output let a reader tell the two apart.

THREE STATES THAT SHARED ONE STRING, now three strings:
  * the four sources saw nothing            -> "0 hallazgos y 0 fichas nuevas"
  * they saw findings that already had a task -> "los hallazgos ... YA tenian ficha"
  * they saw findings with no task            -> "N ficha(s) nueva(s)"
The old sentence was the ``else`` branch of ``if created:``, so it said "already
registered" when it meant "nothing was found".

AND A SOURCE THAT COULD NOT RUN NO LONGER LEAVES BY THE SAME DOOR AS A ZERO.
The probe source is behind ``except Exception``; with logging off by default a
crashed source was indistinguishable from a clean one. Measured by injecting a
failure into ``run_all_probes``: it printed OK, rc=0. It now prints
``NO SE PUDO CORRER`` and counts into ``could_not_run``, which ``--gate`` turns
into a non-zero exit. A report with ``could_not_run > 0`` is not a clean report,
however many rows pass.

Declared asymmetry, on purpose: sources 1-3 are NOT wrapped. If one of them
raises, this command dies loudly with a traceback and a non-zero exit, which is
already the correct behaviour -- there was nothing to fix there. Only source 4
was swallowing, and only source 4 was changed. Wrapping the other three would
have converted three loud failures into three quiet report rows.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.verification import hook_receipts, ledger_schema
from simplecode.guards import angry_path, corruption_guard, unselected_rules
from simplecode.utils.git_utils import git_ls_files

logger = logging.getLogger(__name__)

# A source row: (name, findings, detail). ``findings is None`` means the source
# COULD NOT RUN -- deliberately not the integer 0, so that "saw nothing" and
# "could not look" can never collapse into the same value the way the old
# message collapsed them into the same string.
Fuente = tuple[str, "int | None", str]

# Sources this organ does NOT read. Named so its silence is not read as
# coverage: a finding from any of these is NOT materialized here.
FUENTES_NO_CONSULTADAS: tuple[tuple[str, str], ...] = (
    ("ruff", "ruff check ."),
    ("ghost tasks", "simplecode hunt --gate"),
    ("exenciones sin caducidad", "simplecode sunset-audit"),
    ("contratos de ficha", "python -m simplecode.verification.backlog_verifier --root . --gate"),
    ("instrumentos ciegos", "simplecode telemetry"),
)


def _materialize_probe_findings(
    root: Path, backlog_dir: Path, done_dir: Path, fuentes: list[Fuente]
) -> list[Path]:
    """Source 4: dynamic adversarial probes (Tier 3).

    Extracted from ``materialize_satellite_debt`` so that a source which could
    not run gets a row of its own -- and so the parent stays under the
    complexity ceiling ruff already flagged it over (C901, 11 > 10, measured on
    the unmodified file 2026-09-05).
    """
    created_tasks: list[Path] = []
    try:
        from simplecode.verification import adversarial_probes
        probe_results = adversarial_probes.run_all_probes(root)
    except Exception as exc:
        # NOT a silent skip. The old code logged at DEBUG (off by default) and
        # returned, so a crashed probe source printed the same OK as a clean one.
        logger.warning("Dynamic behavioral probe scan could not run: %s", exc)
        fuentes.append(("adversarial_probes", None,
                        f"NO SE PUDO CORRER: {type(exc).__name__}: {exc}"))
        return created_tasks

    failed = [r for r in probe_results if r.status == "FAILED" and r.findings]
    fuentes.append(("adversarial_probes", len(failed),
                    f"{len(failed)} hallazgo(s) sobre {len(probe_results)} sonda(s) corrida(s)"))
    for r in failed:
        clean_probe_id = r.probe_id.replace("_", "-").replace(" ", "-").upper()
        task_id = f"DEBT-PROBE-{clean_probe_id}"
        task_file = backlog_dir / f"{task_id}.md"
        done_file = done_dir / f"{task_id}.md" if done_dir.is_dir() else None
        if not task_file.is_file() and not (done_file and done_file.is_file()):
            findings_md = "\n".join(
                f"- [{f.severity}] {f.title}: {f.evidence}" for f in r.findings
            )
            content = (
                ledger_schema.render_frontmatter(
                    id=task_id, title=f"Dynamic behavioral probe failure: {r.name}",
                    status="open", severity="P0",
                    satd_family="BEHAVIORAL_PROBE_DEBT",
                    close_check={"cmd": "python3 -m simplecode.verification.adversarial_probes --root . --gate",
                                 "expect": "exit_zero"},
                    risk_score=9, blast_radius="HIGH",
                    lifespan="introduced", tag="BUG",
                ) + "\n"
                f"# Dynamic Behavioral Probe Failure: {r.name}\n\n"
                f"The adversarial probe detected behavioral defects or excessive mock theater:\n\n"
                f"<!-- findings:start -->\n"
                f"{findings_md}\n"
                f"<!-- findings:end -->\n\n"
                f"```json queue-job\n{{\n  \"name\": \"fix_probe_{clean_probe_id.lower()}\",\n  \"command\": \"python3 -m simplecode.verification.adversarial_probes --root . --gate\",\n  \"artifact\": \"tasks/backlog/{task_id}.md\"\n}}\n```\n"
            )
            atomic_io.write_text_durable(task_file, content)
            created_tasks.append(task_file)
    return created_tasks


def materialize_satellite_debt(root: Path, fuentes: list[Fuente] | None = None) -> list[Path]:
    """Scan root and materialize any untracked debt findings into tasks/backlog/.

    Returns the list of task files created, exactly as before. When the caller
    passes ``fuentes``, one row per CONSULTED source is appended to it -- also
    when that source found zero, because a printed zero is a measured zero and
    an omitted zero is indistinguishable from a source nobody knew to look at.

    The report leaves by parameter and NOT by the return value, on purpose:
    returning a tuple let ``assert len(tasks) >= 1`` in
    ``tests/test_full_coverage_gap.py:186`` pass with ``len(tuple) == 2``
    always -- an assertion about the SUBJECT silently turned into an assertion
    about the shape of the return.
    """
    created_tasks = []
    fuentes = [] if fuentes is None else fuentes
    backlog_dir = root / "tasks" / "backlog"
    backlog_dir.mkdir(parents=True, exist_ok=True)
    done_dir = root / "tasks" / "done"

    tracked = git_ls_files(root)

    # 1. Unselected rules
    missing_rules = unselected_rules.audit_linter_rules(root)
    fuentes.append(("unselected_rules", len(missing_rules), f"{len(missing_rules)} hallazgo(s)"))
    if missing_rules:
        task_id = "DEBT-UNSELECTED-RULES"
        task_file = backlog_dir / f"{task_id}.md"
        done_file = done_dir / f"{task_id}.md" if done_dir.is_dir() else None
        if not task_file.is_file() and not (done_file and done_file.is_file()):
            content = (
                ledger_schema.render_frontmatter(
                    id=task_id, title="Mandatory quality rules omitted (GS2-192)",
                    status="open", severity="P0", satd_family="CONFIG_DEBT",
                    close_check={"cmd": "python3 -m simplecode.guards.unselected_rules --gate",
                                 "expect": "exit_zero"},
                    risk_score=9, blast_radius="HIGH",
                    lifespan="introduced", tag="BUG",
                ) + "\n"
                f"# Mandatory Quality Rules Omitted (GS2-192)\n\n"
                f"The repository configuration does not select the mandatory quality rules:\n\n"
                f"<!-- findings:start -->\n"
                + "\n".join(f"- pyproject.toml: missing mandatory rule `{r}`" for r in missing_rules)
                + "\n<!-- findings:end -->\n\n"
                f"```json queue-job\n{{\n  \"name\": \"fix_unselected_rules\",\n  \"command\": \"python3 -m simplecode.guards.unselected_rules --gate\",\n  \"artifact\": \"tasks/backlog/{task_id}.md\"\n}}\n```\n"
            )
            atomic_io.write_text_durable(task_file, content)
            created_tasks.append(task_file)

    # 2. Corruption findings
    corruptions = corruption_guard.scan(tracked)
    fuentes.append(("corruption_guard", len(corruptions),
                    f"{len(corruptions)} hallazgo(s) sobre {len(tracked)} archivo(s) rastreado(s)"))
    if corruptions:
        task_id = "DEBT-BYTE-CORRUPTION"
        task_file = backlog_dir / f"{task_id}.md"
        done_file = done_dir / f"{task_id}.md" if done_dir.is_dir() else None
        if not task_file.is_file() and not (done_file and done_file.is_file()):
            content = (
                ledger_schema.render_frontmatter(
                    id=task_id, title="Byte corruption and encoding defects (GS2-182)",
                    status="open", severity="P1", satd_family="BYTE_CORRUPTION_DEBT",
                    close_check={"cmd": "python3 -m simplecode.guards.corruption_guard",
                                 "expect": "exit_zero"},
                    risk_score=8, blast_radius="HIGH",
                    lifespan="introduced", tag="BUG",
                ) + "\n"
                f"# Byte Corruption & Encoding Defects (GS2-182)\n\n"
                f"NUL bytes, BOMs, CRLF or soft-hyphens detected in tracked files:\n\n"
                f"<!-- findings:start -->\n"
                + "\n".join(f"- {c}" for c in corruptions[:50])
                + (f"\n- ... and {len(corruptions) - 50} more corrupted files." if len(corruptions) > 50 else "")
                + "\n<!-- findings:end -->\n\n"
                f"```json queue-job\n{{\n  \"name\": \"fix_byte_corruption\",\n  \"command\": \"python3 -m simplecode.guards.corruption_guard\",\n  \"artifact\": \"tasks/backlog/{task_id}.md\"\n}}\n```\n"
            )
            atomic_io.write_text_durable(task_file, content)
            created_tasks.append(task_file)

    # 3. Angry Path findings
    angry_findings = angry_path.scan_angry_path(tracked)
    fuentes.append(("angry_path", len(angry_findings),
                    f"{len(angry_findings)} hallazgo(s) sobre {len(tracked)} archivo(s) rastreado(s)"))
    if angry_findings:
        task_id = "DEBT-ANGRY-PATH-DEGRADATION"
        task_file = backlog_dir / f"{task_id}.md"
        done_file = done_dir / f"{task_id}.md" if done_dir.is_dir() else None
        if not task_file.is_file() and not (done_file and done_file.is_file()):
            content = (
                ledger_schema.render_frontmatter(
                    id=task_id, title="Silent error swallowing and dummy fallbacks (Rule B3)",
                    status="open", severity="P1", satd_family="ANGRY_PATH_DEBT",
                    close_check={"cmd": "python3 -m simplecode.guards.angry_path --gate",
                                 "expect": "exit_zero"},
                    risk_score=8, blast_radius="HIGH",
                    lifespan="introduced", tag="BUG",
                ) + "\n"
                f"# Silent Error Swallowing & Dummy Fallbacks (Rule B3)\n\n"
                f"Empty catch blocks, blind except handlers or dummy returns detected:\n\n"
                f"<!-- findings:start -->\n"
                + "\n".join(f"- {af}" for af in angry_findings[:50])
                + (f"\n- ... and {len(angry_findings) - 50} more silent error sites." if len(angry_findings) > 50 else "")
                + "\n<!-- findings:end -->\n\n"
                f"```json queue-job\n{{\n  \"name\": \"fix_angry_path\",\n  \"command\": \"python3 -m simplecode.guards.angry_path --gate\",\n  \"artifact\": \"tasks/backlog/{task_id}.md\"\n}}\n```\n"
            )
            atomic_io.write_text_durable(task_file, content)
            created_tasks.append(task_file)

    # 4. Dynamic Adversarial Probe findings (Tier 3)
    created_tasks.extend(
        _materialize_probe_findings(root, backlog_dir, done_dir, fuentes)
    )

    return created_tasks


def _print_source_report(root: Path, created: list[Path], fuentes: list[Fuente]) -> int:
    """Print WHAT was consulted and what was not, with the zeros printed.

    Returns the number of sources that COULD NOT RUN, which is what ``--gate``
    turns into an exit code.
    """
    print(f"[debt-materializer] FUENTES CONSULTADAS en {root} "
          f"(un cero es un cero medido, no una omision)")
    for nombre, _hallazgos, detalle in fuentes:
        print(f"  {nombre:<26}{detalle}")
    no_corridas = sum(1 for _n, hallazgos, _d in fuentes if hallazgos is None)
    print("[debt-materializer] FUENTES NO CONSULTADAS por este organo "
          "-- su hallazgo NO se materializa aqui")
    for nombre, cmd in FUENTES_NO_CONSULTADAS:
        print(f"  {nombre:<26}NO CONSULTADA  ->  {cmd}")
    if created:
        print(f"[debt-materializer] {len(created)} ficha(s) nueva(s) en "
              f"{root / 'tasks' / 'backlog'}:")
        for t in created:
            print(f"  + {t.name}")
    elif any(hallazgos for _n, hallazgos, _d in fuentes):
        print("[debt-materializer] 0 fichas nuevas: los hallazgos de estas fuentes "
              "YA tenian ficha en tasks/.")
    else:
        print("[debt-materializer] 0 hallazgos y 0 fichas nuevas EN ESTAS FUENTES. "
              "Esto no dice que el repo no tenga deuda: dice que estas fuentes no vieron nada.")
    if no_corridas:
        print(f"[debt-materializer] could_not_run = {no_corridas}. Este informe NO esta limpio.")
    else:
        print("[debt-materializer] could_not_run = 0")
    return no_corridas


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Materialize audit findings into tasks/backlog/ (DGX-169)")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--fleet", type=Path, default=None, help="Scan and materialize across entire fleet directory")
    # `--gate` exists because a `close_check` may carry neither a pipe nor a
    # `grep` (`backlog_verifier` rejects it: "Prohibited shell injection or
    # pipeline operators in verification_command"), so the verdict has to fit
    # in ONE command's exit code. It blocks on the two conditions that mean the
    # tree is not up to date: a source that could not run (a report with
    # could_not_run > 0 is not a clean report) and a task file that had to be
    # materialized right now (there was unregistered debt a second ago).
    ap.add_argument("--gate", action="store_true",
                    help="Exit 1 if a source could not run, or if task files had to be materialized")
    args = ap.parse_args(argv)

    if args.fleet:
        fleet_dir = args.fleet.resolve()
        total_created = 0
        total_no_corridas = 0
        for p in sorted(fleet_dir.iterdir()):
            if p.is_dir() and hook_receipts.is_git_repo(p):
                fuentes: list[Fuente] = []
                created = materialize_satellite_debt(p, fuentes)
                print(f"[{p.name}]")
                total_no_corridas += _print_source_report(p, created, fuentes)
                total_created += len(created)
        print(f"\n[debt-materializer] fleet: {total_created} ficha(s) nueva(s), "
              f"could_not_run = {total_no_corridas}.")
        return 1 if (args.gate and (total_created or total_no_corridas)) else 0

    root = args.root.resolve()
    fuentes = []
    created = materialize_satellite_debt(root, fuentes)
    no_corridas = _print_source_report(root, created, fuentes)
    return 1 if (args.gate and (created or no_corridas)) else 0


if __name__ == "__main__":
    sys.exit(main())
