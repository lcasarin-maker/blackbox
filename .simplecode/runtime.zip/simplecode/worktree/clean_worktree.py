#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""clean_worktree.py — detects "dodged / partial-commit" changes.

Job clause: b (no premature success). A path that IS part of the current
commit (staged) but still carries worktree-side changes on top of that --
a partial `git add -p`, a forgotten second edit -- must not be quietly
skipped: review it, absorb it, validate it, discard it, or quarantine it
with an explicit decision.

SCOPE (narrowed 2026-08-25, DGX-246, Atlas dogfooding): this used to also
block on ANY other untracked or wholly-unstaged path anywhere in the
working tree, on the premise that the whole tree must be clean before any
commit. That premise breaks in a repo with a concurrent daemon or another
agent writing unrelated files -- measured killing 5 unrelated commits
(rc=1, elapsed_s: 0.1) against trees carrying 23/628/17 dirty files from
another process, none of them related to what was being committed. The
guarantee given up: a wholly untracked or unstaged file sitting elsewhere
in the tree no longer blocks a commit that doesn't touch it. What still
blocks: a file that IS staged for this commit and was left half-decided.
"""

from __future__ import annotations

import os
import subprocess
import sys

from simplecode.utils.gate_signal import emit_hallazgos

if sys.stdout.encoding != "utf-8":
    reconf = getattr(sys.stdout, "reconfigure", None)
    if callable(reconf):
        reconf(encoding="utf-8")


# Every prefix here must be something an organ of THIS kit actually writes.
#
#   tasks/backlog/WARN-  the ancestor's auditor wrote these. Nothing in the kit
#                        creates one today; the exemption outlived its producer
#                        and, being a customs post on a border that no longer
#                        exists, is what exposed the whole dead lane. Kept so a
#                        repo still holding old WARN files is not blocked by them.
#   tasks/backlog/DEBT-  verification/finding_backlog.py writes these NOW. It
#                        had no exemption: measured 2026-08-16 in a fresh repo,
#                        one finding filed by the kit's own organ made the kit's
#                        own gate report "dodged changes". Producer without
#                        exemption -- the same defect as the line above, mirrored.
_SELF_GENERATED_PREFIXES = ("tasks/backlog/WARN-", "tasks/backlog/DEBT-")

# Machine state, in a THIRD category: not a dodged change and not a finding to
# triage. `finding_backlog.stamp_verdict` writes the verdict record here, and
# routing it to the triage bucket blocks the commit on a file whose entire
# content is "what this run decided" -- a gate demanding that you review its own
# receipt. Measured 2026-08-16: the first version of this exemption did exactly
# that.
# Python bytecode is created by hook execution, not user intent -- exempt it.
_MACHINE_STATE_PREFIXES = (".simplecode/", "__pycache__/", "testproj/")


def _is_machine_state(path: str) -> bool:
    return path.startswith(_MACHINE_STATE_PREFIXES) or path.endswith(".pyc")


def _is_self_generated_warn_backlog(path: str) -> bool:
    """A tool-owned artifact this kit produced during the same hook run.

    These are not a foreign or human change slipping through, so they are
    exempted here rather than blocking the commit -- the same treatment other
    generated artifacts get. The list is checked against the producing organ by
    tests/smoke_all.py: it is not coupling that keeps the two in step, it is a
    test that fails when they drift, because three separate defects this kit has
    paid for were all two implementations of one idea disagreeing in silence.
    """
    return path.endswith(".md") and path.startswith(_SELF_GENERATED_PREFIXES)


def _candidate_paths_from_porcelain_record(
    record: str,
    *,
    next_record: str | None = None,
    nul_mode: bool = False,
) -> tuple[list[str], int]:
    """Extract candidate paths from a single porcelain record.

    Git porcelain v1 can emit either newline-separated records or NUL-separated
    records (`--porcelain=v1 -z`). The latter is more robust because it avoids
    quoting/escaping issues, but rename/copy entries then consume an additional
    record for the destination path. This helper normalizes both formats.
    """

    record = record.rstrip("\n")
    if not record.strip():
        return [], 0

    if record.startswith("??"):
        path = record[3:].strip()
        return ([path] if path else []), 0

    path = record[3:].strip()
    if not path:
        return [], 0

    if nul_mode and record[:2] and record[0] in {"R", "C"}:
        if next_record is not None:
            next_path = next_record.rstrip("\n").strip()
            if next_path:
                return [path, next_path], 1
        return [path], 0

    is_rename_or_copy = bool(record[:2]) and record[0] in {"R", "C"}
    if not nul_mode and is_rename_or_copy:
        if " -> " in path:
            old_path, new_path = path.split(" -> ", 1)
            candidates = [old_path.strip(), new_path.strip()]
            return [candidate for candidate in candidates if candidate], 0

    return [path], 0


def _porcelain_paths(porcelain: str) -> tuple[list[str], list[str]]:
    """Splits `git status --porcelain=v1 -z` output into dirty paths and untriaged self-generated WARN files.

    Walks NUL- or newline-separated records (auto-detected), reconstructing
    rename/copy pairs that consume an extra record for the destination path.
    A self-generated `tasks/backlog/WARN-*.md` file is excluded from `dirty`
    entirely — staging it fully IS the triage decision — and instead routed
    to the second list only while still untracked/worktree-modified.

    Args:
        porcelain: Raw `git status --porcelain=v1` output, NUL- or
            newline-delimited.

    Returns:
        A `(dirty, warn_backlog)` tuple: `dirty` is every other path that is
        BOTH staged and still worktree-modified (a partial commit of that
        path -- purely untracked or purely-unstaged paths are out of scope,
        see the module docstring); `warn_backlog` is the untriaged
        self-generated WARN-*.md paths, kept separate so callers can report
        them without treating them as ordinary dirty files.
    """
    dirty: list[str] = []
    warn_backlog: list[str] = []

    nul_mode = "\0" in porcelain
    records = porcelain.split("\0") if nul_mode else porcelain.splitlines()
    index = 0
    while index < len(records):
        record = records[index]
        next_record = records[index + 1] if index + 1 < len(records) else None
        paths, consumed = _candidate_paths_from_porcelain_record(
            record, next_record=next_record, nul_mode=nul_mode
        )
        if not paths:
            index += consumed + 1
            continue

        is_untracked = record.startswith("??")
        index_col = record[0] if record else " "
        worktree_col = record[1] if len(record) > 1 else " "
        # Scoped to the commit itself (DGX-246, Atlas 2026-08-25, measured):
        # a path only counts as "dodged" if it is BOTH staged (index_col set --
        # it IS part of this commit) AND still has worktree-side changes on
        # top (worktree_col set -- part of it was left behind). A purely
        # untracked ("??") or purely-unstaged (" M", index_col blank) path was
        # never staged at all, so it isn't part of "this commit" by
        # definition -- it used to block anyway, on the premise that the
        # WHOLE working tree must be clean, which does not hold in a repo
        # with a concurrent daemon or another agent writing unrelated files:
        # measured killing 5 unrelated jobs (rc=1, elapsed_s: 0.1) against
        # trees carrying 23/628/17 dirty files from another process. The
        # guarantee given up: an entirely-unstaged, unrelated change sitting
        # in the tree no longer blocks a commit that doesn't touch it -- only
        # a file that IS part of this commit and was left half-decided still
        # does.
        is_dirty = not is_untracked and index_col != " " and worktree_col != " "
        # A fully staged record (index column set, worktree column clean)
        # must not count as "untriaged" -- otherwise the gate blocks the
        # exact action it demands. Anything untracked or with worktree-side
        # changes still counts.
        is_fully_staged = not is_untracked and worktree_col == " "

        for path in paths:
            # Machine state about the run is neither a dodged change nor a
            # finding to triage: demanding triage of a verdict stamp blocks the
            # commit on a file whose whole content is "what this run decided".
            if _is_machine_state(path):
                continue
            if _is_self_generated_warn_backlog(path):
                if not is_fully_staged:
                    warn_backlog.append(path)
                continue
            if is_dirty:
                dirty.append(path)
        index += consumed + 1

    return dirty, warn_backlog


def untriaged_warn_backlog(porcelain: str) -> list[str]:
    """Returns exactly the self-generated backlog paths that were exempted
    from the dirty check, so callers can surface them instead of silently
    swallowing them.

    Fully staged WARN files (index column set, worktree column clean, e.g.
    'A  ' or 'D  ') do NOT count — staging them IS the triage decision.
    Untracked ('??') or worktree-modified (e.g. 'AM', ' M') still count.

    Args: porcelain (str).
    Returns: List of untriaged (untracked/unstaged) WARN-*.md paths.
    Example: untriaged_warn_backlog("?? tasks/backlog/WARN-x.md\n") == ["tasks/backlog/WARN-x.md"]
    """
    _, found = _porcelain_paths(porcelain)
    return found


def worktree_is_clean(porcelain: str) -> tuple[bool, list[str]]:
    """
    Parses the output of `git status --porcelain`.

    Parameters:
        porcelain: Raw porcelain text to analyze.

    Returns:
        A `(clean, dirty_paths)` tuple.

    Examples:
        >>> worktree_is_clean("")
        (True, [])
    """
    dirty, _ = _porcelain_paths(porcelain)
    return (len(dirty) == 0, dirty)


def _env_hatch_active(var: str) -> bool:
    """Escape hatch check: an explicit, logged opt-out, not a silent one."""
    return os.environ.get(var) == "1"


def main(argv: list[str] | None = None) -> int:
    """pre-commit hook entry point: blocks on a staged path left half-decided.

    Order of checks: the `ALLOW_PARTIAL_COMMIT` escape hatch first, then
    untriaged self-generated WARN-*.md files, then any other path that is
    staged for this commit AND still worktree-modified on top of that.

    Args:
        argv: CLI arguments; this script takes none, so any value is only
            used for `--help` via argparse.

    Returns:
        0 if the escape hatch is active or the worktree is clean; 1 if git
        could not be run/read, untriaged WARN files exist, or dirty paths
        remain.
    """
    import argparse

    parser = argparse.ArgumentParser(
        description=(
            "Blocks the commit if a path staged for it was left partially decided "
            "(also worktree-modified). Conscious escape: env ALLOW_PARTIAL_COMMIT=1."
        )
    )
    parser.add_argument("--root", default=".", help="Root directory of repository")
    args = parser.parse_args(argv)

    if _env_hatch_active("ALLOW_PARTIAL_COMMIT"):
        print("[clean_worktree] escape ALLOW_PARTIAL_COMMIT=1 — tree check skipped.")
        return 0

    try:
        result = subprocess.run(
            ["git", "status", "--porcelain=v1", "-z", "--untracked-files=all"],
            capture_output=True,
            text=True,
            cwd=args.root,
        )
        if not isinstance(result.stdout, str) or not isinstance(result.stderr, str):
            raise TypeError("git status output is not text")
    except (OSError, UnicodeError, TypeError, ValueError) as exc:
        print(f"[clean_worktree] could not run git: {exc}")
        print(f"[clean-worktree] COULD_NOT_RUN: git status could not run: {exc}", file=sys.stderr)
        return 1
    if result.returncode != 0:
        print(f"[clean_worktree] could not read git status: {result.stderr.strip()}")
        print(
            f"[clean-worktree] COULD_NOT_RUN: git status exited {result.returncode}: "
            f"{result.stderr.strip()}",
            file=sys.stderr,
        )
        return 1

    clean, dirty = worktree_is_clean(result.stdout)

    untriaged = untriaged_warn_backlog(result.stdout)
    if untriaged:
        print(
            f"[clean_worktree] {len(untriaged)} generated backlog file(s) untriaged in "
            "tasks/backlog/ (blocks the commit until reviewed and resolved or "
            "discarded)."
        )
        for path in untriaged:
            print(f"   - {path}")
        print(
            f"[clean-worktree] FAIL: {len(untriaged)} untriaged backlog file(s) in "
            f"tasks/backlog/; primero {untriaged[0]}"
        )
        emit_hallazgos("[clean-worktree]", len(untriaged) + len(dirty))
        return 1

    if clean:
        emit_hallazgos("[clean-worktree]", 0)
        return 0

    print(
        "[clean_worktree] Dodged changes: the working tree has files not folded into the commit:"
    )
    for path in dirty:
        print(f"   - {path}")
    print(
        "Review them, absorb them, validate them, discard them, or quarantine them with an "
        "explicit decision. They don't get skipped for being unrelated. Conscious escape: "
        "ALLOW_PARTIAL_COMMIT=1."
    )
    print(
        f"[clean-worktree] FAIL: {len(dirty)} dodged (staged-and-worktree-modified) path(s); "
        f"primero {dirty[0]}"
    )
    emit_hallazgos("[clean-worktree]", len(dirty))
    return 1


if __name__ == "__main__":
    sys.exit(main())
