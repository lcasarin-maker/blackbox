# -*- coding: utf-8 -*-
"""hook_suspension.py -- fleet-wide, contract-compliant suspend/restore of the
simplecode git hooks (CLAUDE.md "Suspension contract"): suspend = rename,
never delete; the manifest records sha256 + mode per file, an expiry, and
who watches it; restore refuses to touch what it cannot verify.

Replaces the prior reference implementation (~/.claude/tools/
restore_hooks_reference.py -> goodcode/worktree/restore_hooks.py), which
rotted silently when the "goodcode" repo was renamed to "simplecode" and the
pointer was never updated -- the exact failure mode this module exists to
prevent is what took out its own predecessor. This lives inside the kit
(version-controlled, tested, reviewable) rather than in ~/.claude (not a git
repo, no history, no remote), per the annotation left on the dead reference.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import stat
import subprocess
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from simplecode.utils import atomic_io
from simplecode.utils.git_utils import run_git

HOOK_NAMES = ("pre-commit", "pre-push", "post-commit")
SUSPENDED_SUFFIX = ".suspended-simplecode"
SUPERSEDED_SUFFIX = ".superseded-simplecode"
MANAGED_MARKER = "# simplecode-managed-hook:v1"
_LEGACY_DISPATCHES = (
    "simplecode.verification.gate_runner",
    "simplecode.verification.hook_receipts",
)
_DATE_RE = re.compile(r"\b\d{4}-\d{2}-\d{2}\b")
_REQUIRED_ENTRY_FIELDS = {
    "repo", "hook", "suspended_path", "sha256", "mode", "owner", "expiry", "restored",
}
_SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")
_MODE_RE = re.compile(r"0o[0-7]{3,4}\Z")
_MANIFEST_STATES = frozenset({"planned", "suspended", "rolled_back", "superseded", "cancelled", "restored"})


class ManifestError(RuntimeError):
    """The suspension ledger cannot be trusted or interpreted."""


class SuspensionError(RuntimeError):
    """A suspension would overwrite or lose an existing hook state."""


def default_manifest_path() -> Path:
    return Path.home() / ".claude" / "tools" / "simplecode_suspension_manifest.json"


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _validate_manifest_expiry(expiry: object, manifest_path: Path) -> None:
    if not isinstance(expiry, str):
        raise ManifestError(
            f"invalid manifest entry in {manifest_path}: expiry must be text"
        )
    date_match = _DATE_RE.search(expiry)
    if not date_match:
        return
    try:
        date.fromisoformat(date_match.group())
    except ValueError as exc:
        raise ManifestError(
            f"invalid manifest entry in {manifest_path}: expiry contains an impossible ISO date"
        ) from exc


def _validate_manifest_optional_fields(entry: dict[str, Any], manifest_path: Path) -> None:
    if "state" in entry and (
        not isinstance(entry["state"], str) or entry["state"] not in _MANIFEST_STATES
    ):
        raise ManifestError(f"invalid manifest entry in {manifest_path}: invalid state")
    for field in ("suspended_at", "restored_at"):
        if field in entry and not isinstance(entry[field], str):
            raise ManifestError(f"invalid manifest entry in {manifest_path}: {field} must be text")
    if ("superseded_path" in entry) != ("superseded_sha256" in entry):
        raise ManifestError(f"invalid manifest entry in {manifest_path}: incomplete superseded receipt")
    if "superseded_path" in entry and (
        not isinstance(entry["superseded_path"], str) or not entry["superseded_path"]
    ):
        raise ManifestError(f"invalid manifest entry in {manifest_path}: invalid superseded path")


def _validate_manifest_entry(entry: dict[str, Any], manifest_path: Path) -> None:
    missing = _REQUIRED_ENTRY_FIELDS - entry.keys()
    if missing:
        raise ManifestError(f"invalid manifest entry in {manifest_path}: missing {sorted(missing)}")
    _validate_manifest_expiry(entry["expiry"], manifest_path)
    if (entry["hook"] not in HOOK_NAMES or not isinstance(entry["restored"], bool)
            or not isinstance(entry["repo"], str) or not entry["repo"]
            or not isinstance(entry["suspended_path"], str) or not entry["suspended_path"]
            or not isinstance(entry["owner"], str) or not entry["owner"]):
        raise ManifestError(f"invalid manifest entry in {manifest_path}: invalid field type or value")
    if not isinstance(entry["sha256"], str) or not _SHA256_RE.fullmatch(entry["sha256"]):
        raise ManifestError(f"invalid manifest entry in {manifest_path}: sha256 must be 64 lowercase hex characters")
    if not isinstance(entry["mode"], str) or not _MODE_RE.fullmatch(entry["mode"]):
        raise ManifestError(f"invalid manifest entry in {manifest_path}: mode must be an octal permission string")
    if "superseded_sha256" in entry and (
        not isinstance(entry["superseded_sha256"], str)
        or not _SHA256_RE.fullmatch(entry["superseded_sha256"])
    ):
        raise ManifestError(f"invalid manifest entry in {manifest_path}: invalid superseded sha256")
    _validate_manifest_optional_fields(entry, manifest_path)


def _load_manifest(manifest_path: Path) -> dict[str, Any]:
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {"entries": []}
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ManifestError(f"cannot read valid JSON from {manifest_path}: {exc}") from exc
    if not isinstance(manifest, dict) or not isinstance(manifest.get("entries"), list):
        raise ManifestError(f"invalid manifest shape in {manifest_path}: expected an entries list")
    if any(not isinstance(entry, dict) for entry in manifest["entries"]):
        raise ManifestError(f"invalid manifest shape in {manifest_path}: every entry must be an object")
    for entry in manifest["entries"]:
        _validate_manifest_entry(entry, manifest_path)
    return manifest


def _save_manifest(manifest_path: Path, manifest: dict[str, Any]) -> None:
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_io.write_text_durable(
        manifest_path,
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        backup=True,
    )


def is_simplecode_hook(hook_path: Path) -> bool:
    """True iff `hook_path` is a launcher this kit installed (carries the marker)."""
    if not hook_path.is_file():
        return False
    try:
        content = hook_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    if MANAGED_MARKER in content:
        return True
    # Compatibility for launchers installed before the dedicated marker existed.
    # Both the shared runner assignment and one exact simplecode dispatch are
    # required, so an unrelated hook that happens to launch Python stays untouched.
    return "RUNNER='python" in content and any(dispatch in content for dispatch in _LEGACY_DISPATCHES)


def _hooks_dir(root: Path) -> Path | None:
    """Resolve the repository's shared hooks directory, including linked worktrees."""
    direct = root / ".git" / "hooks"
    if direct.is_dir():
        return direct
    rc, stdout, _ = run_git(["rev-parse", "--path-format=absolute", "--git-common-dir"], root)
    if rc != 0:
        return None
    common = Path(stdout.decode("utf-8", "surrogateescape").strip())
    hooks = common / "hooks"
    return hooks if hooks.is_dir() else None


def _entry(root: Path, hook_path: Path, suspended_path: Path, owner: str, expiry_note: str) -> dict[str, Any]:
    data = hook_path.read_bytes()
    return {
        "repo": str(root),
        "hook": hook_path.name,
        "suspended_path": str(suspended_path),
        "sha256": _sha256(data),
        "mode": oct(stat.S_IMODE(hook_path.stat().st_mode)),
        "suspended_at": datetime.now(timezone.utc).isoformat(),
        "owner": owner,
        "expiry": expiry_note,
        "state": "planned",
        "restored": False,
    }


def _prepare_suspend_repo(
    root: Path, *, owner: str, expiry_note: str
) -> list[tuple[dict[str, Any], Path, Path]]:
    root = root.resolve()
    hooks_dir = _hooks_dir(root)
    if hooks_dir is None:
        raise SuspensionError(f"repository hooks directory unavailable ({root})")
    plan: list[tuple[dict[str, Any], Path, Path]] = []
    for name in HOOK_NAMES:
        hook_path = hooks_dir / name
        if not is_simplecode_hook(hook_path):
            continue
        suspended_path = hooks_dir / f"{name}{SUSPENDED_SUFFIX}"
        if suspended_path.exists():
            raise SuspensionError(f"{name}: suspended target already exists ({suspended_path})")
        plan.append((_entry(root, hook_path, suspended_path, owner, expiry_note), hook_path, suspended_path))
    return plan


def _apply_suspend_plan(plan: list[tuple[dict[str, Any], Path, Path]]) -> None:
    moved: list[tuple[dict[str, Any], Path, Path]] = []
    try:
        for entry, hook_path, suspended_path in plan:
            hook_path.rename(suspended_path)
            atomic_io.fsync_dir(hook_path.parent)
            entry["state"] = "suspended"
            moved.append((entry, hook_path, suspended_path))
    except OSError as exc:
        for entry, hook_path, suspended_path in reversed(moved):
            if suspended_path.exists() and not hook_path.exists():
                suspended_path.rename(hook_path)
                atomic_io.fsync_dir(hook_path.parent)
            entry["state"] = "rolled_back"
        raise SuspensionError(f"rename failed; completed moves were rolled back: {exc}") from exc


def suspend_repo(root: Path, *, owner: str, expiry_note: str) -> list[dict[str, Any]]:
    """Rename every installed simplecode hook in `root` to `<name>.suspended-simplecode`.

    Returns the manifest entries created (also appended to the shared
    manifest file). A repo with no simplecode hooks installed yields no
    entries -- this is idempotent to call on an already-suspended or
    never-installed repo.
    """
    plan = _prepare_suspend_repo(root, owner=owner, expiry_note=expiry_note)
    _apply_suspend_plan(plan)
    return [entry for entry, _, _ in plan]


def _utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def _supersede_entry(
    hooks_dir: Path, suspended_path: Path, entry: dict[str, Any], verified_sha: str
) -> tuple[str | None, str | None]:
    """Close an entry whose live slot already holds a fresh simplecode launcher.

    A peer session (hook_install/satellite-sync) reinstalled the hook while it
    was suspended. Refusing forever would leave the entry stuck open -- the
    "suspension never restored" failure the contract exists to prevent. But
    suspend = rename, never delete: the verified suspended bytes move to a
    timestamped sibling, recorded in the entry, and are never discarded.
    """
    hook_name = entry["hook"]
    kept_path = hooks_dir / f"{hook_name}{SUPERSEDED_SUFFIX}-{_utc_stamp()}"
    if kept_path.exists():
        return None, f"{hook_name}: superseded target already exists ({kept_path}), refusing to overwrite"
    suspended_path.rename(kept_path)
    atomic_io.fsync_dir(hooks_dir)
    entry["superseded_path"] = str(kept_path)
    entry["superseded_sha256"] = verified_sha
    entry["restored"] = True
    entry["state"] = "superseded"
    entry["restored_at"] = datetime.now(timezone.utc).isoformat()
    return hook_name, None


def _cancel_verified_intent(hook_path: Path, entry: dict[str, Any]) -> tuple[str | None, str | None]:
    """Close a plan only when the untouched live hook still matches its receipt."""
    hook_name = str(entry["hook"])
    try:
        live_sha = _sha256(hook_path.read_bytes())
        live_mode = oct(stat.S_IMODE(hook_path.stat().st_mode))
    except OSError as exc:
        return None, f"{hook_name}: cannot verify live hook for cancellation ({exc})"
    if live_sha != entry.get("sha256"):
        return None, f"{hook_name}: live sha256 mismatch, refusing to cancel an unverified intent"
    if live_mode != entry.get("mode"):
        return None, f"{hook_name}: live mode mismatch, refusing to cancel an unverified intent"
    entry["restored"] = True
    entry["state"] = "cancelled"
    entry["restored_at"] = datetime.now(timezone.utc).isoformat()
    return hook_name, None


def _restore_entry(hooks_dir: Path, entry: dict[str, Any]) -> tuple[str | None, str | None]:
    """Restore one verified entry, returning (restored hook, refusal reason)."""
    hook_name = entry.get("hook")
    if hook_name not in HOOK_NAMES:
        return None, f"invalid hook name in manifest: {hook_name!r}"
    suspended_path = hooks_dir / f"{hook_name}{SUSPENDED_SUFFIX}"
    recorded_path = Path(str(entry.get("suspended_path", ""))).resolve()
    if recorded_path != suspended_path.resolve():
        return None, f"{hook_name}: manifest path escapes the repository hooks directory"
    hook_path = hooks_dir / hook_name
    if entry.get("state") in {"planned", "rolled_back"} and hook_path.is_file() and not suspended_path.exists():
        return _cancel_verified_intent(hook_path, entry)
    if not suspended_path.is_file():
        return None, f"{hook_name}: suspended file missing ({suspended_path})"
    data = suspended_path.read_bytes()
    actual_sha = _sha256(data)
    actual_mode = oct(stat.S_IMODE(suspended_path.stat().st_mode))
    if actual_sha != entry.get("sha256"):
        return None, f"{hook_name}: sha256 mismatch, refusing to restore over an unverified file"
    if actual_mode != entry.get("mode"):
        return None, f"{hook_name}: mode mismatch, refusing to restore an unverified file"
    if hook_path.exists():
        if is_simplecode_hook(hook_path):
            return _supersede_entry(hooks_dir, suspended_path, entry, actual_sha)
        return None, f"{hook_name}: a live hook already exists at {hook_path}, refusing to overwrite"
    suspended_path.rename(hook_path)
    atomic_io.fsync_dir(hook_path.parent)
    hook_path.chmod(int(entry["mode"], 8))
    entry["restored"] = True
    entry["state"] = "restored"
    entry["restored_at"] = datetime.now(timezone.utc).isoformat()
    return hook_name, None


def restore_repo(root: Path, manifest: dict[str, Any]) -> tuple[list[str], list[str]]:
    """Restore every verified entry, refusing any unknown state."""
    root = root.resolve()
    hooks_dir = _hooks_dir(root)
    if hooks_dir is None:
        return [], [f"repository hooks directory unavailable ({root})"]
    restored: list[str] = []
    refused: list[str] = []
    for entry in manifest.get("entries", []):
        if entry.get("repo") != str(root) or entry.get("restored"):
            continue
        hook_name, reason = _restore_entry(hooks_dir, entry)
        if hook_name:
            restored.append(hook_name)
        if reason:
            refused.append(reason)
    return restored, refused


def suspend_daemon() -> str:
    result = subprocess.run(
        ["systemctl", "--user", "stop", "simplecode-daemon.service"],
        capture_output=True, text=True, check=False,
    )
    return "stopped" if result.returncode == 0 else f"could not stop: {result.stderr.strip()}"


def restore_daemon() -> str:
    result = subprocess.run(
        ["systemctl", "--user", "start", "simplecode-daemon.service"],
        capture_output=True, text=True, check=False,
    )
    return "started" if result.returncode == 0 else f"could not start: {result.stderr.strip()}"


def _status_action(manifest: dict[str, Any], manifest_path: Path) -> int:
    open_entries = [entry for entry in manifest.get("entries", []) if not entry.get("restored")]
    print(f"[hook-suspension] {len(open_entries)} open suspension(s) in {manifest_path}")
    for entry in open_entries:
        print(f"  {entry['repo']}: {entry['hook']} (owner={entry['owner']}, expiry={entry['expiry']})")
    expired = []
    for entry in open_entries:
        match = _DATE_RE.search(str(entry.get("expiry", "")))
        if match and date.fromisoformat(match.group()) < date.today():
            expired.append(entry)
    if expired:
        print(f"[hook-suspension] BLOCKED: {len(expired)} suspension(s) expired")
        return 1
    return 0


def _suspend_action(args: argparse.Namespace, manifest: dict[str, Any], manifest_path: Path) -> int:
    if not args.roots or not args.owner or not args.expiry:
        print("[hook-suspension] BLOCKED: suspend requires --roots, --owner, and --expiry YYYY-MM-DD")
        return 2
    try:
        date.fromisoformat(args.expiry)
    except ValueError:
        print("[hook-suspension] BLOCKED: --expiry must be an ISO date (YYYY-MM-DD)")
        return 2
    for root in args.roots:
        try:
            plan = _prepare_suspend_repo(root, owner=args.owner, expiry_note=args.expiry)
        except (OSError, SuspensionError) as exc:
            print(f"[hook-suspension] BLOCKED: {root}: {exc}")
            return 1
        entries = [entry for entry, _, _ in plan]
        manifest.setdefault("entries", []).extend(entries)
        _save_manifest(manifest_path, manifest)
        try:
            _apply_suspend_plan(plan)
        except SuspensionError as exc:
            _save_manifest(manifest_path, manifest)
            print(f"[hook-suspension] BLOCKED: {root}: {exc}")
            return 1
        _save_manifest(manifest_path, manifest)
        print(f"[hook-suspension] {root}: suspended {[entry['hook'] for entry in entries]}")
    if not args.include_daemon:
        return 0
    daemon_result = suspend_daemon()
    print(f"[hook-suspension] daemon: {daemon_result}")
    return 0 if daemon_result == "stopped" else 1


def _restore_action(args: argparse.Namespace, manifest: dict[str, Any], manifest_path: Path) -> int:
    if not args.roots:
        print("[hook-suspension] BLOCKED: restore requires --roots")
        return 2
    any_refused = False
    for root in args.roots:
        restored, refused = restore_repo(root, manifest)
        print(f"[hook-suspension] {root}: restored {restored}")
        for reason in refused:
            print(f"  REFUSED: {reason}")
        any_refused = any_refused or bool(refused)
    if args.include_daemon:
        daemon_result = restore_daemon()
        print(f"[hook-suspension] daemon: {daemon_result}")
        any_refused = any_refused or daemon_result != "started"
    _save_manifest(manifest_path, manifest)
    return 1 if any_refused else 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Suspend/restore simplecode hooks fleet-wide (contract-compliant)")
    parser.add_argument("action", choices=["suspend", "restore", "status"])
    parser.add_argument("--roots", nargs="+", type=Path, required=False, default=[])
    parser.add_argument("--owner")
    parser.add_argument("--expiry", help="Required ISO date (YYYY-MM-DD) for suspend")
    parser.add_argument("--manifest", type=Path, default=None)
    parser.add_argument("--include-daemon", action="store_true")
    args = parser.parse_args(argv)
    manifest_path = args.manifest or default_manifest_path()
    try:
        manifest = _load_manifest(manifest_path)
    except ManifestError as exc:
        print(f"[hook-suspension] COULD_NOT_RUN: {exc}")
        return 2
    actions = {
        "status": lambda: _status_action(manifest, manifest_path),
        "suspend": lambda: _suspend_action(args, manifest, manifest_path),
        "restore": lambda: _restore_action(args, manifest, manifest_path),
    }
    return actions[args.action]()


if __name__ == "__main__":
    raise SystemExit(main())
