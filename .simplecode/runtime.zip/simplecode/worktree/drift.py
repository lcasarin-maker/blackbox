"""Validate a project against the concrete boundaries in its SPEC.md.

`find_deviations` keeps returning list[str]: it is called by cli_spec.py's
`deviations.extend(...)` and covered by tests outside this module's
ownership, both of which assume that shape. `build_drift_report` wraps the
same, real output into the typed `DriftReport` entity (SPEC §4) without
touching that external contract -- see `simplecode.entities` for why the
field list there differs from SPEC's.
"""

from __future__ import annotations

import re
from pathlib import Path

from simplecode.entities import DriftReport


def objective_deviations(content: str) -> list[str]:
    """Return missing or unfilled objective fields."""
    deviations = []
    if "## 0. Objective" not in content and "## 0. Objective (Structured" not in content:
        deviations.append("MISSING: SPEC.md has no structured Objective section")
    mission = re.search(r"\*\*Mission\*\*:\s*\[(.*?)\]", content)
    if mission and "One sentence" in mission.group(1):
        deviations.append("INCOMPLETE: SPEC.md mission is still the template")
    return deviations


def boundary_deviations(root: Path, content: str) -> list[str]:
    """Return imports that contradict an explicit non-UI boundary."""
    if "Not a web UI" not in content and "Not real-time" not in content:
        return []
    deviations = []
    out_of_scope = ("fastapi", "flask", "django", "streamlit", "gradio", "tkinter", "pyqt")
    for path in (root / "src").rglob("*.py") if (root / "src").is_dir() else ():
        try:
            source = path.read_text(encoding="utf-8")
        except OSError as exc:
            deviations.append(f"COULD NOT RUN: cannot read {path.relative_to(root)}: {exc}")
            continue
        for keyword in out_of_scope:
            if keyword in source and f"# drift:allow:{keyword}" not in source:
                deviations.append(f"BOUNDARY: {path.relative_to(root)} contains {keyword}")
    return deviations


def adr_deviations(root: Path) -> list[str]:
    """Return accepted ADRs that do not connect to the project mission."""
    deviations = []
    for adr in sorted((root / "docs" / "adr").glob("*.md")):
        if adr.name in {"README.md", "adr-template.md"}:
            continue
        try:
            adr_content = adr.read_text(encoding="utf-8")
        except OSError as exc:
            deviations.append(f"COULD NOT RUN: cannot read {adr.relative_to(root)}: {exc}")
            continue
        if "**Status**: Accepted" in adr_content and "mission" not in adr_content.lower():
            deviations.append(f"ALIGNMENT: {adr.name} does not reference the mission")
    return deviations


def version_deviations(root: Path, content: str) -> list[str]:
    """Return a deviation if SPEC.md's Template version and pyproject.toml's
    version have drifted apart. The two numbers are kept on the same axis
    deliberately -- a mismatch here is exactly the "lost control" failure
    mode this check exists to catch, not two independent version schemes.
    """
    spec_version = re.search(r"Template version:\s*([0-9]+\.[0-9]+\.[0-9]+)", content)
    if not spec_version:
        return []
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        return []
    try:
        py_content = pyproject.read_text(encoding="utf-8")
    except OSError as exc:
        return [f"COULD NOT RUN: cannot read pyproject.toml: {exc}"]
    py_version = re.search(r'^version\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"', py_content, re.M)
    if not py_version:
        return []
    if spec_version.group(1) != py_version.group(1):
        return [
            f"VERSION: SPEC.md Template version {spec_version.group(1)} != "
            f"pyproject.toml version {py_version.group(1)}"
        ]
    return []


def governance_deviations(root: Path, spec_content: str) -> list[str]:
    """Cross-check governing prose against live organs and hook policy."""
    deviations: list[str] = []
    config = root / ".pre-commit-config.yaml"
    config_text = config.read_text(encoding="utf-8") if config.is_file() else ""
    if "id: vices-semgrep" in config_text and re.search(
        r"(?im)^-\s+semgrep wiring .*before any gate.*honest", spec_content
    ):
        deviations.append("GOVERNANCE: SPEC says Semgrep wiring is out of scope but vices-semgrep is live")

    redesign = root / "docs" / "REDESIGN_KIT_V2.md"
    redesign_text = redesign.read_text(encoding="utf-8") if redesign.is_file() else ""
    retired = set(re.findall(r"\*[^*]*?/([A-Za-z_][\w]*\.py)\* \(removed\)", redesign_text))
    for adr in sorted((root / "docs" / "adr").glob("*.md")) if (root / "docs" / "adr").is_dir() else ():
        adr_text = adr.read_text(encoding="utf-8")
        if "**Status**: Accepted" not in adr_text:
            continue
        for filename in sorted(retired):
            if f"`{Path(filename).stem}`" in adr_text or f"`{filename}`" in adr_text:
                deviations.append(f"GOVERNANCE: accepted {adr.name} requires retired organ {filename}")

    dangling = root / "src" / "simplecode" / "verification" / "dangling_refs.py"
    dangling_text = dangling.read_text(encoding="utf-8") if dangling.is_file() else ""
    if "deliberately **not** wired" in redesign_text and "all_findings.extend(check_citation_lines(root))" in dangling_text:
        deviations.append("GOVERNANCE: redesign contract says citation-lines is unwired but run_all wires it")
    return deviations


def find_deviations(root: Path) -> list[str]:
    """Return objective, boundary, ADR, and version deviations without suppressing errors."""
    spec_path = root / "SPEC.md"
    if not spec_path.is_file():
        return ["MISSING: SPEC.md; run simplecode spec init"]
    try:
        content = spec_path.read_text(encoding="utf-8")
    except OSError as exc:
        return [f"COULD NOT RUN: cannot read SPEC.md: {exc}"]
    return (
        objective_deviations(content)
        + boundary_deviations(root, content)
        + adr_deviations(root)
        + version_deviations(root, content)
        + governance_deviations(root, content)
    )


def build_drift_report(root: Path) -> DriftReport:
    """Structured wrapper around `find_deviations` -- see module docstring."""
    return DriftReport.from_deviations(find_deviations(root))


def main() -> int:
    deviations = find_deviations(Path.cwd())
    if not deviations:
        print("[drift] OK: objective, boundaries, and ADRs align")
        return 0
    print(f"[drift] FAIL: {len(deviations)} deviation(s)")
    for deviation in deviations:
        print(f"  - {deviation}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
