# -*- coding: utf-8 -*-
"""simplecode.rules -- Canonical rule registry and metadata for 1,144 Golden Standard rules."""
from .registry import get_rule, load_catalog, rules_by_family

__all__ = ["get_rule", "load_catalog", "rules_by_family"]
