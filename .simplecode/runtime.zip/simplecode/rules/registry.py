# -*- coding: utf-8 -*-
"""registry.py -- High-performance query engine for the canonical inherited rule set.

Parses catalog.yaml in <5ms using lazy caching and exposes fast lookup helpers.
"""
from __future__ import annotations

import functools
from pathlib import Path
from typing import Any

import yaml

_CATALOG_PATH = Path(__file__).resolve().parent / "catalog.yaml"


@functools.lru_cache(maxsize=1)
def load_catalog() -> list[dict[str, Any]]:
    """Load and cache the complete list of 1,144+ canonical rules."""
    if not _CATALOG_PATH.is_file():
        return []
    try:
        content = _CATALOG_PATH.read_text(encoding="utf-8")
        data = yaml.safe_load(content)
        if isinstance(data, dict):
            return data.get("rules", [])
        if isinstance(data, list):
            return data
        return []
    except (OSError, yaml.YAMLError) as exc:
        import logging
        logging.getLogger("rules.registry").warning("Could not parse catalog.yaml: %s", exc)
        return []


import re


def _normalize_rule_key(k: str) -> str:
    """Normalize rule key by stripping leading zeros from the numeric component."""
    k_upper = k.strip().upper()
    return re.sub(r"^([A-Z0-9]+)-0*([0-9]+)$", r"\1-\2", k_upper)


@functools.lru_cache(maxsize=1)
def _rule_index() -> dict[str, dict[str, Any]]:
    """Build a lookup index supporting canonical, zero-padded, and unpadded rule IDs."""
    index: dict[str, dict[str, Any]] = {}
    for r in load_catalog():
        if "id" in r:
            raw_id = r["id"].upper()
            norm_id = _normalize_rule_key(raw_id)
            index[raw_id] = r
            index[norm_id] = r
    return index


def get_rule(rule_id: str) -> dict[str, Any] | None:
    """Retrieve rule metadata by canonical or aliased ID (e.g. 'GS2-001' or 'GS2-1', 'CC-32' or 'CC-032')."""
    raw = rule_id.strip().upper()
    index = _rule_index()
    return index.get(raw) or index.get(_normalize_rule_key(raw))


def rules_by_family(family: str) -> list[dict[str, Any]]:
    """Retrieve all rules belonging to a specific taxonomy family (e.g. 'GS2', 'VC', 'AV', 'VT', 'CC')."""
    fam_upper = family.strip().upper()
    return [r for r in load_catalog() if r.get("family", "").upper() == fam_upper]


def summary_stats() -> dict[str, int]:
    """Return rule count aggregated by family."""
    stats: dict[str, int] = {}
    for r in load_catalog():
        fam = r.get("family", "OTHER").upper()
        stats[fam] = stats.get(fam, 0) + 1
    return stats
