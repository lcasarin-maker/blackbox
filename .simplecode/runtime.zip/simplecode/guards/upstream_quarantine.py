#!/usr/bin/env python3
"""upstream_quarantine.py -- staging area for moved upstreams (ADR-0010).

When `upstream-check --quarantine` sees a MOVED upstream, this module pulls
the full compare (commits + per-file patches) into
``.simplecode/quarantine/<owner>__<name>/`` and writes a ``DIGEST.md``: the
deterministic pre-digestion of the review -- commit list, files touching the
harvested subpath, license-file and breaking/security signals -- followed by
a Harvest-Lens-shaped evaluation skeleton the HUMAN completes (audited by
`simplecode harvest` once filled).

The adoption boundary (ADR-0009 decision 2, unchanged): everything lands
under the gitignored quarantine directory; nothing here ever touches the
manifest, the working tree outside quarantine, or the reviewed ref. Ingesting
into quarantine is not adoption -- it is the raw material for the human
review that IS.
"""
from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.utils.tool_limits import (
    QUARANTINE_COMPARE_MAX_BYTES,
    QUARANTINE_PATCH_MAX_BYTES,
)

QUARANTINE_DIR = Path(".simplecode") / "quarantine"

# Signals worth surfacing before a human reads a single diff line. Substring
# match over commit messages, case-insensitive; deliberately few and loud.
BREAKING_SIGNALS = ("breaking", "security", "cve", "vulnerab", "deprecat", "yank")
# LICENSE-class: the basename is license/licence/copying/notice, optionally
# prefixed `un` (UNLICENSE) and followed by `-X` or `.X` (LICENSE-MIT, COPYING.LESSER,
# LICENSE.txt) -- or any file under a top-level LICENSES/ directory (REUSE layout).
# Full-match on purpose: src/license_check.py is code that mentions a license.
LICENSE_FILE_RE = re.compile(r"(?:un)?(?:licen[cs]e|copying|notice)(?:[-.].*)?", re.IGNORECASE)
LICENSES_DIR = "licenses/"


def _is_license_class(filename: str) -> bool:
    return (filename.lower().startswith(LICENSES_DIR)
            or LICENSE_FILE_RE.fullmatch(Path(filename).name) is not None)


def harvest_paths(entry: dict) -> tuple[str, ...]:
    """The upstream subpath prefixes of a cosecha's `path`: a string or a list.

    A harvest can live in several places of one monorepo (gnumeric's Lotus
    spec sits in plugins/lotus-123, plugins/qpro and samples/), so `path` takes
    either form. Blank prefixes are dropped: "" would match every file and
    turn the filter into "everything touches the harvest".
    """
    raw = entry.get("path")
    items = raw if isinstance(raw, list) else [raw]
    return tuple(p for p in (str(i).strip() for i in items if i) if p)


def quarantine_path(root: Path, repo: str) -> Path:
    return root / QUARANTINE_DIR / repo.replace("/", "__")


def _ensure_self_ignored(root: Path) -> None:
    """Make the quarantine directory ignore itself, whatever the project's root
    .gitignore says: a satellite whose .gitignore lacks `.simplecode/quarantine/`
    (measured 2026-10-06 on a fleet member under the weekly cron) would leave
    third-party patches one `git add` from a commit. Appends a `*` line to a
    pre-existing .gitignore that lacks one; leaves any other line of it alone."""
    ignore = root / QUARANTINE_DIR / ".gitignore"
    current = ignore.read_text(encoding="utf-8") if ignore.is_file() else ""
    if "*" in current.splitlines():
        return
    glue = "" if not current or current.endswith("\n") else "\n"
    atomic_io.write_text_durable(ignore, f"{current}{glue}*\n")


def _fetch_full_compare(run_gh, repo: str, ref: str, observed: str) -> dict | None:
    """The unabridged compare JSON (commits + files + patches), or None."""
    result = run_gh([f"repos/{repo}/compare/{ref}...{observed}"])
    if result is None or result.returncode != 0:
        return None
    if len(result.stdout.encode("utf-8", errors="replace")) > QUARANTINE_COMPARE_MAX_BYTES:
        return {"_oversize": True}
    try:
        payload = json.loads(result.stdout)
    except ValueError:
        return None
    return payload if isinstance(payload, dict) else None


def _commit_lines(payload: dict) -> list[str]:
    lines = []
    for c in payload.get("commits", []):
        sha = str(c.get("sha", ""))[:7]
        message = str(c.get("commit", {}).get("message", "")).splitlines()
        lines.append(f"{sha} {message[0] if message else ''}")
    return lines


def _is_license_change(entry: dict) -> bool:
    """A file named LICENSE-class before OR after the change (a rename away counts)."""
    names = (str(entry.get("filename", "")), str(entry.get("previous_filename") or ""))
    return any(_is_license_class(n) for n in names if n)


def _license_label(entry: dict) -> str:
    name, prev = str(entry.get("filename", "")), str(entry.get("previous_filename") or "")
    return f"{prev} -> {name}" if prev else name


def touches_subpath(filename: str, subpath: str) -> bool:
    """Directory-boundary match: path `src/lib` is `src/lib/a.py`, never `src/library.py`.

    It was a bare `startswith`, so a manifest `path` written without a trailing
    slash also claimed every sibling sharing its spelling (measured 2026-10-06:
    `src/lib` counted `src/library.py` and `src/libfoo/b.py`, and a change only
    in `src/library.py` reported MOVED instead of MOVED_OUTSIDE_HARVEST).
    """
    base = subpath.rstrip("/")
    return filename == base or filename.startswith(base + "/")


def _signals(payload: dict, subpaths: tuple[str, ...]) -> list[str]:
    """Deterministic pre-review signals. Empty list = nothing loud, NOT 'safe'."""
    out = []
    messages = " ".join(_commit_lines(payload)).lower()
    hits = sorted({s for s in BREAKING_SIGNALS if s in messages})
    if hits:
        out.append(f"commit messages carry breaking/security keywords: {', '.join(hits)}")
    files = [str(f.get("filename", "")) for f in payload.get("files", [])]
    licenses = [_license_label(f) for f in payload.get("files", []) if _is_license_change(f)]
    if licenses:
        out.append(f"LICENSE-class file changed ({', '.join(licenses)}) -- re-check "
                   "the licencia recorded in the manifest before any further vendoring")
    if subpaths:
        touching = [f for f in files if any(touches_subpath(f, p) for p in subpaths)]
        out.append(f"{len(touching)} of {len(files)} changed files touch the "
                   f"harvested subpath {', '.join(subpaths)}")
    return out


def _digest(entry: dict, observed: str, payload: dict, truncated: list[str]) -> str:
    repo, ref, subpaths = str(entry["repo"]), str(entry["ref"]), harvest_paths(entry)
    now = datetime.now(UTC).date().isoformat()
    commits = _commit_lines(payload)
    signals = _signals(payload, subpaths)
    if truncated:
        signals.append(f"{len(truncated)} patch(es) truncated by the quarantine byte cap: "
                       f"{', '.join(truncated)} -- read the upstream compare for the full diff")
    files = [str(f.get("filename", "")) for f in payload.get("files", [])]
    return "\n".join([
        f"# Quarantine digest: {repo}",
        "",
        f"- Reviewed ref: `{ref}`",
        f"- Observed head: `{observed}`",
        f"- Fetched: {now}",
        f"- Commits ahead: {len(commits)} · files changed: {len(files)}",
        "",
        "## Automatic signals",
        "",
        *([f"- {s}" for s in signals] or ["- none fired (absence of a signal is not a verdict)"]),
        "",
        "## Commits",
        "",
        *[f"- {line}" for line in commits],
        "",
        "## Changed files",
        "",
        *[f"- {f}" for f in files],
        "",
        "Per-file patches: `compare.json` in this directory.",
        "",
        "## Evaluation (HUMAN -- complete, then audit with `simplecode harvest <this file>`)",
        "",
        "Mechanisms found (>= 3, or state why fewer exist):",
        "",
        "- M1: _(mechanism -- does it attack a known failure of ours? version at our scale?"
        " does it formally name something we did implicitly?)_",
        "- M2: _",
        "- M3: _",
        "",
        "Verdict (MAD/ABD/INF/LIC/DOM/EVI/TOS/COS): _",
        "",
        "Re-evaluation trigger (disparador/caducidad): _",
        "",
        "On harvest: re-implement clean-room, then bump the manifest ref BY HAND.",
        "On decline: record the rationale here, then bump the ref BY HAND anyway --",
        "a decline is also a review, taken against this exact observed head.",
    ]) + "\n"


def quarantine_moved(root: Path, entry: dict, observed: str, run_gh) -> dict:
    """Stage one moved upstream for review. Returns {ok, path|reason}.

    Writes ONLY under the quarantine directory. Oversize or unfetchable
    compares still produce a DIGEST.md that says so -- the review task must
    never point at an empty directory in silence.
    """
    repo, ref = str(entry["repo"]), str(entry["ref"])
    target = quarantine_path(root, repo)
    payload = _fetch_full_compare(run_gh, repo, ref, observed)
    target.mkdir(parents=True, exist_ok=True)
    _ensure_self_ignored(root)
    if payload is None or payload.get("_oversize"):
        reason = ("compare response exceeds the quarantine byte cap"
                  if payload else "compare unavailable (rewritten history or API failure)")
        (target / "compare.json").unlink(missing_ok=True)  # never beside a digest that says it failed
        atomic_io.write_text_durable(target / "DIGEST.md", "\n".join([
            f"# Quarantine digest: {repo}", "",
            f"- Reviewed ref: `{ref}`", f"- Observed head: `{observed}`", "",
            f"COULD_NOT_STAGE: {reason} -- review upstream directly "
            f"(https://github.com/{repo}/compare/{ref[:12]}...{observed[:12]}), "
            "then bump the manifest ref by hand.", "",
        ]))
        return {"ok": False, "reason": reason, "path": str(target)}
    truncated = []
    for f in payload.get("files", []):
        patch = f.get("patch")
        if isinstance(patch, str) and len(patch.encode("utf-8", errors="replace")) > QUARANTINE_PATCH_MAX_BYTES:
            f["patch"] = (patch[:1000] + "\n... [patch truncated by quarantine byte cap; "
                          "see upstream compare for the full diff]")
            truncated.append(str(f.get("filename", "")))
    atomic_io.write_text_durable(target / "compare.json", json.dumps(payload, indent=1))
    atomic_io.write_text_durable(
        target / "DIGEST.md",
        _digest(entry, observed, payload, truncated),
    )
    return {"ok": True, "path": str(target)}
