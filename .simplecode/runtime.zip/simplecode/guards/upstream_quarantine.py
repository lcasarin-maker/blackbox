#!/usr/bin/env python3
"""upstream_quarantine.py -- staging area for moved upstreams (ADR-0010).

When `upstream-check --quarantine` sees a MOVED upstream, this module pulls
the full compare (commits + per-file patches) into
``.simplecode/quarantine/<owner>__<name>/`` and writes a ``DIGEST.md``: the
deterministic pre-digestion of the review -- commit list, files touching the
harvested subpath, license-file and breaking/security signals -- followed by
a Harvest-Lens-shaped evaluation skeleton the HUMAN completes (audited by
`simplecode harvest` once filled).

The adoption boundary (ADR-0009 decision 2, unchanged): everything lands
under the gitignored quarantine directory; nothing here ever touches the
manifest, the working tree outside quarantine, or the reviewed ref. Ingesting
into quarantine is not adoption -- it is the raw material for the human
review that IS.
"""
from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.utils.tool_limits import (
    QUARANTINE_COMPARE_MAX_BYTES,
    QUARANTINE_PATCH_MAX_BYTES,
)

QUARANTINE_DIR = Path(".simplecode") / "quarantine"

# Signals worth surfacing before a human reads a single diff line. Substring
# match over commit messages, case-insensitive; deliberately few and loud.
BREAKING_SIGNALS = ("breaking", "security", "cve", "vulnerab", "deprecat", "yank")
LICENSE_FILE_NAMES = ("license", "licence", "copying", "notice")


def quarantine_path(root: Path, repo: str) -> Path:
    return root / QUARANTINE_DIR / repo.replace("/", "__")


def _fetch_full_compare(run_gh, repo: str, ref: str, observed: str) -> dict | None:
    """The unabridged compare JSON (commits + files + patches), or None."""
    result = run_gh([f"repos/{repo}/compare/{ref}...{observed}"])
    if result is None or result.returncode != 0:
        return None
    if len(result.stdout.encode("utf-8", errors="replace")) > QUARANTINE_COMPARE_MAX_BYTES:
        return {"_oversize": True}
    try:
        payload = json.loads(result.stdout)
    except ValueError:
        return None
    return payload if isinstance(payload, dict) else None


def _commit_lines(payload: dict) -> list[str]:
    lines = []
    for c in payload.get("commits", []):
        sha = str(c.get("sha", ""))[:7]
        message = str(c.get("commit", {}).get("message", "")).splitlines()
        lines.append(f"{sha} {message[0] if message else ''}")
    return lines


def _signals(payload: dict, subpath: str) -> list[str]:
    """Deterministic pre-review signals. Empty list = nothing loud, NOT 'safe'."""
    out = []
    messages = " ".join(_commit_lines(payload)).lower()
    hits = sorted({s for s in BREAKING_SIGNALS if s in messages})
    if hits:
        out.append(f"commit messages carry breaking/security keywords: {', '.join(hits)}")
    files = [str(f.get("filename", "")) for f in payload.get("files", [])]
    licenses = [f for f in files if Path(f).stem.lower() in LICENSE_FILE_NAMES]
    if licenses:
        out.append(f"LICENSE-class file changed ({', '.join(licenses)}) -- re-check "
                   "the licencia recorded in the manifest before any further vendoring")
    if subpath:
        touching = [f for f in files if f.startswith(subpath)]
        out.append(f"{len(touching)} of {len(files)} changed files touch the "
                   f"harvested subpath {subpath}")
    return out


def _digest(entry: dict, observed: str, payload: dict, truncated: list[str]) -> str:
    repo, ref, subpath = str(entry["repo"]), str(entry["ref"]), str(entry.get("path") or "")
    now = datetime.now(UTC).date().isoformat()
    commits = _commit_lines(payload)
    signals = _signals(payload, subpath)
    if truncated:
        signals.append(f"{len(truncated)} patch(es) truncated by the quarantine byte cap: "
                       f"{', '.join(truncated)} -- read the upstream compare for the full diff")
    files = [str(f.get("filename", "")) for f in payload.get("files", [])]
    return "\n".join([
        f"# Quarantine digest: {repo}",
        "",
        f"- Reviewed ref: `{ref}`",
        f"- Observed head: `{observed}`",
        f"- Fetched: {now}",
        f"- Commits ahead: {len(commits)} · files changed: {len(files)}",
        "",
        "## Automatic signals",
        "",
        *([f"- {s}" for s in signals] or ["- none fired (absence of a signal is not a verdict)"]),
        "",
        "## Commits",
        "",
        *[f"- {line}" for line in commits],
        "",
        "## Changed files",
        "",
        *[f"- {f}" for f in files],
        "",
        "Per-file patches: `compare.json` in this directory.",
        "",
        "## Evaluation (HUMAN -- complete, then audit with `simplecode harvest <this file>`)",
        "",
        "Mechanisms found (>= 3, or state why fewer exist):",
        "",
        "- M1: _(mechanism -- does it attack a known failure of ours? version at our scale?"
        " does it formally name something we did implicitly?)_",
        "- M2: _",
        "- M3: _",
        "",
        "Verdict (MAD/ABD/INF/LIC/DOM/EVI/TOS/COS): _",
        "",
        "Re-evaluation trigger (disparador/caducidad): _",
        "",
        "On harvest: re-implement clean-room, then bump the manifest ref BY HAND.",
        "On decline: record the rationale here, then bump the ref BY HAND anyway --",
        "a decline is also a review, taken against this exact observed head.",
    ]) + "\n"


def quarantine_moved(root: Path, entry: dict, observed: str, run_gh) -> dict:
    """Stage one moved upstream for review. Returns {ok, path|reason}.

    Writes ONLY under the quarantine directory. Oversize or unfetchable
    compares still produce a DIGEST.md that says so -- the review task must
    never point at an empty directory in silence.
    """
    repo, ref = str(entry["repo"]), str(entry["ref"])
    target = quarantine_path(root, repo)
    payload = _fetch_full_compare(run_gh, repo, ref, observed)
    target.mkdir(parents=True, exist_ok=True)
    if payload is None or payload.get("_oversize"):
        reason = ("compare response exceeds the quarantine byte cap"
                  if payload else "compare unavailable (rewritten history or API failure)")
        atomic_io.write_text_durable(target / "DIGEST.md", "\n".join([
            f"# Quarantine digest: {repo}", "",
            f"- Reviewed ref: `{ref}`", f"- Observed head: `{observed}`", "",
            f"COULD_NOT_STAGE: {reason} -- review upstream directly "
            f"(https://github.com/{repo}/compare/{ref[:12]}...{observed[:12]}), "
            "then bump the manifest ref by hand.", "",
        ]))
        return {"ok": False, "reason": reason, "path": str(target)}
    truncated = []
    for f in payload.get("files", []):
        patch = f.get("patch")
        if isinstance(patch, str) and len(patch.encode("utf-8", errors="replace")) > QUARANTINE_PATCH_MAX_BYTES:
            f["patch"] = (patch[:1000] + "\n... [patch truncated by quarantine byte cap; "
                          "see upstream compare for the full diff]")
            truncated.append(str(f.get("filename", "")))
    atomic_io.write_text_durable(target / "compare.json", json.dumps(payload, indent=1))
    atomic_io.write_text_durable(
        target / "DIGEST.md",
        _digest(entry, observed, payload, truncated),
    )
    return {"ok": True, "path": str(target)}
