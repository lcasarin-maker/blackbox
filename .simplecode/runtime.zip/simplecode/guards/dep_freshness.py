#!/usr/bin/env python3
"""dep_freshness.py -- Reports on stale dependencies. Never blocks.

Checks `pip list --outdated` against the CURRENT ACTIVE ENVIRONMENT and
compares release age to thresholds. This is maintenance information, not a
correctness signal: `pip list` enumerates every installed package (dev tools
like ruff/pytest alongside production deps, transitive alongside direct)
with no way to separate them, and dependency age alone proves nothing about
whether a dependency is broken. `pip-audit` is the correctness/vulnerability
gate; this module only ever reports.
"""

import json
import os
import subprocess
import sys
from datetime import UTC, datetime
from urllib.error import URLError
from urllib.request import urlopen

from simplecode.utils.tool_limits import HTTP_FETCH_TIMEOUT, NETWORK_TIMEOUT, PYPI_BASE_URL


def get_outdated_packages() -> list[dict] | None:
    """Returns list of outdated packages from pip list --outdated --format=json."""
    try:
        result = subprocess.run(
            ["pip", "list", "--outdated", "--format=json"],
            capture_output=True,
            text=True,
            timeout=NETWORK_TIMEOUT,
            check=False,
        )
        if result.returncode != 0:
            return None
        return json.loads(result.stdout.strip() or "[]")
    except (subprocess.SubprocessError, OSError, FileNotFoundError, json.JSONDecodeError):
        return None


def latest_release_date(package: str) -> datetime | None:
    """Return the published date of the newest PyPI release for ``package``."""
    try:
        with urlopen(f"{PYPI_BASE_URL}/pypi/{package}/json", timeout=HTTP_FETCH_TIMEOUT) as response:  # nosec B310
            payload = json.load(response)
    except (OSError, URLError, ValueError):
        return None

    releases = payload.get("releases", {})
    dates = [
        parse_datetime(file.get("upload_time_iso_8601", ""))
        for files in releases.values()
        for file in files
    ]
    return max((date for date in dates if date is not None), default=None)


def parse_datetime(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, ValueError):
        return None


def classify_outdated(
    outdated: list[dict], now: datetime, warn_days: int, fail_days: int
) -> tuple[list[str], list[str], list[str]]:
    """Group outdated packages by release age and verification availability."""
    warnings, failures, unavailable = [], [], []
    for pkg in outdated:
        latest_date = latest_release_date(pkg["name"])
        if latest_date is None:
            unavailable.append(pkg["name"])
            continue
        days_old = (now - latest_date).days
        detail = f"{pkg['name']} (latest: {pkg['latest_version']}, {days_old} days old)"
        if days_old >= fail_days:
            failures.append(detail)
        elif days_old >= warn_days:
            warnings.append(detail)
    return warnings, failures, unavailable


def _print_report(population: list[str], threshold: int) -> None:
    print(f"[dep-freshness] REPORT: {len(population)} dependencies exceed {threshold} days (not enforced):")
    for item in population:
        print(f"  - {item}")


def main(
    warn_days: int = 30,
    fail_days: int = 90,
) -> int:
    """Report-only: exit 0 in every case except a real instrument failure (2,
    when pip itself could not answer). A dependency's age, however old, is
    reported and never blocks -- see module docstring for why."""
    warn_days = int(os.getenv("DEP_FRESHNESS_WARN_DAYS", str(warn_days)))
    fail_days = int(os.getenv("DEP_FRESHNESS_FAIL_DAYS", str(fail_days)))

    outdated = get_outdated_packages()
    if outdated is None:
        print("[dep-freshness] COULD NOT RUN: pip could not list outdated dependencies")
        return 2
    if not outdated:
        print("[dep-freshness] OK: All dependencies are up to date")
        return 0

    warnings, failures, unavailable = classify_outdated(
        outdated, datetime.now(UTC), warn_days, fail_days
    )

    if failures:
        _print_report(failures, fail_days)
    if warnings:
        _print_report(warnings, warn_days)
    if unavailable:
        print("[dep-freshness] COULD NOT RUN: no PyPI release date for " + ", ".join(unavailable))
        return 2
    if failures or warnings:
        return 0

    print(f"[dep-freshness] OK: {len(outdated)} outdated packages within thresholds")
    return 0


if __name__ == "__main__":
    import os
    warn_days = int(os.getenv("DEP_FRESHNESS_WARN_DAYS", "30"))
    fail_days = int(os.getenv("DEP_FRESHNESS_FAIL_DAYS", "90"))
    sys.exit(main(warn_days=warn_days, fail_days=fail_days))
