#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mcp_security.py - Static security guardrail for Model Context Protocol (MCP) servers and tools.

Consolidated & deduplicated from SkillSpector forensic patterns:
  1. Tool Poisoning & Shadowing: homoglyphs/confusables and duplicate tool registrations.
  2. Invisible / Zero-Width Unicode Injection in tool definitions and parameter descriptions.
  3. Prompt Injection & Jailbreaks embedded in schema descriptions.
  4. Dangerous Execution Payloads in default values or schema metadata.
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any

from simplecode.guards.agent_threats import CONFUSABLES as _CONFUSABLES
from simplecode.guards.agent_threats import INVISIBLE_OR_BIDI_RE

logger = logging.getLogger("mcp_security")


# Suspicious instruction patterns in tool descriptions
_SUSPICIOUS_PROMPT_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?(previous|prior)\s+instructions", re.IGNORECASE),
    re.compile(r"disregard\s+(all\s+)?(previous|prior)\s+instructions", re.IGNORECASE),
    re.compile(r"system\s+prompt\s+override", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+in\s+developer\s+mode", re.IGNORECASE),
    re.compile(r"bypass\s+all\s+(safety|security)\s+filters", re.IGNORECASE),
    re.compile(r"do\s+not\s+inform\s+the\s+user", re.IGNORECASE),
]

_DANGEROUS_PAYLOADS = [
    re.compile(r"\brm\s+-rf\s+[/~]", re.IGNORECASE),
    re.compile(r"\bcurl\b.*\|\s*(ba)?sh", re.IGNORECASE),
    re.compile(r"\bwget\b.*\|\s*(ba)?sh", re.IGNORECASE),
    re.compile(r"\b(mkfs|dd\s+if=.*of=/dev/)", re.IGNORECASE),
]


def normalize_confusables(text: str) -> str:
    """Replace lookalike unicode characters with ascii equivalents."""
    return "".join(_CONFUSABLES.get(c, c) for c in text)


def has_invisible_chars(text: str) -> bool:
    """Return True if text contains zero-width, filler, or bidi-control characters."""
    return INVISIBLE_OR_BIDI_RE.search(text) is not None


def scan_text_threats(text: str) -> list[str]:
    """Scan string for prompt injections, invisible characters, and dangerous commands."""
    findings: list[str] = []
    if has_invisible_chars(text):
        findings.append("invisible_unicode_characters")
    for pat in _SUSPICIOUS_PROMPT_PATTERNS:
        if pat.search(text):
            findings.append(f"prompt_injection_pattern: {pat.pattern}")
    for pat in _DANGEROUS_PAYLOADS:
        if pat.search(text):
            findings.append(f"dangerous_payload: {pat.pattern}")
    return findings


def _scan_param_schemas(schema: dict[str, Any]) -> list[str]:
    findings: list[str] = []
    properties = schema.get("properties", {})
    if isinstance(properties, dict):
        for param_name, param_def in properties.items():
            if isinstance(param_def, dict):
                param_desc = param_def.get("description", "")
                if isinstance(param_desc, str):
                    for threat in scan_text_threats(param_desc):
                        findings.append(f"param '{param_name}': {threat}")
    return findings


def scan_tool_definition(tool: dict[str, Any]) -> list[str]:
    """Audit an individual MCP tool dictionary."""
    findings: list[str] = []
    name = tool.get("name", "")
    if not isinstance(name, str) or not name:
        return ["missing_or_invalid_tool_name"]

    normalized = normalize_confusables(name)
    if normalized != name:
        findings.append(f"homoglyph_confusable_name: {name} (normalizes to {normalized})")

    desc = tool.get("description", "")
    if isinstance(desc, str):
        if len(desc) > 2000:
            findings.append(f"excessive_description_length: {len(desc)} chars")
        for threat in scan_text_threats(desc):
            findings.append(f"tool_description: {threat}")

    schema = tool.get("inputSchema", {})
    if isinstance(schema, dict):
        findings.extend(_scan_param_schemas(schema))

    return findings


def audit_mcp_tools(tools: list[dict[str, Any]]) -> dict[str, list[str]]:
    """Audit a collection of MCP tools, detecting tool poisoning and collisions."""
    results: dict[str, list[str]] = {}
    seen_names: dict[str, str] = {}

    for tool in tools:
        if not isinstance(tool, dict):
            results.setdefault("global", []).append("invalid_tool_entry_not_dict")
            continue

        raw_name = tool.get("name", "<unnamed>")
        findings = scan_tool_definition(tool)

        # Check collision & shadowing
        norm_name = normalize_confusables(str(raw_name))
        if norm_name in seen_names and seen_names[norm_name] != raw_name:
            findings.append(f"tool_shadowing_collision: '{raw_name}' collides with '{seen_names[norm_name]}'")
        else:
            seen_names[norm_name] = str(raw_name)

        if findings:
            results[str(raw_name)] = findings

    return results


def _audit_server_config(servers: dict[str, Any]) -> dict[str, list[str]]:
    findings: list[str] = []
    for srv_name, srv_conf in servers.items():
        if isinstance(srv_conf, dict):
            cmd = srv_conf.get("command", "")
            args = srv_conf.get("args", [])
            combined = f"{cmd} {' '.join(str(a) for a in args)}"
            for threat in scan_text_threats(combined):
                findings.append(f"server '{srv_name}': {threat}")
    return {"mcpServers": findings} if findings else {}


def audit_mcp_config_file(path: Path) -> dict[str, list[str]]:
    """Audit an MCP JSON or configuration file."""
    if not path.is_file():
        return {"file": [f"file_not_found: {path}"]}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeError) as exc:
        return {"file": [f"unparseable_json: {exc}"]}

    if isinstance(data, list):
        return audit_mcp_tools([t for t in data if isinstance(t, dict)])
    if isinstance(data, dict):
        if "tools" in data and isinstance(data["tools"], list):
            return audit_mcp_tools([t for t in data["tools"] if isinstance(t, dict)])
        if "mcpServers" in data and isinstance(data["mcpServers"], dict):
            return _audit_server_config(data["mcpServers"])
        return audit_mcp_tools([data])
    return {}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Scan MCP tools and server configurations for security threats")
    parser.add_argument("paths", nargs="*", type=Path, help="JSON files with MCP tools or configs")
    args = parser.parse_args(argv)

    if not args.paths:
        print("[mcp-security] No paths provided to scan")
        return 0

    has_violations = False
    for path in args.paths:
        report = audit_mcp_config_file(path)
        if report:
            has_violations = True
            print(f"[mcp-security] Violations in {path}:")
            for target, issues in report.items():
                for issue in issues:
                    print(f"  - {target}: {issue}")
        else:
            print(f"[mcp-security] {path}: OK (no threats detected)")

    return 1 if has_violations else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
