# -*- coding: utf-8 -*-
"""angry_path.py -- Enforces Mandate B3: Angry Path Dominance.

Inspects Python and JS/HTML code to ensure errors are never silently swallowed,
masked with dummy fallbacks, or discarded without logging or re-raising.

Project exemption (opt-in, never a default): ``angry_path_exempt_prefixes`` in
``<root>/.simplecode/corpus_exempt.yaml`` lists exact paths or prefixes,
relative to the root, that the scan skips -- for files a project cannot edit
without breaking an integrity seal (audit evidence hashed in a manifest). Each
skipped file is logged and counted in the ``NOT EXAMINED`` line, so a clean
verdict never says more than the files it opened. The hardcoded skips
(``tests/fixtures/``, ``tests/test_``, ``fixtures/``, ``.min.js``, ``/lib/``,
``/vendor/``, ``/node_modules/``) are counted there too, never in the scanned total.
"""
from __future__ import annotations

import argparse
import ast
import logging
import operator
import re
import sys
from collections.abc import Iterator
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.git_utils import git_ls_files
from simplecode.worktree.zero_debt import _load_corpus_exempt_list, unexamined_source

logger = logging.getLogger("angry_path")

_JS_CATCH_EMPTY = re.compile(
    r"catch\s*\([^)]*\)\s*\{\s*(?:pass|continue|return)?\s*\}",
    re.IGNORECASE,
)

# DEBT-GATE-ENGANABLE-ANGRY-PATH (2026-09-27): these are matched EXACTLY
# against the called name, never as a substring. A substring match accepted
# `debug_noop("x")` (an empty function whose name contains "debug") as proof
# the error was logged -- the one-line atajo the 2026-09-26 audit measured.
_LOG_CALL_NAMES = frozenset({
    "debug", "info", "warning", "warn", "error", "exception", "critical", "fatal", "log",
    "print_exc", "print_exception",
})


def _is_blind_handler(handler_type: ast.AST | None) -> bool:
    """Return True if handler catches everything (bare `except:` or `except BaseException/Exception:`)"""
    if handler_type is None:
        return True
    if isinstance(handler_type, ast.Name):
        return handler_type.id in ("BaseException", "Exception")
    if (isinstance(handler_type, ast.Attribute) and isinstance(handler_type.value, ast.Name)
            and handler_type.value.id == "builtins"):
        return handler_type.attr in ("BaseException", "Exception")
    if isinstance(handler_type, ast.Tuple):
        return any(
            _is_blind_handler(elt)
            for elt in handler_type.elts
        )
    return False


def _is_inert_stmt(stmt: ast.stmt, *, local_assign_only: bool) -> bool:
    """A statement with no effect the caller can observe: pass, a bare
    constant (docstring / `...`), `return <constant>`, or an assignment.
    With `local_assign_only`, only assignments to plain names count (inside a
    function body those die at return; `self.x = ...` persists)."""
    if isinstance(stmt, ast.Pass):
        return True
    if isinstance(stmt, ast.Expr):
        return isinstance(stmt.value, ast.Constant)
    if isinstance(stmt, ast.Return):
        return stmt.value is None or isinstance(stmt.value, ast.Constant)
    if isinstance(stmt, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
        if not local_assign_only:
            return True
        targets = stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]
        return all(isinstance(t, ast.Name) for t in targets)
    return False


def _noop_functions(tree: ast.AST) -> frozenset[str]:
    """Names of functions defined in this module whose body does nothing
    observable -- calling one of them from a handler is not logging, whatever
    its name says."""
    return frozenset(
        node.name
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and all(_is_inert_stmt(s, local_assign_only=True) for s in node.body)
    )


def _if_logs_or_raises(
    stmt: ast.If, noop_funcs: frozenset[str], *, raises_count: bool = True,
) -> bool:
    try:
        branch = ast.literal_eval(stmt.test)
    except (ValueError, TypeError):
        branch = None
    if isinstance(branch, bool):
        return _suite_logs_or_raises(stmt.body if branch else stmt.orelse, noop_funcs, raises_count=raises_count)
    return bool(stmt.orelse) and (
        _suite_logs_or_raises(stmt.body, noop_funcs, raises_count=raises_count)
        and _suite_logs_or_raises(stmt.orelse, noop_funcs, raises_count=raises_count)
    )


def _try_logs_or_raises(
    stmt: ast.Try | ast.TryStar, noop_funcs: frozenset[str], *, raises_count: bool = True,
) -> bool:
    if stmt.finalbody:
        if _suite_logs_or_raises(stmt.finalbody, noop_funcs, raises_count=raises_count):
            return True
        if _suite_has_silent_exit(stmt.finalbody):
            return False
    return _suite_logs_or_raises(stmt.body, noop_funcs, raises_count=raises_count) and all(
        _suite_logs_or_raises(handler.body, noop_funcs, raises_count=raises_count)
        for handler in stmt.handlers
    )


def _match_case_is_exhaustive(case: ast.match_case) -> bool:
    return (
        case.guard is None
        and isinstance(case.pattern, ast.MatchAs)
        and case.pattern.pattern is None
    )


def _match_logs_or_raises(
    stmt: ast.Match, noop_funcs: frozenset[str], *, raises_count: bool = True,
) -> bool:
    if not any(_match_case_is_exhaustive(case) for case in stmt.cases):
        return False  # A value may match no case, so no handler action is guaranteed.
    return all(
        _suite_logs_or_raises(case.body, noop_funcs, raises_count=raises_count)
        for case in stmt.cases
    )


def _literal_truth(node: ast.AST) -> bool | None:
    try:
        return bool(ast.literal_eval(node))
    except (TypeError, ValueError):
        return None


def _while_logs_or_raises(
    stmt: ast.While, noop_funcs: frozenset[str], *, raises_count: bool = True,
) -> bool:
    truth = _literal_truth(stmt.test)
    if truth is False:
        return _suite_logs_or_raises(stmt.orelse, noop_funcs, raises_count=raises_count)
    return truth is True and _suite_logs_or_raises(stmt.body, noop_funcs, raises_count=raises_count)


def _is_logging_call(node: ast.AST, noop_funcs: frozenset[str]) -> bool:
    if not isinstance(node, ast.Call):
        return False
    func = node.func
    fname = func.id if isinstance(func, ast.Name) else (
        func.attr if isinstance(func, ast.Attribute) else ""
    )
    return fname.lower() in _LOG_CALL_NAMES and fname not in noop_funcs


def _boolop_logs_or_raises(node: ast.BoolOp, noop_funcs: frozenset[str]) -> bool:
    for value in node.values:
        if _node_logs_or_raises(value, noop_funcs):
            return True
        truth = _literal_truth(value)
        if truth is None or (
            isinstance(node.op, ast.And) and not truth
            or isinstance(node.op, ast.Or) and truth
        ):
            return False
    return False


def _ifexp_logs_or_raises(node: ast.IfExp, noop_funcs: frozenset[str]) -> bool:
    if _node_logs_or_raises(node.test, noop_funcs):
        return True
    truth = _literal_truth(node.test)
    if truth is not None:
        return _node_logs_or_raises(node.body if truth else node.orelse, noop_funcs)
    return (_node_logs_or_raises(node.body, noop_funcs)
            and _node_logs_or_raises(node.orelse, noop_funcs))


def _compare_logs_or_raises(node: ast.Compare, noop_funcs: frozenset[str]) -> bool:
    left = node.left
    if _node_logs_or_raises(left, noop_funcs):
        return True
    comparisons = {
        ast.Eq: operator.eq, ast.NotEq: operator.ne,
        ast.Lt: operator.lt, ast.LtE: operator.le,
        ast.Gt: operator.gt, ast.GtE: operator.ge,
        ast.In: lambda a, b: operator.contains(b, a),
        ast.NotIn: lambda a, b: not operator.contains(b, a),
    }
    for op, right in zip(node.ops, node.comparators):
        # Both operands run before this comparison can short-circuit the chain.
        if _node_logs_or_raises(right, noop_funcs):
            return True
        compare = comparisons.get(type(op))
        # Literal equality is foldable; identity can depend on object reuse.
        if compare is None:
            return False
        try:
            if not compare(ast.literal_eval(left), ast.literal_eval(right)):
                return False
        except (TypeError, ValueError):
            return False
        left = right
    return False


def _node_logs_or_raises(node: ast.AST, noop_funcs: frozenset[str]) -> bool:
    """Find logging guaranteed to execute in an expression or statement node."""
    if isinstance(node, ast.Assert):
        # Python -O removes the entire assertion, including its test and message.
        return False
    if isinstance(node, ast.BoolOp):
        return _boolop_logs_or_raises(node, noop_funcs)
    if isinstance(node, ast.IfExp):
        return _ifexp_logs_or_raises(node, noop_funcs)
    if isinstance(node, ast.Compare):
        return _compare_logs_or_raises(node, noop_funcs)
    if isinstance(node, (ast.Lambda, ast.GeneratorExp, ast.ListComp, ast.SetComp,
                         ast.DictComp, ast.FunctionDef, ast.AsyncFunctionDef,
                         ast.ClassDef)):
        return False
    if _is_logging_call(node, noop_funcs):
        return True
    return any(_node_logs_or_raises(child, noop_funcs) for child in ast.iter_child_nodes(node))


def _node_contains_logging_call(node: ast.AST, noop_funcs: frozenset[str]) -> bool:
    """Find logging offered as evidence for this handler's control flow.

    A nested handler that reports its own failure is legitimate recovery, not
    optional logging offered as a guarantee for the enclosing handler. Keep
    examining handlers whose logging is itself conditional or unreachable.
    """
    if isinstance(node, ast.ExceptHandler) and _suite_logs_or_raises(node.body, noop_funcs):
        return False
    if isinstance(node, (ast.Lambda, ast.GeneratorExp, ast.ListComp, ast.SetComp,
                         ast.DictComp, ast.FunctionDef, ast.AsyncFunctionDef,
                         ast.ClassDef)):
        return False
    if _is_logging_call(node, noop_funcs):
        return True
    return any(_node_contains_logging_call(child, noop_funcs) for child in ast.iter_child_nodes(node))


def _statement_logs_or_raises(
    stmt: ast.stmt, noop_funcs: frozenset[str], *, raises_count: bool = True,
) -> bool:
    if isinstance(stmt, ast.Raise):
        return raises_count
    if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef,
                         ast.For, ast.AsyncFor)):
        # Loop bodies may execute zero times, so their logging cannot prove
        # that the handler reports the exception.
        return False
    if isinstance(stmt, ast.While):
        return _while_logs_or_raises(stmt, noop_funcs, raises_count=raises_count)
    if isinstance(stmt, ast.If):
        return _if_logs_or_raises(stmt, noop_funcs, raises_count=raises_count)
    if isinstance(stmt, (ast.Try, ast.TryStar)):
        return _try_logs_or_raises(stmt, noop_funcs, raises_count=raises_count)
    if isinstance(stmt, ast.Match):
        return _match_logs_or_raises(stmt, noop_funcs, raises_count=raises_count)
    if isinstance(stmt, (ast.With, ast.AsyncWith)):
        # A context manager may suppress an exception raised by its body.
        return _suite_logs_or_raises(stmt.body, noop_funcs, raises_count=False)
    return _node_logs_or_raises(stmt, noop_funcs)


def _suite_logs_or_raises(
    nodes: list[ast.stmt], noop_funcs: frozenset[str], *, raises_count: bool = True,
) -> bool:
    """Require a log or raise before every reachable handler exit."""
    for stmt in nodes:
        if _statement_logs_or_raises(stmt, noop_funcs, raises_count=raises_count):
            return True
        if not raises_count and _contains_raise([stmt]):
            return False  # A context manager may swallow this exception before a later log.
        if _statement_has_silent_exit(stmt, noop_funcs):
            return False
    return False


def _suite_has_silent_exit(
    nodes: list[ast.stmt], noop_funcs: frozenset[str] = frozenset(),
) -> bool:
    for stmt in nodes:
        if _statement_logs_or_raises(stmt, noop_funcs):
            return False
        if _statement_has_silent_exit(stmt, noop_funcs):
            return True
    return False


def _match_has_silent_exit(stmt: ast.Match, noop_funcs: frozenset[str]) -> bool:
    return any(_suite_has_silent_exit(case.body, noop_funcs) for case in stmt.cases)


def _iter_without_nested_scopes(nodes: list[ast.stmt]) -> Iterator[ast.AST]:
    stack: list[ast.AST] = list(nodes)
    while stack:
        node = stack.pop()
        yield node
        if isinstance(node, (ast.Lambda, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        stack.extend(ast.iter_child_nodes(node))


def _contains_raise(nodes: list[ast.stmt]) -> bool:
    return any(isinstance(node, ast.Raise) for node in _iter_without_nested_scopes(nodes))


def _if_has_silent_exit(stmt: ast.If, noop_funcs: frozenset[str]) -> bool:
    try:
        branch = ast.literal_eval(stmt.test)
    except (ValueError, TypeError):
        branch = None
    if isinstance(branch, bool):
        return _suite_has_silent_exit(stmt.body if branch else stmt.orelse, noop_funcs)
    return any(_suite_has_silent_exit(suite, noop_funcs) for suite in (stmt.body, stmt.orelse))


def _statement_has_silent_exit(stmt: ast.stmt, noop_funcs: frozenset[str]) -> bool:
    if isinstance(stmt, (ast.Continue, ast.Break, ast.Return)):
        return True
    if isinstance(stmt, ast.Assert):
        return True
    if isinstance(stmt, (ast.Raise, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return False
    if isinstance(stmt, (ast.For, ast.AsyncFor, ast.While)):
        return _suite_has_silent_exit(stmt.body, noop_funcs)
    if isinstance(stmt, (ast.With, ast.AsyncWith)):
        # Context exits cannot resume a continue/break/return inside the body.
        # Keep raises separate: __exit__/__aexit__ may suppress those instead.
        return _contains_raise(stmt.body) or _suite_has_silent_exit(stmt.body, noop_funcs)
    if isinstance(stmt, ast.If):
        return _if_has_silent_exit(stmt, noop_funcs)
    if isinstance(stmt, ast.Match):
        return _match_has_silent_exit(stmt, noop_funcs)
    return any(_suite_has_silent_exit(suite, noop_funcs) for suite in _child_suites(stmt))


def _child_suites(stmt: ast.stmt) -> Iterator[list[ast.stmt]]:
    """Include exception routes: Try.handlers are not in body/orelse/finalbody."""
    for field in ("body", "orelse", "finalbody"):
        suite = getattr(stmt, field, None)
        if isinstance(suite, list) and suite:
            yield suite
    if isinstance(stmt, (ast.Try, ast.TryStar)):
        yield from (handler.body for handler in stmt.handlers)
    if isinstance(stmt, ast.Match):
        yield from (case.body for case in stmt.cases)


def _has_logging_or_raise(nodes: list[ast.stmt], noop_funcs: frozenset[str] = frozenset()) -> bool:
    """Compatibility wrapper for the full-suite guarantee used by handlers."""
    return _suite_logs_or_raises(nodes, noop_funcs)


def _references_exception(node: ast.ExceptHandler) -> bool:
    """Whether the handler body reads the bound exception (`except E as exc`)."""
    if node.name is None:
        return False
    return any(
        isinstance(sub, ast.Name) and sub.id == node.name
        for stmt in node.body
        for sub in ast.walk(stmt)
    )


def _has_nested_silent_suite(nodes: list[ast.stmt]) -> bool:
    """Find an inert nested branch in a handler without entering new scopes."""
    for stmt in nodes:
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        suites: list[list[ast.stmt]] = []
        for field in ("body", "orelse", "finalbody"):
            value = getattr(stmt, field, None)
            if isinstance(value, list) and value:
                suites.append(value)
        if isinstance(stmt, ast.Match):
            suites.extend(case.body for case in stmt.cases if case.body)
        for suite in suites:
            if all(
                _is_inert_stmt(child, local_assign_only=False)
                or isinstance(child, (ast.Continue, ast.Break))
                for child in suite
            ):
                return True
            if _has_nested_silent_suite(suite):
                return True
    return False


def _inspect_js_catch(path: Path, code: str) -> list[str]:
    findings = []
    for line_no, line in enumerate(code.splitlines(), start=1):
        if _JS_CATCH_EMPTY.search(line):
            findings.append(f"{path}:{line_no}: empty JS catch block (silent error swallowing)")
    return findings


def _inspect_single_stmt_handler(
    path: Path, node: ast.ExceptHandler, is_blind: bool, noop_funcs: frozenset[str] = frozenset()
) -> str | None:
    first = node.body[0]
    if isinstance(first, ast.Pass) and is_blind:
        return f"{path}:{node.lineno}: blind except handler with pass (silent swallow)"
    if isinstance(first, (ast.Continue, ast.Break)) and is_blind:
        return f"{path}:{node.lineno}: blind except handler with {type(first).__name__.lower()} (silent loop swallow)"
    if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and first.value.value is Ellipsis:
        return f"{path}:{node.lineno}: except handler with ellipsis (stub swallow)"
    if isinstance(first, ast.Return) and is_blind and not _has_logging_or_raise(node.body, noop_funcs):
        val = first.value
        if val is None or (isinstance(val, ast.Constant) and val.value in (None, False, "", 0, {})):
            return f"{path}:{node.lineno}: blind except returns dummy fallback without logging/re-raise"
    return None


def _inspect_single_handler(
    path: Path, node: ast.ExceptHandler, noop_funcs: frozenset[str] = frozenset()
) -> str | None:
    is_blind = _is_blind_handler(node.type)
    body = node.body
    if not body:
        return f"{path}:{node.lineno}: empty except handler"

    if len(body) == 1:
        single_issue = _inspect_single_stmt_handler(path, node, is_blind, noop_funcs)
        if single_issue:
            return single_issue

    if is_blind and not _has_logging_or_raise(body, noop_funcs):
        if any(isinstance(s, (ast.Continue, ast.Break)) for s in body):
            return f"{path}:{node.lineno}: blind except handler swallows loop iteration with no logging or raise"
        if any(isinstance(s, ast.Return) for s in body):
            return f"{path}:{node.lineno}: broad except handler degrades silently with no logging or raise"
        # DEBT-GATE-ENGANABLE-ANGRY-PATH: `except Exception: data = None`
        # masks the error with a dummy value and never looks at it.
        if not _references_exception(node) and all(
            _is_inert_stmt(s, local_assign_only=False) for s in body
        ):
            return f"{path}:{node.lineno}: blind except masks the error with a dummy assignment, no logging or raise"
        reason = _nested_silent_handler_reason(node, body, noop_funcs)
        if reason:
            return f"{path}:{node.lineno}: {reason}"
    return None


def _nested_silent_handler_reason(
    node: ast.ExceptHandler, body: list[ast.stmt], noop_funcs: frozenset[str],
) -> str | None:
    if any(isinstance(subnode, ast.Assert) for stmt in body for subnode in ast.walk(stmt)):
        return "blind except relies on an assertion instead of logging or raising"
    if any(_node_contains_logging_call(stmt, noop_funcs) for stmt in body):
        return "blind except contains logging that is not guaranteed to execute"
    if _suite_has_silent_exit(body, noop_funcs) or _has_nested_silent_suite(body):
        return "blind except contains a nested silent branch without logging or raise"
    if any(isinstance(stmt, (ast.For, ast.AsyncFor, ast.While)) for stmt in body):
        return "blind except relies on logging inside a loop that may not run"
    if not _references_exception(node) and any(
        _is_inert_stmt(stmt, local_assign_only=False) for stmt in body
    ):
        return "blind except contains a silent path without logging or raise"
    return None


def inspect_angry_path(path: Path, code: str) -> list[str]:
    """Scan a Python or JS/HTML file for silent exception swallowing or dummy fallback degradation."""
    suffix = path.suffix.lower()
    if suffix in (".js", ".html", ".ts", ".jsx", ".tsx"):
        return _inspect_js_catch(path, code)
    if suffix != ".py":
        return []

    try:
        tree = ast.parse(code, filename=str(path))
    except SyntaxError as exc:
        return [f"{path}:1: SyntaxError: cannot parse Python code ({exc})"]

    noop_funcs = _noop_functions(tree)
    findings = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            issue = _inspect_single_handler(path, node, noop_funcs)
            if issue:
                findings.append(issue)
    return findings


_BUILTIN_SKIP_MARKERS = (
    "tests/fixtures/", "tests/test_", "fixtures/", ".min.js", "/lib/", "/vendor/", "/node_modules/",
)


def _is_builtin_skipped(path: Path) -> bool:
    """Whether `scan_angry_path` opens nothing for `path` (a hardcoded rule, not a project opt-in)."""
    posix = path.as_posix()
    return any(marker in posix for marker in _BUILTIN_SKIP_MARKERS)


def scan_angry_path(paths: list[Path]) -> list[str]:
    """Scan all provided paths for angry path compliance."""
    findings = []
    for p in paths:
        if not p.is_file():
            continue
        if _is_builtin_skipped(p):
            continue
        try:
            code = p.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            findings.append(f"{p}:1: unreadable file ({exc})")
            continue
        findings.extend(inspect_angry_path(p, code))
    return findings


def _split_project_exempt(root: Path, targets: list[Path]) -> tuple[list[Path], list[Path]]:
    """(scanned, exempted): `targets` split by `angry_path_exempt_prefixes`.

    A prefix matches the root-relative posix path of a target (an exact path is
    a prefix of itself); a target outside `root` can never match.
    """
    prefixes = tuple(p.removeprefix("./") for p in _load_corpus_exempt_list(root, "angry_path_exempt_prefixes"))
    if not prefixes:
        return targets, []
    scanned: list[Path] = []
    exempted: list[Path] = []
    for target in targets:
        try:
            rel = target.relative_to(root).as_posix()
        except ValueError:
            scanned.append(target)
            continue
        matched = next((p for p in prefixes if rel.startswith(p)), None)
        if matched is None:
            scanned.append(target)
            continue
        logger.info(
            "Exempt by angry_path_exempt_prefixes %r in .simplecode/corpus_exempt.yaml: %s",
            matched, rel,
        )
        exempted.append(target)
    return scanned, exempted


def _not_examined_by_this_run(root: Path, targets: list[Path]) -> dict[str, int]:
    """Tracked foreign-source files this run's `targets` did not cover.

    DEBT-SURVEY-GATES-MEASURE-THE-SCAFFOLD: the wired pre-push hook runs
    with `types: [python]`, so pre-commit hands this gate ONLY staged `.py`
    filenames -- a Rust or C# satellite's product never reaches
    `scan_angry_path` at all, yet a clean run printed the exact same "OK"
    line a Python-only repo would, with nothing distinguishing "scanned and
    clean" from "never a subject here". An UNSCOPED sweep (`args.paths`
    empty, so `targets` is every tracked file `git_ls_files` returns) DOES
    reach `.js`/`.ts`/`.tsx`/`.jsx` for the empty-catch regex (see
    `inspect_angry_path`), so those extensions are excluded from the
    confession here when this run actually read them -- the point is to
    name what was NOT looked at, not to claim blindness to a file this run
    just opened.
    """
    examined_exts = {p.suffix.lower() for p in targets}
    return {ext: n for ext, n in unexamined_source(root).items() if ext not in examined_exts}


def _display(path: Path, root: Path) -> str:
    """`path` relative to `root` when it lives under it, else as given."""
    return path.relative_to(root).as_posix() if path.is_relative_to(root) else path.as_posix()


def _is_could_not_run_finding(finding: str) -> bool:
    """Whether a `scan_angry_path` finding means the file couldn't be looked at,
    rather than a real silent-swallow violation being convicted."""
    return ": unreadable file (" in finding or ": SyntaxError: cannot parse Python code (" in finding


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Audit codebase for silent error swallowing (Angry Path Rule B3)")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--gate", action="store_true", help="Exit 1 if findings exist")
    ap.add_argument("paths", nargs="*", type=Path)
    args = ap.parse_args(argv)

    root = args.root.resolve()
    requested = [p.resolve() for p in args.paths] if args.paths else git_ls_files(root)
    project_scanned, exempted = _split_project_exempt(root, requested)
    builtin_skipped = [t for t in project_scanned if _is_builtin_skipped(t)]
    targets = [t for t in project_scanned if not _is_builtin_skipped(t)]
    all_findings = scan_angry_path(targets)
    could_not_run = [f for f in all_findings if _is_could_not_run_finding(f)]
    findings = [f for f in all_findings if f not in could_not_run]

    if exempted:
        print(
            f"[angry-path] NOT EXAMINED -- {len(exempted)} file(s) exempt by "
            f"angry_path_exempt_prefixes in .simplecode/corpus_exempt.yaml (first: "
            f"{exempted[0].relative_to(root).as_posix()}) received no angry-path check. "
            f"A clean verdict above says NOTHING about them."
        )

    if builtin_skipped:
        print(
            f"[angry-path] NOT EXAMINED -- {len(builtin_skipped)} file(s) skipped by the built-in "
            f"angry_path rules (first: {_display(builtin_skipped[0], root)}) received no angry-path "
            f"check. A clean verdict above says NOTHING about them."
        )

    not_examined = _not_examined_by_this_run(root, targets)
    if not_examined:
        total = sum(not_examined.values())
        breakdown = ", ".join(f"{n} {ext}" for ext, n in sorted(not_examined.items()))
        print(
            f"[angry-path] NOT EXAMINED -- this run covered {len(targets)} file(s); "
            f"{total} other tracked source file(s) ({breakdown}) received no angry-path "
            f"check. A clean verdict above says NOTHING about them."
        )

    if could_not_run:
        print(
            f"[angry-path] COULD_NOT_RUN: {len(could_not_run)} file(s) unreadable or "
            f"unparseable; first {could_not_run[0]}",
            file=sys.stderr,
        )

    if findings:
        # DEBT-SURVEY-VERDICT-AND-RC-DIVERGE (2026-09-05): the bare form is
        # consultative by the kit's own convention (orphan_hunter.py's module
        # docstring names this exact organ as the still-open residual case) --
        # every real wiring of this organ passes --gate, so the exit code was
        # already correct; only the WORD lied, printing FAIL (a word that
        # promises to block) while returning 0. Same fix orphan_hunter already
        # applied to itself: the bare form says ADVISORY, never FAIL/BLOCKED.
        verdict = "FAIL" if args.gate else "ADVISORY (would block under --gate)"
        print(f"[angry-path] {verdict}: {len(findings)} silent error handling finding(s):")
        for f in findings:
            print(f"  - {f}")
        emit_hallazgos("[angry-path]", len(findings))
        if args.gate:
            return 1
        return 0

    if could_not_run:
        return 1 if args.gate else 0

    print(f"[angry-path] OK: all {len(targets)} scanned files adhere to Angry Path Dominance (Rule B3).")
    emit_hallazgos("[angry-path]", len(findings))
    return 0


if __name__ == "__main__":
    sys.exit(main())
