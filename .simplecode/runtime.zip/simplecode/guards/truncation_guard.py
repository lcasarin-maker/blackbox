#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""truncation_guard.py - Output-integrity guard for edited files.

Blocks the two mutilations no other gate in the commit catches:
  1. An edited file left empty (0 bytes); ``.gitkeep`` is exempt by
     convention, and a project may exempt an exact path or prefix with
     ``truncation_guard_prefixes`` in ``.simplecode/corpus_exempt.yaml``
     (logged, never silent; suffix exemptions do NOT apply to empty files).
  2. A ``.json`` or ``.toml`` file left with broken syntax.

Trimmed 2026-09-27 per docs/gate_audit_2026-09-26/veredicto_producto/
truncation-guard.md (Luis's vote): the 50%-of-HEAD line ratio went because
pytest with coverage-floor convicts the same cut (measured), ``.py`` syntax
went because ruff E9 owns it, and the repetition-loop detector went because
no real fleet case was found while its false positives were documented.
"""

from __future__ import annotations

import argparse
import functools
import json
import logging
import sys
import tomllib
from pathlib import Path

import yaml

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.git_utils import git_diff_name_only, run_git

logger = logging.getLogger("truncation_guard")

# Bytes sniffed for the binary check below -- enough to catch a NUL in any
# realistic header/section-table region without reading a multi-MB binary
# whole just to reject it.
_BINARY_SNIFF_BYTES = 8192


def _looks_binary(path: Path) -> bool:
    """A NUL byte in the first few KB is git's own binary heuristic (see
    `core.autocrlf`/`.gitattributes`) -- reused here for the same reason:
    the syntax checks assume TEXT. Generalizes the one path-hardcoded
    exemption (`.simplecode/runtime.zip`) by CONTENT, after Twiner
    (2026-09-08) had its vendored `.simplecode/bin/prek` binary judged as
    text, so the next vendored binary doesn't need its own hardcoded line.
    """
    try:
        with path.open("rb") as fh:
            chunk = fh.read(_BINARY_SNIFF_BYTES)
    except OSError:
        return False
    return b"\x00" in chunk


@functools.lru_cache(maxsize=8)
def _load_truncation_exempt(root: Path) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Project-local, opt-in truncation-guard exemptions.

    Read from ``<root>/.simplecode/corpus_exempt.yaml`` (shared with
    corruption_guard's own opt-in mechanism), keys
    ``truncation_guard_prefixes`` and ``truncation_guard_suffixes``. Absent
    file -> no exemptions, so every project keeps sc's shared default
    untouched. A project generating high-volume telemetry (a live queue log
    that legitimately repeats short blocks) opts in explicitly in its own
    tracked config instead of the shared guard being edited to stop checking
    logs/telemetry for the whole fleet.

    Scope of each key: ``truncation_guard_prefixes`` (an exact path or a
    prefix, matched against the root-relative posix path) exempts a file from
    EVERY check here, including the empty-file check -- sealed audit evidence
    captured from a command that wrote nothing is 0 bytes by content, and
    editing it to pass would break its integrity hash.
    ``truncation_guard_suffixes`` exempts only the syntax check: an empty file
    is never exempted by extension, because that would turn one project's
    config line into a blanket pass for every truncated file of that type.
    """
    config = root / ".simplecode" / "corpus_exempt.yaml"
    if not config.is_file():
        return (), ()
    try:
        data = yaml.safe_load(config.read_text(encoding="utf-8")) or {}
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return (), ()
    if not isinstance(data, dict):
        return (), ()
    prefixes = data.get("truncation_guard_prefixes", [])
    suffixes = data.get("truncation_guard_suffixes", [])
    prefixes = tuple(str(p) for p in prefixes) if isinstance(prefixes, list) else ()
    suffixes = tuple(str(s) for s in suffixes) if isinstance(suffixes, list) else ()
    return prefixes, suffixes


def _syntax_check(filepath: Path) -> bool:
    suffix = filepath.suffix.lower()
    if suffix == ".json":
        try:
            json.loads(filepath.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError, UnicodeError) as exc:
            logger.error("JSON syntax check failed for %s: %s", filepath, exc)
            return False
    elif suffix == ".toml":
        try:
            tomllib.loads(filepath.read_text(encoding="utf-8"))
        except (tomllib.TOMLDecodeError, OSError, UnicodeError) as exc:
            logger.error("TOML syntax check failed for %s: %s", filepath, exc)
            return False
    return True


def _truncation_precheck(target_path: Path, rel_path: Path, project_root: Path) -> bool | None:
    """Cheap gates before any diff work: None means "keep going", a bool is the verdict."""
    if not target_path.exists():
        logger.error("Changed file is missing: %s", rel_path)
        print(
            f"[truncation-guard] COULD_NOT_RUN: fichero cambiado no existe en disco: {rel_path}",
            file=sys.stderr,
        )
        return False
    if target_path.stat().st_size == 0:
        # DEBT-SURVEY-LIMITS-DISCOVERED-BY-COLLISION (Twiner): `.gitkeep` is a
        # universal git convention for tracking an otherwise-empty directory --
        # it is 0 bytes BY DESIGN, everywhere, not a per-repo exception someone
        # has to declare. Every other empty file is still a real truncation.
        if rel_path.name == ".gitkeep":
            logger.info(".gitkeep is empty by convention, not truncated: %s", rel_path)
            return True
        exempt_prefixes, _ = _load_truncation_exempt(project_root)
        matched = next((p for p in exempt_prefixes if rel_path.as_posix().startswith(p)), None)
        if matched is not None:
            logger.info(
                "Empty file exempt by truncation_guard_prefixes %r in "
                ".simplecode/corpus_exempt.yaml: %s", matched, rel_path,
            )
            return True
        logger.error("Changed file is empty: %s", rel_path)
        print(f"[truncation-guard] FAIL: fichero vacio (0 bytes) tras la edicion: {rel_path}")
        return False
    if rel_path.as_posix() == ".simplecode/runtime.zip":
        logger.info("Binary runtime integrity is owned by corruption-guard: %s", rel_path)
        return True
    if _looks_binary(target_path):
        logger.info("Binary file, exempt from text checks: %s", rel_path)
        return True
    exempt_prefixes, exempt_suffixes = _load_truncation_exempt(project_root)
    rel_posix = rel_path.as_posix()
    if any(rel_posix.startswith(p) for p in exempt_prefixes) or rel_path.suffix in exempt_suffixes:
        logger.info("Project-exempt path, skipped by truncation guard: %s", rel_path)
        return True
    return None


def validate_chunks(filepath: Path, root: Path | None = None) -> bool:
    """Validate that a changed file was not left empty or with broken JSON/TOML syntax."""
    project_root = (root or Path.cwd()).resolve()
    target_path = filepath if filepath.is_absolute() else (project_root / filepath)
    target_path = target_path.resolve()

    try:
        rel_path = target_path.relative_to(project_root)
    except ValueError as exc:
        logger.error("File is outside repository root: %s (%r)", target_path, exc)
        print(
            f"[truncation-guard] COULD_NOT_RUN: {target_path} esta fuera de la raiz "
            f"{project_root}: {exc}",
            file=sys.stderr,
        )
        return False

    verdict = _truncation_precheck(target_path, rel_path, project_root)
    if verdict is not None:
        return verdict

    if not _syntax_check(target_path):
        print(f"[truncation-guard] FAIL: {rel_path} quedo con sintaxis rota tras la edicion")
        return False

    logger.info("Chunk/state validation passed for %s", rel_path)
    return True


def changed_files(root: Path | None = None) -> list[Path]:
    """Return changed TRACKED files that still exist; explicit deletions are
    not mutilations.

    Deliberately does NOT include untracked (`git status` `??`) files. This
    gate runs at `pre-commit` with `pass_filenames: false`, so its only job
    is validating what is about to enter the commit -- an untracked scratch
    file was never staged, so blocking a commit over unrelated content the
    commit doesn't even touch is the wrong scope (reported live 2026-08-26
    by a peer session vendoring this guard).
    """
    base_root = (root or Path.cwd()).resolve()
    files: set[str] = set()
    files.update(git_diff_name_only(base_root, cached=False))
    files.update(git_diff_name_only(base_root, cached=True))
    rc, stdout, _ = run_git(
        ["diff", "--no-relative", "HEAD", "--name-only", "--diff-filter=D", "-z"],
        base_root,
    )
    if rc == 0:
        files.difference_update(
            b.decode("utf-8", "surrogateescape")
            for b in stdout.split(b"\0")
            if b.strip()
        )
    return [Path(f) for f in sorted(files)]


def _red_team_corpus_removals(root: Path) -> tuple[list[str], str | None]:
    """Protect the kit's append-only adversarial case registry at the index."""
    rel = "tasks/red_team_corpus.json"
    if not (root / ".git").exists():
        return [], None
    rc, changed, err = run_git(["diff", "--cached", "--name-only", "--", rel], root)
    if rc:
        return [], f"could not inspect staged {rel}: {err.decode('utf-8', 'replace')}"
    if rel.encode() not in changed.splitlines():
        return [], None
    rc, tracked, err = run_git(["ls-tree", "-r", "--name-only", "HEAD", "--", rel], root)
    if rc:
        return [], f"could not inspect HEAD for {rel}: {err.decode('utf-8', 'replace')}"
    if not tracked.strip():
        return [], None
    rc, previous, err = run_git(["show", f"HEAD:{rel}"], root)
    if rc:
        return [], f"could not read prior {rel}: {err.decode('utf-8', 'replace')}"
    rc, staged, err = run_git(["show", f":{rel}"], root)
    if rc:
        return ["the staged corpus file was deleted"], None
    try:
        before = json.loads(previous.decode("utf-8"))["casos"]
        after = json.loads(staged.decode("utf-8"))["casos"]
    except (KeyError, TypeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return [], f"could not compare {rel} history: {type(exc).__name__}: {exc}"
    if not isinstance(before, dict) or not isinstance(after, dict):
        return [], f"could not compare {rel} history: `casos` must be an object"
    return sorted(set(before) - set(after)), None


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate edited files are not empty and JSON/TOML still parses")
    parser.add_argument("filepaths", nargs="*", type=Path, help="Files to validate; validates all changed files if omitted")
    parser.add_argument("--root", type=Path, default=None, help="Project root directory")
    parser.add_argument("--gate", action="store_true", help="Exit 1 if any truncation or integrity violations found")
    args = parser.parse_args(argv)

    root = args.root.resolve() if args.root else Path.cwd().resolve()
    files = args.filepaths if args.filepaths else changed_files(root)
    ok = True
    violations = 0
    for path in files:
        full_path = path if path.is_absolute() else (root / path)
        if full_path.is_dir():
            continue
        result = validate_chunks(path, root=root)
        ok = result and ok
        violations += int(not result)
    removed_cases, history_error = _red_team_corpus_removals(root)
    if history_error:
        print(f"[truncation-guard] COULD_NOT_RUN: {history_error}", file=sys.stderr)
        ok = False
        violations += 1
    elif removed_cases:
        print(
            f"[truncation-guard] FAIL: append-only red-team corpus lost "
            f"{len(removed_cases)} record(s); first {removed_cases[0]}",
            file=sys.stderr,
        )
        ok = False
        violations += 1
    # DEBT-GATE-RUNNER-NEVER-WRITES-HALLAZGOS: `violations` also counts a rare
    # COULD_NOT_RUN-per-file case (missing file, path outside root) alongside
    # real empty-file/syntax findings -- `validate_chunks` returns
    # a bare bool for both. Harmless in practice: `gate_runner` already
    # discards this whole run's `hallazgos` whenever ANY line matches its own
    # COULD_NOT_RUN marker, so a mixed run never reaches `gate_effectiveness`
    # with this number; only a run where every file was actually checked does.
    emit_hallazgos("[truncation-guard]", violations)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
