#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""unselected_rules -- detector for omitted mandatory quality rules (GS2-192).

A check available in the installed analyzer but not selected in the configuration
leaves its property unverified, and no output exhibits the gap.

Mandatory Quality Rules for all repositories in the fleet:
  - Syntax/Undef: E9, F821, F632, F811
  - Complexity:   C901 (cyclomatic > 10)
  - Branches:     PLR0912 (branches > 12)
  - Arguments:    PLR0913 (args > 5)
  - Statements:   PLR0915 (statements > 50)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

MANDATORY_RULES: frozenset[str] = frozenset({
    "E9",
    "F821",
    "F632",
    "F811",
    "C901",
    "PLR0912",
    "PLR0913",
    "PLR0915",
})


# ruff's own default rule set, active whenever a config uses `extend-select`
# (or nothing) rather than `select` -- `select` REPLACES the default set,
# `extend-select` adds to it. Documented, stable ruff behavior; verified live
# (F821 fires against a bare undefined-name file under a ruff.toml that
# declares only `extend-select`, no `select`).
_RUFF_DEFAULT_SELECT: frozenset[str] = frozenset({"E4", "E7", "E9", "F"})


def _parse_toml_select(path: Path) -> set[str]:
    """Extract effectively-active rule codes from a pyproject.toml or ruff.toml.

    Reads both `select` (replaces ruff's defaults) and `extend-select` (adds
    to them) -- a config using only `extend-select` was previously read as
    selecting nothing, so every mandatory rule not itself in extend-select
    (E9, F821, F632, F811 -- all covered by ruff's own defaults) was
    misreported as missing. Measured against Atlas's ruff.toml, which uses
    `extend-select` on purpose (its own comment: `select` would silently
    disable the default E/F rules it relies on today).
    """
    import tomllib

    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return set()

    # Case 1: pyproject.toml -> [tool.ruff.lint] select / extend-select
    tool = data.get("tool", {})
    ruff = tool.get("ruff", {})
    lint = ruff.get("lint", {})
    select = set(lint.get("select", []))
    extend = set(lint.get("extend-select", []))

    # Case 2: ruff.toml -> [lint] select / extend-select, or top-level
    if not select and not extend:
        top_lint = data.get("lint", {})
        select = set(top_lint.get("select", []))
        extend = set(top_lint.get("extend-select", []))
    if not select and not extend:
        select = set(data.get("select", []))
        extend = set(data.get("extend-select", []))

    if not select and not extend:
        return set()
    return (select or set(_RUFF_DEFAULT_SELECT)) | extend


def audit_linter_rules(root: Path) -> list[str]:
    """Return a list of missing mandatory rules in repository root."""
    pyproject = root / "pyproject.toml"
    ruff_toml = root / "ruff.toml"

    selected: set[str] = set()
    found_config = False

    if pyproject.is_file():
        sel = _parse_toml_select(pyproject)
        if sel:
            selected.update(sel)
            found_config = True

    if ruff_toml.is_file():
        sel = _parse_toml_select(ruff_toml)
        if sel:
            selected.update(sel)
            found_config = True

    if not found_config:
        # No ruff configuration found
        return sorted(MANDATORY_RULES)

    missing = []
    for rule in sorted(MANDATORY_RULES):
        # A rule is covered if it is explicitly listed OR if its prefix is
        # selected (e.g. 'PLR' or 'PL' -- or a single-letter ruff category
        # like 'F' or 'E', which _RUFF_DEFAULT_SELECT relies on: >= 1, not
        # >= 2, or F821/F632/F811 read as missing under ruff's own bare 'F'
        # default). The empty string is excluded so a malformed/blank TOML
        # list entry can never match-everything.
        covered = (
            rule in selected
            or any(rule.startswith(prefix) for prefix in selected if len(prefix) >= 1)
        )
        if not covered:
            missing.append(rule)

    return missing


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Audit linter config for mandatory rules.")
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--gate", action="store_true", help="Exit 1 if any mandatory rule is missing.")
    args = ap.parse_args(argv)
    root = args.root.resolve()

    missing = audit_linter_rules(root)
    if not missing:
        print("[unselected-rules] OK: all mandatory quality rules are selected.")
        return 0

    print(f"\033[31m[unselected-rules] FAIL: {len(missing)} mandatory rule(s) NOT selected in linter config!\033[0m")
    for r in missing:
        print(f"  \033[31m✗\033[0m missing: {r}")

    if args.gate:
        print("BLOCKED [unselected-rules] - GS2-192 invariant: required quality rules must be in select.")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
