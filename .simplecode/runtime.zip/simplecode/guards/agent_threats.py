"""AI-agent / MCP-tool threat detectors: source text -> bool per threat.

# simplecode:corpus sus constantes SON las cargas de amenaza que detecta (inyeccion, homoglifos, invisibles)

Registry of pure regex/unicodedata detectors for the threat taxonomy that
shows up in agent skill manifests, tool descriptions, and MCP tool
definitions: prompt injection, tool poisoning via confusable/invisible
Unicode, excessive agency, data exfiltration, and system-prompt leakage.
Mirrors the shape of pattern_detectors.py's PATTERN_DETECTORS registry --
one entry per distinct threat, (function, key, message) tuples -- so it can
be dropped into the same scanning pipeline.

Threat taxonomy informed by SkillSpector (NVIDIA, Apache-2.0), reimplemented
clean-room: this module's regex/unicodedata logic is original, written from
the taxonomy names/categories only, not copied from SkillSpector source.

stdlib only (re, unicodedata).
"""

import re
import unicodedata

from simplecode.guards.pattern_detectors import UnparseableSource, _mask_adversarial_test_literals, _parse

# --- prompt_injection: instruction-override phrasing aimed at an LLM reader ---
_INSTRUCTION_OVERRIDE = re.compile(  # simplecode:corpus vocabulary for prompt_injection
    r"\b(?:ignore|disregard|forget)\s+(?:all\s+|any\s+)?(?:the\s+)?"
    r"(?:previous|prior|above|earlier|your)\s+"
    r"(?:instructions?|rules?|prompts?|guidelines?|constraints?)\b"
    r"|\bignore\s+(?:all\s+)?(?:safety|security)\s+(?:rules?|checks?|constraints?)\b"
    r"|\byou\s+are\s+now\s+(?:in\s+)?(?:an?\s+)?(?:unrestricted|unfiltered|jailbroken?|dan)\s+mode\b"
    r"|\bnew\s+instructions?\s*:\s"
    r"|\boverride\s+(?:your\s+)?(?:system|safety|security)\b"
    r"|<\|(?:im_start|im_end|system|user|assistant)\|>"
    r"|\[\/?INST\]"
    r"|<<SYS>>|<\/<<SYS>>"
    r"|<｜(?:User|Assistant|System)｜>",
    re.IGNORECASE,
)

# --- tool_poisoning: Unicode deception in identifiers/names ---
# Common confusable Cyrillic/Greek letters that render identically to Latin.
_CONFUSABLES = {  # simplecode:corpus vocabulary for tool_poisoning_homoglyph
    "а": "a", "е": "e", "о": "o", "р": "p",
    "с": "c", "у": "y", "х": "x", "і": "i",
    "А": "A", "В": "B", "Е": "E", "К": "K",
    "М": "M", "Н": "H", "О": "O", "Р": "P",
    "С": "C", "Т": "T", "Х": "X",
    "α": "a", "ε": "e", "ο": "o", "ρ": "p",
}

# Public export (DEBT-INVISIBLE-CHAR-CONSOLIDATION follow-up): mcp_security.py
# hand-maintained its own near-identical confusables dict, independently, and
# was missing lowercase Cyrillic 'х' (U+0445) -> 'x' -- a tool named with it
# (e.g. "eхec_tool" spoofing "exec_tool") normalized to itself unchanged, so
# it would not be flagged as shadowing/matching the real tool name. Same
# consolidation as INVISIBLE_OR_BIDI_RE above, same reason: one hand-written
# copy per file diverges silently, one shared definition can't.
CONFUSABLES = _CONFUSABLES
# Two families, because only one of them can be written down as data safely.
# Zero-width/filler: render as nothing, reorder nothing.
_ZW_CHARS = (  # simplecode:corpus vocabulary for tool_poisoning_invisible
    "​‌‍⁠﻿­"
    # Filler and blank codepoints that render as nothing but are *letters* or
    # *marks* to the tokenizer, so they pass identifier validation: an adversarial
    # fixture hid U+034F inside `account` and U+3164 inside a call, and neither
    # fired against the zero-width set above.
    "͏ㅤ⠀ᅟᅠ"
)
# Bidi controls: these REORDER the rendering of the source around them, so they
# are the vice even quoted -- a U+202E inside a string flips the rest of the line.
_BIDI_CHARS = "‪-‮⁦-⁩"  # nosec B613 - detection constant, not hidden bidi  # simplecode:corpus vocabulary for tool_poisoning_invisible
_ZERO_WIDTH_OR_BIDI = re.compile(f"[{_ZW_CHARS}{_BIDI_CHARS}]")

# Public export (DEBT-INVISIBLE-CHAR-CONSOLIDATION): injection_filter.py and
# mcp_security.py each hand-maintained their own narrower invisible/bidi
# character set, independently, and diverged -- injection_filter's missed
# every bidi control, mcp_security's missed the soft-hyphen/word-joiner
# group AND the filler codepoints above (U+034F, U+3164, ...) that an
# adversarial fixture proved necessary against the naive zero-width set.
# This set is the union of everything either module needs, so a payload
# that would have slipped past one of the two narrower sets is now caught
# by both. Both modules now import this instead of maintaining their own.
INVISIBLE_OR_BIDI_RE = _ZERO_WIDTH_OR_BIDI

# A quoted literal whose ENTIRE content is zero-width characters is the codepoint
# being named as data, not hidden in text: `text.lstrip('﻿')` strips a BOM,
# it disguises nothing. The vice is the disguise, and a disguise needs visible
# neighbours to hide among -- measured against the fleet, both hits this detector
# had were exactly this idiom (office2office/parsers/html_parser.py:995 and
# scripts/independent_oracles.py:115), each with a comment naming the BOM one line
# up. rules/vices.yaml's own vc-083-invisible-control-character-in-source says the
# same with `pattern-not-inside: '"..."'`; the detector had simply diverged from it.
# Narrower than the rule on purpose: only a *purely* invisible literal is exempt,
# so `"account<U+200B>_id"` is still convicted, and bidi controls never are. Capped
# at 8, because a long invisible run is a steganographic payload, not a constant.
_INVISIBLE_CHAR_CONSTANT = re.compile(rf"(['\"])[{_ZW_CHARS}]{{1,8}}\1")


def _script_of(ch: str) -> str:
    """Coarse Unicode script bucket for a single letter, via unicodedata name."""
    try:
        name = unicodedata.name(ch)
    except ValueError:
        return "OTHER"
    for script in ("LATIN", "CYRILLIC", "GREEK", "ARABIC", "HEBREW", "HANGUL"):
        if script in name:
            return script
    return "OTHER"


# --- excessive_agency: unbounded shell/file/network reach with no gate ---
_UNBOUNDED_AGENCY = re.compile(
    r"\b(?:run|execute|invoke|call)\s+any\s+(?:available\s+)?(?:tool|command|script)s?\b"
    r"|\ballow(?:ed)?\s*[:=]\s*(?:\[\s*)?['\"]?\*['\"]?"
    r"|\bfull\s+(?:shell|file\s*system|network)\s+access\b"
    r"|\bno\s+(?:confirmation|approval|human[- ]in[- ]the[- ]loop)\s+(?:required|needed)\b"
    r"|\bwithout\s+(?:asking|confirming|user\s+approval)\b.{0,40}\b(?:delete|rm\s|format|drop|deploy|transfer)\b",
    re.IGNORECASE,
)

# --- data_exfiltration: a harvested secret store carried INTO an outbound call ---
# The source is deliberately narrow: HARVESTING, which is the word the threat is
# named after -- the whole environment as one value, or a credentials file. A
# single named read (`os.environ.get("OPENFOLD_PORT")`, `os.environ["TOKEN"]`)
# is configuration, and an identifier merely *called* `api_key` is a variable
# name, not evidence. Measured on the live fleet (2026-08-16): the old
# co-occurrence rule convicted 10 files and every one of the 10 was legitimate --
# a port read plus a POST to localhost, a DocuSign JWT exchanged at DocuSign's
# own /oauth/token, a Google key sent to Google in X-Goog-Api-Key.
_SECRET_SOURCE = re.compile(
    r"os\.environ\b(?!\s*(?:\.get\b|\[|\.setdefault\b|\.update\b|\.pop\b))"
    r"|process\.env\b(?!\s*[.\[])"
    r"|\.ssh/id_\w+"
    r"|\.aws/credentials",
    re.IGNORECASE,
)
_OUTBOUND_SINK = re.compile(
    r"requests\.(?:post|put)\s*\(|httpx\.(?:post|put)\s*\("
    r"|urllib\.request\.urlopen\s*\(|fetch\s*\(\s*['\"]https?://"
    r"|curl\s+[^\n]*(?:-d|--data)|\bnc\s+-e\b",
    re.IGNORECASE,
)

# --- second rule: a credential built INTO a URL query string ---
# The harvesting rule above is correct and stays, but it answers only half the
# threat, and the half it misses is the one that leaks silently. Sending a
# credential to the service that issued it is authentication -- and real
# authentication travels in a HEADER or a body. A secret concatenated into
# `?k=<value>` is leaked to every proxy, load balancer and access log on the
# path, whoever the recipient is. That is why the read form excluded as
# "configuration" by _SECRET_SOURCE (`os.environ["API_KEY"]`, `os.getenv(...)`)
# still convicts here: the sin is the PLACEMENT, not the read.
#
# GET joins the sink list for THIS rule only. Adding it to _OUTBOUND_SINK would
# reinstate the co-occurrence rule that fired 10 times and was wrong 10 times,
# because every API client in the fleet does a GET somewhere.
_URL_SINK = re.compile(
    r"requests\.(?:get|post|put|patch|delete)\s*\(|httpx\.(?:get|post|put)\s*\("
    r"|urllib\.request\.urlopen\s*\(|session\.(?:get|post)\s*\(",
    re.IGNORECASE,
)
# A query string being BUILT: a literal containing `?x=` or `&x=` that the
# expression continues past, i.e. concatenation or interpolation follows.
_QUERY_BUILD = re.compile(r"""['"][^'"]*[?&][A-Za-z_][\w\-]*=(?:['"]\s*\+|\{)""")
_ANY_SECRET_READ = re.compile(
    r"os\.environ\s*(?:\[|\.get\s*\()\s*['\"][^'\"]*"
    r"(?:KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL|AUTH)[^'\"]*['\"]"
    r"|os\.getenv\s*\(\s*['\"][^'\"]*"
    r"(?:KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL|AUTH)[^'\"]*['\"]"
    r"|process\.env\.[\w]*(?:KEY|TOKEN|SECRET|PASSWORD)[\w]*",
    re.IGNORECASE,
)

# --- system_prompt_leakage: instructions to reveal/dump the hidden prompt ---
_PROMPT_LEAK_REQUEST = re.compile(
    r"\b(?:print|reveal|show|output|repeat|dump|leak)\s+(?:your\s+|the\s+)?"
    r"(?:full\s+|entire\s+)?system\s+prompt\b"
    r"|\bwhat\s+(?:are|is)\s+your\s+(?:system\s+)?(?:instructions?|rules?)\b"
    r"|\brepeat\s+(?:everything|all\s+text)\s+(?:above|before\s+this)\b",
    re.IGNORECASE,
)


# Real executor for an instruction-override PAYLOAD: something that actually
# invokes an agent/LLM with it. ATTR-only (see pattern_detectors._adversarial_
# test_data_ids docstring) -- a bare `run(...)`/`generate(...)` is exactly as
# likely to be the validator/probe under test as a real agent call.
_PROMPT_INJECTION_EXECUTORS = frozenset(
    {"run", "arun", "generate", "invoke", "ainvoke", "complete", "chat", "predict", "send"}
)


def prompt_injection(code: str) -> bool:
    """Instruction-override phrasing targeting an LLM reader ("ignore previous instructions").

    First real fleet hit (2026-08-26, Atlas tests/test_wallbreaker_adversarial_probe.py):
    an injection payload fed to the probe under test to verify it gets
    DETECTED, never to a real agent. Exempted the same way `pattern_detectors
    .destructive_without_dryrun` exempts adversarial destructive literals --
    inside a `def test_*`, the phrase is data unless actually passed to
    something in `_PROMPT_INJECTION_EXECUTORS` (see `_adversarial_test_data_ids`
    for the shared mechanism and its rationale).

    Unlike Python source files, this detector's input is not guaranteed to be
    parseable Python -- it also scans prose (tool descriptions, manifests,
    docstrings-as-text). An unparseable input skips the structural exemption
    and falls back to the original whole-text regex, unchanged.
    """
    if not _INSTRUCTION_OVERRIDE.search(code):
        return False
    try:
        tree = _parse(code)
    except UnparseableSource:
        return True
    masked = _mask_adversarial_test_literals(tree, code, _PROMPT_INJECTION_EXECUTORS)
    return bool(_INSTRUCTION_OVERRIDE.search(masked))


def _tokens(code: str) -> list[str]:
    """Word-like runs. The substitution attack happens INSIDE a word."""
    return re.findall(r"[^\s.,;:()\[\]{}'\"=+\-*/<>!&|@#$%^~`?\\]{2,}", code)


# A maximal run of LETTERS -- no `_`, no digits. `_tokens` keeps those inside the
# word, which is right for a substitution but wrong for a subscript: `CVaR_α` is
# one token and two letter runs, and only the second reading tells them apart.
_LETTER_RUN = re.compile(r"[^\W\d_]+", re.UNICODE)
# Word scale. Measured over the fleet (2026-08-16): 3,922,592 of 3,922,690
# letter runs are <= 40 characters (99.9975%), and every run above 45 is a
# protein sequence in a viewer build script. A longer run is an inventory or a
# payload; nothing that long passes for a name a human reads.
_WORD_SCALE = 40


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def tool_poisoning_homoglyph(code: str) -> bool:
    """A confusable letter substituted INSIDE an otherwise-Latin word.

    Both conditions are per-token, not per-file. Judged per file, this fired on
    any file that happened to contain a wholly-Cyrillic string and any English
    word anywhere -- measured against the cemetery's labeled near-miss corpus,
    it convicted `MENSAJE_ERROR_RU = "ошибка configuración"`, where nothing is
    substituted: every letter looks exactly like what it is. The vice is the
    disguise (`fоrmat_text` with a Cyrillic о), so the confusable and the Latin
    letters it hides among must sit in the SAME token.

    Same token is still not tight enough for GREEK. An underscore-joined Greek
    subscript is the notation of maths and finance, not a disguise: measured on
    the live fleet, this convicted `# α in CVaR_α` in NVIDIA's Apache-2.0
    cvar_parameters.py, where α is the confidence level's actual name, spelled
    out in the same comment -- the sibling `Δt`/`σ_ruido` case the near-miss
    corpus already exonerates for tool_poisoning_mixed_script. A Greek letter
    only disguises when it sits INSIDE an alphabetic run with Latin letters
    (`fοrmat`), never when the underscore makes it its own morpheme.

    Cyrillic gets no such exemption and must not: it names no magnitude, so
    `Т_tar` shadowing `T_tar` is the disguise even as a lone morpheme. The
    asymmetry is deliberate. Ceiling: an identifier that genuinely mixes a
    Russian word with an English one (`счет_total`) reads as a hit; no such
    token exists in the measured fleet, and for a SECURITY detector the
    false negative is the worse of the two errors.
    """
    for token in _tokens(code):
        confusables = [ch for ch in token if ch in _CONFUSABLES]
        if not confusables:
            continue
        if not any(ch.isascii() and ch.isalpha() for ch in token):
            continue  # wholly non-Latin token: nothing is being passed off
        if any(_script_of(ch) == "CYRILLIC" for ch in confusables):
            return True
        # Greek: a vice only inside an alphabetic run shared with Latin letters.
        for part in re.split(r"[_\d]+", token):
            if any(ch in _CONFUSABLES for ch in part) and any(
                ch.isascii() and ch.isalpha() for ch in part
            ):
                return True
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def tool_poisoning_invisible(code: str) -> bool:
    """A zero-width, BOM, soft-hyphen, or bidi-override character hidden in text.

    `hidden` is the whole vice. A codepoint written as the sole content of a
    quoted literal is declared, not hidden -- that is how every BOM stripper in
    existence is written -- so those literals are masked out before the search.
    Bidi controls are never masked: they reorder the source around them whether
    quoted or not.
    """
    return bool(_ZERO_WIDTH_OR_BIDI.search(_INVISIBLE_CHAR_CONSTANT.sub("", code)))


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def tool_poisoning_mixed_script(code: str) -> bool:
    """A WORD mixing scripts where the intruding letter is a CONFUSABLE.

    Mixed scripts alone are not the vice. Scientific notation mixes them by
    convention -- `Δt`, `μs_por_muestra`, `σ_ruido`, `2·π·r` are physics, and
    the cemetery's labeled near-miss corpus convicts exactly those to make the
    point: a Greek letter that IS the name of a magnitude substitutes nothing,
    because it looks like nothing else. The vice needs a letter that passes for
    another one, so at least one character must be confusable.

    Two further narrowings, each paid for by a measured false positive on the
    fleet (fixture: near_miss/VC-083-magnitud.py):

    1. The unit is the LETTER RUN, not the token. `_tokens` keeps `_` and digits
       inside the word, so `CVaR_α` read as one token "mixes scripts" -- but the
       Greek letter is its own segment, a subscript, not a letter smuggled among
       Latin ones. Measured: Atlas `cvar_parameters.py:43` (`α in CVaR_α`), the
       standard name of the CVaR confidence level. VC-083 exonerated `Δ/μ/σ`,
       none of which is in _CONFUSABLES, so this path was never exercised: the
       four Greek letters that ARE confusable (`α ε ο ρ`) are also the canonical
       names of magnitudes -- significance, tolerance, density, correlation.
    2. A run longer than a word is an INVENTORY, not a disguise. Measured:
       office2office `wpd_parser.py:70`, the WordPerfect Cyrillic character set
       -- 350+ letters enumerating an alphabet so it can be decoded, mixed only
       because that set legitimately contains U+0194/U+0263 LATIN GAMMA. Nothing
       350 characters long passes for a name a human reads. The bound is
       measured, not guessed: 99.9975% of the 3,922,690 letter runs in the fleet
       are <= 40 characters, and every run above 45 is a protein sequence.

    A homoglyphed identifier stays caught however heavily it is substituted
    (`ассоunt`, majority-Cyrillic, is 7 characters and still a word).
    """
    for run in _LETTER_RUN.finditer(code):
        word = run.group()
        if len(word) > _WORD_SCALE or not any(ch in _CONFUSABLES for ch in word):
            continue
        scripts = {
            _script_of(ch)
            for ch in word
            if ch.isalpha() and _script_of(ch) != "OTHER"
        }
        if len(scripts) > 1:
            return True
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def excessive_agency(code: str) -> bool:
    """Unbounded tool/shell/network reach granted with no confirmation gate."""
    return bool(_UNBOUNDED_AGENCY.search(code))


_SPAN_CAP = 20_000  # a real argument list is small; the cap bounds a runaway scan


def _sink_argument_spans(code: str, sink: re.Pattern | None = None) -> list[str]:
    """The argument text of each outbound call: from its `(` to the matching `)`.

    Shell sinks (`curl ... -d`, `nc -e`) have no parentheses, so their span is
    the rest of the command line. A call whose parentheses never balance inside
    `_SPAN_CAP` characters yields NO span: an unbalanced scan running to EOF
    would swallow the whole file and reinstate the co-occurrence rule this
    function exists to replace.
    """
    spans = []
    for m in (sink or _OUTBOUND_SINK).finditer(code):
        if m.group(0).lstrip().lower().startswith(("curl", "nc")):
            eol = code.find("\n", m.end())
            spans.append(code[m.start(): eol if eol != -1 else len(code)])
            continue
        start = code.find("(", m.start(), m.end())
        if start == -1:
            continue
        depth = 0
        limit = min(len(code), start + _SPAN_CAP)
        for i in range(start, limit):
            if code[i] == "(":
                depth += 1
            elif code[i] == ")":
                depth -= 1
                if depth == 0:
                    spans.append(code[start:i + 1])
                    break
    return spans


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def data_exfiltration(code: str) -> bool:
    """A harvested secret store passed as an ARGUMENT to an outbound network call.

    Co-presence in a file is not the vice. Any client that talks to an
    authenticated service reads config from the environment somewhere and posts
    somewhere else; measured over 2,898 live fleet files, that rule fired 10
    times and was wrong 10 times. The vice is the flow: `dict(os.environ)` or
    `~/.aws/credentials` sitting INSIDE the call that ships it out. Sending a
    credential to the service that issued it (a Bearer header, an OAuth token
    exchange, `X-Goog-Api-Key` to Google) is authentication, not exfiltration.

    SECOND RULE, added after a sensitivity battery caught this detector at 0 of 4
    real variants of the vice: a credential concatenated into a URL QUERY STRING.
    There the sin is the PLACEMENT, not the read -- real authentication travels
    in a header or a body, while `?k=<secret>` is copied into every proxy and
    access log on the path -- so the named reads that rule one treats as
    configuration do convict here.
    """
    if any(_SECRET_SOURCE.search(span) for span in _sink_argument_spans(code)):
        return True
    return any(
        _QUERY_BUILD.search(span) and _ANY_SECRET_READ.search(span)
        for span in _sink_argument_spans(code, sink=_URL_SINK)
    )


# flota 2026-08-20: 0 hits.
def system_prompt_leakage(code: str) -> bool:
    """A request to print, reveal, or repeat the hidden system prompt."""
    return bool(_PROMPT_LEAK_REQUEST.search(code))


_GHOST_TOOL_RE = re.compile(
    r"""(?:\btool_name\s*[:=]\s*['"](?:ghost_|fake_|hallucinated_|mock_nonexistent_)[^'"]+['"])"""
    r"""|(?:\bcall_tool\s*\(\s*['"](?:ghost_|fake_|hallucinated_)[^'"]+['"])""",
    re.IGNORECASE,
)

_SIMULATION_COMMENT = (
    r"#\s*(?:simulación|simulacion|stub\s+(?:implementation|tool|check)|fake\s+(?:implementation|benchmark|data)|mock\s+implementation)\b"
)
_SIMULATION_EMPTY_DEF = (
    r"\bdef\s+\w+\([^)]*\):\s*(?:\"\"\"[^\"]*\"\"\"\s*)?(?:#\s*.*?\n\s*)?(?:print\([^\n]+\)\s*;?\s*)?return\s+(?:\[\]|\{\}|0|\"\"|'')\s*$"
)
_SIMULATION_STUB_RE = re.compile(  # simplecode:corpus vocabulary for simulated_or_stub_implementation
    _SIMULATION_COMMENT + "|" + _SIMULATION_EMPTY_DEF, re.IGNORECASE | re.MULTILINE,
)
# In a test file, a fake `def fetchall(self): return []` is a test DOUBLE, not a stub implementation
# disguised as a real one (cuenza, 2026-09-25: two test files convicted for their fake DB cursors). Only
# the empty-`def` shape is dropped there; a `# simulación` comment convicts in tests as everywhere.
_SIMULATION_COMMENT_RE = re.compile(_SIMULATION_COMMENT, re.IGNORECASE | re.MULTILINE)


def _is_test_file(path: str | None) -> bool:
    if not path:
        return False
    parts = path.replace("\\", "/").split("/")
    return "tests" in parts[:-1] or parts[-1].startswith("test_") or parts[-1] == "conftest.py"


# flota 2026-08-20: 0 hits.
def ghost_tool_invocation(code: str) -> bool:
    """Invocation of an unregistered/ghost agent tool (GS2-155 / GS2-183)."""
    return bool(_GHOST_TOOL_RE.search(code))


_SIMULATION_STUB_CONSUMERS = frozenset({"simulated_or_stub_implementation"})


def simulated_or_stub_implementation(code: str, path: str | None = None) -> bool:
    """Detection of explicit simulation comments (# Simulación) or stub tool definitions (GS2-227).

    `path` (optional) tells a test file from production code: the empty-`def` alternative is a test
    double there and is not judged; the comment alternative is judged everywhere.
    """
    rx = _SIMULATION_COMMENT_RE if _is_test_file(path) else _SIMULATION_STUB_RE
    if not rx.search(code):
        return False
    try:
        tree = _parse(code)
    except UnparseableSource:
        return True
    masked = _mask_adversarial_test_literals(tree, code, frozenset(), bare_consumers=_SIMULATION_STUB_CONSUMERS)
    return bool(rx.search(masked))


# Registry: (function, key, human message). One entry per distinct threat.
AGENT_THREAT_DETECTORS: tuple[tuple, ...] = (
    (prompt_injection, "prompt_injection", "Instruction-override prompt injection ('ignore previous instructions' family)"),
    (tool_poisoning_homoglyph, "tool_poisoning_homoglyph", "Confusable Cyrillic/Greek homoglyph mixed into Latin identifier text"),
    (tool_poisoning_invisible, "tool_poisoning_invisible", "Invisible Unicode (zero-width/BOM/bidi-override) hidden in text"),
    (tool_poisoning_mixed_script, "tool_poisoning_mixed_script", "Identifier mixing multiple Unicode scripts (visual spoofing)"),
    (excessive_agency, "excessive_agency", "Unbounded shell/file/network agency granted with no confirmation gate"),
    (data_exfiltration, "data_exfiltration", "Secret/env harvesting reaching an outbound network sink"),
    (system_prompt_leakage, "system_prompt_leakage", "Instruction requesting the hidden system prompt be revealed"),
    (ghost_tool_invocation, "ghost_tool_invocation", "Invocation of an unregistered/ghost agent tool (GS2-155 / GS2-183)"),
    (simulated_or_stub_implementation, "simulated_or_stub_implementation", "Simulated or stub implementation disguised as functional code (# Simulación family)"),
)

