# -*- coding: utf-8 -*-
# simplecode:corpus constantes con vocabulario de patrones de inyeccion y tokens de control LLM
"""Deterministic sanitizer for prompt injection vehicles and covert payloads in text documents."""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from simplecode.guards.agent_threats import INVISIBLE_OR_BIDI_RE as ZERO_WIDTH_RE

HTML_COMMENT_RE = re.compile(r"<!--[\s\S]*?(?:-->|$)", re.IGNORECASE)
BASE64_BLOB_RE = re.compile(r"\b[A-Za-z0-9+/]{100,}={0,2}\b")
IMPERATIVE_PHRASES = [
    r"(?i)\b(?:ignore|disregard|forget|override|bypass)\s+(?:all\s+)?(?:previous|prior|system)\s+(?:instructions|rules|prompts|directives)\b",
    r"(?i)\b(?:olvida|ignora|anula|descarta)\s+(?:todas\s+)?(?:las\s+)?(?:instrucciones|reglas|directivas)\s+(?:previas|anteriores|del\s+sistema)\b",
    r"(?i)\b(?:system\s+prompt\s+override|admin\s+mode\s+enabled|jailbreak\s+prompt)\b",
    r"(?i)\b(?:you\s+must\s+now\s+act\s+as|actúa\s+ahora\s+como)\s+DAN\b",
]
# LLM Role & Special Control Tokens (ChatML, LLaMA, Mistral, DeepSeek, Anthropic) (DGX-298)
CONTROL_TOKENS_RE = re.compile(
    r"(?i)(?:<\|(?:im_start|im_end|system|user|assistant|endoftext)\|>"
    r"|\[\/?INST\]|<<SYS>>|<\/<<SYS>>"
    r"|<｜(?:User|Assistant|System)｜>"
    r"|^(?:Human|Assistant|System):\s+)",
    re.MULTILINE,
)
IMPERATIVE_RES = [re.compile(p) for p in IMPERATIVE_PHRASES]


def sanitize_text(text: str) -> tuple[str, list[str]]:
    """Sanitize incoming text, stripping injection vehicles and returning detected findings."""
    findings: list[str] = []
    cleaned = text

    # 1. Zero-width character injection
    if ZERO_WIDTH_RE.search(cleaned):
        findings.append("zero_width_chars")
        cleaned = ZERO_WIDTH_RE.sub("", cleaned)

    # 2. Hidden HTML comments
    if HTML_COMMENT_RE.search(cleaned):
        findings.append("html_comment_payload")
        cleaned = HTML_COMMENT_RE.sub("[SANITIZED_HTML_COMMENT]", cleaned)

    # 3. Large Base64 payload blobs
    if BASE64_BLOB_RE.search(cleaned):
        findings.append("base64_covert_blob")
        cleaned = BASE64_BLOB_RE.sub("[REDACTED_BASE64_PAYLOAD]", cleaned)

    # 4. Explicit imperative override commands
    for pat in IMPERATIVE_RES:
        if pat.search(cleaned):
            findings.append(f"imperative_override: {pat.pattern}")
            cleaned = pat.sub("[REDACTED_INJECTION_DIRECTIVE]", cleaned)

    # 5. Raw LLM control & role-tag tokens (DGX-298)
    if CONTROL_TOKENS_RE.search(cleaned):
        findings.append("control_token_role_tag")
        cleaned = CONTROL_TOKENS_RE.sub("[SANITIZED_CONTROL_TAG]", cleaned)

    return cleaned, findings


def sanitize_file(path: Path) -> tuple[str, list[str]]:
    """Read and sanitize a file."""
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "", ["file_read_error"]
    return sanitize_text(content)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Sanitize documents and prompt inputs against injection vehicles."
    )
    parser.add_argument("paths", nargs="*", type=Path, help="Files to inspect/sanitize")
    args = parser.parse_args(argv)

    if not args.paths:
        print("[injection-filter] No files provided. Reading from stdin...")
        try:
            content = sys.stdin.read()
            cleaned, findings = sanitize_text(content)
            if findings:
                print(f"[injection-filter] Sanitized {len(findings)} threats: {findings}", file=sys.stderr)
            sys.stdout.write(cleaned)
            return 0
        except OSError:
            return 1

    threat_count = 0
    for p in args.paths:
        if not p.is_file():
            continue
        _, findings = sanitize_file(p)
        if findings:
            threat_count += len(findings)
            print(f"[injection-filter] THREAT in {p}: {findings}")
        else:
            print(f"[injection-filter] OK: {p}")

    return 1 if threat_count > 0 else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
