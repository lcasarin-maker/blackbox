#!/usr/bin/env python3
"""Auditoria mecanica y determinista de la flota, sin LLM. Para correr cada 2-3 dias.

Generalizado a partir de la auditoria manual de 6 agentes en paralelo del 2026-09-07
(ver DEBT-FLEET-GENERALIZATION-CANDIDATES-2026-09-07 item 7, pedido explicito de Luis
tras ver el resultado de esa pasada). Esa auditoria encontro deuda real -- forks
desactualizados, `EXPECT` reinventado a mano, `local_hooks.yaml` gitignorado -- pero cada
repeticion cuesta 6 agentes leyendo codigo. Este modulo repite solo la parte MECANICA de
esa pasada: diffs de contenido de `gates/*.py` contra la madre, si `EXPECT` sigue escrito
a mano, si `.simplecode/local_hooks.yaml` esta trackeado, y si `runtime.zip` diverge de
version. Cuatro chequeos que ya existian como funciones sueltas en
`simplecode.verification.canon_adoption` y `simplecode.satellite.satellite_sync` --
este modulo los corre juntos, por satelite, sin releer codigo nuevo con criterio.

LO QUE ESTE MODULO NO PUEDE CAZAR, dicho para que nadie lo lea como el reemplazo del
ejercicio manual: cualquier patron nuevo que no este codificado aqui. La pasada manual del
2026-09-07 encontro `deuda-declarada` y `auto_commit_enforcer.py` -- ninguno de los dos lo
habria cazado un script determinista, porque exigen JUZGAR codigo nuevo, no comparar bytes
contra una madre. Este modulo es el complemento barato de esa pasada, no su sustituto.

Uso:
    python -m simplecode.guards.fleet_audit --fleet ~/projects [--json] [--materialize]
"""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from simplecode import cli_new
from simplecode.satellite.satellite_sync import (
    _bundle_version,
    _bundle_version_from_bytes,
    enrolled_satellites,
)
from simplecode.verification.canon_adoption import (
    _gates_forkeados_desactualizados,
    _local_hooks_sin_versionar,
    _mother_reachable,
)

# El literal exacto que `_expect_del_kit()` reemplaza (DEBT-QUINCE-COPIAS-DEL-ESQUEMA-
# DIVERGEN). Un satelite que todavia lo tenga escrito a mano no ha migrado.
_EXPECT_LITERAL_RE = re.compile(r'EXPECT\s*=\s*\{["\']exit_zero')
_EXPECT_DERIVADO_RE = re.compile(r"EXPECT\s*=\s*_expect_del_kit\(\)")


@dataclass(frozen=True)
class HallazgoSatelite:
    repo: str
    forks_desactualizados: list[str] = field(default_factory=list)
    expect_escrito_a_mano: bool = False
    local_hooks_sin_trackear: bool = False
    version_satelite: str = "missing"
    version_madre: str = "unknown"

    @property
    def runtime_diverge(self) -> bool:
        return self.version_satelite not in (self.version_madre, "missing")

    @property
    def limpio(self) -> bool:
        return not (
            self.forks_desactualizados
            or self.expect_escrito_a_mano
            or self.local_hooks_sin_trackear
            or self.runtime_diverge
        )


def _expect_escrito_a_mano(root: Path) -> bool:
    """True si `gates/ledger_schema.py` existe y todavia declara `EXPECT` como
    literal en vez de derivarlo del kit (`_expect_del_kit()`)."""
    fork = root / "gates" / "ledger_schema.py"
    if not fork.is_file():
        return False
    texto = fork.read_text(encoding="utf-8", errors="ignore")
    return bool(_EXPECT_LITERAL_RE.search(texto)) and not bool(_EXPECT_DERIVADO_RE.search(texto))


def auditar_satelite(root: Path) -> HallazgoSatelite:
    """El chequeo mecanico de UN repo. No escribe nada."""
    mother_pkg = _mother_reachable(root)
    version_madre = (
        _bundle_version_from_bytes(cli_new._runtime_bundle())
        if mother_pkg is not None
        else "unknown"
    )
    return HallazgoSatelite(
        repo=root.name,
        forks_desactualizados=_gates_forkeados_desactualizados(root),
        expect_escrito_a_mano=_expect_escrito_a_mano(root),
        local_hooks_sin_trackear=_local_hooks_sin_versionar(root),
        version_satelite=_bundle_version(root / ".simplecode" / "runtime.zip"),
        version_madre=version_madre,
    )


def _es_repo(path: Path) -> bool:
    return path.is_dir() and (path / ".git").exists()


def auditar_flota(fleet: Path, manifest: Path | None = None) -> list[HallazgoSatelite]:
    """Audit explicit enrollment when a manifest is supplied; discovery is legacy."""
    if manifest is not None:
        return [auditar_satelite(p.resolve()) for p in enrolled_satellites(fleet, manifest)]
    return [
        auditar_satelite(p.resolve())
        for p in sorted(fleet.iterdir())
        if _es_repo(p)
    ]


def _reporte_satelite(h: HallazgoSatelite) -> list[str]:
    lineas = []
    if h.forks_desactualizados:
        lineas.append(
            f"  fork(s) desactualizados vs madre: {', '.join(h.forks_desactualizados)}"
        )
    if h.expect_escrito_a_mano:
        lineas.append("  EXPECT sigue escrito a mano (no migrado a _expect_del_kit())")
    if h.local_hooks_sin_trackear:
        lineas.append("  .simplecode/local_hooks.yaml existe pero no esta trackeado por git")
    if h.runtime_diverge:
        lineas.append(
            f"  runtime.zip diverge: satelite={h.version_satelite} madre={h.version_madre}"
        )
    return lineas


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--fleet", type=Path, required=True, help="Audita cada repo bajo DIR")
    ap.add_argument("--manifest", type=Path, help="Inventario TOML explícito de satélites")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    hallazgos = auditar_flota(args.fleet, args.manifest)
    sucios = [h for h in hallazgos if not h.limpio]

    if args.json:
        print(json.dumps({
            "total": len(hallazgos),
            "limpios": len(hallazgos) - len(sucios),
            "sucios": {h.repo: _reporte_satelite(h) for h in sucios},
        }, ensure_ascii=False))
        return 1 if sucios else 0

    print(f"[fleet-audit] {len(hallazgos)} repo(s) auditados, {len(sucios)} con hallazgos")
    for h in sucios:
        print(f"  {h.repo}:")
        for linea in _reporte_satelite(h):
            print(linea)
    if not sucios:
        print("  ningun hallazgo mecanico -- esto NO cubre lo que exige criterio "
              "(ver docstring del modulo)")
    return 1 if sucios else 0


if __name__ == "__main__":
    raise SystemExit(main())
