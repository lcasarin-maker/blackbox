#!/usr/bin/env python3
# simplecode:corpus el organo lleva los codepoints que detecta -- el ZWJ es la constante con la que reconoce un ZWJ
"""Guard against silent file corruption in tracked text files.

Detects six corruption classes: (1) NUL-byte truncation/padding in text
files, (2) clean byte-mangling that breaks Python parsing without inserting
NUL bytes, (3) mojibake — text that shows signs of a UTF-8-read-as-
Latin-1/CP1252 double-encoding corruption, (4) a leading UTF-8 byte-order
mark, (5) CRLF line endings, and (6) soft-hyphen / zero-width encoding
corruption. Run standalone or as a pre-commit / pre-push hook.

Project exemptions live in ``<root>/.simplecode/corpus_exempt.yaml`` and are
opt-in, never a default:
  * ``corruption_guard_prefixes`` -- substring match; skips mojibake and the
    soft-hyphen / zero-width check (scraped corpora already diagnosed
    irrecoverable).
  * ``corruption_guard_exempt_prefixes`` -- exact cwd-relative paths or
    prefixes; skips ONLY the soft-hyphen / zero-width class. For sealed
    evidence whose measured datum IS the invisible character (a valid JSON
    whose string carries the U+FEFF an audited export emitted): editing it
    would break its integrity hash. NUL, leading BOM, CRLF, invalid UTF-8,
    syntax and mojibake are still judged on those paths. Every file whose
    finding this suppresses is logged and counted in a ``NOT EXAMINED`` line.

Job clause: c (no bad practice — corrupted files must not merge silently).
"""

from __future__ import annotations

import ast
import functools
import logging
import threading
import os
import re
import pathlib
import subprocess
import sys
import time
import unicodedata
from pathlib import Path

import yaml

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.git_utils import git_diff_name_only, git_ls_files, repo_toplevel
from simplecode.worktree.zero_debt import _load_corpus_exempt_list
from simplecode.utils.tool_limits import (
    DIFF_TIMEOUT_BASE,
    GIT_O1_TIMEOUT,
    compute_proportional_timeout,
)

# Extensions treated as text (must never contain NUL bytes).
#
# `.jsonl`/`.ndjson` added 2026-09-01, reported by Atlas (DGX-389) and
# reproduced here with the variable isolated -- same bytes, same directory, both
# staged, only the extension differs:
#
#     $ python3 -c "open('s.jsonl','wb').write(b'{\"a\":1}\n'+b'\x00'*2048)"
#     $ cp s.jsonl s.md && git add -A && python -m simplecode.guards.corruption_guard
#     s.md:2: NUL byte(s) in text file (2048 total) - corruption; restore from git
#     1 corrupted file(s).
#
# One, not two. `.json` was covered and `.jsonl` was not, so 8,494 NUL bytes
# reached Atlas's HEAD in a tracked 22 MB `logs/remine_harvest/remine.jsonl`
# with no gate skipped and no `--no-verify` -- five holes ending on exact 4,096
# byte boundaries, a dirty page lost to a hard cut. The guard's logic was never
# wrong; its reach was. `.jsonl` is the substrate of nearly all structured
# telemetry across the fleet and the format nobody reads by eye, which is
# exactly where silent corruption accumulates.
TEXT_SUFFIXES = {
    ".md",
    ".py",
    ".json",
    ".jsonl",
    ".ndjson",
    ".yaml",
    ".yml",
    ".txt",
    ".ini",
    ".cfg",
    ".toml",
    ".template",
    ".cursorrules",
    ".claudeignore",
    ".gitattributes",
}
# The list above is no longer the guard's REACH, only its fast path. Audit
# 2026-09-26 (DEBT-GATE-ENGANABLE-CORRUPTION-GUARD): the same corrupt bytes that
# block as `ledger.md` / `page.md` / `run.py` passed as `ledger.csv` (4,096 NUL)
# / `page.html` (mojibake) / `run.sh` (CRLF) --
#
#     $ python -m simplecode.guards.corruption_guard --staged
#     CORRUPTION GUARD: OK (5 files scanned)          rc=0
#
# -- so renaming the file was the whole cost of the bypass, and `.jsonl` had
# already fallen through that hole once (above). Any other file is now judged by
# CONTENT (`_looks_like_text`): if what remains after dropping NULs is UTF-8 text
# with no binary control bytes, it is a text file, judged by
# `_scan_unlisted_file` -- the classes that are damage in ANY format.
#
# Shell scripts are where CRLF/BOM break execution (`/bin/sh\r: not found`), so
# unlisted files with a shebang or one of these suffixes get those checks too.
LF_REQUIRED_SUFFIXES = {".sh", ".bash"}
# C0 control bytes that do not occur in text (everything below 0x20 except
# TAB, LF, VT, FF, CR and ESC, plus DEL). NUL is handled apart: it is the
# corruption being hunted, so it must not be what makes a file "binary".
_BINARY_CONTROLS = bytes(
    b for b in (*range(0x01, 0x20), 0x7F) if b not in b"\t\n\x0b\x0c\r\x1b"
)
# Directories that legitimately hold binary or historical artifacts.
SKIP_DIRS = {".git", "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache"}
SPECIAL_TEXT_PATHS = {
    Path(".git/config"),
    Path(".git/packed-refs"),
}

# Lead characters of a UTF-8-read-as-Latin-1/CP1252 double-encoding. On their
# own these are ALSO ordinary letters -- `â` in Portuguese `parâmetros`, `Ã` in
# `SÃO PAULO`, `Â` in French `Â«` -- so a bare marker is NOT evidence of
# corruption. What makes it mojibake is the SEQUENCE: a UTF-8 continuation byte
# (0x80-0xBF) read as Latin-1 renders in U+0080..U+00BF, so real double-encoding
# always appears as marker + one of those (`Ã©`, `Ã¡`, `â€™`, `Â `). A lone
# accented letter never does.
#
# Reported by Atlas 2026-09-01, right after `.jsonl` widened this guard's reach:
# the word `parâmetros` -- the local model writing one Portuguese term inside
# Spanish prose -- was declared corruption, with the message prescribing
# `restore from git` for a file that CAME from git and would come back
# identical. Measured on that 22 MB ledger: exactly one suspect character
# (`{'â': 1}`) and ZERO round-trip sequences (`Ã©`, `Ã¡`, `â€`, `Â ` -> 0 hits).
# For human-written code and markdown a lone `â` was a decent proxy; for a
# `.jsonl` holding multilingual model output it turns every spelling slip into a
# declared corruption, and with `pass_filenames: false` one such file froze
# every commit in the repo.
MOJIBAKE_LEADS = ("Ã", "Â", "â", "ð")
# Sequences that are unambiguous on their own, needing no continuation char.
MOJIBAKE_SEQUENCES = ("ï¸", "�")
# A UTF-8 continuation byte (0x80-0xBF) as it renders through EITHER decoding.
# Latin-1 maps them straight to U+0080..U+00BF, but CP1252 remaps 0x80-0x9F to
# printable punctuation (0x80 -> EUR, 0x99 -> RIGHT SINGLE QUOTE), which is why
# the classic `a-EUR-TM` apostrophe mojibake exists at all. Deriving the set
# from both codecs instead of hand-listing it means a byte cannot be missed the
# way `a-EUR-TM` was on the first cut of this fix.
_MOJIBAKE_CONT = tuple({
    bytes([c]).decode(codec)
    for c in range(0x80, 0xC0)
    for codec in ("latin-1", "cp1252")
    if bytes([c]).decode(codec, errors="ignore")
})
# One compiled scan instead of len(LEADS) x len(CONT) substring searches per
# line. The first cut of the sequence fix did the nested loop: 4 leads x 91
# continuations = 364 searches per line against the old predicate's 6, measured
# 113x slower (96.5 ms vs 0.9 ms over 2000 lines). Correctness fixed, throughput
# broken, in the same change -- and this guard sweeps every tracked text file, so
# Atlas felt it as a slow repo-wide scan and reasonably blamed the .jsonl bytes.
# Reading 160 MB there costs 0.22 s; the per-file work was the whole cost.
_MOJIBAKE_RE = re.compile(
    "(?:%s)|[%s][%s]" % (
        "|".join(re.escape(s) for s in MOJIBAKE_SEQUENCES),
        "".join(re.escape(c) for c in MOJIBAKE_LEADS),
        "".join(re.escape(c) for c in _MOJIBAKE_CONT),
    )
)

# UTF-8 byte-order mark. A BOM at the start of a tracked text file is almost
# always an editor/encoding artifact, not intentional content.
UTF8_BOM = b"\xef\xbb\xbf"

# Soft hyphen (U+00AD) and zero-width characters (ZWSP U+200B, ZWNJ U+200C,
# ZWJ U+200D, BOM-as-ZWNBSP U+FEFF mid-text) as their UTF-8 encodings. These
# are invisible in a rendered diff but corrupt tokenization/parsing and are a
# common symptom of a lossy copy-paste or encoding round-trip.
SOFT_HYPHEN_UTF8 = b"\xc2\xad"
ZERO_WIDTH_MARKERS_UTF8 = (
    b"\xe2\x80\x8b",  # ZERO WIDTH SPACE
    b"\xe2\x80\x8c",  # ZERO WIDTH NON-JOINER
    b"\xe2\x80\x8d",  # ZERO WIDTH JOINER
    b"\xef\xbb\xbf",  # ZERO WIDTH NO-BREAK SPACE / BOM (when not leading)
)

# Same four, as characters, for the decoded pass that spares emoji sequences.
_ZERO_WIDTH_CHARS = tuple(m.decode("utf-8") for m in ZERO_WIDTH_MARKERS_UTF8)


def _tracked_files() -> list[Path]:
    """Return git-tracked files; fall back to a filesystem walk if git is absent."""
    files = git_ls_files(Path("."))
    if files:
        return files
    def scan() -> list[Path]:
        return [
            p for p in Path(".").rglob("*")
            if p.is_file() and not (SKIP_DIRS & set(p.parts))
        ]

    try:
        return scan()
    except FileNotFoundError:
        return scan()


def _special_files() -> list[Path]:
    """Return extra text targets that git ls-files would not surface."""
    specials = [path for path in SPECIAL_TEXT_PATHS if path.is_file()]
    specials.extend(
        path
        for path in Path(".").rglob(".claude/*.md")
        if path.is_file() and ".claude" in path.parts
    )
    return specials


def _is_special_corruption_target(path: Path) -> bool:
    """Return True for text files that live outside the tracked-file inventory.

    The `.claude` check must anchor to the file's IMMEDIATE parent directory,
    not to any ancestor in the (possibly absolute) path. `git_ls_files`
    anchors paths to an absolute cwd, and an agent worktree commonly lives
    under `~/.claude/projects/<session>/...` -- matching `.claude` anywhere
    in that absolute path would misclassify every tracked `.md` file in such
    a worktree as this repo's own `.claude/` config, wrongly demanding a
    trailing newline and skipping the extension filter. `_special_files`'s
    own `.claude/*.md` glob is likewise non-recursive (direct children only),
    so `parent.name` matches its scope exactly.
    """
    parts = path.parts
    if len(parts) >= 2 and parts[-2:] in ((".git", "config"), (".git", "packed-refs")):
        return True
    return path.suffix.lower() == ".md" and path.parent.name == ".claude"


def _looks_like_text(data: bytes) -> bool:
    """Whether bytes outside `TEXT_SUFFIXES` are a text file (possibly corrupted).

    NULs are dropped before judging, because NUL padding of a text file is the
    corruption this guard exists for -- git's own "any NUL means binary" rule
    would classify exactly the damaged file as binary and let it through. A
    UTF-16/32 BOM declares a non-UTF-8 text encoding, which is not damage.
    Limit, declared: a text file saved in Latin-1 reads as binary here (it is
    not UTF-8), so its invalid-UTF-8 finding exists only on listed suffixes.

    Example:
        >>> _looks_like_text(b"a,b\\n1,2\\n" + b"\\x00" * 16)
        True
        >>> _looks_like_text(b"\\x89PNG\\r\\n\\x1a\\n\\x00\\x00\\x00\\rIHDR")
        False
        >>> _looks_like_text(b"\\xff\\xfeh\\x00i\\x00")
        False
    """
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return False
    body = data.replace(b"\x00", b"")
    if not body or len(body.translate(None, _BINARY_CONTROLS)) != len(body):
        return False
    try:
        body.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return True


def _first_nul_line(data: bytes) -> int:
    """1-based line number of the first NUL byte (for an actionable message)."""
    return data[: data.index(b"\x00")].count(b"\n") + 1


def has_mojibake(text: str) -> bool:
    """Whether text carries a double-encoding SEQUENCE, not just an accent.

    Example:
        >>> has_mojibake("plain ascii")
        False
        >>> has_mojibake("cafÃ©")
        True
        >>> has_mojibake("los parâmetros del modelo")
        False
        >>> has_mojibake("SÃO PAULO")
        False
    """
    return _MOJIBAKE_RE.search(text) is not None


def _find_mojibake_lines(text: str) -> list[tuple[int, str]]:
    """1-indexed (line number, stripped line) pairs for every mojibake line."""
    return [
        (line_no, line.strip())
        for line_no, line in enumerate(text.splitlines(), start=1)
        if has_mojibake(line)
    ]


def has_bom(data: bytes) -> bool:
    """Whether the raw bytes open with a UTF-8 byte-order mark.

    Example:
        >>> has_bom(b"\\xef\\xbb\\xbfhello")
        True
        >>> has_bom(b"hello")
        False
    """
    return data.startswith(UTF8_BOM)


def has_crlf(data: bytes) -> bool:
    """Whether the raw bytes contain a CRLF line ending.

    Example:
        >>> has_crlf(b"line1\\r\\nline2")
        True
        >>> has_crlf(b"line1\\nline2")
        False
    """
    return b"\r\n" in data


def _zwj_is_emoji_glue(text: str, index: int) -> bool:
    """Whether the ZWJ at `index` is joining two emoji into one glyph.

    U+200D between two emoji is the sequence itself, not damage: the office
    worker is literally person + ZWJ + briefcase. Measured on the live fleet,
    29 of 33 invisible characters this check flagged were exactly that, an 88%
    false-positive rate; deleting them would have split one glyph into two.
    """
    if index == 0 or index + 1 >= len(text):
        return False
    before, after = text[index - 1], text[index + 1]

    def emoji_like(ch: str) -> bool:
        return ord(ch) >= 0x1F000 or unicodedata.category(ch) == "So"

    return emoji_like(before) and emoji_like(after)


def has_soft_hyphen_or_zero_width(data: bytes) -> bool:
    """Whether the raw bytes carry an invisible character that is NOT emoji glue.

    Example:
        >>> has_soft_hyphen_or_zero_width(b"soft\\xc2\\xadhyphen")
        True
        >>> has_soft_hyphen_or_zero_width(b"plain ascii")
        False
    """
    if SOFT_HYPHEN_UTF8 in data:
        return True
    if not any(marker in data for marker in ZERO_WIDTH_MARKERS_UTF8):
        return False
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return True   # undecodable AND carrying a marker: report, never absolve
    return any(
        ch in _ZERO_WIDTH_CHARS
        and not (ch == "‍" and _zwj_is_emoji_glue(text, i))
        for i, ch in enumerate(text)
    )


@functools.lru_cache(maxsize=8)
def _load_corpus_exempt_prefixes(root: Path) -> tuple[str, ...]:
    """Project-local, opt-in mojibake exemptions (never a code-wide default).

    Read from ``<root>/.simplecode/corpus_exempt.yaml``, key
    ``corruption_guard_prefixes``. Absent file -> no exemptions, so every
    project (including this one) keeps sc's shared default untouched. A
    satellite carrying genuine, already-diagnosed-irrecoverable corpus
    corruption (e.g. scraped web content) opts in explicitly in its own
    tracked config instead of the shared guard being edited to carry one
    satellite's debt for the whole fleet -- exactly what happened to this
    function on 2026-08-24 (reverted; see git history) before this opt-in
    mechanism replaced it.
    """
    config = root / ".simplecode" / "corpus_exempt.yaml"
    if not config.is_file():
        return ()
    try:
        data = yaml.safe_load(config.read_text(encoding="utf-8")) or {}
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return ()
    if not isinstance(data, dict):
        return ()
    prefixes = data.get("corruption_guard_prefixes", [])
    if not isinstance(prefixes, list):
        return ()
    return tuple(str(p) for p in prefixes if str(p).strip())


def _is_exempt_corpus_char_file(p: Path) -> bool:
    posix = p.as_posix()
    if ("tests/fixtures/" in posix or "fixtures/" in posix
            or posix.startswith("tests/") or "/tests/" in posix
            or posix.endswith("src/simplecode/guards/agent_threats.py")
            or posix.endswith("guards/agent_threats.py")
            or posix.endswith("src/simplecode/guards/corruption_guard.py")
            or posix.endswith("guards/corruption_guard.py")):
        return True
    return any(prefix in posix for prefix in _load_corpus_exempt_prefixes(Path.cwd()))


logger = logging.getLogger("corruption_guard")

# Files whose soft-hyphen / zero-width finding `corruption_guard_exempt_prefixes`
# suppressed in the current `scan()`, for the NOT EXAMINED line in `main`.
# Per thread, not per process: backlog_verifier calls `scan()` from the workers of its
# thread pool (`_verify_corruption_finding`), and the process-wide list that stood here
# was cleared by whichever scan started last (ponytail trigger exercised 2026-10-07).
_exempted_by_thread = threading.local()


def _zero_width_exempted() -> list[str]:
    return _exempted_by_thread.__dict__.setdefault("paths", [])


@functools.lru_cache(maxsize=8)
def _load_exempt_prefixes(root: Path) -> tuple[str, ...]:
    return _load_corpus_exempt_list(root, "corruption_guard_exempt_prefixes")


def _zero_width_exempt_prefix(path: Path) -> str | None:
    """The `corruption_guard_exempt_prefixes` entry covering `path`, if any."""
    rel = Path(os.path.relpath(path)).as_posix()
    return next((p for p in _load_exempt_prefixes(Path.cwd()) if rel.startswith(p.removeprefix("./"))), None)


def _check_raw_byte_corruptions(path: Path, data: bytes) -> list[str]:
    findings: list[str] = []
    if has_bom(data):
        findings.append(
            f"{path}:1: UTF-8 byte-order mark (BOM) detected — "
            "encoding corruption; restore from git or strip the BOM"
        )
    if has_crlf(data):
        findings.append(
            f"{path}:1: CRLF line endings detected — "
            "encoding corruption; restore from git or normalize to LF"
        )
    if not _is_exempt_corpus_char_file(path) and has_soft_hyphen_or_zero_width(data):
        matched = _zero_width_exempt_prefix(path)
        if matched is None:
            findings.append(
                f"{path}:1: soft hyphen or zero-width character detected — "
                "encoding corruption; restore from git"
            )
        else:
            logger.info(
                "Soft hyphen / zero-width exempt by corruption_guard_exempt_prefixes "
                "%r in .simplecode/corpus_exempt.yaml: %s", matched, path,
            )
            if str(path) not in _zero_width_exempted():  # the stable re-read judges twice
                _zero_width_exempted().append(str(path))
    return findings


def _scan_text_file(path: Path, data: bytes) -> list[str]:
    """Return findings for one text file."""
    if b"\x00" in data:
        line = _first_nul_line(data)
        count = data.count(b"\x00")
        return [
            f"{path}:{line}: NUL byte(s) in text file "
            f"({count} total) — corruption; restore from git "
            f"(`git checkout HEAD -- {path}`)"
        ]

    findings = _check_raw_byte_corruptions(path, data)

    if _is_special_corruption_target(path) and data and not data.endswith(b"\n"):
        line = data.count(b"\n") + 1
        findings.append(
            f"{path}:{line}: missing trailing newline "
            "(possible truncation) — restore from git"
        )
        return findings

    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        findings.append(
            f"{path}:1: invalid UTF-8 "
            f"({exc.reason}) — corruption; restore from git"
        )
        return findings

    if path.suffix.lower() == ".py":
        try:
            ast.parse(text, filename=str(path))
        except SyntaxError as exc:
            findings.append(
                f"{path}:{exc.lineno or 1}: does not parse "
                f"({exc.msg}) — likely corruption/truncation; "
                f"restore from git"
            )

    if not _is_exempt_corpus_char_file(path):
        for line_no, snippet in _find_mojibake_lines(text):
            findings.append(
                f"{path}:{line_no}: mojibake detected ({snippet!r}) — "
                "UTF-8 text was likely re-saved through a Latin-1/CP1252 "
                "round-trip; restore from git"
            )

    return findings


def _scan_unlisted_file(path: Path, data: bytes) -> list[str]:
    """Findings for a text file outside `TEXT_SUFFIXES` (see `_looks_like_text`).

    Keeps the classes that are damage in any format -- NUL padding and mojibake
    -- and drops the ones that are a convention elsewhere. Measured over the
    fleet 2026-09-27 on files this reach adds: CRLF/BOM are native to `.ps1`,
    `.rtf`, `.aspx`/`.vb` and Windows `.log` captures (cuenza alone: 101 BOM),
    and the invisible-character check fired mostly on the Excel idiom
    `'\\ufeff' + csv` in JavaScript. CRLF/BOM stay checked where they break
    execution: a shebang or a shell suffix. A single trailing NUL is the
    terminator WordPad/RichEdit writes after an RTF (3 samples in
    office2office), not padding, and is not reported.
    """
    if data.endswith(b"\x00") and data.count(b"\x00") == 1:
        data = data[:-1]
    dropped = {"soft-hyphen/zero-width"}
    if not (data.removeprefix(UTF8_BOM).startswith(b"#!")
            or path.suffix.lower() in LF_REQUIRED_SUFFIXES):
        dropped |= {"CRLF", "BOM"}
    return [f for f in _scan_text_file(path, data) if _finding_class(f) not in dropped]


def lineas_anadidas(paths: list[Path]) -> dict[str, set[int] | None]:
    """Números de línea que el commit AÑADE o MODIFICA, por archivo.

    `None` significa «todo el archivo»: es lo que corresponde a un archivo nuevo,
    donde cada línea es diff, y también a cualquier caso en que git no pueda
    responder -- por defecto se mira entero, nunca menos.
    """
    mapa: dict[str, set[int] | None] = {}
    if not paths:
        return mapa
    # git responde con rutas relativas a la raíz del repo, y quien llama tiene
    # rutas absolutas. Sin resolver esa diferencia el mapa nunca casa, el
    # alcance sale None para todo, y el recorte no recorta nada -- que fue
    # exactamente lo que la batería atrapó al escribirla.
    base = pathlib.Path(paths[0]).resolve().parent
    try:
        top = subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=base,
                             capture_output=True, text=True, timeout=GIT_O1_TIMEOUT)
        raiz = pathlib.Path(top.stdout.strip()) if top.returncode == 0 else base
        # El coste de `git diff --cached -U0` escala con el tamaño del payload
        # staged, y ESE tamaño es medible antes de la llamada: son los mismos
        # ficheros que ya están en disco (staged == working tree para los
        # ficheros de texto que este guard mira). Sumar sus bytes en disco es
        # una medida honesta, no una tarifa fija disfrazada de "proporcional".
        payload_bytes = sum(
            pathlib.Path(p).stat().st_size
            for p in paths
            if pathlib.Path(p).is_file()
        )
        diff_timeout = compute_proportional_timeout(
            payload_bytes, base_timeout_sec=DIFF_TIMEOUT_BASE
        )
        salida = subprocess.run(
            ["git", "diff", "--cached", "-U0", "--", *[str(p) for p in paths]],
            cwd=raiz, capture_output=True, text=True,
            encoding="utf-8", errors="ignore", timeout=diff_timeout,
        )
    except (OSError, subprocess.SubprocessError):
        return mapa
    if salida.returncode != 0:
        return mapa
    actual: str | None = None
    for linea in salida.stdout.splitlines():
        if linea.startswith("+++ b/"):
            actual = str((raiz / linea[6:]).resolve())
            mapa.setdefault(actual, set())
        elif linea.startswith("+++ /dev/null"):
            actual = None
        elif linea.startswith("@@") and actual is not None:
            try:
                nuevo = linea.split("+", 1)[1].split(" ", 1)[0]
                inicio, _, cuantas = nuevo.partition(",")
                inicio_i = int(inicio)
                n = int(cuantas) if cuantas else 1
            except (ValueError, IndexError):
                mapa[actual] = None
                continue
            destino = mapa.get(actual)
            if destino is not None:
                destino.update(range(inicio_i, inicio_i + n))
    return mapa


_HEAD_BYTES = 64 * 1024


def _head_says_binary(path: Path) -> bool:
    """Whether the first `_HEAD_BYTES` already settle `_looks_like_text` as False.

    A UTF-16/32 BOM or a binary control byte anywhere in the file makes
    `_looks_like_text` False, so finding one in the head gives the same verdict
    without reading a multi-hundred-MB binary whole. The head is never used to
    say "text": UTF-8 validity and an all-NUL head still need the whole file.
    """
    with path.open("rb") as fh:
        head = fh.read(_HEAD_BYTES)
    if head.startswith((b"\xff\xfe", b"\xfe\xff")):
        return True
    body = head.replace(b"\x00", b"")
    return len(body.translate(None, _BINARY_CONTROLS)) != len(body)


def _read_subject(path: Path, listed: bool) -> bytes | None:
    """The bytes to judge, or None when an unlisted file is binary (not a subject)."""
    if not listed and _head_says_binary(path):
        return None
    data = path.read_bytes()
    if not listed and not _looks_like_text(data):
        return None
    return data


def _read_bytes_stable(path: Path, attempts: int = 4, delay: float = 0.05) -> bytes:
    """Read `path`, retrying until two consecutive reads agree.

    A non-atomic writer (truncate-then-write, no temp+rename) can leave a
    reader looking at a half-written file -- confirmed live against Atlas's
    liberation_watchdog reeval_referencia jobs, which is what kept flagging
    DEBT-BYTE-CORRUPTION as still reproducing (2026-08-29). Two matching reads
    means the file was quiescent when read; that's the cheapest proxy for "not
    mid-write" without adding any coordination with the writer.
    """
    previous = path.read_bytes()
    for _ in range(attempts - 1):
        time.sleep(delay)  # blocking-sleep: bounded stabilization retry, not a poll -- DEBT-CORRUPTION-GUARD-01
        current = path.read_bytes()
        if current == previous:
            return current
        previous = current
    return previous


def scan(paths: list[Path], solo_lineas: dict[str, set[int] | None] | None = None) -> list[str]:
    findings: list[str] = []
    _zero_width_exempted().clear()
    for path in paths:
        is_special = _is_special_corruption_target(path)
        if not is_special and (SKIP_DIRS & set(path.parts) or not path.is_file()):
            continue
        listed = is_special or path.suffix.lower() in TEXT_SUFFIXES
        try:
            data = _read_subject(path, listed)
        except OSError as exc:  # unreadable file is itself a finding
            findings.append(f"{path}:1: cannot read ({exc})")
            continue
        if data is None:
            continue
        judge = _scan_text_file if listed else _scan_unlisted_file
        hallazgos = judge(path, data)
        # Sólo un archivo CON hallazgos se re-lee estabilizado: un lector que
        # cayó a mitad de un truncate-then-write puede fabricar un falso
        # positivo, y ése es el único daño que la doble lectura previene. Pagar
        # el sleep de la estabilización en cada archivo quieto puso un piso de
        # 0.05s x N al gate entero -- medido 2026-08-29: 36.9s de reloj con
        # 0.5s de CPU sobre 719 archivos aquí, y 7,881 archivos en Atlas
        # (~394s), que es el "cuelgue" que paró sus commits.
        if hallazgos:
            try:
                stable = _read_bytes_stable(path)
            except OSError as exc:
                findings.append(f"{path}:1: cannot read ({exc})")
                continue
            if stable != data:
                hallazgos = judge(path, stable)
        # El alcance sólo recorta MOJIBAKE. UTF-8 inválido, NUL, BOM y sintaxis
        # rota son hechos del archivo entero y siguen mirándose enteros.
        #
        # Por qué el recorte: en un gate de pre-commit se juzga lo que se está
        # commiteando. Medido el 2026-08-17: 58 documentos de la flota llevan
        # una línea con mojibake -- 50 en Atlas y CUATRO en el propio kit-- y
        # cualquier commit que tocara cualquier OTRA línea de esos archivos
        # quedaba detenido por una línea que el autor no escribió. En
        # `aequitas_os/docs/jurisprudencia/AEQUITAS_JURISPRUDENCE_WORKFLOW.md`
        # esa línea además es un EJEMPLO: cita la corrupción para explicar qué
        # repara un paso de limpieza de PDF.
        #
        # Ley 37: un archivo nuevo es todo diff, y ahí `permitidas` vale None,
        # que significa mirarlo entero. Ante la duda, entero.
        if solo_lineas is not None:
            clave = str(path)
            permitidas = solo_lineas.get(clave, solo_lineas.get(str(path.resolve())))
            if permitidas is not None:
                hallazgos = [
                    h for h in hallazgos
                    if "mojibake detected" not in h
                    or _numero_de_linea(h, clave) in permitidas
                ]
        findings.extend(hallazgos)
    return findings


def _numero_de_linea(hallazgo: str, prefijo: str) -> int:
    """El número de línea de un hallazgo `ruta:N: ...`, o -1 si no se lee."""
    resto = hallazgo[len(prefijo) + 1:] if hallazgo.startswith(prefijo + ":") else hallazgo
    cabeza = resto.split(":", 1)[0]
    try:
        return int(cabeza)
    except ValueError:
        return -1


def _staged_files() -> list[Path]:
    """Files THIS commit is introducing -- the only subject a pre-commit gate has.

    Reuses `git_diff_name_only(cached=True)` rather than a second way of asking
    git the same question. Staged content equals the working tree for these
    paths at pre-commit time, so reading them from disk is reading what is being
    committed.

    git answers relative to the repo ROOT; the files are opened from the cwd.
    Anchoring on the toplevel (DEBT-GIT-PATHS-NOT-ANCHORED-TO-ROOT) keeps a run
    from a subdirectory from resolving every path to a file that does not exist
    and scanning zero of them; `relpath` keeps the root-run output unchanged.
    """
    top = repo_toplevel() or Path(".")
    paths = [Path(os.path.relpath(top / rel)) for rel in git_diff_name_only(cached=True)]
    return [p for p in paths if p.is_file()]


def _finding_class(line: str) -> str:
    """Short corruption class for a `scan()` finding line, for the tagged summary."""
    if "NUL byte(s)" in line:
        return "NUL bytes"
    if "byte-order mark (BOM)" in line:
        return "BOM"
    if "CRLF line endings" in line:
        return "CRLF"
    if "soft hyphen or zero-width" in line:
        return "soft-hyphen/zero-width"
    if "invalid UTF-8" in line:
        return "invalid UTF-8"
    if "does not parse" in line:
        return "syntax"
    if "mojibake detected" in line:
        return "mojibake"
    if "missing trailing newline" in line:
        return "truncation"
    return "corruption"


def _report_staged_entry_modes() -> tuple[list, int]:
    """Judge staged symlink modes as part of the existing corruption gate."""
    from simplecode.guards.staged_mode_guard import GitUnavailable, analyze

    try:
        mode_findings, _mode_notes, examined = analyze(Path.cwd())
    except GitUnavailable as exc:
        print(f"[corruption-guard] COULD_NOT_RUN staged entry modes: {exc}", file=sys.stderr)
        return [], 2
    print(
        f"[corruption-guard] staged entry modes examined: {examined}; "
        f"findings: {len(mode_findings)}"
    )
    return mode_findings, 0


def _explicit_targets(argv: list[str]) -> list[Path] | None:
    desconocidos = [arg for arg in argv if arg.startswith("-")]
    if not desconocidos:
        return [Path(arg) for arg in argv]
    print(
        f"CORRUPTION GUARD: COULD NOT RUN -- unknown option(s) "
        f"{desconocidos}. This gate takes file paths or `--staged`, and "
        f"nothing else; it does NOT take --root/--gate like the other "
        f"organs. Treating them as paths would scan {len(desconocidos)} "
        f"file(s) that do not exist and report OK.",
        file=sys.stderr,
    )
    print(
        f"[corruption-guard] COULD_NOT_RUN: unknown option(s) {desconocidos}; "
        f"this gate takes file paths or --staged only",
        file=sys.stderr,
    )
    return None


def _resolve_targets(argv: list[str]) -> tuple[list[Path] | None, list, int]:
    staged = bool(argv and argv[0] == "--staged")
    if staged:
        targets = _staged_files() + _special_files()
    elif argv:
        targets = _explicit_targets(argv)
        if targets is None:
            return None, [], 2
    else:
        try:
            targets = _tracked_files() + _special_files()
        except OSError as exc:
            print(f"[corruption-guard] COULD_NOT_RUN filesystem walk: {exc}", file=sys.stderr)
            return None, [], 2
    mode_findings = []
    if staged:
        mode_findings, rc = _report_staged_entry_modes()
        if rc:
            return None, [], rc
    return targets, mode_findings, 0


def main(argv: list[str]) -> int:
    """Scan for corruption. Explicit paths > `--staged` > every tracked file.

    `--staged` exists because the repo-wide default made this gate judge the
    repo's ACCUMULATED debt instead of what a commit introduces. Reported by two
    Atlas sessions 2026-09-01, after `.jsonl` widened the reach: `pass_filenames:
    false` means the hook passes no paths, so one already-committed corrupt
    ledger froze EVERY commit in that repo -- including commits touching none of
    it, and including debt with an open ticket and a deliberate decision not to
    repair it blind (Atlas DGX-343). The corruption was verified already in HEAD
    (`git status --porcelain` empty, `git show HEAD:<f>` carrying the same 2,191
    NUL bytes), so no commit was introducing it.

    That also explains the two different verdicts they measured minutes apart on
    an unchanged repo: with a file staged, pre-commit passes argv and the scan is
    scoped to it; with nothing staged, argv is empty and it swept everything.

    The repo-wide sweep is NOT deleted -- it stays the default for `make` and
    manual runs, where finding old debt is the point. What changes is that
    finding it no longer blocks work that did not cause it. Named honestly: with
    the pre-commit hook on `--staged`, pre-existing corruption is reported, not
    gated. A gate that blocks on what is already merged cannot tell "this commit
    introduces corruption" from "this repo has old debt", and only the first is
    a pre-commit gate's job.
    """
    # An unknown flag is an ERROR, not a path. Reported by the
    # agente_inmobiliario session 2026-09-05: a ficha had carried
    # `corruption_guard --root . --gate` as its close_check since August.
    # Every other organ in the kit takes --root/--gate, so the mistake is
    # predictable rather than exotic -- and the flags became three nonexistent
    # paths. `_resolve_targets` preserves the explicit COULD_NOT_RUN result.
    targets, mode_findings, target_rc = _resolve_targets(argv)
    if target_rc:
        return target_rc
    assert targets is not None

    # Under --staged, mojibake is judged only on the lines this commit adds or
    # modifies (DEBT-CORRUPTION-GUARD-MOJIBAKE-WHOLE-FILE-FP): `scan` already
    # knew how to filter by `solo_lineas`, but this branch never passed it, so an
    # untouched line elsewhere in the file blocked every commit to it. NUL, CRLF,
    # BOM and invisibles are still judged on the whole file.
    solo = lineas_anadidas(targets) if argv and argv[0] == "--staged" else None
    findings = scan(targets, solo_lineas=solo)
    cnr = [f for f in findings if ": cannot read (" in f]
    real = [f for f in findings if f not in cnr]
    real.extend(finding.render() for finding in mode_findings)

    exempted = _zero_width_exempted()
    if exempted:
        print(
            f"[corruption-guard] NOT EXAMINED -- {len(exempted)} file(s) had the "
            f"soft-hyphen/zero-width check suppressed by corruption_guard_exempt_prefixes in "
            f".simplecode/corpus_exempt.yaml (first: {exempted[0]}). A clean "
            f"verdict below says NOTHING about that class in them."
        )

    if cnr:
        print(
            f"[corruption-guard] COULD_NOT_RUN: {len(cnr)} fichero(s) ilegible(s) "
            f"durante el escaneo; primero {cnr[0]}",
            file=sys.stderr,
        )

    if real:
        print("CORRUPTION GUARD: FAIL", file=sys.stderr)
        for line in real:
            print(f"  {line}", file=sys.stderr)
        print(f"\n{len(real)} corrupted file(s).", file=sys.stderr)
        print(
            f"[corruption-guard] FAIL: {len(real)} fichero(s) con corrupcion "
            f"({_finding_class(real[0])}); primero {real[0]}",
            file=sys.stderr,
        )
        emit_hallazgos("[corruption-guard]", len(real))
        return 1
    if cnr:
        return 1
    print(f"CORRUPTION GUARD: OK ({len(targets)} files scanned)")
    emit_hallazgos("[corruption-guard]", 0)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
