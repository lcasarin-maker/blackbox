# -*- coding: utf-8 -*-
"""multilang_detectors.py -- one real detector per non-Python language, on
purpose no more (DEBT-KIT-CANNOT-ANALYSE-{CSHARP,JAVASCRIPT,RUST,TYPESCRIPT}).

Every semantic detector in this kit parses Python with `ast`; a satellite
whose product is C#, JavaScript, Rust or TypeScript got the same green from
every Python-typed gate regardless of what its own code did, because absence
of a subject and absence of defects produce the same "0 findings" (measured
across the fleet 2026-09-05, see `subject_survey.py`'s own docstring).

These tickets are explicit about what they do NOT ask for: full parity with
`pattern_detectors.py`, a real parser, or AST-level precision. "Un solo
detector que abra <lang> y condene una clase real ya cambia el veredicto."
Each function here is a single regex-based check for one well-known,
real vice in that language -- not a parser, and not pretending to be one.

WHAT THIS DOES NOT DO, stated rather than discovered later: it is not wired
into `zero_debt`'s pipeline, `.pre-commit-config.yaml`, or `satellite_sync`'s
template -- that is a fleet-wide wiring decision (a new hook reaching 20
satellites) separate from "does a real organ exist that can read this
language at all", which is what `subject_survey.ANALYSABLE` gates on and what
this module answers. A regex over source text can be defeated by anything a
real parser would not miss (a vice string inside a comment or a string
literal); each function is documented with that exact limit, not silently.
"""
from __future__ import annotations

import re

# Shared C-family empty-catch shape: `catch`, an optional typed/named
# parameter list, then a body containing only whitespace/comments before the
# closing brace. Deliberately simple (no brace-depth counting) -- it convicts
# the textbook case (`catch (Exception e) {}`, `catch (e) {}`) and does not
# claim to convict a catch block containing only a line comment before `}`,
# which requires tracking nesting a regex cannot do honestly.
_EMPTY_CATCH_RE = re.compile(r"catch\s*(?:\([^)]*\))?\s*\{\s*\}")

# Rust's well-known panic-on-error anti-pattern: `.unwrap()` on a Result/Option
# instead of handling the error. Real vice, real fleet subject (RePic, 10,486
# lines) -- not exhaustive: `.expect("...")` and `?` are equally real
# concerns this function does not claim to cover.
_RUST_UNWRAP_RE = re.compile(r"\.unwrap\(\)")


def csharp_empty_catch(code: str) -> bool:
    """A `catch` block with nothing in it -- the C# shape of a silent swallow.

    LIMIT, stated: a regex over raw text, not a C# parser. A vice string
    appearing inside a `//` comment or a string literal is indistinguishable
    from real code to this function; `pattern_detectors.py`'s Python
    detectors have this same limit for anything outside what `ast` sees, and
    this module inherits it rather than pretending a second parser exists.
    """
    return bool(_EMPTY_CATCH_RE.search(code))


def javascript_empty_catch(code: str) -> bool:
    """The JavaScript/TypeScript shape of the same vice as :func:`csharp_empty_catch`."""
    return bool(_EMPTY_CATCH_RE.search(code))


def typescript_empty_catch(code: str) -> bool:
    """TypeScript shares JavaScript's `catch` syntax; same check, own name so
    each language's ticket has its own function to point at."""
    return bool(_EMPTY_CATCH_RE.search(code))


def rust_unwrap_call(code: str) -> bool:
    """A bare `.unwrap()` call -- panics the whole process on an Err/None
    instead of handling it. LIMIT: a regex, not a Rust parser; `.unwrap()`
    appearing inside a comment or string literal reads the same as real code."""
    return bool(_RUST_UNWRAP_RE.search(code))
