#!/usr/bin/env python3
"""upstream_watch.py -- fork&own upstream watch (ADR-0009). Detects, never absorbs.

Compares every entry of the project's fork&own manifest against its upstream
GitHub HEAD via a `gh api` subprocess. The manifest is read from the first of
MANIFEST_CANONICAL, MANIFEST_FALLBACK (this module's own JSON shape), or
MANIFEST_YAML (own_chats's YAML shape, see `load_manifest`) that exists on
disk -- added 2026-09-05 (DEBT-UPSTREAM-CHECK-DOS-ORGANOS-UNO-CIEGO) after a
satellite with a real, current manifest in the third shape was silently
reported as having "nothing to watch", rc=0, identical to a project with
nothing forked at all. Movement is a REVIEW SUGGESTION: with
``--materialize`` it becomes one backlog task per moved repo whose OFFLINE
``--verify-reviewed`` gate stays red until a human harvests (clean-room) or
declines with rationale and bumps the manifest ``ref`` themselves. This module
never writes any manifest -- the harvested ancestor
(Atlas ``tools/check_upstream_updates.py``) auto-bumped the ref on detection,
which marked unreviewed upstream code as reviewed; that defect is the one
thing deliberately NOT harvested (ADR-0009).

Report-only on the network path: exit 0 in every case except a real
instrument failure (2 = COULD_NOT_RUN: gh missing or timed out, unauthenticated,
rate-limited or HTTP 403/429, or the upstream never answered -- network
unreachable, HTTP 5xx). Only a failure whose text matches none of those stays
COULD_NOT_CHECK, rc 0.
Never wired into a commit/push hook. ``--verify-reviewed`` is pure file reads.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import quote

import yaml

from simplecode.guards.upstream_quarantine import harvest_paths, touches_subpath
from simplecode.utils import atomic_io
from simplecode.utils.tool_limits import NETWORK_TIMEOUT
from simplecode.verification.finding_backlog import prune_finding, write_findings

MANIFEST_CANONICAL = Path(".simplecode") / "fork_own.json"
# Atlas's pre-existing registry location, readable so Atlas participates in a
# fleet sweep without being written to (it is write-frozen); never written.
MANIFEST_FALLBACK = Path("docs") / "fork_own_manifest.json"
# own_chats's shape (measured 2026-09-05, DEBT-UPSTREAM-CHECK-DOS-ORGANOS-UNO-CIEGO):
# a satellite that vendors whole upstream repos under vendor/<name>, tracked in
# YAML with {path, repo: <URL>, license, reviewed_head, reviewed_date} instead of
# this module's {repo: "owner/name", ref, licencia}. Before this candidate existed,
# a project keeping ONLY this file made `load_manifest` return ([], None) same as
# a project with nothing forked at all -- "no manifest here" and "nothing to
# review" shared one rc=0 door. Census 2026-09-05 across ~/projects (5 repos on
# MANIFEST_CANONICAL, 1 on MANIFEST_FALLBACK, 1 on this shape): both JSON and this
# YAML shape are live, so this is read IN ADDITION to the JSON candidates, never
# instead of them.
MANIFEST_YAML = Path("vendor") / "UPSTREAM.yaml"
STATE_FILE = Path(".simplecode") / "upstream_watch_state.json"
FROZEN_MARKER = Path(".simplecode") / "WRITE_FROZEN"
FROZEN_ENV = "SIMPLECODE_WRITE_FROZEN"
# The GitHub compare API caps its `files` list at 300 and turns huge ranges
# into summaries; past either cap the compare's file list cannot prove
# "untouched", so `_classify_movement` asks the path-scoped commits endpoint
# (no cap) instead, and falls OPEN (MOVED) when that query cannot answer.
COMPARE_FILES_CAP = 300
COMPARE_COMMITS_CAP = 250
SCOPED_PAGE = 100  # per_page of the path-scoped commits query (GitHub max)
# Sentinel recorded as observed_head when upstream 404s: the review action for
# a vanished upstream is editing the manifest (drop the cosecha, or set its
# ref to this sentinel to acknowledge), which is what --verify-reviewed reads.
GONE_SENTINEL = "GONE"


def _github_slug(repo_url: str) -> str | None:
    """'https://github.com/owner/name(.git)?' -> 'owner/name'; None otherwise.

    `check_entry` calls `gh api repos/{repo}/...`, which needs the short slug;
    own_chats's vendor/UPSTREAM.yaml records the full clone URL instead.
    """
    if "github.com/" not in repo_url:
        return None
    tail = repo_url.split("github.com/", 1)[1].strip("/")
    if tail.endswith(".git"):
        tail = tail[:-4]
    parts = [p for p in tail.split("/") if p]
    return "/".join(parts[:2]) if len(parts) >= 2 else None


def _cosecha_from_upstream_yaml(entry: object) -> dict | None:
    """One vendor/UPSTREAM.yaml `upstreams[]` row -> this module's cosecha shape.

    Deliberately drops the YAML entry's `path`: there it names the LOCAL
    destination (e.g. "vendor/mychatarchive", a whole-repo vendor drop), while
    this module's `path` (a string or a list) names SUBDIRECTORIES INSIDE THE
    UPSTREAM repo used to filter a monorepo compare's file list (see
    `_classify_movement`). Carrying the local path across would make every
    real upstream file fail that `touches_subpath` filter -- a moved repo silently reclassified as
    MOVED_OUTSIDE_HARVEST, the exact class of blind instrument this fixes.
    """
    if not isinstance(entry, dict):
        return None
    slug = _github_slug(str(entry.get("repo") or ""))
    ref = entry.get("reviewed_head")
    if not slug or not ref:
        return None
    return {"repo": slug, "ref": ref, "licencia": entry.get("license")}


def load_manifest(root: Path) -> tuple[list[dict], Path | None]:
    """The project's cosechas and the file they came from; ([], None) if none.

    Malformed JSON/YAML or an unexpected shape yields ([], None), mirroring the
    tolerance of `zero_debt._load_corpus_exempt_list`: an absent registry is a
    project with nothing forked, never an error.

    Tries, in order: MANIFEST_CANONICAL, MANIFEST_FALLBACK (both this module's
    own JSON shape), then MANIFEST_YAML (own_chats's shape, translated by
    `_cosecha_from_upstream_yaml`). The first candidate that exists on disk
    wins, whether or not it parses -- a broken canonical manifest must not
    silently fall through to a stale YAML one.
    """
    for candidate in (root / MANIFEST_CANONICAL, root / MANIFEST_FALLBACK):
        if not candidate.is_file():
            continue
        try:
            data = json.loads(candidate.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, ValueError):
            return [], None
        if not isinstance(data, dict) or not isinstance(data.get("cosechas"), list):
            return [], None
        cosechas = [c for c in data["cosechas"] if isinstance(c, dict)]
        return cosechas, candidate
    yaml_candidate = root / MANIFEST_YAML
    if yaml_candidate.is_file():
        try:
            data = yaml.safe_load(yaml_candidate.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, yaml.YAMLError):
            return [], None
        if not isinstance(data, dict) or not isinstance(data.get("upstreams"), list):
            return [], None
        cosechas = [c for e in data["upstreams"]
                   if (c := _cosecha_from_upstream_yaml(e)) is not None]
        return cosechas, yaml_candidate
    return [], None


def is_write_frozen(root: Path, env: dict[str, str]) -> bool:
    """Whether `root` refuses fleet writes (marker file or env list, ADR-0009)."""
    if (root / FROZEN_MARKER).is_file():
        return True
    frozen = {name.strip() for name in env.get(FROZEN_ENV, "").split(",") if name.strip()}
    return root.resolve().name in frozen


def _run_gh(args: list[str]) -> subprocess.CompletedProcess[str] | None:
    """One `gh api` call; None means the instrument itself is unavailable."""
    try:
        return subprocess.run(
            ["gh", "api", *args],
            capture_output=True, text=True, timeout=NETWORK_TIMEOUT, check=False,
        )
    except (subprocess.SubprocessError, OSError):
        return None


# What gh and Go's net stack print when the request never got an HTTP answer.
# Measured 2026-10-06 with real gh 2.45.0 inside `unshare -rn`:
# "error connecting to api.github.com\ncheck your internet connection ...".
_UNREACHED_PHRASES = ("error connecting to", "dial tcp", "no such host", "connection refused",
                      "connection reset", "network is unreachable", "timeout", "deadline exceeded",
                      "host not found", "name resolution")


def _classify_gh_error(stderr: str) -> str:
    """'not_found' | 'rate_limit' | 'auth' | 'unreached' | 'other' from gh's stderr.

    The HTTP status code is the one thing the upstream actually said, so every
    code is tested before any phrase: a 403 whose text also contains "not found"
    is a refusal, never a vanished upstream (it was UPSTREAM_GONE, rc 0, while
    the phrase was tested first); a code not listed here is 'other', so the
    phrases below only ever classify text that carries no code. Network phrases
    are tested before "not found" because resolvers print "host not found".
    """
    low = stderr.lower()
    return _classify_by_code(low) or _classify_by_phrase(low)


def _classify_by_code(low: str) -> str | None:
    """The classification gh's own "(HTTP NNN)" decides, or None when the text carries no code."""
    if "http 404" in low:
        return "not_found"
    if "http 403" in low or "http 429" in low:
        return "rate_limit"
    if "http 401" in low:
        return "auth"
    if re.search(r"http 5\d\d", low):
        return "unreached"
    if re.search(r"http \d{3}", low):
        return "other"  # any other code (409, 422, 451...) was an answer: its text decides nothing
    return None


def _classify_by_phrase(low: str) -> str:
    """The classification of a failure text that carries no HTTP code."""
    if re.match(r'\s*(get|post|put|patch|delete|head) "https?://', low):
        # gh prints every answer GitHub gave as "(HTTP NNN)"; Go's url.Error form
        # without one ('Get "https://api.github.com/...": unexpected EOF', behind a
        # proxy 'Bad Gateway') is a request that never got an answer.
        return "unreached"
    if "rate limit" in low:
        return "rate_limit"
    if "gh auth login" in low or "authentication" in low:
        return "auth"
    if any(phrase in low for phrase in _UNREACHED_PHRASES):
        return "unreached"
    if "not found" in low:
        return "not_found"
    return "other"


def check_entry(entry: dict) -> dict:
    """One cosecha against its upstream. Returns {repo, status, ...}; never writes."""
    repo, ref = entry.get("repo"), entry.get("ref")
    if not (isinstance(repo, str) and isinstance(ref, str) and repo and ref):
        return {"repo": repo if isinstance(repo, str) and repo else "?",
                "status": "MALFORMED_ENTRY",
                "detail": "cosecha lacks repo or ref"}
    head = _run_gh([f"repos/{repo}/commits/HEAD", "--jq", ".sha"])
    if head is None:
        return {"repo": repo, "status": "COULD_NOT_RUN", "detail": "gh unavailable"}
    if head.returncode != 0 or not head.stdout.strip():
        kind = _classify_gh_error(head.stderr)
        if kind == "not_found":
            return {"repo": repo, "status": "UPSTREAM_GONE",
                    "observed_head": GONE_SENTINEL,
                    "detail": "upstream 404s -- the local copy may be the only copy"}
        if kind == "auth":
            return {"repo": repo, "status": "COULD_NOT_RUN",
                    "detail": "gh is not authenticated -- run `gh auth login`"}
        if kind == "rate_limit":
            # Same family as offline and unauthenticated: the instrument never
            # reached the subject, so it knows nothing about the upstream and
            # must not let the run exit 0. It fell through to COULD_NOT_CHECK
            # (rc=0) until 2026-09-01, which made "GitHub throttled us" and
            # "everything is current" produce the same exit code -- while
            # ADR-0009 stated a rate-limited `gh api` yields rc=2. Found by an
            # adversarial panel with a planted 403 on stderr.
            return {"repo": repo, "status": "COULD_NOT_RUN",
                    "detail": f"gh api rate-limited -- upstream not reached: "
                              f"{head.stderr.strip()[:120] or 'HTTP 403/429'}"}
        if kind == "unreached":
            # Offline and a 5xx are the same family as the throttle above: no
            # verdict about the upstream came back. Measured 2026-10-06 (real gh
            # in `unshare -rn`): it exited 0 here while this module's docstring
            # and message both said offline is COULD_NOT_RUN, rc 2.
            return {"repo": repo, "status": "COULD_NOT_RUN",
                    "detail": f"upstream not reached: "
                              f"{' '.join(head.stderr.split())[:120] or 'network unreachable or HTTP 5xx'}"}
        return {"repo": repo, "status": "COULD_NOT_CHECK",
                "detail": head.stderr.strip()[:200] or "gh api failed"}
    observed = head.stdout.strip()
    if observed == ref:
        return {"repo": repo, "status": "UP_TO_DATE", "observed_head": observed}
    return _classify_movement(entry, repo, ref, observed)


def _classify_movement(entry: dict, repo: str, ref: str, observed: str) -> dict:
    compare = _run_gh([
        f"repos/{repo}/compare/{ref}...{observed}", "--jq",
        '{status:.status, total_commits:.total_commits, files:[.files[].filename]}',
    ])
    if compare is None or compare.returncode != 0:
        # Old SHA unreachable (force-push / rewritten history) or any compare
        # failure: still MOVED -- a diff summary is a courtesy, not a gate.
        return {"repo": repo, "status": "HISTORY_REWRITTEN", "observed_head": observed,
                "detail": "compare unavailable (rewritten history?) -- manual review required"}
    try:
        summary = json.loads(compare.stdout)
        files = [str(f) for f in summary.get("files", [])]
        total = int(summary.get("total_commits") or 0)
    except (ValueError, TypeError):
        return {"repo": repo, "status": "HISTORY_REWRITTEN", "observed_head": observed,
                "detail": "compare output unreadable -- manual review required"}
    paths = harvest_paths(entry)
    if not paths:
        return _moved(repo, observed, total, files)
    touching = [f for f in files if any(touches_subpath(f, p) for p in paths)]
    shown = ", ".join(paths)
    if len(files) < COMPARE_FILES_CAP and total <= COMPARE_COMMITS_CAP:
        if not touching:
            return {"repo": repo, "status": "MOVED_OUTSIDE_HARVEST",
                    "observed_head": observed, "ahead_by": total,
                    "detail": f"{total} commits, none touching {shown}"}
        return _moved(repo, observed, total, touching)
    # Capped compare: its file list is a truncated sample, never proof.
    scoped = _commits_touching(repo, ref, observed, paths)
    if scoped == 0:
        return {"repo": repo, "status": "MOVED_OUTSIDE_HARVEST",
                "observed_head": observed, "ahead_by": total,
                "detail": f"{total} commits (compare capped), none touching {shown} "
                          "per the path-scoped commit query"}
    moved = _moved(repo, observed, total, touching)
    moved["detail"] += (" -- compare capped; path-scoped query: "
                        + ("unavailable, falling open" if scoped is None
                           else f"{scoped}{'+' if scoped >= SCOPED_PAGE else ''} "
                                f"commit(s) touch {shown}"))
    return moved


def _moved(repo: str, observed: str, total: int, files: list[str]) -> dict:
    return {"repo": repo, "status": "MOVED", "observed_head": observed,
            "ahead_by": total, "files_sample": files[:5],
            "detail": f"{total} commits, {len(files)} files (sample: {', '.join(files[:5])})"}


def _commits_touching(repo: str, ref: str, observed: str, paths: tuple[str, ...]) -> int | None:
    """Commits in ref..observed that touch any of `paths`; None = could not tell.

    Uses `commits?sha=<observed>&path=<p>&since=<ref committer date>`, which has
    no 300-file cap. The ref commit itself is dropped from the answer (`since`
    is inclusive, and the harvest already covers it). A full page (SCOPED_PAGE)
    is returned as-is: any non-zero count is MOVED, so no pagination is needed.
    ponytail: `since` filters on committer date, so a commit whose committer
    clock predates the ref's is missed; trigger: a MOVED_OUTSIDE_HARVEST
    verdict contradicted by a manual `git log ref..head -- path`.
    """
    when = _run_gh([f"repos/{repo}/commits/{ref}", "--jq", ".commit.committer.date"])
    if when is None or when.returncode != 0 or not when.stdout.strip():
        return None
    total = 0
    for path in paths:
        page = _run_gh([f"repos/{repo}/commits?sha={observed}&path={quote(path, safe='/')}"
                        f"&since={when.stdout.strip()}&per_page={SCOPED_PAGE}",
                        "--jq", "[.[].sha]"])
        if page is None or page.returncode != 0:
            return None
        try:
            shas = [str(s) for s in json.loads(page.stdout)]
        except (ValueError, TypeError):
            return None
        total += sum(1 for s in shas if not (s.startswith(ref) or ref.startswith(s)))
    return total


def _load_state(root: Path) -> dict:
    try:
        data = json.loads((root / STATE_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"repos": {}}
    if not isinstance(data, dict) or not isinstance(data.get("repos"), dict):
        return {"repos": {}}
    return data


def _write_state(root: Path, state: dict) -> None:
    atomic_io.write_text_durable(root / STATE_FILE, json.dumps(state, indent=2, sort_keys=True))


def review_finding(repo: str) -> str:
    """The finding text for a moved upstream. SHA-free on purpose: task_id
    hashes this text, so one repo always maps to one task file, updated in
    place by the state file rather than by rewriting the task."""
    slug = repo.replace("/", "__")
    return (f"[upstream-watch] fork&own upstream {repo} has advanced beyond the "
            "reviewed ref in the fork&own manifest -- review upstream (staged "
            f"digest, when quarantined: .simplecode/quarantine/{slug}/DIGEST.md): "
            "harvest improvements (clean-room) or decline with rationale, then bump the ref")


def _verification_command(root: Path, repo: str) -> str:
    runner = ("python .simplecode/run.py" if (root / ".simplecode" / "run.py").is_file()
              else "python -m")
    return f"{runner} simplecode.guards.upstream_watch --verify-reviewed {repo}"


def run_check(root: Path, *, materialize: bool, env: dict[str, str],
              allow_frozen_writes: bool = False,
              quarantine: bool = False) -> tuple[list[dict], int]:
    """Check every cosecha of `root`. Returns (results, rc)."""
    cosechas, manifest_path = load_manifest(root)
    if manifest_path is None:
        return [], 0
    results = [check_entry(entry) for entry in cosechas]
    for entry, result in zip(cosechas, results):
        if entry.get("licencia") == "NOASSERTION" and result.get("status") != "MALFORMED_ENTRY":
            result["license_warning"] = ("upstream declares no license -- "
                                         "clean-room only, never vendor verbatim")
    pairs = [(entry, r) for entry, r in zip(cosechas, results)
             if r["status"] not in ("COULD_NOT_RUN", "COULD_NOT_CHECK", "MALFORMED_ENTRY")]
    checked = [r for _, r in pairs]
    unverified = {entry["repo"] for entry, r in zip(cosechas, results)
                  if r not in checked and isinstance(entry.get("repo"), str)}
    # An unreached cosecha makes the run rc 2, but never discards what the others
    # measured: a moved upstream beside a 5xx one still gets its state, digest
    # and review task (it used to be dropped by an early return).
    rc = 2 if any(r["status"] == "COULD_NOT_RUN" for r in results) else 0
    frozen = is_write_frozen(root, env) and not allow_frozen_writes
    if checked and not frozen:
        groups = _group_by_repo(pairs)
        state = _load_state(root)
        now = datetime.now(UTC).isoformat(timespec="seconds")
        for repo, group in groups.items():
            worst = _worst_result([r for _, r in group])
            state["repos"][repo] = {
                "last_checked": now,
                "observed_head": worst.get("observed_head"),
                "status": worst["status"],
                "ahead_by": worst.get("ahead_by"),
            }
        _write_state(root, state)
        if quarantine:
            _quarantine(root, groups)
        if materialize:
            _materialize(root, groups, unverified)
    return results, rc


def _quarantine(root: Path, groups: dict[str, list[tuple[dict, dict]]]) -> None:
    """Stage each moved upstream's compare into quarantine (ADR-0010).

    MOVED and HISTORY_REWRITTEN both stage (the latter's digest says the
    compare is unavailable rather than pointing nowhere); UPSTREAM_GONE has
    no head to fetch, so its review stays manual by nature. A repo has one
    digest directory: with several cosechas it is staged once, from the
    widest-range cosecha among the MOVED/HISTORY_REWRITTEN ones (HISTORY_REWRITTEN
    first, then the most commits ahead, a tie to the first listed), using THAT
    cosecha's own ref and subpath.
    """
    from simplecode.guards import upstream_quarantine
    for group in groups.values():
        moved = [(e, r) for e, r in group if r["status"] in ("MOVED", "HISTORY_REWRITTEN")]
        if not moved:
            continue
        entry, widest = min(moved, key=lambda p: (_SEVERITY.index(p[1]["status"]),
                                                   -(p[1].get("ahead_by") or 0)))
        staged = upstream_quarantine.quarantine_moved(
            root, entry, widest["observed_head"], _run_gh)
        for _, r in moved:
            r["quarantine"] = staged


# Worst first. A repo with several cosechas is one review task and one state row,
# so its status is the worst of its cosechas', never whichever was checked last.
_SEVERITY = ("UPSTREAM_GONE", "HISTORY_REWRITTEN", "MOVED", "MOVED_OUTSIDE_HARVEST", "UP_TO_DATE")
_NEEDS_REVIEW = _SEVERITY[:3]


def _group_by_repo(pairs: list[tuple[dict, dict]]) -> dict[str, list[tuple[dict, dict]]]:
    groups: dict[str, list[tuple[dict, dict]]] = {}
    for entry, result in pairs:
        groups.setdefault(result["repo"], []).append((entry, result))
    return groups


def _worst_result(results: list[dict]) -> dict:
    return min(results, key=lambda r: _SEVERITY.index(r["status"]))


def _reviewed(entry: dict, result: dict) -> bool:
    """The manifest ref already equals what upstream shows: UP_TO_DATE, or an
    UPSTREAM_GONE the human acknowledged by setting the ref to the sentinel."""
    return result.get("observed_head") == entry.get("ref")


def _materialize(root: Path, groups: dict[str, list[tuple[dict, dict]]],
                 unverified: set[str]) -> None:
    """One review task per repo with an unreviewed move/gone cosecha; prune it
    once EVERY cosecha of the repo is reviewed. Anything between (an outside-
    harvest cosecha still behind) files nothing and prunes nothing. A repo with a
    cosecha this run could not verify (lookup failed, malformed entry) is never
    pruned: what was not checked is not known to be reviewed."""
    for repo, group in groups.items():
        finding = review_finding(repo)
        if any(r["status"] in _NEEDS_REVIEW and not _reviewed(e, r) for e, r in group):
            write_findings(root, [finding],
                           verification_command=_verification_command(root, repo))
        elif repo not in unverified and all(_reviewed(e, r) for e, r in group):
            prune_finding(root, finding)


def verify_reviewed(root: Path, repo: str) -> int:
    """OFFLINE gate for the review task: 1 while the review is pending.

    Pending means: the manifest still carries this repo with a ref, the state
    file recorded a different observed head, and no human has since bumped
    the ref (or dropped/acknowledged the cosecha). Pure file reads -- safe
    inside hooks and verification_command runs, never touches the network.
    """
    cosechas, _ = load_manifest(root)
    refs = [c["ref"] for c in cosechas if c.get("repo") == repo and c.get("ref") is not None]
    observed = _load_state(root)["repos"].get(repo, {}).get("observed_head")
    if not refs or observed is None:
        print(f"[upstream-watch] OK: {repo} has no pending observation")
        return 0
    behind = [ref for ref in refs if ref != observed]
    if not behind:
        print(f"[upstream-watch] OK: {repo} reviewed up to {observed[:12]}")
        return 0
    print(f"[upstream-watch] PENDING: {repo} observed {observed[:12]} but {len(behind)} of "
          f"{len(refs)} manifest ref(s) are behind (e.g. {str(behind[0])[:12]}) -- review "
          "upstream, then bump every ref")
    return 1


def _report(project: str, results: list[dict]) -> None:
    for r in results:
        line = f"  [{r['repo']}] {r['status']}"
        if r.get("detail"):
            line += f" -- {r['detail']}"
        print(line)
        if r.get("license_warning"):
            print(f"    WARNING: {r['license_warning']}")
    moved = sum(r["status"] in ("MOVED", "HISTORY_REWRITTEN", "UPSTREAM_GONE") for r in results)
    print(f"[upstream-watch] {project}: {len(results)} upstream(s), {moved} needing review")


def _run_single(root: Path, args: argparse.Namespace, env: dict[str, str],
                explicit_root: bool) -> int:
    results, rc = run_check(root, materialize=args.materialize, env=env,
                            allow_frozen_writes=explicit_root,
                            quarantine=args.quarantine)
    if args.json:
        print(json.dumps({"project": root.name, "results": results}, indent=2))
    else:
        if not results:
            # NOT a verified-clean verdict -- distinguish it from one on purpose
            # (DEBT-UPSTREAM-CHECK-DOS-ORGANOS-UNO-CIEGO). "nothing to watch"
            # here means no manifest was RECOGNIZED at any known path/shape; a
            # project can still be forking upstream in a shape this module does
            # not read yet. Never cite this line as evidence an upstream is
            # current -- that requires the per-repo UP_TO_DATE report below.
            print(f"[upstream-watch] {root.name}: no fork&own manifest recognized at "
                  f"{MANIFEST_CANONICAL}, {MANIFEST_FALLBACK}, or {MANIFEST_YAML} -- "
                  "nothing to watch (not the same as checked-and-current)")
        else:
            _report(root.name, results)
        if rc == 2:
            print("[upstream-watch] COULD NOT RUN: the upstream was not reached "
                  "(gh unavailable, unauthenticated, rate-limited, offline or HTTP 5xx)")
        if is_write_frozen(root, env) and not explicit_root and results:
            print(f"[upstream-watch] {root.name} is write-frozen: reported only, "
                  "no state or tasks written")
    return rc


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=None, help="Project root (default: cwd)")
    ap.add_argument("--fleet", type=Path, default=None, help="Check every project under DIR")
    ap.add_argument("--json", action="store_true", help="Machine-readable results")
    ap.add_argument("--materialize", action="store_true",
                    help="File one backlog review task per moved upstream repo")
    ap.add_argument("--quarantine", action="store_true",
                    help="Stage each moved upstream's compare + digest under "
                         ".simplecode/quarantine/ (ADR-0010; never adoption)")
    ap.add_argument("--verify-reviewed", metavar="OWNER/NAME", default=None,
                    help="Offline: exit 1 while OWNER/NAME's review is pending")
    args = ap.parse_args(argv)
    import os
    env = dict(os.environ)
    root = (args.root or Path.cwd()).resolve()
    if args.verify_reviewed:
        return verify_reviewed(root, args.verify_reviewed)
    if args.fleet is None:
        return _run_single(root, args, env, explicit_root=args.root is not None)
    rc = 0
    for project in sorted(p for p in args.fleet.iterdir() if p.is_dir()):
        if load_manifest(project)[1] is None:
            continue
        rc = max(rc, _run_single(project.resolve(), args, env, explicit_root=False))
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
