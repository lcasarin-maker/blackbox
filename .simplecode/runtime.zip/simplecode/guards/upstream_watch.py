#!/usr/bin/env python3
"""upstream_watch.py -- fork&own upstream watch (ADR-0009). Detects, never absorbs.

Compares every entry of the project's fork&own manifest against its upstream
GitHub HEAD via a `gh api` subprocess. The manifest is read from the first of
MANIFEST_CANONICAL, MANIFEST_FALLBACK (this module's own JSON shape), or
MANIFEST_YAML (own_chats's YAML shape, see `load_manifest`) that exists on
disk -- added 2026-09-05 (DEBT-UPSTREAM-CHECK-DOS-ORGANOS-UNO-CIEGO) after a
satellite with a real, current manifest in the third shape was silently
reported as having "nothing to watch", rc=0, identical to a project with
nothing forked at all. Movement is a REVIEW SUGGESTION: with
``--materialize`` it becomes one backlog task per moved repo whose OFFLINE
``--verify-reviewed`` gate stays red until a human harvests (clean-room) or
declines with rationale and bumps the manifest ``ref`` themselves. This module
never writes any manifest -- the harvested ancestor
(Atlas ``tools/check_upstream_updates.py``) auto-bumped the ref on detection,
which marked unreviewed upstream code as reviewed; that defect is the one
thing deliberately NOT harvested (ADR-0009).

Report-only on the network path: exit 0 in every case except a real
instrument failure (2 = COULD_NOT_RUN: gh missing, unauthenticated, offline).
Never wired into a commit/push hook. ``--verify-reviewed`` is pure file reads.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import yaml

from simplecode.utils import atomic_io
from simplecode.utils.tool_limits import NETWORK_TIMEOUT
from simplecode.verification.finding_backlog import prune_finding, write_findings

MANIFEST_CANONICAL = Path(".simplecode") / "fork_own.json"
# Atlas's pre-existing registry location, readable so Atlas participates in a
# fleet sweep without being written to (it is write-frozen); never written.
MANIFEST_FALLBACK = Path("docs") / "fork_own_manifest.json"
# own_chats's shape (measured 2026-09-05, DEBT-UPSTREAM-CHECK-DOS-ORGANOS-UNO-CIEGO):
# a satellite that vendors whole upstream repos under vendor/<name>, tracked in
# YAML with {path, repo: <URL>, license, reviewed_head, reviewed_date} instead of
# this module's {repo: "owner/name", ref, licencia}. Before this candidate existed,
# a project keeping ONLY this file made `load_manifest` return ([], None) same as
# a project with nothing forked at all -- "no manifest here" and "nothing to
# review" shared one rc=0 door. Census 2026-09-05 across ~/projects (5 repos on
# MANIFEST_CANONICAL, 1 on MANIFEST_FALLBACK, 1 on this shape): both JSON and this
# YAML shape are live, so this is read IN ADDITION to the JSON candidates, never
# instead of them.
MANIFEST_YAML = Path("vendor") / "UPSTREAM.yaml"
STATE_FILE = Path(".simplecode") / "upstream_watch_state.json"
FROZEN_MARKER = Path(".simplecode") / "WRITE_FROZEN"
FROZEN_ENV = "SIMPLECODE_WRITE_FROZEN"
# The GitHub compare API caps its `files` list at 300 and turns huge ranges
# into summaries; past either cap a subpath filter cannot prove "untouched",
# so the check falls OPEN and treats the harvest as moved.
COMPARE_FILES_CAP = 300
COMPARE_COMMITS_CAP = 250
# Sentinel recorded as observed_head when upstream 404s: the review action for
# a vanished upstream is editing the manifest (drop the cosecha, or set its
# ref to this sentinel to acknowledge), which is what --verify-reviewed reads.
GONE_SENTINEL = "GONE"


def _github_slug(repo_url: str) -> str | None:
    """'https://github.com/owner/name(.git)?' -> 'owner/name'; None otherwise.

    `check_entry` calls `gh api repos/{repo}/...`, which needs the short slug;
    own_chats's vendor/UPSTREAM.yaml records the full clone URL instead.
    """
    if "github.com/" not in repo_url:
        return None
    tail = repo_url.split("github.com/", 1)[1].strip("/")
    if tail.endswith(".git"):
        tail = tail[:-4]
    parts = [p for p in tail.split("/") if p]
    return "/".join(parts[:2]) if len(parts) >= 2 else None


def _cosecha_from_upstream_yaml(entry: object) -> dict | None:
    """One vendor/UPSTREAM.yaml `upstreams[]` row -> this module's cosecha shape.

    Deliberately drops the YAML entry's `path`: there it names the LOCAL
    destination (e.g. "vendor/mychatarchive", a whole-repo vendor drop), while
    this module's `path` names a SUBDIRECTORY INSIDE THE UPSTREAM repo used to
    filter a monorepo compare's file list (see `_classify_movement`). Carrying
    the local path across would make every real upstream file fail that
    `.startswith(subpath)` filter -- a moved repo silently reclassified as
    MOVED_OUTSIDE_HARVEST, the exact class of blind instrument this fixes.
    """
    if not isinstance(entry, dict):
        return None
    slug = _github_slug(str(entry.get("repo") or ""))
    ref = entry.get("reviewed_head")
    if not slug or not ref:
        return None
    return {"repo": slug, "ref": ref, "licencia": entry.get("license")}


def load_manifest(root: Path) -> tuple[list[dict], Path | None]:
    """The project's cosechas and the file they came from; ([], None) if none.

    Malformed JSON/YAML or an unexpected shape yields ([], None), mirroring the
    tolerance of `zero_debt._load_corpus_exempt_list`: an absent registry is a
    project with nothing forked, never an error.

    Tries, in order: MANIFEST_CANONICAL, MANIFEST_FALLBACK (both this module's
    own JSON shape), then MANIFEST_YAML (own_chats's shape, translated by
    `_cosecha_from_upstream_yaml`). The first candidate that exists on disk
    wins, whether or not it parses -- a broken canonical manifest must not
    silently fall through to a stale YAML one.
    """
    for candidate in (root / MANIFEST_CANONICAL, root / MANIFEST_FALLBACK):
        if not candidate.is_file():
            continue
        try:
            data = json.loads(candidate.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, ValueError):
            return [], None
        if not isinstance(data, dict) or not isinstance(data.get("cosechas"), list):
            return [], None
        cosechas = [c for c in data["cosechas"] if isinstance(c, dict)]
        return cosechas, candidate
    yaml_candidate = root / MANIFEST_YAML
    if yaml_candidate.is_file():
        try:
            data = yaml.safe_load(yaml_candidate.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, yaml.YAMLError):
            return [], None
        if not isinstance(data, dict) or not isinstance(data.get("upstreams"), list):
            return [], None
        cosechas = [c for e in data["upstreams"]
                   if (c := _cosecha_from_upstream_yaml(e)) is not None]
        return cosechas, yaml_candidate
    return [], None


def is_write_frozen(root: Path, env: dict[str, str]) -> bool:
    """Whether `root` refuses fleet writes (marker file or env list, ADR-0009)."""
    if (root / FROZEN_MARKER).is_file():
        return True
    frozen = {name.strip() for name in env.get(FROZEN_ENV, "").split(",") if name.strip()}
    return root.resolve().name in frozen


def _run_gh(args: list[str]) -> subprocess.CompletedProcess[str] | None:
    """One `gh api` call; None means the instrument itself is unavailable."""
    try:
        return subprocess.run(
            ["gh", "api", *args],
            capture_output=True, text=True, timeout=NETWORK_TIMEOUT, check=False,
        )
    except (subprocess.SubprocessError, OSError):
        return None


def _classify_gh_error(stderr: str) -> str:
    """'not_found' | 'rate_limit' | 'auth' | 'other' from gh's stderr."""
    low = stderr.lower()
    if "http 404" in low or "not found" in low:
        return "not_found"
    if "rate limit" in low or "http 403" in low or "http 429" in low:
        return "rate_limit"
    if "gh auth login" in low or "authentication" in low or "http 401" in low:
        return "auth"
    return "other"


def check_entry(entry: dict) -> dict:
    """One cosecha against its upstream. Returns {repo, status, ...}; never writes."""
    repo, ref = entry.get("repo"), entry.get("ref")
    if not repo or not ref:
        return {"repo": repo or "?", "status": "MALFORMED_ENTRY",
                "detail": "cosecha lacks repo or ref"}
    head = _run_gh([f"repos/{repo}/commits/HEAD", "--jq", ".sha"])
    if head is None:
        return {"repo": repo, "status": "COULD_NOT_RUN", "detail": "gh unavailable"}
    if head.returncode != 0 or not head.stdout.strip():
        kind = _classify_gh_error(head.stderr)
        if kind == "not_found":
            return {"repo": repo, "status": "UPSTREAM_GONE",
                    "observed_head": GONE_SENTINEL,
                    "detail": "upstream 404s -- the local copy may be the only copy"}
        if kind == "auth":
            return {"repo": repo, "status": "COULD_NOT_RUN",
                    "detail": "gh is not authenticated -- run `gh auth login`"}
        if kind == "rate_limit":
            # Same family as offline and unauthenticated: the instrument never
            # reached the subject, so it knows nothing about the upstream and
            # must not let the run exit 0. It fell through to COULD_NOT_CHECK
            # (rc=0) until 2026-09-01, which made "GitHub throttled us" and
            # "everything is current" produce the same exit code -- while
            # ADR-0009 stated a rate-limited `gh api` yields rc=2. Found by an
            # adversarial panel with a planted 403 on stderr.
            return {"repo": repo, "status": "COULD_NOT_RUN",
                    "detail": f"gh api rate-limited -- upstream not reached: "
                              f"{head.stderr.strip()[:120] or 'HTTP 403/429'}"}
        return {"repo": repo, "status": "COULD_NOT_CHECK",
                "detail": head.stderr.strip()[:200] or "gh api failed"}
    observed = head.stdout.strip()
    if observed == ref:
        return {"repo": repo, "status": "UP_TO_DATE", "observed_head": observed}
    return _classify_movement(entry, repo, ref, observed)


def _classify_movement(entry: dict, repo: str, ref: str, observed: str) -> dict:
    compare = _run_gh([
        f"repos/{repo}/compare/{ref}...{observed}", "--jq",
        '{status:.status, total_commits:.total_commits, files:[.files[].filename]}',
    ])
    if compare is None or compare.returncode != 0:
        # Old SHA unreachable (force-push / rewritten history) or any compare
        # failure: still MOVED -- a diff summary is a courtesy, not a gate.
        return {"repo": repo, "status": "HISTORY_REWRITTEN", "observed_head": observed,
                "detail": "compare unavailable (rewritten history?) -- manual review required"}
    try:
        summary = json.loads(compare.stdout)
        files = [str(f) for f in summary.get("files", [])]
        total = int(summary.get("total_commits") or 0)
    except (ValueError, TypeError):
        return {"repo": repo, "status": "HISTORY_REWRITTEN", "observed_head": observed,
                "detail": "compare output unreadable -- manual review required"}
    subpath = str(entry.get("path") or "")
    if subpath and len(files) < COMPARE_FILES_CAP and total <= COMPARE_COMMITS_CAP:
        touching = [f for f in files if f.startswith(subpath)]
        if not touching:
            return {"repo": repo, "status": "MOVED_OUTSIDE_HARVEST",
                    "observed_head": observed, "ahead_by": total,
                    "detail": f"{total} commits, none touching {subpath}"}
        files = touching
    return {"repo": repo, "status": "MOVED", "observed_head": observed,
            "ahead_by": total, "files_sample": files[:5],
            "detail": f"{total} commits, {len(files)} files (sample: {', '.join(files[:5])})"}


def _load_state(root: Path) -> dict:
    try:
        data = json.loads((root / STATE_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"repos": {}}
    if not isinstance(data, dict) or not isinstance(data.get("repos"), dict):
        return {"repos": {}}
    return data


def _write_state(root: Path, state: dict) -> None:
    atomic_io.write_text_durable(root / STATE_FILE, json.dumps(state, indent=2, sort_keys=True))


def review_finding(repo: str) -> str:
    """The finding text for a moved upstream. SHA-free on purpose: task_id
    hashes this text, so one repo always maps to one task file, updated in
    place by the state file rather than by rewriting the task."""
    slug = repo.replace("/", "__")
    return (f"[upstream-watch] fork&own upstream {repo} has advanced beyond the "
            "reviewed ref in the fork&own manifest -- review upstream (staged "
            f"digest, when quarantined: .simplecode/quarantine/{slug}/DIGEST.md): "
            "harvest improvements (clean-room) or decline with rationale, then bump the ref")


def _verification_command(root: Path, repo: str) -> str:
    runner = ("python .simplecode/run.py" if (root / ".simplecode" / "run.py").is_file()
              else "python -m")
    return f"{runner} simplecode.guards.upstream_watch --verify-reviewed {repo}"


def run_check(root: Path, *, materialize: bool, env: dict[str, str],
              allow_frozen_writes: bool = False,
              quarantine: bool = False) -> tuple[list[dict], int]:
    """Check every cosecha of `root`. Returns (results, rc)."""
    cosechas, manifest_path = load_manifest(root)
    if manifest_path is None:
        return [], 0
    results = [check_entry(entry) for entry in cosechas]
    for entry, result in zip(cosechas, results):
        if entry.get("licencia") == "NOASSERTION" and result.get("status") != "MALFORMED_ENTRY":
            result["license_warning"] = ("upstream declares no license -- "
                                         "clean-room only, never vendor verbatim")
    checked = [r for r in results if r["status"] not in ("COULD_NOT_RUN", "COULD_NOT_CHECK",
                                                         "MALFORMED_ENTRY")]
    if any(r["status"] == "COULD_NOT_RUN" for r in results):
        return results, 2
    frozen = is_write_frozen(root, env) and not allow_frozen_writes
    if checked and not frozen:
        state = _load_state(root)
        now = datetime.now(UTC).isoformat(timespec="seconds")
        for r in checked:
            state["repos"][r["repo"]] = {
                "last_checked": now,
                "observed_head": r.get("observed_head"),
                "status": r["status"],
                "ahead_by": r.get("ahead_by"),
            }
        _write_state(root, state)
        if quarantine:
            _quarantine(root, cosechas, checked)
        if materialize:
            _materialize(root, checked)
    return results, 0


def _quarantine(root: Path, cosechas: list[dict], checked: list[dict]) -> None:
    """Stage each moved upstream's compare into quarantine (ADR-0010).

    MOVED and HISTORY_REWRITTEN both stage (the latter's digest says the
    compare is unavailable rather than pointing nowhere); UPSTREAM_GONE has
    no head to fetch, so its review stays manual by nature.
    """
    from simplecode.guards import upstream_quarantine
    entries = {c.get("repo"): c for c in cosechas}
    for r in checked:
        if r["status"] not in ("MOVED", "HISTORY_REWRITTEN"):
            continue
        staged = upstream_quarantine.quarantine_moved(
            root, entries[r["repo"]], r["observed_head"], _run_gh)
        r["quarantine"] = staged


def _materialize(root: Path, checked: list[dict]) -> None:
    """One review task per moved/gone repo; prune the ones now reviewed."""
    for r in checked:
        finding = review_finding(r["repo"])
        if r["status"] in ("MOVED", "HISTORY_REWRITTEN", "UPSTREAM_GONE"):
            write_findings(root, [finding],
                           verification_command=_verification_command(root, r["repo"]))
        elif r["status"] == "UP_TO_DATE":
            prune_finding(root, finding)


def verify_reviewed(root: Path, repo: str) -> int:
    """OFFLINE gate for the review task: 1 while the review is pending.

    Pending means: the manifest still carries this repo with a ref, the state
    file recorded a different observed head, and no human has since bumped
    the ref (or dropped/acknowledged the cosecha). Pure file reads -- safe
    inside hooks and verification_command runs, never touches the network.
    """
    cosechas, _ = load_manifest(root)
    refs = {c.get("repo"): c.get("ref") for c in cosechas}
    observed = _load_state(root)["repos"].get(repo, {}).get("observed_head")
    ref = refs.get(repo)
    if ref is None or observed is None:
        print(f"[upstream-watch] OK: {repo} has no pending observation")
        return 0
    if observed == ref:
        print(f"[upstream-watch] OK: {repo} reviewed up to {ref[:12]}")
        return 0
    print(f"[upstream-watch] PENDING: {repo} observed {observed[:12]} but manifest "
          f"ref is {ref[:12]} -- review upstream, then bump the ref")
    return 1


def _report(project: str, results: list[dict]) -> None:
    for r in results:
        line = f"  [{r['repo']}] {r['status']}"
        if r.get("detail"):
            line += f" -- {r['detail']}"
        print(line)
        if r.get("license_warning"):
            print(f"    WARNING: {r['license_warning']}")
    moved = sum(r["status"] in ("MOVED", "HISTORY_REWRITTEN", "UPSTREAM_GONE") for r in results)
    print(f"[upstream-watch] {project}: {len(results)} upstream(s), {moved} needing review")


def _run_single(root: Path, args: argparse.Namespace, env: dict[str, str],
                explicit_root: bool) -> int:
    results, rc = run_check(root, materialize=args.materialize, env=env,
                            allow_frozen_writes=explicit_root,
                            quarantine=args.quarantine)
    if args.json:
        print(json.dumps({"project": root.name, "results": results}, indent=2))
    else:
        if not results:
            # NOT a verified-clean verdict -- distinguish it from one on purpose
            # (DEBT-UPSTREAM-CHECK-DOS-ORGANOS-UNO-CIEGO). "nothing to watch"
            # here means no manifest was RECOGNIZED at any known path/shape; a
            # project can still be forking upstream in a shape this module does
            # not read yet. Never cite this line as evidence an upstream is
            # current -- that requires the per-repo UP_TO_DATE report below.
            print(f"[upstream-watch] {root.name}: no fork&own manifest recognized at "
                  f"{MANIFEST_CANONICAL}, {MANIFEST_FALLBACK}, or {MANIFEST_YAML} -- "
                  "nothing to watch (not the same as checked-and-current)")
        else:
            _report(root.name, results)
        if rc == 2:
            print("[upstream-watch] COULD NOT RUN: gh unavailable or unauthenticated")
        if is_write_frozen(root, env) and not explicit_root and results:
            print(f"[upstream-watch] {root.name} is write-frozen: reported only, "
                  "no state or tasks written")
    return rc


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=None, help="Project root (default: cwd)")
    ap.add_argument("--fleet", type=Path, default=None, help="Check every project under DIR")
    ap.add_argument("--json", action="store_true", help="Machine-readable results")
    ap.add_argument("--materialize", action="store_true",
                    help="File one backlog review task per moved upstream repo")
    ap.add_argument("--quarantine", action="store_true",
                    help="Stage each moved upstream's compare + digest under "
                         ".simplecode/quarantine/ (ADR-0010; never adoption)")
    ap.add_argument("--verify-reviewed", metavar="OWNER/NAME", default=None,
                    help="Offline: exit 1 while OWNER/NAME's review is pending")
    args = ap.parse_args(argv)
    import os
    env = dict(os.environ)
    root = (args.root or Path.cwd()).resolve()
    if args.verify_reviewed:
        return verify_reviewed(root, args.verify_reviewed)
    if args.fleet is None:
        return _run_single(root, args, env, explicit_root=args.root is not None)
    rc = 0
    for project in sorted(p for p in args.fleet.iterdir() if p.is_dir()):
        if load_manifest(project)[1] is None:
            continue
        rc = max(rc, _run_single(project.resolve(), args, env, explicit_root=False))
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
