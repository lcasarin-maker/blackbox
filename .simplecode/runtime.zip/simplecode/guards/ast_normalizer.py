# -*- coding: utf-8 -*-
"""ast_normalizer.py -- Canonical AST normalization and desugaring layer (ADR-0012).

Normalizes dynamic indirections, getattr wrappers, and dynamic import expressions
into canonical AST nodes before running pattern detectors. This allows a single
canonical detector to catch dozens of synthesized evasion variations in O(1) time
without exploding the rule set (avoiding the bloat trap).
"""
from __future__ import annotations

import ast


class ASTEvasionNormalizer(ast.NodeTransformer):
    """Normalize evasion constructs into canonical AST expressions."""

    # Split in two by WHAT THE RULE DOES TO THE NODE, which is the distinction
    # the rule bodies themselves already make: some rules find that the Call IS
    # the indirection and replace it with the expression it hid (they `return` a
    # new node); the rest find that only the CALLEE was written indirectly and
    # rewrite `node.func` in place (they mutate and `return node`).
    #
    # Both halves stay METHODS of this class on purpose, not module-level
    # functions: `hardening_proposal._RULE_BEGIN`/`_RULE_END` match
    # `# rule: <id>` at EXACTLY 8 spaces of indentation, and
    # `extract_rule_bodies` -- the organ that stops a proposed rule from being
    # appended as a third byte-identical copy -- would find ZERO rules the
    # moment these bodies moved to 4 spaces. `visit_Call` also stays LAST, so
    # `_INSERTION_MARKER` ("        return node\n\n\ndef normalize_ast") keeps
    # pointing at it and a newly proposed rule keeps landing where it is tried.
    #
    # THE ONE BEHAVIOURAL CLAIM THIS SPLIT MAKES: grouping reorders
    # `dynamic_import_attribute` from second to fifth, and that is safe because
    # every rule here is gated on the TYPE of `node.func` and the groups are
    # disjoint on it -- Name (getattr), Call (attrgetter), Lambda (lambda wrap),
    # Subscript (vars/__dict__/globals), Attribute-of-Call (the two import
    # rules, which then disagree on the inner callee: `__import__` vs
    # `import_module`). No Call node can satisfy two of them, so the order
    # between groups cannot decide an outcome. `tests/test_ast_normalizer.py`
    # holds one case per rule and is the control on that claim.
    def _replacement_for_indirect_call(self, node: ast.Call) -> ast.AST | None:
        """The rules where the Call itself vanishes: return the expression it
        was hiding, or None when none of them applies."""
        # rule: getattr_indirection
        # 1. Transform: getattr(target, 'attr') -> target.attr
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "getattr"
            and len(node.args) >= 2
            and isinstance(node.args[1], ast.Constant)
            and isinstance(node.args[1].value, str)
        ):
            target = node.args[0]
            attr_name = node.args[1].value
            # If target is __import__('mod'), unwrap to Name('mod')
            if (
                isinstance(target, ast.Call)
                and isinstance(target.func, ast.Name)
                and target.func.id == "__import__"
                and target.args
                and isinstance(target.args[0], ast.Constant)
                and isinstance(target.args[0].value, str)
            ):
                target = ast.Name(id=target.args[0].value, ctx=ast.Load())
            return ast.Attribute(
                value=target,
                attr=attr_name,
                ctx=ast.Load(),
            )
        # endrule: getattr_indirection
        # rule: attrgetter_indirection
        # 3. Transform: operator.attrgetter('attr')(target) -> target.attr
        # Reported live (2026-08-31, red-team fuzzer widened past the original
        # getattr/__import__ pair): unlike those two, attrgetter indirection
        # never requires `target` to be a module -- it's the general stdlib
        # idiom for "resolve this attribute name dynamically" on ANY object,
        # so 32 mutations across otherwise-unrelated detectors evaded before
        # this rule existed.
        if (
            isinstance(node.func, ast.Call)
            and isinstance(node.func.func, ast.Attribute)
            and node.func.func.attr == "attrgetter"
            and isinstance(node.func.func.value, ast.Name)
            and node.func.func.value.id == "operator"
            and len(node.func.args) == 1
            and isinstance(node.func.args[0], ast.Constant)
            and isinstance(node.func.args[0].value, str)
            and len(node.args) == 1
        ):
            return ast.Attribute(
                value=node.args[0],
                attr=node.func.args[0].value,
                ctx=ast.Load(),
            )
        # endrule: attrgetter_indirection
        # rule: immediate_lambda_wrap
        # 4. Transform: (lambda: target.attr)() -> target.attr
        # A zero-arg lambda immediately called with no arguments is
        # semantically a no-op wrapper around its own body -- desugaring it
        # to that body directly closes an entire class of "wrap the real
        # expression in something callable" evasions at once, not just this
        # one shape: any zero-arg lambda body (not only Attribute access)
        # collapses the same way.
        if (
            isinstance(node.func, ast.Lambda)
            and not node.func.args.args
            and not node.func.args.posonlyargs
            and not node.func.args.kwonlyargs
            and not node.func.args.vararg
            and not node.func.args.kwarg
            and not node.args
            and not node.keywords
        ):
            return node.func.body
        # endrule: immediate_lambda_wrap
        return None

    def _rewrote_indirect_callee(self, node: ast.Call) -> bool:
        """The rules where the Call stays a Call and only `node.func` was
        written indirectly: rewrite it in place, and say whether one fired."""
        # rule: dynamic_import_attribute
        # 2. Transform: __import__('module').func(...) -> module.func(...)
        if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Call):
            inner_call = node.func.value
            if (
                isinstance(inner_call.func, ast.Name)
                and inner_call.func.id == "__import__"
                and inner_call.args
                and isinstance(inner_call.args[0], ast.Constant)
                and isinstance(inner_call.args[0].value, str)
            ):
                mod_name = inner_call.args[0].value
                node.func.value = ast.Name(id=mod_name, ctx=ast.Load())
                return True
        # endrule: dynamic_import_attribute
        # rule: vars_subscript
        if (
            isinstance(node.func, ast.Subscript)
            and isinstance(node.func.value, ast.Call)
            and isinstance(node.func.value.func, ast.Name)
            and node.func.value.func.id == 'vars'
            and len(node.func.value.args) == 1
            and isinstance(node.func.slice, ast.Constant)
            and isinstance(node.func.slice.value, str)
        ):
            node.func = ast.Attribute(value=node.func.value.args[0], attr=node.func.slice.value, ctx=ast.Load())
            return True
        # endrule: vars_subscript
        # rule: dunder_dict_subscript
        if (
            isinstance(node.func, ast.Subscript)
            and isinstance(node.func.value, ast.Attribute)
            and isinstance(node.func.value.attr, str)
            and node.func.value.attr == '__dict__'
            and isinstance(node.func.slice, ast.Constant)
            and isinstance(node.func.slice.value, str)
        ):
            node.func = ast.Attribute(value=node.func.value.value, attr=node.func.slice.value, ctx=ast.Load())
            return True
        # endrule: dunder_dict_subscript
        # rule: globals_locals_subscript
        # 5. Transform: globals()['name'](...) / locals()['name'](...) -> name(...)
        # `globals()` y `locals()` no llevan argumentos, asi que exigirlos vacios
        # distingue el builtin real de un `globals(x)` cualquiera del usuario. La
        # clave tiene que ser una constante str: con una clave computada el nombre
        # no se conoce estaticamente y reescribir seria inventarselo.
        if (
            isinstance(node.func, ast.Subscript)
            and isinstance(node.func.value, ast.Call)
            and isinstance(node.func.value.func, ast.Name)
            and node.func.value.func.id in ("globals", "locals")
            and not node.func.value.args
            and not node.func.value.keywords
            and isinstance(node.func.slice, ast.Constant)
            and isinstance(node.func.slice.value, str)
        ):
            node.func = ast.Name(id=node.func.slice.value, ctx=ast.Load())
            return True
        # endrule: globals_locals_subscript
        # rule: importlib_import_module
        # 6. Transform: importlib.import_module('mod').func(...) -> mod.func(...)
        # Misma familia que la regla 2 (`__import__('mod').func`), con la
        # ortografia que la stdlib documenta como la preferida -- por eso es la
        # que un evasor escribe primero. Se aceptan las dos formas de llamarla,
        # `importlib.import_module` y el `import_module` importado suelto.
        if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Call):
            llamada_interna = node.func.value
            objetivo = llamada_interna.func
            es_import_module = (
                isinstance(objetivo, ast.Attribute)
                and objetivo.attr == "import_module"
                and isinstance(objetivo.value, ast.Name)
                and objetivo.value.id == "importlib"
            ) or (isinstance(objetivo, ast.Name) and objetivo.id == "import_module")
            if (
                es_import_module
                and len(llamada_interna.args) == 1
                and isinstance(llamada_interna.args[0], ast.Constant)
                and isinstance(llamada_interna.args[0].value, str)
            ):
                node.func.value = ast.Name(id=llamada_interna.args[0].value, ctx=ast.Load())
                return True
        # endrule: importlib_import_module
        return False

    def visit_Call(self, node: ast.Call) -> ast.AST:
        # Recursively visit children first
        self.generic_visit(node)

        replacement = self._replacement_for_indirect_call(node)
        if replacement is not None:
            return replacement
        self._rewrote_indirect_callee(node)
        return node


def normalize_ast(tree: ast.AST) -> ast.AST:
    """Normalize an AST tree by desugaring evasive indirection patterns."""
    transformer = ASTEvasionNormalizer()
    normalized = transformer.visit(tree)
    ast.fix_missing_locations(normalized)
    return normalized
