#!/usr/bin/env python3
"""Espejo de ADR-0009 (`guards/upstream_watch.py`) para un caso distinto: no un
upstream externo, el KIT PROPIO alejandose de sus satelites en silencio.

Reportado por `declutter` (2026-09-27, DEBT-DECLUTTER-KIT-SATELLITE-DRIFT-RECURRENTE,
retirada por esa misma sesion tras verificar que su script `verify_disposition_classes`
era suyo, no del kit): `DECL-GOV-166` cerraba el drift puntual una y otra vez, pero
nada avisaba a `declutter` CUANDO la madre volvia a avanzar -- el drift crecio de
`mother=8.6.3` a `mother=8.6.5` en menos de 24h sin que declutter tocara nada. El
mismo patron de fondo que ADR-0009 ya resolvio para upstreams externos: deteccion +
"teeth" (una ficha materializada, offline-verificable) + un dead-man switch en
`doctor` para el propio cron, en vez de "solo reporte" -- esa ultima opcion ya la
rechazo el ADR-0009 por nombre ("fork&forget con un recordatorio pegado").

Reutiliza, no reinventa:
- La deteccion de drift YA existe: `satellite_sync.sync_all_satellites(...,
  apply_fix=False)` es el mismo `--plan` de siempre, de solo lectura.
- La materializacion YA existe: `finding_backlog.write_findings`/`prune_finding`,
  las mismas primitivas que usa `upstream_watch`. La ficha se escribe en el
  `tasks/backlog/` del SATELITE, no en el de la madre -- es su deuda, no la de
  simplecode (la miscategorizacion `owner: simplecode` es exactamente el defecto
  que la ficha original de declutter tenia y que este modulo no repite).

Solo corre con sentido desde la madre (`simplecode`, contra `~/projects`): un
satelite no tiene con que compararse a si mismo.

Uso:
    python -m simplecode.guards.kit_drift_watch --fleet ~/projects [--materialize] [--json]
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

from simplecode.satellite import satellite_sync
from simplecode.utils import atomic_io
from simplecode.verification.finding_backlog import prune_finding, write_findings

STATE_FILE = ".simplecode/kit_drift_state.json"


def drift_finding(satellite: str) -> str:
    """Texto de hallazgo para un satelite atrasado. Sin version en el texto a
    proposito -- igual que `upstream_watch.review_finding`, para que un mismo
    satelite mapee siempre al mismo id de ficha en vez de minar una nueva cada
    vez que el drift avanza un numero mas."""
    return (f"[kit-drift-watch] {satellite} esta atrasado respecto al kit de la madre "
            "(simplecode) -- `sync-satellites --plan` reporta drift. Corre "
            "`sync-satellites --apply --target <satelite>` para ponerlo al dia, o "
            "declara por que se queda atras a proposito.")


def _verification_command(satellite: str, projects_dir: Path) -> str:
    python = sys.executable
    return (f"{python} -m simplecode.cli sync-satellites --plan "
            f"--projects-dir {projects_dir} --target {satellite}")


def _load_state(root: Path) -> dict:
    path = root / STATE_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"satellites": {}}
    if not isinstance(data, dict) or not isinstance(data.get("satellites"), dict):
        return {"satellites": {}}
    return data


def _write_state(root: Path, state: dict) -> None:
    atomic_io.write_text_durable(root / STATE_FILE, json.dumps(state, indent=2, sort_keys=True))


def check_fleet(projects_dir: Path) -> dict[str, tuple[bool, str]]:
    """Un `sync-satellites --plan` de solo lectura sobre cada satelite descubierto.
    Delegado por completo a `satellite_sync` -- este modulo no vuelve a medir
    drift, solo decide que hacer con lo que ya se midio."""
    return satellite_sync.sync_all_satellites(projects_dir, apply_fix=False)


def run_check(projects_dir: Path, mother_root: Path, *, materialize: bool) -> dict[str, tuple[bool, str]]:
    """Corre el chequeo, actualiza el estado del dead-man switch en la madre, y
    opcionalmente materializa/poda una ficha por satelite en SU PROPIO backlog."""
    results = check_fleet(projects_dir)
    now = datetime.now(UTC).isoformat()
    state = _load_state(mother_root)
    for name, (ok, _detail) in results.items():
        state["satellites"][name] = {"last_checked": now, "ok": ok}
    _write_state(mother_root, state)

    if materialize:
        for name, (ok, _detail) in results.items():
            satellite_path = projects_dir / name
            finding = drift_finding(name)
            if ok:
                prune_finding(satellite_path, finding)
            else:
                write_findings(
                    satellite_path, [finding],
                    verification_command=_verification_command(name, projects_dir),
                )
    return results


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--fleet", type=Path, required=True, help="Check every satellite under DIR")
    ap.add_argument("--mother-root", type=Path, default=satellite_sync.MOTHER_REPO_ROOT,
                    help="Where the dead-man switch state is recorded (default: this kit's own repo)")
    ap.add_argument("--materialize", action="store_true",
                    help="File one backlog task per drifted satellite, in ITS OWN tasks/backlog/")
    ap.add_argument("--json", action="store_true", help="Machine-readable results")
    args = ap.parse_args(argv)

    results = run_check(args.fleet.resolve(), args.mother_root.resolve(), materialize=args.materialize)
    drifted = {name: detail for name, (ok, detail) in results.items() if not ok}

    if args.json:
        print(json.dumps({"checked": len(results), "drifted": drifted}, indent=2))
    else:
        print(f"[kit-drift-watch] {len(results)} satellite(s) checked, {len(drifted)} drifted")
        for name, detail in sorted(drifted.items()):
            print(f"  [{name}] {detail}")
    return 1 if drifted else 0


if __name__ == "__main__":
    raise SystemExit(main())
