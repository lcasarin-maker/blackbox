#!/usr/bin/env python3
"""signed_commit.py -- Verifies OUTGOING commits are GPG/SSH signed (pre-push).

A pre-commit hook cannot prove the commit it fires for is signed: at
pre-commit time that commit does not exist yet, so the only things a
pre-commit-stage check can inspect are the PREVIOUS commit (`git log -1
--format=%G?`) or the signing CONFIG (a proxy for future intent, not proof).
Neither is evidence about the commit actually being pushed.

This runs at pre-push instead, where the commits being pushed are real,
addressable objects: `git verify-commit <sha>` checks each one directly.
"""

from __future__ import annotations

import select
import subprocess
import sys
from pathlib import Path

from simplecode.utils.tool_limits import GIT_O1_TIMEOUT, GIT_SCAN_TIMEOUT

ZERO_SHA_CHARS = frozenset("0")


# How long to wait for the pre-push protocol before concluding nobody is going
# to send it. Git writes its lines and closes immediately, so this is only ever
# reached by a manual or CI invocation with an idle stdin -- where the old code
# blocked forever.
STDIN_WAIT_SECONDS = 2.0


def _is_zero_sha(sha: str) -> bool:
    """True for git's all-zeros sentinel (a ref being created or deleted)."""
    return bool(sha) and set(sha) <= ZERO_SHA_CHARS


def commits_in_range(range_spec: str) -> list[str] | None:
    """List commit SHAs in `range_spec` (oldest first), or None if git failed."""
    try:
        result = subprocess.run(
            ["git", "rev-list", range_spec],
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
            timeout=GIT_SCAN_TIMEOUT,
            check=False,
        )
    except (subprocess.SubprocessError, OSError, FileNotFoundError):
        return None
    if result.returncode != 0:
        return None
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def verify_commit(commit_ish: str) -> tuple[bool, str]:
    """Run `git verify-commit` on one commit. Returns (signed_ok, detail)."""
    try:
        result = subprocess.run(
            ["git", "verify-commit", commit_ish],
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
            timeout=GIT_O1_TIMEOUT,
            check=False,
        )
    except (subprocess.SubprocessError, OSError, FileNotFoundError) as exc:
        return False, f"ERROR: {exc}"
    if result.returncode == 0:
        return True, "signed"
    detail = (result.stderr or result.stdout).strip()
    return False, detail or "signature missing or invalid"


def _push_ranges_from_stdin() -> list[str]:
    """Parse the pre-push protocol (<local ref> <local sha> <remote ref>
    <remote sha> per line) into one range-spec per updated ref.

    A brand-new remote ref (all-zero remote sha) has no upstream tip to diff
    against; verifying the FULL ancestry of a new branch is unbounded (it may
    share no history-scope decision with the rest of this repo), so this
    scopes to the branch tip alone -- a declared, deliberate narrowing, not a
    silent gap.
    """
    ranges = []
    for line in sys.stdin.read().splitlines():
        parts = line.split()
        if len(parts) != 4:
            continue
        _local_ref, local_sha, _remote_ref, remote_sha = parts
        if _is_zero_sha(local_sha):
            continue  # a branch deletion pushes nothing to verify
        if _is_zero_sha(remote_sha):
            ranges.append(local_sha)
        else:
            ranges.append(f"{remote_sha}..{local_sha}")
    return ranges


def _resolve_ranges() -> list[str]:
    """Ranges to verify: parsed from the pre-push protocol on stdin, or just
    HEAD for a manual/interactive invocation -- or when stdin exists but
    isn't actually readable (e.g. a test harness capturing it), same
    fallback as the interactive case.

    THE READ IS BOUNDED, and that is not defensive decoration. Until 2026-09-05
    a non-tty stdin went straight to `sys.stdin.read()`, which blocks until the
    writer closes the pipe. An OPEN pipe that never writes raises no OSError --
    it simply never returns, so the `except OSError` fallback below could not
    catch it. Measured: `python -m simplecode.guards.signed_commit --root .`
    from a non-interactive shell hung past 120s and had to be killed.

    This hook runs at pre-push. A gate that hangs is worse than a gate that
    fails: a failure is a verdict, a hang is no verdict at all, and it stalls
    the whole push chain behind it with nothing printed to say why. Under the
    real pre-push protocol git writes its lines immediately, so `select` returns
    ready at once and nothing changes; only the pathological case is bounded.
    """
    if sys.stdin.isatty():
        return ["HEAD"]
    try:
        fileno = sys.stdin.fileno()
    except (OSError, ValueError, AttributeError):
        # No real file descriptor: an in-memory buffer (a test harness capturing
        # stdin, a StringIO). Those cannot block, so read them directly. Waiting
        # on `select` here would be worse than the bug it fixes -- it would make
        # the gate verify HEAD alone while a perfectly readable protocol sat in
        # the buffer, silently narrowing what every push checks.
        try:
            return _push_ranges_from_stdin()
        except OSError:
            return ["HEAD"]
    try:
        ready, _, _ = select.select([fileno], [], [], STDIN_WAIT_SECONDS)
    except (OSError, ValueError):
        return ["HEAD"]
    if not ready:
        print(
            f"[signed-commit] no pre-push data on stdin after {STDIN_WAIT_SECONDS}s "
            "-- verifying HEAD only. This is the manual-invocation path; under a "
            "real `git push` the protocol arrives immediately."
        )
        return ["HEAD"]
    try:
        return _push_ranges_from_stdin()
    except OSError:
        return ["HEAD"]


def _expand_to_shas(ranges: list[str]) -> tuple[list[str] | None, str | None]:
    """Expand each range spec to individual commit SHAs. Returns (shas, error);
    error is None on success."""
    shas: list[str] = []
    for range_spec in ranges:
        if ".." not in range_spec:
            shas.append(range_spec)
            continue
        commits = commits_in_range(range_spec)
        if commits is None:
            return None, f"git could not list commits in {range_spec}"
        shas.extend(commits)
    return shas, None


def main() -> int:
    """Exit 0 when every outgoing commit verifies as signed, 1 if any does
    not, 2 when git itself could not answer."""
    ranges = _resolve_ranges()
    if not ranges:
        print("[signed-commit] OK: no commits to verify")
        return 0

    shas, error = _expand_to_shas(ranges)
    if error is not None:
        print(f"[signed-commit] COULD_NOT_RUN: {error}")
        return 2
    if not shas:
        print("[signed-commit] OK: no commits to verify")
        return 0

    unsigned = []
    for sha in shas:
        ok, detail = verify_commit(sha)
        if not ok:
            if detail.startswith("ERROR"):
                print(f"[signed-commit] COULD_NOT_RUN: {detail}")
                return 2
            unsigned.append((sha, detail))

    if unsigned:
        for sha, detail in unsigned:
            print(f"[signed-commit] FAIL: {sha[:12]} is not signed ({detail})")
        print(
            f"[signed-commit] FAIL: {len(unsigned)}/{len(shas)} outgoing commit(s) not signed; "
            f"primero {unsigned[0][0][:12]}"
        )
        print("  Fix: git config --global commit.gpgSign true; ensure a signing key is configured")
        return 1

    print(f"[signed-commit] OK: {len(shas)} outgoing commit(s) signed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
