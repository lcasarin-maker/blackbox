#!/usr/bin/env python3
"""pr_size_limit.py -- Reports commit size against advisory thresholds.

Measures the STAGED commit (not a PR: no base ref exists at pre-commit time,
so this can only ever see the one commit being formed, never the shape of a
whole pull request) and reports lines added/removed and files touched against
a threshold. Advisory only: legitimate large but reviewable changes exist, and
splitting a commit to dodge a blocking version of this check would be pure
overhead, not a real reduction in review surface. Never wire this as a
blocking gate; it exists to flag a commit worth a second look, not to refuse
one.
"""

import subprocess
import sys

from simplecode.utils.tool_limits import GIT_O1_TIMEOUT

NUMSTAT_FIELDS = 3


def get_staged_stats() -> tuple[int, int, int] | None:
    """Return staged stats, or None when Git cannot provide them."""
    try:
        # `--numstat` walks an already-indexed diff -- no working-tree bytes
        # to measure before the call, and the output is bounded by file
        # count, not payload size. Near-O(1) git plumbing: GIT_O1_TIMEOUT,
        # not a fabricated proportional formula over an unmeasured input.
        result = subprocess.run(
            ["git", "diff", "--cached", "--numstat"],
            capture_output=True,
            text=True,
            timeout=GIT_O1_TIMEOUT,
            check=False,
        )
        if result.returncode != 0:
            return None

        lines_added = 0
        lines_removed = 0
        files_changed = 0

        for line in result.stdout.strip().splitlines():
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) >= NUMSTAT_FIELDS:
                try:
                    added = int(parts[0]) if parts[0] != "-" else 0
                    removed = int(parts[1]) if parts[1] != "-" else 0
                    lines_added += added
                    lines_removed += removed
                    files_changed += 1
                except ValueError:
                    return None
        return lines_added, lines_removed, files_changed
    except (subprocess.SubprocessError, OSError, FileNotFoundError):
        return None


def main(
    max_lines: int = 500,
    max_files: int = 20,
    mode: str = "staged",
) -> int:
    """Report-only: always exits 0 (or 2 when the stats themselves could not
    be read). A threshold breach is printed, never blocked -- see module
    docstring for why this cannot be a gate."""
    if mode != "staged":
        print(f"[pr-size-limit] Unknown mode: {mode}")
        return 2

    stats = get_staged_stats()
    if stats is None:
        print("[pr-size-limit] COULD NOT RUN: Git could not read staged change statistics")
        return 2
    added, removed, files = stats
    total = added + removed

    if total > max_lines:
        print(f"[pr-size-limit] REPORT: {total} lines changed (advisory limit: {max_lines})")
        print(f"  Added: {added}, Removed: {removed}")
        print(f"  Files: {files}")
        print("  Not enforced -- this measures the staged commit, not a PR.")
        return 0

    if files > max_files:
        print(f"[pr-size-limit] REPORT: {files} files changed (advisory limit: {max_files})")
        print("  Not enforced -- this measures the staged commit, not a PR.")
        return 0

    print(f"[pr-size-limit] OK: {total} lines, {files} files (limits: {max_lines} lines, {max_files} files)")
    return 0


if __name__ == "__main__":
    import os
    max_lines = int(os.getenv("PR_SIZE_LIMIT_MAX_LINES", "500"))
    max_files = int(os.getenv("PR_SIZE_LIMIT_MAX_FILES", "20"))
    mode = os.getenv("PR_SIZE_LIMIT_MODE", "staged")
    sys.exit(main(max_lines=max_lines, max_files=max_files, mode=mode))
