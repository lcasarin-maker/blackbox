# -*- coding: utf-8 -*-
"""multilang_ast.py -- AST-semantic detectors for Rust and TypeScript.

DEBT-SPEC8-RUST-TS-PARSERS: every semantic detector in this kit was
Python-only (`ast` module). A Rust or TypeScript satellite got the
pattern-level checks (`guards/pattern_detectors.py`, regex-based, language-
agnostic) but none of the AST-level ones -- `angry_path`'s own Mandate B3
("errors are never silently swallowed") is exactly the class of check a
regex cannot express reliably across languages (nesting, multi-line bodies,
comments-that-look-like-code), which is why it stayed Python-only.

Scope, stated so nobody reads more into this than what is here: this is ONE
detector per language (silent-error-swallow, the same vice `angry_path`
already convicts in Python's bare `except: pass` and JS/TS's empty
`catch {}` via regex), not parity with the kit's ~37 Python detectors. It
establishes the real parsing infrastructure and one real, tested check --
a foundation to extend, not the finished feature.

Optional dependency (`pip install simplecode[multilang]`): `tree-sitter` +
per-language grammar bindings. Most satellites are pure Python and should
never be forced to install Rust/TS grammar bindings just to run this kit's
Python-only gates -- every function here degrades to `None`/`COULD_NOT_RUN`
when the bindings are absent, matching the existing
`unanalysed_semantic_source` confession this module now narrows.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

# Type-only: never executed, so this costs nothing when the optional dep is
# absent, and gives every `"Parser | None"`/`"Node"` annotation below a real
# type instead of the runtime `try/except` fallback fighting pyright over
# what those names mean. The actual runtime objects are imported fresh,
# locally, inside each parser-builder function below -- reached only when
# MULTILANG_AST_AVAILABLE is True, i.e. only when tree-sitter genuinely is
# installed.
if TYPE_CHECKING:
    from tree_sitter import Node, Parser

try:
    __import__("tree_sitter")

    MULTILANG_AST_AVAILABLE = True
except ImportError:
    MULTILANG_AST_AVAILABLE = False

_RUST_PARSER: "Parser | None" = None
_TS_PARSER: "Parser | None" = None
_TSX_PARSER: "Parser | None" = None


def _rust_parser() -> "Parser | None":
    global _RUST_PARSER
    if not MULTILANG_AST_AVAILABLE:
        return None
    if _RUST_PARSER is None:
        from tree_sitter import Language, Parser
        import tree_sitter_rust

        _RUST_PARSER = Parser(Language(tree_sitter_rust.language()))
    return _RUST_PARSER


def _typescript_parser(*, tsx: bool) -> "Parser | None":
    global _TS_PARSER, _TSX_PARSER
    if not MULTILANG_AST_AVAILABLE:
        return None
    from tree_sitter import Language, Parser
    import tree_sitter_typescript

    if tsx:
        if _TSX_PARSER is None:
            _TSX_PARSER = Parser(Language(tree_sitter_typescript.language_tsx()))
        return _TSX_PARSER
    if _TS_PARSER is None:
        _TS_PARSER = Parser(Language(tree_sitter_typescript.language_typescript()))
    return _TS_PARSER


def _find_all(node: "Node", node_type: str):
    if node.type == node_type:
        yield node
    for child in node.children:
        yield from _find_all(child, node_type)


def _is_empty_block(node: "Node | None", empty_type: str) -> bool:
    """A block/statement_block with no children besides its own braces."""
    if node is None or node.type != empty_type:
        return False
    return not any(c.type not in ("{", "}") for c in node.children)


def _line_of(node: "Node", source: bytes) -> int:
    return source[: node.start_byte].count(b"\n") + 1


def scan_rust_silent_swallow(path: Path) -> list[str] | None:
    """`match` arms on `Err(...)` with an empty `{}` body -- the Rust shape
    of `angry_path`'s bare `except: pass`: a fallible call's failure is
    matched, named, and discarded without logging, re-raising, or even a
    comment.

    Returns None (COULD_NOT_RUN) when no Rust parser is available or the
    file cannot be read/parsed -- never an empty list, which would read as
    "checked, found nothing" and is not the same claim as "could not check".
    """
    parser = _rust_parser()
    if parser is None:
        return None
    try:
        source = path.read_bytes()
    except OSError:
        return None
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logging.debug("%s: parser failure: %s", path, exc)
        return None

    findings = []
    for arm in _find_all(tree.root_node, "match_arm"):
        # `match_arm`'s first child is always its `match_pattern` -- required
        # by the grammar, confirmed against or-patterns (`Ok(v) | Err(v)`),
        # bound patterns (`e @ Err(_)`), and the wildcard (`_`), none of
        # which carry a direct `tuple_struct_pattern` child -- exactly the
        # shapes `tuple_pattern is None` below exists to skip past.
        pattern = arm.children[0] if arm.children else None
        tuple_pattern = next(
            (c for c in (pattern.children if pattern else ()) if c.type == "tuple_struct_pattern"),
            None,
        )
        if tuple_pattern is None or not tuple_pattern.children:
            continue
        head = tuple_pattern.children[0]
        if head.type != "identifier" or head.text != b"Err":
            continue
        # A trailing comma is the final child of a Rust match arm. Selecting
        # the grammar's value field preserves the body for both spellings.
        body = arm.child_by_field_name("value")
        if _is_empty_block(body, "block"):
            line = _line_of(arm, source)
            findings.append(f"{path}:{line}: match arm on Err(...) has an empty body -- error matched and discarded")
    return findings


def scan_typescript_silent_swallow(path: Path) -> list[str] | None:
    """`catch` clauses (`catch (e) {}` or bare `catch {}`) with an empty
    body -- the same vice `angry_path`'s `_JS_CATCH_EMPTY` regex already
    catches for single-line cases, done via real AST so multi-line bodies,
    nested braces, and comment-only "handlers" cannot produce a false
    negative the way a regex can.

    Returns None (COULD_NOT_RUN) when no TypeScript parser is available or
    the file cannot be read/parsed.
    """
    parser = _typescript_parser(tsx=path.suffix.lower() == ".tsx")
    if parser is None:
        return None
    try:
        source = path.read_bytes()
    except OSError:
        return None
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logging.debug("%s: parser failure: %s", path, exc)
        return None

    findings = []
    for clause in _find_all(tree.root_node, "catch_clause"):
        body = next((c for c in clause.children if c.type == "statement_block"), None)
        if _is_empty_block(body, "statement_block"):
            line = _line_of(clause, source)
            findings.append(f"{path}:{line}: catch clause has an empty body -- error caught and discarded")
    return findings
