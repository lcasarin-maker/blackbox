# -*- coding: utf-8 -*-
"""orphan_hunter.py -- consolidated dead-code & slop forensics (ADR-0004).

Five reachability-aware forensic engines over a repository tree, exposed as
``simplecode hunt`` and folded into ``make deadcode``. Consolidate, never
duplicate: two engines are genuinely new (a cross-module Symbol Dependency
Graph and a zombie-fixture sweeper); the other three delegate to organs that
already own their subject.

  1. Symbol Dependency Graph (SDG, NEW) -- an in-degree graph over ``src/``.
     A public (non-underscore) module-level function/class/constant whose name
     is referenced nowhere and is not a root anchor is a CONVICTED_ORPHAN.
     Root anchors (any one exempts a symbol): the name ``main``; any name in a
     module ``__all__``; any name referenced from ``tests/``; any name that
     appears as a token in ``.pre-commit-config.yaml`` hook entries, the
     ``Makefile``, or ``.github/workflows/*.yml``.

     HEURISTIC, STATED HONESTLY: in-degree is computed from static references
     only -- ``ast.Name`` loads, ``ast.Attribute`` attributes, imported alias
     names, and identifier-valued string literals (which catch string-keyed
     dispatch and ``getattr(obj, "name")``). A reference reachable only through
     a computed name this pass cannot resolve is invisible to it, so the pass
     fails TOWARD reachable: string identifiers count as references, a symbol is
     convicted only when NOTHING references it, and orphans are reviewable
     findings, never auto-deletions. False negatives (a real orphan missed)
     are preferred to false positives (a live symbol convicted).

  2. Zombie fixture/helper sweeper (NEW) -- a ``@pytest.fixture`` or a helper
     function under ``tests/``/``conftest.py`` referenced by no test. Runs only
     under ``--include-tests``.

  3. Ghost task / dangling backlog -- DELEGATED to ``dangling_refs``
     (``check_broken_evidence_pins`` + ``check_inventory_drift``): a backlog or
     markdown reference to a file that does not exist.

  4. Tombstone / slop remnant -- CONSOLIDATED on ``dangling_refs``' ``[RETIRED:]``
     support (``get_retired_rules``) PLUS an optional ``.simplecode/tombstones.yaml``
     catalog of deprecated names/flags/namespaces scanned across ``.py``/``.md``/
     ``.yaml`` for surviving mentions. Absent catalog yields nothing. Runs only
     under ``--tombstones``.

  5. Over-engineering Density Index (ODS) -- CONSOLIDATED on
     ``pattern_detectors._function_complexity``: ``ODS = LoC * complexity /
     (in-degree + 1)`` per module; warns on a high-complexity module with zero
     or unit import traffic.

An unreadable, undecodable, or unparseable file is fail-closed as COULD_NOT_RUN,
never a silent pass: it is recorded, printed beside the findings, and (like an
orphan or a ghost task) trips ``--gate``. A report with ``could_not_run > 0`` is
not a clean report, however many rows pass.

CONSULTATIVE WITHOUT ``--gate``, AND THAT IS DECLARED HERE ON PURPOSE. The bare
invocation reports and exits 0; only ``--gate`` puts the verdict in the exit
code. That is the kit's convention, measured 2026-09-05 on a dirty subject
rather than deduced from the code: ``unselected_rules`` bare -> rc=0 with no
``BLOCKED`` line, ``--gate`` -> rc=1 WITH it; ``angry_path`` bare -> rc=0
printing ``FAIL``, ``--gate`` -> rc=1. Every wiring of this organ in this repo
passes ``--gate`` (the ``Makefile`` ``deadcode`` target; the ``deadcode-gate``
hook was retired from ``.pre-commit-config.yaml``, DEBT-SYNC-REMOVED-DEADCODE-GATE);
nothing consumes the bare form's exit code.

What was WRONG until 2026-09-05 was the WORD, not the exit code: the bare form
printed ``BLOCKED`` -- a word that promises to block -- and exited 0, so a
consumer who read the word got the opposite of what the exit code did. A
consultative organ saying BLOCKED is lying about what it is. The bare form now
says ``ADVISORY (would block under --gate)``, the vocabulary ``ratchet.py``
already uses for exactly this state (``"debt BLOCKED" if armed else "debt
ADVISORY (would block if armed)"``). The exit code was left alone: changing it
would have armed, with no announcement, an organ that 17 satellites pull by
content hash within 60s.
"""

from __future__ import annotations

import argparse
import ast
import json
import logging
import os
import symtable
import sys
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import cast

import yaml

from simplecode.verification import ledger_schema
from simplecode.guards.pattern_detectors import _function_complexity
from simplecode.utils.atomic_io import write_text_durable
from simplecode.verification import dangling_refs

logger = logging.getLogger("orphan_hunter")

# --- ODS thresholds (documented, named constants — not anonymous magic) ------
# A module whose summed cyclomatic complexity reaches this bound while carrying
# at most ODS_UNIT_INDEGREE importers is over-engineered relative to the traffic
# it serves. 40 is a deliberate, defensible floor: measured against this repo it
# names only the densest modules, not the median one -- an instrument that fires
# on everything catches nothing.
ODS_MODULE_COMPLEXITY_WARN = 40
# "Zero or unit in-degree": a module imported by no other module, or by exactly
# one, is low-traffic enough that its density is worth a human's glance.
ODS_UNIT_INDEGREE = 1

_PY_GLOB = "*.py"
_CATALOG_REL = ".simplecode/tombstones.yaml"
_WORKFLOW_GLOB = ".github/workflows/*.yml"
_CONFIG_FILES = (".pre-commit-config.yaml", "Makefile")

# A regression test whose whole job is proving a tombstoned name is gone must
# name it to do that -- mentioning it there is the record of the retirement
# holding, not a remnant of it coming back. Same shape and reasoning as
# canon_adoption.py's own self-exemption for its test file; kept explicit and
# small on purpose, so a genuine reintroduction elsewhere still convicts.
_TOMBSTONE_TEST_EXEMPT = frozenset({"tests/test_accepted_task.py"})


class CouldNotRun(Exception):
    """A file could not be read/decoded/parsed: there is NO verdict on it.

    Raised instead of returning a false "clean", so the caller must record the
    file and its reason rather than silently treating absence of a scan as
    absence of a defect.
    """


@dataclass
class Finding:
    """One forensic finding, in the shape every engine emits."""

    engine: str
    kind: str
    ref: str
    origin: str
    message: str
    severity: str = "FAIL"

    def as_dict(self) -> dict:
        return {
            "engine": self.engine,
            "kind": self.kind,
            "ref": self.ref,
            "origin": self.origin,
            "message": self.message,
            "severity": self.severity,
        }


@dataclass
class HuntReport:
    """The full result of a hunt: findings, what could not run, and telemetry."""

    findings: list[Finding] = field(default_factory=list)
    could_not_run: list[tuple[str, str]] = field(default_factory=list)
    retired_rules: list[int] = field(default_factory=list)
    engines_run: dict[str, bool] = field(default_factory=dict)

    def of_kind(self, kind: str) -> list[Finding]:
        return [f for f in self.findings if f.kind == kind]

    @property
    def gating(self) -> list[Finding]:
        """Findings that trip ``--gate``: convicted orphans, ghost tasks,
        tombstone-catalog hits, and zombie fixtures/helpers. All four use the
        same conservative "fail toward reachable" reference collection
        (``_collect_references``: names, attributes, string-literal dispatch
        keys) that SDG orphans already relied on, so promoting zombie to
        gating is consistent with an existing, already-gating engine, not a
        new risk class. Only ODS stays reviewable-only: it is a density
        *score*, not a discrete match, so there is no clean threshold to gate
        on without inventing one. An engine that finds real remnants but can
        never gate or materialize is a defect in the instrument, not evidence
        the repo is clean.
        """
        return [f for f in self.findings if f.kind in ("orphan", "ghost_task", "tombstone", "zombie")]

    @property
    def ok(self) -> bool:
        return not self.gating and not self.could_not_run


# ---------------------------------------------------------------------------
# File reading -- fail closed on unreadable/undecodable/unparseable input
# ---------------------------------------------------------------------------

def _read_text(path: Path) -> str:
    """Read a file as strict UTF-8, raising CouldNotRun on any failure.

    Bytes are read first, then decoded strict (mirroring corruption_guard /
    zero_debt): an undecodable file, a NUL-laden file, or an unreadable file
    is a fact about the file, never absolved as clean.
    """
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise CouldNotRun(f"unreadable: {exc}") from exc
    if b"\x00" in data:
        raise CouldNotRun("NUL byte in source (corruption/truncation)")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CouldNotRun(f"invalid UTF-8: {exc.reason}") from exc


def _parse(path: Path) -> ast.Module:
    """Parse a file into a Module AST, raising CouldNotRun on read/syntax failure."""
    text = _read_text(path)
    try:
        tree = ast.parse(text, filename=str(path))
        setattr(tree, "_simplecode_source", text)
        return tree
    except (SyntaxError, ValueError, RecursionError, MemoryError) as exc:
        raise CouldNotRun(f"unparseable: {type(exc).__name__}: {exc}") from exc


def _py_files(base: Path, errors: list[tuple[str, str]] | None = None) -> list[Path]:
    """Every ``.py`` file under ``base`` (sorted, deterministic)."""
    if not base.is_dir():
        return []
    found: list[Path] = []

    def record_error(exc: OSError) -> None:
        if errors is not None:
            errors.append((str(exc.filename or base), f"unreadable directory: {exc}"))

    for directory, _dirs, files in os.walk(base, onerror=record_error):
        found.extend(Path(directory) / name for name in files if name.endswith(".py"))
    return sorted(found)


# ---------------------------------------------------------------------------
# Reference extraction (shared by SDG and zombie engines)
# ---------------------------------------------------------------------------

def _collect_references(tree: ast.AST) -> set[str]:
    """Every name this AST references, conservatively.

    Includes loaded ``ast.Name`` ids, augmented-assignment reads,
    ``ast.Attribute`` attributes,
    imported names/aliases, and identifier-valued string literals. The string
    literals are what make the pass fail toward reachable: a name used only as
    a dispatch key (``handlers["do_it"]``) or via ``getattr`` still counts.
    """
    source = getattr(tree, "_simplecode_source", None)
    refs = _global_load_references(source) if isinstance(source, str) else set()
    for node in ast.walk(tree):
        if source is None and isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            refs.add(node.id)
        elif source is None and isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name):
            # Augmented assignment reads the prior value as well as storing
            # the replacement, although Python's AST marks the target Store.
            refs.add(node.target.id)
        elif isinstance(node, ast.arg):
            # A pytest fixture is consumed by NAME as a test's parameter, so an
            # argument name is a genuine reference (and, for the SDG, one more
            # way to fail toward reachable).
            refs.add(node.arg)
        elif isinstance(node, ast.Attribute):
            refs.add(node.attr)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            refs |= _import_names(node)
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value.isidentifier():
            refs.add(node.value)
    return refs


def _global_load_references(source: str) -> set[str]:
    """Return global dependencies, including postponed type annotations.

    Symtable omits annotation loads under PEP 563. For dependency analysis,
    build the symbol table with only that future flag removed; this
    preserves lexical scope (local aliases still cannot rescue globals).
    Compile the original source first to validate it without executing it.
    """
    refs: set[str] = set()
    try:
        compile(source, "<orphan-hunter>", "exec", dont_inherit=True)
        tree = ast.parse(source)
        postponed = [node for node in tree.body if isinstance(node, ast.ImportFrom)
                     and node.module == "__future__"
                     and any(alias.name == "annotations" for alias in node.names)]
        if postponed:
            for node in postponed:
                node.names = [alias for alias in node.names if alias.name != "annotations"]
                if not node.names:
                    tree.body.remove(node)
            source = ast.unparse(tree)
        scopes = [symtable.symtable(source, "<orphan-hunter>", "exec")]
    except (SyntaxError, ValueError, RecursionError, MemoryError) as exc:
        raise CouldNotRun(f"invalid symbol table: {type(exc).__name__}: {exc}") from exc
    while scopes:
        scope = scopes.pop()
        refs.update(
            symbol.get_name() for symbol in scope.get_symbols()
            if symbol.is_referenced() and (scope.get_type() == "module" or symbol.is_global())
        )
        scopes.extend(scope.get_children())
    return refs


def _import_names(node: ast.Import | ast.ImportFrom) -> set[str]:
    """Names an import statement binds into the referencing module's namespace."""
    if isinstance(node, ast.ImportFrom):
        return {
            name
            for alias in node.names
            for name in (alias.name, alias.asname or alias.name)
        }
    return {
        name
        for alias in node.names
        for name in (alias.name.split(".")[0], (alias.asname or alias.name).split(".")[0])
    }


@dataclass
class _Symbol:
    name: str
    module: Path
    kind: str
    lineno: int


def _module_scope_suites(node: ast.stmt) -> list[list[ast.stmt]]:
    if isinstance(node, (ast.If, ast.For, ast.AsyncFor, ast.While)):
        return [node.body, node.orelse]
    if isinstance(node, (ast.With, ast.AsyncWith)):
        return [node.body]
    if isinstance(node, (ast.Try, ast.TryStar)):
        return [node.body, node.orelse, node.finalbody, *(handler.body for handler in node.handlers)]
    if isinstance(node, ast.Match):
        return [case.body for case in node.cases]
    return []


def _assigned_module_target_names(target: ast.expr) -> list[str]:
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, (ast.Tuple, ast.List)):
        return [name for element in target.elts for name in _assigned_module_target_names(element)]
    if isinstance(target, ast.Starred):
        return _assigned_module_target_names(target.value)
    return []


def _assigned_module_symbols(
    targets: list[ast.expr], value: ast.expr, lineno: int, path: Path,
) -> tuple[list[_Symbol], set[str]]:
    symbols: list[_Symbol] = []
    all_names: set[str] = set()
    for target in targets:
        for name in _assigned_module_target_names(target):
            if name == "__all__":
                all_names |= _literal_names(value)
            elif not name.startswith("_"):
                symbols.append(_Symbol(name, path, "constant", lineno))
    return symbols, all_names


def _module_symbol_declarations(node: ast.stmt, path: Path) -> tuple[list[_Symbol], set[str]]:
    symbols: list[_Symbol] = []
    all_names: set[str] = set()
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_"):
        symbols.append(_Symbol(node.name, path, "function", node.lineno))
    elif isinstance(node, ast.ClassDef) and not node.name.startswith("_"):
        symbols.append(_Symbol(node.name, path, "class", node.lineno))
    elif isinstance(node, ast.Assign):
        return _assigned_module_symbols(node.targets, node.value, node.lineno, path)
    elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.value is not None:
        return _assigned_module_symbols([node.target], node.value, node.lineno, path)
    return symbols, all_names


def _module_symbols(tree: ast.Module, path: Path) -> tuple[list[_Symbol], set[str]]:
    """Public module-scope symbols, including declarations in control blocks.

    Function/class bodies are separate scopes. If/try/loop/match suites remain
    in the module namespace and therefore contribute definitions and constants.
    """
    symbols: list[_Symbol] = []
    dunder_all: set[str] = set()
    stack = list(reversed(tree.body))
    while stack:
        node = stack.pop()
        declared, exported = _module_symbol_declarations(node, path)
        symbols.extend(declared)
        dunder_all |= exported
        for suite in reversed(_module_scope_suites(node)):
            stack.extend(reversed(suite))
    return symbols, dunder_all


def _literal_names(node: ast.AST) -> set[str]:
    """String entries of a list/tuple literal (an ``__all__`` value)."""
    if not isinstance(node, (ast.List, ast.Tuple)):
        return set()
    return {
        elt.value
        for elt in node.elts
        if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
    }


# ---------------------------------------------------------------------------
# Root-anchor tokens (config + tests)
# ---------------------------------------------------------------------------

def _identifier_tokens(text: str) -> set[str]:
    """Every maximal identifier-shaped token in arbitrary text."""
    tokens: set[str] = set()
    current: list[str] = []
    for ch in text:
        if ch.isalnum() or ch == "_":
            current.append(ch)
        elif current:
            tokens.add("".join(current))
            current = []
    if current:
        tokens.add("".join(current))
    return tokens


def _config_tokens(root: Path, report: HuntReport) -> set[str]:
    """Identifier tokens from pre-commit, Makefile, and workflow files.

    An unreadable config file is recorded as COULD_NOT_RUN; the scan continues
    with whatever config it could read (a missing anchor fails toward reachable,
    never toward a false conviction).
    """
    tokens: set[str] = set()
    paths = [root / name for name in _CONFIG_FILES]
    workflow_dir = root / ".github" / "workflows"
    try:
        with os.scandir(workflow_dir) as entries:
            paths.extend(
                workflow_dir / entry.name
                for entry in sorted(entries, key=lambda item: item.name)
                if entry.is_file() and entry.name.endswith(".yml")
            )
    except FileNotFoundError:
        pass
    except OSError as exc:
        report.could_not_run.append((str(workflow_dir), f"cannot enumerate workflow anchors: {exc}"))
    for path in paths:
        if not path.is_file():
            continue
        try:
            tokens |= _identifier_tokens(_read_text(path))
        except CouldNotRun as exc:
            report.could_not_run.append((str(path), str(exc)))
    return tokens


def _project_scripts(path: Path, report: HuntReport) -> dict[str, object] | None:
    try:
        data = tomllib.loads(_read_text(path))
    except CouldNotRun as exc:
        report.could_not_run.append((str(path), str(exc)))
        return None
    except tomllib.TOMLDecodeError as exc:
        report.could_not_run.append((str(path), f"invalid TOML: {exc}"))
        return None
    project = data.get("project", {})
    if not isinstance(project, dict):
        report.could_not_run.append((str(path), "invalid TOML structure: [project] must be a table"))
        return None
    return project


def _entrypoint_group_tokens(group: object, path: Path, name: str, report: HuntReport) -> set[str]:
    if not isinstance(group, dict):
        report.could_not_run.append(
            (str(path), f"invalid TOML structure: project.entry-points.{name} must be a table")
        )
        return set()
    tokens = set()
    for target in group.values():
        if not isinstance(target, str) or ":" not in target:
            continue
        symbol = target.rsplit(":", 1)[1].strip()
        if symbol:
            # Entry-point attributes such as ``Runner.run`` are loaded from
            # the public root object ``Runner``; the attribute is not a
            # separately defined module-level symbol.
            tokens.add(symbol.split(".", 1)[0])
    return tokens


def _entrypoint_tokens(root: Path, report: HuntReport) -> set[str]:
    """Return reachable symbols from console-scripts and entry-points tables."""
    path = root / "pyproject.toml"
    if not path.is_file():
        return set()
    project = _project_scripts(path, report)
    if project is None:
        return set()

    tokens: set[str] = set()
    scripts = project.get("scripts", {})
    if not isinstance(scripts, dict):
        report.could_not_run.append((str(path), "invalid TOML structure: project.scripts must be a table"))
    else:
        tokens |= _entrypoint_group_tokens(scripts, path, "scripts", report)

    entry_points = project.get("entry-points", {})
    if not isinstance(entry_points, dict):
        report.could_not_run.append((str(path), "invalid TOML structure: project.entry-points must be a table"))
        return tokens
    for name, group in entry_points.items():
        tokens |= _entrypoint_group_tokens(group, path, str(name), report)
    return tokens


# ---------------------------------------------------------------------------
# Engine 1: Symbol Dependency Graph
# ---------------------------------------------------------------------------

@dataclass
class _Graph:
    symbols: list[_Symbol]
    refs_by_file: dict[Path, set[str]]
    dunder_all: set[str]
    module_of: dict[Path, set[str]]  # file -> names defined in it


def _build_graph(src: Path, report: HuntReport) -> _Graph:
    """Parse every ``src/`` file into the symbol/reference graph."""
    symbols: list[_Symbol] = []
    refs_by_file: dict[Path, set[str]] = {}
    dunder_all: set[str] = set()
    module_of: dict[Path, set[str]] = {}
    for path in _py_files(src, report.could_not_run):
        try:
            tree = _parse(path)
            file_symbols, file_all = _module_symbols(tree, path)
            refs = _collect_references(tree)
        except CouldNotRun as exc:
            report.could_not_run.append((str(path), str(exc)))
            continue
        symbols.extend(file_symbols)
        dunder_all |= file_all
        refs_by_file[path] = refs
        module_of[path] = {s.name for s in file_symbols}
    return _Graph(symbols, refs_by_file, dunder_all, module_of)


def _symbol_indegree(name: str, refs_by_file: dict[Path, set[str]]) -> int:
    """Number of files whose reference set contains ``name``."""
    return sum(1 for refs in refs_by_file.values() if name in refs)


def hunt_orphans(src: Path, root_tokens: set[str], graph: _Graph) -> list[Finding]:
    """Engine 1: public symbols with in-degree 0 that no root anchor exempts."""
    findings: list[Finding] = []
    for sym in graph.symbols:
        if sym.name == "main" or sym.name in graph.dunder_all or sym.name in root_tokens:
            continue
        if _symbol_indegree(sym.name, graph.refs_by_file) > 0:
            continue
        rel = _relpath(sym.module, src.parent)
        findings.append(Finding(
            engine="sdg", kind="orphan", ref=sym.name, origin=f"{rel}:{sym.lineno}",
            message=(f"public {sym.kind} {sym.name!r} has in-degree 0 and is not a "
                     "root anchor (CONVICTED_ORPHAN -- reviewable, not auto-deleted)"),
            severity="FAIL",
        ))
    return findings


def _relpath(path: Path, base: Path) -> str:
    """``path`` relative to ``base`` when possible, else its absolute form."""
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return path.as_posix()


# ---------------------------------------------------------------------------
# Engine 2: zombie fixture/helper sweeper
# ---------------------------------------------------------------------------

def _is_fixture(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """True when ``fn`` carries a ``@pytest.fixture`` / ``@fixture`` decorator."""
    for dec in fn.decorator_list:
        target = dec.func if isinstance(dec, ast.Call) else dec
        if isinstance(target, ast.Name) and target.id == "fixture":
            return True
        if isinstance(target, ast.Attribute) and target.attr == "fixture":
            return True
    return False


def _is_autouse_fixture(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """True when a ``@pytest.fixture(autouse=True, ...)`` call carries ``autouse=True``.

    An autouse fixture is applied to every test in its scope without ever
    being named, so "referenced by no test" is its normal, correct state --
    not a zombie signal.
    """
    for dec in fn.decorator_list:
        if not isinstance(dec, ast.Call):
            continue
        for kw in dec.keywords:
            if kw.arg == "autouse" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                return True
    return False


def _is_fixture_data_dir(path: Path, tests: Path) -> bool:
    """True when ``path`` sits under a ``tests/fixtures/`` tree.

    Files there are sample data read as text/AST by other tests (e.g. near-miss
    detector corpora), not pytest test modules -- being unreferenced by name is
    their normal state, not a zombie signal. Scoped narrowly to ``fixtures/``
    so real test modules elsewhere under ``tests/`` are unaffected.
    """
    try:
        parts = path.relative_to(tests).parts
    except ValueError:
        return False
    return "fixtures" in parts[:-1]


def _module_definitions(tree: ast.Module, path: Path) -> list[_Symbol]:
    """Module-level fixtures and helpers, minus the ones pytest discovers itself."""
    found: list[_Symbol] = []
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if _is_fixture(node):
            if not _is_autouse_fixture(node):
                found.append(_Symbol(node.name, path, "fixture", node.lineno))
        elif (
            not node.name.startswith("test")
            and not node.name.startswith("_")
            # pytest_* are plugin hooks auto-discovered by pytest itself
            # (pytest_configure, pytest_collection_modifyitems, ...) -- never
            # referenced by name anywhere, by design, same class as an autouse
            # fixture. Measured on Atlas.
            and not node.name.startswith("pytest_")
        ):
            found.append(_Symbol(node.name, path, "helper", node.lineno))
    return found


def hunt_zombies(
    tests: Path, report: HuntReport, root_conftest: Path | None = None,
) -> list[Finding]:
    """Engine 2: unused test helpers, including a repository-root conftest."""
    definitions: list[_Symbol] = []
    all_refs: set[str] = set()
    paths = _py_files(tests, report.could_not_run)
    if root_conftest is not None and root_conftest.is_file():
        paths.append(root_conftest)
    for path in sorted(set(paths)):
        try:
            tree = _parse(path)
            refs = _collect_references(tree)
        except CouldNotRun as exc:
            report.could_not_run.append((str(path), str(exc)))
            continue
        all_refs |= refs
        if _is_fixture_data_dir(path, tests):
            continue
        definitions.extend(_module_definitions(tree, path))
    findings: list[Finding] = []
    for sym in definitions:
        if sym.name in all_refs:
            continue
        findings.append(Finding(
            engine="zombie", kind="zombie", ref=sym.name,
            origin=f"{_relpath(sym.module, tests.parent)}:{sym.lineno}",
            message=f"{sym.kind} {sym.name!r} in tests is referenced by no test (zombie)",
            severity="FAIL",
        ))
    return findings


# ---------------------------------------------------------------------------
# Engine 3: ghost task / dangling backlog (delegated)
# ---------------------------------------------------------------------------

def hunt_ghost_tasks(root: Path) -> list[Finding]:
    """Engine 3: delegate to dangling_refs' broken-pin + inventory-drift detectors."""
    findings: list[Finding] = []
    delegated = dangling_refs.check_broken_evidence_pins(root)
    delegated += dangling_refs.check_inventory_drift(root)
    for raw in delegated:
        findings.append(Finding(
            engine="ghost_task", kind="ghost_task", ref=raw["ref"],
            origin=raw["origin"], message=raw["message"],
            severity=raw.get("severity", "FAIL"),
        ))
    return findings


# ---------------------------------------------------------------------------
# Engine 4: tombstone / slop remnant
# ---------------------------------------------------------------------------

def _checkouts_anidados(root: Path) -> list[Path]:
    """Directorios bajo `root` que son OTRO checkout de git (llevan su propio `.git`).

    Un worktree anidado es otro SUJETO, no parte de este. Medido el 2026-09-06: el
    push de 5.9.0 lo bloqueo `deadcode-gate` con
    `.claude/worktrees/optimistic-tesla-6e3530/.simplecode/tombstones.yaml:13` --
    4 de los 15 YAML escaneados pertenecian al espacio de trabajo de otra sesion,
    que este repo ignora en `.git/info/exclude` y este organo caminaba igual.

    Se detecta por ESTRUCTURA (un `.git` propio), no por una lista de nombres:
    `corruption_guard` sufrio esta misma clase el 2026-08-26 y se arreglo alli con
    un caso especial para `.claude`, asi que el siguiente sitio donde alguien monte
    un checkout volveria a caer. Un `.git` debajo de la raiz es la definicion de
    "esto lo juzga otro".
    """
    anidados = []
    for git in root.rglob(".git"):
        padre = git.parent
        if padre.resolve() != root.resolve():
            anidados.append(padre.resolve())
    return anidados


def _fuera_de_otro_checkout(path: Path, anidados: list[Path]) -> bool:
    resuelta = path.resolve()
    return not any(resuelta.is_relative_to(a) for a in anidados)


def _load_catalog(root: Path, report: HuntReport) -> list[str]:
    """Deprecated names/flags/namespaces from ``.simplecode/tombstones.yaml``.

    Absent catalog -> empty list (the engine yields nothing, no crash). A
    present-but-unreadable or malformed catalog is fail-closed as COULD_NOT_RUN.
    """
    path = root / _CATALOG_REL
    if not path.is_file():
        return []
    try:
        text = _read_text(path)
    except CouldNotRun as exc:
        report.could_not_run.append((str(path), str(exc)))
        return []
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        report.could_not_run.append((str(path), f"malformed tombstone catalog: {exc}"))
        return []
    if data is None:
        return []
    if isinstance(data, dict):
        data = data.get("tombstones", data.get("names", []))
    if not isinstance(data, list):
        report.could_not_run.append((str(path), "tombstone catalog is not a list of names"))
        return []
    return [str(item) for item in data if str(item).strip()]


def _tombstone_scan_targets(root: Path, report: HuntReport) -> list[Path]:
    """Every file the tombstone engine is willing to READ: src/ and tests/
    Python, plus the Markdown/YAML the retirement record lives in.

    Split out of ``hunt_tombstones`` because "which files does this engine
    look at" is a different question from "which mentions do not count" and
    from "find the dead names" -- the three used to be one loop, and the
    checkout filtering below (``_fuera_de_otro_checkout``) is the part that
    silently decides whether a nested agent worktree gets swept too.
    """
    targets = _py_files(root / "src", report.could_not_run) + _py_files(root / "tests", report.could_not_run)
    anidados = _checkouts_anidados(root)
    for suffix in ("*.md", "*.yaml", "*.yml"):
        targets += sorted(
            p for p in root.rglob(suffix)
            if p.is_file() and ".git" not in p.parts
            and _fuera_de_otro_checkout(p, anidados)
        )
    return sorted(set(targets))


def _tombstone_mention_is_record(path: Path, root: Path, catalog_path: Path) -> bool:
    """True when a dead name inside ``path`` is the RECORD of the retirement
    rather than a remnant of it.

    Three distinct exemptions, kept together because they answer one question
    and each would otherwise read as an unexplained ``continue``:
    the catalog naming its own dead names; append-only history (shared
    predicate ``dangling_refs._is_exempt_history``, not a second copy of the
    list); and the test that PROVES the retirement holds.
    """
    if path.resolve() == catalog_path:
        return True
    rel = _relpath(path, root)
    return dangling_refs._is_exempt_history(rel) or rel in _TOMBSTONE_TEST_EXEMPT


def hunt_tombstones(root: Path, report: HuntReport) -> list[Finding]:
    """Engine 4: retired-rule count (delegated) + catalog remnant scan (new).

    Append-only history is skipped via ``dangling_refs._is_exempt_history``
    -- the same predicate, not a second copy of the list. Measured 2026-09-01
    while retiring the dead predecessor-repo pointers: all 6 live mentions of
    the retired kit's path sit in ``docs/decisions/`` and
    ``docs/domain_knowledge/``, the two harvest-output folders whose whole
    purpose is to cite another project's paths. Without this skip the catalog
    could never hold a retired repo's name -- a remnant gate that cannot name
    the biggest remnant is not a gate.
    """
    report.retired_rules = sorted(dangling_refs.get_retired_rules(root))
    catalog = _load_catalog(root, report)
    if not catalog:
        return []
    findings: list[Finding] = []
    catalog_path = (root / _CATALOG_REL).resolve()
    for path in _tombstone_scan_targets(root, report):
        if _tombstone_mention_is_record(path, root, catalog_path):
            continue
        try:
            text = _read_text(path)
        except CouldNotRun as exc:
            report.could_not_run.append((str(path), str(exc)))
            continue
        for line_no, line in enumerate(text.splitlines(), start=1):
            for dead in catalog:
                if dead in line:
                    findings.append(Finding(
                        engine="tombstone", kind="tombstone", ref=dead,
                        origin=f"{_relpath(path, root)}:{line_no}",
                        message=f"deprecated {dead!r} still mentioned after retirement",
                        severity="FAIL",
                    ))
    return findings


# ---------------------------------------------------------------------------
# Engine 5: Over-engineering Density Index
# ---------------------------------------------------------------------------

def _module_complexity_and_loc(tree: ast.AST, text: str) -> tuple[int, int]:
    """Summed cyclomatic complexity of every function, and non-blank LoC."""
    complexity = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            complexity += _function_complexity(node)
        elif isinstance(node, ast.AsyncFunctionDef):
            # _function_complexity only ast.walk()s the node body; an async def
            # has the same shape, so it is measured identically.
            complexity += _function_complexity(cast(ast.FunctionDef, node))
    loc = sum(1 for line in text.splitlines() if line.strip())
    return complexity, loc


def hunt_ods(src: Path, graph: _Graph, report: HuntReport) -> list[Finding]:
    """Engine 5: high-complexity, low-traffic modules (ODS warnings)."""
    findings: list[Finding] = []
    for path in _py_files(src):
        try:
            text = _read_text(path)
            tree = ast.parse(text, filename=str(path))
        except (CouldNotRun, SyntaxError, ValueError):
            # Already recorded by _build_graph; ODS simply skips it.
            continue
        complexity, loc = _module_complexity_and_loc(tree, text)
        indegree = _module_indegree(path, graph)
        ods = loc * complexity / (indegree + 1)
        if complexity >= ODS_MODULE_COMPLEXITY_WARN and indegree <= ODS_UNIT_INDEGREE:
            findings.append(Finding(
                engine="ods", kind="ods", ref=_relpath(path, src.parent),
                origin=_relpath(path, src.parent),
                message=(f"ODS={ods:.0f} (LoC={loc} x complexity={complexity} / "
                         f"in-degree+1={indegree + 1}): high complexity, "
                         f"{'zero' if indegree == 0 else 'unit'} import traffic"),
                severity="WARN",
            ))
    return findings


def _module_indegree(path: Path, graph: _Graph) -> int:
    """Number of OTHER src files that reference any symbol defined in ``path``."""
    own = graph.module_of.get(path, set())
    if not own:
        return 0
    return sum(
        1 for other, refs in graph.refs_by_file.items()
        if other != path and own & refs
    )


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def hunt(
    root: Path,
    include_tests: bool = False,
    tombstones: bool = False,
) -> HuntReport:
    """Run every engine over ``root`` and return one consolidated report."""
    report = HuntReport()
    src = root / "src"
    graph = _build_graph(src, report)
    root_tokens = (
        _config_tokens(root, report)
        | _tests_reference_tokens(root, report)
        | _entrypoint_tokens(root, report)
    )

    # The dependency graph and root anchors form one verdict surface. If any
    # input to it could not be read, a partial graph can mislabel reachable
    # symbols as orphans; report the instrument failure without convictions.
    if report.could_not_run:
        report.engines_run["sdg"] = False
    else:
        report.findings.extend(hunt_orphans(src, root_tokens, graph))
        report.engines_run["sdg"] = True

    if include_tests:
        report.findings.extend(hunt_zombies(root / "tests", report, root / "conftest.py"))
    report.engines_run["zombie"] = include_tests

    report.findings.extend(hunt_ghost_tasks(root))
    report.engines_run["ghost_task"] = True

    if tombstones:
        report.findings.extend(hunt_tombstones(root, report))
    report.engines_run["tombstone"] = tombstones

    if report.could_not_run:
        report.engines_run["ods"] = False
    else:
        report.findings.extend(hunt_ods(src, graph, report))
        report.engines_run["ods"] = True

    return report


def _tests_reference_tokens(root: Path, report: HuntReport) -> set[str]:
    """Every name referenced by pytest's root and tests conftest files."""
    tokens: set[str] = set()
    paths = _py_files(root / "tests", report.could_not_run)
    root_conftest = root / "conftest.py"
    if root_conftest.is_file():
        paths.append(root_conftest)
    for path in sorted(paths):
        try:
            tokens |= _collect_references(_parse(path))
        except CouldNotRun as exc:
            report.could_not_run.append((str(path), str(exc)))
    return tokens


# ---------------------------------------------------------------------------
# Materialization
# ---------------------------------------------------------------------------

_MATERIALIZE_VERIFICATION = "python3 -m simplecode.guards.orphan_hunter --root . --gate"


def materialize(report: HuntReport, root: Path) -> Path | None:
    """Write gating findings to ``tasks/backlog/DEBT-DEADCODE-*.md`` (GS2-214).

    Returns the task path, or None when there is nothing gating to record.
    """
    gating = report.gating
    if not gating:
        return None
    task_id = "DEBT-DEADCODE-ORPHANS"
    task_file = root / "tasks" / "backlog" / f"{task_id}.md"
    lines = "\n".join(
        f"- [{f.kind}] {f.ref} -- {f.message} (in {f.origin})" for f in gating
    )
    content = (
        ledger_schema.render_frontmatter(
            id=task_id, title="Dead code and slop forensics (ADR-0004 / Orphan Hunter)",
            status="open", severity="P1", satd_family="DEAD_CODE_DEBT",
            close_check={"cmd": _MATERIALIZE_VERIFICATION, "expect": "exit_zero"},
            risk_score=7, blast_radius="MEDIUM",
            lifespan="introduced", tag="BUG",
        ) + "\n"
        "# Dead Code & Slop Forensics (ADR-0004 / Orphan Hunter)\n\n"
        "Convicted orphans and ghost tasks found by the Symbol Dependency Graph "
        "and delegated dangling-reference detectors. These are REVIEWABLE "
        "findings, not auto-deletions -- confirm each before removing.\n\n"
        "<!-- findings:start -->\n"
        f"{lines}\n"
        "<!-- findings:end -->\n\n"
        "```json queue-job\n"
        "{\n"
        f'  "name": "remediate_{task_id.lower()}",\n'
        f'  "command": "{_MATERIALIZE_VERIFICATION}",\n'
        f'  "artifact": "tasks/backlog/{task_id}.md"\n'
        "}\n"
        "```\n"
    )
    return write_text_durable(task_file, content)


# ---------------------------------------------------------------------------
# Reporting + CLI
# ---------------------------------------------------------------------------

def _report_json(report: HuntReport, root: Path) -> dict:
    counts = {
        kind: len(report.of_kind(kind))
        for kind in ("orphan", "zombie", "ghost_task", "tombstone", "ods")
    }
    counts["could_not_run"] = len(report.could_not_run)
    return {
        "root": str(root),
        "engines_run": report.engines_run,
        "counts": counts,
        "retired_rules": report.retired_rules,
        "findings": [f.as_dict() for f in report.findings],
        "could_not_run": [{"path": p, "reason": r} for p, r in report.could_not_run],
        "ok": report.ok,
    }


def _print_human(report: HuntReport, root: Path, *, gate: bool = False) -> None:
    """Print the report. ``gate`` says whether THIS invocation blocks on it.

    The verdict word must name what this run does, not what some other run
    would do: without ``--gate`` the exit code is 0 whatever is found, so the
    word is ``ADVISORY``, never ``BLOCKED``. Default False = the CLI default.
    """
    for kind in ("orphan", "zombie", "ghost_task", "tombstone", "ods"):
        rows = report.of_kind(kind)
        print(f"[orphan-hunter] {kind}: {len(rows)} finding(s)")
        for f in rows:
            print(f"  [{f.severity}] ({f.engine}) {f.ref} -- {f.message} (in {f.origin})")
    if report.retired_rules:
        print(f"[orphan-hunter] retired rules honored: "
              f"{', '.join(f'#{r}' for r in report.retired_rules)}")
    # The zeros are printed: what could not run goes out ALWAYS, findings or not.
    print(f"[orphan-hunter] could_not_run: {len(report.could_not_run)}")
    for path, reason in report.could_not_run:
        print(f"  [COULD_NOT_RUN] {path} -- {reason}")
    if report.ok:
        verdict = "OK"
    elif gate:
        verdict = "BLOCKED"
    else:
        verdict = "ADVISORY (would block under --gate)"
    print(f"[orphan-hunter] {verdict}: {len(report.gating)} gating finding(s), "
          f"{len(report.could_not_run)} could-not-run")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Consolidated dead-code & slop forensics (ADR-0004)."
    )
    parser.add_argument("--root", type=Path, default=Path("."), help="Repository root")
    parser.add_argument("--gate", action="store_true",
                        help="Exit 1 on any orphan, ghost task, tombstone hit, zombie, or "
                             "could-not-run. WITHOUT this flag the run is consultative: it "
                             "reports and exits 0, and says ADVISORY instead of BLOCKED.")
    parser.add_argument("--json", action="store_true", help="Emit a structured JSON report")
    parser.add_argument("--tombstones", action="store_true",
                        help="Run the tombstone catalog engine (.simplecode/tombstones.yaml)")
    parser.add_argument("--include-tests", action="store_true",
                        help="Run the zombie fixture/helper sweeper over tests/")
    parser.add_argument("--materialize", action="store_true",
                        help="Write gating findings to tasks/backlog/DEBT-DEADCODE-*.md")
    args = parser.parse_args(argv)

    root = args.root.resolve()
    report = hunt(root, include_tests=args.include_tests, tombstones=args.tombstones)

    if args.materialize:
        written = materialize(report, root)
        if written is not None:
            print(f"[orphan-hunter] materialized {written}")

    if args.json:
        print(json.dumps(_report_json(report, root), indent=2, ensure_ascii=False))
    else:
        _print_human(report, root, gate=args.gate)

    if args.gate and not report.ok:
        # --json carries the verdict machine-readably in "ok"; the tagged
        # verdict line below is for the human/hook-runner (text) path only,
        # so it must not appear mixed into stdout JSON.
        if not args.json:
            if report.gating:
                first = report.gating[0]
                print(
                    f"[deadcode-gate] FAIL: {len(report.gating)} simbolo(s)/hallazgo(s) sin consumidor; "
                    f"primero {first.origin} {first.kind} {first.ref}"
                )
            else:
                first_path, first_reason = report.could_not_run[0]
                print(
                    f"[deadcode-gate] COULD_NOT_RUN: {len(report.could_not_run)} archivo(s) no analizados; "
                    f"primero {first_path} ({first_reason})",
                    file=sys.stderr,
                )
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
