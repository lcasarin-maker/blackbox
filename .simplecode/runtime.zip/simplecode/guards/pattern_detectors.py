"""Unified AST/regex vice-detector registry: source text -> bool per vice.

# simplecode:corpus sus constantes SON el vocabulario del vicio; el patron que define eval coincide con el patron de eval

Flags bad practice already present in code (hardcoded secrets, dangerous
sinks, placeholders, premature closure, blind trust in LLM output, insecure
defaults, destructive commands without dry-run, stubs-as-architecture,
test-theater patterns, etc.) so it can be caught before it ships. Detectors
are pure functions (source text in, bool out); PATTERN_DETECTORS is the
single registry of (function, key, message) consumed by callers -- one
entry per distinct vice.
"""

import ast
import copy
import functools
import io
import tokenize
import re
from collections.abc import Callable, Iterator, Sequence


def _ticket_justification_re(tag: str) -> re.Pattern[str]:
    """A same-line `# <tag>: <reason> -- <TICKET>` escape comment, requiring
    a real, checkable ticket citation (ADR/DGX/SC/DEBT-<id>).

    Shared by every detector that grew this exact escape hatch after a
    fleet false-positive incident (`destructive-input`, `noqa`,
    `blocking-sleep`, `unmanaged-open`, ...): each needed its own TAG word
    but the shape -- and the requirement that a bare "-- fixed later" not
    count -- is identical, so the four near-duplicate regex literals this
    replaced (found 2026-08-28 during a dedup pass) are now one definition.
    """
    return re.compile(
        rf"""#\s*{tag}(?::\s*|\s+)[^\n]*\b(?:ADR|DGX|SC|DEBT)-[0-9A-Za-z_-]+\b""",
        re.I,
    )

# Matches a real `eval(...)` call while excluding a method call (`x.eval()`,
# common in PyTorch/sklearn/keras for eval-MODE, not code execution) and a
# `def eval(...)` definition (needed to double an API that has one, e.g. a
# test mock). Python forbids variable-width lookbehind, but `def ` is a fixed
# four characters, so this lookbehind is expressible.
UNSAFE_EVAL = r"(?<!\.)(?<!def )\beval\s*\(|\b(?:builtins|__builtins__)\.eval\s*\("

# --- shared regex constants ---

# Unchanged from the version that scanned the fleet, except that the VALUE is
# now captured so the caller can weigh it. Widening the key leftwards inside the
# regex (`[\w.\-]*(?:password|...)`) was tried and REVERTED: unanchored, it
# re-scanned a name of unbounded length from every start position, and the angry
# layer's 200KB single line took it from milliseconds to minutes -- the same
# quadratic trap already documented on _DSN below. The left context is read off
# the line instead, through a fixed window, in _key_at().
# The tail after the keyword closes the `SECRET_KEY` hole (keyword, THEN more
# name), and it is deliberately not `\w*`. Measured 2026-08-17 on the fleet: a
# bare `\w*` tail took hits from 4 to 7 and all 3 new ones were false --
# `tokenUrl = "/api/auth/login"`, `token_savings = "Reduced duplicated
# explanation."`, `_CHECKPOINT_FOR_TOKEN_CLASSIFICATION = "dbmdz/bert-large-..."`.
# The vice is a name whose keyword is the HEAD NOUN, not one that merely contains
# it, so the tail must itself be credential vocabulary. With that: 4 -> 4 hits,
# zero new, zero lost, and the hole closed on SECRET_KEY / API_KEY_ID.
_SECRET = re.compile(
    r"""(?P<key>(?:password|passwd|pwd|secret|api[_-]?key|token)"""
    r"""(?:[_-](?:key|token|secret|password|passwd|pwd|id))?)"""
    r"""\s*=\s*['"](?P<value>[^'"]*)['"]""",
    re.I,
)
# How far left of the keyword the full field name is read. A name longer than
# this before `password` does not exist in practice; the bound is what keeps the
# lookup O(1) per match instead of O(line length).
_KEY_PREFIX_WINDOW = 32
_NAME_TAIL = re.compile(r"[\w.\-]*$")
# Any key naming a hash holds a digest, not a credential: hashed_password,
# password_hash, token_hash.
#
# The negative lookbehind excludes "un"-negated names: `unhashed_password`
# announces the value is explicitly NOT a digest -- a real plaintext secret
# a bare `hash` substring match silently acquitted (found 2026-08-28
# reviewing this same detector: "unhashed" contains "hash" as a literal
# substring, so `unhashed_password="n3wSecr3t..."` was reading as a digest
# field and never convicted). `password_hash`/`hashed_password`/`token_hash`
# all still match since "hash" isn't preceded by "un" there.
_HASH_FIELD = re.compile(r"(?<!un)hash", re.I)
# Minimum length of a usable credential. Taken from the repo's own vc-095
# (`{8,}`), not invented here. Below it live the dummies a local
# OpenAI-shaped server demands and ignores -- `api_key="ollama"`,
# `api_key="api_key"`, `hashed_password="x"` -- and the tail of a regex
# vocabulary that HUNTS the vice: `[r"password=", r"token="]` captures `, r`.
_SECRET_MIN_LEN = 8
# Markers that make the VALUE announce itself as a fixture. Each one is either
# inherited from the sibling organ dangerous_patterns._PLACEHOLDER_MARKERS or
# was measured in a fleet hit, and each is too specific to appear inside a real
# credential. "example" is deliberately NOT here: AWS's documented
# AKIAIOSFODNN7EXAMPLE is the red case smoke_all pins, and suppressing it would
# narrow the detector into an instrument that catches nothing.
_SECRET_PLACEHOLDERS = (
    "changeme", "change_me", "change-me", "placeholder", "dummy", "replace_me",
    "local-only",   # api_key="local-only" (aequitas_os prompt_optimization_service.py:131)
    "test-only",    # hashed_password="test-only-hash" (test_collection_agent.py:105)
    "unit-test",    # secret = "unit-test-docusign-secret" (test_e1_security.py:71)
    "fake-", "fake_",  # hashed_password="fake-hashed-password" (conftest.py:213)
)
# The scheme repeat is BOUNDED. Unbounded (`*`) it re-scanned the rest of the
# line from every start position, which is quadratic and measured at 4.6s on a
# 40KB line and 118s on a 200KB one -- a minified bundle or a base64 blob would
# hang the pre-commit hook outright. The longest IANA-registered scheme is well
# under 16 characters, so the bound costs no real match.
_DSN = re.compile(r"""[a-z][a-z0-9+.\-]{0,15}://[^'"\s/]{1,512}:[^'"\s/@]{1,512}@""", re.I)
# The OTHER shape a connection string takes: `key=value;` parameters instead of
# a URL. Found because a real password walked past every detector --
# `cuenza/migration_tools/migrate_data.py:12`, inside a parenthesised
# concatenation where each physical line is its own literal:
#
#     mssql_conn_str = (
#         "DRIVER={SQL Server};"
#         ...
#         "PWD=CpaLegacy_2026!;"      <-- no assignment, no `://`, invisible
#     )
#
# _DSN needs `://user:pass@` and _SECRET needs an assignment whose left side is
# the key, so neither could see it. The value must be non-trivial and not a
# placeholder: `PWD=;`, `PWD={pwd}`, `PWD=%s` and `PWD=$PASSWORD` are how a real
# template writes it, and every one of them stays silent.
#
# Measured before shipping: keyed on the line alone this fired on 22 new fleet
# files and 17 were FALSE -- `password=POSTGRES_PASSWORD`, `password=pwd)`,
# `password=None):`, `password = os.getenv(`. A keyword argument is not a
# credential. So the match must live INSIDE a string literal that also carries
# another connection-string parameter, which is what makes it a connection
# string rather than an assignment. AST, not lines, because implicit
# concatenation folds the parenthesised block above into ONE literal that holds
# DRIVER, SERVER, DATABASE, UID and PWD together -- while each physical line
# holds only one of them.
_CONN_PARAM_CRED = re.compile(
    r"""\b(?:PWD|PASSWORD|PASSWD)\s*=\s*(?![;'"\s{$%<>])[^;'"\s]{4,}""", re.I)
_CONN_PARAM_OTHER = re.compile(
    r"""\b(?:DRIVER|SERVER|DATABASE|DBNAME|HOST|PORT|UID|USER|INITIAL\s+CATALOG)\s*=""",
    re.I)


def _conn_string_credential(tree: ast.AST) -> "ast.Constant | None":
    """The string literal that is a connection string carrying a password, or None.

    Returns the NODE rather than a bool so `hardcoded_secret_findings` can name
    the line. Reported by descargaSAT 2026-09-05: this detector fired with
    `line: 0` and the message "<detector> fired", and locating the actual hit
    cost them six probes -- two of which measured the wrong file.

    Docstrings are excluded: a connection string shown in documentation is an
    example, the same treatment the line-based path gives prose.
    """
    docstrings: set[int] = set()
    for node in _walk(tree):
        body = getattr(node, "body", None)
        if isinstance(body, list) and body and isinstance(body[0], ast.Expr):
            first = body[0].value
            if isinstance(first, ast.Constant) and isinstance(first.value, str):
                docstrings.add(id(first))
    for node in _walk(tree):
        if (isinstance(node, ast.Constant) and isinstance(node.value, str)
                and id(node) not in docstrings
                and _CONN_PARAM_CRED.search(node.value)
                and _CONN_PARAM_OTHER.search(node.value)):
            return node
    return None
# The `=` must be an ASSIGNMENT, never the tail of a comparison: `==` contains
# `=`, so the unanchored version convicted `if key == "REPLACE_ME":` -- code that
# HUNTS placeholders instead of shipping one, which is the opposite of the vice.
# Caught by the labeled near-miss fixture VC-027.
_PLACEHOLDER = re.compile(  # simplecode:corpus vocabulary for untracked_prototype
    r"""(?<![=!<>])=(?!=)\s*['"]\s*"""
    r"""(REPLACE_ME|CHANGE_?ME|YOUR_[A-Z_]+|X{4,}|TODO|FIXME|placeholder)\s*['"]""",
    re.I,
)
# A marker needs marker punctuation, not just the bare word, since "TODO" can
# be an ordinary word in non-English prose comments. `TODO:`, `TODO(`,
# `TODO -` and `TODO!` match; bare "todo" in prose does not.
_TODO_MARK = re.compile(  # simplecode:corpus vocabulary for untracked_prototype
    r"#.*\b(TODO|FIXME|HACK|XXX|PROTOTYPE|TEMP)\s*[:(\-!]"
)
# Two narrowings, each measured over the fleet (see destructive_without_dryrun):
#
# `-delete` is the find(1) PREDICATE: one dash, preceded by whitespace or a
# quote. Unanchored it also matched the tail of the word `soft-delete` -- which
# names the exact OPPOSITE of the vice, a row marked and kept -- and the long
# option `--delete`, where the operator typing the flag IS the confirmation.
#
# `DROP` alone convicted the idempotent-DDL preamble `DROP <object> IF EXISTS`
# + `CREATE <object>`: dropping an INDEX, TRIGGER, POLICY, CONSTRAINT, ROLE or
# VIEW destroys no row and is how a bootstrap is made re-runnable. Only the
# object kinds that take DATA with them are kept. Known hole, deliberate: the
# SQL keywords stay case-SENSITIVE (as before this fix), so `drop table foo`
# in lowercase is missed -- adding re.I would ADD hits and could not be proved
# a subset of the previous behaviour in the same measurement.
_DESTRUCTIVE = re.compile(
    r"(?<![-\w])-delete\b"
    r"|rm\s+-rf"
    r"|\bDROP\s+(?:TABLE|DATABASE|SCHEMA)\b"
    r"|\bTRUNCATE\b"
    r"|git\s+reset\s+--hard"
)
_DRYRUN = re.compile(r"(-print\b|--dry-run\b|\bEXPLAIN\b|\becho\b)")
# Same shape as _SLEEP_JUSTIFICATION / _UNMANAGED_OPEN_JUSTIFICATION: a real
# ticket, never a bare "because". File-wide, not same-line, matching this
# detector's own existing granularity -- _DRYRUN itself is already a
# whole-file search, not tied to the specific destructive call it excuses.
_DESTRUCTIVE_INPUT_JUSTIFICATION = _ticket_justification_re("destructive-input")
# A destructive-looking string literal fed to one of these inside a test IS a
# real execution, not adversarial test data -- see _adversarial_test_data_ids.
# ATTR-only: a bare `run(...)`/`call(...)` is exactly as likely to be the
# validator under test as `subprocess.run`/`subprocess.call`, so only the
# attribute form (something.run(...)) counts.
_DESTRUCTIVE_ATTR_EXECUTORS = frozenset(
    {"system", "run", "call", "Popen", "check_call", "check_output",
     "execute", "executemany"}
)
_DESTRUCTIVE_BARE_EXECUTORS = frozenset({"eval", "exec"})
_VERSION_LITERAL = re.compile(
    r"""(?im)(?:__version__|version)\s*[:=][^\n\r]{0,40}?['"]?(\d+\.\d+\.\d+(?:[-+][^\s'"]+)?)['"]?|##\s+(\d+\.\d+\.\d+(?:[-+][^\s]+)?)"""
)
# Narrowed to recv/acquire/wait: a bare `join(` matches os.path.join()/
# str.join() far more often than Thread.join()-style blocking, so it is
# excluded to avoid systematic false positives.
_BLOCKING_CALL = re.compile(r"\b(recv|acquire|wait)\s*\(", re.I)
_LIVENESS_MARK = re.compile(
    r"\b(?:settimeout|timeout\s*=|heartbeat|wait_for|deadline)\b", re.I
)
# `async with x.pool.acquire()` / `async with x.acquire()`: the object
# `.acquire()` returns here is an async context manager (asyncpg-style
# connection pool), not a raw lock/semaphore -- entering it is a coroutine
# yield bounded by the pool's own size, never the thread-blocking OS wait
# this detector exists to catch. Measured on the fleet (2026-08-16): 12
# identical occurrences in one asyncpg-backed storage class, all false.
_ASYNC_POOL_ACQUIRE = re.compile(r"\basync\s+with\b[^\n]{0,80}?\.acquire\s*\(", re.I)
# A `.wait()` preceded within a few lines by a SIGKILL/killpg of the SAME
# process is reaping an already-dying child, not blocking on an external
# event: SIGKILL cannot be intercepted, deferred, or ignored by the target,
# so the wait it precedes is bounded by definition. Measured on the fleet
# (2026-08-16): a chaos/kill-test harness that SIGKILLs its own child and
# immediately reaps it -- the exact idiom this excludes.
_KILL_THEN_WAIT = re.compile(
    r"\b(?:SIGKILL|killpg)\b[^\n]*\n(?:[^\n]*\n){0,3}?[^\n]*?\bwait\s*\(", re.I
)
# `lock.acquire(blocking=False)`: a NON-blocking acquisition cannot block by
# construction -- it returns True/False immediately and never waits. This is
# not a bounded wait (which is what _LIVENESS_MARK's vocabulary attests to);
# it is the ABSENCE of a wait, so no timeout/heartbeat token will ever appear
# beside it. `\s*` spans newlines, so the argument split across lines matches
# too. Measured on the fleet (2026-08-17, all .py under the 11 repos, 2326
# files): one file fired, and it was exactly this idiom -- an Atlas test
# asserting a service's "busy" contract with `_EN_CURSO.acquire(blocking=False)`.
# Zero tracked files of the fleet contain `blocking=False` at all, so this
# narrowing releases nothing that was being caught.
_NONBLOCKING_ACQUIRE = re.compile(r"\bacquire\s*\(\s*blocking\s*=\s*False\b", re.I)
_UNSTABLE_IMPORT = re.compile(
    r"\bfrom\s+(experimental|unstable|beta|volatile)(?:[\.\w]*)\s+import\b|\bimport\s+(experimental|unstable|beta|volatile)\b",
    re.I,
)
_VERSIONED_IDENTIFIER = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*(?:_v\d+|V\d+)\b")
_PROMPT_INJECTION = re.compile(r"agent\.run\([^)]*\+\s*[A-Za-z_][A-Za-z0-9_]*", re.S)
_AGENT_EDIT = re.compile(r"\b(agent_[A-Za-z0-9]+)\.edit\((['\"])([^'\"]+)\2\)", re.I)
_MODEL_OUTPUT = re.compile(r"\bmodel\.generate(?:_json)?\s*\(", re.I)
_DANGEROUS_SINK = re.compile(
    r"\b(?:cursor\.execute|execute|os\.system|subprocess\.(?:run|call|Popen)|exec|innerHTML)\s*\("
    rf"|{UNSAFE_EVAL}",
    re.I,
)
_OUTPUT_GUARD = re.compile(
    r"\b(?:validate_schema|parameteri[sz]e|escape|allowlist|sanitize|safe_)\b", re.I
)
_SED_STRUCT = re.compile(r"\b(sed|awk)\b[^\n]*\.(json|ya?ml|toml|xml|ini)\b", re.I)
# `debug=True` deliberately NOT a branch here (found 2026-08-28, dedup
# pass): optimistic_config's own docstring cites `app.run(debug=True,
# port=5000)` as its canonical real-world hit, via `_OPTIMISTIC_DEBUG`
# below -- every insecure_defaults `debug=True` hit already double-fired
# optimistic_config under a second vice name for the same one finding.
# optimistic_config owns debug/testing-flag findings; this stays the
# general security-misconfig bucket (verify=False, CORS, md5, bind-all).
_INSECURE_DEFAULT = re.compile(
    r"""(verify\s*=\s*False|origins\s*=\s*['"]\*['"]|hashlib\.md5\(|host\s*=\s*['"]0\.0\.0\.0['"])"""
)
_OPTIMISTIC_DEBUG = re.compile(r"(?:DEBUG|TESTING)\s*=\s*True", re.IGNORECASE)
# The secret-shaped half used to be a bare `NAME = ['"]` regex -- any quote
# after those four names, full stop. Measured on the live fleet with
# distinct_hits (2026-08-16): 30 files, 29 false positives, and every one of
# them is a shape hardcoded_secret's `_is_credential_literal` already knows
# how to acquit (digest column, self-naming local-model dummy, a guard's own
# vocabulary of the vice, a fixture marker, an `allow-secret` escape). Two
# detectors had independently drifted from the one spec (rules/vices.yaml
# vc-095 already carries the 8-char floor; the Python `hardcoded_secret` was
# repaired to match it in 948e0d6 the same day). Reusing that already-tested
# predicate here is Reuse (ponytail rung 2), not a second detector:
# optimistic_config keeps its own regex, its own four-name vocabulary, and its
# own verdict -- it borrows only the is-this-actually-usable check. See
# tests/fixtures/near_miss/VC-095.py, now also pinned to this detector.
_OPTIMISTIC_SECRET = re.compile(
    r"""(?P<key>DATABASE_URL|API_KEY|SECRET_KEY|PASSWORD)"""
    r"""\s*=\s*['"](?P<value>[^'"]*)['"]""",
    re.IGNORECASE,
)
# io_without_validation used to be three regexes over the whole file text
# (_EXTERNAL_IO / _IO_SINK / _IO_VALIDATION). They are gone: the word "argv"
# anywhere -- a docstring, a parameter name, a generated driver inside a string
# literal -- plus a `subprocess.run([...])` anywhere else convicted the file,
# and the only acquittal was an English magic word (`validate_`, `safe_`) that
# a Spanish-language fleet never writes. Measured on the fleet (2898 .py,
# distinct_hits): 18 files fired, 18 were false positives. See the AST version
# below and tests/fixtures/near_miss/VC-IOV.py.
_BLANKET_WARN = re.compile(r"""filterwarnings\(\s*['"]ignore['"]\s*\)""")
_NOSEMGREP = re.compile(r"#\s*nosemgrep\b(?::\s*[\w.-]+)?(.*)$", re.MULTILINE)
# _ABS_PATH murió con el fallback line-level de hardcoded_path: desde que
# _parse levanta UnparseableSource, ese detector nunca ve texto sin árbol, así
# que la variante de regex sobre líneas quedó sin llamador. La nota de calibración
# sigue valiendo para _ABS_PATH_VALUE, que hereda el mismo (?!\{).
# The (?!\{) excludes an f-string placeholder sitting immediately after the
# prefix -- `f"/home/{os_user}/..."` is not a hardcoded username, it is a
# template whose value comes from a variable at call time. Measured on the
# fleet (2026-08-16, 33 distinct hits, hardcoded_path): 2 of 18 false
# positives were exactly this shape (Atlas playbooks/station-connect-two-
# stations/assets/cx8_setup.py:114 and playbooks/multi-sparks-through-switch/
# .../spark_cluster_setup.py:352, both a remote homedir built from a runtime
# username, not a machine-specific literal). See
# tests/fixtures/near_miss/HP-001.py. The other 16 false positives (config
# defaults pointing at OS-standard install dirs, test fixtures that never
# touch a real filesystem, meta lists of path markers used as search
# patterns, and a skipif-guarded corpus path) need context this line-level
# regex cannot see without becoming an AST pass of its own -- left open, not
# papered over.
# Measured over 2,899 live fleet files: the shipped pattern's ENTIRE catch was
# `shutdown(`, and 7 of 7 hits were false -- HTTPServer.shutdown(),
# ThreadPoolExecutor.shutdown(wait=False), BackgroundScheduler.shutdown(),
# and one `async def shutdown():` that was a definition, not even a call.
# Lifecycle teardown destroys no data. The other three branches could never
# fire as written: `destroy_\s*\(` needs the literal `destroy_(`, and `rm -rf`
# is never followed by `(` -- with `shutdown` removed the old pattern scored 0
# hits on the whole fleet, so every branch was either noise or dead.
# Shell-level `rm -rf` already belongs to destructive_without_dryrun
# (_DESTRUCTIVE above); this detector keeps only what is its own -- a *call*
# that drops a data store. The verb+noun pair is what separates the vice from
# teardown: `destroy_process_group()` (torch teardown, measured in the fleet)
# is not `destroy_volume()`. `(?<!def )` keeps a definition of such a helper
# from being convicted; the vice is the ungated call site.
#
# The noun list is deliberately WHOLE-STORE, not DDL. A first attempt allowed
# `table|tables|schema|index|collection` and went from 7 fleet hits to 95: every
# added one an alembic `op.drop_table()`/`op.drop_index()` inside a migration's
# downgrade(), which is the reviewed, reversible mechanism for exactly this and
# not an unconfirmed act. `collection` alone still added two live files
# (Atlas/rag/qdrant_manager.py delete_collection()), so it is left out too --
# judged, not shipped: any hit the previous pattern did not have is a
# regression, and a detector that grows its catch by convicting migrations has
# learned nothing from the shutdown() lesson above.
# The gate was a single hardcoded name, `confirm_with_user`, which exists in no
# file of simplecode or the fleet except this line: a deletion gated by
# click.confirm() or ask_for_confirmation() was convicted anyway, and no code
# could ever satisfy the gate. Any confirmation-shaped call now counts.
_CONFIRM_GATE = re.compile(r"\b\w*confirm\w*\s*\(|\bare_you_sure\b", re.I)
_INVISIBLE_DEBT = re.compile(
    r"#.*(for now|shortcut:|quick.?fix|hack:|workaround:)", re.IGNORECASE
)
_SELF_POLLUTING = re.compile(
    r"TemporaryDirectory\s*\(.*dir\s*="
    r"|mkdtemp\s*\(.*dir\s*="
    r"|tempfile\.tempdir\s*="
)
# A handoff note ANNOUNCES itself; a file that merely uses the word `status` does
# not. The bare `\bstatus\b` alternative was the whole problem: measured over
# 1,953 fleet files, 538 matched this pattern and only 13 contained the word
# "handoff" -- 525 of 538 (97.6%) were convicted by `status = 200` and `if
# status:`. That single word is what put this detector at 24.6% of the tree and
# got it excluded from every debt count by name.
#
# What remains has to look like a note's HEADING or an explicit resumption
# phrase: a markdown/comment heading naming a handoff or status update, or
# "continue where we left off".
_HANDOFF_MARK = re.compile(
    r"^\s*(?:#{1,6}|//|#)?\s*(?:handoff|status\s+(?:update|report|note))\b"
    r"|continue where we left off",
    re.IGNORECASE | re.MULTILINE,
)
_HANDOFF_FIELDS = ("goal:", "state:", "evidence:", "blockers:", "next:")


class UnparseableSource(Exception):
    """El archivo no se pudo leer como Python: NO hay veredicto sobre él.

    Antes esto era `return None`, y cada uno de los 25 detectores lo traducía a
    `return False` -- es decir, a "aquí no hay vicio". Medido el 2026-08-23: un
    `broken.py` con `def f(:` y una clave AWS literal salía del escáner como
    PASSED, con could_not_run vacío. Una ausencia de lectura no es una absolución,
    sí que ahora sube como excepción y el que escanea tiene que registrarla.
    """


@functools.lru_cache(maxsize=128)
def _parse(code: str) -> ast.AST:
    """Parse arbitrary scanned source, raising UnparseableSource when it is not Python."""
    try:
        raw_tree = ast.parse(code)
        from simplecode.guards.ast_normalizer import normalize_ast
        return normalize_ast(raw_tree)
    except (SyntaxError, ValueError) as exc:
        raise UnparseableSource(f"{type(exc).__name__}: {exc}") from exc


def _walk(tree: ast.AST) -> tuple[ast.AST, ...]:
    """Reuse one stdlib traversal for every detector inspecting this parsed AST."""
    cached = getattr(tree, "_simplecode_walk", None)
    if cached is None:
        cached = tuple(ast.walk(tree))
        setattr(tree, "_simplecode_walk", cached)
    return cached


def _test_funcs(tree: ast.AST) -> list[ast.FunctionDef]:
    """Every top-level or nested function whose name starts with `test`,
    excluding `@pytest.fixture`-decorated ones.

    A fixture is a data/setup factory, not a test -- it returns objects for
    other tests to consume, it doesn't verify anything itself, and pytest
    never runs it as a test regardless of its name. Measured on the fleet
    (2026-08-16): aequitas_os/backend/tests/test_portal.py::
    test_user_and_proposal and test_forecasting_endpoints.py::test_matter are
    both `@pytest.fixture(scope=...)` object builders that only collided with
    this detector's naming heuristic because their names happen to start with
    "test".
    """
    def _is_fixture(fn: ast.FunctionDef) -> bool:
        for dec in fn.decorator_list:
            target = dec.func if isinstance(dec, ast.Call) else dec
            if isinstance(target, ast.Name) and target.id == "fixture":
                return True
            if isinstance(target, ast.Attribute) and target.attr == "fixture":
                return True
        return False

    return [
        n
        for n in _walk(tree)
        if isinstance(n, ast.FunctionDef)
        and n.name.startswith("test")
        and not _is_fixture(n)
    ]


def _body_without_docstring(fn: ast.FunctionDef) -> list[ast.stmt]:
    """A function's body statements, with a leading docstring Expr stripped."""
    body = list(fn.body)
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and isinstance(body[0].value.value, str)
    ):
        return body[1:]
    return body


def _stmt_signature(stmt: ast.stmt) -> str:
    """A structural fingerprint of a statement with names/literals blanked out."""
    node = copy.deepcopy(stmt)

    class Canonicalizer(ast.NodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.AST:
            return ast.copy_location(ast.Name(id="_", ctx=node.ctx), node)

        def visit_Attribute(self, node: ast.Attribute) -> ast.AST:
            self.generic_visit(node)
            node.attr = "_"
            return node

        def visit_Constant(self, node: ast.Constant) -> ast.AST:
            if isinstance(node.value, str):
                return ast.copy_location(ast.Constant(value="_"), node)
            if (
                isinstance(node.value, (int, float, complex, bool))
                or node.value is None
            ):
                return ast.copy_location(ast.Constant(value="_"), node)
            return node

        def visit_arg(self, node: ast.arg) -> ast.AST:
            node.arg = "_"
            return node

    node = Canonicalizer().visit(node)
    ast.fix_missing_locations(node)
    return ast.dump(node, include_attributes=False)


def _function_complexity(fn: ast.FunctionDef) -> int:
    """Cyclomatic complexity: 1 plus one per branching node, plus (N-1) per BoolOp's operands."""
    complexity = 1
    for node in _walk(fn):
        if isinstance(
            node,
            (
                ast.If,
                ast.For,
                ast.While,
                ast.With,
                ast.Try,
                ast.IfExp,
                ast.ExceptHandler,
                ast.Match,
                ast.comprehension,
            ),
        ):
            complexity += 1
        elif isinstance(node, ast.BoolOp):
            complexity += len(node.values) - 1
    return complexity


# flota 2026-08-17: 2 hits (Atlas 2). Primero: Atlas/playbooks/station-gr00t/assets/patches/video_utils_modified.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def untracked_prototype(code: str) -> bool:
    """TODO/FIXME/HACK marker with no owner+expires accountability.

    Matched against real COMMENT tokens only, never raw line text: the
    line-scan version convicted a string literal that merely QUOTES the
    marker vocabulary -- a lint rule comparing a decorator's preceding line
    against `("# TODO:", "# REMOVE_WHEN:", ...)` is enforcing this exact
    accountability rule, not committing the vice (fleet hit, 2026-08-16:
    cuenza/scripts/run_security_audit_12d.py:328, see
    tests/fixtures/near_miss/UP-001.py). Falls back to the line-based scan
    when the source does not tokenize, matching code_without_prose's rule:
    refusing to guess beats silently skipping a file we cannot parse.
    """
    try:
        toks = list(tokenize.generate_tokens(io.StringIO(code).readline))
    except (tokenize.TokenError, IndentationError, SyntaxError):
        for line in code.splitlines():
            m = _TODO_MARK.search(line)
            if m:
                comment = line[m.start():]
                if not ("owner=" in comment and "expires=" in comment):
                    return True
        return False
    for tok in toks:
        if tok.type != tokenize.COMMENT:
            continue
        m = _TODO_MARK.search(tok.string)
        if m:
            comment = tok.string[m.start():]
            if not ("owner=" in comment and "expires=" in comment):
                return True
    return False



# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def premature_closure(code: str) -> bool:
    """Errors dismissed as closed despite noted secondary failures."""
    text = code.lower()
    if "closed" not in text:
        return False
    if "assert not scan_logs().errors" in text:
        return False
    return (
        "ignored and closed" in text
        or "secondary keyerror" in text
        or "secondary failures" in text
    )


# flota 2026-08-17: 4 hits (aequitas_os 3, Atlas 1). Primero: Atlas/tests/test_session_manager_sql.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def destructive_without_dryrun(code: str) -> bool:
    """Destructive command (rm -rf, TRUNCATE, DROP TABLE, ...) with no dry-run path.

    Scanned with prose blanked, and only for the object kinds that take data
    with them (see _DESTRUCTIVE). Measured over the fleet (2898 .py files,
    distinct_hits): 24 files fired before this narrowing, 8 after, and the 8
    are a strict subset of the 24. All 21 hits read one by one; 3 were the
    vice. The 16 that stopped firing were:

      * seven files whose only match was the WORD `soft-delete` in a docstring
        (aequitas_os app/services/purge_saga.py:6, app/models/harness.py:58,
        app/harness/executor.py:8, ...) -- a soft delete keeps the row;
      * six idempotent `DROP <object> IF EXISTS` + `CREATE <object>` pairs,
        among them app/core/rls.py:77, which is the code that INSTALLS the
        row-level-security policy isolating one client's data from another's;
      * a comment quoting the SQL injection it had already fixed
        (Atlas rag/session_manager.py:210);
      * the `--delete` sub-command of a scheduler script
        (cuenza scripts/setup_reminder_task.py:58);
      * an alembic downgrade dropping the constraints its own upgrade added.

    Prose is blanked for the ACCUSATION only; `_DRYRUN` still reads the raw
    text. A safety marker written in a comment is still a safety marker, and
    keeping the defence on raw text is what makes this change provably
    hit-set-shrinking rather than merely different.

    Residual false positives, measured and NOT fixed -- a report that hides
    what it could not do is not a clean report:
      * a quoted SQL-injection payload inside the test that proves the table
        survives it (Atlas tests/test_session_manager_sql.py:59, `"x'; DROP
        TABLE queries; --"`): the literal is the attack, the file is the
        defence, and no cheap text rule separates the two;
      * `DROP TABLE IF EXISTS` in an alembic downgrade helper
        (aequitas_os alembic/versions/cd6f8e90d449_*.py:27) -- alembic's dry
        run is the framework's `--sql` flag, which no in-file token declares;
      * `DROP DATABASE IF EXISTS "{drill_db}" WITH (FORCE)` dropping the
        throwaway database the same function created seconds earlier
        (aequitas_os scripts/pg_backup_restore.py:204);
      * a pytest conftest that already REFUSES to run unless the database name
        contains "test" (aequitas_os tests/conftest.py:98,109) -- this
        detector has no notion of a refusal gate, only of a dry run;
      * `Bash(git reset --hard)` as the input of the test asserting the
        permission auditor REJECTS it (cuenza tests/test_maintenance_support.py:25).

    Exception, structural (2026-08-26): the two residual false positives
    above -- a destructive literal fed to the function under test to prove a
    `pytest.raises` REJECTS it -- are exempted the same way `hardcoded_path`
    already exempts test-data path literals: inside a `def test_*`, the
    literal is data unless it is actually passed to a real executor
    (`subprocess.run`/`os.system`/`cursor.execute`/... -- see
    `_DESTRUCTIVE_EXECUTORS`). No annotation needed for a well-shaped
    adversarial test. `# destructive-input: <reason> -- <TICKET>` (file-wide,
    same mechanism as `blocking_sleep`/`unmanaged_resource_open`) remains as
    a fallback for a shape the structural check cannot cover -- a multi-line
    literal, or a payload built outside any `def test_*`.
    """
    if _DESTRUCTIVE_INPUT_JUSTIFICATION.search(code):
        return False
    tree = _parse(code)
    masked = _mask_adversarial_test_literals(
        tree, code, _DESTRUCTIVE_ATTR_EXECUTORS, _DESTRUCTIVE_BARE_EXECUTORS
    )
    return bool(_DESTRUCTIVE.search(code_without_prose(masked))) and not bool(
        _DRYRUN.search(code)
    )


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def broken_version_parity(code: str) -> bool:
    """Two or more distinct version literals declared in one file."""
    versions = {
        match.group(1) or match.group(2)
        for match in _VERSION_LITERAL.finditer(code)
        if (match.group(1) or match.group(2))
    }
    return len(versions) >= 2


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def _has_blocking_call(code: str) -> bool:
    """A blocking `recv`/`acquire`/`wait` call, seen by regex or -- when the
    regex cannot see it -- by the parser.

    The AST pass is NOT a redundant second opinion: `_BLOCKING_CALL` requires
    the name and its `(` to be separated by whitespace alone, so a call with a
    comment or a line continuation in between is invisible to it and plainly
    visible to the parser. Measured 2026-09-15 while splitting this detector,
    because "the regex already covers it" was the obvious wrong conclusion:
    over the 273 tracked `.py` files of this repo ZERO reach the AST pass, and
    these two do --

        result = (\n    lock.acquire  # grab it\n    ()\n)    -> regex blind, AST convicts
        lock.acquire \\\n()                                    -> regex blind, AST convicts

    An unparseable file answers False here, not True: this half only reports
    whether a blocking call was SEEN, and nothing was seen.
    """
    if _BLOCKING_CALL.search(code):
        return True
    try:
        tree = _parse(code)
    except UnparseableSource:
        return False
    return any(
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr in ("acquire", "wait", "recv")
        and not node.keywords
        for node in _walk(tree)
    )


# Marks that EXONERATE a blocking call: an explicit liveness/timeout marker, an
# `async with pool.acquire()`, a kill-then-wait teardown, or a non-blocking
# acquire. Any one of them clears the call -- the order is immaterial to the
# verdict, so they are one `any()` instead of four sequential early returns.
_DEADLOCK_EXONERATIONS = (
    _LIVENESS_MARK,
    _ASYNC_POOL_ACQUIRE,
    _KILL_THEN_WAIT,
    _NONBLOCKING_ACQUIRE,
)


def deadlock_without_heartbeat(code: str) -> bool:
    """Blocking call (recv/acquire/wait) with no liveness/timeout marker."""
    if not _has_blocking_call(code):
        return False
    return not any(rx.search(code) for rx in _DEADLOCK_EXONERATIONS)


_STUB_CONSTANT_MAX_LEN = 40  # a real stub returns a short placeholder, not a template


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def constant_stub(code: str) -> bool:
    """VT-001: a function that ignores a declared parameter and returns a bare constant.

    `return <constant>` is the SHAPE of the vice, not the vice. This kit's own
    catalog states the vice as "function ignores its declared parameter and
    returns a bare literal" (rules/vices.yaml, vt-001-hardcoded-return) and
    carves out three constructions with `pattern-not` / `metavariable-regex`:
    a bound method (`self`/`cls` first), a parameter marked unused with a
    leading underscore, and -- since the pattern requires `$A` -- a function
    with no parameter at all. This detector was written from the one-line
    message instead of the rule and kept none of the three, so it convicted all
    four legitimate shapes of the labeled near-miss tests/fixtures/near_miss/
    VT-001.py: `default_timeout_seconds()` (no input it could depend on),
    `FixedDelayRetry.backoff(self, attempt)` (a fixed delay IS flat; the
    signature belongs to the strategy interface), `NullMetrics.timing` (a null
    object must do nothing) and `always_allow(_principal, ...)` (underscored
    arguments). Measured over the fleet before the fix: 11 distinct files, of
    which 9 were exactly those shapes -- `close(self)`, `raise_for_status(self)`,
    `strftime(self, _fmt)`, `undo()`.

    Ceiling, deliberate: excluding bound methods loses a hardcoded return
    written inside a class (`is_available(self) -> True`, office2office). The
    catalog trades that away because a method's signature is imposed by its
    interface, not invented to satisfy a test.

    Fourth carve-out, added after triaging the live fleet (2026-08-16, 2
    distinct files): a SCREAMING_CASE function name. Measured hits were
    `COMPLACIENTE`/`AFIRMA_TODO`/`NIEGA_TODO` (Atlas tests/test_grounding_
    criterion.py) and `COMPLACIENTE`/`ASESINO` (Atlas tests/test_source_
    verifier.py) -- fake "judge" callables injected by name into
    `verdict_for`/`grounding_verdict_for` specifically to test that the
    pipeline is independent of what a pathological judge returns. Their
    params (`q, c` / `hechos, c`) are genuinely unused, same as
    `always_allow`'s, but PEP 8 has no leading-underscore convention for an
    unused *parameter of a fixed-behavior callback* the way it does for a
    throwaway local -- these functions instead marked themselves the way
    Python already marks a fixed value: an all-caps name. A real function
    is essentially never named in SCREAMING_CASE (that casing is reserved
    for module constants), so trusting it as a second "this is deliberately
    constant" signal, alongside the underscore prefix, costs almost nothing
    on production code and was the exact fix these two false positives
    needed.
    """
    tree = _parse(code)
    for fn in _walk(tree):
        if (
            isinstance(fn, ast.FunctionDef)
            and not fn.name.startswith("test")
            and not (fn.name.startswith("__") and fn.name.endswith("__"))
            and not fn.name.isupper()
        ):
            positional = fn.args.posonlyargs + fn.args.args
            if positional and positional[0].arg in ("self", "cls"):
                continue
            ignored = [
                a
                for a in positional + fn.args.kwonlyargs
                if not a.arg.startswith("_")
            ]
            if not ignored:
                continue
            body = [
                n
                for n in fn.body
                if not (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant))
            ]
            if (
                len(body) == 1
                and isinstance(body[0], ast.Return)
                and isinstance(body[0].value, ast.Constant)
            ):
                value = body[0].value.value
                if isinstance(value, str) and len(value) > _STUB_CONSTANT_MAX_LEN:
                    continue
                return True
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def blind_shell_edit(code: str) -> bool:
    """Blind shell manipulation (sed/awk) of a structured data file."""
    return bool(_SED_STRUCT.search(code))


def code_without_prose(code: str) -> str:
    """`code` with comments and docstrings blanked, offsets preserved.

    A detector hunting a vice in CODE must not convict prose that merely
    describes it. Measured: the labeled near-miss fixture VC-027 -- code that
    HUNTS placeholders instead of shipping one -- was convicted because its own
    docstring quotes the thing to avoid.

    Blanking rather than deleting keeps every line and column intact, so a
    position computed on the stripped text still points at the right place in
    the original. Input that does not tokenize comes back unchanged: refusing
    to guess beats silently scanning half a file.
    """
    return _blank_token_spans(code, _is_comment_or_docstring)


def _is_comment_or_docstring(tok: tokenize.TokenInfo) -> bool:
    """A COMMENT token, or a STRING token written in docstring shape."""
    stripped = tok.line.lstrip()
    is_doc = tok.type == tokenize.STRING and (
        stripped.startswith(('"""', "'''"))
        or stripped[:2].lower() in ("r'", 'r"') and stripped[1:4] in ('"""', "'''")
    )
    return tok.type == tokenize.COMMENT or is_doc


def _is_string_token(tok: tokenize.TokenInfo) -> bool:
    """Any string literal -- docstring-shaped or not, statement or value."""
    return tok.type == tokenize.STRING


def code_without_string_literals(code: str) -> str:
    """`code` with EVERY string literal blanked, comments and offsets intact.

    The complement of `code_without_prose`, for the one detector whose subject
    IS a comment: `unjustified_noqa_complexity` hunts a suppression comment, so
    blanking comments -- what `code_without_prose` does -- would blank the
    subject itself and blind the detector completely. What has to disappear is
    the INSIDE of string literals, all of them and not only docstring-shaped
    ones, because the text falsely convicted is prose either way.

    Why the blank is by COLUMN and not by line: a line-wide exemption is the
    hole. A line can carry a string AND a real suppression comment at once
    (`_PROBE = "x"  # noqa: C901`, or a docstring statement followed by `;`),
    and dropping the whole line would drop the suppression with it. A token's
    own column range leaves the comment standing.

    Untokenizable input comes back unchanged, so an unparseable file is scanned
    IN FULL -- the same fail-toward-convicting rule `gate_relaxation_tamper`
    documents: a syntax error must not become a way to hide a suppression.
    """
    return _blank_token_spans(code, _is_string_token)


def _blank_token_spans(
    code: str, selected: Callable[[tokenize.TokenInfo], bool]
) -> str:
    """`code` with every `selected` token's character span replaced by spaces.

    Extracted verbatim from `code_without_prose` when
    `code_without_string_literals` needed the same span arithmetic under the
    opposite predicate. The line-terminator rule below is the whole reason this
    is shared instead of re-derived: getting it wrong desynchronised 84% of the
    fleet's files once already.
    """
    try:
        toks = list(tokenize.generate_tokens(io.StringIO(code).readline))
    except (tokenize.TokenError, IndentationError, SyntaxError):
        return code
    lines = code.splitlines(keepends=True)
    for tok in toks:
        if not selected(tok):
            continue
        (srow, scol), (erow, ecol) = tok.start, tok.end
        for row in range(srow, min(erow, len(lines)) + 1):
            line = lines[row - 1]
            # El terminador de línea NO se blanquea. Blanquearlo convertía el
            # salto en un espacio y fundía las líneas de un docstring de varias
            # líneas en una sola, y con eso se rompía la promesa del docstring
            # de arriba: «una posición calculada sobre el texto blanqueado sigue
            # apuntando al sitio correcto del original».
            #
            # Medido el 2026-08-17 sobre los 2,967 `.py` de la flota:
            # **2,498 desincronizaban**, el 84%. Todo lo que empareja por
            # posición la línea original con la blanqueada -- entre ello el
            # escape `allow-secret` de `hardcoded_secret` -- miraba OTRA línea a
            # partir del primer docstring del archivo.
            cuerpo = line.rstrip("\r\n")
            term = line[len(cuerpo):]
            a = min(scol if row == srow else 0, len(cuerpo))
            b = min(ecol if row == erow else len(cuerpo), len(cuerpo))
            lines[row - 1] = cuerpo[:a] + " " * max(0, b - a) + cuerpo[b:] + term
    return "".join(lines)


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def placeholder_literal(code: str) -> bool:
    """Permanent placeholder literal (REPLACE_ME, CHANGE_ME, TODO, ...) assigned in code.

    Scanned with prose blanked: a docstring quoting the vice as the thing to
    avoid is documentation, not a shipped placeholder.
    """
    return bool(_PLACEHOLDER.search(code_without_prose(code)))


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def core_dependent_on_unstable_parts(code: str) -> bool:
    """Import of an experimental/unstable/beta/volatile module."""
    return bool(_UNSTABLE_IMPORT.search(code))


# Three shapes a synthetic literal takes that the placeholder vocabulary cannot
# name, each closing exactly one measured false positive of optimistic_config:
#
#   x:x@localhost   the DSN whose user and password are THE SAME one-or-two-char
#                   token. Nobody's real credential is `x`, and the shape is what
#                   a test writes when the value must parse and nothing more.
#                   (aequitas_os/backend/tests/test_pg_backup_restore.py)
#   12345678        a strictly consecutive digit run. Real secrets are not
#                   ascending. (test_sat_buzon_service.py)
#   secret1234      the value is its own KEY plus digits. `_is_credential_literal`
#                   already rejected value == key; this covers key + filler.
#                   (red_python/tests/test_dimensions_contracts.py)
#
# All three are deliberately narrower than "it is in a test file": a real
# credential leaked into a test is still a leak, so the exemption is the SHAPE of
# the value, never its neighbourhood.
_PLACEHOLDER_DSN = re.compile(r"://(?P<u>[^:/@]{1,2}):(?P<p>[^:/@]{1,2})@")


def _is_synthetic_literal(key: str, value: str) -> bool:
    """True when the literal's own shape says nobody could authenticate with it."""
    m = _PLACEHOLDER_DSN.search(value)
    if m and m.group("u") == m.group("p"):
        return True
    if value.isdigit() and len(value) >= 4:
        digits = [int(c) for c in value]
        if all(b - a == 1 for a, b in zip(digits, digits[1:])):
            return True
        if len(set(digits)) == 1:
            return True
    # The value names what it is instead of being one: `secret1234`,
    # `password01`, or the key's own name plus filler. Compared against the
    # credential vocabulary AND the key, because the measured case
    # (`password = "secret1234"`) has the word in the VALUE, not in the key --
    # which is what the first version of this rule got wrong.
    base = key.rsplit(".", 1)[-1].lower()
    stripped = value.lower().rstrip("0123456789_-")
    if stripped != value.lower() and stripped in (
            {base} | {"secret", "password", "passwd", "pwd", "token", "key", "apikey",
                      "api_key", "clave", "contrasena"}):
        return True
    return False


def _is_credential_literal(key: str, value: str) -> bool:
    """True when `key = "value"` puts a USABLE credential in the source text.

    A secret is what an attacker can present to a service. Three shapes that
    match the key pattern cannot be:

      * a digest field -- `hashed_password="hashed"` is the output of a hash,
        which is precisely what gets stored so the credential never does;
      * a literal too short to be a token, or one that merely repeats its own
        key (`api_key="api_key"`, the dummy a local OpenAI-shaped server
        requires and ignores);
      * a literal that names itself a fixture (`fake-hashed-password`).
    """
    if _HASH_FIELD.search(key):
        return False
    value = value.strip()
    if len(value) < _SECRET_MIN_LEN:
        return False
    if value.lower() == key.rsplit(".", 1)[-1].lower():
        return False
    if _is_synthetic_literal(key, value):
        return False
    lowered = value.lower()
    return not any(marker in lowered for marker in _SECRET_PLACEHOLDERS)


def _prose_blanked_lines(code: str) -> "Iterator[str]":
    """Yields each line with prose blanked, skipping any line whose ORIGINAL
    text carries the `allow-secret` escape (blanking would erase the marker
    along with the comment carrying it) -- shared scan loop for
    `hardcoded_secret` and `optimistic_config` (found 2026-08-28, dedup
    pass: both walked `zip(code.splitlines(), code_without_prose(code)
    .splitlines())` with the identical skip condition).
    """
    blanked = code_without_prose(code).splitlines()
    for original, line in zip(code.splitlines(), blanked):
        if "allow-secret" not in original:
            yield line


def _match_is_credential(line: str, match: "re.Match[str]") -> bool:
    """Reconstructs the full dotted/attribute key ending at `match` (the
    prefix window before it) and checks whether key+value together are a
    usable credential -- the per-match body `hardcoded_secret` and
    `optimistic_config` both had inline, differing only in which regex's
    match object they were called with.
    """
    window = line[max(0, match.start() - _KEY_PREFIX_WINDOW):match.start()]
    tail_m = _NAME_TAIL.search(window)
    key = (tail_m.group(0) if tail_m else "") + match.group("key")
    return _is_credential_literal(key, match.group("value"))


_PEM_PRIVATE_KEY = re.compile(
    r"-----BEGIN (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----"
    r"[\s\S]*?"
    r"-----END (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----",
    re.I,
)


# flota 2026-08-17: 1 hits (aequitas_os 1). Primero: aequitas_os/backend/tests/test_pg_backup_restore.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def hardcoded_secret(code: str) -> bool:
    """Hardcoded secret or connection string with embedded credentials.

    Scanned line by line with prose blanked, so a secret QUOTED in a comment or
    docstring (`# token = "hf_..."`) is documentation, not a shipped credential
    -- the same treatment placeholder_literal already gives its own vice. The
    `allow-secret` escape comment that dangerous_patterns.scan_content honours
    is honoured here too, read off the ORIGINAL line because blanking would
    erase the marker along with the comment carrying it.

    Line-by-line costs the (already unreachable in practice) match of an
    assignment split across two physical lines, and buys the per-line escape
    comment, which is what the fleet actually writes.
    """
    return bool(hardcoded_secret_findings(code))


def hardcoded_secret_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every hardcoded secret, with its LINE and which rule convicted it.

    The detail sibling `zero_debt._scan_registry` looks for. Without it this
    detector emitted one generic `line: 0` / "<detector> fired" row per file.
    Reported by descargaSAT 2026-09-05: isolating a single hit in poe_systems
    cost six probes, and two of those probes measured the wrong file because
    the row named no line and no rule. The judgement was correct the whole
    time; what failed was what the organ said about itself.

    Every branch below is the one `hardcoded_secret` had, in the same order and
    with the same guards -- this reports where it fired, it does not change
    when it fires. `test_pattern_detectors` and the near-miss fixtures pin that.
    """
    del path  # the caller already knows it; the message is built by zero_debt
    hits: list[tuple[int, str]] = []
    tree = _parse(code)
    if "allow-secret" not in code:
        node = _conn_string_credential(tree)
        if node is not None:
            hits.append((getattr(node, "lineno", 0),
                         "connection string literal carrying a password"))
        pem_m = _PEM_PRIVATE_KEY.search(code)
        if pem_m and not any(p in pem_m.group(0).lower() for p in _SECRET_PLACEHOLDERS):
            hits.append((code.count("\n", 0, pem_m.start()) + 1,
                         "PEM private key block"))
    for numero, line in enumerate(_prose_blanked_lines(code), start=1):
        dsn = _DSN.search(line)
        if dsn:
            # El DSN entra por su propio camino, antes de _SECRET, asi que el
            # filtro de literales sinteticos hay que aplicarlo tambien aqui: el
            # caso medido (`postgresql://x:x@localhost:5434/x`) llegaba a True sin
            # pasar nunca por _is_credential_literal.
            if not _is_synthetic_literal("dsn", dsn.group(0)):
                hits.append((numero, "DSN with embedded credentials"))
        for match in _SECRET.finditer(line):
            if _match_is_credential(line, match):
                hits.append((numero, f"secret-shaped assignment to `{match.group(0).strip()}`"))
    return hits


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def optimistic_config(code: str) -> bool:
    """DEBUG/TESTING=True, or a secret-shaped key assigned a USABLE literal.

    The DEBUG/TESTING half is a bare regex and stays one -- it produced the
    detector's one true positive on the fleet (agente_inmobiliario/app.py:956,
    `app.run(debug=True, port=5000)`) and zero false positives on both the
    fleet and the sensitivity battery. The secret half goes through the same
    prose-blanking, `allow-secret` escape, and `_is_credential_literal` gate as
    `hardcoded_secret`, for the reasons recorded on `_OPTIMISTIC_SECRET` above.
    """
    return bool(optimistic_config_findings(code))


def optimistic_config_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every optimistic-config hit, with its LINE and which half convicted it.

    The residue descargaSAT flagged 2026-09-05 after verifying the
    `hardcoded_secret` fix: this detector fires on the SAME file for the SAME
    reason and was still emitting `line: 0` / "<detector> fired". In their case
    the two always fired together, so its sibling supplied the line -- but that
    is coupling, not coverage: decouple them once and this one goes mute again.

    Same shape as `hardcoded_secret_findings`, same guards, same order. It
    reports WHERE it fires; it does not change WHEN.
    """
    del path  # the caller already knows it; the message is built by zero_debt
    hits: list[tuple[int, str]] = []
    # BOTH halves read prose-blanked lines now. The debug half used to search
    # the raw `code`, so a COMMENT mentioning the vice was convicted as the
    # vice -- `# never ship app.run(debug=True) in production` came back True.
    # That is documentation, and the detector's own secret half, plus
    # `hardcoded_secret` and `placeholder_literal`, already give prose exactly
    # the opposite treatment; this half was the odd one out.
    #
    # Found by writing the comment that describes this defect INTO the test
    # file for the sibling above, which then convicted the file at that
    # comment's line. The fix reporting the line is what made it findable at
    # all -- with the old `line: 0` I would have had a red file and no idea why.
    #
    # The docstring's calibration survives, and it was re-measured rather than
    # assumed: the one true positive it cites (`app.run(debug=True, port=5000)`)
    # is CODE, so prose-blanking leaves it untouched.
    debug_code = code_without_string_literals(code_without_prose(code)).splitlines()
    for numero, line in enumerate(_prose_blanked_lines(code), start=1):
        debug_line = debug_code[numero - 1] if numero <= len(debug_code) else ""
        debug_m = _OPTIMISTIC_DEBUG.search(debug_line)
        if debug_m:
            hits.append((numero,
                         f"debug/testing flag left on: `{debug_m.group(0).strip()}`"))
        match = _OPTIMISTIC_SECRET.search(line)
        if match and _match_is_credential(line, match):
            hits.append((numero,
                         f"secret-shaped key assigned a usable literal: "
                         f"`{match.group(0).strip()}`"))
    return hits


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def frozen_nomenclature(code: str) -> bool:
    """A versioned identifier baked into a class/function's OWN declared name
    (e.g. foo_v2, BarV3) -- the ossification risk is specific to the name a
    caller has to import/subclass/type out, not any name that merely touches
    a version number.

    Narrowed from also walking ast.Name/ast.arg/ast.Attribute/ast.alias after
    a fleet triage (2026-08-16, 8 distinct hits read one by one): 5 of 8 were
    false positives sharing one shape -- a variable or parameter naming a
    LIVE, currently-relevant version rather than a frozen one. Three shapes
    measured: (1) sibling parameters/locals comparing two variants computed
    in the SAME run (e.g. `fp_v1`/`fp_v2` scoring two regex candidates being
    calibrated side by side), (2) a module constant whose name mirrors the
    real, current filename of an artifact it points to (`EVAL_V2 = ROOT /
    "docs/CLAUDE_DESIGNED_EVAL_V2.md"`, tracking a file that exists on disk
    under that exact name), and (3) a local variable inside a single test
    function naming two sequential instances of a domain object the test
    itself is exercising the versioning of. None of the three go stale the
    way a class/function name does: they are not a public surface someone
    else imports, subclasses, or calls by that exact spelling, so nothing
    breaks when the code around them moves on. A class or function's own
    name IS that surface -- restricting the walk to ClassDef/FunctionDef/
    AsyncFunctionDef keeps the catch (a class or def name pinned to a
    version number that the surrounding file no longer agrees with) and
    drops the five false positives. Fleet hit set measured as a strict
    subset of the pre-fix set after the change (4 of the original 8 files;
    no new file fired) -- see tests/fixtures/near_miss/FN-001.py for the
    fixed shapes and known hole below for the one that remains.
    """
    tree = _parse(code)
    lineas = code.splitlines()
    for node in _walk(tree):
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if not _VERSIONED_IDENTIFIER.search(node.name):
                continue
            # El unico hueco medido de este detector: un nombre que congela una
            # version EXTERNA y real. `looks_like_works_v2` en
            # office2office/parsers/works_parser.py:45 no envejece con el repo --
            # se refiere a Microsoft Works 2.x, un formato de archivo que existe
            # ahi fuera y no va a cambiar de numero. Ensenarle al detector a
            # distinguir una version externa de una interna exigiria saber que
            # formatos existen en el mundo, y eso no se resuelve por AST.
            #
            # Asi que un escape por LINEA, con la misma forma que `allow-secret`
            # que ya honran dangerous_patterns y hardcoded_secret, y con razon
            # obligatoria: sin texto despues de los dos puntos no exime nada, para
            # que no se convierta en un escape sin justificar.
            if _external_version_marked(lineas, node):
                continue
            return True
    return False


_EXTERNAL_VERSION = re.compile(r"#\s*simplecode:external-version\s*:?\s*(\S.*)")


def _external_version_marked(lineas: list[str], node: ast.AST) -> bool:
    """True si la declaracion lleva el marcador de version externa CON razon.

    Se busca en la linea de la declaracion y en el BLOQUE DE COMENTARIO CONTIGUO
    que la precede. Contiguo importa en las dos direcciones: la primera version
    miraba solo la linea inmediatamente anterior y no encontro el marcador del
    caso real, porque su razon ocupaba tres lineas de comentario -- y a la vez el
    bloque tiene que TOCAR la declaracion, para que un marcador treinta lineas
    arriba no exima a una funcion que no es la suya.
    """
    i = getattr(node, "lineno", 0) - 1
    if 0 <= i < len(lineas):
        m = _EXTERNAL_VERSION.search(lineas[i])
        if m and m.group(1).strip():
            return True
    j = i - 1
    while j >= 0 and lineas[j].strip().startswith("#"):
        m = _EXTERNAL_VERSION.search(lineas[j])
        if m and m.group(1).strip():
            return True
        j -= 1
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def prompt_injection_in_agent_loop(code: str) -> bool:
    """Possible prompt injection: agent.run() fed a concatenated variable."""
    if _PROMPT_INJECTION.search(code):
        return True
    try:
        tree = _parse(code)
        for node in _walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "run":
                if node.args and isinstance(node.args[0], (ast.BinOp, ast.JoinedStr)):
                    return True
    except UnparseableSource:
        pass
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def unhandled_tool_call_failure(code: str) -> bool:
    """A call_tool() invocation with no ok-check, retry, or degrade path."""
    if "call_tool(" not in code:
        return False
    return (
        ".ok" not in code and "retry_with_backoff" not in code and "degrade" not in code
    )


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def multi_agent_without_protocol(code: str) -> bool:
    """Multiple agents editing the same file with no lock/handoff/owner protocol."""
    if "lock(" in code or "handoff(" in code or "owner=" in code:
        return False
    matches = _AGENT_EDIT.findall(code)
    if len(matches) >= 2:
        files = [match[2] for match in matches]
        if len(set(files)) < len(files):
            return True
    try:
        tree = _parse(code)
        ast_files: list[str] = []
        for node in _walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "edit":
                if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                    ast_files.append(node.args[0].value)
        if len(ast_files) >= 2 and len(set(ast_files)) < len(ast_files):
            return True
    except UnparseableSource:
        pass
    return False


def insecure_defaults(code: str) -> bool:
    """Insecure default: verify=False, CORS '*', md5, bind-all.

    `debug=True` deliberately excluded -- see the comment on
    `_INSECURE_DEFAULT`; `optimistic_config` owns that finding.

    Parsed Python code is inspected as syntax nodes, so registry strings,
    comments, and documentation prose do not count as executable settings.
    When parsing fails, the legacy pattern check remains available.
    """
    try:
        tree = _parse(code)
    except UnparseableSource:
        return bool(_INSECURE_DEFAULT.search(code))
    return _insecure_defaults_ast(tree)


def _insecure_defaults_ast(tree: ast.AST) -> bool:
    for node in _walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            if (
                isinstance(func, ast.Attribute)
                and func.attr == "md5"
                and isinstance(func.value, ast.Name)
                and func.value.id == "hashlib"
            ):
                return True
            for keyword in node.keywords:
                if _insecure_keyword(keyword.arg, keyword.value):
                    return True
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            positional = [*node.args.posonlyargs, *node.args.args]
            positional_defaults: list[ast.expr | None] = [
                None
            ] * (len(positional) - len(node.args.defaults))
            positional_defaults.extend(node.args.defaults)
            if any(
                default is not None and _insecure_keyword(arg.arg, default)
                for arg, default in zip(positional, positional_defaults)
            ) or any(
                default is not None and _insecure_keyword(arg.arg, default)
                for arg, default in zip(node.args.kwonlyargs, node.args.kw_defaults)
            ):
                return True
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            value = node.value
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if value is not None and any(
                _insecure_keyword(_insecure_target_name(target), value)
                for target in targets
            ):
                return True
    return False


def _insecure_keyword(name: str | None, value: ast.expr) -> bool:
    """Classify insecure setting syntax from AST nodes, never from embedded prose."""
    return (
        name == "verify" and isinstance(value, ast.Constant) and value.value is False
        or name == "origins" and isinstance(value, ast.Constant) and value.value == "*"
        or name == "host" and isinstance(value, ast.Constant) and value.value == "0.0.0.0"
    )


def _insecure_target_name(target: ast.expr) -> str | None:
    if isinstance(target, ast.Name):
        return target.id
    if isinstance(target, ast.Attribute):
        return target.attr
    return None


def _is_llm_generate_call(node: ast.AST) -> bool:
    """True for `model.generate(...)` / `model.generate_json(...)`, same surface as _MODEL_OUTPUT."""
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr in ("generate", "generate_json")
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "model"
    )


def _mentions_any(node: ast.AST, names: set[str]) -> bool:
    """`node`'s subtree reads one of `names`. The one predicate the taint walk
    below asked four separate times in four spellings before 2026-09-15."""
    return any(isinstance(s, ast.Name) and s.id in names for s in _walk(node))


def _bind_names(target: ast.AST, names: set[str]) -> None:
    """Add every `Name` bound by an assignment/loop `target` to `names` --
    the tuple-unpack case included (`a, b = tainted` taints both)."""
    names.update(s.id for s in _walk(target) if isinstance(s, ast.Name))


def _param_reaches_return(
    param: str, body_assigns: Sequence[ast.Assign | ast.AnnAssign],
    returns: Sequence[ast.expr],
) -> bool:
    """Taint seeded on the SINGLE name `param` reaches one of `returns`,
    following local re-binding (`tmp = param; return tmp`) for a capped three
    passes. Checked one parameter at a time -- that is what lets
    `def pick(a, b): return b` report index 1 and not both.
    """
    seeded = {param}
    for _ in range(3):
        for n in body_assigns:
            value = n.value
            if value is None or not _mentions_any(value, seeded):
                continue
            targets = n.targets if isinstance(n, ast.Assign) else [n.target]
            for t in targets:
                _bind_names(t, seeded)
    return any(_mentions_any(r, seeded) for r in returns)


def _function_taint_passthrough(tree: ast.AST) -> dict[str, set[int]]:
    """For each function DEFINED IN THIS FILE, the 0-based positional
    parameter indices that -- if tainted at a call site -- make the
    function's return value tainted too. Closes half of `_two_pass_tainted_names`'s
    former `ponytail:` (2026-09-08, upgrade trigger exercised on request):
    a same-file helper (`def clean(value): return value.strip()`) that just
    forwards its argument used to break the chain at the call site, so
    `result = clean(model.generate(...))` never tainted `result`.

    Deliberately same-file only: this module's detectors are single-file AST
    walks with no import resolution, so a call into another module has no
    body here to analyze -- reported as NOT passthrough (fails toward under-
    tainting a cross-file call, never toward inventing a body it never saw).
    A function is checked against EACH parameter independently (seeding
    taint on just that one name) so `def pick(a, b): return b` correctly
    reports only index 1, not both.
    """
    passthrough: dict[str, set[int]] = {}
    for node in _walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        returns = [r.value for r in _walk(node) if isinstance(r, ast.Return) and r.value is not None]
        if not returns:
            continue
        body_assigns = [n for n in _walk(node) if isinstance(n, (ast.Assign, ast.AnnAssign))]
        indices = {
            i for i, param in enumerate(node.args.args)
            if _param_reaches_return(param.arg, body_assigns, returns)
        }
        if indices:
            passthrough[node.name] = indices
    return passthrough


def _call_result_tainted(
    value: ast.expr, tainted: set[str], passthrough: dict[str, set[int]],
    is_source: Callable[[ast.expr], bool],
) -> bool:
    """`value` is a direct call to a known same-file passthrough function
    (see `_function_taint_passthrough`) with a tainted argument -- either an
    already-tracked name, OR the source expression itself passed inline
    (`identity(model.generate(...))`, never bound to a name at all) -- in a
    position that reaches its return."""
    if not isinstance(value, ast.Call) or not isinstance(value.func, ast.Name):
        return False
    indices = passthrough.get(value.func.id)
    if not indices:
        return False
    return any(
        i in indices and (
            is_source(arg) or any(isinstance(s, ast.Name) and s.id in tainted for s in _walk(arg))
        )
        for i, arg in enumerate(value.args)
    )


def _spread_through_assigns(
    assigns: Sequence[ast.Assign | ast.AnnAssign], tainted: set[str],
    passthrough: dict[str, set[int]], is_source: Callable[[ast.expr], bool],
) -> None:
    """One pass of `_two_pass_tainted_names` over ASSIGNMENTS: a target is
    tainted when its value is a source, reads an already-tainted name, or is a
    call into a same-file passthrough (`_call_result_tainted`). Mutates
    `tainted` in place -- the caller's fixpoint counts its growth to decide
    whether another pass is worth running."""
    for n in assigns:
        value = n.value
        if value is None:
            continue
        carries = (
            is_source(value)
            or _mentions_any(value, tainted)
            or _call_result_tainted(value, tainted, passthrough, is_source)
        )
        if not carries:
            continue
        targets = n.targets if isinstance(n, ast.Assign) else [n.target]
        for t in targets:
            _bind_names(t, tainted)


def _spread_through_for_loops(
    for_loops: Sequence[ast.For], tainted: set[str], is_source: Callable[[ast.expr], bool],
) -> None:
    """One pass of `_two_pass_tainted_names` over `for` LOOPS: iterating a
    tainted iterable taints the loop target. Deliberately NO passthrough-call
    check -- `for x in clean(tainted):` was not tainted before this split
    either, and inventing that here would widen the detector under cover of a
    refactor. Mutates `tainted` in place, like its assignment twin."""
    for n in for_loops:
        if not (is_source(n.iter) or _mentions_any(n.iter, tainted)):
            continue
        _bind_names(n.target, tainted)


def _two_pass_tainted_names(tree: ast.AST, is_source: Callable[[ast.expr], bool]) -> set[str]:
    """Names assigned from a value `is_source` marks as tainted -- a small
    fixpoint (capped, never unbounded) that follows `a = <source>; b = a`,
    a `for x in <tainted iterable>:` unpack, and a call into a same-file
    passthrough function (`_function_taint_passthrough`). Shared by
    `_llm_tainted_names` and `_tainted_names` (found 2026-08-28, dedup pass:
    both were the exact same intraprocedural walk, differing only in which
    predicate identifies the taint SOURCE).

    Real interprocedural analysis (across module boundaries, or through
    anything more than a direct same-file `Name(...)` call) stays out of
    scope: these detectors are single-file AST walks with no import graph to
    resolve a call against, and reasoning about interprocedural taint by
    text alone risks the FALSE precision this whole taint-tracking exercise
    was built to avoid in the first place.
    """
    tainted: set[str] = set()
    assigns = [n for n in _walk(tree) if isinstance(n, (ast.Assign, ast.AnnAssign))]
    for_loops = [n for n in _walk(tree) if isinstance(n, ast.For)]
    passthrough = _function_taint_passthrough(tree)
    for _ in range(5):
        before = len(tainted)
        _spread_through_assigns(assigns, tainted, passthrough, is_source)
        _spread_through_for_loops(for_loops, tainted, is_source)
        if len(tainted) == before:
            break
    return tainted


def _llm_tainted_names(tree: ast.AST) -> set[str]:
    """Names assigned from `model.generate(...)`. Two passes: `a = model.generate(...); b = a`."""
    return _two_pass_tainted_names(tree, _is_llm_generate_call)


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def _has_tainted_arg(call: ast.Call, tainted: set[str]) -> bool:
    return any(
        _is_llm_generate_call(arg)
        or any(isinstance(node, ast.Name) and node.id in tainted for node in _walk(arg))
        for arg in call.args
    )


def _is_tainted_sink(call: ast.Call, local_defs: set[str], tainted: set[str]) -> bool:
    """`execute` and `subprocess` narrowed against the fleet-proven false
    positive `io_without_validation` already avoids: a parameterized query
    (`cursor.execute("... WHERE id=%s", (tainted,))`) has nothing for the
    tainted value to inject INTO when it only reaches the BOUND PARAMS, so
    `execute` checks taint on the query argument itself (`call.args[0]`)
    specifically, not merely on some OTHER arg. Likewise
    `subprocess.run([...], tainted_env)` with an argument list and no shell
    has no shell to inject into; only `shell=True` makes a tainted arg
    dangerous. `eval`/`exec`/`innerHTML`/`os.system` keep their original,
    unnarrowed shape -- there is no safer/parameterized form of any of them
    for a narrowing to exempt."""
    if not call.args or not _has_tainted_arg(call, tainted):
        return False
    func = call.func
    if isinstance(func, ast.Name):
        if func.id == "execute":
            return _carries_taint(call.args[0], tainted)
        return func.id in ("eval", "exec") and func.id not in local_defs
    if not isinstance(func, ast.Attribute):
        return False
    base_name = func.value.id if isinstance(func.value, ast.Name) else ""
    if func.attr == "execute":
        return _carries_taint(call.args[0], tainted)
    if base_name == "subprocess" and func.attr in _SHELL_SUBPROCESS:
        return any(
            kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True
            for kw in call.keywords
        )
    return (
        func.attr in ("exec", "innerHTML")
        or base_name == "os" and func.attr == "system"
        or base_name in ("builtins", "__builtins__") and func.attr == "eval"
    )


def blind_trust_in_llm_output(code: str) -> bool:
    """Model output flowing straight into a dangerous sink with no output guard.

    AST dataflow, not whole-file co-occurrence. The regex-conjunction version
    convicted a file for containing the TEXT "model.generate(" and the TEXT of
    a sink anywhere, with no relation between them. Measured on the fleet
    (2026-08-16, 3 distinct hits, 3 read one by one, 3 false):
      - local_whisper_service.py: `subprocess.run(cmd, ...)` decodes ffmpeg
        audio from a hardcoded arg list BUILT BEFORE `model.generate()` is
        even called; `cmd` never carries the model's output.
      - train_test_gnn.py (x2, txt2kg and station-txt2kg playbooks): `eval(
        question, pred, label)` calls a LOCALLY DEFINED `eval()` (an
        LLMJudge-scoring helper that shadows the builtin name), not the
        dangerous builtin.
    Now the sink call's argument must actually resolve to a name assigned from
    `model.generate(...)`, or be that call inline, and `eval`/`exec` Name calls
    are only convicted when no same-named function is defined in the file (a
    shadow, not the builtin). See tests/fixtures/near_miss/BT-071.py.

    `_is_tainted_sink` additionally narrows `subprocess`/`execute` to the
    same `shell=True`/built-dynamically-query shape `io_without_validation`
    already proved on the fleet (2026-09-08): a `subprocess.run([...])`
    argument list with no shell, or a parameterized `cursor.execute(query,
    (tainted,))` call, has nothing for the model's output to inject into.
    """
    tree = _parse(code)
    if _OUTPUT_GUARD.search(code):
        return False

    local_defs = {n.name for n in _walk(tree) if isinstance(n, ast.FunctionDef)}
    tainted = _llm_tainted_names(tree)

    return any(
        _is_tainted_sink(node, local_defs, tainted)
        for node in _walk(tree)
        if isinstance(node, ast.Call)
    )


def _main_guard_node_ids(tree: ast.AST) -> set[int]:
    """id() of every node textually inside an `if __name__ == "__main__":` body.

    A class defined there is a smoke-test/demo harness for the module, not a
    second production caller -- it should not count as "the" implementation
    when judging whether an abstraction has exactly one. See
    tests/fixtures/near_miss/PA-001.py.
    """
    ids: set[int] = set()
    for node in _walk(tree):
        if not isinstance(node, ast.If):
            continue
        test = node.test
        if not (isinstance(test, ast.Compare) and len(test.ops) == 1
                and isinstance(test.ops[0], ast.Eq)):
            continue
        operands = (test.left, *test.comparators)
        names = {o.id for o in operands if isinstance(o, ast.Name)}
        consts = {o.value for o in operands if isinstance(o, ast.Constant)}
        if "__name__" in names and "__main__" in consts:
            ids.update(id(n) for n in _walk(node))
    return ids


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def premature_abstraction(code: str) -> bool:
    """Detect ABC/Protocol abstractions that have exactly one concrete implementation.

    Args:
        code: Python source text to inspect.

    Returns:
        True when a file declares an abstract/interface-like class and exactly one
        non-abstract subclass -- an actionable premature-abstraction (YAGNI) pattern.

    Example:
        >>> premature_abstraction("class Repo(Protocol): ...\\nclass SqlRepo(Repo): pass")
        True

    A subclass that exists only inside `if __name__ == "__main__":` (a smoke
    harness, not a second caller) does not count -- measured 2026-08-16 on
    agente_inmobiliario/scrapers/base_scraper.py, whose docstring documents
    real production subclasses living in sibling files (inmuebles24.py,
    vivanuncios.py); the only subclass visible to this single-file detector
    was `_TestScraper` under the module's `if __name__ == "__main__":` block.
    """
    tree = _parse(code)

    guarded = _main_guard_node_ids(tree)
    abstract_names: set[str] = set()
    concrete_subclasses: dict[str, int] = {}
    for node in _walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        bases = {
            base.id
            for base in node.bases
            if isinstance(base, ast.Name)
        } | {
            base.attr
            for base in node.bases
            if isinstance(base, ast.Attribute)
        }
        has_abstract_method = any(
            isinstance(child, ast.FunctionDef)
            and any(
                (
                    isinstance(dec, ast.Name)
                    and dec.id == "abstractmethod"
                )
                or (
                    isinstance(dec, ast.Attribute)
                    and dec.attr == "abstractmethod"
                )
                for dec in child.decorator_list
            )
            for child in node.body
        )
        if bases & {"ABC", "Protocol"} or has_abstract_method:
            abstract_names.add(node.name)

    if not abstract_names:
        return False

    for node in _walk(tree):
        if not isinstance(node, ast.ClassDef) or node.name in abstract_names:
            continue
        if id(node) in guarded:
            continue
        bases = {
            base.id
            for base in node.bases
            if isinstance(base, ast.Name)
        } | {
            base.attr
            for base in node.bases
            if isinstance(base, ast.Attribute)
        }
        for abstract_name in bases & abstract_names:
            concrete_subclasses[abstract_name] = concrete_subclasses.get(abstract_name, 0) + 1

    return any(count == 1 for count in concrete_subclasses.values())


# --- Test-theater family: assertions and tests that only look like coverage ---


def _eval_shadow_scopes(tree: ast.AST) -> set[int]:  # noqa: C901 -- intraprocedural scope tracking, DEBT-ACCEPTED-COMPLEXITY-CORE-DETECTORS
    """ids de los ámbitos (módulo o función) que ligan el nombre `eval`.

    El hueco que esto cierra, declarado hasta el 2026-08-17: la comprobación era
    de MÓDULO ENTERO, así que un `def eval(self)` dentro de una clase perdonaba
    un `eval()` del builtin a cien líneas de distancia. Medido sobre la flota:
    8 archivos ligan `eval` y en LOS TRES reales la ligadura está ANIDADA
    -- `def eval(self)` en `Atlas/tests/test_production_pipeline.py:201`, y el
    juez LLM `def eval(question, pred, correct_answer)` en `train_test_gnn.py:264`.
    Por eso no vale estrechar a nivel de módulo: convictaría los tres, y uno de
    ellos es la fixture VC-049 de este kit, que existe para probar que el perdón
    es CORRECTO. La frontera es el alcance, no la altura.
    """
    ligan: set[int] = set()
    ambitos = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)

    def liga(nodo) -> bool:
        for hijo in ast.iter_child_nodes(nodo):
            if isinstance(hijo, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if hijo.name == "eval":
                    return True
                continue          # su cuerpo es otro ámbito
            for n in _walk(hijo):
                if isinstance(n, ast.arg) and n.arg == "eval":
                    return True
                if isinstance(n, ast.alias) and (n.asname or n.name.split(".")[0]) == "eval":
                    return True
                if (isinstance(n, ast.Name) and n.id == "eval"
                        and isinstance(n.ctx, (ast.Store, ast.Del))):
                    return True
        return False

    for nodo in _walk(tree):
        if isinstance(nodo, ambitos):
            args = getattr(nodo, "args", None)
            propios = any(a.arg == "eval" for a in
                          (list(args.args) + list(args.kwonlyargs) + list(args.posonlyargs))
                          ) if args else False
            if propios or liga(nodo):
                ligan.add(id(nodo))
    return ligan


def _binds_eval(tree: ast.AST) -> bool:
    """True if the module binds the name `eval` itself, so a bare `eval(...)`
    call in this file resolves to that binding and not to the builtin."""
    for node in _walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            and node.name == "eval"
        ):
            return True
        if isinstance(node, ast.arg) and node.arg == "eval":
            return True
        if isinstance(node, ast.alias) and (node.asname or node.name.split(".")[0]) == "eval":
            return True
        if (
            isinstance(node, ast.Name)
            and node.id == "eval"
            and isinstance(node.ctx, (ast.Store, ast.Del))
        ):
            return True
    return False


# flota 2026-08-17: 0 hits, y el cero es del detector YA ARREGLADO. Su hueco de
# módulo-entero se cerró el mismo día: la sombra de `eval` se juzga por ÁMBITO.
# Medido antes de elegir la frontera: 8 archivos de flota ligan `eval`, y en los
# tres reales la ligadura está ANIDADA -- incluida la fixture VC-049 de este
# kit, que existe para probar que el perdón es correcto.
def unsafe_eval(code: str) -> bool:  # noqa: C901 -- eval shadow resolution, DEBT-ACCEPTED-COMPLEXITY-CORE-DETECTORS
    """A real `eval(...)` call: the builtin, resolved as a CALL in parsed code.

    Exempt: `.eval()` methods (PyTorch/sklearn eval-MODE), the word "eval" inside
    comments, docstrings and string literals, and a bare `eval(...)` in a file
    that binds the name `eval` itself (a local wrapper shadows the builtin).
    `builtins.eval(...)` / `__builtins__.eval(...)` stay convicted regardless of
    any shadow, since they name the dangerous builtin explicitly.

    The regex alone (UNSAFE_EVAL, still used line-wise by dangerous_patterns and
    inside _DANGEROUS_SINK) cannot see either exemption: `\\s*\\(` matches ordinary
    prose that happens to end a clause with "eval (", and its `(?<!def )` clause
    pardons only the DEFINITION line, never the call site two lines below. Measured
    over the fleet (2899 .py files): 9 distinct hits before, 0 after -- all nine
    read and none a defect. Six were prose or pattern-literals ("la eval (residuo
    2...", a denylist tuple `("eval(", "exec(")`, another scanner's own
    `r"\\beval\\s*\\("`); two were `scores.append(eval(question, pred, label))` in
    train_test_gnn.py, calling the `def eval(...)` LLM-judge wrapper defined 20
    lines above -- three arguments that the builtin, whose 2nd and 3rd must be
    dicts, could not have accepted. Caught by fixture VC-049.

    Fuente ilegible ya no cae al regex: levanta UnparseableSource. El fallback
    existía para que un detector de seguridad no aprobara en silencio lo que no
    pudo leer, y era la mitad correcta del argumento -- la otra mitad es que un
    regex sobre texto que no es Python tampoco lo leyó. Ahora quien escanea
    registra el archivo como no juzgado, que es lo que de verdad se sabe.

    Narrower than the catalog on purpose: rules/vices.yaml vc-049-eval-of-non-literal
    also exempts `eval("...")` on a constant literal. That exemption is not copied
    here -- 0 fleet instances, so it would be untested narrowing.
    """
    tree = _parse(code)
    # Cadena de ámbitos: cada llamada se juzga contra los ámbitos que la
    # ENCIERRAN, no contra el archivo entero.
    ligan = _eval_shadow_scopes(tree)
    padre: dict[int, ast.AST] = {}
    for n_ in _walk(tree):
        for h in ast.iter_child_nodes(n_):
            padre[id(h)] = n_

    def sombreada(nodo) -> bool:
        actual = nodo
        while actual is not None:
            if id(actual) in ligan:
                return True
            actual = padre.get(id(actual))
        return False

    for node in _walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if (
            isinstance(func, ast.Attribute)
            and func.attr == "eval"
            and isinstance(func.value, ast.Name)
            and func.value.id in {"builtins", "__builtins__"}
        ):
            return True
        if isinstance(func, ast.Name) and func.id == "eval" and not sombreada(node):
            return True
    return False


# flota 2026-08-17: 5 hits (Atlas 3, simplecode 1, aequitas_os 1). Primero: Atlas/tools/verify_dgx08_recovery.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def _is_test_source_path(path: str) -> bool:
    normalized = path.replace("\\", "/").lower()
    parts = normalized.split("/")
    name = parts[-1]
    return (
        "tests" in parts
        or name.startswith("test_")
        or name.endswith("_test.py")
        or "control" in name
        or "fixture" in name
    )


def test_without_assert(code: str, path: str | None = None) -> bool:
    """A test function with no assert and no `with` block (e.g. pytest.raises)."""
    return bool(test_without_assert_findings(code, path))


def test_without_assert_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every test function with no oracle, as (def-line, function-name) --
    not just whether the FILE has one. A file with 5 assert-free tests only
    ever collapsed to one bool; this names each one so the caller knows
    which test to fix without grepping.
    """
    if path is not None and not _is_test_source_path(path):
        return []
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for fn in _test_funcs(tree):
        has_assert = any(isinstance(n, ast.Assert) for n in _walk(fn))
        has_with = any(isinstance(n, ast.With) for n in _walk(fn))
        # The oracle of a unittest.TestCase test is a METHOD CALL
        # (`self.assertEqual(...)`), which is never an `ast.Assert` node, so a
        # check that looks only for `ast.Assert`/`with` convicts every xUnit suite.
        # Measured over the fleet (2577 py files): 22 distinct hits before, 15
        # after; all 7 files that stopped firing are unittest suites whose every
        # flagged test asserts via TestCase methods. Caught by fixture VT-006.
        has_assert_call = any(
            isinstance(n, ast.Call)
            and isinstance(n.func, ast.Attribute)
            and (
                n.func.attr.startswith("assert")
                or n.func.attr.startswith("failUnless")
                # `pytest.fail(...)` / `self.fail(...)`: an unconditional,
                # deliberate failure call is exactly as much an oracle as
                # `assert False` -- it just doesn't spell "assert". Measured:
                # aequitas_os/backend/tests/test_no_scratch_in_tree.py::
                # test_no_scratch_written_into_tracked_tree walks the tree for
                # real violations and only fails via `pytest.fail(...)`.
                or n.func.attr == "fail"
            )
            for n in _walk(fn)
        )
        # A manual `raise AssertionError(...)` (or bare `raise AssertionError`)
        # is `assert False, msg` written out by hand -- the tail of a
        # hand-rolled `try: ...; raise AssertionError("should have raised")
        # except SomeError: pass`, the manual form of `pytest.raises`.
        # Measured: aequitas_os/backend/tests/test_dof_monitor_service.py::
        # test_module_never_opens_files_for_writing and
        # test_estados_financieros_adapter.py::
        # test_estado_resultados_rechaza_periodo_invertido both only fail
        # this way.
        has_raise_assertion_error = any(
            isinstance(n, ast.Raise)
            and (
                (
                    isinstance(n.exc, ast.Call)
                    and isinstance(n.exc.func, ast.Name)
                    and n.exc.func.id == "AssertionError"
                )
                or (isinstance(n.exc, ast.Name) and n.exc.id == "AssertionError")
            )
            for n in _walk(fn)
        )
        # A call to a bare (non-attribute) function whose own name starts
        # with `assert` (leading underscore stripped) is a delegated oracle:
        # the test calls a module-level assertion helper instead of
        # asserting inline. Narrower than trusting any helper call -- it only
        # trusts callables that name themselves the way `self.assertEqual`
        # does. Measured: office2office/tests/test_clarisworks_noise.py calls
        # `assert_absent(...)`/`assert_present(...)`; Atlas's
        # test_incremental_index.py calls `_assert_equivalente(...)` -- both
        # module-level helpers whose own bodies hold the real `assert`.
        has_delegated_assert_call = any(
            isinstance(n, ast.Call)
            and isinstance(n.func, ast.Name)
            and n.func.id.lstrip("_").startswith("assert")
            for n in _walk(fn)
        )
        if not (
            has_assert
            or has_with
            or has_assert_call
            or has_raise_assertion_error
            or has_delegated_assert_call
        ):
            hits.append((fn.lineno, f"{fn.name}() has no assert/with/assert-call/fail oracle"))
    return hits


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def assert_true(code: str) -> bool:
    """A test whose only assert is a literal `True` can never fail.

    Literal `assert True` statements inside a test that also has a real oracle
    do not make the test vacuous, so classify each test function independently.
    """
    tree = _parse(code)
    for fn in _test_funcs(tree):
        assertions = [n for n in _walk(fn) if isinstance(n, ast.Assert)]
        if len(assertions) == 1:
            test = assertions[0].test
            if isinstance(test, ast.Constant) and test.value is True:
                return True
    return False


# Structural identity of the two operands is not by itself a tautology: when the
# contract under test IS reflexivity, `x == x` calls the type's own __eq__, which
# can legitimately return False (a broken __eq__ is exactly what such a test
# exists to catch). The catalog entry for this same vice id has always said so --
# rules/vices.yaml `vt-009-tautological-assert` pairs `pattern: assert $X == $X`
# with `pattern-inside: def $F(...)` and a metavariable-regex excluding $F names
# containing reflexiv/equalit/__eq__/identity. This AST detector was written
# separately and never carried that clause, so the two implementations of VT-009
# disagreed, and the AST one convicted the fixture written to exonerate it:
# tests/fixtures/near_miss/VT-009.py:22, `assert point == point` inside
# `test_equality_is_reflexive`. The token list is copied from the catalog rather
# than reinvented, so the two cannot drift apart again.
#
# Known hole, measured rather than hidden: the pardon is granted per FUNCTION, so
# a real tautology sitting in a function whose name merely CONTAINS one of these
# tokens (`test_equality_of_totals`) goes unreported. Sized over the fleet (2577
# .py files): 14 function names match, covering 24 asserts, of which 0 are
# tautological -- this detector's fleet count is 2 before and 2 after the
# exemption. Narrowing it further means diverging from the catalog a second time,
# which is the defect the paragraph above exists to describe.
_EQ_CONTRACT_TEST = re.compile(r"reflexiv|equalit|__eq__|identity", re.I)


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def tautological_assert(code: str) -> bool:
    """An assert comparing a value against a structurally identical copy of itself.

    Exempt: asserts inside a function whose name declares equality/reflexivity as
    the contract under test (see rules/vices.yaml vt-009-tautological-assert).

    Also exempt: `is` / `is not` between two structurally-identical CALL
    expressions (e.g. `ctx.ast_of(x) is ctx.ast_of(x)`). For `==`, two
    identical calls to a deterministic function are trivially equal by value
    -- that's the tautology this detector hunts. But `is` checks object
    IDENTITY across two separate evaluations, which a fresh, uncached call
    would fail (a new object each time). Passing therefore depends on real
    behavior (memoization/caching), so it's a legitimate assertion, not a
    tautology -- measured on the fleet: red_python/tests/test_dimensions_
    contracts.py:62 asserts `ctx.ast_of(good) is ctx.ast_of(good)` to pin
    AuditContext's AST cache; breaking the cache breaks the assert. Bare
    name/attribute repeats (`assert x is x`) get no such exemption: with no
    Call in either operand, both sides denote the exact same single
    evaluation, so `is` there is as trivially true as `==`.
    """
    tree = _parse(code)
    exempt = {
        id(node)
        for fn in _walk(tree)
        if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef))
        and _EQ_CONTRACT_TEST.search(fn.name)
        for node in _walk(fn)
        if isinstance(node, ast.Assert)
    }
    for n in _walk(tree):
        if (
            isinstance(n, ast.Assert)
            and id(n) not in exempt
            and isinstance(n.test, ast.Compare)
            and len(n.test.ops) == 1
        ):
            left, right = n.test.left, n.test.comparators[0]
            if ast.dump(left) != ast.dump(right):
                continue
            if isinstance(n.test.ops[0], (ast.Is, ast.IsNot)) and (
                any(isinstance(x, ast.Call) for x in _walk(left))
            ):
                continue
            return True
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def impossible_condition(code: str) -> bool:
    """An `if` guard comparing two unequal constants (statically dead branch)."""
    tree = _parse(code)
    for n in _walk(tree):
        if (
            isinstance(n, ast.If)
            and isinstance(n.test, ast.Compare)
            and len(n.test.ops) == 1
            and isinstance(n.test.ops[0], ast.Eq)
        ):
            left, right = n.test.left, n.test.comparators[0]
            if (
                isinstance(left, ast.Constant)
                and isinstance(right, ast.Constant)
                and left.value != right.value
            ):
                return True
    return False


def _handler_is_blind(node: ast.expr | None) -> bool:
    """True only for a handler that names no specific failure: bare, or the roots."""
    if node is None:  # bare `except:`
        return True
    if isinstance(node, ast.Tuple):
        return any(_handler_is_blind(elt) for elt in node.elts)
    name = node.attr if isinstance(node, ast.Attribute) else getattr(node, "id", "")
    return name in ("Exception", "BaseException")


def _in_finally_teardown(tree: ast.AST, handler: ast.ExceptHandler) -> bool:
    """True if `handler` sits inside a `finally:` block of an enclosing `try`.

    That position is the close()-on-the-way-out idiom: the payload was already
    produced (or the real error already raised) by the OUTER try before control
    ever reaches its `finally`, so a second try/except there exists only to stop
    a teardown call (closing a file, an OLE container, a connection) from
    replacing whatever exception -- or return value -- is already in flight.
    Swallowing that teardown failure hides nothing the caller depended on.
    """
    for n in _walk(tree):
        if isinstance(n, ast.Try):
            for stmt in n.finalbody:
                for m in _walk(stmt):
                    if m is handler:
                        return True
    return False


# flota 2026-08-17: 5 hits (agente_inmobiliario 5). Primero: agente_inmobiliario/main.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def blind_except(code: str) -> bool:
    """A blind (`except:` / `except Exception:`) clause whose entire body is `pass`."""
    tree = _parse(code)
    for n in _walk(tree):
        # The handler's TYPE is what makes it blind, not the `pass`. This test
        # was missing entirely: the detector matched any handler whose body was
        # `pass`, so `except OSError: pass` -- best-effort cleanup that names the
        # one failure it tolerates -- was convicted alongside a bare `except:`.
        # Measured on the fleet (2577 .py, distinct_hits): 60 files fired before
        # the type test, 21 after; all 39 that stopped named a concrete class.
        if (
            isinstance(n, ast.ExceptHandler)
            and _handler_is_blind(n.type)
            and len(n.body) == 1
            and isinstance(n.body[0], ast.Pass)
        ):
            # A blind handler that only guards a `finally:` teardown call isn't
            # hiding a result -- the method's real payload/error already left
            # through the outer try above it. Measured on the fleet (2026-08-16,
            # 2274 .py under the tracked FLEET, distinct_hits): 21 hits before
            # this test, 20 after; the one that stopped was an OLE-container
            # `.close()` inside a `finally:`, called after `payload` had already
            # been read and was about to be returned two lines above it.
            if _in_finally_teardown(tree, n):
                continue
            return True
    return False


# Words a branch uses to tell the reader "this path is a failure" without
# itself doing anything about it (no raise, no nonzero exit). Fleet-measured
# 2026-08-16: every real hit spelled the failure out in a print/log message
# immediately discarded by a trailing exit(0) two lines later.
_FAILURE_WORDS = ("no se pudo", "fail", "falló", "error", "abort", "rechaz", "❌")


def _is_exit_zero_call(n: ast.AST) -> bool:
    if not isinstance(n, ast.Call):
        return False
    func = n.func
    name = (
        func.attr
        if isinstance(func, ast.Attribute)
        else (func.id if isinstance(func, ast.Name) else "")
    )
    return (
        name == "exit"
        and bool(n.args)
        and isinstance(n.args[0], ast.Constant)
        and n.args[0].value == 0
    )


def _branch_handles_it(stmts: list) -> bool:
    """True if this branch already exits/raises -- its outcome isn't discarded."""
    for node in stmts:
        for sub in _walk(node):
            if isinstance(sub, ast.Raise) or _is_exit_zero_call(sub):
                return True
            if isinstance(sub, ast.Call):
                func = sub.func
                name = func.attr if isinstance(func, ast.Attribute) else (
                    func.id if isinstance(func, ast.Name) else ""
                )
                if name == "exit":  # exit(1), exit(rc), etc. -- also "handled"
                    return True
    return False


def _branch_says_failure(stmts: list) -> bool:
    for node in stmts:
        for sub in _walk(node):
            text = None
            if isinstance(sub, ast.Constant) and isinstance(sub.value, str):
                text = sub.value
            elif isinstance(sub, ast.JoinedStr):
                text = "".join(
                    v.value for v in sub.values
                    if isinstance(v, ast.Constant) and isinstance(v.value, str)
                )
            if text and any(w in text.lower() for w in _FAILURE_WORDS):
                return True
    return False


def _statement_lists(tree: ast.AST):
    """Every body/orelse/finalbody statement list in the tree, innermost first."""
    for node in _walk(tree):
        for field in ("body", "orelse", "finalbody"):
            stmts = getattr(node, field, None)
            if isinstance(stmts, list) and stmts and all(
                isinstance(s, ast.stmt) for s in stmts
            ):
                yield stmts


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def unconditional_exit_zero(code: str) -> bool:
    """`exit(0)` that falls through an if/else which already computed failure.

    Not every `exit(0)` is the vice: one nested directly inside an `if` whose
    condition IS the success check (`if ok(): exit(0)`), or that is simply the
    last line of a script with no failure branch to discard, is a script
    reporting a real, unexamined-because-there-was-none success. The vice is
    narrower and measured: an `if/else` where a branch already prints "this
    failed" in words, then BOTH branches fall through to the same unconditional
    exit(0) two lines later -- the failure was computed and then thrown away.
    Fleet measurement 2026-08-16 (unconditional_exit_zero, 29 distinct hits):
    28 were the conditioned/no-failure-branch shape above; only one --
    `agente_inmobiliario/movilidad.py`, whose `else:` branch prints
    "No se pudo calcular movilidad." and then a bare trailing `sys.exit(0)`
    ignores it -- had a computed failure state actually discarded.
    """
    tree = _parse(code)
    for stmts in _statement_lists(tree):
        for i, stmt in enumerate(stmts):
            if i == 0:
                continue
            if not (isinstance(stmt, ast.Expr) and _is_exit_zero_call(stmt.value)):
                continue
            prev = stmts[i - 1]
            if not (isinstance(prev, ast.If) and prev.orelse):
                continue
            if _branch_handles_it(prev.body) or _branch_handles_it(prev.orelse):
                continue
            if _branch_says_failure(prev.body) or _branch_says_failure(prev.orelse):
                return True
    return False


# --- Other detectors carried in from the secondary registry ---


_REQUEST_INPUT_ATTRS = frozenset({"args", "files", "form", "json", "values", "data"})
# A coercion is a validation: whatever `int(sys.argv[1])` returns cannot carry a
# shell metacharacter or a SQL fragment. Not descending into these is what keeps
# `kill -TERM {int(argv[1])}` out of the docket.
_SAFE_COERCERS = frozenset({"int", "float", "bool", "len", "abs", "round"})
_SHELL_SUBPROCESS = frozenset({"run", "call", "check_call", "check_output", "Popen"})


def _external_expr(node: ast.AST) -> bool:  # noqa: C901 -- external input detection, DEBT-ACCEPTED-COMPLEXITY-CORE-DETECTORS
    """True if this expression *is* raw external input, coercions excluded.

    Only `sys.argv` / `sys.stdin` count -- never a bare `argv`, which in this
    fleet is overwhelmingly a `main(argv=None)` parameter fed by argparse.
    """
    if isinstance(node, ast.Compare):
        # A membership/comparison test converts input into a decision; its raw
        # operand must not leak through the recursive walk below.
        return False
    if isinstance(node, ast.Call):
        function = node.func
        if isinstance(function, ast.Name) and function.id in _SAFE_COERCERS:
            return False
        if isinstance(function, ast.Name) and function.id == "input":
            return True
        if (
            isinstance(function, ast.Attribute)
            and function.attr in ("read", "readline", "readlines")
            and _external_expr(function.value)
        ):
            return True
    if isinstance(node, ast.Attribute):
        if (
            node.attr in ("argv", "stdin")
            and isinstance(node.value, ast.Name)
            and node.value.id == "sys"
        ):
            return True
        if node.attr in _REQUEST_INPUT_ATTRS:
            base = node.value
            name = base.id if isinstance(base, ast.Name) else getattr(base, "attr", "")
            if name == "request":
                return True
    return any(_external_expr(child) for child in ast.iter_child_nodes(node))


def _tainted_names(tree: ast.AST) -> set[str]:
    """Names assigned from external input. Two passes: enough for `a = argv[1]; b = a`."""
    return _two_pass_tainted_names(tree, _external_expr)


def _carries_taint(node: ast.AST, tainted: set[str]) -> bool:
    return _external_expr(node) or any(
        isinstance(s, ast.Name) and s.id in tainted for s in _walk(node)
    )


def _built_dynamically(node: ast.AST) -> bool:
    """A query string assembled at runtime (f-string, %, +, .format) rather than
    a constant with bound parameters."""
    if isinstance(node, ast.JoinedStr):
        return True
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mod)):
        return True
    return isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "format"


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def io_without_validation(code: str) -> bool:  # noqa: C901 -- taint-to-sink dataflow, DEBT-ACCEPTED-COMPLEXITY-CORE-DETECTORS
    """External input (request args, sys.argv, stdin) reaching a shell/eval/SQL sink.

    The sink must actually be injectable: `os.system`, a subprocess call with
    `shell=True`, `eval`/`exec`, or a `.execute()` whose query is concatenated
    instead of parameterised. `subprocess.run([...])` with an argument LIST is
    not a sink -- there is no shell to inject into -- and that single test is
    what separates the vice from fifteen of the eighteen fleet firings.
    """
    tree = _parse(code)
    tainted = _tainted_names(tree)
    for n in _walk(tree):
        if not isinstance(n, ast.Call) or not n.args:
            continue
        func, arg0 = n.func, n.args[0]
        if isinstance(func, ast.Name) and func.id in ("eval", "exec"):
            if _carries_taint(arg0, tainted):
                return True
        if isinstance(func, ast.Attribute):
            base = func.value
            base_name = base.id if isinstance(base, ast.Name) else ""
            if base_name == "os" and func.attr in ("system", "popen"):
                if _carries_taint(arg0, tainted):
                    return True
            if func.attr in _SHELL_SUBPROCESS and any(
                kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True
                for kw in n.keywords
            ):
                if _carries_taint(arg0, tainted):
                    return True
            if func.attr in ("execute", "executescript", "executemany"):
                if _built_dynamically(arg0) and _carries_taint(arg0, tainted):
                    return True
    return False


def _test_nested_function_ids(tree: ast.AST) -> set[int]:
    """id() of every FunctionDef nested inside a `test*`-named function.

    A closure a test redefines locally to isolate itself (a fake `subprocess.run`
    capturing into that test's own dict, say) is not shipped logic -- it never
    ships, it never diverges in production, and pytest convention is to rebuild
    it per test rather than share a mutable double across tests. The top-level
    `not fn.name.startswith("test")` check below only ever looked at a
    function's own name, so a same-shaped closure nested inside two different
    `test_*` functions slipped through it. Measured on the fleet (2026-08-16):
    aequitas_os/backend/tests/test_sat_portal_capture_service.py's `fake_run`,
    redefined identically inside three separate tests.
    """
    skip: set[int] = set()

    def visit(node: ast.AST, in_test: bool) -> None:
        for child in ast.iter_child_nodes(node):
            child_in_test = in_test
            if isinstance(child, ast.FunctionDef):
                if in_test:
                    skip.add(id(child))
                child_in_test = in_test or child.name.startswith("test")
            visit(child, child_in_test)

    visit(tree, False)
    return skip


# flota 2026-08-17: 14 hits (aequitas_os 9, Atlas 4, cuenza 1). Primero: Atlas/playbooks/station-kernel-dev-ft/assets/benchmark_kernels.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def uncritical_copy_paste(code: str) -> bool:
    """Two non-test functions with structurally identical bodies (copy-pasted without review).

    Skips a bare `_`-named function too: the marimo/notebook convention names
    every cell `_`, so two cells sharing that name is the tool's convention,
    not a sign nobody read the second one. Measured on the fleet (2026-08-16):
    Atlas's jax-intro.py notebook, two `@app.cell def _(...)` demo cells.
    """
    tree = _parse(code)
    skip_ids = _test_nested_function_ids(tree)
    signatures: dict[str, int] = {}
    for fn in _walk(tree):
        if (
            isinstance(fn, ast.FunctionDef)
            and not fn.name.startswith("test")
            and fn.name != "_"
            and id(fn) not in skip_ids
        ):
            body = _body_without_docstring(fn)
            if len(body) < 3:
                continue
            signature = " | ".join(_stmt_signature(stmt) for stmt in body)
            signatures[signature] = signatures.get(signature, 0) + 1
            if signatures[signature] >= 2:
                return True
    return False



# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def blanket_filterwarnings(code: str) -> bool:
    """A bare `filterwarnings("ignore")` with no category filter."""
    if _BLANKET_WARN.search(code):
        return True
    try:
        tree = _parse(code)
        for node in _walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "filterwarnings":
                if node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value == "ignore" and len(node.args) == 1:
                    return True
    except UnparseableSource:
        pass
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def unjustified_nosemgrep(code: str) -> bool:
    """A `# nosemgrep` suppression comment with no trailing justification."""
    for m in _NOSEMGREP.finditer(code):
        if not m.group(1).strip():
            return True
    return False


# Only the environment, and only through os. Keyed on the attribute name alone in
# the first version, which pardoned `config.get("soffice_path", r"C:\\Program
# Files\\...")` -- ANY mapping's `.get` default. A dict default is not an
# override the operator controls; that file happened to be a known false
# positive, so the rule was right by accident, and the same rule would have
# pardoned `d.get("k", "/home/luis/secret")`.
_ENV_OBJECTS = frozenset({"environ", "os"})
_ENV_LOOKUPS = frozenset({"get", "getenv", "setdefault"})
# The literal a string Constant must START with to be a machine path -- the
# unquoted form of _ABS_PATH's quote-adjacency requirement, and it stays
# anchored. Unanchoring it was tried and MEASURED: matching the path anywhere in
# the value took the fleet from 32 hits to 38, and all 14 new ones were paths in
# PROSE -- module docstrings saying which corpus a service parses, an HTML
# placeholder, `cuenza/scripts/generate_golden_audit.py` listing `C:\`, `/home/`
# and `/Users/` as the markers it hunts, and this kit's own near-miss fixture
# HP-001.py explaining the pattern. That is the "meta lists of path markers used
# as search patterns" class the fleet measurement already named. The cost of
# staying anchored is a path in a middle piece of implicitly concatenated
# literals (Atlas tools/pss_verdict_join.py:269) -- also prose, so the loss is
# consistent rather than a hole.
_ABS_PATH_VALUE = re.compile(r"^(?:[A-Za-z]:[\\/]|/(?:Users|home)/)(?!\{)")
# Una ruta bajo una raíz ESTÁNDAR de Windows no es "de esta máquina": existe
# igual en cualquier instalación del sistema, como /usr/ o /etc/ en Linux -- que
# este detector ya no mira, porque `_ABS_PATH_VALUE` sólo ancla en /Users/ y
# /home/. La asimetría era el defecto: en Windows condenaba TODA raíz.
# Medido el 2026-08-17: su único caso de flota es
# office2office/registry_config.py:173, que crea el directorio TextConv de
# Microsoft Office. Esa ruta no cambia de máquina a máquina.
_RAIZ_DE_PLATAFORMA = re.compile(
    r"^[A-Za-z]:[\\/](?:Program Files(?: \(x86\))?|Windows|ProgramData|"
    r"Users[\\/](?:Public|All Users|Default))[\\/]", re.I)


# A CONFIG mapping's default is overridable too, and by the same operator. This
# was refused on 2026-08-17 with the argument that "a dict default is not
# something the operator controls", and that argument was wrong for one narrow
# shape: a receiver literally named `config`/`settings`/`cfg` IS the loaded
# configuration, and its `.get(key, default)` is the documented override point.
# Kept to that receiver vocabulary on purpose -- `d.get("k", "/home/luis/secret")`
# on an arbitrary dict stays convicted. Measured: fleet 18 -> 16 hits, and the two
# it pardons are exactly the two files the suite already listed as this false
# positive class (office2office/engines/{libreoffice,fast_binary}_engine.py, both
# an OS-standard install dir behind `config.get`). Zero new, zero collateral.
_CONFIG_RECEIVERS = frozenset(
    {"config", "cfg", "conf", "settings", "options", "opts", "params", "defaults"})


def _second_positional_default_str_ids(
    tree: ast.AST, is_target_call: Callable[[ast.Call], bool]
) -> set[int]:
    """ids of string Constants that are the SECOND positional arg of a call
    `is_target_call` accepts -- shared by `_config_default_paths` and
    `_env_default_paths` (found 2026-08-28, dedup pass: both walked the same
    "call with >=2 args, check its shape, take args[1] if it's a string
    Constant" loop, differing only in which calls they accept).
    """
    ok: set[int] = set()
    for node in _walk(tree):
        if not isinstance(node, ast.Call) or len(node.args) < 2:
            continue
        if not is_target_call(node):
            continue
        default = node.args[1]
        if isinstance(default, ast.Constant) and isinstance(default.value, str):
            ok.add(id(default))
    return ok


def _is_config_get_call(node: ast.Call) -> bool:
    fn = node.func
    if not isinstance(fn, ast.Attribute) or fn.attr != "get":
        return False
    owner = fn.value
    name = (owner.attr if isinstance(owner, ast.Attribute)
            else getattr(owner, "id", ""))
    return name.lower() in _CONFIG_RECEIVERS


def _config_default_paths(tree: ast.AST) -> set[int]:
    """ids of string Constants that are the default of a config mapping's .get()."""
    return _second_positional_default_str_ids(tree, _is_config_get_call)


# Lo que convierte un literal de ruta en DEPENDENCIA y no en dato: alguien lo
# abre, lo resuelve o lo ejecuta. Cualquier otra llamada -- la función bajo
# prueba, un `assert`, un `in` -- lo deja siendo una cadena.
_PATH_CONSUMERS = frozenset(
    {"Path", "PurePath", "PosixPath", "WindowsPath", "open", "exists", "is_file",
     "is_dir", "run", "call", "check_output", "check_call", "Popen", "system",
     "copy", "copy2", "copytree", "move", "rmtree", "remove", "unlink",
     "makedirs", "mkdir", "listdir", "walk", "glob", "chdir", "stat"})


def _test_fixture_paths(tree: ast.AST) -> set[int]:
    """ids de literales de ruta que son DATO DE PRUEBA, no dependencia.

    Medido el 2026-08-17 sobre los 12 hits de flota: dos de ellos son cadenas
    que el test compara con `in` y jamás ejecuta -- una línea de comando falsa
    en `Atlas/tests/test_deteccion_de_procesos.py:237` que sólo sirve de control
    negativo, y `r"C:\\tmp\\folder"` en `red_python/tests/test_filters.py:122`,
    que es la ENTRADA de la función que quita prefijos largos.

    La frontera es lo que CONSUME el literal, no dónde vive: dentro de un
    `def test_*`, un literal queda exento salvo que sea argumento de una llamada
    de `_PATH_CONSUMERS`. Así `subprocess.run("/home/...")` dentro de un test
    sigue condenado -- eso sí es una dependencia de máquina -- y un
    `BLOG_REPO = Path("/home/...")` a nivel de módulo tampoco se toca, porque
    no está dentro de ninguna función de prueba.
    """
    ok: set[int] = set()
    for fn in _walk(tree):
        if not (isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef))
                and fn.name.startswith("test_")):
            continue
        consumidos: set[int] = set()
        for node in _walk(fn):
            if not isinstance(node, ast.Call):
                continue
            f = node.func
            nombre = f.attr if isinstance(f, ast.Attribute) else getattr(f, "id", "")
            if nombre in _PATH_CONSUMERS:
                for arg in node.args:
                    for parte in _walk(arg):
                        consumidos.add(id(parte))
        for node in _walk(fn):
            if (isinstance(node, ast.Constant) and isinstance(node.value, str)
                    and id(node) not in consumidos):
                ok.add(id(node))
    return ok


# Generalizes _test_fixture_paths/_PATH_CONSUMERS above for any "the literal
# IS the attack, the file IS the defense" detector -- destructive_without_dryrun
# (rm -rf / DROP TABLE as adversarial test input) and agent_threats.
# prompt_injection (instruction-override phrasing fed to a validator under
# test, not to a real agent) share the exact same shape hardcoded_path already
# solved: a literal inside a `def test_*` is TEST DATA unless it is actually
# passed to a real executor -- something that runs a shell/SQL command, or
# invokes a real agent/LLM call, rather than the function/detector under test.
#
# Root-caused 2026-08-26 (fleet: Atlas): destructive_without_dryrun and
# prompt_injection had each grown a same-line/file-wide ticketed-comment
# escape hatch instead, requiring a human to remember one on every future
# adversarial payload -- exactly the pattern hardcoded_path never needed a
# human for, because it is structural. Two categories were being conflated:
# genuinely ambiguous PRODUCTION code (blocking_sleep, unmanaged_resource_open
# -- a human's judgment call is the only way to tell those apart, so the
# ticketed comment stays correct there) versus TEST fixtures proving a defense
# rejects an attack, which this module already knew how to detect without any
# annotation at all.
def _simple_string_aliases(fn: ast.AST) -> dict[str, set[int]]:
    """`name -> {ids of Constant str nodes reachable through simple
    assignment}`, resolved to a fixpoint over `payload = "..."` /
    `alias = payload` chains. Without this, `payload = "rm -rf x"` followed
    by `subprocess.run(payload)` would never mark the original literal
    consumed -- the call's argument is the Name `payload`, not the literal
    itself -- and a test that genuinely executes an adversarial string
    through one level of variable indirection would be wrongly exempted."""
    aliases: dict[str, set[int]] = {}
    changed = True
    while changed:
        changed = False
        for node in _walk(fn):
            if not (isinstance(node, ast.Assign) and len(node.targets) == 1
                    and isinstance(node.targets[0], ast.Name)):
                continue
            target = node.targets[0].id
            value = node.value
            reached: set[int] = set()
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                reached.add(id(value))
            elif isinstance(value, ast.Name) and value.id in aliases:
                reached |= aliases[value.id]
            if reached and not reached <= aliases.get(target, set()):
                aliases.setdefault(target, set()).update(reached)
                changed = True
    return aliases


def _adversarial_test_data_ids(
    tree: ast.AST, attr_consumers: frozenset[str], bare_consumers: frozenset[str] = frozenset()
) -> set[int]:
    """ids of string-literal Constant nodes that are adversarial TEST DATA,
    not a real attack: inside a `def test_*`, exempt unless passed (directly,
    or via one level of simple variable aliasing -- see
    `_simple_string_aliases`) as an argument to a real executor call.

    `attr_consumers` matches ONLY as a method/attribute call (`subprocess.run`,
    `os.system`, `cursor.execute`) -- a BARE name like `run(...)` or
    `call(...)` is exactly as likely to be the validator/function under test
    itself (the whole point of the adversarial test), so a bare name is too
    ambiguous to convict on. `bare_consumers` is for names unambiguous even
    bare (`eval`, `exec` -- nobody defines their own function under test
    called `eval`)."""
    ok: set[int] = set()
    for fn in _walk(tree):
        if not (isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef))
                and fn.name.startswith("test_")):
            continue
        consumed = _real_executor_consumed_ids(fn, attr_consumers, bare_consumers)
        for node in _walk(fn):
            if (isinstance(node, ast.Constant) and isinstance(node.value, str)
                    and id(node) not in consumed):
                ok.add(id(node))
    return ok


def _real_executor_consumed_ids(
    fn: ast.AST, attr_consumers: frozenset[str], bare_consumers: frozenset[str]
) -> set[int]:
    """ids of AST nodes (literals and their aliases) passed as an argument to
    a real executor call inside `fn` -- the part of `_adversarial_test_data_ids`
    that decides what counts as "actually executed", split out to keep that
    function's own control flow simple."""
    aliases = _simple_string_aliases(fn)
    consumed: set[int] = set()
    for node in _walk(fn):
        if not isinstance(node, ast.Call):
            continue
        f = node.func
        is_real_executor = (
            (isinstance(f, ast.Attribute) and f.attr in attr_consumers)
            or (isinstance(f, ast.Name) and f.id in bare_consumers)
        )
        if not is_real_executor:
            continue
        for arg in node.args:
            for part in _walk(arg):
                consumed.add(id(part))
                if isinstance(part, ast.Name) and part.id in aliases:
                    consumed |= aliases[part.id]
    return consumed


def _mask_ast_spans(code: str, nodes: Sequence[ast.AST]) -> str:
    """Blank the source text of each node in place (spaces, newlines kept),
    so a downstream whole-file regex check no longer sees it but every other
    line/column in the file is unaffected. Only single-line spans are masked
    -- a multi-line literal is left untouched (conservative: stays subject to
    the original check rather than risking a masking bug silencing real code)."""
    if not nodes:
        return code
    lines = code.splitlines(keepends=True)
    for node in nodes:
        lineno = getattr(node, "lineno", None)
        end_lineno = getattr(node, "end_lineno", None)
        col = getattr(node, "col_offset", None)
        end_col = getattr(node, "end_col_offset", None)
        if lineno is None or end_lineno is None or col is None or end_col is None:
            continue
        if lineno != end_lineno or not (1 <= lineno <= len(lines)):
            continue
        line = lines[lineno - 1]
        lines[lineno - 1] = line[:col] + (" " * (end_col - col)) + line[end_col:]
    return "".join(lines)


def _mask_adversarial_test_literals(
    tree: ast.AST, code: str, attr_consumers: frozenset[str], bare_consumers: frozenset[str] = frozenset()
) -> str:
    """`code` with every adversarial-test-data string literal (see
    `_adversarial_test_data_ids`) blanked out, so a whole-file vice regex run
    against the RESULT no longer matches on data a test uses to prove a
    defense rejects the attack -- while any occurrence outside that shape
    (real production code, or a shape too dynamic to attribute to one AST
    node) is left completely intact and still convicts normally."""
    exempt_ids = _adversarial_test_data_ids(tree, attr_consumers, bare_consumers)
    spans = [
        node for node in _walk(tree)
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) in exempt_ids
    ]
    return _mask_ast_spans(code, spans)


def _is_env_lookup(call: ast.Call) -> bool:
    """True for os.environ.get / os.getenv / os.environ.setdefault, only."""
    fn = call.func
    if not isinstance(fn, ast.Attribute) or fn.attr not in _ENV_LOOKUPS:
        return False
    owner = fn.value
    name = (owner.attr if isinstance(owner, ast.Attribute)
            else getattr(owner, "id", ""))
    return name in _ENV_OBJECTS


def _env_default_paths(tree: ast.AST) -> set[int]:
    """ids of string Constants that are the DEFAULT of an env-var lookup.

    `os.environ.get("DATA_ROOT", "/home/luis/data")` names a machine path, but
    the machine is no longer baked in: anyone can redirect it without editing
    code, which is the entire point of the finding. Measured 2026-08-17 -- of the
    17 fleet fixes that left this detector still firing, 6 were exactly this
    shape, and the pattern's own comment had already named the class as needing
    context "this line-level regex cannot see". It needed an AST, so here it is.

    Deliberately narrow: only the second POSITIONAL argument, and only for
    get/getenv/setdefault. A literal anywhere else on the same line stays
    convicted -- `[os.environ.get("A", "/home/a"), "/home/b"]` still fires on
    the second element, which a line-scoped fix could not manage.
    """
    return _second_positional_default_str_ids(tree, _is_env_lookup)


# flota 2026-08-17: 5 hits. TRES son capturas reales, registradas como deuda
# en su repo: aequitas_os sat_cfdi_verification_service.py:39 y
# test_author_doctrine_ingestion.py:21, y poe_systems Full_dimensions_audit.py:16.
# Las otras DOS viven en office2office/.protocol/snapshots/, copias congeladas
# donde el detector acierta. CERO falsos positivos: cuatro clases cerradas hoy
# -- default de env 32->20, default de mapping 18->16, dato de prueba 12->6,
# raiz de plataforma 6->5.
def hardcoded_path(code: str) -> bool:
    """A hardcoded absolute machine path (e.g. /home/..., /Users/..., C:\\...) in a string literal.

    NOT an f-string whose path segment is immediately parameterized
    (`f"/home/{user}/..."`) -- see _ABS_PATH_VALUE -- and NOT a literal serving as the
    default of an env-var lookup, which is overridable by definition.
    """
    return bool(hardcoded_path_findings(code))


def hardcoded_path_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every hardcoded absolute path literal in the file, as (line, literal)."""
    tree = _parse(code)
    exempt = (_env_default_paths(tree) | _config_default_paths(tree)
              | _test_fixture_paths(tree))
    # An f-string's `/home/` prefix is a Constant PART of a JoinedStr, so walking
    # Constants naively would convict `f"/home/{user}/x"` -- the one shape the
    # regex was deliberately built to spare. Its parts are excluded here and the
    # regex keeps that judgement, `(?!\{)` included.
    for j in _walk(tree):
        if isinstance(j, ast.JoinedStr):
            for part in _walk(j):
                exempt.add(id(part))
    hits: list[tuple[int, str]] = []
    for n in _walk(tree):
        if (isinstance(n, ast.Constant) and isinstance(n.value, str)
                and id(n) not in exempt and _ABS_PATH_VALUE.search(n.value)
                and not _RAIZ_DE_PLATAFORMA.match(n.value)):
            hits.append((n.lineno, f"hardcoded absolute path {n.value!r}"))
    return hits


# Alembic names its two migration entry points `upgrade` and `downgrade` by
# convention. A `downgrade()` that drops the table its `upgrade()` created is the
# WHOLE POINT of a reversible migration -- and it is the dominant shape in the
# fleet: a first attempt at widening this detector to cover library calls went
# from 0 to 115 hits, of which ~90 were exactly this. A destructive call there is
# the feature, so the enclosing function name is the exemption.
_MIGRATION_ENTRYPOINTS = frozenset({"upgrade", "downgrade"})
# `shutil.rmtree` was tried here and REMOVED, measured: it produced 15 of 20
# hits, every one a tool deleting a workspace it manages itself
# (`prepare_workspace`, `convert_with_marker`, most with ignore_errors=True).
# Removing a DIRECTORY is not dropping a data store, and shell `rm -rf` is
# already destructive_without_dryrun's docket -- keeping it here both
# double-counts and drowns the signal.


# The `verb_noun` convention, which is how most of these calls announce
# themselves. Applied to a bare name AND to a method: the first version tested it
# only on `ast.Name`, so `storage.purge_bucket(id)` and `provider.destroy_volume(v)`
# walked past -- caught by the behaviour layer, which pins both.
_STORE_DROP_NAME = re.compile(
    r"(?:delete|drop|destroy|wipe|purge)_"
    r"(?:database|db|datastore|all_tables|all_data|volume|bucket|collection|index|table)\w*",
    re.I,
)
# Names that drop a store without carrying the convention in them.
_STORE_DROP_METHODS = frozenset({"flushall", "flushdb"})
# A function whose WHOLE name is the destructive verb announces itself as much as
# `delete_collection` does. Bare verbs only, deliberately: `cleanup`, `refresh`
# and `_verify_or_write_pin` are not in here, and each is a RED case in the
# behaviour battery precisely to keep this set from creeping.
_ANNOUNCING_NAMES = frozenset(
    {"clear", "reset", "drop", "purge", "wipe", "destroy", "flush", "truncate", "delete"})


# An `if` whose test names the destruction IS the confirmation gate, even when
# no call is shaped like `confirm(...)`. Found against Atlas
# `rag/qdrant_manager.py:202`: `delete_collection` sits inside
# `if self.on_model_mismatch == "recreate":`, an opt-in whose default is "raise"
# and whose caller must pass `rebuild=True` to reach it. Convicting that is the
# instrument lying. Only the `body` branch is pardoned -- a drop in the `else` of
# `if force:` is precisely the unguarded path.
_OPT_IN_GATE = re.compile(
    r"\b(?:force|confirm\w*|yes|recreate|rebuild|overwrite|reset|wipe|purge|"
    r"destructive|dry.?run)\b", re.I)


def _drops_whole_store(node: ast.AST) -> bool:
    """A call that removes an entire store, by naming convention or by library."""
    if not isinstance(node, ast.Call):
        return False
    if isinstance(node.func, ast.Name):
        name = node.func.id
    elif isinstance(node.func, ast.Attribute):
        name = node.func.attr
    else:
        return False
    return name in _STORE_DROP_METHODS or bool(_STORE_DROP_NAME.fullmatch(name))



# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def _enclosing_functions(tree: ast.AST) -> dict[int, ast.AST]:
    enclosing: dict[int, ast.AST] = {}
    for function in _walk(tree):
        if isinstance(function, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for node in _walk(function):
                enclosing.setdefault(id(node), function)
    return enclosing


def _opt_in_nodes(tree: ast.AST) -> set[int]:
    gated: set[int] = set()
    for branch in _walk(tree):
        if isinstance(branch, ast.If) and _OPT_IN_GATE.search(ast.unparse(branch.test)):
            for statement in branch.body:
                gated.update(id(node) for node in _walk(statement))
    return gated


def _drop_is_announced(call: ast.AST, function: ast.AST | None) -> bool:
    if function is None or not hasattr(function, "name"):
        return False
    fn_name: str = getattr(function, "name", "")
    if fn_name in _MIGRATION_ENTRYPOINTS:
        return True
    called = ""
    if isinstance(call, ast.Call):
        called = call.func.attr if isinstance(call.func, ast.Attribute) else getattr(call.func, "id", "")
    return bool(
        called == fn_name
        or fn_name in _ANNOUNCING_NAMES
        or _STORE_DROP_NAME.fullmatch(fn_name)
    )


def destructive_action_without_confirmation(code: str) -> bool:
    """A call that drops a whole data store, with no confirmation gate.

    Two exemptions, both measured rather than assumed: a migration entrypoint
    (`upgrade`/`downgrade`) is EXPECTED to drop what it created, and any
    confirmation-shaped call in the file satisfies the gate.

    Not shell `rm -rf` and not SQL `DROP`/`TRUNCATE` -- those belong to
    destructive_without_dryrun, and duplicating them here double-counts.
    """
    tree = _parse(code)
    if _CONFIRM_GATE.search(code):
        return False
    names = {f.name for f in _walk(tree)
             if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))}
    # A module that defines BOTH entrypoints is an alembic revision file. Its
    # helpers (`_drop_table_if_exists`) are part of the same reversible unit, so
    # exempting only the two entrypoints by name left the helper convicted.
    if _MIGRATION_ENTRYPOINTS <= names:
        return False
    # The enclosing function of every node, or None for module level. Walking
    # only INSIDE functions was the first version, and it missed the worst shape
    # there is: `storage.purge_bucket(bucket_id)` as a bare module-level
    # statement, which runs on IMPORT, before any caller decides anything. The
    # behaviour layer pins that case.
    enclosing = _enclosing_functions(tree)
    gated = _opt_in_nodes(tree)

    for n in _walk(tree):
        if not _drops_whole_store(n) or id(n) in gated:
            continue
        fn = enclosing.get(id(n))
        # A thin wrapper whose own name is the call it forwards
        # (`def delete_collection(...): vector_store.delete_collection(...)`)
        # announces the deletion in its signature; the confirmation belongs at
        # ITS caller, not inside it. The vice is a destructive call somewhere
        # its name does not warn you about.
        # Widened, measured on Atlas `rag/qdrant_manager.py:398`: `def clear(self):
        # self.delete_collection()`. Exact name equality pardoned the wrapper at
        # :394 and convicted its one-line caller, which announces the same thing.
        # The set is bare verbs only -- `cleanup` is NOT in it, and the RED case
        # `def cleanup(db): db.drop_database()` stays convicted because of that.
        if _drop_is_announced(n, fn):
            continue
        return True
    return False



# flota 2026-08-17: 1 hits (Atlas 1). Primero: Atlas/playbooks/multi-sparks-through-switch/assets/spark_cluster_setup/node_scripts/detect_and_configure_cluster_networking.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def invisible_debt(code: str) -> bool:
    """A comment admitting a shortcut/quick-fix/workaround with no tracked follow-up."""
    return bool(_INVISIBLE_DEBT.search(code))


# flota 2026-08-17: 2 hits (office2office 2). Primero: office2office/engines/legacy_text_engine.py.
# Es RESIDUAL, no capturas: mide lo que convictaría hoy.
def self_polluting_tooling(code: str) -> bool:
    """A temp-directory helper pinned to point back inside its own working tree."""
    if _SELF_POLLUTING.search(code):
        return True
    try:
        tree = _parse(code)
        for node in _walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in ("TemporaryDirectory", "mkdtemp"):
                for kw in node.keywords:
                    if kw.arg == "dir":
                        return True
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Attribute) and target.attr == "tempdir":
                        return True
    except UnparseableSource:
        pass
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def bom_in_config(code: str) -> bool:
    """A UTF-8 byte-order-mark at the start of a config file (breaks strict parsers)."""
    return code.startswith("\ufeff")


def _announces_handoff(code: str) -> bool:
    """True if some line OPENS a handoff note, rather than merely mentioning one.

    A note announces itself; a wrapped comment does not. Found on the kit's own
    `verification/dangling_refs.py:103`, where a sentence begun on :101 wrapped
    so that `# HANDOFF/STATE file.` started a line -- a reference to the file
    kind, inside a comment about exemption prefixes, convicted as an incomplete
    handoff note. Any comment block long enough to wrap can produce this.
    """
    prev_comment = False
    for raw in code.splitlines():
        line = raw.strip()
        is_comment = line.startswith(("#", "//"))
        if _HANDOFF_MARK.search(raw) and not prev_comment:
            return True
        prev_comment = is_comment and bool(line)
    return False


# flota 2026-08-17: 0 hits. Es RESIDUAL, no capturas: mide lo que
# convictaría hoy, no lo que atrapó y ya se arregló. Sin hits no hay
def ambiguous_handoff(code: str) -> bool:
    """A handoff/status note missing one of the required fields (goal/state/evidence/blockers/next)."""
    text = code.lower()
    if not _announces_handoff(code):
        return False
    return not all(field in text for field in _HANDOFF_FIELDS)


# `.get` AND `.pop`: the two spellings of the SAME unpack, not two vices.
#
# `.pop()` is the spelling an evader would actually reach for -- besides hiding
# the parameter it removes the key from whatever `**kwargs` is passed onward, so
# the hidden argument does not resurface downstream. Measured 2026-09-15 before
# widening this set: the detector convicted `kw.get()` from 5 occurrences and
# convicted `kw.pop()` at NO count -- probed at 3, 5 and 9. A gate blind to the
# natural route of the evasion it is named after is an instrument defect, not
# evidence the code is clean.
#
# Cost of widening it, measured on this repo the same day
# (scratchpad census over 274 `.py` in `src/` + `tests/`): 17 `.pop(` call sites
# exist, 130 functions take `**kwargs`, and `<own kwargs>.pop(` appears ZERO
# times in any of them -- so zero existing functions become convicted and no
# legitimate-vs-evasive discriminator has to be invented (nothing legitimate is
# being hit). The threshold therefore stays 5, the same as `.get`, instead of a
# separate number nobody could justify. If a future census finds a legitimate
# `**kwargs`-draining wrapper convicted here, the threshold is Luis's call.
_KWARGS_UNPACK_ATTRS = frozenset({"get", "pop"})


def _is_kwargs_unpack(stmt: ast.stmt, kwarg_name: str) -> bool:
    if isinstance(stmt, ast.Assign) and isinstance(stmt.value, ast.Call):
        func = stmt.value.func
        return bool(isinstance(func, ast.Attribute)
                    and isinstance(func.value, ast.Name)
                    and func.value.id == kwarg_name
                    and func.attr in _KWARGS_UNPACK_ATTRS)
    return False


def _count_kwargs_unpack(node: ast.FunctionDef | ast.AsyncFunctionDef, kwarg_name: str) -> int:
    unpack_count = 0
    for stmt in node.body:
        if _is_kwargs_unpack(stmt, kwarg_name):
            unpack_count += 1
            continue
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant) and isinstance(stmt.value.value, str):
            continue
        if unpack_count > 0 and not isinstance(stmt, ast.Assign):
            break
    return unpack_count


# flota 2026-08-20: 0 hits.
def parameter_hiding_kwargs(code: str) -> bool:
    """A function taking **kwargs that immediately unpacks 5+ parameters via kwargs.get()/kwargs.pop().

    This is the signature-evasion antipattern: replacing a multi-parameter signature
    with **kwargs and unpacking each argument with kwargs.get("arg", default) to hide
    parameter-count violations (PLR0913) from linters without actual decoupling.
    `kwargs.pop(...)` counts identically -- see `_KWARGS_UNPACK_ATTRS` for why, and
    for the measured cost of counting it.
    """
    tree = _parse(code)
    for node in _walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            kwarg_name = node.args.kwarg.arg if node.args.kwarg else None
            if kwarg_name and _count_kwargs_unpack(node, kwarg_name) >= 5:
                return True
    return False


# flota 2026-08-20: 0 hits.
def dead_docstring_displacement(code: str) -> bool:
    """A docstring string literal placed after statements, rendering __doc__ None.

    Python requires a docstring to be the very first statement in a function/class body.
    If statements (e.g. kwargs unpacking, logger calls, assignments) precede the docstring,
    the docstring becomes a dead expression statement and __doc__ is permanently lost.
    """
    tree = _parse(code)
    for node in _walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        if len(node.body) < 2:
            continue
        first = node.body[0]
        has_doc = (isinstance(first, ast.Expr)
                   and isinstance(first.value, ast.Constant)
                   and isinstance(first.value.value, str))
        if has_doc:
            continue
        for stmt in node.body[1:]:
            if (isinstance(stmt, ast.Expr)
                    and isinstance(stmt.value, ast.Constant)
                    and isinstance(stmt.value.value, str)):
                val = stmt.value.value.strip()
                if len(val) > 20 or "\n" in val:
                    return True
    return False


_NOQA_COMPLEXITY = re.compile(
    r"""#\s*noqa(?::\s*|\s+)(?:[A-Z0-9_,\s]*\b(?:C901|PLR0912|PLR0913|PLR0915|PLR09\d\d)\b[A-Z0-9_,\s]*)""",
    re.I,
)
_NOQA_JUSTIFICATION = _ticket_justification_re("noqa")


# flota 2026-08-20: 0 hits.
def unjustified_noqa_complexity(code: str) -> bool:
    """A complexity suppression (# noqa: C901/PLR0913/PLR0915) without explicit justification.

    A justification MUST cite a real ticket/ADR (ADR|DGX|SC|DEBT-<id>), verified
    to actually exist by dangling_refs.check_noqa_ticket_references. A bare
    "-- fixed later" or "because it's fine" used to satisfy this (any trailing
    "--", ": word", or the literal word "because"/"por" passed), which any
    agent or developer could paste onto every suppression at zero cost. Citing
    a ticket does not by itself prove the reason is GOOD, but fabricating one
    means creating a real, reviewable file -- a much bigger, more visible
    footprint than one comment.
    """
    return bool(unjustified_noqa_complexity_findings(code))


def unjustified_noqa_complexity_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every unjustified complexity-noqa line, as (line, the noqa text itself).

    Scanned over `code_without_string_literals(code)`, not over the raw lines:
    a MENTION of a suppression and the USE of one were the same text to this
    detector, so a docstring explaining a suppression was convicted as if it
    were applying one. Same class the sibling `gate_relaxation_tamper` already
    documents as DEBT-DETECTOR-LEE-PROSA-COMO-CODIGO, with the predicate
    flipped: that one may blank comments, this one may not -- its subject IS a
    comment.

    Measured 2026-09-15 over the 273 tracked `.py` of this repo, before the
    change: 7 findings, ALL SEVEN prose or fixture strings quoting the token
    (this file's own docstring and registry label, the planted control in
    `verification/detector_controls.py`, four fixture strings in
    `tests/test_detector_behavior.py`) -- zero real suppressions. Twice that
    day an executor documenting its own suppression was convicted for the
    documentation, and `verification/ledger_schema.py` carries the workaround
    in writing: a reasoned PLR0913 exception that "cannot write the complete
    suppression token, not even to quote it in prose". A gate that punishes
    documenting a suppression pushes people to stop documenting it, which is
    the incentive backwards.

    The span blanked is the string token's own COLUMNS, so a real suppression
    sharing a line with a string literal still convicts -- widening the
    exemption to the whole line is what would turn this fix into a hole.
    """
    hits: list[tuple[int, str]] = []
    scanned = code_without_string_literals(code)
    for lineno, line in enumerate(scanned.splitlines(), start=1):
        m = _NOQA_COMPLEXITY.search(line)
        if m and not _NOQA_JUSTIFICATION.search(line):
            hits.append((lineno, f"unjustified {m.group(0)!r} (no ADR/DGX/SC/DEBT-<id> citation)"))
    return hits


def _is_empty_or_trivial_body(body: list[ast.stmt]) -> bool:
    stmts = body
    if stmts and isinstance(stmts[0], ast.Expr) and isinstance(stmts[0].value, ast.Constant) and isinstance(stmts[0].value.value, str):
        stmts = stmts[1:]
    if not stmts:
        return True
    if len(stmts) == 1:
        s = stmts[0]
        if isinstance(s, ast.Pass):
            return True
        if isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant) and s.value.value is Ellipsis:
            return True
    return False


def _has_exempt_decorator(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    for deco in node.decorator_list:
        if isinstance(deco, ast.Name) and deco.id in ("abstractmethod", "overload", "override"):
            return True
        if isinstance(deco, ast.Attribute) and deco.attr in ("abstractmethod", "overload", "override"):
            return True
    return False


def _protocol_method_ids(tree: ast.AST) -> set[int]:
    """ids of every method directly declared in a `class X(Protocol):` body.

    `typing.Protocol` members are structural-typing declarations, not
    implementations -- PEP 544's own convention is a bare `...` body, the
    exact shape `empty_stub_evasion` exists to convict everywhere else.
    Measured 2026-08-27: `PdfBackend(Protocol)`/`LLMProvider(Protocol)` in
    aequitas_os falsely convicted for declaring their own interface.
    """
    protocol_method_ids: set[int] = set()
    for node in _walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        is_protocol = any(
            (isinstance(base, ast.Name) and base.id == "Protocol")
            or (isinstance(base, ast.Attribute) and base.attr == "Protocol")
            for base in node.bases
        )
        if not is_protocol:
            continue
        for stmt in node.body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                protocol_method_ids.add(id(stmt))
    return protocol_method_ids


# flota 2026-08-20: 0 hits.
def empty_stub_evasion(code: str) -> bool:
    """A non-abstract function whose body is only pass, ..., or trivial stub."""
    return bool(empty_stub_evasion_findings(code))


def empty_stub_evasion_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every empty/trivial-stub function, as (def-line, function-name).

    A module defining BOTH `upgrade`/`downgrade` is an Alembic revision file
    (same recognition `destructive_action_without_confirmation` already uses,
    see `_MIGRATION_ENTRYPOINTS`) -- exempted whole, not just the two named
    entrypoints, so a merge revision's helper stays covered by whatever ELSE
    would convict it while the entrypoints themselves don't. A two-heads
    merge revision's `upgrade()`/`downgrade()` are a no-op BY DESIGN (they
    join history, they move no schema); `pass` is Alembic's own canonical
    body for that, and is not a stub hiding an unfinished implementation.
    Reported live (aequitas_os, 2026-09-01): `1dc0b63ea3c5_merge_two_heads.py`
    and a second merge revision both had to use a bare `return` instead of
    `pass` to dodge this detector, since `_is_empty_or_trivial_body` doesn't
    special-case `ast.Return` -- a convention nobody documented anywhere
    they'd find it, and every future merge revision would silently need it.
    """
    tree = _parse(code)
    names = {f.name for f in _walk(tree) if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))}
    if _MIGRATION_ENTRYPOINTS <= names:
        return []
    protocol_method_ids = _protocol_method_ids(tree)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if _has_exempt_decorator(node) or id(node) in protocol_method_ids:
                continue
            if _is_empty_or_trivial_body(node.body):
                hits.append((node.lineno, f"{node.name}() body is only pass/.../a trivial stub"))
    return hits


def unjustified_test_skip(code: str) -> bool:
    """A pytest test marked with @pytest.mark.skip or @pytest.mark.xfail with no reason (VT-040)."""
    return bool(unjustified_test_skip_findings(code))


def unjustified_test_skip_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every unjustified skip/xfail decorator, as (decorator-line, mark name)."""
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for deco in node.decorator_list:
                if isinstance(deco, ast.Attribute) and deco.attr in ("skip", "xfail"):
                    hits.append((deco.lineno, f"@...{deco.attr} on {node.name}() with no reason"))
                if isinstance(deco, ast.Call):
                    func = deco.func
                    if isinstance(func, ast.Attribute) and func.attr in ("skip", "xfail"):
                        has_reason = bool(deco.args) or any(kw.arg == "reason" for kw in deco.keywords)
                        if not has_reason:
                            hits.append((deco.lineno, f"@...{func.attr}(...) on {node.name}() with no reason"))
    return hits


def blind_mock_injection(code: str) -> bool:
    """A test that creates MagicMock instances with zero assertions (VT-009 / Over-mocking)."""
    return bool(blind_mock_injection_findings(code))


def blind_mock_injection_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every test with mocks but no assert, as (def-line, function-name)."""
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
            has_mock = any(
                isinstance(n, ast.Call)
                and (
                    (isinstance(n.func, ast.Name) and "mock" in n.func.id.lower())
                    or (isinstance(n.func, ast.Attribute) and "mock" in n.func.attr.lower())
                )
                for n in _walk(node)
            )
            has_assert = any(isinstance(n, ast.Assert) for n in _walk(node))
            if has_mock and not has_assert:
                hits.append((node.lineno, f"{node.name}() creates a mock but has no bare assert"))
    return hits


def _is_blind_swallow_handler(h: ast.ExceptHandler) -> bool:
    for node in _walk(h):
        if isinstance(node, (ast.Raise, ast.Return)):
            return False
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Attribute):
                if node.func.attr in ("error", "warning", "exception", "info", "debug", "log", "warn", "append", "extend", "add"):
                    return False
            if isinstance(node.func, ast.Name) and node.func.id in ("print", "warn", "error", "log"):
                return False
    return True


_IO_METHODS = frozenset({"open", "read_text", "write_text", "read_bytes", "write_bytes", "unlink"})
# Names shared with non-I/O methods (`str.replace`, `datetime.replace`,
# `list.remove`, `dict.copy`): as a method they count only on an `os`/`shutil`
# receiver, or in the `Path.replace(target)` shape -- one positional, no kwargs.
_AMBIGUOUS_IO_NAMES = frozenset({"copy", "replace", "remove", "move"})


def _is_io_call(c: ast.AST) -> bool:
    if not isinstance(c, ast.Call):
        return False
    if isinstance(c.func, ast.Name):
        return c.func.id in _IO_METHODS or c.func.id in _AMBIGUOUS_IO_NAMES
    if not isinstance(c.func, ast.Attribute):
        return False
    attr = c.func.attr
    if attr in _IO_METHODS:
        return True
    if attr not in _AMBIGUOUS_IO_NAMES:
        return False
    if isinstance(c.func.value, ast.Name) and c.func.value.id in ("os", "shutil"):
        return True
    return attr == "replace" and len(c.args) == 1 and not c.keywords


def silent_io_loop_swallow(code: str) -> bool:
    """Convicts loops containing file I/O operations inside try blocks that swallow exceptions silently (CC-056)."""
    tree = _parse(code)
    for node in _walk(tree):
        if isinstance(node, (ast.For, ast.While)):
            for child in _walk(node):
                if isinstance(child, ast.Try):
                    has_io = any(_is_io_call(c) for c in _walk(child))
                    has_blind_swallow = any(_is_blind_swallow_handler(h) for h in child.handlers)
                    if has_io and has_blind_swallow:
                        return True
    return False


def _is_large_token_val(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and isinstance(node.value, int) and node.value >= 1000


_TOKEN_KWARGS = ("max_tokens", "max_output_tokens")


def _is_timeout_literal_expr(val: ast.AST) -> bool:
    if isinstance(val, ast.Constant) and isinstance(val.value, (int, float)) and not isinstance(val.value, bool):
        return True
    if isinstance(val, ast.BinOp):
        return True
    if isinstance(val, ast.Call) and isinstance(val.func, ast.Name) and val.func.id in ("int", "float"):
        return True
    return False


def _call_invariant_reasons(node: ast.Call) -> list[str]:
    """The three shapes of the GS2-210 vice in a call: tokens, timeout, URL
    base. Names EVERY ONE that fires, not just the first -- a single call
    can pin a token limit AND a timeout AND a base URL at once, and each is
    its own finding, not one report that hides the other two.

    `timeout=`: deliberately no receiver allowlist. Restricting this to
    `subprocess.run`/`urlopen` by name is evaded by a one-line wrapper, and
    that wrapper already exists (`_run_git([...], cwd=root, timeout=10)` in
    verification/dangling_refs.py passes the literal to subprocess by proxy)
    -- the vice is the anonymous number, not the name of whoever receives it.

    Base URL: also counts the constant PART of an f-string
    (`f"https://pypi.org/pypi/{package}/json"`) -- parametrizing the tail
    doesn't make the head dynamic, and the head is what "base URL" means.
    """
    nombre = (node.func.attr if isinstance(node.func, ast.Attribute)
              else getattr(node.func, "id", ""))
    return [
        *_token_kwarg_reasons(node),
        *_timeout_reasons(node, nombre),
        *_base_url_reasons(node, nombre),
    ]


def _token_kwarg_reasons(node: ast.Call) -> list[str]:
    """Shape 1 of GS2-210: a token budget pinned as a keyword literal."""
    return [
        f"{kw.arg}={kw.value.value} hardcoded (>= 1000, should be computed)"
        for kw in node.keywords
        if kw.arg in _TOKEN_KWARGS and isinstance(kw.value, ast.Constant)
        and _is_large_token_val(kw.value)
    ]


def _timeout_reasons(node: ast.Call, nombre: str) -> list[str]:
    """Shape 2 of GS2-210: an anonymous timeout, by keyword or -- for
    `urlopen`/`urlretrieve`, whose signature puts it third -- positionally.
    The keyword half distinguishes a bare literal (whose value is worth
    printing) from a literal EXPRESSION (`60 * 5`, whose value is not
    evaluated here), which is why it is two messages and not one."""
    reasons: list[str] = []
    for kw in node.keywords:
        if kw.arg != "timeout":
            continue
        if (isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, (int, float))
                and not isinstance(kw.value.value, bool)):
            reasons.append(f"timeout={kw.value.value} hardcoded literal (should be computed)")
        elif _is_timeout_literal_expr(kw.value):
            reasons.append("timeout hardcoded expression (should be computed)")
    if nombre in ("urlopen", "urlretrieve") and len(node.args) >= 3 and _is_timeout_literal_expr(node.args[2]):
        reasons.append(f"positional timeout hardcoded in {nombre}() call")
    return reasons


def _base_url_reasons(node: ast.Call, nombre: str) -> list[str]:
    """Shape 3 of GS2-210: an http(s) base URL written into a network call --
    including the constant HEAD of an f-string, per the caller's docstring."""
    if nombre not in _NETWORK_CALLS:
        return []
    return [
        f"hardcoded base URL {part.value!r} in {nombre}() call"
        for arg in list(node.args) + [kw.value for kw in node.keywords]
        for part in _walk(arg)
        if isinstance(part, ast.Constant) and isinstance(part.value, str)
        and part.value.startswith(("http://", "https://"))
    ]


def _dict_token_limit_reasons(node: ast.Dict) -> list[str]:
    """`{"max_tokens": 4096}`: the same vice served as a config mapping.
    Names EVERY key/value pinned -- a dict with both max_tokens and
    max_output_tokens hardcoded yields two reasons, not one."""
    return [
        f'"{k.value}": {v.value} hardcoded token limit in dict literal'
        for k, v in zip(node.keys, node.values)
        if isinstance(k, ast.Constant) and k.value in _TOKEN_KWARGS
        and isinstance(v, ast.Constant) and _is_large_token_val(v)
    ]


# El módulo SANCIONADO donde un límite fijo sí puede vivir como literal.
#
# Medido el 2026-08-23 (auditoría V2-L171): la exención se ancoraba en el
# DOCSTRING (`_LIMITS_MODULE.match(get_docstring(...))`), así que un impostor que
# abriera con `"""tool_limits -- ..."""` -- una línea de texto que cualquiera
# escribe -- quedaba exento y podía clavar todos los literales que quisiera. El
# docstring no es identidad, es prosa editable.
#
# La identidad real es el NOMBRE DEL ARCHIVO: `tool_limits.py`. Cada satélite
# trae su propio `tool_limits.py`, así que el basename exime a los satélites
# igual de bien que el docstring y sin el agujero -- un impostor tendría que
# LLAMARSE `tool_limits.py`, y entonces ya es, a efectos de esta política, el
# módulo de límites. El detector es una función pura `fn(code)`, de modo que la
# ruta llega por un parámetro opcional `path`; el registro de zero_debt lo pasa
# (ver `_run_registry`), y cuando no hay ruta la exención de módulo no se activa.
_LIMITS_BASENAME = "tool_limits.py"


def _is_limits_module(path: str | None) -> bool:
    """True sólo si la RUTA del archivo escaneado se llama `tool_limits.py`.

    Antes recibía el árbol y leía el docstring; ahora recibe la ruta. Sin ruta
    (llamadores que aún invocan `fn(code)` a secas) devuelve False: un archivo
    de límites siempre se escanea con su ruta desde el gate de zero_debt.
    """
    if not path:
        return False
    return path.replace("\\", "/").rsplit("/", 1)[-1] == _LIMITS_BASENAME


# Llamadas que SALEN de este proceso por red. Sólo aquí una URL literal es un
# endpoint clavado; en cualquier otro sitio (`startswith(("http://", ...))`,
# medido hoy en source_verifier.py y dangling_refs.py) es una cadena que se
# compara, no una dependencia.
_NETWORK_CALLS = frozenset(
    {"urlopen", "urlretrieve", "Request", "request", "get", "post", "put",
     "patch", "delete", "head", "connect", "session", "getresponse"})


def _test_scope_node_ids(tree: ast.AST) -> set[int]:
    """ids de todo nodo que vive dentro de un `def test_*`.

    Misma frontera que `_test_fixture_paths` usa para las rutas: un literal que
    sólo existe para armar el caso de prueba no es una invariante del sistema.
    """
    dentro: set[int] = set()
    for fn in _walk(tree):
        if (isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef))
                and (fn.name == "test" or fn.name.startswith("test_"))):
            for node in _walk(fn):
                dentro.add(id(node))
    return dentro


def hardcoded_dynamic_invariants(code: str, path: str | None = None) -> bool:
    """Hardcoding static literals for parameters that require dynamic capacity calculation.

    Three shapes of the same vice (GS2-210): a static large integer token limit
    (`max_tokens >= 1000`), a literal numeric `timeout=`, and a literal http(s)
    base URL handed to a network call. All three are fixed choices pretending to
    be incidental; a fixed choice is honest only when it is DECLARED as one, in
    the sanctioned constants module, under a name that says what it bounds.

    Dos exenciones, ambas declaradas:

      * el módulo `tool_limits.py` -- por BASENAME de la ruta, no por docstring
        (auditoría V2-L171: un impostor con docstring falso se colaba). `path`
        es opcional para no romper la API pura `fn(code)`; el gate de zero_debt
        lo pasa. Sin `path` esta exención no se activa.
      * todo lo que viva dentro de un `def test_*`: ahí el número es el caso de
        prueba, no la invariante del sistema. Es una exención POR ALCANCE (los
        nodos dentro de la función de test), y se mantiene tal cual -- se hace
        explícita aquí porque antes no estaba documentada.

    Returns a bare bool -- for the line number and the specific literal that
    fired, see `hardcoded_dynamic_invariants_findings`, which this wraps.
    """
    return bool(hardcoded_dynamic_invariants_findings(code, path))


def hardcoded_dynamic_invariants_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every hardcoded-invariant hit in the file, as (line, reason) -- not just
    whether the file has one.

    `hardcoded_dynamic_invariants` above collapses a whole file to one bool,
    so a caller sees "this file is guilty" with no line and no idea which of
    the three shapes (token limit / timeout / base URL) fired, or whether
    there was one hit or five. This walks the same tree with the same two
    exemptions (tool_limits.py basename, test-function scope) but keeps every
    match instead of short-circuiting on the first `True` -- including every
    reason within the SAME call (a call pinning a token limit and a timeout
    at once yields two hits, not one), pairing each with `node.lineno` and a
    plain-language reason from `_call_invariant_reasons`/
    `_dict_token_limit_reasons`.
    """
    tree = _parse(code)
    if _is_limits_module(path):
        return []
    en_prueba = _test_scope_node_ids(tree)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if id(node) in en_prueba:
            continue
        if isinstance(node, ast.Call):
            for reason in _call_invariant_reasons(node):
                hits.append((node.lineno, reason))
        elif isinstance(node, ast.Dict):
            for reason in _dict_token_limit_reasons(node):
                hits.append((node.lineno, reason))
    return hits


def _has_mutable_default(d: ast.AST) -> bool:
    if isinstance(d, (ast.List, ast.Dict, ast.Set)):
        return True
    return isinstance(d, ast.Call) and isinstance(d.func, ast.Name) and d.func.id in ("list", "dict", "set")


def mutable_default_argument(code: str) -> bool:
    """Detect mutable default arguments in function definitions (GS2-211)."""
    return bool(mutable_default_argument_findings(code))


def mutable_default_argument_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every function with a mutable default argument, as (def-line, name)."""
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            all_defaults = list(node.args.defaults) + [d for d in node.args.kw_defaults if d is not None]
            if any(_has_mutable_default(d) for d in all_defaults):
                hits.append((node.lineno, f"{node.name}() has a mutable default argument"))
    return hits


# Los métodos de `Path` que devuelven o escriben TEXTO, más `.open()`.
# `read_bytes`/`write_bytes` no están aquí a propósito: son binarios.
_PATH_TEXT_IO = frozenset({"read_text", "write_text", "open"})


def _is_binary_mode_literal(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and isinstance(node.value, str) and "b" in node.value


def _call_has_binary_mode(node: ast.Call) -> bool:
    if len(node.args) >= 2 and _is_binary_mode_literal(node.args[1]):
        return True
    return any(kw.arg == "mode" and _is_binary_mode_literal(kw.value) for kw in node.keywords)


def _has_explicit_encoding(node: ast.Call) -> bool:
    return any(
        kw.arg == "encoding"
        and not (isinstance(kw.value, ast.Constant) and kw.value.value is None)
        for kw in node.keywords
    )


# Nombres de receptor que delatan una ruta. `read_text`/`write_text` son API de
# `Path` y de nadie más, así que no necesitan filtro; `.open()` sí, porque lo
# tienen zipfile, tarfile, sqlite y media stdlib, y ninguno de ésos acepta
# `encoding=`.
_PATHLIKE_RECEIVER = re.compile(
    r"(?:^|_)(?:path|file|dir|dest|destination|src|source|target|ruta|archivo)s?(?:$|_)"
    r"|^(?:p|fp|fh)$",
    re.IGNORECASE,
)


def _receiver_is_pathlike(node: ast.Call) -> bool:
    owner = node.func.value if isinstance(node.func, ast.Attribute) else None
    if isinstance(owner, ast.Call):
        constructor = (owner.func.attr if isinstance(owner.func, ast.Attribute)
                       else getattr(owner.func, "id", ""))
        return constructor in ("Path", "PurePath", "PosixPath", "WindowsPath")
    nombre = (owner.attr if isinstance(owner, ast.Attribute)
              else getattr(owner, "id", ""))
    return bool(_PATHLIKE_RECEIVER.search(nombre))


def _attr_io_is_binary(node: ast.Call) -> bool:
    """Modo binario en un método de `Path`: primer posicional de `.open()` o `mode=`.

    En `Path.open` el modo es el PRIMER argumento, no el segundo como en el
    builtin: `p.open("rb")` es binario y no tiene texto que decodificar. En
    `write_text` el primer posicional son los DATOS, así que ahí sólo cuenta
    la palabra clave.
    """
    if (isinstance(node.func, ast.Attribute) and node.func.attr == "open"
            and node.args and _is_binary_mode_literal(node.args[0])):
        return True
    return any(kw.arg == "mode" and _is_binary_mode_literal(kw.value) for kw in node.keywords)


def _is_text_rw_mode_literal(node: ast.AST) -> bool:
    """True para un literal de modo de TEXTO con acceso r/w/a/x y sin `b`.

    `"w"`, `"r"`, `"a"`, `"w+"`, `"rt"` sí; `"rb"`/`"wb"` no (binario, otra rama);
    `"n"` no (no es un modo: sin r/w/a/x -- así un `zipfile.ZipFile(a).open("n")`
    no se confunde con IO de texto ni aunque le faltara el filtro de receptor).
    """
    if not (isinstance(node, ast.Constant) and isinstance(node.value, str)):
        return False
    mode = node.value
    return "b" not in mode and any(c in mode for c in "rwax")


def _open_has_text_mode(node: ast.Call) -> bool:
    """`.open("w")` / `.open(mode="w")`: primer posicional o `mode=` es texto r/w."""
    if node.args and _is_text_rw_mode_literal(node.args[0]):
        return True
    return any(kw.arg == "mode" and _is_text_rw_mode_literal(kw.value) for kw in node.keywords)


# Constructores/módulos cuyo `.open()` NO es el de una ruta y no acepta
# `encoding=`: zipfile/tarfile/sqlite y los buffers en memoria. Un `.open("w")`
# sobre uno de éstos no es el vicio GS2-212, así que se exime aunque el modo
# parezca de texto. Se prefiere pecar por atrapar de más (un `.open()` oscuro
# sobre un no-listado se condena y puede anotarse con `encoding=`) antes que el
# silencio anterior, donde `out.open("w")` / `f.open("w")` se escapaban enteros.
# `fitz`/`pymupdf` (PyMuPDF): `fitz.open()` sin argumentos construye un documento
# PDF en blanco en memoria -- no hay ruta, no hay modo texto, no hay nada que
# decodificar. Medido 2026-09-21 en aequitas_os/audit/.../aa24_base.py: 3 llamadas
# `doc = fitz.open()` (cada una crea un PDF sintético distinto) condenadas como
# "sin encoding=" por coincidencia sintáctica con `.open(`, sin que exista texto
# de por medio.
_NONPATH_OPEN_OWNERS = frozenset({
    "ZipFile", "TarFile", "zipfile", "tarfile", "sqlite3", "connect",
    "BytesIO", "StringIO", "TemporaryFile", "NamedTemporaryFile",
})


def _python_reassigned_names(tree: ast.AST) -> set[str]:
    """Names rebound or imported as another owner, regardless of AST walk order."""
    return {
        name
        for item in _walk(tree)
        for name in (
            _python_declaration_bindings(item)
            | (_python_import_bindings(item) if isinstance(item, (ast.Import, ast.ImportFrom)) else set())
        )
    }


def _receiver_is_nonpath(node: ast.Call, reassigned: set[str] | None = None) -> bool:
    """True si el receptor de `.open()` es demostrablemente un no-ruta."""
    owner = node.func.value if isinstance(node.func, ast.Attribute) else None
    if isinstance(owner, ast.Call):
        name = (owner.func.attr if isinstance(owner.func, ast.Attribute)
                else getattr(owner.func, "id", ""))
    else:
        name = (owner.attr if isinstance(owner, ast.Attribute)
                else getattr(owner, "id", ""))
    return name in _NONPATH_OPEN_OWNERS and name not in (reassigned or set())


def _pymupdf_import_aliases(tree: ast.AST) -> set[str]:
    aliases: set[str] = set()
    for item in _walk(tree):
        if isinstance(item, ast.Import):
            for imported in item.names:
                bound = imported.asname or imported.name.split(".")[0]
                if imported.name in {"fitz", "pymupdf"}:
                    aliases.add(bound)
    return aliases


# Módulo de stdlib que define cada dueño de `_NONPATH_OPEN_OWNERS`. Importar el
# nombre DESDE su módulo, sin alias, no lo reasigna a otro dueño: sigue siendo el
# mismo objeto. Medido 2026-10-05: `from zipfile import ZipFile` metía "ZipFile" en
# `_python_reassigned_names`, y `ZipFile(p).open("a", "r")` se condenaba como
# lectura de texto sin `encoding=`, que es lo contrario de lo que `_receiver_is_nonpath`
# existe para decidir.
_NONPATH_OWNER_HOME = {
    "ZipFile": "zipfile", "TarFile": "tarfile", "zipfile": "zipfile", "tarfile": "tarfile",
    "sqlite3": "sqlite3", "connect": "sqlite3", "BytesIO": "io", "StringIO": "io",
    "TemporaryFile": "tempfile", "NamedTemporaryFile": "tempfile",
}


def _python_import_bindings(item: ast.Import | ast.ImportFrom) -> set[str]:
    if isinstance(item, ast.ImportFrom):
        return {
            alias.asname or alias.name
            for alias in item.names
            if not (item.level == 0 and alias.asname is None
                    and _NONPATH_OWNER_HOME.get(alias.name) == item.module)
        }
    if isinstance(item, ast.Import):
        return {
            alias.asname or alias.name.split(".")[0]
            for alias in item.names
            if alias.name not in {"fitz", "pymupdf"}
            and not (alias.asname is None and _NONPATH_OWNER_HOME.get(alias.name) == alias.name)
        }


def _python_declaration_bindings(item: ast.AST) -> set[str]:
    if isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store):
        return {item.id}
    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return {item.name}
    if isinstance(item, ast.arg):
        return {item.arg}
    if isinstance(item, ast.ExceptHandler) and item.name:
        return {item.name}
    if isinstance(item, (ast.MatchAs, ast.MatchStar)) and item.name:
        return {item.name}
    if isinstance(item, ast.MatchMapping) and item.rest:
        return {item.rest}
    if isinstance(item, (ast.Global, ast.Nonlocal)):
        return set(item.names)
    return set()


def _pymupdf_module_aliases(tree: ast.AST) -> set[str]:
    """Imported PyMuPDF module names that are not reassigned in this source."""
    aliases = _pymupdf_import_aliases(tree)
    reassigned = _python_reassigned_names(tree)
    return aliases - reassigned


def _awaited_call_ids(tree: ast.AST) -> set[int]:
    """id() de cada `ast.Call` que es operando directo de un `await`."""
    return {
        id(node.value)
        for node in _walk(tree)
        if isinstance(node, ast.Await) and isinstance(node.value, ast.Call)
    }


def _aiofiles_import_aliases(tree: ast.AST) -> set[str]:
    """Alias de `import aiofiles as X` -- nombres de módulo ligados a aiofiles.

    `"aiofiles"` sembrado de fábrica para conservar la conducta con el import
    sin alias (mismo patrón que `_sleep_import_bindings` usa para `time`).
    """
    aliases: set[str] = {"aiofiles"}
    for node in _walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "aiofiles":
                    aliases.add(alias.asname or alias.name)
    return aliases


def _root_name(expr: ast.AST) -> str:
    """Nombre base de una cadena de atributos (`a.b.c` -> `"a"`); `""` si no aplica."""
    while isinstance(expr, ast.Attribute):
        expr = expr.value
    return expr.id if isinstance(expr, ast.Name) else ""


def _is_awaited_non_aiofiles_open(
    node: ast.Call, awaited_ids: set[int], aiofiles_aliases: set[str]
) -> bool:
    """True si `node` es un `.open(...)` bajo `await` y NO es `aiofiles.open(...)`.

    `open()`/`Path.open()` nativos de Python NUNCA son awaitable -- un
    `.open()` bajo `await` es, con certeza, un objeto que no es un archivo
    real (pools de conexión async, clientes de red, etc.), con la única
    excepción conocida de `aiofiles`, que sí ofrece un `open()` awaitable y sí
    necesita `encoding=` real.

    Medido en aequitas_os 2026-08-30: `await pool.open()`
    (`psycopg_pool.AsyncConnectionPool.open`) se marcaba en falso porque
    `_receiver_is_nonpath` empareja por el NOMBRE LITERAL de la variable
    receptora ("pool"), no por su tipo -- agregar "pool" a
    `_NONPATH_OPEN_OWNERS` habría sido correcto solo por coincidencia aquí y
    peligrosamente genérico para cualquier otro repo del fleet que nombre así
    una variable que SÍ es una ruta real. `await` es una señal estructural,
    no un nombre, así que no hereda ese riesgo.
    """
    if id(node) not in awaited_ids:
        return False
    owner = node.func.value if isinstance(node.func, ast.Attribute) else None
    if owner is None:
        return True
    return _root_name(owner) not in aiofiles_aliases


def unencoded_file_io(code: str) -> bool:
    """Detect text file reads/writes without an explicit encoding (GS2-212).

    Cubre el `open()` builtin Y los métodos de `Path`. Medido el 2026-08-23: el
    detector sólo miraba `open()`, así que `Path(p).read_text()` y
    `destino.write_text(s)` -- que toman la codificación de la LOCALE de quien
    ejecuta, que es el defecto entero -- le eran invisibles.

    `.open()` (auditoría V2-L170): antes se condenaba SÓLO si el nombre del
    receptor casaba con `_PATHLIKE_RECEIVER`, así que `out.open("w")` y
    `f.open("w")` se evadían. Ahora se condena cualquier `.open(` con un modo de
    TEXTO r/w explícito y sin `encoding=`, salvo que el receptor sea
    demostrablemente un no-ruta (zipfile/tarfile/sqlite/buffers). El receptor
    con forma de ruta sigue condenándose aunque no lleve modo (`Path("x").open()`).

    `read_bytes`/`write_bytes` quedan fuera: no hay texto que decodificar.
    """
    return bool(unencoded_file_io_findings(code))


def _dot_open_call_is_exempt(
    node: ast.Call, awaited_ids: set[int], aiofiles_aliases: set[str],
    pymupdf_aliases: set[str], reassigned: set[str],
) -> bool:
    """True si un `.open(...)` (no el `open()` builtin) debe eximirse de GS2-212:
    receptor demostrablemente no-ruta, `await` no-aiofiles, o ni ruta ni modo texto."""
    owner = node.func.value if isinstance(node.func, ast.Attribute) else None
    pymupdf_module = isinstance(owner, ast.Name) and owner.id in pymupdf_aliases
    if pymupdf_module or _receiver_is_nonpath(node, reassigned):
        return True
    if _is_awaited_non_aiofiles_open(node, awaited_ids, aiofiles_aliases):
        return True
    return not (_receiver_is_pathlike(node) or _open_has_text_mode(node) or not node.args)


def unencoded_file_io_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every text file I/O call missing an explicit encoding, as (line, call)."""
    tree = _parse(code)
    awaited_ids = _awaited_call_ids(tree)
    aiofiles_aliases = _aiofiles_import_aliases(tree)
    pymupdf_aliases = _pymupdf_module_aliases(tree)
    reassigned = _python_reassigned_names(tree)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Name) and node.func.id == "open":
            if not _call_has_binary_mode(node) and not _has_explicit_encoding(node):
                hits.append((node.lineno, "open(...) with no explicit encoding="))
        elif isinstance(node.func, ast.Attribute) and node.func.attr in _PATH_TEXT_IO:
            if node.func.attr == "open" and _dot_open_call_is_exempt(
                node, awaited_ids, aiofiles_aliases, pymupdf_aliases, reassigned
            ):
                continue
            if not _attr_io_is_binary(node) and not _has_explicit_encoding(node):
                hits.append((node.lineno, f".{node.func.attr}(...) with no explicit encoding="))
    return hits


def _sleep_import_items(node: ast.AST) -> list[tuple[str, str, str]]:
    if isinstance(node, ast.Import):
        return [(alias.name.split(".")[0], alias.name, alias.asname or alias.name.split(".")[0])
                for alias in node.names]
    if isinstance(node, ast.ImportFrom):
        return [(node.module or "", alias.name, alias.asname or alias.name) for alias in node.names]
    return []


def _names_bound_to(value: ast.AST, time_aliases: set[str], sleep_names: set[str]) -> str:
    """Qué representa el RHS de una asignación: `"time"`, `"sleep"` o `""`."""
    if isinstance(value, ast.Name):
        if value.id in time_aliases:
            return "time"
        if value.id in sleep_names:
            return "sleep"
    if (isinstance(value, ast.Attribute) and value.attr == "sleep"
            and isinstance(value.value, ast.Name) and value.value.id in time_aliases):
        return "sleep"
    return ""


def _sleep_scope_local_names(body: list[ast.stmt], args: ast.arguments | None = None) -> set[str]:
    names = set()
    if args is not None:
        names.update(arg.arg for arg in [*args.posonlyargs, *args.args, *args.kwonlyargs])
        if args.vararg is not None:
            names.add(args.vararg.arg)
        if args.kwarg is not None:
            names.add(args.kwarg.arg)
    stack: list[ast.AST] = list(reversed(body))
    scopes = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)
    while stack:
        node = stack.pop()
        names.update(_python_declaration_bindings(node))
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names.update(bound for _, _, bound in _sleep_import_items(node))
        if isinstance(node, scopes):
            continue
        stack.extend(reversed(list(ast.iter_child_nodes(node))))
    return names


def _sleep_set_binding(
    name: str, kind: str, time_aliases: set[str], sleep_names: set[str],
) -> None:
    time_aliases.discard(name)
    sleep_names.discard(name)
    if kind == "time":
        time_aliases.add(name)
    elif kind == "sleep":
        sleep_names.add(name)


class _SleepBindingVisitor(ast.NodeVisitor):
    """Track aliases per lexical scope and snapshot them at each call."""

    def __init__(self) -> None:
        self.time_aliases = {"time"}
        self.sleep_names = {"sleep"}
        self.results: dict[int, tuple[set[str], set[str]]] = {}
        self.scope_stack: list[ast.AST] = []
        self.module_bindings = (set(self.time_aliases), set(self.sleep_names))
        self._deferred_module_functions: list[ast.FunctionDef | ast.AsyncFunctionDef | ast.Lambda] = []
        self._deferred_method_classes: dict[int, ast.ClassDef] = {}
        self._deferred_function_stack: list[list[ast.FunctionDef | ast.AsyncFunctionDef | ast.Lambda]] = []
        self._nested_functions_by_scope: list[dict[str, ast.FunctionDef | ast.AsyncFunctionDef | ast.Lambda]] = []
        self._scope_binding_frames: list[dict[str, set[str]]] = []
        self._active_nested_functions: set[int] = set()
        self._module_callables: dict[str, ast.FunctionDef | ast.AsyncFunctionDef | ast.Lambda] = {}
        self._callable_parent_frames: dict[int, dict[str, set[str]]] = {}
        self._module_binding_frame = {"time": self.time_aliases, "sleep": self.sleep_names}

    def _scope_base(
        self, node: ast.AST, saved: tuple[set[str], set[str]],
        parent_frame: dict[str, set[str]] | None,
    ) -> tuple[set[str], set[str]]:
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef) and self.scope_stack and isinstance(
            self.scope_stack[-1], ast.ClassDef
        ):
            return self.module_bindings
        if parent_frame is not None:
            return parent_frame["time"], parent_frame["sleep"]
        return saved

    def _new_scope_frame(
        self, node: ast.AST, is_function_scope: bool,
    ) -> dict[str, set[str]] | None:
        if is_function_scope:
            frame = {"time": self.time_aliases, "sleep": self.sleep_names}
            self._deferred_function_stack.append([])
            self._nested_functions_by_scope.append({})
            self._scope_binding_frames.append(frame)
            return frame
        if isinstance(node, ast.Module):
            self._module_binding_frame["time"] = self.time_aliases
            self._module_binding_frame["sleep"] = self.sleep_names
            return self._module_binding_frame
        return None

    def _visit_scope(
        self, node: ast.AST, body: list[ast.stmt], args: ast.arguments | None = None,
        parent_frame: dict[str, set[str]] | None = None,
    ) -> None:
        saved = self.time_aliases, self.sleep_names
        base = self._scope_base(node, saved, parent_frame)
        self.time_aliases, self.sleep_names = set(base[0]), set(base[1])
        for name in _sleep_scope_local_names(body, args):
            self.time_aliases.discard(name)
            self.sleep_names.discard(name)
        is_function_scope = isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.Lambda)
        scope_frame = self._new_scope_frame(node, is_function_scope)
        self.scope_stack.append(node)
        for statement in body:
            self.visit(statement)
            if scope_frame is not None:
                scope_frame["time"], scope_frame["sleep"] = self.time_aliases, self.sleep_names
        if is_function_scope:
            deferred = self._deferred_function_stack.pop()
            for function in deferred:
                self._visit_callable_body(function, self._callable_parent_frames.get(id(function)))
            self._nested_functions_by_scope.pop()
            self._scope_binding_frames.pop()
        self.scope_stack.pop()
        if isinstance(node, ast.Module):
            self._visit_deferred_module_functions()
        self.time_aliases, self.sleep_names = saved

    def _visit_deferred_module_functions(self) -> None:
        self.module_bindings = (set(self.time_aliases), set(self.sleep_names))
        for function in self._deferred_module_functions:
            parent_class = self._deferred_method_classes.get(id(function))
            if parent_class is not None:
                self.scope_stack.append(parent_class)
            self._visit_callable_body(function, self._module_binding_frame)
            if parent_class is not None:
                self.scope_stack.pop()

    def visit_Module(self, node: ast.Module) -> None:
        self._visit_scope(node, node.body)

    def _visit_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        for expression in [*node.decorator_list, *node.args.defaults,
                           *(default for default in node.args.kw_defaults if default is not None)]:
            self.visit(expression)
        inside_function = any(
            isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda))
            for scope in self.scope_stack
        )
        if self.scope_stack and isinstance(self.scope_stack[-1], ast.ClassDef):
            self._deferred_module_functions.append(node)
            self._deferred_method_classes[id(node)] = self.scope_stack[-1]
            return
        if inside_function and self._deferred_function_stack:
            # A nested function can close over a name assigned later in its
            # enclosing function. Its body sees the completed binding state
            # when the enclosing function reaches the call, so defer that body
            # until this function's statements have been visited.
            self._deferred_function_stack[-1].append(node)
            self._nested_functions_by_scope[-1][node.name] = node
            self._callable_parent_frames[id(node)] = self._scope_binding_frames[-1]
            return
        # Module function bodies execute after module initialization, so their
        # global lookups see bindings established later in the file.
        self._deferred_module_functions.append(node)
        if self.scope_stack and isinstance(self.scope_stack[-1], ast.Module):
            self._module_callables[node.name] = node
            self._callable_parent_frames[id(node)] = self._module_binding_frame

    def _visit_callable_body(
        self, node: ast.FunctionDef | ast.AsyncFunctionDef | ast.Lambda,
        parent_frame: dict[str, set[str]] | None = None,
    ) -> None:
        if isinstance(node, ast.Lambda):
            self._visit_scope(node, [ast.Expr(value=node.body)], node.args, parent_frame)
        else:
            self._visit_scope(node, node.body, node.args, parent_frame)

    def _resolve_callable(self, name: str) -> ast.FunctionDef | ast.AsyncFunctionDef | ast.Lambda | None:
        return next((scope[name] for scope in reversed(self._nested_functions_by_scope) if name in scope),
                    self._module_callables.get(name))

    def _bind_callable_target(self, target: ast.AST, value: ast.AST | None) -> None:
        if isinstance(target, (ast.Tuple, ast.List)) and isinstance(value, (ast.Tuple, ast.List)):
            for target_item, value_item in zip(target.elts, value.elts):
                self._bind_callable_target(target_item, value_item)
            return
        if not isinstance(target, ast.Name):
            return
        function = value if isinstance(value, ast.Lambda) else (
            self._resolve_callable(value.id) if isinstance(value, ast.Name) else None
        )
        scope = self._nested_functions_by_scope[-1] if self._nested_functions_by_scope else self._module_callables
        if function is None:
            scope.pop(target.id, None)
            return
        scope[target.id] = function
        if isinstance(function, ast.Lambda):
            self._callable_parent_frames[id(function)] = (
                self._scope_binding_frames[-1] if self._scope_binding_frames else self._module_binding_frame
            )

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._visit_function(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._visit_function(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        for expression in [*node.decorator_list, *node.bases,
                           *(keyword.value for keyword in node.keywords)]:
            self.visit(expression)
        self._visit_scope(node, node.body)

    def visit_Lambda(self, node: ast.Lambda) -> None:
        if self._deferred_function_stack:
            self._deferred_function_stack[-1].append(node)
            self._callable_parent_frames[id(node)] = self._scope_binding_frames[-1]
        else:
            self._deferred_module_functions.append(node)
            self._callable_parent_frames[id(node)] = self._module_binding_frame

    def visit_Import(self, node: ast.Import) -> None:
        for module, imported, bound in _sleep_import_items(node):
            kind = "time" if module == "time" and imported == "time" else ""
            _sleep_set_binding(bound, kind, self.time_aliases, self.sleep_names)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        for module, imported, bound in _sleep_import_items(node):
            kind = "time" if module == "time" and imported == "time" else (
                "sleep" if module == "time" and imported == "sleep" else ""
            )
            _sleep_set_binding(bound, kind, self.time_aliases, self.sleep_names)

    def visit_Assign(self, node: ast.Assign) -> None:
        self.visit(node.value)
        kind = _names_bound_to(node.value, self.time_aliases, self.sleep_names)
        for target in node.targets:
            if isinstance(target, ast.Name):
                _sleep_set_binding(target.id, kind, self.time_aliases, self.sleep_names)
            self._bind_callable_target(target, node.value)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            self.visit(node.value)
        kind = _names_bound_to(node.value, self.time_aliases, self.sleep_names) if node.value else ""
        if isinstance(node.target, ast.Name):
            _sleep_set_binding(node.target.id, kind, self.time_aliases, self.sleep_names)
        self._bind_callable_target(node.target, node.value)

    def _clear_loop_target(self, target: ast.AST) -> None:
        if isinstance(target, ast.Name):
            _sleep_set_binding(target.id, "", self.time_aliases, self.sleep_names)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for element in target.elts:
                self._clear_loop_target(element)

    def _visit_loop(self, node: ast.For | ast.AsyncFor | ast.While) -> None:
        if isinstance(node, (ast.For, ast.AsyncFor)):
            self.visit(node.iter)
            targets = [node.target]
        else:
            self.visit(node.test)
            targets = []

        initial = (set(self.time_aliases), set(self.sleep_names))
        states: list[tuple[set[str], set[str]]] = [initial]
        seen: set[tuple[frozenset[str], frozenset[str]]] = set()
        current = initial
        while True:
            key = (frozenset(current[0]), frozenset(current[1]))
            if key in seen:
                break
            seen.add(key)
            self.time_aliases, self.sleep_names = set(current[0]), set(current[1])
            for target in targets:
                self._clear_loop_target(target)
            if isinstance(node, ast.While):
                self.visit(node.test)
            for statement in node.body:
                self.visit(statement)
            following = (set(self.time_aliases), set(self.sleep_names))
            states.append(following)
            if following == current:
                break
            current = following

        # Zero iterations are possible, so merge entry and every reached state.
        self.time_aliases = set().union(*(state[0] for state in states))
        self.sleep_names = set().union(*(state[1] for state in states))
        for statement in node.orelse:
            self.visit(statement)

    def visit_For(self, node: ast.For) -> None:
        self._visit_loop(node)

    def visit_AsyncFor(self, node: ast.AsyncFor) -> None:
        self._visit_loop(node)

    def visit_While(self, node: ast.While) -> None:
        self._visit_loop(node)

    def visit_Call(self, node: ast.Call) -> None:
        prior = self.results.get(id(node), (set(), set()))
        self.results[id(node)] = (
            prior[0] | self.time_aliases,
            prior[1] | self.sleep_names,
        )
        self.generic_visit(node)
        function = node.func if isinstance(node.func, ast.Lambda) else (
            self._resolve_callable(node.func.id) if isinstance(node.func, ast.Name) else None
        )
        if function is None or id(function) in self._active_nested_functions:
            return
        self._active_nested_functions.add(id(function))
        try:
            # A closure observes the bindings at each call site, not only the
            # final state at the end of its enclosing function.
            parent_frame = self._callable_parent_frames.get(id(function))
            self._visit_callable_body(function, parent_frame)
        finally:
            self._active_nested_functions.remove(id(function))


def _sleep_bindings_by_call(tree: ast.AST) -> dict[int, tuple[set[str], set[str]]]:
    visitor = _SleepBindingVisitor()
    visitor.visit(tree)
    return visitor.results


# A justification comment on the SAME line as the condemned `sleep(...)` call,
# mirroring _NOQA_JUSTIFICATION: a real ticket/ADR is mandatory, never a bare
# "because" -- fabricating an exemption means creating a real, reviewable
# ticket file, not pasting one word. dangling_refs.check_noqa_ticket_references
# verifies the cited ticket actually exists (extend its regex alongside this
# one if the prefix ever changes).
_SLEEP_JUSTIFICATION = _ticket_justification_re("blocking-sleep")


def blocking_sleep(code: str) -> bool:
    """A `time.sleep(...)` standing in for waiting on a condition (VT-039).

    vt-039 vivía en rules/catalog.yaml declarado `enforcement: ast_detector` y
    sin detector que lo ejecutara -- prosa con nombre de gate. Esto es el gate.

    `sleep` es una espera que no sabe qué espera: pasa cuando la máquina va
    rápida y falla cuando va lenta, y ninguna de las dos cosas dice nada sobre
    el sistema. `asyncio.sleep` queda fuera: ahí ceder el control ES el mecanismo.

    Se siguen los alias (auditoría V2-L173: antes sólo pillaba `time.sleep` y
    `from time import sleep`, y se le escapaban `import time as t; t.sleep(1)`,
    `from time import sleep as s; s(1)` y el rebinding `mod = time; mod.sleep(1)`).
    Se condena `X.sleep(...)` cuando X apunta al módulo `time`, y `Y(...)` cuando
    Y apunta a `time.sleep` -- ver `_sleep_bindings`.

    Excepción declarada (fleet incident 2026-08-25: ~25 archivos reales en
    Atlas con retry-backoff acotado y documentado quedaban permanentemente
    incommiteables, empujando hacia --no-verify o hacia reescribir el sleep en
    una forma que el AST no reconociera): un comentario `# blocking-sleep:
    <razón> -- <TICKET>` EN LA MISMA LÍNEA que la llamada condenada la exime,
    siempre que cite un ticket real -- ver `_SLEEP_JUSTIFICATION`.

    `getattr(time, "sleep")(1)` también queda normalizado antes de este pase,
    de modo que se inspecciona como una llamada al atributo `sleep`.
    """
    return bool(blocking_sleep_findings(code))


def blocking_sleep_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every unjustified time.sleep() call, as (line, reason)."""
    tree = _parse(code)
    lines = code.splitlines()
    bindings_by_call = _sleep_bindings_by_call(tree)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not isinstance(node, ast.Call):
            continue
        time_aliases, sleep_names = bindings_by_call.get(id(node), (set(), set()))
        fn = node.func
        condemned = (isinstance(fn, ast.Attribute) and fn.attr == "sleep" and isinstance(fn.value, ast.Name) and fn.value.id in time_aliases) or (
            isinstance(fn, ast.Name) and fn.id in sleep_names
        )
        if not condemned:
            continue
        line_no = getattr(node, "lineno", None)
        if line_no and 1 <= line_no <= len(lines) and _SLEEP_JUSTIFICATION.search(lines[line_no - 1]):
            continue
        hits.append((line_no or 0, "blocking time.sleep() with no # blocking-sleep: <reason> -- <TICKET> justification"))
    return hits


# Mirrors _SLEEP_JUSTIFICATION exactly: a same-line comment with a real
# ticket, never a bare "because". Fleet incident (Atlas, 2026-08-26): a
# process-wide file lock (`_lock_file_obj`, paired with a `release_*`
# function called from elsewhere) legitimately holds its `open()` OUTSIDE a
# `with` block on purpose -- a context manager would close the fd, and with
# it the lock, the moment the `with` block exits.
_UNMANAGED_OPEN_JUSTIFICATION = _ticket_justification_re("unmanaged-open")


def unmanaged_resource_open(code: str) -> bool:
    """Detect bare open() calls assigned outside a context manager with statement (GS2-213).

    Exception (fleet incident, Atlas, 2026-08-26): a comment `# unmanaged-open:
    <reason> -- <TICKET>` on the SAME line as the assignment exempts it, same
    mechanism and same ticket requirement as `blocking_sleep`'s
    `_SLEEP_JUSTIFICATION` -- a process lock's file descriptor is meant to
    outlive the statement that opens it, which is exactly what a bare `open()`
    (not a `with`) is for.
    """
    return bool(unmanaged_resource_open_findings(code))


def unmanaged_resource_open_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every unjustified bare open() assignment, as (line, reason)."""
    tree = _parse(code)
    lines = code.splitlines()
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            if isinstance(node.value.func, ast.Name) and node.value.func.id == "open":
                line_no = getattr(node, "lineno", None)
                if line_no and 1 <= line_no <= len(lines) and _UNMANAGED_OPEN_JUSTIFICATION.search(lines[line_no - 1]):
                    continue
                hits.append((line_no or 0, "open() assigned outside a `with` block, no # unmanaged-open: <reason> -- <TICKET> justification"))
    return hits


# unittest.TestCase's assertTrue/assertFalse report ONLY "False is not true"
# on failure -- measured empirically (2026-08-28): `self.assertTrue(a == b)`
# failing prints exactly that string, no operand values, while the matching
# `self.assertEqual(a, b)` prints both sides. A bare `assert x` (no
# comparison) is worse still: pytest's assertion rewriting shows nothing
# beyond `assert False` for a bare local Name (an attribute chain like
# `r.success` at least gets `where False = <R object>.success`, still no
# insight into WHY). This maps each Compare operator to the assertX method
# that would have shown the operands instead of throwing them away.
_ASSERT_TRUE_UPGRADE = {
    ast.Eq: "assertEqual",
    ast.NotEq: "assertNotEqual",
    ast.In: "assertIn",
    ast.NotIn: "assertNotIn",
    ast.Is: "assertIs",
    ast.IsNot: "assertIsNot",
    ast.Lt: "assertLess",
    ast.LtE: "assertLessEqual",
    ast.Gt: "assertGreater",
    ast.GtE: "assertGreaterEqual",
}
# assertFalse(a == b) means "a != b" -- only the operators with a clean,
# unambiguous logical negation get a suggestion for assertFalse. Ordering
# comparators (Lt/Gt/...) are deliberately absent: "not (a < b)" is not the
# same claim as "a >= b" once NaN or a custom __lt__ is involved, so
# suggesting assertGreaterEqual there would be a wrong rewrite, not a
# clearer one.
_ASSERT_FALSE_UPGRADE = {
    ast.Eq: "assertNotEqual",
    ast.NotEq: "assertEqual",
    ast.In: "assertNotIn",
    ast.NotIn: "assertIn",
    ast.Is: "assertIsNot",
    ast.IsNot: "assertIs",
}


def opaque_boolean_assertion(code: str) -> bool:
    """self.assertTrue(a == b) / self.assertFalse(a == b) discard the
    operand-level diagnostic the matching assertEqual/assertIn/etc. would
    have printed on failure -- see `_ASSERT_TRUE_UPGRADE` for the measured
    evidence and the exact mapping used.
    """
    return bool(opaque_boolean_assertion_findings(code))


def opaque_boolean_assertion_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every assertTrue/assertFalse wrapping a comparison that had a more
    informative assertX sibling available, as (line, reason naming both the
    call and its suggested replacement)."""
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)):
            continue
        method = node.func.attr
        if method not in ("assertTrue", "assertFalse"):
            continue
        if not node.args:
            continue
        arg = node.args[0]
        if not (isinstance(arg, ast.Compare) and len(arg.ops) == 1):
            continue
        upgrade_map = _ASSERT_TRUE_UPGRADE if method == "assertTrue" else _ASSERT_FALSE_UPGRADE
        better = upgrade_map.get(type(arg.ops[0]))
        if better is None:
            continue
        hits.append((
            node.lineno,
            f"{method}(<comparison>) reports only pass/fail on failure -- use {better}(...) "
            "to also show the operand values",
        ))
    return hits


def covert_test_skip(code: str, path: str | None = None) -> bool:
    """Detect try/except blocks inside test functions that silently swallow exceptions (GS2-217)."""
    return bool(covert_test_skip_findings(code, path))


def covert_test_skip_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every try/except in a test function that swallows errors with pass/... AND
    verifies nothing else, as (line, reason).

    Excludes the "expect this exception, then assert the effect" idiom --
    `try: <call that must raise>; raise AssertionError(...) except Expected: pass`
    followed by unconditional `assert`s on the resulting state -- from the
    genuine covert-skip pattern (swallow anything, assert nothing, the test
    passes whether or not the code under test even ran). Reported live
    (Atlas, 2026-08-29, atlas-42): a test forcing an OSError mid-write via
    monkeypatch, catching the expected OSError, then asserting the
    destination survived intact, false-positived here -- the `except: pass`
    body is one statement, but the function's OWN unconditional assertions
    after it are what actually verify the behavior, invisible to this
    detector before this fix.
    """
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_")):
            continue
        for child in _walk(node):
            if isinstance(child, ast.ExceptHandler):
                if len(child.body) == 1 and (
                    isinstance(child.body[0], ast.Pass)
                    or (
                        isinstance(child.body[0], ast.Expr)
                        and isinstance(child.body[0].value, ast.Constant)
                        and child.body[0].value.value is ...
                    )
                ):
                    handler_ids = {id(n) for n in _walk(child)}
                    if any(
                        isinstance(n, ast.Assert) and id(n) not in handler_ids
                        for n in _walk(node)
                    ):
                        continue
                    hits.append((
                        child.lineno,
                        "Silent exception swallowing with pass/... inside test function (covert test skip)",
                    ))
    return hits


def integration_filesystem_mock(code: str, path: str | None = None) -> bool:
    """Detect mocking of filesystem/OS primitives in integration/e2e tests (GS2-218)."""
    return bool(integration_filesystem_mock_findings(code, path))


def integration_filesystem_mock_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every filesystem/OS mock in an integration test, as (line, reason)."""
    if path and not any(k in path.lower() for k in ("integration", "e2e", "control")):
        return []
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func_name = ""
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        if func_name == "patch" and node.args:
            first_arg = node.args[0]
            if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
                target = first_arg.value
                if any(target.startswith(p) for p in ("os.", "shutil.", "pathlib.", "builtins.open")):
                    hits.append((
                        node.lineno,
                        f"Integration test mocks core filesystem primitive '{target}' instead of using real tmp_path",
                    ))
    return hits


def silent_dependency_skip(code: str, path: str | None = None) -> bool:
    """Detect silent skipping of tests or engine availability on missing dependencies without explicit warning (GS2-219)."""
    return bool(silent_dependency_skip_findings(code, path))


def silent_dependency_skip_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every silent dependency skip or silent ImportError swallow, as (line, reason)."""
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if isinstance(node, ast.ExceptHandler):
            if _catches_import_error(node):
                hits.extend(_import_error_swallow_hits(node, path))
        elif (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == "importorskip"):
            hits.append((
                node.lineno,
                "pytest.importorskip hides missing dependencies; declare and install dependency in pyproject.toml",
            ))
    return hits


def _catches_import_error(handler: ast.ExceptHandler) -> bool:
    """The handler names ImportError/ModuleNotFoundError, alone or inside a
    tuple. Substring test on purpose: `pkg.ImportError` and an aliased
    `ImportErrorGroup` are caught too, the same as before this split."""
    if isinstance(handler.type, ast.Name):
        exc_name = handler.type.id
    elif isinstance(handler.type, ast.Tuple):
        exc_name = " ".join(e.id for e in handler.type.elts if isinstance(e, ast.Name))
    else:
        exc_name = ""
    return "ImportError" in exc_name or "ModuleNotFoundError" in exc_name


def _import_error_swallow_hits(
    handler: ast.ExceptHandler, path: str | None,
) -> list[tuple[int, str]]:
    """The two ways a caught ImportError gets swallowed: a `.skip()` call, and
    a bare/False `return`. The second is reported ONLY for a test path -- in
    production code `except ImportError: return None` is an optional-dependency
    probe, not a hidden skip, so widening it here would invent convictions."""
    hits: list[tuple[int, str]] = []
    for stmt in handler.body:
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            if isinstance(stmt.value.func, ast.Attribute) and stmt.value.func.attr == "skip":
                hits.append((
                    stmt.lineno,
                    "Test uses pytest.skip() on ImportError -- dependencies must be installed or verified via explicit fallback",
                ))
        elif isinstance(stmt, ast.Return) and (
            stmt.value is None
            or (isinstance(stmt.value, ast.Constant) and stmt.value.value is False)
        ):
            if path and "test" in path.lower():
                hits.append((
                    stmt.lineno,
                    "Test silently returns on ImportError instead of failing or asserting explicit fallback",
                ))
    return hits


def weak_existence_assert(code: str, path: str | None = None) -> bool:
    """Detect test functions where all assertions are trivial existence/type checks (GS2-220)."""
    return bool(weak_existence_assert_findings(code, path))


def weak_existence_assert_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every test function with only trivial existence assertions, as (line, reason)."""
    if path and not any(k in path.lower() for k in ("test", "control", "fixture")):
        return []
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if not node.name.startswith("test_"):
            continue
        asserts = [stmt for stmt in _walk(node) if isinstance(stmt, ast.Assert)]
        if not asserts:
            continue
        if all(_is_weak_assertion(a.test) for a in asserts):
            hits.append((
                node.lineno,
                f"Test '{node.name}' uses only superficial existence/type assertions (e.g. 'is not None'); verify state or values",
            ))
    return hits


_WEAK_ASSERT_BUILTINS = ("isinstance", "bool")


def _is_weak_assertion(test_expr: ast.expr) -> bool:
    """An assertion that checks EXISTENCE or TYPE and nothing else: `x is not
    None`, `isinstance(x, T)`, `bool(x)`. Anything else -- a value comparison,
    a call into the subject, a membership test -- is real verification and
    makes its whole test function real, which is why the caller uses `all()`."""
    if (isinstance(test_expr, ast.Compare) and len(test_expr.ops) == 1
            and isinstance(test_expr.ops[0], ast.IsNot)):
        right = test_expr.comparators[0]
        return isinstance(right, ast.Constant) and right.value is None
    return (isinstance(test_expr, ast.Call) and isinstance(test_expr.func, ast.Name)
            and test_expr.func.id in _WEAK_ASSERT_BUILTINS)


def gate_relaxation_tamper(code: str, path: str | None = None) -> bool:
    """Detect attempts to relax, bypass or weaken quality gates and linters (GS2-221)."""
    return bool(gate_relaxation_tamper_findings(code, path))


# Cero o uno EXACTOS, no un prefijo: `\b` impide que `100` case por empezar por `1`.
_FAIL_UNDER_CASI_CERO = re.compile(r"fail_under\s*=\s*[01]\b")


def gate_relaxation_tamper_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every gate relaxation or bypass pattern in code/config, as (line, reason)."""
    if path and any(k in path.lower() for k in ("tests/", "test_", "docs/")) and not any(k in path.lower() for k in ("control", "fixture")):
        return []
    hits: list[tuple[int, str]] = []
    lines = code.splitlines()
    # Docstring spans come from the PARSER, not from a prefix scan. The hand-rolled
    # state machine that lived here desynchronised on any string its heuristic
    # could not model, and once desynchronised it stayed wrong for the rest of the
    # file: a lone closing delimiter was read as an OPENING, so every docstring
    # after it was inverted and its prose was scanned as source.
    #
    # Measured 2026-09-05 on `verification/coverage_target.py`: by line 263 the
    # machine held in_docstring=True, so the line that OPENS that docstring closed
    # it, and line 274 -- prose quoting `fail_under = 100` -- was judged as code.
    # Together with this detector's substring test (fixed separately by the
    # own_chats session) that convicted the STRICTEST possible threshold and
    # blocked a real push. They fixed the substring half and left this half named
    # instead of working around it.
    #
    # An unparseable file falls back to scanning EVERY line: this detector exists
    # to convict, and skipping what it cannot parse would turn a syntax error into
    # a way to hide a gate relaxation.
    doc_lines: set[int] = set()
    try:
        tree = _parse(code)
    except UnparseableSource:
        tree = None
    if tree is not None:
        # EVERY bare string STATEMENT, not only the one at body[0].
        #
        # Taking only `body[0]` is the ast-based version of the same defect the
        # comment above describes: it models "docstring" instead of "prose". A
        # string expression that is not the first statement is still a string
        # expression -- it does nothing at runtime and its interior is not code
        # -- and it was being scanned as source. Reported as
        # DEBT-DETECTOR-LEE-PROSA-COMO-CODIGO by the own_chats session, who
        # believed the parser rewrite had already closed it. It had not, and my
        # first probe agreed with them because I used `fail_under = 100`, which
        # is not a pattern this detector convicts -- a false negative from
        # testing the wrong string. Measured with one it does:
        #
        #   _PROBE = """algo"""
        #   """never use --no-verify, it skips the hooks"""   <- line 3
        #   -> [(3, "Command contains '--no-verify' bypass ...")]
        #
        # The assignment on line 1 is not a docstring, so line 3's prose stopped
        # being body[0] and was judged as code.
        #
        # NOT widened to string literals used as VALUES: `run("git push
        # --no-verify")` is an argument, it reaches a shell, and it stays
        # convictable. The distinction is statement vs value, not quoted vs not.
        for node in _walk(tree):
            if (isinstance(node, ast.Expr)
                    and isinstance(node.value, ast.Constant)
                    and isinstance(node.value.value, str)):
                last = getattr(node, "end_lineno", None) or node.lineno
                doc_lines.update(range(node.lineno, last + 1))

    for idx, line in enumerate(lines, start=1):
        clean = line.strip()
        if idx in doc_lines or clean.startswith(("#", "*")):
            continue
        reason = _gate_relaxation_reason(clean, path)
        if reason is not None:
            hits.append((idx, reason))
    return hits


# `--no-verify` quoted while REPORTING a bypass is not a bypass: a receipt, an
# error message or a print about it is the gate speaking, not the gate being
# skipped.
_NO_VERIFY_MENTIONS = ("receipt", "error", "message", "print")


def _gate_relaxation_reason(clean: str, path: str | None) -> str | None:
    """What this single stripped, non-prose line relaxes -- or None.

    One line yields at most ONE reason: the three shapes are mutually
    exclusive in practice and the caller's `elif` chain said so before this
    split. Kept as a chain, not widened to collect all three, because
    widening it here would add convictions under cover of a refactor.
    """
    if "--no-verify" in clean and not any(k in clean.lower() for k in _NO_VERIFY_MENTIONS):
        return "Command contains '--no-verify' bypass; all commits must pass pre-commit/pre-push gates"
    if 'ignore = ["ALL"]' in clean or "ignore = ['ALL']" in clean:
        return "Configuration disables all linter rules via ignore=['ALL']"
    # `in` era SUBCADENA, y `fail_under = 100` contiene `fail_under = 1`: el detector
    # condenaba el umbral MAS ESTRICTO posible leyendolo como «casi cero», y con el
    # tambien 10, 15, 19, 1000... Medido el 2026-09-05 sobre
    # `verification/coverage_target.py`, cuyo docstring cita el `fail_under = 100` de
    # pyproject para explicar por que la fase 1 NO puede juzgarse contra el. Un detector
    # que condena lo contrario de lo que busca no protege: gasta el credito del que lo lee.
    if _FAIL_UNDER_CASI_CERO.search(clean) and path != "src/simplecode/cli_new.py":
        return "Configuration reduces test coverage threshold to near-zero"
    return None


def non_atomic_file_overwrite(code: str, path: str | None = None) -> bool:
    """Detect direct truncating open(..., 'w') in production file pipelines without atomic durable writes (GS2-222)."""
    return bool(non_atomic_file_overwrite_findings(code, path))


def _open_target_is_devnull(node: ast.Call) -> bool:
    """True si el primer argumento de `open(...)` es demostrablemente `os.devnull`
    (o su literal `/dev/null`, `nul`). Medido 2026-09-21 en aequitas_os
    (pruebas_aa27_certificados.py:469, `with open(os.devnull, "wb") as f`, el espia
    de control de una prueba de seguridad que verifica que firmar un PDF con P12 NO
    escribe a disco): no hay archivo real que truncar, ni corrupcion posible que un
    tempfile+rename evite -- el sumidero descarta todo sin estado que perder."""
    if not node.args:
        return False
    target = node.args[0]
    if (isinstance(target, ast.Attribute) and target.attr == "devnull"
            and isinstance(target.value, ast.Name) and target.value.id == "os"):
        return True
    return isinstance(target, ast.Constant) and target.value in ("/dev/null", "nul", "NUL")


def non_atomic_file_overwrite_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every non-atomic direct file overwrite call in src/, as (line, reason)."""
    if path and any(k in path.lower() for k in ("tests/", "test_")) and not any(k in path.lower() for k in ("control", "fixture")):
        return []
    tree = _parse(code)
    pymupdf_aliases = _pymupdf_module_aliases(tree)
    reassigned = _python_reassigned_names(tree)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func_name = ""
        is_attr_call = isinstance(node.func, ast.Attribute)
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif is_attr_call and isinstance(node.func, ast.Attribute):
            # Redundant with `is_attr_call` by value (this elif fires only when it's True) --
            # pyright does not propagate isinstance narrowing through a bool variable, so the
            # inline isinstance re-asserts it for the `.attr` access two lines down.
            func_name = node.func.attr
        if func_name != "open" or len(node.args) < 2:
            continue
        mode_arg = node.args[1]
        if not (isinstance(mode_arg, ast.Constant) and mode_arg.value in ("w", "wb", "w+")):
            continue
        # Mismo criterio que GS2-212 (`_receiver_is_nonpath`): un `.open()` sobre un
        # receptor demostrablemente no-ruta (zipfile/tarfile/sqlite/buffers/fitz) no
        # trunca ningun archivo real, sea cual sea el modo.
        owner = node.func.value if isinstance(node.func, ast.Attribute) else None
        pymupdf_module = isinstance(owner, ast.Name) and owner.id in pymupdf_aliases
        if is_attr_call and (pymupdf_module or _receiver_is_nonpath(node, reassigned)):
            continue
        if not is_attr_call and _open_target_is_devnull(node):
            continue
        hits.append((
            node.lineno,
            "Direct truncating open(..., 'w') in production pipeline; use atomic write (atomic_io.write_text_durable or tempfile+rename+fsync)",
        ))
    return hits


def complacent_verification_command(code: str, path: str | None = None) -> bool:
    """Detect tautological or complacent verification commands in contracts or tasks (GS2-223)."""
    return bool(complacent_verification_command_findings(code, path))


def complacent_verification_command_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every complacent verification command in tasks/backlog, as (line, reason)."""
    hits: list[tuple[int, str]] = []
    lines = code.splitlines()
    for idx, line in enumerate(lines, start=1):
        clean = line.strip().lower()
        if "verification_command:" in clean:
            cmd = clean.split("verification_command:", 1)[1].strip().strip('"\'')
            if any(t in cmd for t in ("assert true", "assert 1==1", "assert 1 == 1", "exit 0", "true")):
                hits.append((
                    idx,
                    f"Verification command '{cmd}' is a tautological stub; must run an executable test suite or gate",
                ))
    return hits


def poisonous_empty_fallback(code: str, path: str | None = None) -> bool:
    """Detect except blocks returning empty literals that silently poison downstream pipeline stages (GS2-224)."""
    return bool(poisonous_empty_fallback_findings(code, path))


def poisonous_empty_fallback_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every except block returning raw empty string/dict/list without raise or warning, as (line, reason)."""
    if path and any(k in path.lower() for k in ("tests/", "test_", "docs/")) and not any(k in path.lower() for k in ("control", "fixture")):
        return []
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not isinstance(node, ast.ExceptHandler) or not _catches_broadly(node):
            continue
        empty_lineno = _unannounced_empty_return_line(node)
        if empty_lineno is not None:
            hits.append((
                empty_lineno,
                "Broad except block returns empty literal fallback without logging or warning; risk of downstream pipeline poisoning",
            ))
    return hits


_BROAD_EXCEPTIONS = ("Exception", "BaseException")


def _catches_broadly(handler: ast.ExceptHandler) -> bool:
    """A bare `except:`, `except Exception`/`BaseException`, or a tuple that
    contains one of those. A narrow `except ValueError:` is NOT broad -- naming
    the exception you expect is the opposite of the vice."""
    if handler.type is None:
        return True
    if isinstance(handler.type, ast.Name):
        return handler.type.id in _BROAD_EXCEPTIONS
    if isinstance(handler.type, ast.Tuple):
        return any(isinstance(e, ast.Name) and e.id in _BROAD_EXCEPTIONS
                   for e in handler.type.elts)
    return False


def _is_empty_literal(val: ast.expr) -> bool:
    """`""`, `{}` or `[]` -- the shapes that poison a downstream stage by
    looking like a legitimate "nothing found". `None` and `0` are not here:
    the caller's vice is a fallback that TYPE-CHECKS as real data."""
    if isinstance(val, ast.Constant):
        return val.value == ""
    if isinstance(val, ast.Dict):
        return len(val.keys) == 0
    return isinstance(val, ast.List) and len(val.elts) == 0


def _unannounced_empty_return_line(handler: ast.ExceptHandler) -> int | None:
    """The line of the LAST empty-literal `return` in this handler, or None if
    there is none -- or if the handler says something first.

    "Says something" is any bare call statement, deliberately not an allowlist
    of logger names: `print(...)`, `warnings.warn(...)` and a project-specific
    reporter all count, and requiring a known logger would convict every
    project that names its own. Last, not first, because that is the line the
    unsplit loop left in `empty_lineno` after overwriting it.
    """
    empty_lineno: int | None = None
    for stmt in handler.body:
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            return None
        if (isinstance(stmt, ast.Return) and stmt.value is not None
                and _is_empty_literal(stmt.value)):
            empty_lineno = stmt.lineno
    return empty_lineno


def unhandled_error_continuation(code: str, path: str | None = None) -> bool:
    """Detect except blocks that log error but continue execution without raising or returning (GS2-225)."""
    return bool(unhandled_error_continuation_findings(code, path))


def unhandled_error_continuation_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every except block logging error without terminating handler, as (line, reason)."""
    if path and any(k in path.lower() for k in ("tests/", "test_", "docs/")) and not any(k in path.lower() for k in ("control", "fixture")):
        return []
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if isinstance(node, ast.ExceptHandler) and _logs_error_and_continues(node):
            hits.append((
                node.lineno,
                "Except block logs error/critical but continues execution without raise, return or recovery state",
            ))
    return hits


_ERROR_LOG_METHODS = ("error", "critical", "exception")
# A call that RECOVERS rather than merely reports: it records the failure in
# state, leaves, or writes it out. Matched on the method name alone, with no
# receiver check, for the same reason the log side is: a project's own
# collector is called `.append` too, and demanding a known receiver would let
# every wrapper through.
_RECOVERY_METHODS = ("append", "extend", "update", "set", "exit", "write")
_HANDLING_STATEMENTS = (ast.Raise, ast.Return, ast.Break, ast.Continue, ast.Assign, ast.AugAssign)


def _logs_error_and_continues(handler: ast.ExceptHandler) -> bool:
    """The handler reports an error and does nothing about it.

    Only the handler's OWN top-level statements count, not nested ones: a
    `raise` inside an `if` in the body does not clear the handler here, and did
    not before this split either. That is a declared ceiling of the detector,
    not an accident of the loop -- narrowing it to top level is what keeps
    `except: logger.error(...)` followed by a conditional retry convictable.
    """
    has_error_log = False
    has_handling = False
    for stmt in handler.body:
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            func_name = (stmt.value.func.attr
                         if isinstance(stmt.value.func, ast.Attribute) else "")
            if func_name in _ERROR_LOG_METHODS:
                has_error_log = True
            elif func_name in _RECOVERY_METHODS:
                has_handling = True
        elif isinstance(stmt, _HANDLING_STATEMENTS):
            has_handling = True
    return has_error_log and not has_handling


def test_atrophy_detector(code: str, path: str | None = None) -> bool:
    """Detect test functions hollowed out into empty stubs (GS2-226)."""
    return bool(test_atrophy_detector_findings(code, path))


def test_atrophy_detector_findings(code: str, path: str | None = None) -> list[tuple[int, str]]:
    """Every test function hollowed out to pass or ellipsis, as (line, reason)."""
    if path is not None and not _is_test_source_path(path):
        return []
    tree = _parse(code)
    hits: list[tuple[int, str]] = []
    for node in _walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if not node.name.startswith("test_"):
            continue
        if len(node.body) == 1:
            stmt = node.body[0]
            if isinstance(stmt, ast.Pass) or (
                isinstance(stmt, ast.Expr)
                and isinstance(stmt.value, ast.Constant)
                and stmt.value.value is Ellipsis
            ):
                hits.append((
                    node.lineno,
                    f"Test '{node.name}' is an empty pass/ellipsis stub; write real assertions or deprecate cleanly",
                ))
    return hits


# Registry: (function, key, human message). One entry per distinct vice --
# dedup'd union of the two source registries, not concatenated.
PATTERN_DETECTORS: tuple[tuple, ...] = (
    (untracked_prototype, "untracked_prototype", "Untracked prototype (TODO/FIXME/HACK without owner+expires)"),
    (premature_closure, "premature_closure", "Premature closure despite noted secondary failures"),
    (destructive_without_dryrun, "destructive_without_dryrun", "Destructive command with no dry-run path"),
    (broken_version_parity, "broken_version_parity", "Broken version parity (2+ version literals in one file)"),
    (deadlock_without_heartbeat, "deadlock_without_heartbeat", "Blocking call with no liveness/timeout marker"),
    (constant_stub, "constant_stub", "Stub as architecture (function body is just `return <constant>`)"),
    (blind_shell_edit, "blind_shell_edit", "Blind shell manipulation of a structured data file"),
    (placeholder_literal, "placeholder_literal", "Permanent placeholder literal assigned in code"),
    (core_dependent_on_unstable_parts, "core_dependent_on_unstable_parts", "Core code depends on an experimental/unstable module"),
    (hardcoded_secret, "hardcoded_secret", "Hardcoded secret or connection string with embedded credentials"),
    (optimistic_config, "optimistic_config", "Optimistic config (DEBUG/TESTING=True or secret as default)"),
    (frozen_nomenclature, "frozen_nomenclature", "Frozen nomenclature (versioned identifier baked into a name)"),
    (prompt_injection_in_agent_loop, "prompt_injection_in_agent_loop", "Possible prompt injection in an agent loop"),
    (unhandled_tool_call_failure, "unhandled_tool_call_failure", "Unhandled tool-call failure (no ok-check/retry/degrade)"),
    (multi_agent_without_protocol, "multi_agent_without_protocol", "Multi-agent edits without lock/handoff/owner protocol"),
    (insecure_defaults, "insecure_defaults", "Insecure default (verify=False, CORS '*', md5, bind-all)"),
    (blind_trust_in_llm_output, "blind_trust_in_llm_output", "Blind trust in LLM output flowing to a dangerous sink"),
    (premature_abstraction, "premature_abstraction", "Premature abstraction with exactly one implementation"),
    (unsafe_eval, "unsafe_eval", "Unsafe dynamic execution via eval()"),
    (test_without_assert, "test_without_assert", "Test function with no assert and no raises-context (test theater)"),
    (assert_true, "assert_true", "Trivial `assert True` that can never fail"),
    (tautological_assert, "tautological_assert", "Tautological assert comparing a value against itself"),
    (impossible_condition, "impossible_condition", "Assertion guarded by a statically-false condition (dead branch)"),
    (blind_except, "blind_except", "Blind except clause that silently swallows the failure"),
    (unconditional_exit_zero, "unconditional_exit_zero", "Unconditional exit(0) that ignores real state"),
    (io_without_validation, "io_without_validation", "External input reaching a dangerous sink without validation"),
    (uncritical_copy_paste, "uncritical_copy_paste", "Duplicated function bodies copied without comprehension"),
    (blanket_filterwarnings, "blanket_filterwarnings", "Blanket filterwarnings('ignore') with no category/justification"),
    (unjustified_nosemgrep, "unjustified_nosemgrep", "Bare nosemgrep suppression with no trailing justification"),
    (hardcoded_path, "hardcoded_path", "Hardcoded absolute machine path in a string literal"),
    (destructive_action_without_confirmation, "destructive_action_without_confirmation", "Destructive action with no explicit confirmation gate"),
    (invisible_debt, "invisible_debt", "Comment-only shortcut/workaround admission with no tracked follow-up"),
    (self_polluting_tooling, "self_polluting_tooling", "Temp-directory helper pinned back inside its own working tree"),
    (bom_in_config, "bom_in_config", "UTF-8 byte-order-mark at the start of a config file"),
    (ambiguous_handoff, "ambiguous_handoff", "Handoff/status note missing a required field"),
    (parameter_hiding_kwargs, "parameter_hiding_kwargs", "Parameter hiding via **kwargs unpacking to evade PLR0913"),
    (dead_docstring_displacement, "dead_docstring_displacement", "Dead docstring displacement (statements precede docstring)"),
    (unjustified_noqa_complexity, "unjustified_noqa_complexity", "Unjustified complexity suppression (# noqa: C901/PLR091x)"),
    (empty_stub_evasion, "empty_stub_evasion", "Empty or passthrough stub used to evade complexity gates"),
    (unjustified_test_skip, "unjustified_test_skip", "Unjustified @pytest.mark.skip or xfail with no explanation (VT-040)"),
    (blind_mock_injection, "blind_mock_injection", "Over-mocking test with bare MagicMock and no assertions (VT-009)"),
    (silent_io_loop_swallow, "silent_io_loop_swallow", "Silent exception swallowing in I/O loop without logging (CC-056)"),
    (hardcoded_dynamic_invariants, "hardcoded_dynamic_invariants", "Hardcoded static capacity or token limit in dynamic call (GS2-210)"),
    (mutable_default_argument, "mutable_default_argument", "Mutable default argument in function signature (GS2-211)"),
    (unencoded_file_io, "unencoded_file_io", "Text file read/write without explicit encoding (open/Path.read_text/Path.write_text) (GS2-212)"),
    (blocking_sleep, "blocking_sleep", "time.sleep() standing in for waiting on a condition (VT-039)"),
    (unmanaged_resource_open, "unmanaged_resource_open", "Resource open() assigned outside context manager (GS2-213)"),
    (opaque_boolean_assertion, "opaque_boolean_assertion", "assertTrue/assertFalse wrapping a comparison that had a more informative assertX sibling"),
    (covert_test_skip, "covert_test_skip", "Silent exception swallowing with pass/... inside test function (GS2-217)"),
    (integration_filesystem_mock, "integration_filesystem_mock", "Integration test mocks core filesystem primitive instead of using real tmp_path (GS2-218)"),
    (silent_dependency_skip, "silent_dependency_skip", "Silent skipping of tests on missing dependencies (GS2-219)"),
    (weak_existence_assert, "weak_existence_assert", "Superficial existence assertion in test without state verification (GS2-220)"),
    (gate_relaxation_tamper, "gate_relaxation_tamper", "Gate relaxation or linter bypass pattern in code/config (GS2-221)"),
    (non_atomic_file_overwrite, "non_atomic_file_overwrite", "Direct non-atomic file overwrite in production pipeline (GS2-222)"),
    (complacent_verification_command, "complacent_verification_command", "Tautological or complacent verification command in contract (GS2-223)"),
    (poisonous_empty_fallback, "poisonous_empty_fallback", "Except block returns empty literal without warning (GS2-224)"),
    (unhandled_error_continuation, "unhandled_error_continuation", "Except block logs error but continues without raise/return (GS2-225)"),
    (test_atrophy_detector, "test_atrophy_detector", "Test function hollowed out to pass/ellipsis stub (GS2-226)"),
)


# --- DEBT-SPEC8-RUST-TS-PARSERS: confess the AST-semantic blind spot ---------
# Every detector above (and every one in `agent_threats.py`) is written
# against Python's `ast` module or Python's own surface syntax. A Rust or
# TypeScript satellite's product used to get zero AST-level semantic
# detectors -- not a weaker version, none at all.
#
# `guards/multilang_ast.py` (added 2026-09-07) closes part of that: ONE real
# AST-semantic detector per language (silent-error-swallow, the same vice
# `angry_path` already convicts in Python), via the OPTIONAL `tree-sitter` +
# per-language grammar bindings (`pip install simplecode[multilang]`) --
# most satellites are pure Python and are never forced to install them.
# What remains genuinely blind, honestly: everywhere else in this file's
# ~37-detector list has no Rust/TS counterpart yet. This function's claim
# narrows accordingly -- "no AST parser reaches this language at all" is
# now false where the optional binding is installed; it stays true (and
# still confesses) where it is not.
_SEMANTIC_AST_BLIND_EXTS = (".rs", ".ts", ".tsx")


def unanalysed_semantic_source(root):
    """Tracked Rust/TypeScript(X) files with NO AST parser reaching them at all.

    A narrower claim than `zero_debt.unexamined_source`: that function says
    "nothing read this file"; this one says "no AST parses it". Since
    `multilang_ast` exists, that claim is conditional on whether its
    optional `tree-sitter` binding is actually installed HERE -- when it
    is, these extensions have at least one real (if narrow) AST-semantic
    detector, so they no longer belong in this confession; when it is not,
    the original blindness is unchanged and still reported. Reuses
    `zero_debt.unexamined_source`'s own tracked-file count (a plain
    ``git ls-files`` sweep, no untracked-file fallback quirk) rather than
    re-walking the tree.

    Returns ``{}`` (never a raise) when none of the applicable extensions
    are tracked, or when a parser reaches all of them -- the same "nothing
    to confess" shape used across this kit.
    """
    from simplecode.guards.multilang_ast import MULTILANG_AST_AVAILABLE
    from simplecode.worktree.zero_debt import unexamined_source

    if MULTILANG_AST_AVAILABLE:
        return {}
    unexamined = unexamined_source(root)
    return {ext: n for ext, n in unexamined.items() if ext in _SEMANTIC_AST_BLIND_EXTS}
