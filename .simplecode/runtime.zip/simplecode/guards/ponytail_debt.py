# -*- coding: utf-8 -*-
"""Enforces that declared technical debt has a defined ceiling and expiration trigger."""
from __future__ import annotations

import argparse
import ast
import io
import datetime
import re
import sys
import tokenize
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.git_utils import git_ls_files

FICHA_UNDECLARED_RELPATH = "tasks/backlog/DEBT-PONYTAIL-UNDECLARED.md"

# `ponytail` is lower-case by CLAUDE.md; TODO/FIXME/DEBT are upper-case by
# convention. The distinction is not cosmetic -- it is what keeps the detector
# off ordinary English.
#
# Until 2026-09-05 the whole pattern was IGNORECASE with an OPTIONAL comment
# prefix, so any line beginning `debt:` counted. That convicted a wrapped
# docstring sentence in `finding_backlog.py`:
#
#     debt: the subject was read and judged. `COULD_NOT_RUN` is an open file the
#
# -- prose that begins a line only because the paragraph wraps there. The gate
# then WROTE a ficha for it, and the backlog gate blocked the push on the ficha
# its neighbour had just invented. An instrument that manufactures its own
# subject is worse than one that misses: it costs a real push and the finding is
# not there.
#
# The comment prefix stays optional on purpose: the two real markers in
# `pattern_detectors.py` live inside docstrings, on lines that open no comment.
DEBT_MARKER_RE = re.compile(
    r"""^(?:\#+|\"\"\"|''')?[ \t]*(?:ponytail|PONYTAIL|TODO|FIXME|DEBT):"""
)
# A marker in a TRAILING comment (`x = 1  # ponytail: hack`). Until 2026-09-28
# only DEBT_MARKER_RE existed, anchored at line start, so this shape passed the
# gate with `rc=0, HALLAZGOS: 0` while the same text on its own line gave rc=1.
# The `\s` before `#` keeps string literals like `("# TODO:"` off the detector.
INLINE_MARKER_RE = re.compile(r"""\s\#+[ \t]*(?:ponytail|PONYTAIL|TODO|FIXME|DEBT):""")
TRIGGER_RE = re.compile(r"(?i)\b(?:disparador|trigger)\b")
MAX_BLOCK_LINES = 15
MIN_CEILING_LEN = 12


def extract_debt_block(lines: list[str], start_idx: int) -> str:
    """Extract and flatten the comment block starting at start_idx."""
    chunk = [lines[start_idx]]
    for line in lines[start_idx + 1 : start_idx + MAX_BLOCK_LINES]:
        clean = line.strip().lstrip("#").strip()
        if not clean:
            break
        chunk.append(clean)
    return " ".join(t.strip().lstrip("#").strip() for t in chunk)


def audit_debt_marker(lines: list[str], line_idx: int) -> str | None:
    """Check if the debt marker at line_idx has a ceiling and trigger."""
    block_text = extract_debt_block(lines, line_idx)
    parts = re.split(r"(?:ponytail|PONYTAIL|TODO|FIXME|DEBT):", block_text, maxsplit=1)
    if len(parts) < 2:
        return "invalid_debt_marker"

    body = parts[1]
    trigger_match = TRIGGER_RE.search(body)
    if not trigger_match:
        return "missing_trigger: debt declared without expiration trigger (`trigger:` or `disparador:`)"

    ceiling = body[: trigger_match.start()].strip(" ,.;:-_")
    if len(ceiling) < MIN_CEILING_LEN:
        return "missing_ceiling: debt declared without describing the scope and upper bound (>= 12 chars)"

    return None


CORPUS_MARK = re.compile(r"#\s*simplecode:corpus\s+(\S.*)")


def _python_marker_lines(content: str) -> dict[int, tuple[str, bool]]:
    """Audit comment tokens and explicit docstring declarations, preserving source rows.

    Examples inside strings and indented docstring code blocks are data. Bare
    declarations at the docstring's prose margin remain part of the contract.
    Parsing failures propagate: an unexamined file cannot produce a clean list.
    """
    tree = ast.parse(content)
    lines = content.splitlines()
    candidates = {}
    for tok in tokenize.generate_tokens(io.StringIO(content).readline):
        if tok.type == tokenize.COMMENT and DEBT_MARKER_RE.match(tok.string):
            row, col = tok.start
            candidates[row - 1] = (tok.string, bool(lines[row - 1][:col].strip()))
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if not node.body or not isinstance(node.body[0], ast.Expr):
            continue
        value = node.body[0].value
        if not isinstance(value, ast.Constant) or not isinstance(value.value, str):
            continue
        # Keep physical source rows: decoding escapes invents lines and moves
        # findings. The closing delimiter also anchors an example's indentation.
        segment = ast.get_source_segment(content, value)
        assert segment is not None
        raw = segment.expandtabs().splitlines()
        margin = min((len(line) - len(line.lstrip()) for line in raw[1:] if line.strip()), default=0)
        raw[0] = re.sub(r"(?i)^[ru]*(?:\"\"\"|'''|\"|')", "", raw[0], count=1)
        raw[-1] = re.sub(r"(?:\"\"\"|'''|\"|')$", "", raw[-1], count=1)
        for offset, line in enumerate(raw):
            text = line.lstrip() if offset == 0 else line[margin:]
            if text == text.lstrip() and re.match(r"(?:ponytail|PONYTAIL|TODO|FIXME|DEBT):", text):
                candidates[value.lineno - 1 + offset] = (text, False)
    return dict(sorted(candidates.items()))


def scan_file_debt(file_path: Path) -> list[tuple[int, str]]:
    """Scan a source file for non-compliant technical debt markers."""
    findings: list[tuple[int, str]] = []
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    lines = content.splitlines()
    for line in lines[:10]:
        if CORPUS_MARK.search(line):
            return []

    candidates = _python_marker_lines(content) if file_path.suffix == ".py" else {
        idx: (line, not line.lstrip().startswith("#") and bool(INLINE_MARKER_RE.search(line)))
        for idx, line in enumerate(lines)
    }
    for idx, (line, inline) in candidates.items():
        if inline:
            issue = audit_debt_marker([line], 0)
        elif DEBT_MARKER_RE.match(line.strip()):
            issue = audit_debt_marker([line, *lines[idx + 1:]], 0)
        else:
            continue
        if issue:
            findings.append((idx + 1, issue))
    return findings


def get_target_files(root: Path, paths: list[Path] | None = None) -> list[Path]:
    """Get target code files to scan."""
    valid_exts = {".py", ".sh"}
    if paths:
        return [p.resolve() for p in paths if p.is_file() and p.suffix.lower() in valid_exts]

    return git_ls_files(root, valid_exts=valid_exts)


def _leer_created(ficha_path: Path) -> str:
    """La fecha de creacion YA declarada en la ficha, o hoy si es la primera vez.

    Sin esto, `created:` se re-estamparia en cada corrida del gate y una ficha
    de marcadores viejos parecería nacida ayer -- exactamente el defecto que
    `_finding_key`/`razon_derivada` en otros gates de este mismo repo existen
    para evitar en su propio dominio.
    """
    if ficha_path.is_file():
        m = re.search(r"^created:\s*(\S+)", ficha_path.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1)
    return datetime.date.today().isoformat()


def actualizar_ficha_undeclared(root: Path, hallazgos: dict[Path, list[tuple[int, str]]]) -> str | None:
    """Escribe/actualiza `tasks/backlog/DEBT-PONYTAIL-UNDECLARED.md` con los
    marcadores SIN techo+disparador. Devuelve la ruta escrita, o None si no
    habia nada que declarar (no crea una ficha vacia -- 0 debt no es debt).

    Existe porque `ponytail:`/`TODO`/`FIXME` viven en el codigo, gobernados por
    este mismo modulo, y NUNCA tenian un puntero en `tasks/`: un marcador mal
    declarado podia pasar desapercibido si nadie corria este gate a mano y el
    gate mismo no estaba cableado a ningun hook (medido 2026-09-04: cero
    referencias en `.pre-commit-config.yaml` de simplecode o en la plantilla
    que se distribuye a la flota). Solo los marcadores QUE VIOLAN la regla
    generan ficha -- uno bien declarado (con su techo y su disparador) ya es
    una afirmacion firmada por su autor, no deuda sin ubicar.
    """
    ficha_path = root / FICHA_UNDECLARED_RELPATH
    if not hallazgos:
        # 0 marcadores sin declarar no es deuda: si la ficha existia de una
        # corrida anterior, borrarla es lo correcto -- es contenido puramente
        # mecanico ("no la edites a mano, se sobreescribe"), y dejarla stale
        # con marcadores que ya no existen seria peor que no tenerla.
        if ficha_path.is_file():
            ficha_path.unlink()
            return str(ficha_path)
        return None
    detalle = []
    for f in sorted(hallazgos):
        rel = f.relative_to(root) if f.is_relative_to(root) else f
        for line_no, issue in hallazgos[f]:
            detalle.append(f"- `{rel}:{line_no}` -- {issue}")
    cuerpo = "\n".join(detalle)
    total = sum(len(v) for v in hallazgos.values())
    contenido = f"""---
id: DEBT-PONYTAIL-UNDECLARED
kind: debt
title: Marcadores de deuda (ponytail/TODO/FIXME/DEBT) sin techo ni disparador
status: open
severity: P3
origin: detected
satd_family: CODE_DESIGN_DEBT
close_check: {{"cmd": "python -m simplecode.guards.ponytail_debt --root .", "expect": "exit_zero"}}
created: {_leer_created(ficha_path)}
detector: {{"rule": "ponytail_debt/undeclared_marker", "confidence": 1.0}}
---

## Context

Generada y REGENERADA por `ponytail_debt.py --gate` en cada corrida -- no la edites a
mano, se sobreescribe. Cada marcador de abajo existe en el codigo pero no declara
techo+disparador, que es exactamente lo que la ley `ponytail` (CLAUDE.md) exige de un
atajo deliberado: `ponytail: <ceiling>, <trigger>`. Sin ellos, el marcador no dice
cuando alguien deberia volver a mirarlo.

Se cierra sola (o queda para cerrar a mano) cuando la lista de abajo llega a cero: el
proximo `close_check` sale 0 y el gate deja de regenerarla.

## {total} marcador(es) sin declarar

{cuerpo}
"""
    atomic_io.write_text_durable(ficha_path, contenido)
    return str(ficha_path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Audit code comments for technical debt compliance (requires ceiling and trigger)."
    )
    parser.add_argument("paths", nargs="*", type=Path, help="Specific files to audit")
    parser.add_argument("--root", type=Path, default=None, help="Repository root directory")
    parser.add_argument("--gate", action="store_true",
                        help="Ademas de reportar, escribe/actualiza una ficha en "
                             f"{FICHA_UNDECLARED_RELPATH} con los marcadores sin declarar.")
    args = parser.parse_args(argv)

    root = (args.root or Path.cwd()).resolve()
    target_files = get_target_files(root, args.paths if args.paths else None)

    total_violations = 0
    hallazgos: dict[Path, list[tuple[int, str]]] = {}
    for f in target_files:
        findings = scan_file_debt(f)
        if findings:
            try:
                rel = f.relative_to(root)
            except ValueError:
                rel = f
            print(f"[ponytail-debt] FAIL: {rel}")
            for line_no, issue in findings:
                print(f"  Line {line_no}: {issue}")
            total_violations += len(findings)
            hallazgos[f] = findings

    if args.gate:
        tocada = actualizar_ficha_undeclared(root, hallazgos)
        if tocada and hallazgos:
            print(f"[ponytail-debt] ficha actualizada: {tocada}")
        elif tocada:
            print(f"[ponytail-debt] ficha retirada (0 sin declarar): {tocada}")

    emit_hallazgos("[ponytail-debt]", total_violations)

    if total_violations == 0:
        print(f"[ponytail-debt] OK: {len(target_files)} file(s) scanned, 0 unmanaged debt markers.")
        return 0

    # CONDENA: the subject was read, and at least one marker lacks a ceiling
    # and/or trigger. `hallazgos` preserves scan order, so its first entry is
    # the first concrete site -- no second pass needed to find it again.
    primer_file, primer_hallazgos = next(iter(hallazgos.items()))
    primer_line, primer_issue = primer_hallazgos[0]
    try:
        primer_rel = primer_file.relative_to(root)
    except ValueError:
        primer_rel = primer_file
    primer_clase = primer_issue.split(":", 1)[0]
    print(f"[ponytail-debt] FAIL: {total_violations} marcador(es) sin techo/disparador; "
          f"primero {primer_rel}:{primer_line} ({primer_clase})")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
