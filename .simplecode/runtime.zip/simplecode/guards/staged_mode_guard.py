#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reads the MODE of the staged entries -- the one dimension no other gate looks at.

DEBT-PUSH-LOOP-11. A tracked `.simplecode/runtime.zip` (mode `100644`) turned up
in a worktree as a `120000` symlink to another checkout's copy, and the whole
pre-commit suite -- twelve hooks -- reported `no files to check` over it with
rc 0. The producer of that particular symlink is fixed (`61dc2bd`); the CLASS is
what this module closes: every other gate reads CONTENT (bytes, lines, imports,
AST) or filters by LANGUAGE, and a file's mode is not content.

MEASURED, and it is the mechanism behind that silence, not a guess: pre-commit
resolves `types:` through `identify`, and for a symlink `identify.tags_from_path`
returns `['symlink']` alone -- no `file`, no `text`, no `python`. Every hook with
the default `types: [file]` is therefore STRUCTURALLY unable to see a staged
symlink, whatever its `files:` pattern says. That is why this gate is wired with
`always_run: true`: a hook that can be skipped cannot guard the case whose whole
signature is being skipped.

What it blocks, and nothing else:

1. A tracked path whose staged mode CROSSES the symlink boundary
   (`100644`/`100755` -> `120000`, and the inverse `120000` -> `100644`). The
   entry stops being the kind of thing the repo said it was. The `120000`
   direction is the ficha's subject; the inverse is the other half the ficha's
   acceptance item names, and it is the same one-line rule, not a second one.
2. Any staged symlink -- new or pre-existing -- whose destination is an ABSOLUTE
   path. An absolute path of this machine does not survive a clone: measured in
   the ficha, `-f` follows a dangling link before any sha256 comparison, so every
   generated hook in every clone exits 2 with `COULD_NOT_RUN`, and nobody can
   push. Big blast radius, zero stealth.

What it deliberately does NOT block (each one has a test; a guard that blocks
everything verifies nothing):

- `100644 -> 100755` and back. Adding or dropping the executable bit is
  legitimate and frequent, and it does not change the KIND of the entry.
- A new symlink with a RELATIVE destination. When the repo tracks no other
  symlink this module prints a NOTE saying so and still exits 0 -- whether a
  repo admits tracked symlinks at all is a policy call for a human, and deciding
  it here would be this gate inventing a rule nobody voted.
- Deleting a symlink (`120000 -> 000000`), and a `160000` gitlink: neither
  crosses the symlink boundary. Out of scope, stated rather than silently
  covered.

Honest limit: a RELATIVE destination that escapes the repo (`../../elsewhere`)
is not judged. It survives a clone syntactically, its meaning depends on what
sits beside the clone, and no measurement of that case exists yet.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from simplecode.utils.gate_signal import emit_hallazgos
from simplecode.utils.tool_limits import GIT_O1_TIMEOUT, GIT_SCAN_TIMEOUT

TAG = "[staged-mode-guard]"
SYMLINK_MODE = "120000"
ABSENT_MODE = "000000"


class GitUnavailable(RuntimeError):
    """`git` itself never ran (missing binary, timeout): nothing was checked.

    Kept distinct from a non-zero returncode out of a git that DID run: "not a
    git repository" is an honest empty staged set, while a git that never
    started means this gate has no verdict about the commit at all. Collapsing
    the two is how a dead instrument passes for a clean subject.
    """


@dataclass(frozen=True)
class ModeFinding:
    """One staged entry whose mode is not what the repo can survive."""

    path: str
    old_mode: str
    new_mode: str
    reason: str
    detail: str
    repair: str

    def render(self) -> str:
        return (
            f"{TAG} BLOCKED: {self.path}: mode {self.old_mode} -> {self.new_mode} "
            f"({self.reason}). {self.detail} Repair: {self.repair}"
        )


def _git(root: Path, *args: str, timeout: float = GIT_O1_TIMEOUT) -> subprocess.CompletedProcess[bytes]:
    """Run git, or raise `GitUnavailable` -- never return a fabricated result."""
    try:
        return subprocess.run(
            ["git", "-C", str(root), *args],
            capture_output=True,
            check=False,
            timeout=timeout,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise GitUnavailable(f"git {' '.join(args)} could not be run: {exc}") from exc


def _decode(raw: bytes) -> str:
    return raw.decode("utf-8", "surrogateescape")


@dataclass(frozen=True)
class StagedEntry:
    """A `git diff --cached --raw` record: the two modes and the path they name."""

    old_mode: str
    new_mode: str
    status: str
    path: str


def staged_entries(root: Path) -> list[StagedEntry]:
    """Every staged entry with its OLD and NEW mode, from `diff --cached --raw -z`.

    `-z` because a path may contain any byte but NUL, and the tab-delimited form
    quotes such paths instead of emitting them -- a quoted path is a different
    string from the one `git cat-file blob :<path>` needs.
    """
    proc = _git(root, "diff", "--cached", "--raw", "-z")
    if proc.returncode != 0:
        return []
    fields = _decode(proc.stdout).split("\0")
    entries: list[StagedEntry] = []
    i = 0
    while i < len(fields):
        header = fields[i]
        i += 1
        if not header.startswith(":"):
            continue
        parts = header[1:].split()
        # A well-formed record is `<old> <new> <sha> <sha> <status>`. Anything
        # else (a merge's `::` combined form, a truncated tail) is skipped
        # rather than half-parsed into a mode this gate would then judge.
        if len(parts) != 5:
            continue
        old_mode, new_mode, _old_sha, _new_sha, status = parts
        wanted = 2 if status[:1] in {"R", "C"} else 1
        paths = fields[i : i + wanted]
        i += wanted
        if len(paths) != wanted or not paths[-1]:
            continue
        entries.append(StagedEntry(old_mode, new_mode, status, paths[-1]))
    return entries


def symlink_target(root: Path, path: str) -> str | None:
    """The destination of a staged symlink: the blob's content IS the target."""
    proc = _git(root, "cat-file", "blob", f":{path}")
    if proc.returncode != 0:
        return None
    return _decode(proc.stdout).strip()


def other_tracked_symlinks(root: Path, exclude: set[str]) -> list[str]:
    """Symlinks already in the index, excluding the paths under judgment."""
    proc = _git(root, "ls-files", "-s", "-z", timeout=GIT_SCAN_TIMEOUT)
    if proc.returncode != 0:
        return []
    found: list[str] = []
    for record in _decode(proc.stdout).split("\0"):
        if not record.startswith(f"{SYMLINK_MODE} "):
            continue
        # `<mode> <sha> <stage>\t<path>`; the path keeps every byte it has.
        _meta, _, path = record.partition("\t")
        if path and path not in exclude:
            found.append(path)
    return found


def _repair_for(entry: StagedEntry) -> str:
    """The concrete command that undoes THIS staged entry.

    `HEAD` is explicit and load-bearing, MEASURED 2026-09-15 in a scratch repo
    with the typechange staged: the bare `git checkout -- <path>` exits 0 and
    leaves `:100644 120000 ... T` exactly where it was, because checkout reads
    the INDEX, and the index is what holds the symlink. It is the worst shape a
    repair can have -- it reports success and changes nothing. `git checkout
    HEAD -- <path>` restores index and working tree both, verified by the raw
    diff coming back empty (`test_the_named_repair_actually_repairs`).

    A path git has never seen has no HEAD version to restore, so the same
    command there would fail; that case is unstaged instead.
    """
    if entry.old_mode != ABSENT_MODE:
        return f"git checkout HEAD -- {entry.path}"
    return f"git rm --cached {entry.path} (and re-add it with a destination relative to the repo)"


def analyze(root: Path) -> tuple[list[ModeFinding], list[str], int]:
    """Findings that must block, notes that never block, and HOW MANY entries were read.

    The count travels with the verdict on purpose: without it, "no findings" and
    "read nothing at all" print the same line.
    """
    entries = staged_entries(root)
    findings: list[ModeFinding] = []
    notes: list[str] = []
    new_relative_symlinks: list[StagedEntry] = []

    for entry in entries:
        crosses_into = entry.new_mode == SYMLINK_MODE and entry.old_mode not in {ABSENT_MODE, SYMLINK_MODE}
        crosses_out = entry.old_mode == SYMLINK_MODE and entry.new_mode not in {ABSENT_MODE, SYMLINK_MODE}
        if crosses_into or crosses_out:
            kind = (
                "typechange regular file -> symlink"
                if crosses_into
                else "typechange symlink -> regular file"
            )
            findings.append(
                ModeFinding(
                    path=entry.path,
                    old_mode=entry.old_mode,
                    new_mode=entry.new_mode,
                    reason=kind,
                    detail=(
                        f"the repo TRACKS {entry.path} and this commit would change what kind "
                        f"of entry it is, not its content."
                    ),
                    repair=_repair_for(entry),
                )
            )
        if entry.new_mode != SYMLINK_MODE:
            continue
        target = symlink_target(root, entry.path)
        if target is None:
            notes.append(
                f"{TAG} NOTE: {entry.path} is staged as a symlink and its blob could not be "
                f"read, so its destination was NOT judged."
            )
            continue
        if target.startswith("/"):
            findings.append(
                ModeFinding(
                    path=entry.path,
                    old_mode=entry.old_mode,
                    new_mode=entry.new_mode,
                    reason="symlink destination is an ABSOLUTE path",
                    detail=(
                        f"destination {target!r} is absolute, so it names a location on THIS "
                        f"machine and arrives dangling in every clone."
                    ),
                    repair=_repair_for(entry),
                )
            )
        elif entry.old_mode == ABSENT_MODE:
            new_relative_symlinks.append(entry)

    if new_relative_symlinks:
        staged_paths = {entry.path for entry in new_relative_symlinks}
        if not other_tracked_symlinks(root, staged_paths):
            listed = ", ".join(sorted(staged_paths))
            notes.append(
                f"{TAG} NOTE: {listed} would be the FIRST symlink this repo tracks; nothing is "
                f"blocked, because whether this repo admits tracked symlinks at all is a human "
                f"decision this gate does not make."
            )
    return findings, notes, len(entries)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Block staged mode changes that cross the symlink boundary or point outside any clone."
    )
    ap.add_argument("--root", default=".", help="Repository root to inspect (default: the cwd).")
    ap.add_argument("--gate", action="store_true", help="Exit 1 when there is a finding.")
    args = ap.parse_args(argv)

    root = Path(args.root)
    try:
        findings, notes, examined = analyze(root)
    except GitUnavailable as exc:
        print(f"{TAG} COULD_NOT_RUN: {exc}", file=sys.stderr)
        return 2

    for note in notes:
        print(note)
    for finding in findings:
        print(finding.render())
    # The zeros get printed: a gate that only speaks when it convicts leaves no
    # way to tell "looked, found nothing" from "never looked".
    print(f"{TAG} staged entries examined: {examined}; findings: {len(findings)}")
    emit_hallazgos(TAG, len(findings))
    if findings and args.gate:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
