#!/usr/bin/env python3
"""Create and list Architecture Decision Records."""

from __future__ import annotations

import argparse
import re
import textwrap
from datetime import date
from pathlib import Path


def _slug(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")


def _content(number: int, title: str) -> str:
    return textwrap.dedent(
        f'''\
        # ADR-{number:04d}: {title}

        Status: Proposed
        Date: {date.today().isoformat()}
        Deciders: [Author]

        ## Context
        Describe the forces that require this decision.

        ## Decision
        State the chosen option.

        ## Options Considered
        1. Chosen option: explain cost and benefit.
        2. Rejected option: explain why it lost.

        ## Consequences
        Describe positive and negative consequences.
        '''
    )


def _new(title: str | None) -> int:
    if not title or not _slug(title):
        print('Usage: simplecode adr new "Title of decision"')
        return 1
    adr_dir = Path.cwd() / "docs" / "adr"
    adr_dir.mkdir(parents=True, exist_ok=True)
    numbers = [
        int(path.stem.split("-", 1)[0])
        for path in adr_dir.glob("[0-9][0-9][0-9][0-9]-*.md")
    ]
    number = max(numbers, default=0) + 1
    path = adr_dir / f"{number:04d}-{_slug(title)}.md"
    from simplecode.utils import atomic_io
    atomic_io.write_text_durable(path, _content(number, title))
    print(f"Created {path}")
    print("Edit it, then change Status to Accepted when ready.")
    return 0


def _status(content: str) -> str:
    match = re.search(r"^\*\*?Status\*\*?:\s*(.+)$|^Status:\s*(.+)$", content, re.M)
    if not match:
        return "Proposed"
    return next(value.strip() for value in match.groups() if value)


def _list() -> int:
    adr_dir = Path.cwd() / "docs" / "adr"
    if not adr_dir.exists():
        print('No ADRs yet. Run: simplecode adr new "Title"')
        return 0
    print("Architecture Decision Records\n")
    for path in sorted(adr_dir.glob("[0-9][0-9][0-9][0-9]-*.md")):
        print(f"  {path.stem}  {_status(path.read_text(encoding='utf-8'))}")
    return 0


def main(args: argparse.Namespace) -> int:
    if args.adr_command == "new":
        return _new(args.title)
    if args.adr_command == "list":
        return _list()
    print("Usage: simplecode adr <new|list>")
    return 1
