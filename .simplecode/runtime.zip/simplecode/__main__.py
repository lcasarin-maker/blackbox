"""Entry point for simplecode CLI."""

from simplecode.cli import main

if __name__ == "__main__":
    import sys
    sys.exit(main())