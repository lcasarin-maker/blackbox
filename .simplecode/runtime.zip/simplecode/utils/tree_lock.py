# -*- coding: utf-8 -*-
"""tree_lock.py -- one advisory lock per working tree, so pre-push gates can overlap safely.

The pre-push suite is a set of gates that read the working tree (pyright,
zero-debt-repo, adversarial-judge, version-bump, pii-scan) and one gate whose
tests WRITE it: `coverage-100`, phase 2, the tests marked `mutates_real_source`
that temporarily overwrite a real file under src/ (see coverage_target.py). A
reader that opens the file inside that window reads a half-mutated tree and
reports a defect that does not exist.

Running the suite one gate after another made that impossible by construction.
Running it concurrently (prek, `prek_schedule.py`) makes it possible, so the
window is closed by a lock and not by timing: readers hold it SHARED while they
run, the mutating lane holds it EXCLUSIVE. Readers overlap each other and the
whole of coverage phase 1; only phase 2 waits for them and they for it.

`flock` and not a sentinel file: the kernel drops the lock when its holder
dies, so a killed gate cannot leave the tree locked for the next push.
"""
from __future__ import annotations

import contextlib
from collections.abc import Iterator
from pathlib import Path

try:
    import fcntl
except ImportError:  # ponytail: no lock on a platform without fcntl, prek has no Windows asset so gates never overlap there; revisit when prek_vendor pins a Windows build
    fcntl = None  # type: ignore[assignment]  # sunset-reviewed: 9.8 -- optional-import idiom: fcntl does not exist on Windows and the module documents that no lock is taken there

LOCK_RELPATH = Path(".simplecode") / "tree.lock"

# `gate_runner --name` of the gates that take the lock SHARED. The schedule
# (`prek_schedule.py`) lets exactly these overlap the writer; a gate that is not
# listed runs after it, so a new gate is safe by default and fast only on request.
READERS = frozenset({"zero-debt-repo", "pyright", "adversarial-judge", "version-bump", "pii-scan"})
# The one gate whose tests mutate real source, and which holds the lock EXCLUSIVE.
WRITER = "coverage-100"


@contextlib.contextmanager
def _held(root: Path, mode: int) -> Iterator[None]:
    if fcntl is None:
        yield
        return
    path = root / LOCK_RELPATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        fcntl.flock(handle, mode)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def shared(root: Path) -> contextlib.AbstractContextManager[None]:
    """Hold the tree for READING: other readers proceed, a writer waits."""
    return _held(root, fcntl.LOCK_SH if fcntl else 0)


def exclusive(root: Path) -> contextlib.AbstractContextManager[None]:
    """Hold the tree for WRITING real source: readers and other writers wait."""
    return _held(root, fcntl.LOCK_EX if fcntl else 0)
