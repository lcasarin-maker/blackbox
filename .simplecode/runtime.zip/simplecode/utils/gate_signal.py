"""The one line a gate prints to declare how many things it found.

DEBT-GATE-RUNNER-NEVER-WRITES-HALLAZGOS: `gate_effectiveness` reads a
per-gate `hallazgos` count from telemetry so it can tell "ran clean" apart
from "found N things and did not block" (`sin_senal` otherwise catches both
alike). `gate_runner._parse_hallazgos` looks for exactly this line, so every
gate that has a real count to declare calls `emit_hallazgos` with it -- once,
unconditionally, on every exit path: the clean one too, not just the one that
blocks. A gate that never calls this stays absent in telemetry (`None`, not
`0`) until it adopts the convention; a gate that has genuinely nothing
countable (a percentage, a pure launcher) should not call it at all rather
than invent a number.
"""

from __future__ import annotations

import json


def emit_hallazgos(tag: str, n: int) -> None:
    """Print `n` (>= 0) as this gate's declared findings count for the run.

    `tag` is the gate's own bracketed name, e.g. `"[zero-debt]"` -- the same
    tag its other verdict lines already use, so one shared regex in
    `gate_runner` can find it regardless of which gate ran.
    """
    print(f"{tag} HALLAZGOS: {n}")


def emit_detectores(tag: str, counts: dict[str, int]) -> None:
    """Print which detector produced this run's findings, as one JSON object.

    Twin of `emit_hallazgos`: that line says HOW MANY, this one says WHO. The
    blackbox session measured the gap on 2026-09-27 -- of 16 zero-debt blocks
    it could attribute 3 to a detector and 13 not, because the telemetry row
    carried the block bit and nothing else. Printed on every path that ran the
    scan, `{}` included: an empty object is a measured "no detector fired",
    while a missing line stays absent in the row, as for `hallazgos`.
    """
    print(f"{tag} DETECTORES: {json.dumps(dict(sorted(counts.items())), separators=(',', ':'))}")
