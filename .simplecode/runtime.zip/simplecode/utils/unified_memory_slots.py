"""Global admission for workers that initialize CUDA on unified memory.

Why this exists
---------------
`UNIFIED_MEMORY_WORKER_CAP` caps ONE process at 6. The resource it protects is
not per-process: each worker spawns a full pytest child that imports the
backend and initializes CUDA, and the unified-memory pool is one pool for the
whole machine. Measured on the GB10 box 2026-09-22/23: 16 concurrent crossed
the cliff, 20 and 23 froze it for 17 h 45 min and 5 h 55 min. N coders each
correctly capped at 6 is 6N children, so three concurrent coders reaches 18 --
above the 16 that crossed -- with every per-process cap applied and working.

That gap is not hypothetical on this machine. Measured 2026-09-23: Atlas
deploys coders with no declared ceiling (5 agent worktrees, 28 `claude`
processes live, and no `max_agents`/`max_parallel` anywhere in its tools), and
the one admission gate on the box -- `/srv/ai/gpu_governance/admission_check.sh`
-- is wired as `ExecStartPre` on exactly two units (`ai-ollama`, `ai-nemotron`).
No coder passes through it.

What this does
--------------
One counter shared by every process on the machine, behind an `flock`. A caller
asks for `want` slots and gets what is left under the ceiling. Over the
ceiling it WAITS instead of failing, because the alternative to waiting is the
freeze, and a freeze costs hours while waiting costs minutes.

LIMITS, declared:
  - Slots are ADVISORY. A process that never calls this is not counted and
    nothing stops it. This raises the floor for simplecode's two fan-outs; it
    is not a kernel-level reservation. H34 already established that no such
    reservation exists on this driver -- the `dmem` cgroup controller is
    structurally present and left unpopulated by 580.173.02 -- which is why
    refusing to start is the only lever anyone has here.
  - State lives in `XDG_RUNTIME_DIR` (tmpfs), so it vanishes on reboot. That
    is deliberate: a counter that survived a hard reset would come back
    claiming slots for the processes the reset had just killed.
  - On timeout the caller is granted ONE slot rather than blocked forever.
    That can overshoot the ceiling by one per waiter. Overshooting by one is a
    declared, bounded cost; a fan-out that never returns is an outage, and
    this module exists to prevent outages, not to cause a quieter one.
"""

from __future__ import annotations

import errno
import fcntl
import json
import os
import sys
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from simplecode.utils import atomic_io

# Below the 16 that crossed the cliff, above the 6 a single process can ask
# for -- so one coder working alone is never slowed down by this at all, and
# the third concurrent one is the first to wait. Like UNIFIED_MEMORY_WORKER_CAP
# this is a measured value, not a formula: the formula would have to divide
# MemAvailable by a per-worker footprint, and MemAvailable is precisely the
# number that lied (69 GiB of 124 GiB while every task on the box was stalled
# 99 % of the time).
UNIFIED_MEMORY_SLOT_CEILING = 12

CEILING_ENV = "SIMPLECODE_UNIFIED_SLOT_CEILING"
STATE_ENV = "SIMPLECODE_UNIFIED_SLOT_DIR"
PSI_ENV = "SIMPLECODE_UNIFIED_PSI_VETO"
PSI_PATH_ENV = "SIMPLECODE_UNIFIED_PSI_PATH"

# El contador de arriba frena por CUENTA, que es un proxy. Esto frena por la
# SENAL, que es lo que faltaba: durante los dos congelamientos PSI memory full
# marco 98-99 % las dos noches y nadie la consumio -- `bb` la registraba y
# ningun gate la miraba antes de dejar arrancar trabajo. Un instrumento que
# mide y no frena no es una mitigacion.
#
# 10.0 no es un numero nuevo: es UMBRAL, el corte que blackbox calibro el
# 2026-09-23 contra sus dos congelamientos propios (bin/bb:1108,
# `UMBRAL, SOSTENIDO, PICO_MAX = 10.0, 5.0, 3.0`, ficha
# DEBT-PSI-UMBRALES-SIN-CALIBRAR). Alli 10.0 sostenido 5 min clasifica un
# COLAPSO; aqui se usa el mismo corte para la pregunta mas conservadora de si
# ANADIR un abanico, que no necesita esperar a que el colapso se sostenga.
#
# Lo que NO se consume, a proposito: MemAvailable. Es la senal que MINTIO --
# marco 56 % de 124 GiB durante las 17 h 45 min en que todas las tareas de la
# caja estaban estancadas el 99 % del tiempo, y es la razon por la que
# earlyoom disparo una sola vez en toda la noche. Poner una guarda sobre ella
# daria una sensacion de freno donde ya se midio que no lo hay.
PSI_FULL_AVG10_VETO = 10.0
_PSI_DEFAULT_PATH = "/proc/pressure/memory"


class UnifiedMemoryPressure(RuntimeError):
    """La caja ya esta estancada pidiendo memoria: no se admite mas abanico.

    Se LANZA en vez de degradar a un slot, y esa asimetria es deliberada. Que
    el contador este lleno significa que hay trabajo legitimo en marcha y
    esperar un poco lo resuelve. Que PSI full este por encima del corte
    significa que la maquina ya no sirve, y anadir un hijo mas que inicializa
    CUDA es exactamente el movimiento que la tiro las dos veces. Negarse a
    arrancar es la unica palanca que existe aqui (H34: el controlador cgroup
    `dmem` esta presente en estructura y el driver 580.173.02 no lo rellena).
    """

# A holder older than this is treated as dead even if its pid is alive, which
# covers pid reuse: the kernel can hand a recycled pid to an unrelated process
# and liveness alone would then keep a dead holder's slots forever. Two hours
# is above the longest full-suite run measured on this box (~200 s for the
# pre-push suite in Atlas) by a wide margin, so it never reclaims from a run
# that is genuinely still going.
MAX_HOLDER_AGE_S = 7200.0

_DEFAULT_TIMEOUT_S = 900.0
_DEFAULT_POLL_S = 2.0

# Cuanto se espera a que la presion baje antes de negarse. Sale de la misma
# calibracion que el corte: SOSTENIDO = 5 min es la duracion que separa un
# pico sano de un colapso (bin/bb:1108 en blackbox; PICO_MAX = 3 min es sano,
# >= 5 min es COLAPSO). Si la presion no ha bajado en ese plazo, por la propia
# medicion de esta maquina ya no es un pico: es lo otro, y entonces no se
# espera mas, se rechaza.
PSI_WAIT_S = 300.0


def _state_dir() -> Path:
    override = os.environ.get(STATE_ENV)
    if override:
        return Path(override)
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if runtime and Path(runtime).is_dir():
        return Path(runtime) / "simplecode"
    # No XDG_RUNTIME_DIR (cron, a bare ssh session, a container). /tmp is not
    # as good -- it survives a reboot -- which is exactly why the age ceiling
    # above is not optional.
    return Path("/tmp") / f"simplecode-slots-{os.getuid()}"


def ceiling() -> int:
    """The global ceiling, raisable or lowerable via the environment.

    A value that is not an integer >= 1 is reported to stderr and ignored,
    never silently half-applied -- the fallback is the declared ceiling, never
    an uncapped one.
    """
    raw = os.environ.get(CEILING_ENV)
    if raw is None or not raw.strip():
        return UNIFIED_MEMORY_SLOT_CEILING
    try:
        value = int(raw)
    except ValueError:
        print(
            f"[unified-slots] {CEILING_ENV}={raw!r} is not an integer; "
            f"using the declared ceiling {UNIFIED_MEMORY_SLOT_CEILING}",
            file=sys.stderr,
        )
        return UNIFIED_MEMORY_SLOT_CEILING
    if value < 1:
        print(
            f"[unified-slots] {CEILING_ENV}={value} is below 1; "
            f"using the declared ceiling {UNIFIED_MEMORY_SLOT_CEILING}",
            file=sys.stderr,
        )
        return UNIFIED_MEMORY_SLOT_CEILING
    return value


def psi_full_avg10(path: str | None = None) -> float | None:
    """`full avg10` de /proc/pressure/memory, o None si no se puede leer.

    None es "no se pudo medir", nunca 0.0: un kernel sin PSI y una caja en
    calma son cosas distintas, y devolver 0.0 para la primera convertiria un
    instrumento ausente en un veredicto de "todo bien".
    """
    raw_path = path or os.environ.get(PSI_PATH_ENV) or _PSI_DEFAULT_PATH
    try:
        text = Path(raw_path).read_text(encoding="utf-8")
    except OSError:
        return None
    for line in text.splitlines():
        if not line.startswith("full "):
            continue
        for field in line.split():
            if field.startswith("avg10="):
                try:
                    return float(field.split("=", 1)[1])
                except ValueError:
                    return None
    return None


def psi_veto_threshold() -> float | None:
    """El corte, o None cuando el veto esta apagado (`SIMPLECODE_UNIFIED_PSI_VETO=off`)."""
    raw = os.environ.get(PSI_ENV)
    if raw is None or not raw.strip():
        return PSI_FULL_AVG10_VETO
    if raw.strip().lower() in {"off", "0", "none", "false"}:
        return None
    try:
        return float(raw)
    except ValueError:
        print(
            f"[unified-slots] {PSI_ENV}={raw!r} is not a number nor 'off'; "
            f"using the calibrated cut {PSI_FULL_AVG10_VETO}",
            file=sys.stderr,
        )
        return PSI_FULL_AVG10_VETO


def pressure_veto() -> str | None:
    """Motivo por el que NO se debe admitir mas abanico, o None si se puede."""
    threshold = psi_veto_threshold()
    if threshold is None:
        return None
    avg10 = psi_full_avg10()
    if avg10 is None:
        # Sin PSI no se inventa un veredicto: se deja pasar y el contador de
        # cuenta sigue siendo el freno. Decirlo aqui seria ruido por corrida;
        # `main()` lo imprime cuando alguien pregunta por el estado.
        return None
    if avg10 >= threshold:
        return (
            f"PSI memory full avg10={avg10:.2f} >= {threshold:.2f} (corte calibrado "
            f"contra los congelamientos del 2026-09-22/23): la caja ya esta estancada "
            f"pidiendo memoria, y un hijo mas con CUDA es lo que la tiro las dos veces"
        )
    return None


def _alive(pid: int) -> bool:
    """Whether `pid` names a live process.

    PermissionError means the pid exists and belongs to someone else, which is
    still alive -- reading it as dead would let this process reclaim slots a
    real holder is using.
    """
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError as exc:  # pragma: no cover -- defensive; no input reaches it
        return exc.errno != errno.ESRCH
    return True


@contextmanager
def _locked(state_dir: Path, *, deadline: float | None = None, poll: float = _DEFAULT_POLL_S):
    state_dir.mkdir(parents=True, exist_ok=True)
    lock_path = state_dir / "unified_slots.lock"
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        if deadline is None:
            fcntl.flock(fd, fcntl.LOCK_EX)
        else:
            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise TimeoutError(
                            "unified-memory admission timed out waiting for its shared ledger lock"
                        ) from None
                    time.sleep(min(poll, remaining))  # blocking-sleep: lock polling shares admission deadline -- DEBT-UNIFIED-SLOTS-LOCK-DEADLINE-20261002  # sunset-reviewed: 9.7 -- flock no ofrece notificacion de desbloqueo portable
        yield state_dir / "unified_slots.json"
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _read(path: Path) -> dict[str, dict]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        # A truncated or absent file is an empty ledger, never an error: the
        # failure mode of raising here would be a fan-out that cannot start.
        return {}
    return raw if isinstance(raw, dict) else {}


def _purge(holders: dict[str, dict], now: float) -> dict[str, dict]:
    live = {}
    for token, entry in holders.items():
        if not isinstance(entry, dict):
            continue
        try:
            pid = int(entry["pid"])
            slots = int(entry["n"])
            ts = float(entry["ts"])
        except (KeyError, TypeError, ValueError):
            continue
        if slots < 1:
            continue
        if now - ts > MAX_HOLDER_AGE_S:
            continue
        if not _alive(pid):
            continue
        live[token] = {"pid": pid, "n": slots, "ts": ts}
    return live


def _used(holders: dict[str, dict]) -> int:
    return sum(int(e["n"]) for e in holders.values())


def _try_take(path: Path, token: str, want: int, cap: int) -> int:
    """Claim up to `want` slots under `cap`. Returns how many were granted."""
    now = time.time()
    holders = _purge(_read(path), now)
    free = cap - _used(holders)
    granted = max(0, min(want, free))
    if granted:
        holders[token] = {"pid": os.getpid(), "n": granted, "ts": now}
    _write(path, holders)
    return granted


def _write(path: Path, holders: dict[str, dict]) -> None:
    atomic_io.write_text_durable(path, json.dumps(holders), encoding="utf-8")


def _release(path: Path, token: str) -> None:
    holders = _purge(_read(path), time.time())
    holders.pop(token, None)
    _write(path, holders)


def in_use() -> int:
    """Slots currently held machine-wide, after purging dead holders."""
    state_dir = _state_dir()
    with _locked(state_dir) as path:
        return _used(_purge(_read(path), time.time()))


def _wait_for_pressure(deadline: float, poll: float, announce: bool) -> None:
    """Bloquea mientras la caja este estancada pidiendo memoria.

    Vuelve cuando la presion baja; lanza `UnifiedMemoryPressure` si no baja en
    el plazo monotónico absoluto. Ese plazo sale de SOSTENIDO (300 s) acotado
    por el presupuesto restante de quien llama: un `timeout=5` que tardara 300 s
    es una sorpresa, y colgo una corrida de mutantes durante horas el
    2026-09-23 antes de que nadie lo notara.
    """
    desde: float | None = None
    while True:
        motivo = pressure_veto()
        if motivo is None:
            return
        ahora = time.monotonic()
        if desde is None:
            desde = ahora
            if announce:
                print(
                    f"[unified-slots] esperando a que baje la presion antes de "
                    f"admitir abanico -- {motivo}",
                    file=sys.stderr,
                )
        if ahora >= deadline:
            raise UnifiedMemoryPressure(
                f"{motivo}. Se agoto el plazo de observacion tras {ahora - desde:.0f}s "
                f"sin bajar. No se admite mas abanico: espera a "
                f"que la caja se libere, o fuerza con {PSI_ENV}=off si sabes lo que haces."
            )
        time.sleep(max(0.0, min(poll, deadline - time.monotonic())))  # blocking-sleep: sondeo de recuperacion avg10 acotado al plazo -- DEBT-UNIFIED-SLOTS-DEADLINE-20261002  # sunset-reviewed: 9.7 -- las alertas PSI de stalls no notifican esta condicion de recuperacion


@contextmanager
def unified_memory_slots(
    want: int,
    *,
    cap: int | None = None,
    timeout: float = _DEFAULT_TIMEOUT_S,
    poll: float = _DEFAULT_POLL_S,
    announce: bool = True,
) -> Iterator[int]:
    """Hold up to `want` global slots for the duration of the block.

    Yields how many were granted, which is always >= 1 and may be less than
    `want`. The caller is expected to USE the yielded number as its worker
    count -- that is the whole point: a second coder gets a smaller fan-out
    instead of a fan-out that ignores the first one.
    """
    if want < 1:
        yield 0
        return

    cap = ceiling() if cap is None else cap
    token = uuid.uuid4().hex
    state_dir = _state_dir()
    deadline = time.monotonic() + timeout
    granted = 0
    waited = False

    try:
        while True:
            # La senal antes que la cuenta. Que queden slots libres no
            # autoriza nada si la caja ya esta estancada: el contador mide
            # cuanto abanico declaramos, PSI mide si la maquina sirve.
            _wait_for_pressure(min(deadline, time.monotonic() + PSI_WAIT_S), poll, announce)

            with _locked(state_dir, deadline=deadline, poll=poll) as path:
                granted = _try_take(path, token, want, cap)
            if granted:
                break
            if time.monotonic() >= deadline:
                # Degrade, never deadlock. See LIMITS in the module docstring:
                # this can overshoot `cap` by one per waiter, and that is the
                # declared price of never hanging a fan-out forever.
                with _locked(state_dir, deadline=deadline, poll=poll) as path:
                    granted = _try_take(path, token, 1, cap + 1)
                granted = granted or 1
                print(
                    f"[unified-slots] waited {timeout:.0f}s for a slot and gave up; "
                    f"proceeding with 1 (ceiling {cap} may be exceeded by 1). "
                    f"Something is holding slots for a long time: check "
                    f"`python -m simplecode.utils.unified_memory_slots`.",
                    file=sys.stderr,
                )
                break
            if not waited:
                waited = True
                if announce:
                    print(
                        f"[unified-slots] {cap} slots all held machine-wide; waiting "
                        f"for room instead of adding to the fan-out "
                        f"(this is what keeps N coders from summing past the cliff).",
                        file=sys.stderr,
                    )
            time.sleep(max(0.0, min(poll, deadline - time.monotonic())))  # blocking-sleep: sondeo entre procesos acotado al plazo -- DEBT-UNIFIED-SLOTS-DEADLINE-20261002  # sunset-reviewed: 9.7 -- el ledger compartido no tiene canal de notificacion

        if announce and granted < want:
            print(
                f"[unified-slots] granted {granted} of {want} requested "
                f"(ceiling {cap}, others hold {cap - granted if granted <= cap else 0})",
                file=sys.stderr,
            )
        yield granted
    finally:
        if granted:
            with _locked(state_dir) as path:
                _release(path, token)


def main(argv: list[str] | None = None) -> int:
    """Print who holds slots right now. Read-only."""
    state_dir = _state_dir()
    with _locked(state_dir) as path:
        holders = _purge(_read(path), time.time())
        _write(path, holders)
    cap = ceiling()
    used = _used(holders)
    print(f"[unified-slots] {used}/{cap} held  ({state_dir})")
    avg10 = psi_full_avg10()
    umbral = psi_veto_threshold()
    if umbral is None:
        print(f"  PSI: veto APAGADO por {PSI_ENV} -- solo frena la cuenta")
    elif avg10 is None:
        print(f"  PSI: NO SE PUDO MEDIR ({_PSI_DEFAULT_PATH}); el veto por senal no puede actuar")
    else:
        estado = "VETA" if avg10 >= umbral else "admite"
        print(f"  PSI full avg10={avg10:.2f}  corte={umbral:.2f}  -> {estado}")
    for token, entry in sorted(holders.items(), key=lambda kv: kv[1]["ts"]):
        age = time.time() - entry["ts"]
        print(f"  pid={entry['pid']:<8} slots={entry['n']:<3} age={age:6.0f}s  {token[:8]}")
    if not holders:
        print("  (nobody -- 0 is a measured 0: dead holders were purged just now)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
