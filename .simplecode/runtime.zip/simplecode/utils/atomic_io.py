import hashlib
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def fsync_dir(dir_path: Path) -> None:
    """Flush directory metadata to disk for crash resilience."""
    if not dir_path.is_dir():
        return
    try:
        flags = os.O_RDONLY
        if hasattr(os, "O_DIRECTORY"):
            flags |= os.O_DIRECTORY
        dir_fd = os.open(str(dir_path), flags)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except (OSError, ValueError) as exc:
        logger.debug("fsync_dir failed on %s: %s", dir_path, exc)


class WriteVerificationError(OSError):
    """Raised when written file hash does not match expected payload hash."""


def backup_path_for(path: Path) -> Path:
    """Return the sidecar backup path (`<path>.bak`) for a target file."""
    return path.with_name(path.name + ".bak")


def write_bytes_durable(path: Path, content: bytes, backup: bool = False) -> Path:
    """Atomically replace a file and verify the persisted bytes.

    Durability contract:
      - New bytes are written to a temp file in the target directory, flushed
        and ``fsync``-ed, then ``os.replace``-d over the target (atomic rename),
        after which the directory entry is ``fsync``-ed and the persisted bytes
        are re-hashed (sha256) to prove they match ``content``.
      - ``backup=False`` (default): behavior is identical to the pre-backup
        version -- every existing caller is byte-for-byte unchanged, and no
        ``.bak`` is ever produced.
      - ``backup=True`` AND the target already exists: the CURRENT (prior)
        contents are durably copied to ``<path>.bak`` (its own temp +
        ``fsync`` + rename, via a nested durable write) BEFORE ``os.replace``
        destroys them. A crash mid-replace therefore leaves a recoverable
        ``.bak`` holding the last-known-good file. If the target does not yet
        exist there is nothing to preserve and no ``.bak`` is written.

    The backup is taken before the replace precisely so the prior content is
    never the only copy in flight when the rename lands.
    """
    path = path.resolve()
    target_dir = path.parent
    target_dir.mkdir(parents=True, exist_ok=True)

    expected_hash = hashlib.sha256(content).hexdigest()

    if backup and path.is_file():
        # Durably preserve the prior contents before os.replace overwrites them.
        # Nested backup=False keeps this bounded (a .bak is never itself backed up).
        prior = path.read_bytes()
        write_bytes_durable(backup_path_for(path), prior, backup=False)

    prefix = f".tmp_{path.stem}_"
    suffix = path.suffix or ".tmp"

    fd, tmp_path_str = tempfile.mkstemp(prefix=prefix, suffix=suffix, dir=str(target_dir))
    tmp_path = Path(tmp_path_str)

    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp_path, path)
        fsync_dir(target_dir)

        # Post-write cryptographic verification (CC-42 & CC-56)
        written_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        if written_hash != expected_hash:
            raise WriteVerificationError(
                f"Cryptographic post-write verification failed for {path}. Expected {expected_hash}, got {written_hash}."
            )

        return path
    except (OSError, ValueError):
        tmp_path.unlink(missing_ok=True)
        raise


def write_text_durable(path: Path, content: str, encoding: str = "utf-8", backup: bool = False) -> Path:
    """Atomically replace a text file and verify the persisted bytes.

    See :func:`write_bytes_durable` for the durability and ``backup`` contract;
    ``backup=True`` durably preserves the prior file at ``<path>.bak`` before
    the replace. Default ``backup=False`` leaves every existing caller unchanged.
    """
    return write_bytes_durable(path, content.encode(encoding), backup=backup)


def restore_from_backup(path: Path) -> bool:
    """Durably restore ``path`` from its ``<path>.bak`` sidecar, if one exists.

    Returns True when a backup was found and restored (durably, over the target),
    False when no ``.bak`` exists. Used to roll back a write whose result was
    rejected (e.g. a refused malformed structured-file edit).
    """
    path = path.resolve()
    bak = backup_path_for(path)
    if not bak.is_file():
        return False
    write_bytes_durable(path, bak.read_bytes(), backup=False)
    return True


def append_jsonl(path: Path, record: dict[str, Any] | list[Any]) -> None:
    """Append a single JSON record to a JSONL file with partial-write protection and fsync."""
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)

    line = json.dumps(record, ensure_ascii=False) + "\n"
    data = line.encode("utf-8")

    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
    mode = 0o666
    fd = os.open(str(path), flags, mode)
    try:
        total_written = 0
        while total_written < len(data):
            written = os.write(fd, data[total_written:])
            if written == 0:
                raise OSError(f"Zero bytes written appending to {path}")
            total_written += written
        os.fsync(fd)
    finally:
        os.close(fd)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Read a JSONL file safely, recovering all valid records even if individual lines are corrupt."""
    if not path.is_file():
        return []
    records: list[dict[str, Any]] = []
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        logger.debug("Failed reading JSONL file %s: %s", path, exc)
        return []

    for line_no, line in enumerate(content.splitlines(), start=1):
        line_str = line.strip()
        if not line_str:
            continue
        try:
            parsed = json.loads(line_str)
            if isinstance(parsed, dict):
                records.append(parsed)
        except json.JSONDecodeError as exc:
            logger.debug("Skipping corrupted JSON line %d in %s: %s", line_no, path, exc)
    return records
