# -*- coding: utf-8 -*-
"""detach.py -- launch a command that outlives this process's own siblings.

`nohup <cmd> & disown` inside a shell script keeps the child in the SAME
process group as the script: verified live (2026-09-15) that bash without
job control does not call `setpgid` on a backgrounded job, so `disown` only
stops the shell from sending it SIGHUP on exit, it never moves the process
to a different group. Anything that later waits on that group -- gate_runner's
process-tree drain, DEBT-GATE-RUNNER-PREK-ORPHAN-TELEMETRY-RACE -- would
then wait for it too, defeating the entire point of running it in the
background (the `observe` and `growth-ratchet` pre-push hooks, SPEC-L133,
measured saving ~13s per push by not waiting on bandit+vulture).

A real new session (`start_new_session=True`, i.e. `setsid()`) puts the
child in a brand new process group, invisible to any group-based wait on
the launcher's own group -- the same mechanism
`red_team._spawn_hardening_drafting_detached` already used correctly for
its own drafting child. This module is that mechanism, factored out so the
shell-based background hooks can reuse it instead of the shell idiom that
does not actually detach.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def launch_detached(command: list[str], log_path: Path) -> None:
    """Start `command` in a new session, appending its combined output to
    `log_path`. Returns as soon as the process is started -- never waits for
    it, by design."""
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "ab") as log_file:
        subprocess.Popen(
            command, stdout=log_file, stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL, start_new_session=True,
        )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a command is required after --")
    launch_detached(command, args.log)
    print(f"[detach] launched in background -- see {args.log}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
