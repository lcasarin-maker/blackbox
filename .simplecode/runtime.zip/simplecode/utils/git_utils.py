# -*- coding: utf-8 -*-
"""Consolidated, safe, and fast Git operations for simplecode tools and guards."""
from __future__ import annotations

import subprocess
from pathlib import Path


def run_git(args: list[str], root: Path | None = None) -> tuple[int, bytes, bytes]:
    """Execute a git command securely, returning (returncode, stdout_bytes, stderr_bytes)."""
    cwd = str(root.resolve()) if root else str(Path.cwd())
    try:
        res = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            check=False,
        )
        raw_stdout = getattr(res, "stdout", b"")
        raw_stderr = getattr(res, "stderr", b"")
        stdout = raw_stdout if isinstance(raw_stdout, bytes) else str(raw_stdout).encode("utf-8", "surrogateescape")
        stderr = raw_stderr if isinstance(raw_stderr, bytes) else str(raw_stderr).encode("utf-8", "surrogateescape")
        return res.returncode, stdout, stderr
    except (OSError, subprocess.SubprocessError):
        return 1, b"", b"git_subprocess_error"


def hooks_dir(root: Path) -> Path | None:
    """Resolve the repository's shared hooks directory, including linked worktrees.

    `root / ".git"` is a directory for a main checkout but a gitdir-pointer FILE
    for a `git worktree add` linked worktree (it reads `gitdir: <main>/.git/
    worktrees/<name>`), so `(root / ".git" / "hooks").is_dir()` is unconditionally
    False there even though the worktree is real and hooks ARE installable --
    git shares one hooks directory, `$GIT_COMMON_DIR/hooks`, across the main
    checkout and every one of its worktrees. Falls back to `git rev-parse
    --git-common-dir` to resolve it for that case; same logic already proven in
    `simplecode.worktree.hook_suspension._hooks_dir`.
    """
    direct = root / ".git" / "hooks"
    if direct.is_dir():
        return direct
    rc, stdout, _ = run_git(["rev-parse", "--path-format=absolute", "--git-common-dir"], root)
    if rc != 0:
        return None
    common = Path(stdout.decode("utf-8", "surrogateescape").strip())
    hooks = common / "hooks"
    return hooks if hooks.is_dir() else None


def repo_toplevel(root: Path | None = None) -> Path | None:
    """The working-tree root of the repository containing `root` (or the cwd).

    None when `root` is not inside a git working tree. Callers that turn git's
    root-relative paths back into files anchor them here, never on the cwd.
    """
    rc, stdout, _ = run_git(["rev-parse", "--show-toplevel"], root)
    if rc != 0:
        return None
    return Path(stdout.decode("utf-8", "surrogateescape").strip())


def git_diff_name_only(root: Path | None = None, cached: bool = False) -> list[str]:
    """Changed file paths, always relative to the repository ROOT.

    DEBT-GIT-PATHS-NOT-ANCHORED-TO-ROOT: with `git config diff.relative true`,
    `git diff --name-only` run from a subdirectory lists only that subdirectory's
    changes, relative to it -- a gate fed that list reviews a subset of the commit,
    or nothing, and says OK. `--no-relative` overrides the config, and running at
    the toplevel makes the answer independent of whatever `root`/cwd the caller has.
    """
    args = ["diff", "--no-relative", "--name-only", "-z"]
    if cached:
        args.insert(1, "--cached")
    rc, stdout, _ = run_git(args, repo_toplevel(root) or root)
    if rc != 0:
        return []
    return [
        b.decode("utf-8", "surrogateescape")
        for b in stdout.split(b"\0")
        if b.strip()
    ]


def git_status_paths(root: Path | None = None) -> list[str]:
    """Every path `git status` reports as changed: staged, unstaged, AND
    untracked -- the full working-tree picture `git diff` alone cannot give,
    since a modified-vs-index path with no unstaged change never shows there.

    DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP (Twiner, item d): a SessionStart
    summary of "N archivos modificados ajenos" needs this broader set, not
    just what a commit would introduce (that scope belongs to `claim_guard`'s
    pre-commit check, which stays staged-only on purpose).
    """
    rc, stdout, _ = run_git(["status", "--porcelain=v1", "--untracked-files=all", "-z"], root)
    if rc != 0:
        return []
    # Porcelain v1 -z: each entry is "XY path", NUL-terminated. A rename or
    # copy (X or Y == 'R'/'C') is the ONE shape with an extra bare token right
    # after it -- the origin path, with no "XY " prefix at all -- so it must
    # be consumed and skipped explicitly, or it would be misread as its own
    # unprefixed changed path.
    tokens = [t.decode("utf-8", "surrogateescape") for t in stdout.split(b"\0") if t]
    paths = []
    i = 0
    while i < len(tokens):
        entry = tokens[i]
        if len(entry) > 3 and entry[2] == " ":
            paths.append(entry[3:])
            if entry[0] in "RC" or entry[1] in "RC":
                i += 1  # skip the bare origin-path token that follows
        i += 1
    return paths


def git_is_tracked(rel_path: str | Path, root: Path | None = None) -> bool:
    """Whether `rel_path` (relative to `root`) is currently tracked in git's index.

    `ls-files --error-unmatch` exits non-zero for a pathspec that matches no
    tracked file -- including when `root` is not a git repository at all, which
    this treats the same as "not tracked" rather than raising, since callers
    use it to decide whether an untrack is needed, not to assert a repo exists.
    """
    rel = Path(rel_path).as_posix()
    rc, _, _ = run_git(["ls-files", "--error-unmatch", "--", rel], root)
    return rc == 0


def git_divergent_staged_files(root: Path | None = None) -> list[str]:
    """Find files that are staged in the index but also have unstaged modifications in the working tree."""
    wt_files = set(git_diff_name_only(root, cached=False))
    cached_files = set(git_diff_name_only(root, cached=True))
    return sorted(wt_files & cached_files)


def git_ls_files(root: Path | None = None, valid_exts: set[str] | None = None) -> list[Path]:
    """List tracked repository files, optionally filtered by file extensions."""
    base_root = (root or Path.cwd()).resolve()
    rc, stdout, _ = run_git(["ls-files", "-z"], base_root)
    files: list[Path] = []
    if rc == 0:
        for b in stdout.split(b"\0"):
            if b.strip():
                rel = b.decode("utf-8", "surrogateescape")
                p = base_root / rel
                if valid_exts is None or p.suffix.lower() in valid_exts:
                    if p.is_file():
                        files.append(p)
    if not files and valid_exts:
        # Fallback to rglob if not a git repository or git failed
        for ext in valid_exts:
            files.extend(base_root.rglob(f"*{ext}"))
    return sorted(files)


def git_committed_files(ref: str = "HEAD", root: Path | None = None) -> list[str]:
    """Paths a single commit actually changed (added, modified, or deleted).

    DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP (OWNS law, second half): "si ya lo
    cometiste, avisa al dueno" needs to know what THAT commit touched, not
    the working tree's current state (which `git_status_paths`/
    `git_diff_name_only` answer, and which has already moved on by the time
    a post-commit hook runs).
    """
    # `--root`: without it, `diff-tree` on a commit with NO parent (the
    # repo's very first commit) silently reports nothing, since there is no
    # parent tree to diff against -- `--root` diffs a root commit against
    # the empty tree instead, so its own files count as "changed" too.
    rc, stdout, _ = run_git(["diff-tree", "--no-commit-id", "--name-only", "-r", "--root", "-z", ref], root)
    if rc != 0:
        return []
    return [b.decode("utf-8", "surrogateescape") for b in stdout.split(b"\0") if b]


def git_show_blob(rel_path: str | Path, ref: str = "HEAD", root: Path | None = None) -> str | None:
    """Retrieve the text content of a file at a specific git ref (e.g. HEAD, :0)."""
    rel = Path(rel_path).as_posix().lstrip("/")
    locator = f"{ref}:{rel}" if not ref.startswith(":") else f"{ref}{rel}"
    rc, stdout, _ = run_git(["show", locator], root)
    if rc != 0:
        return None
    try:
        return stdout.decode("utf-8")
    except UnicodeDecodeError:
        return stdout.decode("utf-8", "replace")
