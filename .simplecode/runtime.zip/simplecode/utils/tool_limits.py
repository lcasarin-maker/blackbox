# -*- coding: utf-8 -*-
"""tool_limits.py -- Single source of truth for fixed tool limits (GS2-210).

Every timeout, ceiling, or endpoint that is a deliberate fixed choice lives
here under a name that states what it bounds. A literal timeout anywhere else
in ``src/`` is a GS2-210 conviction: fixed limits are only honest when they
are declared as such, in one place, instead of scattered as anonymous magic
numbers -- or worse, fed through a "dynamic" formula with a fabricated input.

Calls whose cost genuinely scales with a payload measurable *before* the call
must not use these constants; they compute a proportional timeout via
``dynamic_resolution.compute_proportional_timeout`` with the real byte count.
"""
from __future__ import annotations

import os
import sys

from simplecode.utils.dynamic_resolution import compute_proportional_timeout

__all__ = [
    "QUARANTINE_COMPARE_MAX_BYTES",
    "QUARANTINE_PATCH_MAX_BYTES",
    "GIT_O1_TIMEOUT",
    "GIT_SCAN_TIMEOUT",
    "NETWORK_TIMEOUT",
    "HTTP_FETCH_TIMEOUT",
    "SMOKE_SUITE_TIMEOUT",
    "VERSION_PROBE_TIMEOUT",
    "DIFF_TIMEOUT_BASE",
    "TASK_VERIFICATION_CMD_TIMEOUT",
    "PYPI_BASE_URL",
    "HARVEST_SOURCE_FILE_MAX_BYTES",
    "ARTIFACT_BUILD_TIMEOUT",
    "ARTIFACT_INSTALL_TIMEOUT",
    "GATE_DRAIN_WARN_AFTER",
    "GATE_DRAIN_HARD_TIMEOUT",
    "RETROACTIVE_GATE_TIMEOUT",
    "WORKERS_ENV",
    "UNIFIED_MEMORY_WORKER_CAP",
    "xdist_workers",
    "compute_proportional_timeout",
]

# O(1) git plumbing: rev-parse, config lookups, signature checks, numstat of
# an already-indexed diff. Output is bounded; ten seconds only trips on a
# hung process, never on volume.
GIT_O1_TIMEOUT = 10.0

# Repo-wide git enumeration (ls-files and friends) whose cost tracks tracked
# file count but cannot be measured before the call without making the call.
GIT_SCAN_TIMEOUT = 15.0

# Local subprocesses that talk to the network (pip list --outdated). The
# response size is unknowable before the response arrives, so a fixed wall
# is the honest bound.
NETWORK_TIMEOUT = 30.0

# Direct HTTP metadata fetches (one JSON document per request).
HTTP_FETCH_TIMEOUT = 10.0

# The isolated dist smoke suite is bounded by design (unittest discover over
# the packaged tests, no coverage, no plugins).
SMOKE_SUITE_TIMEOUT = 30.0

# `<python> -m pytest --version` probes: interpreter startup plus import of
# pytest, no collection.
VERSION_PROBE_TIMEOUT = 30.0

# Base handshake latency for staged-diff subprocesses; callers add the
# proportional component from the measured staged byte count via
# compute_proportional_timeout(payload, base_timeout_sec=DIFF_TIMEOUT_BASE).
DIFF_TIMEOUT_BASE = 5.0

# A closed task's declared verification_command (typically a scoped pytest
# node or a single gate invocation) runs as a bounded local subprocess whose
# cost is fixed by design -- a whole-suite command is rejected upstream by
# contract validation, so this wall only trips on a genuinely hung process.
TASK_VERIFICATION_CMD_TIMEOUT = 30.0

# Canonical package index. Fixed because it IS the canonical endpoint; the
# environment override exists for mirrors and air-gapped registries, not to
# pretend the default is computed.
PYPI_BASE_URL = os.environ.get("SIMPLECODE_PYPI_BASE_URL", "https://pypi.org")

# Ceiling on a single transcript/archive source file read whole into memory by
# the universal harvester and transcript acquisition (W1D audit, Axiom 10).
# Measured: the largest real Claude session transcript found under
# ~/.claude/projects during the W1D measurement pass was 211,065,334 bytes
# (~201 MiB, cb8b9e23-6960-42fb-89db-0f980bda1837.jsonl; reproduce with
# `find ~/.claude/projects -iname '*.jsonl' -printf '%s %p\n' | sort -rn | head`).
# 512 MiB gives >2x headroom over that measured max while still bounding a
# pathological/mis-globbed file (e.g. a multi-GB embeddings dump) from being
# read whole; oversize files are skipped loudly and counted, never silently
# truncated.
HARVEST_SOURCE_FILE_MAX_BYTES = 512 * 1024 * 1024

# `python -m build --outdir` for this package, measured 2026-08-25: 1.99s wall
# (setuptools reading ~120 tracked modules, no compiled extensions). 60s gives
# >30x headroom -- this only trips on a genuinely hung build, not volume.
ARTIFACT_BUILD_TIMEOUT = 60.0

# Ceilings for the upstream quarantine stage (ADR-0010). The GitHub compare
# API itself caps files at 300 and elides very large patches, so a normal
# review payload is well under a megabyte; these caps only bound the
# pathological case (a giant vendored blob rewritten upstream) from being
# written whole into `.simplecode/quarantine/`. Oversize is reported loudly
# in the digest, never silently truncated into looking complete.
QUARANTINE_COMPARE_MAX_BYTES = 8 * 1024 * 1024
QUARANTINE_PATCH_MAX_BYTES = 256 * 1024

# `pip install <built artifact>` into a fresh venv, then `pip check`, measured
# 2026-08-25: venv creation 1.29s + install 1.41s + check 0.15s wall with this
# package's 2 declared dependencies (pre-commit, PyYAML) warm in pip's cache.
# 120s gives generous headroom for a cold cache or a slower mirror without
# masking a genuinely hung resolver.
ARTIFACT_INSTALL_TIMEOUT = 120.0

# DEBT-GATE-RUNNER-PREK-ORPHAN-TELEMETRY-RACE (2026-09-15): prek (ADR-0009)
# dispatches pre-push hooks concurrently and can exit while one it spawned is
# still running -- a plain `subprocess.run` only waits for prek's own exit,
# not its children's, so the orphan kept writing telemetry.jsonl after the
# hook, and `git push`, had already returned (observed live: a
# `backlog_verifier --gate` process still alive 316s after the push attempt
# that started it had exited). gate_runner now waits for its wrapped
# command's whole process group to empty before returning. 30s is
# comfortably under the 197s measured wall time of the full 16-hook pre-push
# suite (hook_install.py's _PREFER_PREK, measured 2026-08-31) -- a
# legitimately slow suite should rarely trip this warning, and when it does
# the message is informational, not a failure.
GATE_DRAIN_WARN_AFTER = 30.0

# Hard ceiling on the same wait. A zombie (already exited, not yet reaped by
# its parent) answers the liveness probe the same as a running process until
# something reaps it, so a broken init/subreaper that never reaps could stall
# this forever with no ceiling. 600s is ~3x the measured 197s full-suite wall
# time: generous enough not to cut off a genuinely slow but legitimate run,
# bounded enough that a real hang gets reported instead of wedging every
# future `git push` in the repo.
GATE_DRAIN_HARD_TIMEOUT = 600.0

# Wall ceiling on ONE retroactive gate run (`hook_receipts --verify-historical`):
# the repo's own installed pre-commit launcher, executed against a historical
# commit's staged state reconstructed in a throwaway worktree. Measured
# 2026-09-17 in poe_systems against commit 372a904e, 13 hooks, all Passed:
#
#   $ cd <scratch worktree> && time /home/lcasarin/projects/poe_systems/.git/hooks/pre-commit
#   real 0m2.819s
#
# 1800s is ~640x that measurement, and still ~9x the 197s measured wall of the
# heaviest suite in the fleet (the full pre-push run, see GATE_DRAIN_WARN_AFTER
# above) -- a satellite that wires a heavy pre-commit suite must not be cut off
# mid-run, because a timeout here is a REFUSAL: the commit stays unverified and
# keeps blocking. Only a genuinely hung gate trips this.
RETROACTIVE_GATE_TIMEOUT = 1800.0

# Moved here from coverage_target.py (2026-09-21, DEBT-PUSH-LOOP-02 follow-up: parallelize
# backlog_verifier.audit_closed_tasks): both that module and backlog_verifier need the same
# knob for the same reason -- "how much of this box should simplecode's own parallel work use
# right now" -- and this file is the one both already import from, so a shared home beats
# either duplicating the ~15-line function or reaching into a sibling verification module for
# a private symbol. coverage_target.py keeps a back-compat re-export of both names.
#
# Measured live on this repo's own suite (2026-08-31): serial 156.4s -> parallel 58.1s/58.9s/
# 27.7s across several xdist worker counts (coverage_target's own phase-split fix; see that
# module for the full story). Re-measured 2026-09-08 on a 20-core machine: -n 4 -> 54.0s,
# -n 10 -> 45.6s, -n 20 -> 31.8s. Uncapped `os.cpu_count()` -- the same value `-n auto` would
# pick -- cut the dominant cost of the pre-push suite by ~41% over an old, unmeasured cap.
WORKERS_ENV = "SIMPLECODE_XDIST_WORKERS"

# Ceiling on the DEFAULT worker count (what an unset WORKERS_ENV resolves to). The speedup
# above is real and stays reachable -- WORKERS_ENV raises the count back up to cpu_count on a
# box with memory to spare. It is the *default* that had to change, because the fleet's only
# machine class is a GB10 box where GPU memory IS system memory, and there the uncapped
# default froze the machine three times:
#
#   2026-09-21  aequitas_os, 20 workers at 1.7-3.3 GB each past 37 GB: the kernel killed the
#               graphical session twice (recorded in xdist_workers' docstring at the time,
#               as a reason to set WORKERS_ENV by hand -- nothing made it the default).
#   2026-09-22 05:45  17h45m frozen, ended in a hard reset.
#   2026-09-22 23:49   5h55m frozen, ended in a hard reset.
#
# The last two were sampled minute by minute (~/.local/share/blackbox/samples/):
#
#   23:39   3 GPU processes  38.1 GiB  load 2.44  MemAvailable 63 GiB
#   23:45  10 GPU processes  45.2 GiB  load 19.2  MemAvailable 38 GiB
#   23:46  16 GPU processes  58.8 GiB  load 31.0  MemAvailable 20 GiB
#   23:49  23 GPU processes  -- PSI memory full 98.2%, load 177, frozen until the reset
#
# Each xdist worker that imports the backend initializes CUDA and takes ~1.15-1.25 GiB of
# unified memory on top of its 1.5-2.8 GiB RSS, and nothing counted them: the admission check
# on this box guards the inference gateway only. Past the cliff the machine does not come back
# on its own -- earlyoom killed the 33 GiB gateway at 05:51:40 and MemAvailable rose from 31
# to 44 GiB while PSI memory full stayed at 99% for six more hours. Prevention is the only
# lever; there is no recovery to fall back on.
#
# 6 is not a formula. A formula here would have to divide MemAvailable by a per-worker
# footprint, and MemAvailable is precisely the number that lied: it read 69 GiB of 124 GiB
# while every task on the box was stalled 99% of the time. 6 is the value already in hand-use
# on this machine (`SIMPLECODE_XDIST_WORKERS=6 git push`) across the runs that did NOT freeze
# it, and it sits below all three counts that did (16 crossed the cliff, 20 and 23 froze).
UNIFIED_MEMORY_WORKER_CAP = 6


def xdist_workers(env: dict[str, str] | None = None) -> int:
    """Workers for a parallel phase: UNIFIED_MEMORY_WORKER_CAP, raisable via SIMPLECODE_XDIST_WORKERS.

    The count measured above (`-n 20` at 31.8s) is right on a machine with memory to spare, and
    stays available: set the variable to ask for it. What changed (2026-09-23) is which value
    you get by NOT choosing. On a box with unified memory and a resident service each xdist
    worker loads the whole backend, and the uncapped default froze this machine three times --
    see UNIFIED_MEMORY_WORKER_CAP for the three measurements and why the cap is a declared
    number and not a formula over MemAvailable.

    The variable now raises as well as lowers, bounded by `os.cpu_count()` -- before
    2026-09-23 it only REDUCED, because the default was already the maximum. A value that is
    not an integer >= 1 is reported to stderr and ignored, never silently half-applied; the
    fallback is the capped default, never the uncapped core count.

    Both callers are bounded by this one number, and the second one is why. Until 2026-09-23
    this docstring argued that a caller whose "worker" is a lightweight thread around a single
    subprocess.run -- backlog_verifier's parallel task audit -- "does not carry the same memory
    argument for capping below cpu_count()". That reasoning is what let the hazard through, and
    the measurement contradicts it: each of those threads spawns a full pytest CHILD that
    imports the backend and initializes CUDA, so a thread pool of 20 is 20 whole test suites
    resident at once, not 20 cheap threads. On 2026-09-22 23:45 that audit had 10 GPU processes
    live; a minute later, 16; three minutes after that the box was frozen. A thread is cheap;
    what it starts is not.
    """
    cpus = os.cpu_count() or 1
    default = min(cpus, UNIFIED_MEMORY_WORKER_CAP)
    raw = (os.environ if env is None else env).get(WORKERS_ENV)
    if raw is None or not raw.strip():
        return default
    try:
        requested = int(raw)
    except ValueError:
        requested = 0
    if requested < 1:
        print(f"[xdist-workers] {WORKERS_ENV}={raw!r} is not an integer >= 1 -- ignored, "
              f"using {default} worker(s)", file=sys.stderr)
        return default
    return min(requested, cpus)
