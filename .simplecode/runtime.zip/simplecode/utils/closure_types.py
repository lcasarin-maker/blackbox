"""The closure types a ficha may declare, in ONE place.

Why this module exists
----------------------
Until 2026-09-23 this frozenset was written out twice -- in
`genuine_task_closure.py` (the gate that blocks the commit) and in
`harvest_decision.py` (the close_check a HARVEST ficha runs) -- with
`harvest_decision`'s docstring promising it was "the same enum
`genuine_task_closure.py` accepts". Two copies held together by a promise in a
docstring is how the two drift, and drift between a rule and its enforcement is
worse than either rule alone: measured the same day in blackbox, whose local
copy of a HARVEST close_check accepted `status: done` with no `closure_type`
while this repo's gate rejected the identical file.

A closure type is an explicit, on-the-record human claim, never something a
detector infers. That trust model is deliberate and predates this module: see
`genuine_task_closure`'s header on why byte-identical renames (`R100`) cannot
distinguish a real relocation from the Atlas fraud incident's own regression
test, and only a person declaring it with a `reason:` can.
"""

from __future__ import annotations

#: No work was owed: the ficha describes something that will not be fixed.
VOID_WONTFIX = "void_wontfix"

#: Another ficha already covers it.
DUPLICATE = "duplicate"

#: `status: done` and a real close_check were committed and verified in an
#: EARLIER, separate commit; this commit only corrects which `tasks/` subfolder
#: the ficha lives in. A filesystem tidy-up, not a new closure (2026-09-07).
RELOCATED_PRIOR_VERIFICATION = "relocated_prior_verification"

#: The ficha evaluated an ADOPTION, the adoption was implemented with real code
#: in an EARLIER, named commit, and this commit only records the closure.
#:
#: Added 2026-09-23 because the case arrived for real and nothing covered it.
#: `harvest_decision`'s own docstring had declared the gap and said it was "not
#: built for because it hasn't happened yet": a HARVEST ficha closed by a real
#: substantive code change. It happened. blackbox's
#: HARVEST-366436-lm-studio-models-overload-freezes-spark was adopted AND
#: implemented the same day (`bin/bb-usable`, 64d3daa), after two measured
#: freezes of 17 h 45 min and 5 h 55 min, and today it cannot be closed
#: correctly: `void_wontfix` and `duplicate` are both false (work WAS done, and
#: it is not a duplicate), and `relocated_prior_verification` does not fit
#: because the ficha is still `status: open` with an `accepted` block -- it was
#: never `done` in an earlier commit, which is that type's whole premise.
#:
#: The distinction from `relocated_prior_verification` is what was verified
#: earlier: there, the FICHA's own closure was; here, the CODE was, while the
#: ficha stayed open. `genuine_task_closure` sees the same shape in both -- a
#: rename into `tasks/done/` with no substantive change in this commit -- which
#: is exactly why the difference has to be declared and cannot be detected.
#:
#: The `reason:` is expected to NAME the commit that carried the code. That is
#: not enforced here, on purpose and consistently with the other three: this
#: enum's trust model is an explicit human claim, and a regex over prose would
#: buy the appearance of verification without the thing. What does check it is
#: a reader, and naming the commit is what gives that reader something to check.
ADOPTED_PRIOR_IMPLEMENTATION = "adopted_prior_implementation"

EXEMPT_CLOSURE_TYPES = frozenset({
    VOID_WONTFIX,
    DUPLICATE,
    RELOCATED_PRIOR_VERIFICATION,
    ADOPTED_PRIOR_IMPLEMENTATION,
})
