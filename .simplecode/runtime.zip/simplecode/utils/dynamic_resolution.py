# -*- coding: utf-8 -*-
"""dynamic_resolution.py -- Universal dynamic resource resolution & capacity adaptors.

Erradica el vicio del hardcoding (Rule GS2-210) proveyendo mecanismos estándar
para la resolución en tiempo de ejecución de:
  - Rutas de máquina relativas al repositorio (anti-DGX-194).
  - Concurrencia adaptativa y conteo seguro de workers.
  - Candidatos de puerto efímero resueltos por el sistema operativo.
  - Presupuesto elástico de tokens y headspace para LLMs (anti-LibreChat HTTP 400).
  - Timeouts proporcionales al volumen de datos.
"""
from __future__ import annotations

import os
import socket
import tempfile
from pathlib import Path
from typing import Optional


def get_repo_root(anchor: Optional[Path | str] = None) -> Path:
    """Resolve the git repository root dynamically without hardcoded machine paths.

    Args:
        anchor: Optional starting path or file. Defaults to caller directory or cwd.

    Returns:
        Path to the repository root directory.
    """
    if anchor is not None:
        start_path = Path(anchor).resolve()
        if start_path.is_file():
            start_path = start_path.parent
    else:
        start_path = Path.cwd().resolve()

    current = start_path
    while current != current.parent:
        if (current / ".git").exists() or (current / "pyproject.toml").is_file():
            return current
        current = current.parent

    # Fallback to starting directory
    return start_path


def get_safe_workers(max_cap: int = 8, reserve_cores: int = 1) -> int:
    """Calculate adaptive process/thread concurrency based on available host CPUs.

    Args:
        max_cap: Hard ceiling to prevent overloading shared development machines.
        reserve_cores: Number of cores to leave free for OS/system responsiveness.

    Returns:
        Safe integer worker count (minimum 1).
    """
    detected_cpus = os.cpu_count() or 1
    safe = max(1, detected_cpus - reserve_cores)
    return max(1, min(max_cap, safe))


def get_ephemeral_port(fallback_base: int = 49152) -> int:
    """Ask the OS for an ephemeral port number.

    If network sockets are prohibited by the sandbox environment (e.g. PermissionError),
    return a deterministic candidate in the ephemeral range. Callers that require an
    exclusive reservation must bind and retain their own socket because an integer
    port number cannot provide a collision-free reservation.

    Returns:
        Ephemeral TCP port candidate.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("", 0))
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            return int(sock.getsockname()[1])
    except (PermissionError, OSError):
        # Clamped fallback base within valid ephemeral port range [1024, 65500]
        base = max(1024, min(65500, fallback_base))
        span = 65535 - base + 1
        offset = (os.getpid() * 37) % span
        return base + offset


def compute_dynamic_headspace(
    prompt_tokens: int,
    max_context_window: int = 32768,
    min_floor: int = 500,
    max_ceiling: int = 4000,
    safety_margin: int = 500,
) -> int:
    """Compute elastic LLM output token budget to prevent context window overflow (HTTP 400).

    Formula:
        headspace = max(min_floor, min(max_ceiling, max_context_window - prompt_tokens - safety_margin))

    Args:
        prompt_tokens: Estimated or counted tokens in the prompt context.
        max_context_window: Physical window limit of the target model (e.g. 32768, 128000).
        min_floor: Guaranteed minimum response budget.
        max_ceiling: Upper bound to avoid unbounded generation costs.
        safety_margin: Headroom reserved for model metadata / reasoning token drift.

    Returns:
        Safe integer output tokens budget.
    """
    available = max_context_window - prompt_tokens - safety_margin
    clamped = min(max_ceiling, available)
    return max(min_floor, clamped)


def compute_proportional_timeout(
    payload_size_bytes: int,
    base_timeout_sec: float = 5.0,
    bytes_per_sec: float = 500_000.0,
    max_timeout_sec: float = 300.0,
) -> float:
    """Compute dynamic I/O timeout proportional to the payload data size.

    Args:
        payload_size_bytes: Size of the payload to transfer or process.
        base_timeout_sec: Base handshake / setup latency in seconds.
        bytes_per_sec: Expected transfer rate (default 500 KB/s conservative).
        max_timeout_sec: Hard ceiling in seconds.

    Returns:
        Calculated timeout in seconds.
    """
    transfer_time = max(0.0, payload_size_bytes / max(1.0, bytes_per_sec))
    total = base_timeout_sec + transfer_time
    return max(base_timeout_sec, min(max_timeout_sec, total))


def fresh_bytecode_env(base: Optional[dict] = None) -> dict:
    """An environment whose Python cannot be served STALE bytecode.

    Three sessions hit this in one day, 2026-09-05, in three repos: Atlas
    (committed as "el bytecode rancio en los controles"), simplecode (a
    truncation_guard test failing while its fix was already applied --
    `inspect.getsource` showed `- 3` while the loaded code object still held
    `- 4`), and descargaSAT (`tool_limits.py` reading 9 from a file that said
    8). None was caught by reading the code; each was caught by a control that
    disagreed with the file on disk.

    THE MECHANISM. CPython validates a cached `.pyc` against the source's
    mtime AND size. Restoring a file -- `git checkout -- f`, `cp backup f`,
    any mutate-measure-restore cycle -- can reproduce BOTH, and then a
    byte-different source is served from the old bytecode. Reproduced
    deterministically: write `VALUE = 9`, import it, rewrite as `VALUE = 8`
    (same length) with the original mtime restored, and a fresh interpreter
    still reports 9.

    THE TWO OBVIOUS REMEDIES DO NOT WORK, and both were proposed in good faith
    before being measured:

        control (stale)                    -> 9
        python -B                          -> 9   only stops WRITING a .pyc
        importlib.invalidate_caches()      -> 9   does not touch a stale .pyc
        rm -rf __pycache__                 -> 8   works
        PYTHONPYCACHEPREFIX=<fresh dir>    -> 8   works

    This returns `base` (default `os.environ`) plus `PYTHONPYCACHEPREFIX`
    pointing at a fresh temporary directory, which is the remedy that needs no
    write access to the tree being measured -- deleting `__pycache__` mutates
    the subject, and an instrument that edits its subject to measure it is the
    defect one rung down.

    The directory is deliberately NOT cleaned up here: it must outlive this
    call, since the subprocess that uses the env has not started yet. It lands
    under the OS temp dir and is reclaimed with it.

    Use it for any subprocess that measures code which some earlier step may
    have restored -- which is every negative control in this kit.
    """
    env = dict(os.environ if base is None else base)
    env["PYTHONPYCACHEPREFIX"] = tempfile.mkdtemp(prefix="simplecode-pyc-")
    return env
