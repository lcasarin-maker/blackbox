"""`simplecode push`: apply the due version bump, commit it, then `git push`.

A push carrying a feat/fix commit fails its pre-push version gate once, until someone runs
`version_bump --apply` and commits the result (DEBT-PUSH-LOOP-02: version-bump was red in 14 of 22
blocked attempts on this repo and the only red gate in 5). This does that step first, so the first
attempt does not fail for a reason known in advance. It changes no gate: a plain `git push` still
works, and the pre-push hook still judges everything.

Exit codes: 0 pushed; 2 COULD_NOT_RUN (dirty tree, or the bump commit failed); otherwise the exit
code of whichever step failed (a bump that cannot apply, e.g. the sunset audit of a minor, or
`git push` itself).
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from simplecode.verification import version_bump


def _git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, check=False)


def main(args: argparse.Namespace) -> int:
    root = Path.cwd()
    # Tracked changes only: the bump commit must carry the bump and nothing else, and an untracked
    # scratch file is neither. `git add` below names exactly what the bump modified.
    dirty = _git(root, "status", "--porcelain", "--untracked-files=no").stdout.strip()
    if dirty:
        print(
            "[push] COULD_NOT_RUN: the working tree has uncommitted changes to tracked files, and the "
            f"bump commit must carry only the bump. Commit or stash them first:\n{dirty}",
            file=sys.stderr,
        )
        return 2
    if version_bump.required_bump(version_bump.commits_since_last_bump(root)) != "none":
        rc = version_bump.main(["--root", str(root), "--apply"])
        if rc != 0:
            print(f"[push] the version bump did not apply (rc={rc}); nothing was committed or pushed.", file=sys.stderr)
            return rc
        changed = _git(root, "diff", "--no-relative", "--name-only").stdout.split()
        version = version_bump.current_version(root)
        _git(root, "add", "--", *changed)
        commit = _git(root, "commit", "-q", "-m", f"chore(version): bump to {version} per semver gate")
        if commit.returncode != 0:
            print(
                f"[push] the bump commit failed (rc={commit.returncode}); the bump is left in the working "
                f"tree, nothing was pushed:\n{commit.stdout}{commit.stderr}",
                file=sys.stderr,
            )
            return 2
    # `simplecode push -- --dry-run`: argparse keeps the `--` separator, and git must not see it.
    extra = args.push_args[1:] if args.push_args[:1] == ["--"] else args.push_args
    return subprocess.run(["git", "push", *extra], cwd=root, check=False).returncode
