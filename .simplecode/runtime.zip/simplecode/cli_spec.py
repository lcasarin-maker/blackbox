#!/usr/bin/env python3
"""Create and validate the project specification."""

from __future__ import annotations

import argparse
import re
import shlex
import subprocess
import sys
from pathlib import Path

from simplecode.cli_new import _spec
from simplecode.utils import atomic_io
from simplecode.verification.mutation_verify import _module_source_path

PLACEHOLDER_PATTERNS = [
    r"Describe the specific problem",
    r"Record the trigger",
    r"Name the specific user",
    r"Define the first required behavior",
    r"Define one explicit boundary",
    r"Replace every placeholder above",
    r"Replace with one concrete sentence",
    r"Define the concrete purpose and domain scope",
    r"Operational requirement trigger",
    r"Primary system engineer and automated pipeline agents",
]


_VERIFY_LINE_RE = re.compile(r"^verify:\s*(.+?)\s*$")
_EXPECT_LINE_RE = re.compile(r"^expect:\s*(\S+)")
_REQ_HEADING_RE = re.compile(r"^#+\s*(REQ-\d+)")
_EXPECTS = ("exit_zero", "exit_nonzero")
# 126/127 are the shell's "found but not executable" / "command not found": the child never ran.
_NOT_STARTED_RCS = (126, 127)


def _declared_verifies(content: str) -> list[tuple[str, str, str]]:
    """(requirement, command, expect) for every `verify:` line; `expect:` is the line right after
    it and defaults to `exit_zero`."""
    lines = content.splitlines()
    found = []
    req = "?"
    for i, line in enumerate(lines):
        heading = _REQ_HEADING_RE.match(line)
        if heading:
            req = heading.group(1)
        verify = _VERIFY_LINE_RE.match(line)
        if verify:
            expect = _EXPECT_LINE_RE.match(lines[i + 1]) if i + 1 < len(lines) else None
            found.append((req, verify.group(1), expect.group(1) if expect else "exit_zero"))
    return found


# Real shells only -- NOT "python"/"python3". `python -c "<code>"` is inline code, a
# fundamentally different thing from a shell wrapping a composed command: recursing into
# it as if it were shell syntax would misparse Python (a dict literal, an f-string) as
# tokens, and it is already excluded on purpose (the existing `prev != "-c"` guard below).
# A shell's `-c` argument, by contrast, genuinely IS another command line -- the same
# grammar `shlex.split` already understands -- so recursing into it is reuse of the exact
# same check, not new parsing machinery.
_SHELLS = frozenset({"bash", "sh", "zsh", "dash"})


def _missing_targets(
    tokens: list[str], root: Path, src_dir: Path, local_top_names: set[str],
) -> list[str]:
    """Missing `.py` paths and local `-m <module>` targets among `tokens`, recursing into
    a shell's own `-c "<command>"` argument (see `_SHELLS`) the same way -- a
    `verify: bash -c "pytest tests/foo.py"` cites `tests/foo.py` exactly as directly as a
    bare `verify: pytest tests/foo.py` does; only the wrapper differs.
    """
    found = []
    is_shell = bool(tokens) and Path(tokens[0]).name in _SHELLS
    for prev, tok in zip([""] + tokens, tokens):
        if prev == "-c":
            if is_shell:
                try:
                    inner = shlex.split(tok)
                except ValueError:
                    continue  # can't parse the embedded command; not this check's job
                found.extend(_missing_targets(inner, root, src_dir, local_top_names))
            continue
        path = tok.split("::")[0]
        if path.endswith(".py") and not (root / path).exists():
            found.append(f"verify cites missing file {path}")
        elif (prev == "-m" and tok.split(".")[0] in local_top_names
              and _module_source_path(src_dir, tok) is None):
            found.append(f"verify cites missing module {tok}")
    return found


def _verify_target_problems(content: str, root: Path) -> list[str]:
    """Problems with the files that `verify:` lines cite, judged WITHOUT executing them.

    `check` runs as a commit hook, and REQ verifies can be the whole suite or `pre-commit`
    itself, so running them here would recurse; `spec verify` is the half that executes.

    Three halves closed over three days (2026-09-21 `.py` paths; 2026-09-24 `-m <module>`
    targets and shell-composed `-c` commands, both reuse of `mutation_verify`'s existing
    module resolver and `shlex`'s existing grammar, not new machinery) -- the ponytail this
    docstring used to carry is gone; a `&&`/`|`/`;`-chained command needed nothing extra at
    all, `shlex.split` already tokenizes past those operators and the checks below see the
    real targets on either side.
    """
    problems = []
    src_dir = root / "src"
    # Same filter `mutation_verify.resolve_source_for_test` uses: only a dotted name whose
    # TOP-LEVEL package is actually present under src/ is treated as local. `-m pytest`,
    # `-m http.server`, `-m py_compile` -- the overwhelming majority of real `-m` verifies
    # in this fleet -- have no local source to check and must never be flagged; only a
    # name that already looks like OUR OWN package, with a submodule path that doesn't
    # resolve under it, is the rename this ponytail was about.
    local_top_names = (
        {p.stem for p in src_dir.iterdir() if p.is_dir() or p.suffix == ".py"}
        if src_dir.is_dir() else set()
    )
    for req, cmd, _expect in _declared_verifies(content):
        try:
            tokens = shlex.split(cmd)
        except ValueError:
            problems.append(f"{req}: unparseable verify: {cmd}")
            continue
        problems.extend(
            f"{req}: {msg}" for msg in _missing_targets(tokens, root, src_dir, local_top_names)
        )
    return problems


def _judge_verify(cmd: str, expect: str, timeout: float) -> tuple[str, str]:
    """(verdict, detail): OK, FAIL (ran, wrong outcome) or COULD_NOT_RUN (never started)."""
    try:
        tokens = shlex.split(cmd)
    except ValueError:
        return "COULD_NOT_RUN", "unparseable verify"
    if expect not in _EXPECTS:
        return "COULD_NOT_RUN", f"unknown expect {expect!r}"
    if tokens[0] in ("python", "python3"):
        tokens[0] = sys.executable
    try:
        rc = subprocess.run(tokens, capture_output=True, timeout=timeout, check=False).returncode
    except subprocess.TimeoutExpired:
        return "COULD_NOT_RUN", f"timed out after {timeout:g}s"
    except OSError as exc:
        return "COULD_NOT_RUN", f"could not start: {exc}"
    if rc in _NOT_STARTED_RCS:
        return "COULD_NOT_RUN", f"exited {rc}: command not found or not executable"
    if (rc == 0) == (expect == "exit_zero"):
        return "OK", ""
    return "FAIL", f"exited {rc}, expected {expect}"


def _verify(timeout: float) -> int:
    """Run every `verify:` of SPEC.md. 0 all OK, 1 any FAIL, 2 COULD_NOT_RUN (and no FAIL)."""
    spec_path = Path.cwd() / "SPEC.md"
    if not spec_path.exists():
        print("[spec-verify] COULD_NOT_RUN: SPEC.md not found", file=sys.stderr)
        return 2
    declared = _declared_verifies(spec_path.read_text(encoding="utf-8"))
    if not declared:
        print("[spec-verify] COULD_NOT_RUN: SPEC.md has no verify: lines, so 0 requirements were examined")
        return 2
    tally = {"OK": 0, "FAIL": 0, "COULD_NOT_RUN": 0}
    for req, cmd, expect in declared:
        verdict, detail = _judge_verify(cmd, expect, timeout)
        tally[verdict] += 1
        print(f"{verdict} {req}: {cmd}" + (f"  [{detail}]" if detail else ""))
    print(f"[spec-verify] {tally['OK']} OK, {tally['FAIL']} FAIL, {tally['COULD_NOT_RUN']} COULD_NOT_RUN")
    if tally["FAIL"]:
        return 1
    return 2 if tally["COULD_NOT_RUN"] else 0


def _init(force: bool) -> int:
    spec_path = Path.cwd() / "SPEC.md"
    if spec_path.exists() and not force:
        print("SPEC.md already exists. Use --force to overwrite.")
        return 1
    atomic_io.write_text_durable(spec_path, _spec(Path.cwd().name))
    print("SPEC.md created. Complete its product decisions before committing.")
    return 0


def _check() -> int:
    spec_path = Path.cwd() / "SPEC.md"
    if not spec_path.exists():
        # INSTRUMENTO CAIDO: no hay SPEC.md que mirar, cero elementos examinados.
        print("SPEC.md not found. Run: simplecode spec init")
        print("[spec-check] COULD_NOT_RUN: SPEC.md not found", file=sys.stderr)
        return 1

    content = spec_path.read_text(encoding="utf-8")
    verify_problems = _verify_target_problems(content, Path.cwd())
    checks = [
        ("Verify targets exist", not verify_problems),
        ("Objective", "## 0. Objective" in content and "**Mission**:" in content),
        ("Purpose", "Purpose" in content),
        ("Why now", "Why now" in content),
        ("User", "Who is the user" in content),
        ("In scope", "In scope" in content and ("- [" in content or "- " in content)),
        ("Out of scope", "Out of scope" in content),
        ("Python version", "Python version" in content),
        ("Deployment", "Deployment target" in content),
        ("ADRs table", "ADR" in content and "Status" in content),
        ("Risks table", "Risk" in content and "Likelihood" in content),
        ("Acceptance criteria", "Acceptance Criteria" in content),
    ]

    # Anti-template-placeholder validation
    placeholders_found = []
    for pat in PLACEHOLDER_PATTERNS:
        if re.search(pat, content):
            placeholders_found.append(pat)

    print("SPEC.md Validation\n")
    all_ok = True
    for name, ok in checks:
        print(f"  {'PASS' if ok else 'FAIL'} {name}")
        if not ok:
            all_ok = False

    for problem in verify_problems:
        print(f"    - {problem}")

    if placeholders_found:
        print("\n  FAIL: SPEC.md still contains unreplaced template placeholders:")
        for p in placeholders_found:
            print(f"    - '{p}'")
        all_ok = False

    if all_ok:
        print("\nAll checks passed")
        return 0

    # CONDENA: SPEC.md was read and judged against its own required sections.
    failed_checks = [name for name, ok in checks if not ok]
    total_fail = len(failed_checks) + len(placeholders_found)
    primero = failed_checks[0] if failed_checks else f"placeholder '{placeholders_found[0]}'"
    print(f"[spec-check] FAIL: {total_fail} check(s) failed; first {primero}")
    print("\nSome checks failed")
    return 1


def _drift() -> int:
    spec_path = Path.cwd() / "SPEC.md"
    if not spec_path.exists():
        print("SPEC.md not found. Run: simplecode spec init")
        return 1

    content = spec_path.read_text(encoding="utf-8")
    deviations = []

    # 1. ADR consistency
    adr_files = list(Path("docs/adr").glob("*.md")) if Path("docs/adr").is_dir() else []
    for m in re.finditer(r"\|\s*(\d{4})\s*\|", content):
        adr_num = m.group(1)
        if not any(adr_num in f.name for f in adr_files):
            deviations.append(f"ADR {adr_num} declared in SPEC.md but missing in docs/adr/")

    # 2. Coverage floor consistency
    pyproj = Path.cwd() / "pyproject.toml"
    if pyproj.is_file():
        py_content = pyproj.read_text(encoding="utf-8")
        spec_cov = re.search(r"(?:floor|fail_under|minimum)[^0-9]*([0-9]{2,3})%", content, re.I) or re.search(r"(?:coverage|cobertura)[^0-9]*([0-9]{2,3})%", content, re.I)
        py_cov = re.search(r"fail_under\s*=\s*([0-9]+)", py_content)
        if spec_cov and py_cov:
            if int(spec_cov.group(1)) > int(py_cov.group(1)):
                deviations.append(f"Coverage floor drift: SPEC requires {spec_cov.group(1)}%, pyproject.toml has {py_cov.group(1)}%")

    # 3. Objective & Boundaries check from drift module
    from simplecode.worktree import drift
    deviations.extend(drift.find_deviations(Path.cwd()))

    if deviations:
        print("[spec-drift] FAIL: Detected specification drift:")
        for d in deviations:
            print(f"  🔴 {d}")
        return 1

    print("[spec-drift] OK: Specification aligns with repository state.")
    return 0


def main(args: argparse.Namespace) -> int:
    cmd = args.spec_command
    if cmd == "init":
        return _init(args.force)
    if cmd in ("check", "validate"):
        return _check()
    if cmd == "drift":
        return _drift()
    if cmd == "verify":
        return _verify(args.timeout)
    print("Usage: simplecode spec <init|check|validate|drift|verify>")
    return 1


if __name__ == "__main__":
    import sys
    parser = argparse.ArgumentParser(description="Specification Manager")
    parser.add_argument("spec_command", choices=["init", "check", "validate", "drift", "verify"], default="check", nargs="?")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--timeout", type=float, default=900.0)
    sys.exit(main(parser.parse_args()))
