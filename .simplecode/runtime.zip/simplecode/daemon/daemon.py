"""simplecode.daemon -- módulo del demonio de fondo, versionado en el repo.

Historial: hasta el 2026-09-16 el demonio vivía en
``~/.local/share/simplecode/daemon/daemon.py``, fuera de cualquier repo git.
Eso provocó DGX-484: la función ``propagate_hooks`` original corría
``pre-commit install --overwrite`` sobre todos los repos bajo $HOME cada 30
minutos, reemplazando el hook personalizado ``simplecode-managed-hook:v1``
(escrito por ``verification.hook_install``) con la plantilla genérica del
framework, bloqueando pushes durante 15+ minutos en Atlas y simplecode el
mismo día (2026-09-08).

La mitigación inmediata fue redefinir ``propagate_hooks`` como no-op en el
archivo externo.  Este módulo es el arreglo definitivo: la lógica del demonio
vive en el repo, usa ``hook_install.install_hooks()`` que sabe del wrapper
versionado, y el systemd unit apunta a ``python -m simplecode.daemon`` en vez
del archivo suelto.
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime
from pathlib import Path

from simplecode.utils import atomic_io

log = logging.getLogger(__name__)

# ── Constantes de configuración ─────────────────────────────────────────────
TELEMETRY_INTERVAL = 3600   # 1 h
HOOK_PROPAGATION_INTERVAL = 1800  # 30 min

CONFIG_DIR = Path.home() / ".config" / "simplecode"
STATE_FILE = CONFIG_DIR / "daemon_state.json"


# ── Detección de repos gestionados ──────────────────────────────────────────

def _managed_repos() -> list[Path]:
    """Repos bajo $HOME que tienen .pre-commit-config.yaml o .simplecode/.

    Criterio conservador: sólo repos que ya adoptaron el kit. No toca repos
    ajenos ni repos sin el archivo de config --  evita exactamente el error de
    la función original que corría ``pre-commit install`` en TODOS los repos.
    """
    home = Path.home()
    found: list[Path] = []
    for gitdir in sorted(home.rglob(".git")):
        # Saltear worktrees (el archivo .git en un worktree es un archivo, no un dir)
        if not gitdir.is_dir():
            continue
        repo = gitdir.parent
        # Sólo repos que el kit ya gestiona
        if (repo / ".pre-commit-config.yaml").is_file() or (repo / ".simplecode").is_dir():
            found.append(repo)
    return found


# ── Hook propagation (arreglo definitivo de DGX-484) ────────────────────────

def propagate_hooks() -> None:
    """Instala/actualiza los launchers git en cada repo gestionado por simplecode.

    Llama a ``hook_install.install_hooks(repo)`` -- que escribe el wrapper
    ``# simplecode-managed-hook:v1`` -- en vez de ``pre-commit install
    --overwrite`` a ciegas. Eso garantiza que el hook personalizado nunca es
    reemplazado por la plantilla genérica del framework.

    Repos objetivo: los que tienen ``.pre-commit-config.yaml`` o
    ``.simplecode/`` bajo $HOME (no todos los repos de la máquina).
    """
    # Importación diferida: el daemon puede correr antes de que el paquete esté
    # instalado en el entorno del sistema; si no puede importar, avisa y sale.
    try:
        from simplecode.verification import hook_install
    except ImportError as exc:  # pragma: no cover
        log.warning("propagate_hooks: no se pudo importar hook_install -- %s", exc)
        return

    repos = _managed_repos()
    ok = skipped = failed = 0
    for repo in repos:
        try:
            result = hook_install.install_hooks(repo)
            if result:
                ok += 1
            else:
                failed += 1
                log.warning("propagate_hooks: install_hooks(%s) devolvió False", repo)
        except Exception as exc:
            failed += 1
            log.warning("propagate_hooks: fallo en %s -- %s", repo, exc)
    log.info(
        "propagate_hooks: %d repos -- ok=%d skipped=%d failed=%d",
        len(repos), ok, skipped, failed,
    )


# ── Telemetría (sin cambios respecto al original) ───────────────────────────

def collect_findings() -> list[dict]:
    telemetry_log = CONFIG_DIR / "telemetry.jsonl"
    findings: list[dict] = []
    if telemetry_log.exists():
        try:
            for line in telemetry_log.read_text(encoding="utf-8").strip().split("\n")[-100:]:
                if line.strip():
                    findings.append(json.loads(line))
        except Exception as exc:
            log.warning("collect_findings: %s", exc)
    return findings


def send_telemetry(findings: list[dict]) -> None:
    try:
        telemetry_log = CONFIG_DIR / "telemetry_log.jsonl"
        payload = {
            "timestamp": datetime.now().isoformat(),
            "findings": findings,
        }
        with open(telemetry_log, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload) + "\n")
    except Exception as exc:
        log.warning("send_telemetry: %s", exc)


# ── Estado persistido ────────────────────────────────────────────────────────

def load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            log.warning("load_state: %s", exc)
    return {"last_telemetry": 0, "last_hook_propagation": 0}


def save_state(state: dict) -> None:
    try:
        atomic_io.write_text_durable(STATE_FILE, json.dumps(state), encoding="utf-8")
    except Exception as exc:
        log.warning("save_state: %s", exc)


# ── Bucle principal ──────────────────────────────────────────────────────────

def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
    )
    log.info("simplecode daemon started (versioned module)")

    state = load_state()
    state.pop("last_update_check", None)
    last_telemetry = state.get("last_telemetry", 0)
    last_propagation = state.get("last_hook_propagation", 0)

    while True:
        now = time.time()

        if now - last_propagation >= HOOK_PROPAGATION_INTERVAL:
            propagate_hooks()
            last_propagation = now
            state["last_hook_propagation"] = now

        if now - last_telemetry >= TELEMETRY_INTERVAL:
            findings = collect_findings()
            if findings:
                send_telemetry(findings)
            last_telemetry = now
            state["last_telemetry"] = now

        save_state(state)
        time.sleep(60)  # blocking-sleep: demonio de sistema en su propio proceso, bloquear es correcto -- DGX-484  # sunset-reviewed: 9.6 -- demonio de sistema en su propio proceso


if __name__ == "__main__":
    main()
