"""simplecode.daemon package."""
from __future__ import annotations

from simplecode.daemon.daemon import main, propagate_hooks

__all__ = ["main", "propagate_hooks"]
