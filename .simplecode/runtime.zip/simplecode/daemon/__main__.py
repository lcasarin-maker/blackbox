"""simplecode.daemon.__main__ -- permite ``python -m simplecode.daemon``."""
from __future__ import annotations

from simplecode.daemon.daemon import main

if __name__ == "__main__":
    main()
