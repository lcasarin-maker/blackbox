#!/usr/bin/env python3
"""Create a portable Python project with complete simplecode canonical gates."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import io
import json
import keyword
import re
import subprocess
import textwrap
import tomllib
import zipfile
from collections.abc import Iterable, Iterator
from datetime import date
from pathlib import Path

from simplecode.utils import atomic_io
from simplecode.verification import hook_install, telemetry_dispositions
from simplecode.worktree import claims

PROJECT_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")


PYTEST_MARKER_DESCRIPTIONS = {
    "unit": "Fast unit tests (<= 0.2s)",
    "integration": "Integration tests (<= 2.0s)",
    "slow": "Slow tests (> 2.0s)",
    "e2e": "End-to-end and browser tests",
}


def _project_pyproject(name: str, package: str) -> str:
    return textwrap.dedent(
        f'''\
        [build-system]
        requires = ["setuptools==83.0.0"]
        build-backend = "setuptools.build_meta"

        [project]
        name = "{name}"
        version = "0.1.0"
        description = "Canonical {name} with simplecode gates"
        readme = "README.md"
        requires-python = ">=3.11"
        [project.optional-dependencies]
        dev = [
            "deptry==0.25.1",
            "pip==26.2.1",
            "pip-audit==2.10.1",
            "pre-commit==4.6.2",
            "pytest==9.0.3",
            "pytest-cov==7.1.0",
            "PyYAML==6.0.3",
            "pyright==1.1.411",
            "ruff==0.15.22",
            "setuptools==83.0.0",
        ]

        [tool.setuptools.packages.find]
        where = ["src"]

        [tool.ruff]
        target-version = "py311"
        line-length = 100

        [tool.ruff.lint]
        select = ["E9", "F821", "F632", "F811", "C901", "PLR0912", "PLR0913", "PLR0915"]

        [tool.pytest.ini_options]
        testpaths = ["tests"]
        pythonpath = ["src"]
        markers = {json.dumps([f"{key}: {value}" for key, value in PYTEST_MARKER_DESCRIPTIONS.items()])}

        [tool.coverage.run]
        source = ["{package}"]

        [tool.coverage.report]
        fail_under = 100
        show_missing = true

        [tool.pyright]
        include = ["src"]
        pythonVersion = "3.11"
        venvPath = "."
        venv = ".venv"
        typeCheckingMode = "strict"
        '''
    )


def pre_commit_config(portable: bool = True) -> str:
    config = textwrap.dedent(
        '''\
        fail_fast: false
        repos:
          - repo: https://github.com/astral-sh/ruff-pre-commit
            rev: v0.15.22
            hooks:
              - id: ruff
                name: "ruff (staged fatal blockers)"
                args: [--select, "E9,F821,F632,F811"]
                stages: [pre-commit, pre-merge-commit]

          - repo: https://github.com/gitleaks/gitleaks
            rev: v8.30.1
            hooks:
              - id: gitleaks
                name: "gitleaks (secrets staged)"
                args: [--no-banner, --redact]
                stages: [pre-commit, pre-merge-commit]

          - repo: local
            hooks:
              # 2026-09-27: 25 hooks the kit's gate audit judged APARATO / AVISO /
              # REDUNDANTE (they guarded the kit's own process, not your product)
              # were retired from this template. Their modules still ship in
              # runtime.zip, runnable by hand. See the kit's DECISIONS.md.
              # `--staged`: this gate judges what the COMMIT introduces, never
              # the repo's accumulated debt. Without the flag the module falls
              # back to a whole-repo sweep, and one already-committed corrupt
              # file freezes EVERY commit in the satellite -- measured in Atlas
              # 2026-09-01, two sessions frozen over corruption verified already
              # in HEAD. The repo-wide sweep stays available for `make`/manual.
              - id: corruption-guard
                name: "corruption guard (bytes, mojibake, CRLF, BOM) -- staged"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name corruption-guard --hook pre-commit --
                  python .simplecode/run.py simplecode.guards.corruption_guard --staged
                language: system
                stages: [pre-commit, pre-merge-commit]
                pass_filenames: false

              - id: angry-path
                name: "angry path dominance (Rule B3)"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name angry-path --hook pre-commit --
                  python .simplecode/run.py simplecode.guards.angry_path --gate
                language: system
                types: [python]
                stages: [pre-commit, pre-merge-commit]
                pass_filenames: true

              - id: staged-parity
                name: "staged-parity (index vs working tree)"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name staged-parity --hook pre-commit --
                  python .simplecode/run.py simplecode.worktree.staged_parity
                language: system
                stages: [pre-commit, pre-merge-commit]
                pass_filenames: false

              - id: truncation-guard
                name: "truncation guard (integrity of edits)"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name truncation-guard --hook pre-commit --
                  python .simplecode/run.py simplecode.guards.truncation_guard --gate
                language: system
                stages: [pre-commit, pre-merge-commit]
                pass_filenames: false

              # 2026-10-07 (Atlas DGX-531): an exemption enters WITH its
              # `# sunset-reviewed: X.Y -- reason` tag or the commit is refused,
              # not at push. `--staged` judges only the lines this commit ADDS, so
              # a repo with old untagged exemptions is not frozen by them.
              - id: sunset-audit-staged
                name: "sunset audit (exemptions this commit adds carry a tag)"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name sunset-audit-staged --hook pre-commit --
                  python .simplecode/run.py simplecode.verification.sunset_audit --root . --staged --gate
                language: system
                stages: [pre-commit, pre-merge-commit]
                pass_filenames: false

              - id: zero-debt-repo
                name: "zero debt (repo-wide ship freeze)"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name zero-debt-repo --hook pre-push --
                  python .simplecode/run.py simplecode.worktree.zero_debt
                  --root . --mode zero --gate
                language: system
                types: [python]
                stages: [pre-push]
                pass_filenames: false

              - id: coverage-floor
                name: "coverage target (ratchet: never below watermark)"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name coverage-100 --hook pre-push --
                  python .simplecode/run.py simplecode.verification.coverage_target
                  -q
                language: system
                types: [python]
                stages: [pre-push]
                pass_filenames: false

              - id: pyright
                name: "pyright (type checking)"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name pyright --hook pre-push --
                  python .simplecode/run.py simplecode.verification.pyright_gate --root .
                language: system
                types: [python]
                stages: [pre-push]
                pass_filenames: false

              - id: pii-scan
                name: "no third-party PII (RFC/CURP) in tasks/ or docs/"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name pii-scan --hook pre-push --
                  python .simplecode/run.py simplecode.verification.pii_scan --root .
                language: system
                stages: [pre-push]
                pass_filenames: false

              - id: adversarial-judge
                name: "Judge-Zero forensic auditor"
                entry: >-
                  python .simplecode/run.py simplecode.verification.gate_runner
                  --root . --name adversarial-judge --hook pre-push --
                  python .simplecode/run.py simplecode.verification.adversarial_judge
                  --root . --gate
                language: system
                stages: [pre-push]
                pass_filenames: false
        '''
    )
    if portable:
        return config
    return config.replace("python .simplecode/run.py ", "python -m ")


# Compatibility for existing kit consumers.
_pre_commit_config = pre_commit_config

def _ci_workflow(name: str, package: str) -> str:
    return textwrap.dedent(
        f'''\
        name: {name} CI Gate

        on:
          push:
            branches: [ master, main ]
          pull_request:
            branches: [ master, main ]
          schedule:
            # Continuous mutation testing (DEBT-SPEC8-MUTATION-CI): `make mutate`
            # reruns the WHOLE suite once per mutant, so it does not belong on the
            # push/PR path (measured on the mother repo: one full suite run alone
            # takes minutes, not seconds). Scheduled instead of pre-push/pre-commit
            # so it still runs on its own -- unlike the growth ratchet, which sat
            # BLOCKED for 8 days because nothing invoked it -- weekly, not "when a
            # human remembers to type `make mutate`".
            - cron: '0 6 * * 1'
          workflow_dispatch: {{}}

        jobs:
          verify:
            name: Fleet Integrity & Quality Gates (Python ${{{{ matrix.python-version }}}})
            runs-on: ubuntu-latest
            if: github.event_name != 'schedule'
            strategy:
              fail-fast: false
              matrix:
                python-version: ['3.11', '3.12']
            steps:
              - name: Checkout repository
                uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
                with:
                  fetch-depth: 0

              - name: Set up Python ${{{{ matrix.python-version }}}}
                uses: actions/setup-python@42375524e23c412d93fb67b49958b491fce71c38 # v5.4.0
                with:
                  python-version: ${{{{ matrix.python-version }}}}
                  cache: pip

              - name: Install dependencies
                run: |
                  python -m venv .venv
                  .venv/bin/python -m pip install ".[dev]"

              - name: Preventive and ship gates
                run: PATH="$PWD/.venv/bin:$PATH" make check

          mutation-testing:
            name: Continuous mutation testing (scheduled, SPEC.md section 8 / DEBT-SPEC8-MUTATION-CI)
            runs-on: ubuntu-latest
            if: github.event_name == 'schedule' || github.event_name == 'workflow_dispatch'
            steps:
              - name: Checkout repository
                uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
                with:
                  fetch-depth: 0

              - name: Set up Python
                uses: actions/setup-python@42375524e23c412d93fb67b49958b491fce71c38 # v5.4.0
                with:
                  python-version: '3.12'
                  cache: pip

              - name: Install dependencies
                run: |
                  python -m venv .venv
                  .venv/bin/python -m pip install ".[dev]"

              - name: Mutation testing (does the suite kill a real code mutation?)
                run: PATH="$PWD/.venv/bin:$PATH" make mutate
        '''
    )


def _makefile(name: str, package: str) -> str:
    """The satellite Makefile.

    The literal is written FLUSH-LEFT and `textwrap.dedent` is deliberately absent.
    `dedent` computes the common prefix over every line, and a recipe line begins with
    a literal TAB (make requires it) while a definition line began with spaces -- they
    share no common prefix, so the dedent was a no-op and every satellite ever
    scaffolded carries 8 stray spaces on `VENV ?=`, `.PHONY:`, `install:` and friends.
    Harmless to make (measured: a target indented with 8 spaces and a TAB recipe runs,
    rc 0), but it makes the template unreadable against a real satellite's file, which
    is exactly the normalisation DEBT-PUSH-LOOP-10's census had to do by hand before it
    could tell a local edit from template staleness.
    """
    return f'''\
VENV ?= .venv

# DEBT-PUSH-LOOP-10 (2026-09-15): interpreter selection PROMOTED TO CANONICAL from
# declutter, which had fixed it locally after a measured incident (DECL-CORE-093).
# There, bare `python` resolved to /opt/miniforge3/bin/python while the gates and CI
# ran the `.venv` that `uv sync` builds, so the SAME TREE returned two different
# verdicts -- a dependency failure visible under one interpreter and invisible under
# the other. The old canonical `PYTHON := $(VENV)/bin/python` had no fallback at all:
# in a fresh clone, before `make install`, every recipe using $(PYTHON) died with
# "no such file", and every recipe that said bare `python` silently used the system
# interpreter, which is the same divergence with no error to notice.
# So: prefer the project venv, fall back to whatever `python` is on PATH, and SAY
# WHICH ONE -- a fallback nobody can see is how the incident above stayed invisible.
# The fallback is the literal `python`, not `$(shell command -v python)`: an empty
# expansion would make every recipe fail with a confusing error instead of a clear
# "python: command not found", and the literal is resolved at recipe time, so it also
# picks up the PATH export below once a venv appears.
PYTHON := $(shell test -x $(VENV)/bin/python && echo $(VENV)/bin/python || echo python)
PYTHON_IS_VENV := $(shell test -x $(VENV)/bin/python && echo yes || echo no)
export PATH := $(abspath $(VENV))/bin:$(PATH)

# DEBT-SPEC8-MUTATION-CI: override once the package has real logic worth
# mutating, e.g. `make mutate MUTATE_TARGET=src/{package}/core.py`. Defaults
# to __init__.py, which every scaffolded project has, so the target always
# resolves -- a freshly scaffolded package has nothing to mutate yet, and
# that is what the probe honestly reports, not a silently-skipped success.
MUTATE_TARGET ?= src/{package}/__init__.py

.PHONY: install check ci test lint types coverage deps fix mutate doctor session-gate interpreter

interpreter:
	@echo "[interpreter] PYTHON=$(PYTHON) (project venv: $(PYTHON_IS_VENV))"
	@$(PYTHON) -c "import sys; print('[interpreter]  ', sys.executable)"

install:
	python -m venv $(VENV)
	$(PYTHON) -m pip install ".[dev]"
	$(PYTHON) .simplecode/run.py simplecode.verification.hook_install --root .

check:
	@# Announced, not assumed: every gate below runs under THIS interpreter, and a
	@# `no` here means the verdict may differ from CI's for no reason but the PATH.
	@echo "[check] interpreter: $(PYTHON) (project venv: $(PYTHON_IS_VENV))"
	$(PYTHON) .simplecode/run.py simplecode.verification.gate_runner --root . --name pre-commit-all --hook manual --propagate-only -- pre-commit run --all-files --hook-stage pre-commit
	@# PARITY -- DEBT-PUSH-LOOP-04 (kit, 2026-09-15). This step used to be
	@# `pre-commit run --all-files --hook-stage pre-push` under `gate_runner --hook manual`,
	@# which is NOT what gates a push: the generated .git/hooks/pre-push prefers the
	@# vendored `prek` (concurrent), mints one SIMPLECODE_RUN_ID for the whole attempt,
	@# skips telemetry-disposition inside the suite and re-invokes it last on a green
	@# suite. Rehearsing with another launcher returns the verdict of another run.
	@#
	@# CHOSEN (a): invoke the INSTALLED script exactly as it is on disk, no reinstall first.
	@#   COST, named: `make check` rehearses whatever launcher THIS checkout currently has,
	@#   so a checkout whose hook predates a kit sync rehearses a stale script. Accepted
	@#   because that stale script is also precisely what git will run on this checkout at
	@#   push time, so parity -- the property this step exists for -- still holds; hook
	@#   staleness is a different subject, owned by satellite_sync's HOOK_DRIFTED and by
	@#   `make doctor`.
	@# REJECTED (b): `hook_install --root .` first, then invoke. It would make a target named
	@#   `check` rewrite the files under .git/hooks as a side effect, silently overwriting a
	@#   suspended or hand-edited hook (see the suspension contract), and it could never
	@#   report a MISSING hook at all, because it installs one -- turning a COULD_NOT_RUN
	@#   into a pass.
	@#
	@# `< /dev/null`: git feeds pre-push the ref-update lines on stdin. Make would leave the
	@# terminal there and the hook's `read` loop would hang. Zero lines now means VERIFY, not
	@# "every ref is a deletion" -- see hook_install._SKIP_ON_ALL_DELETE (REFS_SEEN).
	@hook="$$(git rev-parse --path-format=absolute --git-path hooks/pre-push 2>/dev/null)"; \
	if [ -z "$$hook" ] || [ ! -x "$$hook" ]; then \
		echo "[check] COULD_NOT_RUN: no executable pre-push launcher at '$$hook'."; \
		echo "[check] This is NOT a pass: zero pre-push gates ran. Install it, then re-run:"; \
		echo "[check]     $(PYTHON) .simplecode/run.py simplecode.verification.hook_install --root ."; \
		exit 2; \
	fi; \
	echo "[check] rehearsing the installed pre-push launcher: $$hook"; \
	"$$hook" < /dev/null
	$(PYTHON) .simplecode/run.py simplecode.verification.gate_runner --root . --name dependency-audit --hook manual -- make deps

# ---- one-shot tools, PROMOTED FROM declutter (DEBT-PUSH-LOOP-10, 2026-09-15) -------
# Four targets a satellite had to invent because the template offered no way to run one
# tool alone. Each was measured against declutter's OWN gate suite before promoting:
#   types    -- its `pyright` gate already runs pyright at pre-push: a DUPLICATE. So this
#               is an alias onto THE SAME module the gate runs, not a second call to
#               `pyright` -- two implementations of one check is how one tree comes to
#               have two verdicts.
#   coverage -- its `coverage-floor` gate is a RATCHET (never below the watermark) and
#               strictly stronger than the fixed `--cov-fail-under=91` it kept locally.
#               Same reasoning: alias onto the gate's own module, never a second floor.
#   lint     -- a REAL GAP, in this template and in the kit's own Makefile. The staged
#               `ruff` gate checks four fatal rules (E9,F821,F632,F811) over STAGED files
#               only; `ruff check .` is the full ruleset over the whole tree, and nothing
#               else in the suite runs it.
#   test     -- the suite with NO floor, because this is what a per-ficha
#               `verification_command` runs and those execute ONE test file. A repo-wide
#               floor applied to a single-file run measures the instrument, not the
#               subject (measured in declutter: 35 per-ficha commands failing at 23-75%
#               with nothing actually broken). The floor lives in `coverage`.
test:
	$(PYTHON) -m pytest -q

lint:
	ruff check .

types:
	$(PYTHON) .simplecode/run.py simplecode.verification.pyright_gate --root .

coverage:
	$(PYTHON) .simplecode/run.py simplecode.verification.coverage_target -q

# CI entry point -- and the reason it is NOT named `check`: `check` rehearses the
# INSTALLED .git/hooks/pre-push, and a CI job clones fresh, so there is no launcher to
# rehearse and `check` would report COULD_NOT_RUN with exit 2 on every single run.
# Renaming is the fix; weakening `check` to pass when the hook is missing is not, because
# that turns the one arm that says "zero gates ran" into a silent pass. declutter's
# `check: coverage lint type` IS this target under the old name, and its CI calls it.
ci: coverage lint types

deps:
	mkdir -p .simplecode/evidence
	$(PYTHON) -m pip freeze --all --exclude {name} > .simplecode/evidence/audit-requirements.txt
	pip-audit --cache-dir .simplecode/cache/pip-audit --strict --no-deps --disable-pip -r .simplecode/evidence/audit-requirements.txt
	deptry src --known-first-party {package} --optional-dependencies-dev-groups dev

fix:
	ruff check --fix src tests
	ruff format src tests

mutate:
	$(PYTHON) .simplecode/run.py simplecode.verification.test_effectiveness --target-file $(MUTATE_TARGET) --root . --tests-dir tests --max-mutants 20

doctor:
	$(PYTHON) .simplecode/run.py simplecode.doctor --root . --gate

session-gate:
	$(PYTHON) .simplecode/run.py simplecode.verification.finding_backlog --root . --gate
'''


def _spec(name: str, project_type: str = "library") -> str:
    return textwrap.dedent(
        f'''\
        ---
        spec_version: 2
        id: {name}
        kind: {project_type}
        owner: ""
        runtime: {{lang: python, version: ">=3.11"}}
        scaffold: {{name: simplecode, mode: vendored}}
        debt: tasks/
        gate_level: strict
        ---

        # SPEC.md - {name}

        ## Requirements

        <!-- Write real product requirements here: ### REQ-0001, an EARS
        requirement, its verify: command and expect: criterion. Fill owner above.
        A fresh scaffold deliberately has no invented acceptance requirement. -->

        ## 0. Objective

        **Mission**: [Replace with one concrete sentence describing the outcome and user.]

        ## Purpose
        Define the concrete purpose and domain scope for {name}.

        ## Why now
        Operational requirement trigger.

        ## Who is the user
        Primary system engineer and automated pipeline agents.

        ## In scope
        - Initial domain model and core execution engine.
        - Canonical pre-commit quality gates and automated CI.

        ## Out of scope
        - Legacy unverified modules.

        ## Constraints
        Python version: 3.11+
        Deployment target: local

        ## ADRs
        | ADR | Decision | Status |
        | --- | --- | --- |
        | 0001 | Adopt simplecode gates | Accepted |

        ## Risks
        | Risk | Likelihood | Mitigation |
        | --- | --- | --- |
        | Undefined product behavior | Medium | Complete specification before implementation |

        ## Acceptance Criteria
        - Initial implementation verified with full coverage.
        - `simplecode check` passes.
        '''
    )


def _portable_runner() -> str:
    return textwrap.dedent(
        '''\
        #!/usr/bin/env python3
        """Run the explicitly pinned Simplecode runtime."""
        import hashlib
        import json
        import runpy
        import sys
        import zipfile
        from pathlib import Path

        here = Path(__file__).resolve().parent
        runtime = here / "runtime.zip"
        lock_path = here / "kit.lock"

        if not runtime.is_file():
            raise SystemExit("simplecode runtime.zip is missing; run explicit sync apply")
        if not lock_path.is_file():
            raise SystemExit("simplecode kit.lock is missing; run explicit sync apply")
        try:
            lock = json.loads(lock_path.read_text(encoding="utf-8"))
            bundle = runtime.read_bytes()
            with zipfile.ZipFile(runtime) as zf:
                manifest = json.loads(zf.read("RUNTIME_MANIFEST.json").decode("utf-8"))
                entries = [
                    (name, zf.read(name))
                    for name in sorted(name for name in zf.namelist() if name.endswith((".py", ".yaml")))
                ]
        except (OSError, KeyError, ValueError, zipfile.BadZipFile) as exc:
            raise SystemExit(f"simplecode runtime identity cannot be verified: {exc}") from exc
        actual_bundle_sha = hashlib.sha256(bundle).hexdigest()
        if lock.get("artifact_sha256") != actual_bundle_sha:
            raise SystemExit("simplecode runtime.zip differs from kit.lock; run explicit sync apply")
        content = hashlib.sha256()
        for name, data in entries:
            content.update(name.encode("utf-8"))
            content.update(data)
        if manifest.get("content_sha256") != content.hexdigest():
            raise SystemExit("simplecode runtime.zip does not match its content manifest; run explicit sync apply")
        if lock.get("content_sha256") != manifest.get("content_sha256"):
            raise SystemExit("simplecode runtime manifest differs from kit.lock; run explicit sync apply")
        if len(sys.argv) < 2:
            raise SystemExit("usage: run.py MODULE [ARGS...]   |   run.py --version")
        if sys.argv[1] in ("--version", "-V"):
            print(f"simplecode {manifest.get('simplecode_version', '?')} "
                  f"(content {str(manifest.get('content_sha256', '?'))[:12]})")
            print(f"  bundle: {runtime}")
            print(f"  artifact: {actual_bundle_sha[:12]}")
            raise SystemExit(0)
        module = sys.argv[1]
        sys.path.insert(0, str(runtime))
        sys.argv = sys.argv[1:]
        runpy.run_module(module, run_name="__main__")
        '''
    )


def _runtime_manifest_bytes(sources: list[tuple[str, bytes]], version: str) -> bytes:
    """A self-describing fingerprint for this exact runtime.zip snapshot.

    A gate wired through `.simplecode/run.py` runs whatever was frozen into
    runtime.zip at the last scaffold/resync -- which silently diverges from
    a "standalone" run against a live/editable install as the two drift
    apart. Without this, a contradiction between the two (one says clean,
    the other fails) is undiagnosable: nothing states which snapshot either
    run used. `doctor` surfaces this manifest so the two can be compared.
    """
    manifest = {"simplecode_version": version, "content_sha256": runtime_content_sha256(sources)}
    return json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8") + b"\n"


def runtime_content_sha256(entries: Iterable[tuple[str, bytes]]) -> str:
    """The single definition of what `content_sha256` hashes.

    Relative path, then bytes, for each entry, in the caller's order. Three
    callers feed it three different iterables of the SAME thing:
    `_runtime_manifest_bytes` (the mother's package, at bundle time),
    `bundle_content_sha256` (a built bundle's own entries), and the shipped
    runner's mother walk. One function so the first two cannot drift; the
    third is a source string that cannot import the kit before deciding
    whether to pull the kit, and `organ_crossings.runner_digest_matches_manifest`
    is what crosses it against this one.
    """
    digest = hashlib.sha256()
    for relative, data in entries:
        digest.update(relative.encode("utf-8"))
        digest.update(data)
    return digest.hexdigest()


def bundle_sources(archive: zipfile.ZipFile) -> Iterator[tuple[str, bytes]]:
    """The entries a bundle's `content_sha256` was computed over, read back
    out of the bundle itself.

    `_runtime_bundle` writes the sources sorted by path and then appends
    `RUNTIME_MANIFEST.json`, which is neither `.py` nor `.yaml` and so is
    excluded here exactly as it was excluded there.
    """
    for name in sorted(n for n in archive.namelist() if n.endswith((".py", ".yaml"))):
        yield name, archive.read(name)


def bundle_content_sha256(bundle: bytes) -> str:
    """Recompute `content_sha256` from a bundle's REAL entries."""
    with zipfile.ZipFile(io.BytesIO(bundle), "r") as archive:
        return runtime_content_sha256(bundle_sources(archive))


def bundle_self_disagreement(bundle: bytes) -> str | None:
    """`None` when a bundle's content matches what its own manifest declares;
    otherwise the reason it does not, in words.

    The freshness trigger in `.simplecode/run.py` compares the mother's
    digest against the `content_sha256` the bundle DECLARES. Nothing in that
    comparison reads the bundle's content, so a bundle whose code was altered
    and whose manifest was then brought up to date reads as "up to date" on
    every hook run of every satellite, forever, in silence. Measured
    2026-09-05: two bundles carrying the same altered `.py` returned opposite
    verdicts, the only difference being the field the zip states about itself.
    A disagreement here is COULD_NOT_RUN -- the bundle is not what it says it
    is, so nothing it contains can be trusted to report on itself -- never a
    quiet "up to date".
    """
    try:
        with zipfile.ZipFile(io.BytesIO(bundle), "r") as archive:
            declared = str(json.loads(archive.read("RUNTIME_MANIFEST.json").decode("utf-8")).get("content_sha256", ""))
            actual = runtime_content_sha256(bundle_sources(archive))
    except (KeyError, ValueError, OSError, zipfile.BadZipFile) as exc:
        return f"bundle manifest unreadable ({exc})"
    if actual != declared:
        return f"bundle content {actual[:16]} != the content_sha256 {declared[:16]} it declares"
    return None


def _source_version(package_root: Path) -> str:
    """The version simplecode is actually being bundled at.

    Prefers `pyproject.toml` at the repo root over `importlib.metadata`: an
    editable/dev install's metadata is stamped once at `pip install -e .`
    and does not update on every source change, so it silently drifts
    behind `pyproject.toml`'s own version bumps -- confirmed live in this
    checkout while building this fix (`pyproject.toml` at 3.7.0, this venv's
    installed metadata still reporting 0.1.0). Falls back to
    `importlib.metadata` for an installed wheel, which does not ship
    `pyproject.toml`.
    """
    pyproject_path = package_root.parent.parent / "pyproject.toml"
    if pyproject_path.is_file():
        try:
            data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        except (tomllib.TOMLDecodeError, OSError):
            data = {}
        version = data.get("project", {}).get("version")
        if version:
            return str(version)
    try:
        return importlib.metadata.version("simplecode")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def _runtime_bundle() -> bytes:
    """Build a deterministic zip import bundle from the installed package."""
    package_root = Path(__file__).resolve().parent
    sources = [
        (source.relative_to(package_root.parent).as_posix(), source.read_bytes())
        for source in sorted(package_root.rglob("*"))
        if source.is_file() and source.suffix in (".py", ".yaml")
    ]
    version = _source_version(package_root)
    manifest_bytes = _runtime_manifest_bytes(sources, version)

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative, data in [*sources, ("RUNTIME_MANIFEST.json", manifest_bytes)]:
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, data)
    return buffer.getvalue()


def kit_lock_bytes(runner: str, bundle: bytes) -> bytes:
    """Return the portable runtime identity a satellite commits alongside it.

    The lock deliberately lives outside the bundle: an artifact cannot safely
    contain its own whole-file digest without a circular hash.  The runner
    validates both the bundle digest and the manifest content digest before it
    imports anything from the ZIP.
    """
    try:
        with zipfile.ZipFile(io.BytesIO(bundle)) as archive:
            manifest = json.loads(archive.read("RUNTIME_MANIFEST.json").decode("utf-8"))
    except (KeyError, OSError, ValueError, zipfile.BadZipFile) as exc:
        raise ValueError(f"runtime bundle has no readable manifest: {exc}") from exc
    payload = {
        "format": 1,
        "simplecode_version": str(manifest.get("simplecode_version", "unknown")),
        "content_sha256": str(manifest.get("content_sha256", "")),
        "artifact_sha256": hashlib.sha256(bundle).hexdigest(),
        "runner_sha256": hashlib.sha256(runner.encode("utf-8")).hexdigest(),
    }
    return (json.dumps(payload, sort_keys=True, indent=2) + "\n").encode("utf-8")


# ---------------------------------------------------------------------------
# Fleet canon directories (2026-09-02)
# ---------------------------------------------------------------------------
#
# Scaffolded because a structure that only exists where somebody remembered to
# create it is not a canon. Each README is what makes git keep the directory,
# and says what belongs in it so an empty one is legible rather than mysterious.

_TASKS_EVIDENCE_README = """# tasks/evidence

Artifacts a task's `evidence` field points at: the output that proves a check
passed, the output proving it can FAIL, and the end-to-end run. The fail
artifact is the one that is usually missing and the only one that makes the
other two mean anything -- a check that cannot come out negative is not a check.

A `.md` living directly under here (a disposition note, an audit writeup) is
documentation, not a task: `simplecode.verification.ledger_schema` and
`.no_perder_lineas` both exempt this directory from their coverage sweep of
`tasks/`, the same way they exempt `README.md`/`BACKLOG.md` by name.
"""

_GATES_README = """# gates

Repository-specific gates, wired through `.simplecode/local_hooks.yaml` and NOT
through `.pre-commit-config.yaml`, which `satellite_sync` composes from the kit
and overwrites.

A gate here runs with `--check` and does not write into the tree it judges.

To declare one in a task's `close_check`, use the MODULE form, not the script
path: `python -m gates.<name>`, never `python gates/<name>.py`. Both give the
same exit code today (no `__init__.py` needed -- `gates/` works as a namespace
package), but the module form is what stays correct if a gate ever needs an
import relative to this package; the script-path form breaks silently the day
that happens. Found by the session declutter (2026-09-04) after discovering
the module form by trial, undocumented until now.
"""


def _write_project(target: Path, name: str, package: str, project_type: str) -> None:
    from simplecode.satellite.satellite_sync import compose_canonical_config

    for directory in (
        target / "src" / package,
        target / "tests",
        target / "docs" / "adr",
        target / "tasks" / "backlog",
        target / "tasks" / "evidence",
        target / ".github" / "workflows",
        target / ".simplecode",
    ):
        directory.mkdir(parents=True, exist_ok=True)

    files = {
        # SPEC.md is FIRST, and the order is load-bearing: SPEC.md:153 claims
        # `simplecode new` writes it literally first, spec-first discipline made
        # mechanical. Adding the canon READMEs above it on 2026-09-02 silently
        # made that claim false -- SPEC.md became the fifth file written -- and
        # the H1 audit caught it by running `simplecode new` under strace rather
        # than by reading this dict.
        "SPEC.md": _spec(name, project_type),
        # Fleet canon (2026-09-02), UPDATED 2026-09-04: `ledger/` (entries/evidence/
        # decisions) collapsed into `tasks/` the same day it was born -- `tasks/`
        # already separated open from closed by directory, and the ledger duplicated
        # 2,133 fichas without adding that separation. This scaffold created the OLD
        # `ledger/entries|decisions|evidence/README.md` trio until today: any repo
        # `simplecode new` produced was born with the retired design. `tasks/backlog`
        # is in the mkdir list above (it must exist even with zero fichas); this file
        # is the one still true to the current architecture. `git stores no empty
        # tree` still applies to `tasks/evidence/`, hence it's in the mkdir list too.
        "tasks/done/README.md": "# Done\n\nClosed tasks with their verification evidence.\n",
        "tasks/backlog/README.md": "# Backlog\n\nOpen tasks and their verification criteria.\n",
        "tasks/evidence/README.md": _TASKS_EVIDENCE_README,
        "gates/README.md": _GATES_README,
        # canon_adoption criterion 14 (2026-09-22, Pista 3): the one convention with no gate,
        # adopted organically by 14/18 fleet repos before it had a criterion at all -- a fresh
        # scaffold starts with the same header `/vote` already uses when it has to create this
        # file lazily, so the two paths that can produce DECISIONS.md never disagree on its
        # contract.
        "DECISIONS.md": (
            "# Decisions\n\nDurable decisions only -- not a log. One entry per decision, with "
            "the reason it was taken and what it rules out.\n"
        ),
        "pyproject.toml": _project_pyproject(name, package),
        ".pre-commit-config.yaml": compose_canonical_config(target),
        ".github/workflows/ci.yml": _ci_workflow(name, package),
        "README.md": (
            f"# {name}\n\nProject type: {project_type}. See `SPEC.md`.\n\n"
            "Evaluate an agent success report:\n\n"
            "```bash\n"
            "python .simplecode/run.py simplecode.cli success-eval report.md\n"
            "```\n"
        ),
        "Makefile": _makefile(name, package),
        ".gitignore": (
            "__pycache__/\n*.py[cod]\n*.egg-info/\nbuild/\ndist/\n.venv/\n.coverage\n"
            ".pytest_cache/\n.ruff_cache/\n.simplecode/cache/\n.simplecode/evidence/\n"
            ".simplecode/last_backlog_verdict.json\n.simplecode/audit_ledger.json\n"
            ".simplecode/coverage.json\n.simplecode/upstream_watch_state.json\n"
            ".simplecode/quarantine/\n"
            # TTL'd claim-lock state (worktree/claims.py), never product
            # material -- written every time `sync-satellites --fix` touches
            # this satellite's runtime files (satellite_sync.claims.claim()),
            # so it must be ignored from the first scaffold, not bolted on
            # after the first sync leaves it untracked
            # (DEBT-CLAIM-STATE-DIRTY-AFTER-SYNC). Kept as explicit entries,
            # not a blanket `.simplecode/*`, matching this list's own
            # enumerated style -- a blanket pattern here would also ignore
            # kit.lock/run.py/runtime.zip, which a fresh scaffold must be
            # able to `git add` untracked.
            ".simplecode/claims.json\n.simplecode/claims.json.bak\n"
        ),
        # Empty fork&own registry (ADR-0009): discoverable from day one; stays
        # green until the first harvest/vendoring, which doctor then demands
        # be registered here.
        ".simplecode/fork_own.json": (
            '{\n  "_doc": {\n'
            '    "que_es": "Fork&own manifest (ADR-0009): every external repo studied or vendored '
            'gets an entry {repo, ref, fecha_cosecha, que_se_cosecho, licencia} fixed AT the moment '
            'of reading. Watched by `simplecode upstream-check`; the tool never bumps ref -- human '
            'review does.",\n'
            '    "politica": "fork-and-own != fork-and-forget (Luis 2026-07-31)"\n'
            '  },\n  "cosechas": []\n}\n'
        ),
        f"src/{package}/__init__.py": '__version__ = "0.1.0"\n',
        f"tests/test_{package}.py": (
            f"import {package}\n\n\n"
            f"def test_version() -> None:\n    assert {package}.__version__ == \"0.1.0\"\n"
        ),
        ".simplecode/run.py": _portable_runner(),
        "docs/adr/0001-adopt-simplecode.md": textwrap.dedent(
            f'''\
            # ADR-0001: Adopt simplecode gates

            Status: Accepted
            Date: {date.today().isoformat()}

            ## Decision
            Use simplecode as the local preventive gate for {name}.
            '''
        ),
    }
    for relative, content in files.items():
        dest = target / relative
        atomic_io.write_text_durable(dest, content)
    bundle = _runtime_bundle()
    atomic_io.write_bytes_durable(target / ".simplecode" / "runtime.zip", bundle)
    atomic_io.write_bytes_durable(
        target / ".simplecode" / "kit.lock",
        kit_lock_bytes(_portable_runner(), bundle),
    )
    # DEBT-PUSH-LOOP-03 (voted by Luis 2026-09-15): declare the telemetry
    # disposition cutoff HERE, where a tracked file is written on purpose.
    # `telemetry_dispositions` used to create it on first use, and first use is
    # `build_report` -- inside the pre-push gate, so a freshly enrolled
    # satellite's first push had the gate writing a tracked file mid-run
    # (`tree_changed_during_run` + `clean_worktree`). The scaffold is one of the
    # two paths that already write tracked files deliberately; the other is
    # `satellite_sync._sync_cutoff_declaration`. Imported at module scope, not
    # lazily: measured `python -X importtime`, the module costs 2.4 ms
    # cumulative on top of what `cli_new` already imports (its own dependency
    # set is stdlib plus `atomic_io`, which `cli_new` imports anyway), against
    # 18-34 ms of run-to-run noise in `import simplecode.cli_new` itself -- a
    # lazy import here would buy a saving too small to measure.
    telemetry_dispositions.declare_cutoff(target)

    # DEBT-SURVEY-NO-CONCURRENT-OWNERSHIP (a): same reasoning as
    # `satellite_sync._sync_runtime` -- self-claim the kit's own writes so a
    # `claim_guard` check run later in this same project never reads the
    # scaffold's own runner/bundle as an unexplained foreign edit.
    for relative in (".simplecode/run.py", ".simplecode/runtime.zip"):
        claims.claim(
            target / relative, owner="simplecode-kit:new", ttl_seconds=600,
            command="simplecode new", root=target,
        )


def _run(command: list[str], target: Path) -> bool:
    result = subprocess.run(command, cwd=target, check=False, capture_output=True, text=True)
    if result.returncode == 0:
        return True
    detail = result.stderr.strip() or result.stdout.strip() or "unknown error"
    print(f"Failed: {' '.join(command)}\n{detail}")
    return False


def main(args: argparse.Namespace) -> int:
    name = args.name
    target = Path.cwd() / name
    package = args.package or name.replace("-", "_")
    project_type = args.type or "library"

    if not PROJECT_NAME.fullmatch(name):
        print(f"Invalid project name: {name}")
        return 1
    if target.exists():
        print(f"Directory {target} already exists")
        return 1
    if not package.isidentifier() or keyword.iskeyword(package):
        print(f"Invalid package name: {package}")
        return 1

    _write_project(target, name, package, project_type)
    if not _run(["git", "init", "-q"], target):
        return 1
    if not _run(["git", "add", "-A"], target):
        return 1
    if not hook_install.install_hooks(target):
        return 1

    print(f"Created {target}")
    print(f"Package: {package} ({project_type})")
    print(f"Next: cd {name} && edit SPEC.md && git add -A && make install && make check")
    return 0
