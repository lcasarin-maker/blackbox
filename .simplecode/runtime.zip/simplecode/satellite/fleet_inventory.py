# -*- coding: utf-8 -*-
"""fleet_inventory.py -- Dynamic census, categorization, and cross-project awareness for the fleet.

Discovers all projects in the fleet directory (~/projects/), inspects tech stack,
SPEC.md, simplecode gate adoption, and task backlog metrics, categorizes projects
into semantic clusters, and broadcasts shared fleet catalogs to keep sibling projects
mutually aware of the broader ecosystem.
"""
from __future__ import annotations

import argparse
import json
import logging
import re
import zipfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from simplecode.verification import hook_receipts
from simplecode.utils import atomic_io

logger = logging.getLogger(__name__)

# Excluded directory names (caches, environments, tools)
EXCLUDED_NAMES = frozenset({
    ".ruff_cache",
    ".pytest_cache",
    ".mypy_cache",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".git",
})

# Canonical Clusters
CLUSTER_LABELS = {
    "core_governance": "Núcleo y Gobernanza",
    "legal_documental": "Satélites Legales / Documentales",
    "financial_fiscal": "Satélites Financieros / Fiscales",
    "organization_media": "Satélites de Organización / Medios",
    "chat_content_network": "Satélites de Chat / Contenido / Red",
    "ai_prototypes_specialized": "Satélites de IA / Prototipos / Especializados",
    "other": "Otros Satélites",
}

# Names here that are PREFIXES of real repos rather than repos themselves. Declared
# so `test_no_cluster_map_entry_names_a_repo_that_no_longer_exists` can tell a
# living alias from a name whose subject was deleted -- without that distinction
# the ratchet would either miss deletions or convict every alias.
CLUSTER_MAP_ALIASES = frozenset({"aequitas", "descargasat"})

KNOWN_CLUSTER_MAP = {
    # Core & Governance
    "atlas": "core_governance",
    "simplecode": "core_governance",
    # Legal / Documental
    "aequitas_os": "legal_documental",
    "aequitas": "legal_documental",
    "poe_systems": "legal_documental",
    "imagen_corporativa_aequitas": "legal_documental",
    "agente_inmobiliario": "legal_documental",
    # Financial / Fiscal
    "cuenza": "financial_fiscal",
    "descargasat": "financial_fiscal",
    # Organization / Media
    "declutter": "organization_media",
    "repic": "organization_media",
    "office2office": "organization_media",
    # Chat / Content / Network
    "own_chats": "chat_content_network",
    "blog_ciudadano_x": "chat_content_network",
    "red_python": "chat_content_network",
    # AI / Prototypes / Specialized
    "qubit": "ai_prototypes_specialized",
    "twiner": "ai_prototypes_specialized",
    "maletin_homeopatia": "ai_prototypes_specialized",
    "migracion_atom": "ai_prototypes_specialized",
    "sistemas_estocasticos_ruleta": "ai_prototypes_specialized",
}


@dataclass
class ProjectEntry:
    """Detailed metadata for one project in the fleet."""

    name: str
    path: str
    cluster: str
    cluster_label: str
    is_git: bool = False
    tech_stack: list[str] = field(default_factory=list)
    description: str = ""
    has_spec: bool = False
    has_simplecode: bool = False
    runtime_version: str | None = None
    has_hooks: bool = False
    coverage_watermark: float | None = None
    tasks_backlog: int = 0
    tasks_done: int = 0
    tasks_active: int = 0
    tasks_blocked: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class FleetInventory:
    """Aggregated census of all projects in the fleet."""

    timestamp: str
    projects_dir: str
    total_projects: int
    git_repositories: int
    simplecode_adopted: int
    clusters: dict[str, int]
    projects: list[ProjectEntry] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)


def classify_cluster(name: str, path: Path | None = None) -> str:
    """Classify a project name or path into its canonical cluster."""
    norm_name = name.strip().lower().replace("-", "_")
    if norm_name in KNOWN_CLUSTER_MAP:
        return KNOWN_CLUSTER_MAP[norm_name]

    # Heuristic detection from name and contents
    if any(k in norm_name for k in ("legal", "norm", "corpus", "iure", "jur")):
        return "legal_documental"
    if any(k in norm_name for k in ("finan", "sat", "fiscal", "tax", "contab", "invoice", "cfdi")):
        return "financial_fiscal"
    if any(k in norm_name for k in ("pic", "media", "organize", "clean", "clutter", "file", "office")):
        return "organization_media"
    if any(k in norm_name for k in ("chat", "blog", "net", "web", "social", "post")):
        return "chat_content_network"
    if any(k in norm_name for k in ("ai", "rag", "model", "proto", "sim", "stoch", "atom")):
        return "ai_prototypes_specialized"

    return "other"


def _read_or_none(path: Path) -> str | None:
    """The text of `path`, or None when it is absent or unreadable. The two
    are folded on purpose HERE and nowhere else: every caller below treats
    "no such file" and "cannot read it" the same way -- try the next source --
    so each one repeated the same is_file()/try/except OSError preamble."""
    if not path.is_file():
        return None
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def _desc_from_spec(project_dir: Path) -> str | None:
    """The Objective paragraph of SPEC.md, or None when this source has no
    answer (no file, unreadable, no Objective heading, an empty paragraph, or
    a commented-out one)."""
    content = _read_or_none(project_dir / "SPEC.md")
    if content is None:
        return None
    # Extract first sentence or Objective paragraph
    m = re.search(r"##\s*1\.\s*Objective[^\n]*\n+([^\n#]+)", content, re.I)
    if not m:
        return None
    desc = m.group(1).strip()
    if not desc or desc.startswith("<!--"):
        return None
    return desc[:140].rstrip(".") + "."


def _desc_from_pyproject(project_dir: Path) -> str | None:
    """The `description = "..."` of pyproject.toml, or None when there is no
    such key.

    A key whose value is whitespace-only answers with the EMPTY STRING, not
    None, and that empty answer wins over README -- which is what the single
    function did before this split and is preserved on purpose. A refactor
    that "tidied" it into falling through to README would have changed the
    description of any repo shaped like that, silently, with no test naming
    the case. It is not defended here as good; it is preserved as measured.
    """
    content = _read_or_none(project_dir / "pyproject.toml")
    if content is None:
        return None
    m = re.search(r'description\s*=\s*["\']([^"\']+)["\']', content)
    return m.group(1).strip()[:140] if m else None


def _desc_from_readme(project_dir: Path) -> str | None:
    """The first non-heading line of README.md, or None when there is none."""
    content = _read_or_none(project_dir / "README.md")
    if content is None:
        return None
    lines = [ln.strip() for ln in content.splitlines() if ln.strip() and not ln.startswith("#")]
    return lines[0][:140].rstrip(".") + "." if lines else None


def _extract_description(project_dir: Path) -> str:
    """Extract a short description from SPEC.md, pyproject.toml, or README.md.

    ORDER IS THE CONTRACT, not an implementation detail: SPEC.md is what the
    repo says it is FOR, pyproject.toml is packaging metadata that is often a
    stale one-liner, and README.md's first line is whatever prose happened to
    be there. The first source that ANSWERS wins; a later one can never
    override it. "Answers" is None-vs-not, never truthiness, because an empty
    answer is still an answer here -- see `_desc_from_pyproject`.
    """
    for fuente in (_desc_from_spec, _desc_from_pyproject, _desc_from_readme):
        desc = fuente(project_dir)
        if desc is not None:
            return desc
    return ""


def _detect_tech_stack(project_dir: Path) -> list[str]:
    """Detect technologies and languages used in project."""
    stack = []
    if (project_dir / "pyproject.toml").is_file() or (project_dir / "requirements.txt").is_file() or list(project_dir.glob("*.py")):
        stack.append("Python")
    if (project_dir / "Cargo.toml").is_file() or list(project_dir.glob("*/Cargo.toml")):
        stack.append("Rust")
    if (project_dir / "package.json").is_file():
        stack.append("TypeScript/Node")
    if (project_dir / "Makefile").is_file():
        stack.append("Make")
    if (project_dir / "docker-compose.yml").is_file() or (project_dir / "Dockerfile").is_file():
        stack.append("Docker")
    if not stack:
        if (project_dir / "SPEC.md").is_file() or list(project_dir.glob("*.md")):
            stack.append("Markdown/Docs")
    return stack or ["Generic"]


def _get_runtime_version(simplecode_dir: Path) -> str | None:
    """Read version from .simplecode/runtime.zip manifest if present."""
    bundle = simplecode_dir / "runtime.zip"
    if not bundle.is_file():
        return None
    try:
        with zipfile.ZipFile(bundle, "r") as archive:
            manifest_bytes = archive.read("RUNTIME_MANIFEST.json")
            manifest = json.loads(manifest_bytes.decode("utf-8"))
            return str(manifest.get("simplecode_version"))
    except (OSError, KeyError, ValueError, zipfile.BadZipFile):
        return "unknown"


def _count_tasks(project_dir: Path, subdir: str) -> int:
    """Count task markdown files in a tasks/ subfolder."""
    target = project_dir / "tasks" / subdir
    if not target.is_dir():
        return 0
    try:
        return sum(1 for p in target.iterdir() if p.is_file() and p.suffix == ".md" and not p.name.startswith("."))
    except OSError:
        return 0


def _read_watermark(project_dir: Path) -> float | None:
    """Read .coverage_watermark as float."""
    p = project_dir / ".coverage_watermark"
    if not p.is_file():
        return None
    try:
        val = p.read_text(encoding="utf-8").strip()
        return float(val)
    except (OSError, ValueError):
        return None


def inspect_project(project_dir: Path) -> ProjectEntry:
    """Inspect a single project directory and extract its fleet metadata."""
    name = project_dir.name
    cluster = classify_cluster(name, project_dir)
    cluster_label = CLUSTER_LABELS.get(cluster, "Otros")
    is_git = hook_receipts.is_git_repo(project_dir)
    tech_stack = _detect_tech_stack(project_dir)
    description = _extract_description(project_dir)
    has_spec = (project_dir / "SPEC.md").is_file()

    simplecode_dir = project_dir / ".simplecode"
    has_simplecode = simplecode_dir.is_dir() or (project_dir / "src" / "simplecode").is_dir()
    runtime_version = _get_runtime_version(simplecode_dir) if simplecode_dir.is_dir() else None
    has_hooks = (project_dir / ".git" / "hooks" / "pre-commit").is_file()
    watermark = _read_watermark(project_dir)

    return ProjectEntry(
        name=name,
        path=str(project_dir.resolve()),
        cluster=cluster,
        cluster_label=cluster_label,
        is_git=is_git,
        tech_stack=tech_stack,
        description=description,
        has_spec=has_spec,
        has_simplecode=has_simplecode,
        runtime_version=runtime_version,
        has_hooks=has_hooks,
        coverage_watermark=watermark,
        tasks_backlog=_count_tasks(project_dir, "backlog"),
        tasks_done=_count_tasks(project_dir, "done"),
        tasks_active=_count_tasks(project_dir, "active"),
        tasks_blocked=_count_tasks(project_dir, "blocked"),
    )


def scan_fleet(projects_dir: Path) -> FleetInventory:
    """Scan all project directories in the fleet root."""
    import time
    projects_dir = projects_dir.resolve()
    entries: list[ProjectEntry] = []
    cluster_counts: dict[str, int] = {}

    if projects_dir.is_dir():
        for entry in sorted(projects_dir.iterdir()):
            if not entry.is_dir() or entry.name in EXCLUDED_NAMES or entry.name.startswith("."):
                continue
            item = inspect_project(entry)
            entries.append(item)
            cluster_counts[item.cluster] = cluster_counts.get(item.cluster, 0) + 1

    timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    git_count = sum(1 for e in entries if e.is_git)
    adopted_count = sum(1 for e in entries if e.has_simplecode)

    return FleetInventory(
        timestamp=timestamp,
        projects_dir=str(projects_dir),
        total_projects=len(entries),
        git_repositories=git_count,
        simplecode_adopted=adopted_count,
        clusters=cluster_counts,
        projects=entries,
    )


def generate_fleet_registry_markdown(inventory: FleetInventory) -> str:
    """Generate Markdown matrix representation for Atlas knowledge base."""
    lines = [
        "# Registro Oficial de la Flota (Fleet Projects Registry)",
        "",
        "> Este documento define el mapa oficial y dinámico de proyectos del ecosistema de Luis Casarin.",
        f"> **Censo al {inventory.timestamp}**: **{inventory.total_projects} proyectos** ({inventory.git_repositories} repositorios Git, {inventory.simplecode_adopted} satélites Simplecode).",
        "",
        "---",
        "",
        "## Resumen por Clúster",
        "",
        "| Clúster | Cantidad | Descripción |",
        "| :--- | :---: | :--- |",
    ]

    for key, label in CLUSTER_LABELS.items():
        count = inventory.clusters.get(key, 0)
        if count > 0:
            lines.append(f"| **{label}** | {count} | Clúster temático |")

    lines.extend([
        "",
        "---",
        "",
        "## Matriz Detallada de Proyectos",
        "",
        "| Proyecto | Clúster | Stack | Simplecode | Tareas (Done/Open) | Descripción |",
        "| :--- | :--- | :--- | :---: | :---: | :--- |",
    ])

    for p in sorted(inventory.projects, key=lambda x: (x.cluster, x.name)):
        sc_status = f"✓ ({p.runtime_version or 'v3'})" if p.has_simplecode else "✗"
        tasks_status = f"{p.tasks_done} / {p.tasks_backlog}"
        stack_str = ", ".join(p.tech_stack)
        desc_str = p.description or "*Sin descripción formal*"
        lines.append(f"| **{p.name}** | {p.cluster_label} | {stack_str} | {sc_status} | {tasks_status} | {desc_str} |")

    lines.extend([
        "",
        "---",
        "",
        "## Conciencia Cruzada de Flota (Cross-Project Awareness)",
        "",
        "Cada satélite con Simplecode activo almacena una copia viva de `.simplecode/fleet_catalog.json`.",
        "Esto permite que cualquier agente en cualquier satélite consulte las capacidades y contratos de sus proyectos hermanos sin alucinaciones de nombres de rutas.",
        "",
    ])

    return "\n".join(lines)


def broadcast_fleet_catalog(projects_dir: Path, inventory: FleetInventory | None = None) -> dict[str, bool]:
    """Broadcast the fleet catalog to all Simplecode satellites and update Atlas registry."""
    if inventory is None:
        inventory = scan_fleet(projects_dir)

    catalog_json = inventory.to_json()
    md_content = generate_fleet_registry_markdown(inventory)
    results: dict[str, bool] = {}

    for p in inventory.projects:
        proj_path = Path(p.path)
        # If project has simplecode adopted, write .simplecode/fleet_catalog.json
        simplecode_dir = proj_path / ".simplecode"
        if simplecode_dir.is_dir():
            try:
                catalog_file = simplecode_dir / "fleet_catalog.json"
                atomic_io.write_text_durable(catalog_file, catalog_json + "\n")
                results[p.name] = True
            except OSError as exc:
                logger.warning("Could not write fleet catalog to %s: %s", p.name, exc)
                results[p.name] = False

        # If project is Atlas, update knowledge/fleet/fleet_projects_registry.md
        if p.name.lower() == "atlas":
            atlas_kb_file = proj_path / "knowledge" / "fleet" / "fleet_projects_registry.md"
            if atlas_kb_file.parent.is_dir():
                try:
                    atomic_io.write_text_durable(atlas_kb_file, md_content)
                    results["atlas_knowledge_registry"] = True
                except OSError as exc:
                    logger.warning("Could not update Atlas fleet registry: %s", exc)
                    results["atlas_knowledge_registry"] = False

    return results


def print_fleet_summary(inventory: FleetInventory) -> None:
    """Print terminal-friendly summary table of the fleet."""
    print(f"\n=== CENSO DE FLOTA SIMPLECODE ({inventory.total_projects} Proyectos) ===")
    print(f"Ruta raíz: {inventory.projects_dir}")
    print(f"Repositorios Git: {inventory.git_repositories} · Satélites Simplecode: {inventory.simplecode_adopted}\n")

    current_cluster = ""
    for p in sorted(inventory.projects, key=lambda x: (x.cluster, x.name)):
        if p.cluster != current_cluster:
            current_cluster = p.cluster
            print(f"\n-- {p.cluster_label.upper()} ({inventory.clusters.get(p.cluster, 0)}) --")
        sc_tag = f"[SC {p.runtime_version or 'v3'}]" if p.has_simplecode else "[NO-SC]"
        stack = f"({', '.join(p.tech_stack)})"
        tasks = f"tasks:{p.tasks_done}d/{p.tasks_backlog}b"
        print(f"  {p.name:30s} {sc_tag:10s} {tasks:15s} {stack}")
    print()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="simplecode fleet",
        description="Dynamic fleet inventory, census, and cross-project awareness for Simplecode.",
    )
    parser.add_argument("--projects-dir", type=Path, default=Path.home() / "projects", help="Fleet root directory")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON inventory")
    parser.add_argument("--matrix", action="store_true", help="Emit Markdown fleet registry matrix")
    parser.add_argument("--broadcast", "--sync", action="store_true", dest="broadcast", help="Broadcast fleet catalog to all satellites & Atlas")
    args = parser.parse_args(argv)

    inventory = scan_fleet(args.projects_dir)

    if args.json:
        print(inventory.to_json())
        return 0

    if args.matrix:
        print(generate_fleet_registry_markdown(inventory))
        return 0

    if args.broadcast:
        sync_results = broadcast_fleet_catalog(args.projects_dir, inventory)
        print(f"\n=== DIFUSIÓN DE CONCIENCIA DE FLOTA ({len(sync_results)} destinos) ===")
        for target, ok in sorted(sync_results.items()):
            status = "✓ ALINEADO" if ok else "✗ ERROR"
            print(f"  [{status}] {target}")
        print()
        return 0

    print_fleet_summary(inventory)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
