# -*- coding: utf-8 -*-
"""satellite_sync.py -- Propagate and enforce canonical preventive gates across the fleet.

Cures the satellite desynchronization vulnerability where satellites run outdated
pre-commit manifests missing critical verification organs (e.g. backlog_verifier,
unselected_rules, corruption_guard).
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys
import tomllib
import zipfile
from pathlib import Path

import yaml

from simplecode import cli_new
from simplecode.utils import atomic_io, git_utils
from simplecode.verification import (
    hook_install,
    hook_local_config,
    hook_receipts,
    telemetry_dispositions,
)
from simplecode.worktree import claims

CANONICAL_PRE_COMMIT_CONFIG = cli_new._pre_commit_config()

# Repo-relative paths that a shipped hook READS. Shipping the hook without
# these makes the gate exit "config not found" forever in every satellite.
MOTHER_ROOT = Path(__file__).resolve().parents[3]
HOOK_ASSET_FILES = ("rules/custom/vices_unique.yaml",)


def _load_local_hooks(satellite: Path) -> str:
    """Project-local, opt-in extra `- repo: local` hooks a satellite adds on top
    of the canonical set (e.g. a secret scanner that only that satellite needs).

    Read from ``<satellite>/.simplecode/local_hooks.yaml``, key
    ``extra_hooks`` -- a RAW YAML block (the satellite's own hook entries,
    indented to match the canonical ``hooks:`` list) concatenated verbatim
    rather than parsed and re-serialized, because drift detection below is
    byte-exact. Absent file/key -> no extra hooks, same opt-in pattern as
    corpus_exempt.yaml.

    Any YAML block-scalar style works (bare ``|`` or an explicit ``|2``
    indentation indicator) -- `_compose_canonical_config` re-indents whatever
    comes out of the YAML read to the canonical hooks: list's own
    indentation, so the raw indentation surviving the parse doesn't matter.
    It used to: a plain ``|`` dedents to column 0 on read, landing every hook
    OUTSIDE the `hooks:` list it's meant to extend, so the composed config
    failed to parse ("expected <block end>, but found '-'") unless the author
    knew to write ``|2`` instead -- measured authoring this file for Atlas,
    2026-08-25, before the re-indent step existed.

    Extra hooks are appended AFTER the canonical set, always -- there is no
    way to interleave one in the middle of the canonical list. A satellite
    whose removed hooks used to sit between two canonical ones (as Atlas's
    did) gets them back at the end instead: a change in execution order, not
    coverage, but a gate's order can be observable, so note it if the
    satellite has cross-hook ordering dependencies.

    Before this existed, `_sync_config_file` compared a satellite's config
    against ONE global canonical string and rewrote the whole file on any
    mismatch, so a satellite-added hook was indistinguishable from drift and
    the next sync silently deleted it -- measured on Atlas 2026-08-25:
    sync-satellites --fix removed its secret-credential scanner twice in one
    day, and the check that "should" have caught the gap didn't, because the
    hooks that vanished simply stopped running instead of failing.
    """
    config = satellite / ".simplecode" / "local_hooks.yaml"
    if not config.is_file():
        return ""
    try:
        data = yaml.safe_load(config.read_text(encoding="utf-8")) or {}
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return ""
    if not isinstance(data, dict):
        return ""
    extra = data.get("extra_hooks", "")
    return extra if isinstance(extra, str) else ""


_HOOK_LIST_INDENT = "      "  # matches "      - id: ruff" in _pre_commit_config()


_HOOK_START_RE = re.compile(r"^      - id: (\S+)\s*$")
_HOOK_COMMENT_RE = re.compile(r"^      #")
_HOOK_FIELD_INDENT = "        "


def _hook_block_bounds(lines: list[str], start: int) -> tuple[int, int]:
    """The (first, last+1) line indices of the hook block beginning at `start`.

    Grows UPWARD over the contiguous comment run and blank separator above the
    `- id:` line, because that comment describes this hook and nothing else --
    leaving it behind would produce a paragraph explaining a hook that is no
    longer there, which is the dead-pointer shape the tombstone gate exists for.
    Grows DOWNWARD over the hook's own fields (indented deeper than the `- id:`
    line) and stops at the first line that is neither blank nor a field, so
    anything following the hooks list survives untouched.
    """
    top = start
    while top - 1 >= 0 and _HOOK_COMMENT_RE.match(lines[top - 1]):
        top -= 1
    while top - 1 >= 0 and not lines[top - 1].strip():
        top -= 1
    end = start + 1
    last_content = end
    while end < len(lines):
        line = lines[end]
        if line.strip() and not line.startswith(_HOOK_FIELD_INDENT):
            break
        end += 1
        if line.strip():
            last_content = end
    return top, last_content


def _strip_hooks_without_subject(config_text: str, satellite: Path) -> tuple[str, list[str]]:
    """Drop hooks whose `--subdir` does not exist here, and say which.

    Announcing a blind hook was the first half (`HOOK_WITHOUT_SUBJECT`); this is
    the half declutter actually asked for, and the reason it had to follow:
    until 2026-09-02 the shipped template CLAIMED this refusal existed while the
    code only warned. Atlas received `growth-ratchet --subdir src/simplecode`
    and that false claim in the same patch (their `757329ea`, sync of 19:34) --
    two organs asserting the same thing and disagreeing, with the comment
    winning because nobody re-reads code to check a comment.

    Byte-exact drift detection still works because the removal is applied to
    the EXPECTED text as well: a satellite keeping the hook now differs from
    what it should have, and `--fix` takes it out.
    """
    doomed = {row.split(" ", 1)[0] for row in _hooks_without_subject(config_text, satellite)}
    if not doomed:
        return config_text, []
    lines = config_text.splitlines()
    drop: set[int] = set()
    removed: list[str] = []
    for i, line in enumerate(lines):
        match = _HOOK_START_RE.match(line)
        if match is None or match.group(1) not in doomed:
            continue
        top, end = _hook_block_bounds(lines, i)
        drop.update(range(top, end))
        removed.append(match.group(1))
    if not removed:
        return config_text, []
    kept = "\n".join(ln for i, ln in enumerate(lines) if i not in drop)
    return kept.rstrip("\n") + "\n", sorted(removed)


def _reindent_extra_hooks(extra: str) -> str:
    """Re-indent a raw `extra_hooks:` block to canonical's own hook-list
    indentation (`_HOOK_LIST_INDENT`), regardless of how the satellite's
    local_hooks.yaml happened to be written.

    A plain YAML `|` block scalar dedents its content to column 0 on read, so
    appending it verbatim (the original approach) landed every extra hook
    OUTSIDE the `hooks:` list it was meant to extend -- the composed file
    didn't parse. Re-indenting programmatically here means the author never
    needs the `|2`-vs-`|` indentation-indicator incantation to get this
    right; whatever indentation survived the YAML read is discarded and
    replaced with the one indentation that is actually correct.
    """
    lines = extra.splitlines()
    base_indent = min((len(ln) - len(ln.lstrip(" ")) for ln in lines if ln.strip()), default=0)
    return "\n".join(
        f"{_HOOK_LIST_INDENT}{ln[base_indent:]}" if ln.strip() else "" for ln in lines
    )


def _extra_hook_ids(reindented_extra: str) -> set[str]:
    """Hook ids declared in a satellite's (already reindented) extra_hooks
    block -- `_hook_ids` cannot be reused here, it requires a full,
    parseable pre-commit-config document (`repos:` / `hooks:`), and
    `extra_hooks:` is a bare hooks-list fragment with no such wrapper."""
    return {
        m.group(1)
        for line in reindented_extra.splitlines()
        if (m := _HOOK_START_RE.match(line))
    }


def _drop_hooks_shadowed_by_canonical(reindented_extra: str, canonical: str) -> tuple[str, list[str]]:
    """Remove extra_hooks blocks whose id the canonical config already
    declares, and say which.

    A hook that used to live only in a satellite's `local_hooks.yaml`,
    because the mother did not yet ship it, can be promoted into the
    canonical template later -- `pii-scan` was, after DGX-468. Composing
    canonical + extra unconditionally then leaves the satellite's
    `.pre-commit-config.yaml` with two `id: pii-scan` entries: pre-commit
    accepts that silently (duplicate ids are valid YAML across separate list
    items) and runs whichever it feels like, with the satellite's own copy --
    and whatever historical justification it carried for living outside the
    canonical file -- now stale and misleading right next to the new one.
    Reported by Atlas, DGX-475, 2026-09-06.

    Canonical wins: it is the more current wiring, and the satellite's own
    copy is the one that has become redundant.
    """
    shadowed = _extra_hook_ids(reindented_extra) & _hook_ids(canonical)
    if not shadowed:
        return reindented_extra, []
    lines = reindented_extra.splitlines()
    drop: set[int] = set()
    removed: list[str] = []
    for i, line in enumerate(lines):
        match = _HOOK_START_RE.match(line)
        if match is None or match.group(1) not in shadowed:
            continue
        top, end = _hook_block_bounds(lines, i)
        drop.update(range(top, end))
        removed.append(match.group(1))
    kept = "\n".join(ln for i, ln in enumerate(lines) if i not in drop)
    return (kept.rstrip("\n") + "\n" if kept.strip() else ""), sorted(removed)


def _extra_hooks_shadowed_by_canonical(satellite: Path) -> list[str]:
    """The ids `_compose_canonical_config` drops from this satellite's
    `local_hooks.yaml` because the canonical template now declares them too
    -- for `_sync_config_file` to announce, the same way it already
    announces a withheld or blind hook."""
    canonical, _removed = _strip_hooks_without_subject(CANONICAL_PRE_COMMIT_CONFIG, satellite)
    extra = _load_local_hooks(satellite)
    if not extra.strip():
        return []
    _, shadowed = _drop_hooks_shadowed_by_canonical(_reindent_extra_hooks(extra), canonical)
    return shadowed


_STAGES_FIELD_RE = re.compile(r"^\s*stages:\s*\[([^\]]*)\]", re.MULTILINE)


def _hook_semantic_summary(block_text: str) -> str:
    """One-line stage + blocking read of a hook's own YAML block.

    DGX-487 (Atlas, 2026-09-08): `_compose_canonical_config` silently drops a
    satellite's local override on id collision -- a settled decision
    (canonical wins, DGX-475) -- but said NOTHING about what the collision
    actually changes. Atlas measured a real case where canon's `pii-scan`
    runs at `pre-push` while their local copy ran at `pre-commit` (blocking
    every commit, not just the push), and had to read both YAML blocks by
    hand to find that out. This is the read, done once, for the message to
    quote instead of making every operator repeat the archaeology.
    """
    match = _STAGES_FIELD_RE.search(block_text)
    stages = f"stages=[{match.group(1).strip()}]" if match else "no stages: declared (runs on every installed hook stage, including pre-commit)"
    blocking = "non-blocking (|| true)" if "|| true" in block_text else "blocking"
    return f"{stages}, {blocking}"


def _shadowed_hook_semantic_diff(satellite: Path, hook_id: str) -> str:
    """`" -- differs: <local> vs canonical <canon>"` when the shadowed local
    hook and the canonical one that replaces it disagree on stage or
    blocking behavior; "" when they match (a pure duplicate, safe to drop
    without a second look)."""
    canonical, _removed = _strip_hooks_without_subject(CANONICAL_PRE_COMMIT_CONFIG, satellite)
    extra = _reindent_extra_hooks(_load_local_hooks(satellite))
    local_block = _hook_block_text(extra, hook_id)
    canonical_block = _hook_block_text(canonical, hook_id)
    if not local_block or not canonical_block:
        return ""
    local_summary = _hook_semantic_summary(local_block)
    canonical_summary = _hook_semantic_summary(canonical_block)
    def execution_policy(block: str) -> tuple[str, ...]:
        return tuple(
            line.strip() for line in block.splitlines()
            if line.strip()
            and not line.lstrip().startswith("#")
            and not re.match(r"(?:id|name):\s*", line.strip())
        )

    if execution_policy(local_block) == execution_policy(canonical_block):
        return ""
    return (f" -- SEMANTIC DIFFERENCE, verify before dropping: local ({local_summary}) "
            f"vs canonical ({canonical_summary}); execution-affecting hook fields differ")


def _semantic_local_hook_collisions(satellite: Path) -> list[str]:
    """Ids whose local declaration would lose a meaningful policy in sync.

    Duplicate ids with identical execution policy are stale copies and may be
    deduplicated. A duplicate that changes any hook field is an override, not
    drift. The composer cannot retain both entries because
    pre-commit permits duplicate ids without defining which one wins, so the
    safe outcome is to refuse the sync and require the project to give its
    stricter local policy a distinct, documented id.
    """
    return [
        hook_id
        for hook_id in _extra_hooks_shadowed_by_canonical(satellite)
        if _shadowed_hook_semantic_diff(satellite, hook_id)
    ]


def compose_canonical_config(satellite: Path) -> str:
    """Canonical config + this satellite's opt-in extra hooks, if any.

    An extra hook whose id the canonical template has since absorbed is
    dropped from the extra block (see `_drop_hooks_shadowed_by_canonical`),
    so the composed file never carries the same id twice.
    """
    canonical, _removed = _strip_hooks_without_subject(CANONICAL_PRE_COMMIT_CONFIG, satellite)
    extra = _load_local_hooks(satellite)
    if not extra.strip():
        return canonical
    reindented, _shadowed = _drop_hooks_shadowed_by_canonical(_reindent_extra_hooks(extra), canonical)
    if not reindented.strip():
        return canonical
    return canonical.rstrip("\n") + "\n" + reindented + "\n"


# Compatibility for existing kit consumers.
_compose_canonical_config = compose_canonical_config

def discover_satellites(projects_dir: Path) -> list[Path]:
    """Legacy library helper for ad-hoc tests and one-off recovery.

    The CLI does not use discovery: production fleet membership lives in
    ``fleet.toml``.  Scanning a directory makes an unrelated checkout become a
    managed satellite without an operator enrolling it.
    """
    satellites = []
    if not projects_dir.is_dir():
        return satellites
    for entry in sorted(projects_dir.iterdir()):
        if entry.is_dir() and hook_receipts.is_git_repo(entry) and entry.name != "simplecode":
            satellites.append(entry)
    return satellites


def enrolled_satellites(projects_dir: Path, manifest: Path | None = None) -> list[Path]:
    """Return only satellites explicitly enrolled in the checked-in manifest."""
    manifest = manifest or MOTHER_REPO_ROOT / "fleet.toml"
    try:
        data = tomllib.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, tomllib.TOMLDecodeError) as exc:
        raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: {exc})") from exc
    rows = data.get("satellite")
    if not isinstance(rows, list):
        raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: missing [[satellite]])")
    names: list[str] = []
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("name"), str):
            raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: each satellite needs name)")
        name = row["name"]
        if name in names:
            raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: duplicate satellite {name})")
        names.append(name)
    satellites: list[Path] = []
    for name in names:
        candidate = projects_dir / name
        if not hook_receipts.is_git_repo(candidate):
            raise ValueError(f"FLEET_MEMBER_UNAVAILABLE ({name}: {candidate})")
        satellites.append(candidate)
    return satellites


def enrolled_python_product_scope(
    manifest: Path | None = None,
) -> dict[str, bool]:
    """Read the reviewed product-applicability declaration for every fleet row.

    A satellite's own tests, gates, and maintenance scripts do not make it a
    Python product. The fleet inventory must say so explicitly; missing or
    malformed declarations stop a fleet sync before it writes anything.
    """
    manifest = manifest or MOTHER_REPO_ROOT / "fleet.toml"
    try:
        data = tomllib.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, tomllib.TOMLDecodeError) as exc:
        raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: {exc})") from exc
    rows = data.get("satellite")
    if not isinstance(rows, list):
        raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: missing [[satellite]])")
    scope: dict[str, bool] = {}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("name"), str):
            raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: each satellite needs name)")
        name = row["name"]
        product_python = row.get("python_product")
        if name in scope:
            raise ValueError(f"FLEET_MANIFEST_REFUSED ({manifest}: duplicate satellite {name})")
        if not isinstance(product_python, bool):
            raise ValueError(
                f"FLEET_MANIFEST_REFUSED ({manifest}: {name} needs python_product = true|false)"
            )
        scope[name] = product_python
    return scope


def sync_scoped_satellite(
    satellite: Path, *, python_product: bool, apply_fix: bool, runtime_only: bool = False,
) -> tuple[bool, str]:
    """Leave a reviewed non-Python product untouched; sync applicable repos normally."""
    if not python_product:
        return True, "OUT_OF_SCOPE_NO_PYTHON_PRODUCT (no satellite files written)"
    return sync_satellite(satellite, apply_fix=apply_fix, runtime_only=runtime_only)


def _ensure_hook_installed_and_executable(satellite: Path, apply_fix: bool) -> tuple[bool, str]:
    """Verify all four canonical Git launchers."""
    # `git_hooks_dir`, not `satellite / ".git" / "hooks"`: in a worktree `.git`
    # is a FILE and that path does not exist, so the launchers landed nowhere.
    hooks_dir = hook_receipts.git_hooks_dir(satellite)
    if hooks_dir is None:
        return False, "NOT_A_GIT_REPO (no .git directory, file pointer, or resolvable common dir)"
    if not hooks_dir.is_dir():
        if not apply_fix:
            return False, "NO .git/hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)

    defect = _hook_defect(satellite, hooks_dir)
    if not defect:
        return True, "HOOK_OK"
    if not apply_fix:
        return False, defect
    status = {
        "HOOK_MISSING": "HOOK_INSTALLED",
        "HOOK_HAS_CRLF": "HOOK_CRLF_FIXED",
        "HOOK_NOT_EXECUTABLE": "HOOK_CHMOD_FIXED",
    }.get(defect, "HOOK_UPDATED")
    return (True, status) if hook_install.install_hooks(satellite) else (False, "HOOK_INSTALL_FAILED")


def _hook_defect(satellite: Path, hooks_dir: Path) -> str:
    """Return the first launcher defect, or an empty string when aligned.

    Compares each installed launcher against hook_install's OWN generator
    byte-for-byte, not a substring probe. A `"simplecode.verification.
    gate_runner" not in content` check passes for any hand-edited or stale
    hook that happens to still mention that string ANYWHERE -- e.g. in a
    comment -- which is exactly the failure mode a drift check exists to
    catch: a test that cannot fail against the case that matters is not a
    test (Atlas dogfooding, 2026-08-24, four unrelated instances of the same
    root cause the same day)."""
    hook_file = hooks_dir / "pre-commit"
    if not hook_file.is_file():
        return "HOOK_MISSING"

    data = hook_file.read_bytes()
    if b"\r\n" in data:
        return "HOOK_HAS_CRLF"

    if not os.access(hook_file, os.X_OK):
        return "HOOK_NOT_EXECUTABLE"

    expected = {
        "pre-commit": hook_install._launcher(satellite, "pre-commit"),
        "pre-merge-commit": hook_install._launcher(satellite, "pre-commit"),
        "pre-push": hook_install._launcher(satellite, "pre-push"),
        "post-commit": hook_install._post_commit(satellite),
    }
    missing = [name for name in expected if not (hooks_dir / name).is_file()]
    nonexecutable = [name for name in expected if (hooks_dir / name).is_file()
                     and not os.access(hooks_dir / name, os.X_OK)]
    mismatched = [
        name
        for name, want in expected.items()
        if (hooks_dir / name).is_file()
        and (hooks_dir / name).read_text(encoding="utf-8", errors="replace") != want
    ]
    drifted = bool(missing) or bool(mismatched) or bool(nonexecutable)
    if drifted:
        reason = ", ".join(missing + [f"{name} content mismatch" for name in mismatched]
                           + [f"{name} not executable" for name in nonexecutable])
        return f"HOOK_DRIFTED ({reason})"
    return ""


_MARKER_DESCRIPTIONS = cli_new.PYTEST_MARKER_DESCRIPTIONS
CANONICAL_MARKERS = tuple(_MARKER_DESCRIPTIONS)
CANONICAL_MARKER_DESCRIPTIONS = _MARKER_DESCRIPTIONS
CANONICAL_PYTEST_INI = (
    "[pytest]\ntestpaths = tests\npythonpath = .\nmarkers =\n"
    + "".join(f"    {key}: {value}\n" for key, value in _MARKER_DESCRIPTIONS.items())
    + 'addopts = -m "not slow and not e2e" --tb=short\n'
)
_TOML_MARKERS_BLOCK = (
    "markers = [\n"
    + "".join(f'    "{key}: {value}",\n' for key, value in _MARKER_DESCRIPTIONS.items())
    + "]"
)

# The mother repo itself: satellite conformance is meaningless if the repo
# that defines the canonical standard does not meet it (GS2-215, repo self-check).
MOTHER_REPO_ROOT = Path(__file__).resolve().parents[3]


def _harness_gaps(txt: str) -> list[str]:
    """Return which canonical GS2-215 requirements a pytest config's text is missing.

    Checked by simple substring presence, matching the existing (pre-existing)
    style of this module's drift detection -- good enough to catch an absent
    `pythonpath` key or an absent/incomplete tiered `markers` set without a
    full TOML/INI parse.
    """
    gaps = []
    if "pythonpath" not in txt:
        gaps.append("pythonpath")
    if "markers" not in txt or any(f"{name}:" not in txt for name in CANONICAL_MARKERS):
        gaps.append("markers")
    return gaps


def _resolve_baseline_coverage(satellite: Path) -> float:
    """Resolve the coverage watermark baseline for a satellite.

    Reads the satellite's own measured `coverage.json` artifact when one is
    present (produced by `coverage json` after a test run) so the watermark
    reflects reality. When no measurement exists yet -- e.g. first sync of a
    brand-new satellite -- falls back to the fixed fleet policy floor
    (coverage_ratchet.DEFAULT_FLOOR). This is a fallback floor, not a
    dynamically resolved value: it never claims to measure anything.
    """
    from simplecode.worktree import coverage_ratchet

    measured = coverage_ratchet.extract_coverage_from_json(satellite / "coverage.json")
    return measured if measured is not None else coverage_ratchet.DEFAULT_FLOOR


def _sync_watermark_file(satellite: Path, apply_fix: bool) -> list[str]:
    """Ensure .coverage_watermark exists in satellite with dynamic baseline."""
    watermark_file = satellite / ".coverage_watermark"
    if not watermark_file.is_file():
        if apply_fix:
            baseline = _resolve_baseline_coverage(satellite)
            atomic_io.write_text_durable(watermark_file, f"{baseline:.2f}\n")
            return ["WATERMARK_INITIALIZED"]
        return ["WATERMARK_MISSING"]
    return []


def _sync_cutoff_declaration(satellite: Path, apply_fix: bool) -> list[str]:
    """Ensure the satellite has DECLARED its telemetry disposition cutoff.

    DEBT-PUSH-LOOP-03 (voted by Luis 2026-09-15): a gate does not write tracked
    files. `telemetry_dispositions` used to create
    `.simplecode/telemetry_disposition_cutoff.json` -- tracked, by an explicit
    `.gitignore` exception -- on first use, and first use is `build_report`,
    which runs inside the pre-push gate. Measured on the fleet the same day: 7
    of 18 satellites had no cutoff file, so each one's first pre-push would have
    had the gate write a tracked file mid-run, tripping
    `gate_runner._working_tree_fingerprint` (`tree_changed_during_run`) and
    `clean_worktree`. So the declaration moves here, to a deliberate `--fix`,
    which is already where tracked files get written on purpose -- same
    reasoning and same shape as :func:`_sync_watermark_file` above.

    A MALFORMED declaration is reported and left exactly as it is. Repairing it
    here would be the identical fault in a new place: an unattended write over a
    tracked file whose content nobody has looked at, moving the cutoff of that
    repo's entire history. A human repairs it; the gate meanwhile says
    COULD_NOT_RUN and prints the command.
    """
    try:
        declared = telemetry_dispositions.read_cutoff(satellite)
    except telemetry_dispositions.CutoffMalformed as exc:
        return [f"CUTOFF_REFUSED_MALFORMED ({exc})"]
    if declared is not None:
        return []
    if not apply_fix:
        return ["CUTOFF_MISSING (telemetry_disposition_cutoff.json undeclared)"]
    telemetry_dispositions.declare_cutoff(satellite)
    return ["CUTOFF_DECLARED"]


_MARKERS_LINE_RE = re.compile(r"^[ \t]*markers[ \t]*=[ \t]*$", re.M)


def _merge_missing_markers(txt: str, missing_names: tuple[str, ...]) -> str | None:
    """Insert missing canonical marker lines into an EXISTING ``markers =``
    block instead of appending a second ``markers`` key.

    INI keys are unique -- a duplicate raises configparser's
    DuplicateOptionError and breaks every test collection in the satellite,
    not just the gap this was meant to close. Measured live on Atlas and
    office2office: both already declared a partial markers block (their own
    project markers plus some but not all of the canonical four), and the
    old append-a-fresh-block path duplicated the key and broke `pytest
    --collect-only` fleet-wide for them. Returns None when no confidently
    line-anchored ``markers =`` block is found, so the caller falls back to
    appending a brand new block (the correct move when there is none yet).
    """
    match = _MARKERS_LINE_RE.search(txt)
    if match is None:
        return None
    lines = txt.splitlines(keepends=True)
    offset = 0
    start_idx = 0
    for i, line in enumerate(lines):
        if offset <= match.start() < offset + len(line):
            start_idx = i
            break
        offset += len(line)
    end_idx = start_idx + 1
    while end_idx < len(lines) and lines[end_idx].strip() and lines[end_idx][0] in " \t":
        end_idx += 1
    insertion = "".join(
        f"    {name}: {CANONICAL_MARKER_DESCRIPTIONS[name]}\n" for name in missing_names
    )
    return "".join(lines[:end_idx]) + insertion + "".join(lines[end_idx:])


def _fix_pytest_ini_gaps(pytest_ini: Path, txt: str, gaps: list[str]) -> None:
    """Close the missing canonical GS2-215 keys in an INI-style pytest.ini.

    Unlike the pyproject.toml path there is no stdlib validator for the ``.ini``
    dialect configparser/pytest accept, so we cannot cheaply prove the result
    still parses. What we CAN do -- and do -- is take a durable ``.bak`` of the
    satellite's original before overwriting it (``backup=True``), so an edit
    that turns out wrong is recoverable via :func:`atomic_io.restore_from_backup`.
    """
    new_txt = txt.rstrip() + "\n"
    if "pythonpath" in gaps:
        new_txt += "pythonpath = .\n"
    if "markers" in gaps:
        missing = tuple(name for name in CANONICAL_MARKERS if f"{name}:" not in txt)
        merged = _merge_missing_markers(new_txt, missing) if missing else None
        if merged is not None:
            new_txt = merged
        else:
            new_txt += (
                "markers =\n"
                "    unit: Fast unit tests (<= 0.2s)\n"
                "    integration: Integration tests (<= 2.0s)\n"
                "    slow: Slow tests (> 2.0s)\n"
                "    e2e: End-to-end and browser tests\n"
            )
    atomic_io.write_text_durable(pytest_ini, new_txt, backup=True)


HARNESS_FIX_REFUSED_MALFORMED = "HARNESS_FIX_REFUSED_MALFORMED"


def _fix_pyproject_gaps(pyproject_toml: Path, txt: str, gaps: list[str], satellite: Path) -> list[str]:
    """Insert the missing canonical GS2-215 keys into [tool.pytest.ini_options].

    Fail-closed against corrupting a FOREIGN repo's build config under fleet
    ``--fix``. The header is matched by naive ``str.replace``, which can inject
    keys into an unintended position (e.g. a matching substring inside a string
    value) and produce invalid TOML. So:

      1. If the ORIGINAL text does not already parse as TOML, refuse -- we will
         not layer an edit onto an already-broken file.
      2. Build ``new_txt`` and re-validate it with :func:`tomllib.loads`; if the
         result would not parse, refuse.

    On refusal the satellite's ``pyproject.toml`` is left byte-for-byte
    untouched and ``[HARNESS_FIX_REFUSED_MALFORMED]`` is recorded (loud, fails
    closed) instead of the ``_ADDED`` statuses. When we do write, ``backup=True``
    preserves the original at ``<path>.bak`` so the applied edit is recoverable.

    A satellite that already declares SOME but not all canonical markers under
    its own wording (measured on aequitas_os, 2026-08-25: unit/integration/slow
    present, e2e missing) hits the header-insertion path for a SECOND `markers
    = [...]` key -- invalid TOML (duplicate key), correctly caught by the
    re-parse below, but with the pyproject already valid, that refusal has no
    augmentation path to ever un-stick it; see `_augment_markers`, which
    inserts only the missing marker lines into the existing array instead.
    """
    try:
        tomllib.loads(txt)
    except tomllib.TOMLDecodeError:
        return [HARNESS_FIX_REFUSED_MALFORMED]

    source_root = "src" if (satellite / "src").is_dir() else "."
    new_txt = txt
    if "pythonpath" in gaps:
        new_txt = new_txt.replace(
            "[tool.pytest.ini_options]",
            f'[tool.pytest.ini_options]\npythonpath = ["{source_root}"]',
        )
    if "markers" in gaps:
        new_txt = _augment_markers(new_txt)

    try:
        tomllib.loads(new_txt)
    except tomllib.TOMLDecodeError:
        return [HARNESS_FIX_REFUSED_MALFORMED]

    atomic_io.write_text_durable(pyproject_toml, new_txt, backup=True)
    return [f"HARNESS_{gap.upper()}_ADDED" for gap in gaps]


def _augment_markers(txt: str) -> str:
    """Add any missing CANONICAL_MARKERS lines to an EXISTING `markers = [...]`
    array; falls back to inserting the full canonical block after the table
    header when no `markers = [` array exists at all yet."""
    match = re.search(r"^markers\s*=\s*\[", txt, re.M)
    if match is None:
        return txt.replace(
            "[tool.pytest.ini_options]",
            "[tool.pytest.ini_options]\n" + _TOML_MARKERS_BLOCK,
        )
    close = txt.find("]", match.end())
    if close == -1:
        return txt
    existing = txt[match.end() : close]
    missing = [name for name in CANONICAL_MARKERS if f"{name}:" not in existing]
    if not missing:
        return txt
    addition = "".join(f'\n    "{name}: {_MARKER_DESCRIPTIONS[name]}",' for name in missing)
    return txt[:close] + addition + "\n" + txt[close:]


def _read_config_text(path: Path) -> tuple[str | None, list[str]]:
    """Read a harness config as strict UTF-8, refusing to silently drop bytes.

    The prior code used ``errors="ignore"``, which would silently discard
    undecodable bytes and then edit the mangled remainder -- exactly the kind of
    quiet corruption M5b hardens against. Here an undecodable file yields a loud
    ``HARNESS_UNDECODABLE`` status and no edit, rather than a silent partial read.
    """
    try:
        return path.read_text(encoding="utf-8"), []
    except UnicodeDecodeError:
        return None, ["HARNESS_UNDECODABLE"]


def _sync_pytest_ini(pytest_ini: Path, apply_fix: bool) -> list[str]:
    """Resolve GS2-215 gaps for an INI-style pytest.ini (loud skip if undecodable)."""
    txt, read_err = _read_config_text(pytest_ini)
    if txt is None:
        return read_err
    gaps = _harness_gaps(txt)
    if not gaps:
        return []
    if not apply_fix:
        return [f"HARNESS_MISSING_{gap.upper()}" for gap in gaps]
    _fix_pytest_ini_gaps(pytest_ini, txt, gaps)
    return [f"HARNESS_{gap.upper()}_ADDED" for gap in gaps]


def _sync_pyproject(pyproject_toml: Path, satellite: Path, apply_fix: bool) -> list[str] | None:
    """Resolve GS2-215 gaps for a pyproject.toml [tool.pytest.ini_options] table.

    Returns ``None`` when this pyproject declares no pytest table (caller falls
    through to installing a canonical pytest.ini, preserving prior behavior).
    Loud skip if the file is undecodable; fail-closed refusal (via
    :func:`_fix_pyproject_gaps`) if the edit would produce malformed TOML.
    """
    txt, read_err = _read_config_text(pyproject_toml)
    if txt is None:
        return read_err
    if "[tool.pytest.ini_options]" not in txt:
        return None
    gaps = _harness_gaps(txt)
    if not gaps:
        return []
    if not apply_fix:
        return [f"HARNESS_MISSING_{gap.upper()}" for gap in gaps]
    return _fix_pyproject_gaps(pyproject_toml, txt, gaps, satellite)


def _sync_harness_config(satellite: Path, apply_fix: bool) -> list[str]:
    """Ensure repository has valid pytest pythonpath and tiered marker configuration (GS2-215)."""
    pytest_ini = satellite / "pytest.ini"
    pyproject_toml = satellite / "pyproject.toml"

    if pytest_ini.is_file():
        return _sync_pytest_ini(pytest_ini, apply_fix)

    if pyproject_toml.is_file():
        result = _sync_pyproject(pyproject_toml, satellite, apply_fix)
        if result is not None:
            return result

    if apply_fix:
        atomic_io.write_text_durable(pytest_ini, CANONICAL_PYTEST_INI)
        return ["HARNESS_INSTALLED"]
    return ["MISSING_HARNESS"]


def _hooks_without_subject(config_text: str, satellite: Path) -> list[str]:
    """Hooks citing a `--subdir` that does not exist in the target repo.

    A hook pointed at an absent directory measures nothing. When it is also
    advisory it never blocks, so nobody looks and it stays installed and blind
    for as long as it exists. Reported by declutter 2026-09-01, the day it
    shipped: `growth-ratchet` carries `--subdir src/simplecode`, which is the
    mother repo's own source tree and exists in none of the satellites.

    `gate-effectiveness`, shipped in the same commit to catch instruments that
    never convict, is blind to this one by construction -- an organ measuring
    an absent subject emits no telemetry row, so a per-organ counter has nothing
    to count. Same shape as shipping a hook without the config it reads: the
    capability arrives, its subject does not.
    """
    try:
        data = yaml.safe_load(config_text) or {}
    except yaml.YAMLError:
        return []
    if not isinstance(data, dict):
        return []
    faltan = []
    for repo in data.get("repos", []) or []:
        if not isinstance(repo, dict):
            continue
        for hook in repo.get("hooks", []) or []:
            if not isinstance(hook, dict):
                continue
            tokens = " ".join((hook.get("entry") or "").split()).split()
            for i, tok in enumerate(tokens):
                if tok == "--subdir" and i + 1 < len(tokens):
                    if not (satellite / tokens[i + 1]).is_dir():
                        faltan.append(f"{hook.get('id', '?')} (--subdir {tokens[i + 1]})")
    return faltan


def _hook_ids(config_text: str) -> set[str]:
    """Every hook id declared in a pre-commit config, or empty if unparseable.

    Unparseable yields the empty set on purpose: it makes the caller report NO
    removals rather than claim every hook is about to be deleted. A wrong alarm
    over a file we could not read would train the reader to ignore the real one.
    """
    try:
        data = yaml.safe_load(config_text) or {}
    except yaml.YAMLError:
        return set()
    if not isinstance(data, dict):
        return set()
    return {
        h["id"]
        for repo in data.get("repos", []) or []
        if isinstance(repo, dict)
        for h in repo.get("hooks", []) or []
        if isinstance(h, dict) and "id" in h
    }


def _hook_block_text(config_text: str, hook_id: str) -> str:
    """The verbatim config lines of one hook, or "" when it cannot be located."""
    lines = config_text.splitlines()
    for i, line in enumerate(lines):
        match = _HOOK_START_RE.match(line)
        if match is not None and match.group(1) == hook_id:
            top, end = _hook_block_bounds(lines, i)
            return "\n".join(lines[top:end]).strip("\n")
    return ""


def _local_config_error(satellite: Path) -> str | None:
    path = satellite / ".simplecode" / "local_hooks.yaml"
    if not path.exists():
        return None
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("extra_hooks", ""), str):
            return "expected a mapping with an extra_hooks string"
        hooks = yaml.safe_load(data.get("extra_hooks", ""))
        if hooks is not None and (not isinstance(hooks, list) or any(
            not isinstance(h, dict) or not isinstance(h.get("id"), str)
            or not isinstance(h.get("entry"), str) for h in hooks
        )):
            return "extra_hooks must declare a YAML list of hooks with id and entry"
    except (OSError, UnicodeError, yaml.YAMLError) as exc:
        return str(exc)
    return None


def _sync_config_file(config_file: Path, apply_fix: bool) -> list[str]:
    """Check or update the .pre-commit-config.yaml file (canonical + this
    satellite's opt-in extra hooks from .simplecode/local_hooks.yaml, if any)."""
    error = _local_config_error(config_file.parent)
    if error:
        return [f"LOCAL_CONFIG_REFUSED ({error})"]
    semantic_collisions = _semantic_local_hook_collisions(config_file.parent)
    if semantic_collisions:
        details = "; ".join(
            f"{hook_id}{_shadowed_hook_semantic_diff(config_file.parent, hook_id)}"
            for hook_id in semantic_collisions
        )
        return [
            "SEMANTIC_LOCAL_HOOK_REFUSED "
            f"({details}) -- canonical sync would discard a project policy; "
            "rename the documented local override to a project-specific id "
            "or adopt the canonical semantics"
        ]
    expected = _compose_canonical_config(config_file.parent)
    if not config_file.is_file():
        if apply_fix:
            atomic_io.write_text_durable(config_file, expected)
            return ["CONFIG_INSTALLED"]
        return ["MISSING_CONFIG"]

    try:
        current = config_file.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        return [f"CONFIG_REFUSED ({exc})"]
    # Computed even when the file needs no rewrite: `_compose_canonical_config`
    # already dropped the shadowed id from `expected` on its own, silently, so
    # a satellite whose config happens to already match `expected` byte-for-
    # byte would otherwise report nothing at all about a local_hooks.yaml
    # declaration that is now dead weight -- the file is fine, the declaration
    # is stale, and only this line says so.
    sombreados = [f"EXTRA_HOOK_SHADOWED_BY_CANON ({h}) -- the canonical config "
                  f"now declares this id too; this repo's own copy in "
                  f".simplecode/local_hooks.yaml was dropped from the composed "
                  f"config to avoid writing the id twice -- remove it there"
                  f"{_shadowed_hook_semantic_diff(config_file.parent, h)}"
                  for h in _extra_hooks_shadowed_by_canonical(config_file.parent)]
    if current == expected:
        return sombreados

    # Name the hooks this overwrite would remove, BEFORE removing them.
    # Measured 2026-09-01: this printed `UPDATED (canonical config)` and nothing
    # else while deleting Atlas's `tenancy-isolation` gate 63 minutes after it
    # was voted and verified with a negative control -- 11 multi-tenant
    # isolation tests that nothing else ran, with legally privileged files
    # arriving in a sibling repo. The legitimate path is
    # `.simplecode/local_hooks.yaml`, whose hooks survive because they are part
    # of `expected`; a hook written straight into the config is not, and used to
    # vanish without a word. Atlas's framing: two sources of the same truth, and
    # the sync resolving the conflict by deleting one in silence.
    # Reported ALONGSIDE the rest, never instead of it: an early return here hid
    # the drift verdict and the removal warning behind one finding, which is the
    # same "first link of the cascade" mistake that cost this session five push
    # attempts against the wrong gate.
    #
    # LIMIT, declared: this announces the blind hook, it does not withhold it.
    # declutter asked for the hook not to be installed at all, which is the right
    # end state and needs the composer to filter it out of the canonical text.
    # That text is kept byte-exact for drift detection, so filtering it is a
    # separate change and a riskier one across 12 repos. Loud beats silent today;
    # absent beats loud tomorrow.
    # WITHHELD, not merely announced: `expected` already had these stripped, so
    # this line reports what the sync is about to take OUT of the satellite.
    # `_hooks_without_subject(expected, ...)` still runs afterwards because a
    # satellite's own `extra_hooks` can add a blind hook that the canonical
    # strip never sees -- that one can only be announced, since it is the
    # satellite's own declaration and not ours to delete.
    _, retirados = _strip_hooks_without_subject(CANONICAL_PRE_COMMIT_CONFIG, config_file.parent)
    sin_sujeto = [f"HOOK_WITHHELD ({h}) -- its --subdir is absent here, so it could "
                  f"only measure nothing; not installed" for h in retirados]
    sin_sujeto += [f"HOOK_WITHOUT_SUBJECT ({s}) -- declared in this repo's own "
                   f"local_hooks.yaml with a --subdir that is absent here"
                   for s in _hooks_without_subject(expected, config_file.parent)]
    sin_sujeto += sombreados
    # `local_hooks.yaml` (extra hooks, read here) and `hooks-local.yaml` (per-
    # developer SKIP) sit in the same directory one letter and one hyphen apart
    # and do opposite things. Atlas looked for the wrong one, concluded no
    # extension mechanism existed, and re-applied a deleted gate by hand. Say
    # which file the author probably wanted rather than reading nothing quietly.
    misfiled = hook_local_config.misfiled_key_warning(config_file.parent, "local_hooks.yaml")
    sin_sujeto += [f"MISFILED_LOCAL_CONFIG -- {misfiled}"] if misfiled else []
    # A hook we deliberately withheld is not an "unknown hook about to be
    # deleted": naming it under that heading would tell the operator to declare
    # it in local_hooks.yaml, which is the opposite of the intent.
    perdidos = sorted(_hook_ids(current) - _hook_ids(expected) - set(retirados))
    aviso = ([f"REMOVES_UNKNOWN_HOOKS ({', '.join(perdidos)}) -- declare them in "
              f".simplecode/local_hooks.yaml (key `extra_hooks`) to keep them"]
             if perdidos else [])
    if apply_fix and perdidos:
        return sin_sujeto + aviso + [
            "REFUSED_UNKNOWN_HOOKS -- configuration left untouched; declare each local hook "
            "in .simplecode/local_hooks.yaml (extra_hooks) before syncing"
        ]
    # Mirror of `perdidos`: ids the canonical config declares that this
    # satellite's OWN tracked file currently lacks. Fires for a brand-new
    # canonical hook just as much as for one a satellite deliberately
    # retired by hand (satellite_sync has no way to tell the two apart --
    # both look identical from git state alone) -- reported by Atlas,
    # DGX-475, 2026-09-06: `ledger-schema`, retired here by a documented
    # vote outside the scope of that day's sync, came back silently and
    # blocked every commit on 128 pre-existing UNVERIFIED fichas. This does
    # NOT withhold the hook -- `--fix` still installs it, exactly as before
    # this existed -- it only says so, loud, so a retirement made on purpose
    # does not have to be rediscovered the hard way after the fact.
    reintroducidos = sorted(_hook_ids(expected) - _hook_ids(current))
    aviso += ([f"HOOK_REINTRODUCED ({', '.join(reintroducidos)}) -- absent from this "
               "repo's own .pre-commit-config.yaml (retired here, or newly canonical) "
               "and about to be (re)installed by this sync"]
              if reintroducidos else [])
    if apply_fix:
        # Sync owns kit files only.  A configuration conflict is reported in
        # the plan; it never creates, moves, or rewrites the project's tasks.
        atomic_io.write_text_durable(config_file, expected)
        return sin_sujeto + aviso + ["UPDATED (canonical config)"]
    return sin_sujeto + aviso + ["DRIFTED (canonical config mismatch)"]


def _bundle_version_from_bytes(data: bytes) -> str:
    """The `simplecode_version` a runtime.zip bundle was frozen at, for a
    human-readable drift message ("satellite=0.1.0, mother=3.7.0") instead
    of an opaque byte-mismatch flag. A bundle from before RUNTIME_MANIFEST.json
    existed (commit 7c27c19) reports "pre-manifest"; a bundle that fails to
    open at all reports "unreadable" -- both distinct from "unknown", which
    the manifest itself uses when `_source_version` could not resolve one."""
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            manifest = json.loads(archive.read("RUNTIME_MANIFEST.json").decode("utf-8"))
            return str(manifest.get("simplecode_version", "unknown"))
    except KeyError:
        return "pre-manifest"
    except (OSError, zipfile.BadZipFile):
        return "unreadable"


def _bundle_version(bundle: Path) -> str:
    """`_bundle_version_from_bytes` for a bundle already on disk (a satellite's
    `.simplecode/runtime.zip`), reporting "missing" when there is none yet."""
    if not bundle.is_file():
        return "missing"
    return _bundle_version_from_bytes(bundle.read_bytes())


def _sync_runtime(
    satellite: Path, apply_fix: bool, runtime: tuple[str, bytes] | None = None,
) -> list[str]:
    runtime_dir = satellite / ".simplecode"
    runner, bundle = runtime_dir / "run.py", runtime_dir / "runtime.zip"
    expected_runner, expected_bundle = runtime or (cli_new._portable_runner(), cli_new._runtime_bundle())
    current_runner = runner.read_bytes() if runner.is_file() else None
    current_bundle = bundle.read_bytes() if bundle.is_file() else None
    changes = [(path, expected) for path, current, expected in (
        (runner, current_runner, expected_runner.encode("utf-8")),
        (bundle, current_bundle, expected_bundle),
    ) if current != expected]
    if not changes:
        return []
    satellite_version = _bundle_version_from_bytes(current_bundle) if current_bundle else "missing"
    mother_version = _bundle_version_from_bytes(expected_bundle)
    parts = [path.name for path, _ in changes]
    detail = f"satellite={satellite_version}, mother={mother_version}, differs: {'+'.join(parts)}"
    if satellite_version == mother_version and "runtime.zip" in parts:
        detail += " -- SAME VERSION, DIFFERENT CONTENT: the version number did not move with the code"
    if not apply_fix:
        return [f"RUNTIME_DRIFTED ({detail})"]
    for path, expected in changes:
        atomic_io.write_bytes_durable(path, expected)
        claims.claim(
            path, owner="simplecode-kit:sync_runtime", ttl_seconds=600,
            command="simplecode sync-satellites --fix", root=satellite,
        )
    return [f"RUNTIME_INSTALLED ({satellite_version} -> {mother_version})"]


def _sync_kit_lock(
    satellite: Path, apply_fix: bool, runtime: tuple[str, bytes] | None = None,
) -> list[str]:
    """Verify or install the immutable identity for the managed runtime files."""
    runtime_dir = satellite / ".simplecode"
    runner, bundle = runtime_dir / "run.py", runtime_dir / "runtime.zip"
    expected_runner, expected_bundle = runtime or (cli_new._portable_runner(), cli_new._runtime_bundle())
    expected = cli_new.kit_lock_bytes(expected_runner, expected_bundle)
    lock = runtime_dir / "kit.lock"
    current = lock.read_bytes() if lock.is_file() else None
    if current == expected:
        return []
    if not apply_fix:
        return ["KIT_LOCK_DRIFTED (.simplecode/kit.lock)"]
    # A lock may only be written with the exact runner and bundle it describes.
    if not runner.is_file() or not bundle.is_file():
        return ["KIT_LOCK_REFUSED (runtime files missing)"]
    if runner.read_text(encoding="utf-8") != expected_runner or bundle.read_bytes() != expected_bundle:
        return ["KIT_LOCK_REFUSED (runtime files do not match expected release)"]
    atomic_io.write_bytes_durable(lock, expected)
    claims.claim(
        lock, owner="simplecode-kit:sync_runtime", ttl_seconds=600,
        command="simplecode sync-satellites --apply", root=satellite,
    )
    return ["KIT_LOCK_INSTALLED"]


# `.simplecode/claims.json` (and its `.bak`) are TTL'd claim-lock state
# (worktree/claims.py), never product material -- and `_sync_runtime`/
# `_sync_kit_lock` above WRITE it unconditionally via `claims.claim()` every
# time a sync actually touches a satellite's runtime files. Before this, no
# `_sync_*` pass ever touched `.gitignore`, so a satellite scaffolded before
# `claims.py` existed (or one whose `.gitignore` predates this fix) kept
# whichever ignore list it was born with, and the very sync run that writes
# the claim leaves it untracked in `git status` (DEBT-CLAIM-STATE-DIRTY-
# AFTER-SYNC). Kept as explicit literal entries here, matching
# `cli_new._write_project`'s own enumerated `.gitignore` style, rather than a
# blanket `.simplecode/*` -- a blanket pattern would also swallow
# kit.lock/run.py/runtime.zip, which a satellite must be able to `git add`
# the first time sync installs them (see `_sync_runtime`'s "fresh scaffolds
# track both runtime files").
REQUIRED_GITIGNORE_ENTRIES = (
    ".simplecode/claims.json",
    ".simplecode/claims.json.bak",
)

# A satellite that already hand-rolled a wider ignore (e.g. its own
# `.simplecode/*` line) already covers a required entry; literal-line
# matching only (no gitignore glob engine -- YAGNI for two fixed paths),
# so this is not a general "is X ignored" check, just enough to avoid
# rewriting a `.gitignore` that already does the job.
def _covering_patterns(entry: str) -> tuple[str, ...]:
    directory = entry.rsplit("/", 1)[0]
    return (entry, f"{directory}/*", f"{directory}/", directory)


def _untrack_claim_state(satellite: Path, apply_fix: bool) -> list[str]:
    """`.gitignore` only stops git from tracking a path that isn't tracked
    YET -- a satellite that committed `.simplecode/claims.json` (or `.bak`)
    before this sync existed keeps tracking it forever after, no matter how
    many times the ignore rule gets added. Confirmed live in declutter
    (2026-09-13): both files were already tracked, `_sync_gitignore` had just
    added their `.gitignore` lines, and `git status` still showed them
    modified -- every future claim-lock write was going to keep showing up as
    a dirty file, unresolved by the ignore rule alone.

    `git rm --cached` drops the index entry only; the working-tree file is
    left untouched, matching this module's documented non-destructive posture
    (content on disk is never deleted, only untracked).
    """
    issues: list[str] = []
    for entry in REQUIRED_GITIGNORE_ENTRIES:
        if not git_utils.git_is_tracked(entry, satellite):
            continue
        if not apply_fix:
            issues.append(f"GITIGNORE_CLAIM_STATE_TRACKED ({entry})")
            continue
        rc, _, stderr = git_utils.run_git(["rm", "--cached", "-q", "--", entry], satellite)
        if rc != 0:
            detail = stderr.decode("utf-8", "replace").strip()
            issues.append(f"GITIGNORE_CLAIM_STATE_UNTRACK_FAILED ({entry}: {detail})")
            continue
        issues.append(f"GITIGNORE_CLAIM_STATE_UNTRACKED ({entry})")
    return issues


def _sync_gitignore(satellite: Path, apply_fix: bool) -> list[str]:
    """Ensure `.gitignore` carries the claim-state entries the sync composer
    otherwise never touches (DEBT-CLAIM-STATE-DIRTY-AFTER-SYNC), and that
    those entries are not left tracked out from under the new rule.

    The `.gitignore` write is additive only: appends whichever required lines
    are missing, never rewrites, reorders, or removes anything already in the
    satellite's own `.gitignore` -- the same non-destructive posture as
    `_merge_missing_markers`. The untrack step below is checked unconditionally
    (not skipped when nothing was missing), since an entry can already be
    covered by an existing pattern while the file underneath is still tracked.
    """
    gitignore = satellite / ".gitignore"
    text = gitignore.read_text(encoding="utf-8") if gitignore.is_file() else ""
    present = {line.strip() for line in text.splitlines()}
    missing = [
        entry for entry in REQUIRED_GITIGNORE_ENTRIES
        if not present.intersection(_covering_patterns(entry))
    ]
    issues: list[str] = []
    if missing:
        if not apply_fix:
            issues.append(f"GITIGNORE_CLAIM_STATE_MISSING ({', '.join(missing)})")
        else:
            new_text = text
            if new_text and not new_text.endswith("\n"):
                new_text += "\n"
            new_text += "".join(f"{entry}\n" for entry in missing)
            atomic_io.write_text_durable(gitignore, new_text, backup=True)
            issues.append(f"GITIGNORE_CLAIM_STATE_ADDED ({', '.join(missing)})")
    issues.extend(_untrack_claim_state(satellite, apply_fix=apply_fix))
    return issues


def _sync_hook_assets(satellite: Path, apply_fix: bool) -> list[str]:
    """Files the shipped hooks READ but that the kit never shipped.

    `vices-semgrep` is wired into every satellite's config and invokes
    `semgrep --config rules/custom/vices_unique.yaml`. That file lives here and
    was propagated nowhere: measured 2026-09-01 across Atlas, aequitas_os,
    declutter and RePic, absent from all four. The gate therefore exits 7
    (config not found) on every run in every satellite and has never been able
    to convict anything -- its recorded "blocks" are the runner failing to find
    itself. Reported by declutter, who read the rc rather than the pass/fail.

    Shipping the hook and withholding what the hook reads is the same shape as
    fixing a gate in this repo and not in `cli_new`'s template: the config
    arrives, the capability does not, and the satellite reports green.
    """
    issues: list[str] = []
    for rel in HOOK_ASSET_FILES:
        source = MOTHER_ROOT / rel
        if not source.is_file():
            # Fail loudly rather than skipping: an asset the kit promises and
            # cannot find is a broken kit, not a satisfied satellite.
            issues.append(f"ASSET_MISSING_AT_SOURCE ({rel})")
            continue
        target = satellite / rel
        expected = source.read_bytes()
        if target.is_file() and target.read_bytes() == expected:
            continue
        if not apply_fix:
            issues.append(f"ASSET_DRIFTED ({rel})")
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        atomic_io.write_bytes_durable(target, expected)
        issues.append(f"ASSET_INSTALLED ({rel})")
    return issues


# ---- Makefile parity, measured BY TARGET and never written (DEBT-PUSH-LOOP-10) ----
# GNU make's own search order, so this organ reads the file make itself would read.
# `find -maxdepth 1 -iname makefile*` was the census's probe precisely because a
# `[ -f Makefile ]` misses the other two spellings and calls the repo clean.
MAKEFILE_NAMES = ("GNUmakefile", "makefile", "Makefile")

# The absent verdict as a named constant: it is a THIRD state beside drift and
# alignment, and callers (including `sync_all_satellites`' own tests) need to
# compare against it exactly rather than against a wording that may be reworded.
MAKEFILE_ABSENT = (
    "MAKEFILE_ABSENT (no GNUmakefile, makefile or Makefile -- no subject to compare)"
)

# A rule line: a target name at column zero (after optional leading spaces, which
# make accepts and the pre-2026-09-15 template emitted) followed by `:` but NOT
# `:=`, which is a variable assignment. `.PHONY` is excluded by the leading-char
# class: it is a declaration, it has no recipe, and its target list is not a recipe.
_MAKE_RULE_RE = re.compile(
    r"^([A-Za-z0-9_][A-Za-z0-9_.\-]*(?:[ \t]+[A-Za-z0-9_][A-Za-z0-9_.\-]*)*)[ \t]*:(?!=)"
)

# A recipe line declaring its own override deliberate. RePic's Makefile carries two
# -- `@# LOCAL LEGITIMATE (...)` on `mutate` and `@# LOCAL, UNDETERMINED (...)` on
# `install` -- written 2026-09-15 for this organ to read, not as prose.
_MAKE_LOCAL_MARKER_RE = re.compile(r"^\t@?#[ \t]*LOCAL\b")


def _makefile_targets(text: str) -> dict[str, list[str]]:
    """Split a Makefile into ``target -> recipe lines``.

    Per TARGET, because the FILE is not the canon: a satellite's Makefile
    legitimately carries targets of its own, and the 8 stray spaces the old
    template put on every definition line (measured live in Twiner, 2026-09-15,
    from a `textwrap.dedent` that was a no-op) make a whole-file diff announce a
    difference make itself cannot see. A recipe line is a line beginning with a
    literal TAB -- make's own rule, not an approximation of it.
    """
    targets: dict[str, list[str]] = {}
    current: str | None = None
    for line in text.splitlines():
        if line.startswith("\t"):
            if current is not None:
                targets[current].append(line)
            continue
        match = _MAKE_RULE_RE.match(line.lstrip(" "))
        if match:
            name = match.group(1).split()[0]
            targets.setdefault(name, [])
            current = name
        elif line.strip():
            current = None
    return targets


def _makefile_project_name(satellite: Path) -> str | None:
    """The ``[project] name`` the satellite's canonical Makefile is generated from.

    Read from the satellite's own `pyproject.toml`, NEVER from its Makefile:
    deriving the expected text from the subject under comparison is a check that
    cannot come out negative. Nor from the directory name -- measured 2026-09-15
    on the three satellites that have a Makefile, `RePic`'s project is `repic`,
    so `name.replace("-", "_")` over the directory name would have reported a
    false `deps` drift in that repo.

    Measured the other way too: instantiating `cli_new._makefile(name,
    name.replace("-", "_"))` (the same derivation `cli_new.main` uses at scaffold
    time) with the names read here reproduced the `deps` recipe byte for byte in
    all three -- `repic`, `twiner`, `declutter` -- turning 3 false positives into
    0. `None` when no name can be read; the caller turns that into COULD_NOT_RUN,
    never into a pass.
    """
    try:
        data = tomllib.loads((satellite / "pyproject.toml").read_text(encoding="utf-8"))
    except (OSError, UnicodeError, tomllib.TOMLDecodeError):
        return None
    project = data.get("project")
    name = project.get("name") if isinstance(project, dict) else None
    return name if isinstance(name, str) and name else None


def _classify_makefile_targets(
    canonical: dict[str, list[str]], present: dict[str, list[str]],
) -> tuple[list[str], list[str]]:
    """Split the canonical targets into (drifted, locally declared).

    Only CANONICAL targets are judged: a satellite's own extra targets are its
    business, which is the whole reason the Makefile is not synchronised as a
    file. A target absent from the satellite is drift with its own wording --
    skipping it is how a satellite carrying half the canonical targets would
    report clean.
    """
    drifted: list[str] = []
    declared: list[str] = []
    for target, recipe in canonical.items():
        found = present.get(target)
        if found == recipe:
            continue
        if found is None:
            drifted.append(f"{target} (target absent)")
        elif any(_MAKE_LOCAL_MARKER_RE.match(line) for line in found):
            declared.append(target)
        else:
            drifted.append(target)
    return drifted, declared


def _sync_makefile(satellite: Path) -> list[str]:
    """Report how a satellite's Makefile diverges from the canonical, by TARGET.

    THIS FUNCTION NEVER WRITES, and it takes no `apply_fix` parameter because
    there is nothing for `--fix` to do here: under `--fix` the kit does exactly
    what it does under a plain check, which is measure and say so. That is Luis's
    registered decision of 2026-09-15 (`DECISIONS.md`, "El Makefile de un
    satelite no se pisa: la divergencia se mide por TARGET"), and its measured
    basis is that of the 3 satellites in the fleet that have a Makefile, NONE
    could be overwritten with a copy of the canonical without destroying
    something: declutter's `.github/workflows/ci.yml` called `make check` on a
    `check` that measured coverage/lint/types, so the canonical `check` would
    have kept its CI green or red for reasons unrelated to what it protected;
    RePic's `mutate` points at `pytest -q` because that repo has no `src/` tree
    at all (the engine is Rust) and the canonical MUTATE_TARGET would report a
    missing file instead of a mutation verdict. So: the organ measures, a human
    decides. An `apply_fix` argument accepted and ignored would be a parameter
    that lies.

    Divergence is classified by reading the satellite's OWN declaration: a recipe
    line matching ``@# LOCAL ...`` marks that override deliberate, so the target
    is counted apart and is NOT drift. The rejected alternative, named in the
    same decision, was a registry of historical canonical recipe texts that this
    module would have to carry forever.

    Four verdicts, and none of them collapses into another:

    ``MAKEFILE_ABSENT``
        No Makefile at all -- 15 of the 18 enrolled satellites, measured
        2026-09-15. Not drift and not clean: there is no subject.
    ``MAKEFILE_DRIFTED``
        A canonical target the satellite differs on, or lacks, with no LOCAL
        marker. Named target by target.
    ``MAKEFILE_LOCAL_DECLARED``
        A canonical target the satellite differs on and says so. Counted apart.
    ``MAKEFILE_COULD_NOT_RUN``
        The file exists but cannot be read, no rule could be parsed out of it, or
        no canonical can be instantiated for this repo. Never a pass: the prefix
        is in `sync_satellite`'s unresolved list and in `main`'s could_not_run
        count, which is the whole point of not calling it drift.
    """
    found = [satellite / name for name in MAKEFILE_NAMES if (satellite / name).is_file()]
    if not found:
        return [MAKEFILE_ABSENT]
    makefile = found[0]
    try:
        text = makefile.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        return [f"MAKEFILE_COULD_NOT_RUN ({makefile.name} unreadable: {exc})"]
    present = _makefile_targets(text)
    if not present:
        return [
            f"MAKEFILE_COULD_NOT_RUN ({makefile.name}: no target rule parsed out of "
            f"{len(text.splitlines())} lines -- a Makefile with no readable rule is "
            f"not a Makefile that agrees with the canonical)"
        ]
    project_name = _makefile_project_name(satellite)
    if project_name is None:
        return [
            f"MAKEFILE_COULD_NOT_RUN ({makefile.name}: cannot instantiate the canonical -- "
            f"pyproject.toml carries no readable [project] name to generate it with)"
        ]
    canonical = _makefile_targets(cli_new._makefile(project_name, project_name.replace("-", "_")))
    drifted, declared = _classify_makefile_targets(canonical, present)
    issues: list[str] = []
    if drifted:
        issues.append(f"MAKEFILE_DRIFTED ({makefile.name}: {', '.join(drifted)})")
    if declared:
        issues.append(f"MAKEFILE_LOCAL_DECLARED ({makefile.name}: {', '.join(declared)})")
    return issues


def _revert_satellite_fraud(satellite: Path) -> list[str]:
    """Check and revert fraudulent tasks in satellite."""
    tasks_dir = satellite / "tasks"
    if not tasks_dir.is_dir():
        return []
    tasks_count = len(list(tasks_dir.glob("**/*.md")))
    if tasks_count > 20:
        return []
    from simplecode.verification.backlog_verifier import verify_closed_tasks
    fraudulent = verify_closed_tasks(satellite, auto_revert=True)
    if fraudulent:
        return [f"REVERTED_{len(fraudulent)}_FRAUD_TASKS"]
    return []


def is_the_mother(satellite: Path) -> bool:
    """Whether this target IS the kit's own repository.

    `discover_satellites` has always excluded it by NAME, but `--target` never
    did, so pointing the sync at the mother composed her config from the
    scaffold template -- which by design does not carry the gates the kit runs
    only on itself (`SIMPLECODE_ONLY`: gate-controls, ratchet-audit,
    findings-detail-ratchet, red-team, build-dist, signed-commit,
    write-hook-receipt, vices-semgrep, observe, deadcode-gate).

    Measured 2026-09-02: a peer session ran the sync against this repository and
    its config went from 32 hooks to 24, losing H2, H3, H4, the red team, the
    dist verification and the receipts producer in one write. The removal was
    ANNOUNCED and materialized as DEBT-SYNC-REMOVED-* tasks -- the mechanisms
    added earlier that day worked -- but announcing the amputation of a third of
    the verification architecture is not the same as not performing it.
    """
    return satellite.resolve() == MOTHER_REPO_ROOT.resolve()


def sync_satellite(
    satellite: Path, apply_fix: bool = False, runtime_only: bool = False,
    *, runtime: tuple[str, bytes] | None = None,
) -> tuple[bool, str]:
    """Check or update a satellite's managed kit files.

    `runtime_only` limits writes to the runner, runtime ZIP and Git launchers.
    Config, assets, coverage, harness and tasks are checked but left unchanged.
    This is a file-role boundary, not a Git tracking boundary: fresh scaffolds
    track both runtime files. It does not guarantee an unchanged index/worktree
    during a hook; stable gate revisions require separating updates from runs.
    """
    if is_the_mother(satellite):
        return False, (
            "REFUSED: this target IS the kit's own repository. Composing its config "
            "from the scaffold template would strip the gates the kit runs only on "
            "itself and does not ship. Nothing was read and nothing was written."
        )
    config_file = satellite / ".pre-commit-config.yaml"
    issues: list[str] = []
    # Writes that touch TRACKED files, withheld in runtime_only mode.
    fix_tracked = apply_fix and not runtime_only

    # Preflight/write the config first: an unregistered local hook makes the
    # canonical overwrite refuse before any other file is touched.
    issues.extend(_sync_config_file(config_file, apply_fix=fix_tracked))
    if any("REFUSED" in issue for issue in issues):
        return False, ", ".join(issues)

    # `.gitignore` precedes runtime/kit-lock writes because those helpers may
    # create `.simplecode/claims.json`; the config preflight above has already
    # ruled out a destructive local-hook conflict.
    issues.extend(_sync_gitignore(satellite, apply_fix=apply_fix))

    # Runtime and config must exist before their Git launchers are installed.
    issues.extend(_sync_runtime(satellite, apply_fix=apply_fix, runtime=runtime))
    issues.extend(_sync_kit_lock(satellite, apply_fix=apply_fix, runtime=runtime))
    issues.extend(_sync_hook_assets(satellite, apply_fix=fix_tracked))

    hook_ok, hook_msg = _ensure_hook_installed_and_executable(satellite, apply_fix=apply_fix)
    if not hook_ok:
        issues.append(hook_msg)

    # 3. Verify .coverage_watermark
    issues.extend(_sync_watermark_file(satellite, apply_fix=fix_tracked))

    # 4. Verify test harness configuration (GS2-215)
    issues.extend(_sync_harness_config(satellite, apply_fix=fix_tracked))

    # 5. Verify the telemetry disposition cutoff is declared (DEBT-PUSH-LOOP-03).
    # `fix_tracked`, never `apply_fix`: the file is TRACKED, so a `--runtime-only`
    # hot pull firing inside somebody else's commit must not write it. DECLARED
    # LIMIT, also written in the ficha: a satellite that receives this kit only
    # through `--runtime-only`, before any full `--fix`, will meet the gate with
    # no declaration and get COULD_NOT_RUN (rc 2) naming the repair command --
    # never a mute block and never a silent pass.
    issues.extend(_sync_cutoff_declaration(satellite, apply_fix=fix_tracked))

    # 6. Measure -- never write -- the Makefile's distance from the canonical,
    # target by target (DEBT-PUSH-LOOP-10). No `apply_fix` argument on purpose:
    # see `_sync_makefile`'s docstring for Luis's decision and its measured basis.
    issues.extend(_sync_makefile(satellite))

    if not issues:
        return True, "ALIGNED"

    status_str = ", ".join(issues)
    # COULD_NOT_RUN is in this list because it is a DISTINCT verdict from a
    # finding and must never read as a pass. MAKEFILE_ABSENT and
    # MAKEFILE_LOCAL_DECLARED are deliberately NOT here: the first means there is
    # no subject and the second means the satellite declared its override, and a
    # report that goes permanently red on 17 of 18 satellites stops being read.
    unresolved = any(any(marker in issue.partition(" (")[0] for marker in (
        "REFUSED", "UNDECODABLE", "MISSING", "DRIFTED", "NOT_EXECUTABLE",
        "CRLF", "FAILED", "NO .git/hooks", "NOT_A_GIT_REPO", "COULD_NOT_RUN",
    )) for issue in issues)
    return not unresolved, status_str


def is_mother_repo(root: Path) -> bool:
    """Whether `root` really is the simplecode source repo, rather than a guess.

    `MOTHER_REPO_ROOT` is derived by counting directories up from `__file__`,
    which is only correct in the mother's own source layout. Imported from a
    satellite's `runtime.zip` or its `.simplecode/` tree, the same arithmetic
    lands on a directory that is not the mother and never was.
    """
    return (root / "src" / "simplecode" / "satellite" / "satellite_sync.py").is_file()


def check_own_conformance(apply_fix: bool = False) -> tuple[bool, list[str]]:
    """Verify the mother repo's own pytest harness satisfies GS2-215.

    Fleet-wide GS2-215 enforcement means nothing if the mother repo that
    defines the canonical standard does not meet it itself. This is checked
    (and, with apply_fix, corrected) on every satellite_sync run, independent
    of --target/--projects-dir, so a drifted mother repo is never silently
    excluded from its own rule.

    Refuses outright when the path this module computed as the mother is not
    the mother. Reported by Atlas 2026-09-01 with literal output: run from
    inside a satellite, the sync took that satellite's `.simplecode/` as the
    mother, said `MISSING_HARNESS` about it, and under `--fix` reported
    `HARNESS_INSTALLED` -- it failed at what it was asked AND wrote anyway,
    into a gitignored path the operator cannot see in git. The refusal comes
    BEFORE `_sync_harness_config` precisely so that no write happens: a check
    that cannot identify its own subject must not repair it.
    """
    if not is_mother_repo(MOTHER_REPO_ROOT):
        return (False, [
            f"NOT_THE_MOTHER_REPO ({MOTHER_REPO_ROOT}) -- this module was imported "
            f"from {Path(__file__).resolve()}, which puts the mother repo at a "
            f"directory holding no src/simplecode/. Nothing was checked and nothing "
            f"was written. Run this from the simplecode checkout, with "
            f"--target pointing at the repo you want synced."
        ])
    issues = _sync_harness_config(MOTHER_REPO_ROOT, apply_fix=apply_fix)
    return (not issues, issues)


def sync_all_satellites(
    projects_dir: Path, apply_fix: bool = False, runtime_only: bool = False,
    *, satellites: list[Path] | None = None,
) -> dict[str, tuple[bool, str]]:
    """Use one runtime snapshot and retain every satellite's actual verdict."""
    selected = discover_satellites(projects_dir) if satellites is None else satellites
    if not selected:
        return {}
    scope = enrolled_python_product_scope()
    results = {
        sat.name: (True, "OUT_OF_SCOPE_NO_PYTHON_PRODUCT (no satellite files written)")
        for sat in selected if scope.get(sat.name) is False
    }
    applicable = [sat for sat in selected if scope.get(sat.name) is True or sat.name not in scope]
    runtime = (cli_new._portable_runner(), cli_new._runtime_bundle()) if applicable else None
    for sat in applicable:
        try:
            results[sat.name] = sync_satellite(
                sat, apply_fix=apply_fix, runtime_only=runtime_only, runtime=runtime,
            )
        except (OSError, ValueError, yaml.YAMLError) as exc:
            results[sat.name] = (False, f"COULD_NOT_RUN ({exc})")
    return results


def _resolve_target(target: Path, projects_dir: Path) -> Path:
    """Resolve a `--target` value the way a caller actually means it.

    A bare or relative name (`--target aequitas_os`) is meant as a satellite
    under `--projects-dir`, the same tree `discover_satellites` scans -- not a
    path relative to the current working directory. Resolving against cwd
    silently missed the real satellite and, under `--fix`, wrote a brand new
    phantom directory tree (`.git/`, `.pre-commit-config.yaml`, ...) wherever
    the caller happened to be standing; the caller-facing `.git` existence
    check in `main` is the second half of the fix, catching any path -- from
    this or a genuine typo -- that still doesn't land on a real repo. An
    already-absolute target is used as given.
    """
    if target.is_absolute():
        return target.resolve()
    under_projects = (projects_dir / target).resolve()
    if under_projects.is_dir():
        return under_projects
    return target.resolve()


def _sync_fleet_cli(args: argparse.Namespace) -> int:
    try:
        enrolled = enrolled_satellites(args.projects_dir.resolve())
        scope = enrolled_python_product_scope()
    except ValueError as exc:
        print(f"[satellite-sync] COULD_NOT_RUN: {exc}")
        return 1
    missing = sorted({sat.name for sat in enrolled} - set(scope))
    if missing:
        print(f"[satellite-sync] COULD_NOT_RUN: missing product scope for {missing}")
        return 1
    applicable = [sat for sat in enrolled if scope.get(sat.name) is True]
    results = sync_all_satellites(
        args.projects_dir.resolve(), apply_fix=args.apply_fix, runtime_only=args.runtime_only,
        satellites=applicable,
    )
    results.update({
        sat.name: (True, "OUT_OF_SCOPE_NO_PYTHON_PRODUCT (no satellite files written)")
        for sat in enrolled if scope.get(sat.name) is False
    })
    failed = sum(not ok for ok, _ in results.values())
    could_not_run = sum("COULD_NOT_RUN" in msg for _, msg in results.values()) or int(not results)
    print(f"\n=== SATELLITE FLEET SYNCHRONIZATION ({len(results)} satellites) ===")
    for name, (ok, msg) in sorted(results.items()):
        mark = "—" if msg.startswith("OUT_OF_SCOPE_NO_PYTHON_PRODUCT") else "✓" if ok else "✗"
        print(f"  [{mark}] {name:30s} -> {msg}")
    print(f"[satellite-sync] checked={len(results)} failed={failed} could_not_run={could_not_run}")
    print(
        f"[satellite-sync] scope: python_product={len(applicable)} "
        f"out_of_scope={len(enrolled) - len(applicable)}"
    )
    print(
        "[satellite-sync] makefile: "
        f"drifted={sum('MAKEFILE_DRIFTED' in msg for _, msg in results.values())} "
        f"local_declared={sum('MAKEFILE_LOCAL_DECLARED' in msg for _, msg in results.values())} "
        f"absent={sum('MAKEFILE_ABSENT' in msg for _, msg in results.values())} "
        f"could_not_run={sum('MAKEFILE_COULD_NOT_RUN' in msg for _, msg in results.values())} "
        "(absent = no Makefile at all: no subject, not a pass)"
    )
    if not results:
        print("[satellite-sync] COULD_NOT_RUN: no satellites found")
        return 1
    if failed:
        print("[satellite-sync] Unresolved satellite issues; see the per-target results.")
        return 1
    print("[satellite-sync] Fleet gates successfully verified and aligned.")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Plan, apply, or verify an explicit Simplecode kit revision.")
    ap.add_argument("--projects-dir", type=Path, default=Path.home() / "projects")
    ap.add_argument("--target", type=Path, default=None, help="Target specific satellite path")
    ap.add_argument("--plan", action="store_true", help="Report drift without writing managed files")
    ap.add_argument("--apply", "--fix", action="store_true", dest="apply_fix",
                    help="Apply updates explicitly; --fix is retained as an alias")
    ap.add_argument("--runtime-only", action="store_true",
                    help="Refresh run.py, runtime.zip and kit.lock without changing tracked config")
    args = ap.parse_args(argv)

    if args.plan and args.apply_fix:
        ap.error("--plan and --apply are mutually exclusive")

    mother_ok, mother_issues = check_own_conformance(apply_fix=args.apply_fix)
    if not mother_ok:
        print(
            f"\033[31m[satellite-sync] FATAL: mother repo ({MOTHER_REPO_ROOT.name}) fails its "
            f"own GS2-215 harness conformance: {', '.join(mother_issues)}\033[0m"
        )
        return 1

    if args.target:
        target = _resolve_target(args.target, args.projects_dir.resolve())
        # Worktrees and submodules carry `.git` as a FILE holding
        # `gitdir: <path>`, so the old `(target / ".git").is_dir()` refused every
        # one of them. Reported by the fleet-canon pilot 2026-09-02: all agent
        # work in Atlas happens in worktrees, so no worktree there could sync at
        # all. The fix already existed in `hook_receipts.get_git_dir`, a few
        # files away, with a docstring describing this exact failure -- two
        # readings of `.git` in one kit, one fixed and one not, and nothing
        # crossing them. `organ_crossings` crosses them now.
        if not hook_receipts.is_git_repo(target):
            print(
                f"\033[31m[satellite-sync] FATAL: target '{target}' is not a git repository "
                f"(no .git directory, no worktree pointer file) -- refusing to write there.\033[0m"
            )
            return 1
        try:
            scope = enrolled_python_product_scope()
        except ValueError as exc:
            print(f"[satellite-sync] COULD_NOT_RUN: {exc}")
            return 1
        ok, msg = sync_scoped_satellite(
            target,
            python_product=scope.get(target.name, True),
            apply_fix=args.apply_fix,
            runtime_only=args.runtime_only,
        )
        print(f"[{target.name}] {msg}")
        if ok and args.apply_fix:
            # `fail_fast: false` already makes pre-commit report every hook's
            # verdict in one run, but pre-commit-stage and pre-push-stage
            # hooks only fire on a real `git commit`/`git push` -- so a fresh
            # adoption discovers each stage's failures only by attempting
            # one. Both stages can be run by hand, against everything, with
            # no commit or push at all: printed here because newly-adopted
            # repos (RePic, blackbox, 2026-09-08) discovered this only after
            # ~15 sequential commit-fails-fix cycles.
            print(
                "\nNext: see every pre-commit AND pre-push finding in one pass, "
                "before committing anything --\n"
                "  pre-commit run --config .pre-commit-config.yaml --hook-stage pre-commit --all-files\n"
                "  pre-commit run --config .pre-commit-config.yaml --hook-stage pre-push --all-files"
            )
        return 0 if ok else 1

    return _sync_fleet_cli(args)


if __name__ == "__main__":
    sys.exit(main())
